#!/usr/bin/python -tt

import collections
import httplib
import threading
import socket
import redis
import json
import logging
import uuid
import re
from error_configuration import USER_ERROR
from gevent.pywsgi import WSGIServer
from urllib import quote

ERROR_ACS_TIMEOUT = "504 Gateway Time-out"
ERROR_ACS_BADGW = "502 Bad Gateway"
TICKET_TIMEOUT_MSG = "Timeout finding ticket"
GW_TIMEOUT_MSG = "TImeout connecting ACS"
GW_CONNECTERR_MSG = "Error connecting ACS"

SOAP_HEADER = """<soap:Envelope
        xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
        xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xmlns:xsd="http://www.w3.org/2001/XMLSchema"
        """
SOAP_FAULT_HEADER = """<SOAP-ENV:Body>
        <SOAP-ENV:Fault>
           <faultcode xsi:type="xsd:string">SOAP-ENV:Client</faultcode>
           <faultstring xsi:type="xsd:string">"""
SOAP_FAULT_FOOTER = """
           </faultstring>
       </SOAP-ENV:Fault>
       </SOAP-ENV:Body>"""

SOAP_FOOTER = """
</SOAP-ENV:Envelope>"""

BAD_GW_RESPONSE = {
    "status": ERROR_ACS_BADGW,
    "msg": GW_CONNECTERR_MSG
}

GW_TIMEOUT_RESPONSE = {
        "status": ERROR_ACS_TIMEOUT,
        "msg": GW_TIMEOUT_MSG
}

TICKET_TIMEOUT_RESPONSE = {
        "status": ERROR_ACS_BADGW,
        "msg": TICKET_TIMEOUT_MSG
}


class proxyCB(object):

    def __init__(self, config_param, logger=None, init_redis=True):

        self.cfg = config_param
        self.redis_conn = ""
        self.req_type = "REST"
        if logger:
            netmsg = 'ax.callbackproxy_wrapper.networkmsg'
            self.logger = logger
            self.logger2 = logging.getLogger(netmsg)
        else:  # unit test need logging instance
            proxy_log = 'ax.callback_proxy.proxy_cb'
            self.logger2 = self.logger = logging.getLogger(proxy_log)

        if init_redis:
            self.redis_conn = self.initialize_redis()
        # stop the application on True
        self.my_wsgi = None

    def _retrieve_redisinfo(self, r_info):

        redis_info = {}

        try:
            ip = r_info.split(',')[0]
            port = r_info.split(',')[1]
            pasw = r_info.split(',')[2]
            tmp_db = r_info.split(',')[3]
            # db index is db(x)
            db_idx = tmp_db[2:]
            if db_idx == '':
                db_idx = 0
        except:
            self.logger.debug("Can not parse redis keys %s", r_info)
            raise

        redis_info = {
                      "ip": ip,
                      "port": port,
                      "pasw": pasw,
                      "db": db_idx
                      }

        return redis_info

    def redis_connect(self, redis_info, to):
        """
        internal wrapper for redis connect
        :param : list containing redis server info
        :param to: timeout socket
        :return : list of connected servers
        """
        red_inf = self._retrieve_redisinfo(redis_info)

        try:
                r_server = redis.StrictRedis(host=red_inf["ip"],
                                             port=int(red_inf["port"]),
                                             password=red_inf["pasw"],
                                             db=int(red_inf["db"]),
                                             socket_timeout=to)
                r_server.ping()
                self.logger.debug(
                                  "Connect success for redis [%s:%s/%s]" % (
                                    red_inf["ip"],
                                    red_inf["port"],
                                    red_inf["db"])
                                )
        except:
                server_info = red_inf["ip"] + ":" + str(red_inf["port"])
                self.logger.debug("Timeout [%d]s when connecting redis [%s]"
                                  % (to, server_info))

                raise

        return r_server

    def redis_reconnect(self, redis_ip):
        """
        In some cases, the redis server can be down
        a reconnect should be done for all redis-servers
        that were not up on INIT
        servers that <were> up on INIT is also re-checked
        :param: redis info <port:ip:db>
        return strictredis object
        """

        # for easier logging purpose
        r_info = self._retrieve_redisinfo(redis_ip)

        # This server was up at Init.
        # check if this redis server is still ok
        reconnect = False
        conn = ""
        if self.redis_conn and self.redis_conn[redis_ip]:
            try:
                conn = self.redis_conn[redis_ip]
                conn.ping()
                self.logger.debug("Re-check Server [%s:%s] OK"
                                  % (r_info["ip"], r_info["port"]))
            except:
                self.logger.debug("Reconnect <Init> Server needed for [%s:%s]"
                                  % (r_info["ip"], r_info["port"]))
                reconnect = True
        else:
                self.logger.debug("Reconnect needed for [%s:%s]"
                                  % (r_info["ip"], r_info["port"]))
                reconnect = True

        # if server was down then reconnect
        if reconnect:
                try:
                    conn = self.redis_connect(redis_ip,
                                              self.cfg["redis_timeout"])
                except:
                    self.logger.debug("Reconnect fails, ignoring this server")
                    conn = ""
        return conn

    def _parse_rediscfg(self, cfg):
        """
        parse the configuration and return
        the corresponding servers
        param: user defined config
        return: parsed servers
        """
        # redis servers has the format of
        # redis://pass@ip:port/db,redis://pas@ip:port/db
        # or redis://ip:port/db
        reg_exp = r"redis://(.*?)(?=\s*,\s*redis://|$)"
        servers = re.findall(reg_exp, cfg)
        return servers

    def _parse_eachredis(self, redis_srv):
        """
        parse each redis information from user defined config
        """
        idx_defredis = "/db0"
        # no db is specified by user, use zero
        if "/" not in redis_srv:
                redis_srv = redis_srv + idx_defredis

        r_db = redis_srv.rpartition("/")[2]

        db_len = len(r_db) + 1
        str_len = len(redis_srv) - db_len
        redis_ip_port = redis_srv[0:(str_len)]
        pass_ip_port = redis_ip_port.rpartition(":")
        redis_pass_ip = pass_ip_port[0].rpartition("@")

        # redis port
        r_port = int(pass_ip_port[2])
        # redis pass and ip
        r_ip = redis_pass_ip[2]
        r_pass = redis_pass_ip[0]

        # create key for internal process
        r_key = r_ip + "," + str(r_port) + "," + r_pass + "," + str(r_db)
        return r_key

    def initialize_redis(self):
        """
        Connect to redis servers given by args_redis[address:port]
        :return : Dictionary of "ip,port,pass": <server object>
        """
        redis_servers = {}
        servers = self._parse_rediscfg(self.cfg["redis_server"])

        for redis_srv in servers:
            try:

                r_key = self._parse_eachredis(redis_srv)
                r_server = self.redis_connect(r_key, self.cfg["redis_timeout"])
                # save server for checking connection later on
                redis_servers[r_key] = r_server
            except redis.ConnectionError:
                redis_servers[r_key] = ""
                continue
            except:
                self.logger.exception("Can not parse parameter redis-server!")
                raise
        return redis_servers

    def log_originalreq(self, env):
        """
        reconstruct original uri from wsgi env
        :param env
        """
        url_scheme = env['wsgi.url_scheme']
        # pep 333 states this will always be there
        server_name = env['SERVER_NAME']
        server_port = env['SERVER_PORT']
        http_host = env.get('HTTP_HOST')
        script_name = env.get('SCRIPT_NAME', '')
        path_info = env.get('PATH_INFO', '')

        orig_url = url_scheme + "://"
        if http_host:
            orig_url += http_host
        else:
            orig_url += server_name
            orig_url += ":" + server_port
        orig_url += quote(script_name)
        orig_url += quote(path_info)

        return orig_url

    def check_postbody(self, env):
        """
        Internal helper for checking whether
        a post body exist
        :param env: WSGI env
        :return: decoded body
        """

        post_body = ""

        if "CONTENT_LENGTH" in env and env["CONTENT_LENGTH"] != 0:
            post_len = int(env["CONTENT_LENGTH"])
            if post_len:
                post_body = env["wsgi.input"].read(post_len)

        return post_body

    def decode_request(self, env):
        """
        Decoding request coming from NBI

        :param env: PEP 333 environment variables
        :return: headers: HTTPLib ready headers
        """

        headers = {}

        for key, value in env.items():
            if key.startswith("HTTP_"):
                headers[key[5:].replace("_", '-').lower()] = value

        # differentiate request type
        if 'HTTP_SOAPACTION' in env:
            self.req_type = "SOAP"
        else:
            self.req_type = "REST"

        # pep 333 enviro can take the content type from http_x
        # this will cause the http_contentype is not used,
        # hence we take the type from enviro
        if ("CONTENT_TYPE" in env) and (env["CONTENT_TYPE"] != ""):
            headers["content-type"] = env["CONTENT_TYPE"]
            self.logger.debug("Adding content type header %s",
                              env["CONTENT_TYPE"])

        # add x-forwarded-for. If req went from multiple hops,
        # then we append last hop ip address
        # otherwise, create a new x-forwarded-for hdr with last hop
        if "x-forwarded-for" in headers:
            tmp_xhdr = headers["x-forwarded-for"]
            tmp_xhdr += ", "
            tmp_xhdr += env["REMOTE_ADDR"]
        else:
            tmp_xhdr = env['REMOTE_ADDR']

        self.logger.debug("Adding header x-fwd-for : [%s]", tmp_xhdr)
        headers['x-forwarded-for'] = tmp_xhdr

        return headers

    def contact_acs(self, method, path, httplibheaders, postbody):
        """
        HTTPLib hook to ACS
        open the socket and forward the fetched request
        to corresponding ACS URL
        :param httplibheaders: http headers to be forwarded
        :return: response that is received from ACS
        """

        conn = httplib.HTTPConnection(
                        self.cfg["acs_address"],
                        self.cfg["acs_port"],
                        timeout=self.cfg["acs_timeout"]
                        )

        conn.connect()
        conn.request(method, path, postbody, httplibheaders)
        try:
            response = conn.getresponse()
            # check whether async or sync
            ticketid = response.getheader("AX-TicketID")
        except httplib.BadStatusLine:
            self.logger.exception("Unknown HTTP status received")
        except:
            self.logger.exception("Can not get response from acs")

        try:
            response_status = "%d %s" % (response.status, response.reason)

            return {
                    "httpresponse": {
                        "status": response_status,
                        "headers": collections.OrderedDict(
                                       response.getheaders()
                                    ),
                        "msg": response.read()
                    },
                    "ticketid": ticketid
                }
        except:
            self.logger.exception("Can not get response from acs")
        finally:
            response.close()

    def check_ticketid(self, ticketid, conn,
                       trigger_thread, redis_content):
        """
        Connect to redis server
        get the content body and send upwards
        :param redis_conn : key value of the IP:PORT
          and strict redis object
        :param trigger_thread: flag to be set if value is found
        :param ticketid: ticket id to be searched
        :return:
        """
        # for easier logging purpose
        begin = "StrictRedis<ConnectionPool<Connection<host="
        last = ">>>"
        try:
            conn_info = str(conn)
            conn_info = conn_info[len(begin):-len(last)]
            conn_info = conn_info.replace("=", "")
            conn_info = conn_info.replace("port", "")
            # here password is not reeded
            r_info = conn_info.strip().split(",")
        except:
            self.logger.debug("Parsing info %s fails" % conn)

        # key in redis is ticket_X
        ticketkey = "ticket_" + str(ticketid)
        self.logger.debug("Finding [%s] in server [%s:%s] with timeout [%s]s"
                          % (ticketkey, r_info[0], r_info[1],
                             self.cfg["redis_timeout"]))

        try:
            content_body = conn.blpop(ticketkey,
                                      timeout=self.cfg["redis_timeout"]
                                      )
        except Exception as e:
            self.logger.exception("Error finding [%s] in [%s:%s]. Reason [%s]"
                                  % (ticketkey, r_info[0], r_info[1],
                                     e.message))

        if content_body:
            # content_body is (ticket_id,result), we return only result
            redis_content['content-body'] = content_body[1]
            trigger_thread.set()

    def _check_asyncresponse(self, ticketid):

        """
        Spawn threads to find the ticket
        :param ticketid: ticket id to be searched
        :return:
        """

        try:
            result_contentbody = {'content-body': ""}
            trigger_thread = threading.Event()

            for conn in self.redis_conn:

                conn_obj = self.redis_reconnect(conn)
                if not conn_obj:
                    # as this server can't connect. we do not search inside
                    continue

                start_thread = threading.Thread(target=self.check_ticketid,
                                                args=(ticketid, conn_obj,
                                                      trigger_thread,
                                                      result_contentbody))
                start_thread.daemon = True
                start_thread.start()
            trigger_thread.wait(self.cfg["redis_timeout"])
        except:
            self.logger.exception("Pop redis error")

        # self.logger.debug("Redis get content-body of %s", result_contentbody)
        return result_contentbody["content-body"]

    def _append_additionalbody(self, contentmsg, req):

        """
        Update content body on error with
        user defined body
        :param contentmsg: content message to be updated
        :param
        :return:
        """

        if len(USER_ERROR) != 0:
            contentmsg["Result"].update(USER_ERROR)

        if 'x-transactionid' in req:
            contentmsg["Result"]["transactionid"] = req['x-transactionid']

        if 'x-siteid' in req:
            contentmsg["Result"]["siteid"] = req['x-siteid']

        is_jsonmsg = json.dumps(contentmsg)
        return is_jsonmsg

    def _updatetransactionid(self, httpresponse, req):
        """
        Update transaction id and xid inside header
        on error, we send as well these value on body
        :param httpresponse: original response
        :param req: request header
        :param contentmsg: content message to be updated
        :param is_error: whether tid and xid should be added on body
        :return:
        """

        # append request HDR + body info if transactionID is found
        if 'x-transactionid' in req:
            httpresponse["x-transactionid"] = req['x-transactionid']
            # transid body is appended only on error case,
            # because on success, this value is
            # taken directly from ACS

        if 'x-siteid' in req:
            httpresponse["x-siteid"] = req['x-siteid']

    def update_asyncheader(self, httpresponse, contentupdate,
                           request_header, req_id):
        """
        After receiving response from ACS,
        header must be updated with values from redis
        :param header: httpresponse original header
        :param contentupdate: content body from redis
        :return: updated httpresponse
        """

        if contentupdate:
            self.logger.debug("Req [%s] cb value found,\
                              update content" % req_id)
            try:
                contentmsg = contentupdate
            except:
                self.logger.exception("Req [%s] Can not get \
                                      redis content-body" % req_id)
                raise
        else:
            self.logger.debug("Req [%s] No updated cb value found, "
                              "sending back error to client" % req_id)
            # on error, remove existing content-body sent by ACS,
            # and send Errmsg instead
            # check if nms headers are needed, if yes send back to client
            httpresponse["status"] = ERROR_ACS_BADGW
            contentmsg = self._get_contenterror_type(request_header,
                                                     self.req_type,
                                                     TICKET_TIMEOUT_MSG)

        try:
            # check whether x-transactionid needs to be added
            self._updatetransactionid(httpresponse["headers"], request_header)
            content_len = len(str(contentmsg))
            httpresponse["headers"]["content-length"] = str(content_len)
            httpresponse["msg"] = contentmsg
            # convert headers from OrderedDict to list of tupples
            # httpresponse["headers"] = httpresponse["headers"].items()
        except:
            self.logger.exception("Building new http headers fail")
            raise

        return httpresponse

    def check_acsresponse(self, response, request_hdr, request_id):
        """
        Check ACS response to identify whether this is a sync or asnyc
        if async, get the value from redis
        and update the body
        :param response:
        :param request_header: request_header got from client
        :return:
        """
        if 'ticketid' in response and response['ticketid'] is not None:
            self.logger.debug("Req %s ASYNC process" % request_id)
            try:
                result_contentbody = self._check_asyncresponse(
                                            response['ticketid'])
            except:
                result_contentbody = None
            finally:
                response["httpresponse"] = self.update_asyncheader(
                                                response["httpresponse"],
                                                result_contentbody,
                                                request_hdr,
                                                request_id)

                return response
        else:
            self.logger.debug("Req %s SYNC process" % request_id)
            return response

    def _get_contenterror_type(self, req_header, req_type, errormsg):

        if req_type == "REST":
            contentmsg = {"Result": {"message": errormsg}}
            contentmsg = self._append_additionalbody(contentmsg,
                                                     req_header)
            return contentmsg
        else:
            contentmsg = SOAP_HEADER + SOAP_FAULT_HEADER + \
                         errormsg + \
                         SOAP_FAULT_FOOTER + SOAP_FOOTER
            return contentmsg

    def _send_errorrest(self, req_header, errortype):

        contentmsg = self._get_contenterror_type(req_header,
                                                 "REST",
                                                 errortype["msg"])

        error_hdr = {"content-type": "application/json"}

        sent_headers = {"status": errortype["status"]}
        sent_headers["msg"] = contentmsg
        sent_headers["headers"] = error_hdr

        return sent_headers

    def _send_errorsoap(self, errortype):

        error_hdr = {"content-type": "text/xml;charset=UTF-8"}
        # contentmsg = self._append_additionalbody(contentmsg, req_header)

        sent_headers = {"status": errortype["status"]}
        sent_headers["msg"] = self._get_contenterror_type("",
                                                          "SOAP",
                                                          errortype["msg"])
        sent_headers["headers"] = error_hdr

        return sent_headers

    def send_errorheader(self, req_header, errortype):
        """
        When contacting ACS, any occured error within initial communication
        will be handled by sending back header + xid or x-siteid
        This is due to session-id in WebNMS for example
        Any other error occured after a request has been forwarded to ACS,
        will be responded as-is with the header given by ACS
        :param req_header: original request header
        :param errortype type of error to be sent
        :return: error message with stripped request header
        """

        if self.req_type == "SOAP":
                sent_headers = self._send_errorsoap(errortype)
        else:
                sent_headers = self._send_errorrest(req_header, errortype)

        return sent_headers

    def application(self, env, start_response):
        """
        WSGI Application
        :param env: environment variable
        :param start_response: start_response object
        :return:
        """
        acs_return = self._application(env)

        # wanted format for headers are list of tuples
        acs_headers = acs_return.get("headers")
        # ToDo: ignore content-length for now
        acs_headers.pop("content-length", 0)
        start_response(acs_return.get("status"), acs_headers.items())

        return acs_return.get("msg")

    def _application(self, env):
        """
        Receive Incoming data
        Forward the request to ACS
        All HTTP keywords is plainly proxied to ACS
        Response is directly fetched to the caller

        :param env: environment variable of WSGIServer
        :param start_response: handler for response

        :return: HTTP response to client
        """
        req_id = str(uuid.uuid4())

        postbody = self.check_postbody(env)
        httplib_headers = self.decode_request(env)
        self.logger.debug("Req [%s] Processing Type : [%s]"
                          % (req_id, self.req_type))
        try:
            orig_uri = self.log_originalreq(env)
            self.logger2.debug("Req [%s] Original URI is: %s,\
                                POST Body is :%s" % (req_id,
                                                     orig_uri,
                                                     postbody))
        except Exception, e:
            self.logger.exception("Decoding URI fails. Continue")
            self.logger.exception("Raising -> %s" % str(e))
            pass
        self.logger2.debug("Req [%s] Decoded request: %s"
                           % (req_id, httplib_headers))

        # forward query string
        if ("QUERY_STRING" in env) and (env["QUERY_STRING"] != ""):
            http_path = env["PATH_INFO"] + "?" + env["QUERY_STRING"]
        else:
            http_path = env["PATH_INFO"]

        try:
            response = self.contact_acs(
                     env["REQUEST_METHOD"],
                     http_path,
                     httplib_headers,
                     postbody)
        except socket.timeout:
            self.logger.exception("Req [%s] Socket timeout to ACS" % req_id)
            return self.send_errorheader(httplib_headers, GW_TIMEOUT_RESPONSE)
        except:
            self.logger.exception("Req [%s] Exception to ACS" % req_id)
            return self.send_errorheader(httplib_headers, BAD_GW_RESPONSE)

        try:
            response = self.check_acsresponse(response, httplib_headers,
                                              req_id)
            self.logger2.debug("Req [%s] HTTP response: %s",
                               req_id,
                               response["httpresponse"])

            return response["httpresponse"]
        except:
            return self.send_errorheader(httplib_headers, BAD_GW_RESPONSE)

    def stop_wsgiserver(self):
        self.my_wsgi.stop()
        self.logger.debug("Stopping WSGI Server")

    def start_wsgiserver(self):
        """
        Main engine of WSGI server
        """

        self.logger.info("Starting Callback Proxy on [%s:%s]"
                         % (self.cfg["cbaddr"], self.cfg["port"]))

        if self.cfg["ssl_key"] and self.cfg["ssl_crt"]:
            kwargs = {"keyfile": self.cfg["ssl_key"],
                      "certfile": self.cfg["ssl_crt"]}
            self.logger.info("SSL Enabled crt:key [%]" % (
                                                          self.cfg["ssl_crt"],
                                                          self.cfg["ssl_key"]))
        elif self.cfg["ssl_crt"]:
            self.logger.info("SSL Enabled crt [%s]" % (self.cfg["ssl_crt"]))
            kwargs = {"keyfile": self.cfg["ssl_key"]}
        else:
            self.logger.info("SSL Not Enabled")
            kwargs = {}

        try:
                self.my_wsgi = WSGIServer((self.cfg["cbaddr"],
                                          self.cfg["port"]),
                                          self.application,
                                          spawn=self.cfg["pool"],
                                          **kwargs
                                          )
                self.my_wsgi.serve_forever()
        except KeyboardInterrupt:
                self.logger.debug("Sending Ctrl+C")
                self.stop_wsgiserver()
        except:
                self.logger.exception("Can not start CB Proxy")

        self.logger.info("Quitting Callback Proxy")
