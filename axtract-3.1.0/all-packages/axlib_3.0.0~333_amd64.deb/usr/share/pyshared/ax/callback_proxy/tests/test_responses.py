#!/usr/bin/python -tt
import unittest
import ax.callback_proxy.proxy_cb as proxy
import json
import redis

IPLOC = "127.0.0.1"
RED_PORT = "6379"
RED_SERVER = "redis://" + IPLOC + ":" + RED_PORT + "/db1"
BADGW = "502 Bad Gateway"
XID = "x-transactionid"

RSP_SYNC = {
    "httpresponse": {
        "status": "200 OK",
        "headers": ([('content-length', 57), ('x-powered-by', 'Zope'),
                     ('content-type', 'application/json; charset=utf-8')]),
        "msg": {"Result": {
                    "message": "OK",
                    "code": "200",
                    "details": []}
                }
    },
}

HDR = {"accept-encoding": "gzip, deflate", "accept": "*/*",
       "host": IPLOC+":8080", "connection": "keep-alive"}

SERVER_INFO = {
        "port": 808, "pool": 100, "redis_server": RED_SERVER, "acs_port": 99,
        "redis_timeout": 10, "acs_address": IPLOC,
        "acs_timeout": 60, "loglevel": "DEBUG"}

SOAP_HEADER = """<soap:Envelope
        xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
        xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xmlns:xsd="http://www.w3.org/2001/XMLSchema"
        """
SOAP_FAULT_HEADER = """<SOAP-ENV:Body>
        <SOAP-ENV:Fault>
           <faultcode xsi:type="xsd:string">SOAP-ENV:Client</faultcode>
           <faultstring xsi:type="xsd:string">"""
SOAP_FAULT_FOOTER = """
           </faultstring>
       </SOAP-ENV:Fault>
       </SOAP-ENV:Body>"""

SOAP_FOOTER = """
</SOAP-ENV:Envelope>"""


class CallbackProxyTestResponses(unittest.TestCase):

        def test_sendbadgwheader(self):
            my_proxy = proxy.proxyCB(SERVER_INFO, init_redis=False)
            errorgw = "Error connecting ACS"
            badgw = {"status": BADGW, "msg": errorgw}
            ret_error = my_proxy.send_errorheader(HDR, badgw)

            expected = {
                        "status": "502 Bad Gateway",
                        "msg": '{"Result": {'
                               '"message": "Error connecting ACS"}'
                               '}',
                        "headers": {"content-type": "application/json"}
                        }

            self.assertDictEqual(ret_error, expected)

        def test_sendtimeoutheader(self):

            my_proxy = proxy.proxyCB(SERVER_INFO, init_redis=False)
            is_timeout = {"status": "504 Gateway Time-out",
                          "msg": "Timeout connecting ACS"}
            ret_error = my_proxy.send_errorheader(HDR, is_timeout)
            expected = {
                        "status": "504 Gateway Time-out",
                        "msg": '{"Result": {'
                               '"message": "Timeout connecting ACS"}}',
                        "headers": {"content-type": "application/json"}
                        }

            self.assertDictEqual(ret_error, expected)

        def test_appendcontentbody(self):

            my_proxy = proxy.proxyCB(SERVER_INFO, init_redis=False)
            contentmsg = {"Result": {"myresult": "testresult"}}
            req = {XID: 123}
            rsp = my_proxy._append_additionalbody(contentmsg, req)
            rsp_dict = json.loads(rsp)
            wanted_response = {
                                "Result": {
                                    "myresult": "testresult",
                                    "transactionid": 123,
                                }
                              }
            self.assertDictEqual(rsp_dict, wanted_response)

        def test_decoderequest_REST(self):

            env = {
                'PATH_INFO': '/live/CPEManager/AXFirmwareManager/NBI/',
                'SERVER_PROTOCOL': 'HTTP/1.0',
                'CONTENT_LENGTH': '41',
                'HTTP_USER_AGENT': 'UASIP/1.0',
                'SERVER_PORT': '8080',
                'REMOTE_ADDR': IPLOC,
                'HTTP_HOST': IPLOC+":8080",
                'CONTENT_TYPE': 'text',
                'HTTP_ACCEPT_ENCODING': 'gzip, deflate'
            }
            my_proxy = proxy.proxyCB(SERVER_INFO, init_redis=False)
            headers = my_proxy.decode_request(env)
            wanted_headers = {
                "x-forwarded-for": IPLOC,
                "host": IPLOC+":8080", "content-type": "text",
                "accept-encoding": "gzip, deflate",
                "user-agent": "UASIP/1.0"
            }
            self.assertDictEqual(headers, wanted_headers)

        def test_decoderequest_SOAP(self):

            env = {
                'PATH_INFO': '/live/CPEManager/AXFirmwareManager/NBI/',
                'SERVER_PROTOCOL': 'HTTP/1.0',
                'CONTENT_LENGTH': '41',
                'HTTP_USER_AGENT': 'UASIP/1.0',
                'HTTP_SOAPACTION': 'urn:GetParameterValues',
                'SERVER_PORT': '8080',
                'REMOTE_ADDR': IPLOC,
                'HTTP_HOST': IPLOC+":8080",
                'CONTENT_TYPE': 'text',
                'HTTP_ACCEPT_ENCODING': 'gzip, deflate'
            }
            my_proxy = proxy.proxyCB(SERVER_INFO, init_redis=False)
            headers = my_proxy.decode_request(env)
            wanted_headers = {
                "x-forwarded-for": IPLOC,
                "host": IPLOC+":8080", "content-type": "text",
                "soapaction": "urn:GetParameterValues",
                "accept-encoding": "gzip, deflate",
                "user-agent": "UASIP/1.0"
            }
            self.assertDictEqual(headers, wanted_headers)

        def test_snycprocess(self):

            my_proxy = proxy.proxyCB(SERVER_INFO, init_redis=False)
            req_id = "abc"
            ret_error = my_proxy.check_acsresponse(RSP_SYNC,
                                                   HDR,
                                                   req_id
                                                   )
            # loopback check
            self.assertEqual(ret_error, RSP_SYNC)

        def test_updateasynchderror(self):
            contentmsg = {}
            req = {XID: 123}
            my_proxy = proxy.proxyCB(SERVER_INFO, init_redis=False)
            is_headers = {"content-length": 57}
            httpresponse = {"headers": is_headers}
            req_id = "123"
            rsp = my_proxy.update_asyncheader(httpresponse, contentmsg,
                                              req, req_id)

            wanted_response = {
                "status": "502 Bad Gateway",
                "headers": {
                    "content-length": '71',
                    "x-transactionid": 123},
                "msg": '{"Result": {'
                       '"message": "Timeout finding ticket", '
                       '"transactionid": 123}}'
            }
            self.assertDictEqual(rsp, wanted_response)

        def test_updateasyncheader(self):

            contentmsg = {"msg": "testupdate"}
            req = {XID: 123}
            my_proxy = proxy.proxyCB(SERVER_INFO, init_redis=False)
            is_headers = {"content-length": 57, "x-powered-by": 'Zope'}
            httpresponse = {"headers": is_headers}
            req_id = "abc"
            rsp = my_proxy.update_asyncheader(httpresponse, contentmsg,
                                              req, req_id)
            wanted_response = {'msg': {'msg': 'testupdate'},
                               'headers':
                                   {'content-length': '21',
                                    'x-transactionid': 123,
                                    'x-powered-by': 'Zope'
                                    }
                               }
            self.assertDictEqual(rsp, wanted_response)

        def test_getcontenterror_REST(self):

            my_proxy = proxy.proxyCB(SERVER_INFO, init_redis=False)
            is_headers = {"content-length": 57,
                          "x-powered-by": 'Zope',
                          "x-transactionid": 12
                          }
            rsp = my_proxy._get_contenterror_type(is_headers,
                                                  "REST", "TestErr")
            wtd = """{"Result": {"message": "TestErr", "transactionid": 12}}"""
            self.assertEqual(rsp, wtd)

        def test_getcontenterror_SOAP(self):

            my_proxy = proxy.proxyCB(SERVER_INFO, init_redis=False)
            is_headers = {"content-length": 57,
                          "x-powered-by": 'Zope',
                          "x-transactionid": 12
                          }
            err = "TestErr"
            rsp = my_proxy._get_contenterror_type(is_headers,
                                                  "SOAP", err)

            wtd = SOAP_HEADER + SOAP_FAULT_HEADER + err + \
                SOAP_FAULT_FOOTER + SOAP_FOOTER
            self.assertEqual(rsp, wtd)

        def test_senderror_SOAP(self):

            my_proxy = proxy.proxyCB(SERVER_INFO, init_redis=False)

            err_info = "TicketNotFound"
            status = "200OK"
            err_headers = {"status": status,
                           "msg": err_info
                           }
            rsp = my_proxy._send_errorsoap(err_headers)

            soap_rsp = SOAP_HEADER + SOAP_FAULT_HEADER + err_info + \
                SOAP_FAULT_FOOTER + SOAP_FOOTER

            wtd = {
                    "status": status,
                    "msg": soap_rsp
                  }

            self.assertEqual(wtd["msg"], rsp["msg"])
            self.assertEqual(wtd["status"], rsp["status"])

        def test_senderror_REST(self):

            my_proxy = proxy.proxyCB(SERVER_INFO, init_redis=False)

            hdrs = {"content-length": 57,
                    "x-powered-by": 'Zope',
                    "x-transactionid": 12}

            err_type = {"msg": "timeout",
                        "status": "200OK"
                        }

            rsp = my_proxy._send_errorrest(hdrs, err_type)
            wtd_msg = '{"Result": {"message": "timeout", "transactionid": 12}}'
            wtd = {"status": "200OK",
                   'msg': wtd_msg,
                   "headers": {"content-type": "application/json"}}
            self.assertDictEqual(rsp, wtd)


class CallbackProxyTestConfigParsing(unittest.TestCase):

        def test_uriparsing(self):

            my_proxy = proxy.proxyCB(SERVER_INFO, init_redis=False)
            path = "/live/CPEManager/DMInterfaces/IFmethod/rest/v1/act"
            server_port = "4011"
            request = "https://" + IPLOC + ":" + server_port + path

            env = {}
            env['wsgi.url_scheme'] = "https"
            env['HTTP_HOST'] = IPLOC + ":" + server_port
            env['SCRIPT_NAME'] = ""
            env['PATH_INFO'] = path

            # http host must overwrite the serv name:port
            env['SERVER_NAME'] = "c5830d5796b8"
            env['SERVER_PORT'] = server_port

            decoded_rsp = my_proxy.log_originalreq(env)
            self.assertEqual(request, decoded_rsp)

        def test_redisconfigparsing(self):

            my_proxy = proxy.proxyCB(SERVER_INFO, init_redis=False)

            # <ip:port/db1>
            cfg = SERVER_INFO["redis_server"]
            parsed_redis = my_proxy._parse_rediscfg(cfg)
            initial_config = [IPLOC + ":" + RED_PORT + "/db1"]
            self.assertEqual(initial_config, parsed_redis)

            # <ip:port>
            cfg = "redis://192.168.0.3:1236"
            parsed_redis = my_proxy._parse_rediscfg(cfg)
            first_config = ["192.168.0.3:1236"]
            self.assertEqual(first_config, parsed_redis)

            # <password@ip:port/db1>
            cfg = "redis://mypass@192.168.0.1:1234/db2"
            parsed_redis = my_proxy._parse_rediscfg(cfg)
            second_config = ["mypass@192.168.0.1:1234/db2"]
            self.assertEqual(second_config, parsed_redis)

            # <password@ip:port>
            cfg = "redis://mypass@192.168.0.2:1235"
            parsed_redis = my_proxy._parse_rediscfg(cfg)
            third_config = ["mypass@192.168.0.2:1235"]
            self.assertEqual(third_config, parsed_redis)

        def test_eachredisparsing(self):

            my_proxy = proxy.proxyCB(SERVER_INFO, init_redis=False)
            redis_srv = "mypass@192.168.0.2:1235"
            result = my_proxy._parse_eachredis(redis_srv)
            expected = "192.168.0.2,1235,mypass,db0"
            self.assertEqual(result, expected)

            my_proxy = proxy.proxyCB(SERVER_INFO, init_redis=False)
            redis_srv = "mypass@192.168.0.2:1235/db1"
            result = my_proxy._parse_eachredis(redis_srv)
            expected = "192.168.0.2,1235,mypass,db1"
            self.assertEqual(result, expected)

            my_proxy = proxy.proxyCB(SERVER_INFO, init_redis=False)
            redis_srv = "192.168.0.2:1235/db1"
            result = my_proxy._parse_eachredis(redis_srv)
            expected = "192.168.0.2,1235,,db1"
            self.assertEqual(result, expected)


class CallbackProxyTestResponsesRedis(unittest.TestCase):

        def test_parseredisinfo(self):

            my_proxy = proxy.proxyCB(SERVER_INFO, init_redis=False)
            redis_ip = IPLOC + ",6379" + ",hello,db0"
            rsp = my_proxy._retrieve_redisinfo(redis_ip)
            wanted_response = {
                                "ip": IPLOC,
                                "port": "6379",
                                "pasw": "hello",
                                "db": "0"
                               }
            self.assertDictEqual(rsp, wanted_response)

        def test_initializeredis(self):

            my_proxy = proxy.proxyCB(SERVER_INFO, init_redis=False)
            rsp = my_proxy.initialize_redis()
            if '127.0.0.1,6379,,db1' in rsp:
                assert True
            else:
                assert False

        def test_initializemultipleredis(self):

            config = {}
            config["redis_timeout"] = 1
            config["redis_server"] = "redis://127.0.0.1:6379/db1,\
                                      redis://172.0.0.4:8888/db2,\
                                      redis://127.0.0.1:8989/db3"

            my_proxy = proxy.proxyCB(config, init_redis=False)
            rsp = my_proxy.initialize_redis()
            if all(k in rsp for k in("127.0.0.1,8989,,db3",
                                     "172.0.0.4,8888,,db2",
                                     "127.0.0.1,6379,,db1")):
                assert True
            else:
                assert False

        def test_connectredis(self):

            my_proxy = proxy.proxyCB(SERVER_INFO, init_redis=False)

            redis_ip = IPLOC + ",6371,,db1"
            try:
                my_proxy.redis_connect(redis_ip, 1)
            except redis.exceptions.ConnectionError:
                assert True
            except:
                assert False

        def test_reconnectredis(self):

            my_proxy = proxy.proxyCB(SERVER_INFO, init_redis=False)

            redis_ip = IPLOC + ",6371,,db1"
            try:
                my_proxy.redis_reconnect(redis_ip)
            except redis.exceptions.ConnectionError:
                assert True
            except:
                raise
                assert False

        def test_reconnectredisinit(self):

            config = {}
            config["redis_server"] = "redis://127.0.0.1:6371/db1,\
                                      redis://127.0.0.2:1234/db2"
            config["redis_timeout"] = 1
            my_proxy = proxy.proxyCB(config, init_redis=True)

            redis_ip = IPLOC + ",6371,,db1"
            try:
                my_proxy.redis_reconnect(redis_ip)
            except redis.exceptions.ConnectionError:
                assert True
            except:
                raise
                assert False
