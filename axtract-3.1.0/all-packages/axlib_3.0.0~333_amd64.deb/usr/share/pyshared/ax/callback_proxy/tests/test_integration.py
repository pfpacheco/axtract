#!/usr/bin/python -tt
import unittest
import server_layer
import subprocess
import httplib
import urllib

OK = 200
KO = 502
INIT_CB = "/etc/init.d/ax_callback_proxy"

CONNECT_PROXY = httplib.HTTPConnection('127.0.0.1:8080')
CPE_JSON = {
    "CPEIdentifier": {"cpeid": "axiros_35"},
    "CommandOptions": {},
    "Parameters": ["I.MS."]
}
CPE_JSON_RESPONSE = {
    "message": "OK",
    "key": "InternetGatewayDevice.ManagementServer.PeriodicInformEnable"
}


class CallbackProxyTestDaemon(unittest.TestCase):

    def test_cbdaemoninit(self):

        stream = open("/etc/default/ax_callback_proxy", 'w')

        stream.write("SERVICE_ENABLED=true\n")
        stream.write('EXTRA_ARGS="$EXTRA_ARGS \
                     --port=8080 --pool=10 \
                     --redis=redis://127.0.0.1:6379 \
                     --redistimeout=10 --acsport=9676 \
                     --acsaddress=127.0.0.1 --acstimeout=10 \
                     --sslcrt= --sslkey="')
        stream.close()

        return_code = subprocess.call([INIT_CB, "start"])
        self.assertEqual(return_code, 0)

        return_code = subprocess.call([INIT_CB, "status"])
        self.assertEqual(return_code, 0)

        return_code = subprocess.call([INIT_CB, "stop"])
        self.assertEqual(return_code, 0)


class CallbackProxyTestIntegration(unittest.TestCase):

        layer = server_layer.RunningDBLayer

        stream = open("/etc/default/ax_callback_proxy", 'w')

        stream.write("SERVICE_ENABLED=true\n")
        stream.write('EXTRA_ARGS="$EXTRA_ARGS \
                     --port=8080 --pool=10 \
                     --redis=redis://127.0.0.1:6379 \
                     --redistimeout=10 --acsport=9676 \
                     --acsaddress=127.0.0.1 --acstimeout=10"')
        stream.close()

        subprocess.call([INIT_CB, "restart"])

        def test_boot_proxy(self):
            conn = CONNECT_PROXY
            conn.request("GET", "/helloproxy")
            r1 = conn.getresponse()
            conn.close()

            self.assertEqual(r1.status, OK)

        def test_error_proxy(self):
            conn = CONNECT_PROXY
            conn.request("GET", "/randomurl")
            r1 = conn.getresponse()
            conn.close()
            self.assertEqual(r1.status, KO)

        def test_simple_post(self):
            params = urllib.urlencode(CPE_JSON)
            headers = {"Content-type": "application/x-www-form-urlencoded"}
            conn = CONNECT_PROXY
            conn.request("POST", "/live", params, headers)
            r1 = conn.getresponse()
            conn.close()
            self.assertEqual(r1.status, OK)

        def test_simple_rest(self):
            params = urllib.urlencode(CPE_JSON)
            headers = {"Content-type": "application/x-www-form-urlencoded"}
            conn = CONNECT_PROXY
            conn.request("POST", "/simplerest", params, headers)
            r1 = conn.getresponse()
            net_jsonresp = r1.read()
            json_rsp = str(CPE_JSON_RESPONSE)
            conn.close()
            self.assertEqual(net_jsonresp, json_rsp)


if __name__ == "__main__":

    unittest.main(verbosity=2)
