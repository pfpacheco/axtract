#!/usr/bin/env python

"""
User defined dict-body
On error, customized body can be sent,
only if the following lines are added
Otherwise, default error (502) with empty body will be sent.

All value that is added under will be sent as is
Use with caution!
"""

USER_ERROR = {}
