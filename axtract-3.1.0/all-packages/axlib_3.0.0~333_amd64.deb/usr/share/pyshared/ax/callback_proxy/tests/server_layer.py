#!/usr/bin/python -tt
from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
import threading

DUMMY_ACS_PORT = 9676
LOCALHOST = "127.0.0.1"
MY_TIMEOUT = 30
OK = 200
KO = 502

CPE_JSON = {
    "CPEIdentifier": {"cpeid": "axiros_35"},
    "CommandOptions": {},
    "Parameters": ["I.MS."]
}
CPE_JSON_RESPONSE = {
    "message": "OK",
    "key": "InternetGatewayDevice.ManagementServer.PeriodicInformEnable"
}


class JSONHandler(BaseHTTPRequestHandler):

    def do_POST(self):
        if self.path == "/live":
            self.set_basic_headers(OK)
        elif self.path == "/simplerest":
            self.set_basic_headers(OK)
            self.set_json_response()
        else:
            self.set_basic_headers(KO)

    def do_GET(self):
        if self.path == "/helloproxy":
            self.set_basic_headers(OK)
        else:
            self.set_basic_headers(KO)

    def set_basic_headers(self, code):
        self.send_response(code)
        self.send_header('Content-type', 'text/html')
        self.end_headers()

    def set_json_response(self):
        self.wfile.write(CPE_JSON_RESPONSE)


class RunningDBLayer(object):
    @classmethod
    def setUp(cls):
        cls.t1 = 0

        try:
            cls.server = HTTPServer(("127.0.0.1", DUMMY_ACS_PORT),
                                    JSONHandler)
            cls.thread_acs = threading.Thread(
                target=cls.server.serve_forever)
            cls.thread_acs.daemon = True
            cls.thread_acs.start()
        except:
            raise

        # Proxy listens to port 4812

    @classmethod
    def tearDown(cls):

        cls.server.shutdown()
        cls.thread_acs.join()
