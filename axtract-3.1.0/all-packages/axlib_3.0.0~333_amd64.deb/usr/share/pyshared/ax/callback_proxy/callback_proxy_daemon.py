#!/usr/bin/env python
from ax.daemon.daemon import AxDaemon
import ax.callback_proxy.proxy_cb as callback_proxy
import gevent.monkey
gevent.monkey.patch_all()


class CallbackProxyDaemon(AxDaemon):
    def __init__(self):
        super(CallbackProxyDaemon, self).__init__()

        self.ta_start = False
        self.redirect_print = False
        self.daemon_name = 'ax_callbackproxy_wrapper'

        self.log_file = '/var/log/ax_callback_proxy/server.log'
        # if user wants a different log location,
        # copy the files on the following location
        self.log_location = '/opt/logging_callback.json'
        self.log_level = 'DEBUG'

        self.proxyCB = None

    def define_command_line(self):
        super(CallbackProxyDaemon, self).define_command_line()

        self.option_parser.remove_option('--log-level')
        log_help = """Callback log level in ascending order:"
                    DEBUG, INFO, WARNING, ERROR and CRITICAL"
                    The log is available in the server.log file"
                    Default: DEBUG"""
        self.option_parser.add_option(
            "--log",
            dest="log_level",
            default="DEBUG",
            help=log_help
        )

        self.option_parser.add_option(
            "--cbaddr",
            dest="cbaddr",
            default="127.0.0.1",
            help="Callback engine default address: 127.0.0.1"
        )

        self.option_parser.add_option(
            "--port",
            dest="cbport",
            default=8080,
            type=int,
            help="Callback engine default port: 8080"
        )

        self.option_parser.add_option(
            "--pool",
            dest="cbpool",
            default=1000,
            type=int,
            help="Maximum number of spawned connections."
                 "Default: 1000"
        )

        self.option_parser.add_option(
            "--acsaddress",
            dest="acsaddress",
            default="127.0.0.1",
            help="Location of ACS. Default: 127.0.0.1"
        )

        self.option_parser.add_option(
            "--acsport",
            dest="acsport",
            type=int,
            default=9676,
            help="Listening Port of ACS. Default: 9676"
        )

        self.option_parser.add_option(
            "--acstimeout",
            dest="acstimeout",
            default=60,
            type=int,
            help="Timeout in (s) when callback server "
                 "tries to connect ACS. Default: 60 s"
        )

        self.option_parser.add_option(
            "--redis",
            dest="redisserver",
            default="127.0.0.1:6379:",
            help="Redis servers to connect to."
                 "If more servers are needed, "
                 "then specifiy this as IP:PORT:PASSWORD"
                 "e.g. IP1:PORT1:PASS1,IP2:PORT2:PASS2,IP3:PORT3:PASS3"
            )

        self.option_parser.add_option(
            "--redistimeout",
            dest="redistimeout",
            default=30,
            type=int,
            help="""Timeout in (s) when callback server
                  tries to find a value in redis server.
                  Default: 30 s"""
            )

        self.option_parser.add_option(
            "--sslcrt",
            dest="sslcrt",
            default="",
            help="""Path of SSL Certificate"""
            )

        self.option_parser.add_option(
            "--sslkey",
            dest="sslkey",
            default="",
            help="""Path of SSL key"""
            )

    def handle_termination_signal(self, unused1, unused2):
        super(CallbackProxyDaemon, self).\
              handle_termination_signal(unused1, unused2)
        self.logger.warn("CBProxy Daemon triggering shutdown...")
        if self.proxyCB:
            self.proxyCB.stop_wsgiserver()

    def run(self):

        server_info = {
            "cbaddr": self.options.cbaddr,
            "port": self.options.cbport,
            "pool": self.options.cbpool,
            "redis_server": self.options.redisserver,
            "redis_timeout": self.options.redistimeout,
            "acs_address": self.options.acsaddress,
            "acs_port": self.options.acsport,
            "acs_timeout":  self.options.acstimeout,
            "ssl_crt": self.options.sslcrt,
            "ssl_key": self.options.sslkey,
        }

        try:
            self.proxyCB = callback_proxy.proxyCB(server_info, self.logger)
            self.proxyCB.start_wsgiserver()
        except:
            self.logger.exception("Can not start server")


if __name__ == "__main__":
    daemon = CallbackProxyDaemon()
    daemon.setup()
    daemon.run()
    daemon.cleanup()
