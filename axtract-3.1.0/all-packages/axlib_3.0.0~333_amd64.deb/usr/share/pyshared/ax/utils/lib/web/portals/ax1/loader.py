"""
LOADER of python logic  of ax1 portal into the AXESS app server
(called from AXWorkflow)


The decision point which python funcs to call (and reload)

this one was made for into zope loading - the logic is simple enough to do for
other app servers as well.


Note: Meanwhile added out of zope loading, same loader could be used (AXPAND)
"""

# just to print it:
import thread, re
#from ax.transport.model.servers.http.http_lib import Redirect
# we store imported modules here - to be able to reload them:
MOD_CACHE = {}


RELOAD_KEY = 'reload'

def do_load(r, s, uri, ctx, app=None, **kw):
    # ref to the application - here the AXWorkflowScript.

    app_name = ctx['app_name']
    if 'debug' in kw:
        print 'context is', ctx
        print 'thread is', thread.get_ident()
        print 'module cache', MOD_CACHE.keys()

        print 'loading ', r.URL
        # analyse the path:
        print 'uri is ', uri

    sections = ctx.get('sections', [])

    loaded = MOD_CACHE.get(app_name, '')
    if loaded == '':
        MOD_CACHE[app_name] = {}
    if len(loaded) < len(sections):
        load(app_name, ['main'], ctx)
        load(app_name, sections, ctx)

    ctx['MODULES'] = MOD_CACHE[app_name]
    subsect1 = ''
    if not uri:
        # deliver the main page:
        uri = ['main']
        section = 'main'
    else:
        section = uri[0]
        if not '_' in section:
            section += '_'
        section, subsect1 = section.split('_', 1)
        # may he?
        may = 0
        allw = ctx.get('allowed', 0)
        if allw:
            if re.search(allw, uri[0]):
                may = 1
        else:
            if section in sections:
                may = 1
            if subsect1:
                if subsect1 in ctx.get('section_%s_sub1' % section, []):
                    may = 1
        if not may:
            raise LookupError('%s not found' % uri[0])

    modobj = MOD_CACHE[app_name][section]
    if modobj:
        if RELOAD_KEY in kw:
            reload(modobj)

    # run:
    func = subsect1 or section
    res = {'status': 200}
    res['data'] = getattr(modobj, 'render_%s' % func)(r, s, ctx, uri, app)
    # can be used later:
    res['headers'] = None
    return res


def load(app_name, sections, ctx):
    for section in sections:
        # like: ctx['section_logging_from'] = 'AXPAND.portal'
        sfrom = ctx.get('section_%s_from' % section, 0)
        if sfrom:
            # custom section:
            s = 'from %s.%s import render as _tmp' % (sfrom, section)
        else:
            # default section of the ax1 portal framework:
            s = 'from ax1.sections.%s import render as _tmp' % section
        exec "%s;MOD_CACHE['%s']['%s'] = _tmp" % (s, app_name, section)


def axess_load(app, **kw):
    """ load from AXESS. app is the AXWorkflow script """
    ctx = kw['kw']
    # ref to the application - here the AXWorkflowScript.
    r   = app.REQUEST
    s   = r.SESSION
    uri = r.traverse_subpath
    return do_load(r, s, uri, ctx, app, **kw)


# execed from the loader of us:
try:
    # res is set from the exec in the app (AXWorkflow):
    locals()['_ax_funcobj'] = axess_load
except:
    pass
