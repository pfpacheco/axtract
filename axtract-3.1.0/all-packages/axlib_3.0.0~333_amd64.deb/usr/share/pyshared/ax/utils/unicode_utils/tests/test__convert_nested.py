import json
import unittest
import copy
import time
import collections

from ax.utils.unicode_utils import encode_nested
from .sample_objects import big_doc


class TestConvertNested(unittest.TestCase):
    def test_equal(self):
        new_ob = encode_nested(copy.deepcopy(big_doc))
        self.assertEqual(new_ob, big_doc)

    def test_encode_happens(self):
        ob = copy.deepcopy(big_doc)
        ob['foo'] = {u'a': [{'b': [(1, 2, [u'\xd6sterreich'])]}]}

        ob = encode_nested(ob)

        self.assertTrue(isinstance(ob['foo'].keys()[0], str))
        self.assertFalse(isinstance(ob['foo'].keys()[0], unicode))

        self.assertTrue(isinstance(ob['foo']['a'][0]['b'][0][2][0], str))
        self.assertFalse(isinstance(ob['foo']['a'][0]['b'][0][2][0], unicode))

        ref = {'a': [{'b': [(1, 2, ['\xc3\x96sterreich'])]}]}
        self.assertEqual(ob['foo'], ref)

    def test_long_int(self):
        self.assertEqual(2**66, encode_nested(2**66))

    def test_pymongo_int64(self):
        class Int64(long):
            pass

        ob = Int64(2**66)
        ret = encode_nested(ob)
        self.assertTrue(ob is ret)

    def test_ordered_dict(self):
        ob = collections.OrderedDict()
        ob[1] = 'a'
        ob[2] = 'b'
        ob[3] = 'c'
        ob[10000] = 'd'
        ob[20000] = 'e'

        new_ob = encode_nested(ob)

        self.assertIsInstance(new_ob, collections.OrderedDict)
        self.assertEqual([1, 2, 3, 10000, 20000],  new_ob.keys())

    def test_perf(self):
        return
        print
        nb = 100000

        start = time.time()
        for _ in xrange(nb):
            encode_nested(big_doc)
        print 'big object with %s bytes json: ' % len(json.dumps(big_doc)),
        print int(nb / (time.time() - start)), ' OPS/s'

        start = time.time()
        for _ in xrange(nb):
            encode_nested(big_doc['props'])
        print 'small object with %s bytes json: ' % len(json.dumps(big_doc['props'])),
        print int(nb / (time.time() - start)), ' OPS/s'
