#!/usr/bin/python -tt

import time
import unittest

from ax.utils.dynamic_objects import objectpool as op

class SimpleClass(object):
    """A class that is very simple to instantiate"""
    pass

class ComplexClass(object):
    """A class the is very picky about correct parameters for __init__"""
    def __init__(self, argument1, argument2, keyword1=None, keyword2=None, **kwargs):
        #print "TestClass instantiated with:"
        #print "argument1=%s argument2=%s" % (argument1, argument2)
        #print "keyword1=%s keyword2=%s" % (keyword1, keyword2)
        if argument1 != "arg1value": raise ValueError("argument1")
        if argument2 != "arg2value": raise ValueError("argument2")
        if keyword1 != "kwarg1value": raise ValueError("keyword1")
        if keyword2 != "kwarg2value": raise ValueError("keyword2")
        if kwargs: raise ValueError("extra kwargs were given")

class ObjectPoolTests(unittest.TestCase):
    """Test cases for basic ObjectPool functionality"""
    def setUp(self):
        self.pool_class = op.ObjectPool

    def test_parameter_passing_to_class(self):
        """Check if obj_args and obj_kwargs are properly passed to the class

        Check with SimpleClass and ComplexClass.
        """
        pool = self.pool_class(obj_class=SimpleClass)
        obj = pool.get_object()
        del(obj)

        pool = self.pool_class(
                obj_class=ComplexClass,
                obj_args=["arg1value", "arg2value"],
                obj_kwargs={'keyword1': "kwarg1value",
                    'keyword2': "kwarg2value"})
        obj = pool.get_object()
        del(obj)

    def test_no_threadsafe(self):
        """not-threadsafe pools get a different tokenbucket"""
        pool = self.pool_class(obj_class=SimpleClass,
                threadsafe=False)
        obj = pool.get_object()
        del(obj)

        pool = self.pool_class(
                threadsafe=False,
                obj_class=ComplexClass,
                obj_args=["arg1value", "arg2value"],
                obj_kwargs={'keyword1': "kwarg1value",
                    'keyword2': "kwarg2value"})
        obj = pool.get_object()
        del(obj)

class BoundedObjectPoolTests(ObjectPoolTests):
    """Test cases for the BoundedObjectPoolTests

    Inherits the basic tests from ObjectPoolTests class. More tests are
    performed as part of testing the factory.
    """
    def setUp(self):
        self.pool_class = op.BoundedObjectPool

class PoolFactoryTests(unittest.TestCase):
    """Tests for the object_pool_factory function"""
    def test_defaults(self):
        pass
        #TODO: ensure the default values are reasonable

    def test_poolsize(self):
        """ testing poolsize """
        pool = op.object_pool_factory(obj_class=SimpleClass,
                poolsize=None)
        self.assert_(isinstance(pool, op.ObjectPool))
        pool = op.object_pool_factory(obj_class=SimpleClass,
                poolsize=42)
        self.assert_(isinstance(pool, op.BoundedObjectPool))

    def test_obj_kwargs(self):
        """obj_args/obj_kwargs must be passed on correctly"""
        pool = op.object_pool_factory(obj_class=ComplexClass,
                obj_args=["arg1value", "arg2value"],
                obj_kwargs={'keyword1': "kwarg1value",
                    'keyword2': "kwarg2value"})
        pool.get_object()

    def test_create_rate(self):
        """obj_create_rate must limit object creation, not giveout"""
        taken = []

        start = time.time()
        pool = op.object_pool_factory(obj_class=SimpleClass,
                obj_create_rate=5)
        # Tokenbucket gets prefilled with 1 token by default, compensate by
        # taking an extra item.
        for count in range(5 + 1):
            taken.append(pool.get_object())
        stop = time.time()
        for obj in taken:
            pool.put_object(obj)
        del(taken)

        # This should have taken > 1 second
        self.assert_(stop - start > 1.0)
        self.assert_(stop -start < 1.1)

        # Now, 6 object are already created. Taking 6 objects should therefore
        # take ~0 seconds
        start = time.time()
        for count in range(5 + 1):
            pool.get_object()
        stop = time.time()
        self.assert_(stop - start < 0.1)

    def test_giveout_rate(self):
        """obj_giveout_rate must limit object giveout"""
        for give_policy in ['lifo', 'fifo']:
            taken = []

            start = time.time()
            pool = op.object_pool_factory(obj_class=SimpleClass,
                    obj_create_rate=5, obj_giveout_policy=give_policy)
            # Tokenbucket gets prefilled with 1 token by default, compensate by
            # taking an extra item.
            for count in range(5 + 1):
                taken.append(pool.get_object())
            stop = time.time()
            for obj in taken:
                pool.put_object(obj)
            del(taken)

            # This should have taken > 1 second
            self.assert_(stop - start > 1.0)
            self.assert_(stop - start < 1.1)

            # Now, 6 object are already created. Giveout must be unlimited.
            start = time.time()
            for count in range(5 + 1):
                pool.get_object()
            stop = time.time()
            self.assert_(stop - start < 0.1)

    def test_giveout_rate_create_rate(self):
        """combine obj_create_rate with obj_giveout_rate"""
        taken = []

        start = time.time()
        pool = op.object_pool_factory(obj_class=SimpleClass,
                obj_create_burst=1, obj_create_rate=5,
                obj_giveout_burst=1, obj_giveout_rate=10)
        # Tokenbucket gets prefilled with 1 token by default, compensate by
        # taking an extra item.
        for count in range(5 + 1):
            taken.append(pool.get_object())
        stop = time.time()
        for obj in taken:
            pool.put_object(obj)
        del(taken)

        # This should have taken > 1 second
        self.assert_(stop - start > 1.0)
        self.assert_(stop -start < 1.1)

        # Now, 6 object are already created and obj_create_rate will be
        # irrelevant for the following code. Two extreme scenarios:
        #   giveout bucket has 1 token, 0.999 leftovers
        #   giveout bucket has 0 tokens, 0 leftovers
        # So the following should take anywhere from 0.4 to 0.6 seconds.
        start = time.time()
        for count in range(5 + 1):
            pool.get_object()
        stop = time.time()
        self.assert_(stop - start > 0.4)
        self.assert_(stop - start < 0.7)


    def test_obj_giveout_policy(self):
        fifo_pool = op.object_pool_factory(obj_class=SimpleClass,
                obj_giveout_policy = 'fifo')
        lifo_pool = op.object_pool_factory(obj_class=SimpleClass,
                obj_giveout_policy = 'lifo')
        for s in xrange(10):
            lifo_pool.put_object(str(s))
            fifo_pool.put_object(str(s))
        s_fifo = fifo_pool.get_object()
        s_lifo = lifo_pool.get_object()
        assert s_fifo == '0'
        assert s_lifo == '9'

class BoundedStatsObjectPoolTests(BoundedObjectPoolTests):
    """Test cases for the BoundedStatsObjectPool
    """
    def test_counting(self):
        """Check if counting works"""
        pool = op.object_pool_factory(obj_class=SimpleClass,
                poolsize=2,
                threadsafe=False,
                with_stats=True)
        self.assertEquals(pool.create_count, 0)
        self.assertEquals(pool.given_out_count, 0)

        obj = pool.get_object()

        self.assertEquals(pool.create_count, 1)
        self.assertEquals(pool.given_out_count, 1)

        pool.put_object(obj)

        self.assertEquals(pool.create_count, 1)
        self.assertEquals(pool.given_out_count, 0)

    def test_threadsafe(self):
        """Check creation of threadsafe pool

        This is a bit more complicated, since the statistics code needs to
        be protected.
        """
        pool = op.object_pool_factory(obj_class=SimpleClass,
                poolsize=2,
                threadsafe=True,
                with_stats=True)
        self.assertEquals(pool.create_count, 0)
        self.assertEquals(pool.given_out_count, 0)

        obj = pool.get_object()

        self.assertEquals(pool.create_count, 1)
        self.assertEquals(pool.given_out_count, 1)

        pool.put_object(obj)

        self.assertEquals(pool.create_count, 1)
        self.assertEquals(pool.given_out_count, 0)



if __name__ == "__main__":
    unittest.main()

