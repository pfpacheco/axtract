import unittest2
import time
import os
import sqlalchemy
from sqlalchemy import create_engine
import simplejson as json

from ax.utils.listables import listable
from ax.utils.grouping import Grouping
from schema import GroupTestSchema
"""
Test data:

    enterprise1
        |
        +-- operator1
                |
                +-- user1
                |     |
                |     +-- Z1
                |     |
                |     +-- Z4
                |         |
                +-- user2 +
                      |
                      + --Z3
"""

# MySQL engine
DB_NAME = os.getenv('DB_NAME', 'test')
DB_USER = os.getenv('DB_USER','ax')
DB_PWD = os.getenv('DB_PWD', 'ax')
DB_HOST = os.getenv('DB_HOST', '127.0.0.1')
DB_PORT = os.getenv('DB_PORT', 3306)
url = 'mysql://%s:%s@%s:%s/%s' %  (
        DB_USER,
        DB_PWD,
        DB_HOST,
        DB_PORT,
        DB_NAME)
engine = create_engine(url, echo=False)


def build_query(query_map):
    query_params = query_map.get('filter_params', [])
    sql_query = ' '.join(query_map['full_query'])
    sql_query = sql_query.replace("?", "%s")

    return sql_query % tuple(query_params)


def prepare_data():
    # Add CPEs
    engine.execute("INSERT INTO CPEManager_CPEs("
                   "cid, cid2, cpeid, cpetype, path, version, IP, "
                   "unmanagedProps, pendingProps, props, scProps, "
                   "events, methods, comments, roles) "
                   "VALUES('', 'operator1', 'ZZ0000000001', 'genericTR69', '',"
                   "'version1__HardwareVersion1__1.011', '10.0.0.135', '[]',"
                   "'{}','{}','{}','[]','','','unsupportedFW')")
    engine.execute("INSERT INTO CPEManager_CPEs("
                   "cid, cid2, cpeid, cpetype, path, version, IP, "
                   "unmanagedProps, pendingProps, props, scProps, "
                   "events, methods, comments, roles) "
                   "VALUES('', '', 'ZZ0000000002', 'genericTR69', '',"
                   "'version2__HardwareVersion2__2.022', '10.0.0.137', '[]',"
                   "'{}','{}','{}','[]','','','unsupportedFW')")
    engine.execute("INSERT INTO CPEManager_CPEs("
                   "cid, cid2, cpeid, cpetype, path, version, IP, "
                   "unmanagedProps, pendingProps, props, scProps, "
                   "events, methods, comments, roles) "
                   "VALUES('', 'operator1', 'ZZ0000000003', 'genericTR69', '',"
                   "'version1__HardwareVersion1__1.011', '10.0.0.136', '[]',"
                   "'{}','{}','{}','[]','','','unsupportedFW')")
    engine.execute("INSERT INTO CPEManager_CPEs("
                   "cid, cid2, cpeid, cpetype, path, version, IP, "
                   "unmanagedProps, pendingProps, props, scProps, "
                   "events, methods, comments, roles) "
                   "VALUES('', 'operator1', 'ZZ0000000004', 'genericTR69', '',"
                   "'version1__HardwareVersion1__1.011', '10.0.0.138', '[]',"
                   "'{}','{}','{}','[]','','','unsupportedFW')")

    # Add enterprise
    engine.execute("INSERT INTO vss_ENTERPRISE("
                   "servicetype, comments, props, account_name, account_role, "
                   "account_parent) "
                   "VALUES('ENTERPRISE', '', '{}', 'enterprise1', "
                   "'enterprise', '')")

    # Add operators
    engine.execute("INSERT INTO vss_OPERATOR("
                   "servicetype, comments, props, account_name, account_role, "
                   "account_parent) "
                   "VALUES('OPERATOR', '', '{}', 'operator1', "
                   "'operator', 'enterprise1')")

    # Add users
    engine.execute("INSERT INTO vss_USER("
                   "servicetype, comments, props, account_name, account_role, "
                   "account_parent) "
                   "VALUES('USER', '', '{}', 'user1', "
                   "'user', 'operator1')")
    engine.execute("INSERT INTO vss_USER("
                   "servicetype, comments, props, account_name, account_role, "
                   "account_parent) "
                   "VALUES('USER', '', '{}', 'user2', "
                   "'user', 'operator1')")

    # Add user-cpe relations
    engine.execute("INSERT INTO vss_USER_CPE_RELATION("
                   "servicetype, comments, props, cpeid, sip_url, userid) "
                   "VALUES('USER_CPE_RELATION', '', '{}', 'ZZ0000000001', "
                   "'sip:user1@ZZ0000000001', 'user1')")
    engine.execute("INSERT INTO vss_USER_CPE_RELATION("
                   "servicetype, comments, props, cpeid, sip_url, userid) "
                   "VALUES('USER_CPE_RELATION', '', '{}', 'ZZ0000000004', "
                   "'sip:user1@ZZ0000000004', 'user1')")
    engine.execute("INSERT INTO vss_USER_CPE_RELATION("
                   "servicetype, comments, props, cpeid, sip_url, userid) "
                   "VALUES('USER_CPE_RELATION', '', '{}', 'ZZ0000000003', "
                   "'sip:user2@ZZ0000000003', 'user2')")
    engine.execute("INSERT INTO vss_USER_CPE_RELATION("
                   "servicetype, comments, props, cpeid, sip_url, userid) "
                   "VALUES('USER_CPE_RELATION', '', '{}', 'ZZ0000000004', "
                   "'sip:user2@ZZ0000000004', 'user2')")


def cleanup_data():
    # Delete CPEs
    engine.execute("DELETE FROM CPEManager_CPEs WHERE cpeid IN "
                   "('ZZ0000000001', "
                   "'ZZ0000000002', "
                   "'ZZ0000000003', "
                   "'ZZ0000000004')")

    # Delete enterprise
    engine.execute("DELETE FROM vss_ENTERPRISE WHERE account_name IN "
                   "('enterprise1')")

    # Delete operator
    engine.execute("DELETE FROM vss_OPERATOR WHERE account_name IN "
                   "('operator1')")

    # Delete user
    engine.execute("DELETE FROM vss_USER WHERE account_name IN "
                   "('user1', 'user2')")

   # Delete user-cpe relation
    engine.execute("DELETE FROM vss_USER_CPE_RELATION WHERE cpeid IN "
                   "('ZZ0000000001', "
                   "'ZZ0000000002', "
                   "'ZZ0000000003', "
                   "'ZZ0000000004')")

    # Delete AXGroup stuff
    engine.execute("DELETE FROM AXGroup")
    engine.execute("DELETE FROM AXGroupStaticRelation")
    engine.execute("DELETE FROM AXGroupSuperRelation")
    engine.execute("DELETE FROM AXGroupConsumedMembers")

class TestAXGroupingDynamic(unittest2.TestCase):
    def setUp(self):
        prepare_data()
        self.grouping = Grouping(GroupTestSchema, engine)

    def tearDown(self):
        cleanup_data()

    def test_create_group_exceptions(self):
        group_test1_id = 0
        with self.assertRaises(ValueError) as context:
            group_test1_id = self.grouping.create_group(
                'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
                ['=', 'operator1'])
        self.assertTrue("Cannot create group %d:"
                        " Cannot set filters: string index out of range" %
                        group_test1_id, str(context.exception))

        with self.assertRaises(ValueError) as context:
            group_test1_id = self.grouping.create_group(
                'test1', 'test group', 'test_user', 'dynamic', [],
                ['Operator.account_name', '=', 'operator1'])
        self.assertTrue("Cannot create group %d: No resultset provided" %
                        group_test1_id, str(context.exception))

    def test_create_group_empty_filter(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe'])
        group_definition = self.grouping.get_group_by_id(group_test1_id)
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE', '1 = 1'
            ]))

    def test_create_group(self):
        id_ = self.grouping.create_group(
            'test1', 'CPEs of operator1', 'test_user', 'dynamic',
            ['cpe.cpeid'], ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.get_group_by_id(id_)
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                'Operator.account_name = operator1'
            ]))

    def test_key_expansion(self):
        id_ = self.grouping.create_group('test2', 'CPEs of operator1',
                                         'test_user', 'dynamic', ['cpe'],
                                         ['Operator', '=', 'operator1'])
        group_definition = self.grouping.get_group_by_id(id_)
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                'Operator.account_name = operator1'
            ]))

    def test_extend_group(self):
        # Create group
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']

        with self.assertRaises(ValueError) as context:
            self.grouping.create_group(
                'test2',
                'test group',
                'test_user',
                'static', ['Operator.account_name'],
                ['User.account_name', '=', 'user1'],
                base_group=group_test1_id)
        self.assertEqual(
            "Cannot create group test2: Cannot extend from or to static group",
            str(context.exception))

        self.grouping.create_group(
            'test2',
            'test group',
            'test_user',
            'dynamic', ['Operator.account_name'], ['User', '=', 'user1'],
            base_group=group_test1_id)
        group_definition = self.grouping.search_groups_by_name('test2')[0]
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid, Operator.account_name', 'FROM',
                'vss_OPERATOR AS `Operator`', 'INNER JOIN vss_USER AS `User`',
                'ON Operator.account_name = User.account_parent',
                'INNER JOIN CPEManager_CPEs AS `cpe`',
                'ON Operator.account_name = cpe.cid2', 'WHERE',
                '(Operator.account_name = operator1 and User.account_name = user1)'
            ]))

    def test_create_group_in_operator(self):
        group_test3_id = self.grouping.create_group(
            'test3', 'test group', 'test_user', 'dynamic',
            ['cpe.cpeid', 'User.account_name'], [
                'cpe.cpeid', 'in', ('ZZ0000000001', 'ZZ0000000002',
                                    'ZZ0000000003', 'ZZ0000000004')
            ])
        group_definition = self.grouping.get_group_by_id(group_test3_id)
        self.assertEqual(group_definition['name'], 'test3')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid, User.account_name', 'FROM',
                'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_USER_CPE_RELATION AS `UserCPERelation`',
                'ON cpe.cpeid = UserCPERelation.cpeid',
                'INNER JOIN vss_USER AS `User`',
                'ON UserCPERelation.userid = User.account_name', 'WHERE',
                'cpe.cpeid in (ZZ0000000001,ZZ0000000002,ZZ0000000003,ZZ0000000004)'
            ]))

    def test_create_group_wrong_filter(self):
        group_test1_id = 0
        with self.assertRaises(ValueError) as context:
            group_test1_id = self.grouping.create_group(
                'test1', 'test group', 'test_user', 'dynamic',
                ['Operator.account_name'], ['User.account_name', '=', '%s'])
        self.assertTrue("Cannot create group %d: "
                        "Filter doesn't comply with group type dynamic" %
                        group_test1_id, str(context.exception))

    def test_delete_group(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.get_group_by_id(group_test1_id)
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                'Operator.account_name = operator1'
            ]))

        self.grouping.delete_group(group_test1_id)
        with self.assertRaises(ValueError) as context:
            group_definition = self.grouping.get_group_by_id(group_test1_id)
        self.assertTrue("Group test1 does not exist", str(context.exception))

    def test_update_group(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                'Operator.account_name = operator1'
            ]))

        self.grouping.update_group(
            group_test1_id, 'test1', 'test group', 'test_user', 'dynamic',
            ['Operator.account_name'], ['cpe.cpeid', '=', 'ZZ0000000001'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'Operator.account_name', 'FROM',
                'vss_OPERATOR AS `Operator`',
                'INNER JOIN CPEManager_CPEs AS `cpe`',
                'ON Operator.account_name = cpe.cid2', 'WHERE',
                'cpe.cpeid = ZZ0000000001'
            ]))

        with self.assertRaises(ValueError) as context:
            self.grouping.update_group(group_test1_id, 'test1', 'test group',
                                       'test_user', 'dynamic', ['cpe.cpeid'],
                                       ['=', 'operator1'])
        self.assertTrue("Cannot update group %d: Cannot set filters: " \
                "string index out of range" % group_test1_id, str(context.exception))

        self.grouping.update_group(group_test1_id, 'test1', 'test group',
                                   'test_user', 'dynamic', ['cpe.cpeid'], [])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE', '1 = 1'
            ]))

        with self.assertRaises(ValueError) as context:
            self.grouping.update_group(
                group_test1_id, 'test1', 'test group', 'test_user', 'dynamic',
                [], ['Operator.account_name', '=', 'operator1'])
        self.assertTrue("Cannot update group %d: No resultset provided" %
                        group_test1_id, context.exception)

    def test_get_members(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.get_group_by_id(group_test1_id)
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                'Operator.account_name = operator1'
            ]))

        with self.assertRaises(ValueError) as context:
            self.grouping.get_group_members(
                None, limit=2, offset=0, return_as='dict')
        self.assertEqual("Cannot fetch members of group None: " \
                "Group None does not exist", str(context.exception))

        all_results = []
        result = self.grouping.get_group_members(
            group_test1_id, limit=2, offset=0)
        all_results.extend(result)
        self.assertEqual(len(result), 2)

        result = self.grouping.get_group_members(
            group_test1_id, limit=2, offset=2)
        all_results.extend(result)
        self.assertEqual(len(result), 1)

        all_results = sorted(all_results)
        self.assertEqual(all_results[0][0], 'ZZ0000000001')
        self.assertEqual(all_results[1][0], 'ZZ0000000003')
        self.assertEqual(all_results[2][0], 'ZZ0000000004')
        self.assertEqual(
            self.grouping.get_group_member_count(group_test1_id), 3)

    def test_get_group_unconsumed_members(self):
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']

        result = self.grouping.get_group_unconsumed_members(
            group_test1_id, limit=3, offset=0, return_as='dict')
        result = sorted(result, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')

        self.grouping.consume_member(group_test1_id, 'ZZ0000000001')
        self.grouping.consume_member(group_test1_id, 'ZZ0000000003')

        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000001'))
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000003'))
        self.assertFalse(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000004'))

        self.grouping.consume_member(group_test1_id, 'ZZ0000000004')
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000004'))

        result = self.grouping.get_group_unconsumed_members(
            group_test1_id, limit=3, offset=0, return_as='dict')
        self.assertEqual(len(result), 0)

        self.grouping.reset_consumed_members(group_test1_id)
        result = self.grouping.get_group_unconsumed_members(
            group_test1_id, limit=3, offset=0, return_as='dict')
        result = sorted(result, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')

    def test_get_membership(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cid2', '=', 'operator1'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE', 'cpe.cid2 = operator1'
            ]))

        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cpeid', '=', 'ZZ0000000001'])
        group_definition = self.grouping.search_groups_by_name('test2')[0]
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE', 'cpe.cpeid = ZZ0000000001'
            ]))

        group_test3_id = self.grouping.create_group(
            'test3', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['User.account_name', '=', 'user2'])
        group_definition = self.grouping.search_groups_by_name('test3')[0]
        self.assertEqual(group_definition['name'], 'test3')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_USER_CPE_RELATION AS `UserCPERelation`',
                'ON cpe.cpeid = UserCPERelation.cpeid',
                'INNER JOIN vss_USER AS `User`',
                'ON UserCPERelation.userid = User.account_name', 'WHERE',
                'User.account_name = user2'
            ]))

        group_test4_id = self.grouping.create_group(
            'test4', 'test group', 'test_user', 'dynamic',
            ['Operator.account_name'], ['cpe.cpeid', '=', 'ZZ0000000004'])
        group_definition = self.grouping.search_groups_by_name('test4')[0]
        self.assertEqual(group_definition['name'], 'test4')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'Operator.account_name', 'FROM',
                'vss_OPERATOR AS `Operator`',
                'INNER JOIN CPEManager_CPEs AS `cpe`',
                'ON Operator.account_name = cpe.cid2', 'WHERE',
                'cpe.cpeid = ZZ0000000004'
            ]))

        self.assertFalse(
            self.grouping.get_group_membership(None, 'ZZ0000000004'))

        membership = self.grouping.get_group_membership('cpe', 'ZZ0000000004')
        self.assertEqual(len(membership), 2)
        self.assertTrue(group_test1_id in membership)
        self.assertTrue(group_test3_id in membership)

        membership = self.grouping.get_group_membership(
            'Enterprise.account_name', 'enterprise1')
        self.assertEqual(len(membership), 0)

        membership = self.grouping.get_group_membership('Operator',
                                                        'operator1')
        self.assertEqual(len(membership), 1)
        self.assertTrue(group_test4_id in membership)

    def test_is_member(self):
        group_test0_id = self.grouping.create_group(
            'test0', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            [['cpe.cid2', '=', 'operator1'], 'or',
             [['cpe.cpetype', 'like', 'gen\*ric*'], 'and',
              ['cpe.version', 'like', '1.*']]])
        group_definition = self.grouping.search_groups_by_name('test0')[0]
        self.assertEqual(group_definition['name'], 'test0')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE',
                '(cpe.cid2 = operator1 or (cpe.cpetype like gen*ric%% and cpe.version like 1.%%))'
            ]))

        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            [['cpe.cid2', '=', 'operator1'], 'or',
             [['cpe.state', '<', 5], 'and', ['cpe.version', 'like', '1.*']]])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE',
                '(cpe.cid2 = operator1 or (cpe.state < 5 and cpe.version like 1.%%))'
            ]))

        with self.assertRaises(ValueError) as context:
            self.grouping.is_member('cpe.cpeid', 'ZZ0000000004', None)
        self.assertEqual("Cannot verify membership for " \
                "cpe.cpeid=ZZ0000000004 against group None: " \
                "Group None does not exist", str(context.exception))

        self.assertFalse(
            self.grouping.is_member(None, 'ZZ0000000004', group_test1_id))

        self.assertTrue(
            self.grouping.is_member('cpe.cpeid', 'ZZ0000000001',
                                    group_test1_id))
        self.assertFalse(
            self.grouping.is_member('cpe.cpeid', 'ZZ0000000002',
                                    group_test1_id))
        self.assertTrue(
            self.grouping.is_member('cpe.cpeid', 'ZZ0000000003',
                                    group_test1_id))
        self.assertTrue(
            self.grouping.is_member('cpe.cpeid', 'ZZ0000000004',
                                    group_test1_id))


class TestAXGroupingLazy(unittest2.TestCase):
    def setUp(self):
        prepare_data()
        self.grouping = Grouping(GroupTestSchema, engine)

    def tearDown(self):
        cleanup_data()

    def test_create_group(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'lazy', ['cpe.cpeid'],
            ['Operator.account_name', '=', '%(operator_name)s'])
        group_definition = self.grouping.get_group_by_id(group_test1_id)
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'lazy')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                'Operator.account_name = %(operator_name)s'
            ]))

    def test_extend_group(self):
        # Create group
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']

        with self.assertRaises(ValueError) as context:
            self.grouping.create_group(
                'test2',
                'test group',
                'test_user',
                'dynamic', ['cpe.cpeid'],
                ['Operator.account_name', '=', 'operator1'],
                base_group=group_test1_id)
        self.assertEqual(
            "Cannot create group test2: Filter doesn't comply with group type dynamic",
            str(context.exception))

        self.grouping.create_group(
            'test2',
            'test group',
            'test_user',
            'lazy', ['cpe.cpeid'], ['Operator.account_name', '=', 'operator1'],
            base_group=group_test1_id)
        group_definition = self.grouping.search_groups_by_name('test2')[0]
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'lazy')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                '(Operator.account_name = %(operator_name)s and '
                'Operator.account_name = operator1)'
            ]))

    def test_create_group_wrong_filter(self):
        group_test1_id = 0
        with self.assertRaises(ValueError) as context:
            group_test1_id = self.grouping.create_group(
                'test1', 'test group', 'test_user', 'lazy',
                ['Operator.account_name'], ['User.account_name', '=', 'user1'])
        self.assertTrue("Cannot create group %d: "
                        "Filter doesn't comply with group type lazy" %
                        group_test1_id, str(context.exception))

    def test_update_group(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                'Operator.account_name = operator1'
            ]))

        self.grouping.update_group(
            group_test1_id, 'test1', 'test group', 'test_user', 'lazy',
            ['Operator.account_name'], ['cpe.cpeid', '=', '%(cpeid)s'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'lazy')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'Operator.account_name', 'FROM',
                'vss_OPERATOR AS `Operator`',
                'INNER JOIN CPEManager_CPEs AS `cpe`',
                'ON Operator.account_name = cpe.cid2', 'WHERE',
                'cpe.cpeid = %(cpeid)s'
            ]))

        self.grouping.update_group(group_test1_id, 'test1', 'test group',
                                   'test_user', 'dynamic', ['cpe.cpeid'],
                                   ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                'Operator.account_name = operator1'
            ]))

    def test_get_members(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'lazy', ['cpe.cpeid'],
            [['Operator.account_name', '=', '%(operator_name)s'], 'or',
             ['Enterprise.account_name', '=', '%(enterprise_name)s']])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'lazy')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
                build_query(query_map),
                ' '.join(['SELECT', 'cpe.cpeid', 'FROM',
                    'CPEManager_CPEs AS `cpe`',
                    'INNER JOIN vss_OPERATOR AS `Operator`',
                    'ON cpe.cid2 = Operator.account_name',
                    'INNER JOIN vss_ENTERPRISE AS `Enterprise`',
                    'ON Operator.account_parent = Enterprise.account_name',
                    'WHERE',
                    '(Operator.account_name = %(operator_name)s or ' \
                            'Enterprise.account_name = %(enterprise_name)s)']))

        with self.assertRaises(ValueError) as context:
            self.grouping.get_group_members(
                group_test1_id, limit=2, offset=0, return_as='dict')
        self.assertTrue("Cannot fetch members of group test1: " \
                "lazy filters cannot be resolved", str(context.exception))

        with self.assertRaises(ValueError) as context:
            self.grouping.get_group_members(
                group_test1_id,
                lazy_filter={'enterprise_name': 'enterprise1'},
                limit=2,
                offset=0,
                return_as='dict')
        self.assertEqual("Cannot fetch members of group %d: " \
                "Cannot resolve filter: Key 'operator_name' not found" % group_test1_id,
                str(context.exception))

        all_results = []
        result = self.grouping.get_group_members(
            group_test1_id,
            lazy_filter={
                'enterprise_name': 'enterprise1',
                'operator_name': 'operator1'
            },
            limit=2,
            offset=0,
            return_as='dict')
        all_results.extend(result)
        self.assertEqual(len(result), 2)
        result = self.grouping.get_group_members(
            group_test1_id,
            lazy_filter={
                'enterprise_name': 'enterprise1',
                'operator_name': 'operator1'
            },
            limit=2,
            offset=2,
            return_as='dict')
        all_results.extend(result)
        self.assertEqual(len(result), 1)

        all_results = sorted(all_results, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(all_results[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(all_results[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(all_results[2]['cpe.cpeid'], 'ZZ0000000004')
        self.assertEqual(
            self.grouping.get_group_member_count(
                group_test1_id,
                lazy_filter={
                    'enterprise_name': 'enterprise1',
                    'operator_name': 'operator1'
                }), 3)

    def test_get_group_unconsumed_members(self):
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']

        result = self.grouping.get_group_unconsumed_members(
            group_test1_id,
            lazy_filter={'operator_name': 'operator1'},
            limit=3,
            offset=0,
            return_as='dict')
        result = sorted(result, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')

        self.grouping.consume_member(group_test1_id, 'ZZ0000000001')
        self.grouping.consume_member(group_test1_id, 'ZZ0000000003')

        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000001'))
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000003'))
        self.assertFalse(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000004'))

        self.grouping.consume_member(group_test1_id, 'ZZ0000000004')
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000004'))

        result = self.grouping.get_group_unconsumed_members(
            group_test1_id,
            lazy_filter={'operator_name': 'operator1'},
            limit=3,
            offset=0,
            return_as='dict')
        self.assertEqual(len(result), 0)

        self.grouping.reset_consumed_members(group_test1_id)
        result = self.grouping.get_group_unconsumed_members(
            group_test1_id,
            lazy_filter={'operator_name': 'operator1'},
            limit=3,
            offset=0,
            return_as='dict')
        self.assertEqual(len(result), 3)
        result = sorted(result, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')

    def test_get_membership(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'lazy', ['cpe.cpeid'],
            [['Operator.account_name', '=', '%(operator_name)s'], 'or',
             ['Enterprise.account_name', '=', '%(enterprise_name)s']])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'lazy')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
                build_query(query_map),
                ' '.join(['SELECT', 'cpe.cpeid', 'FROM',
                    'CPEManager_CPEs AS `cpe`',
                    'INNER JOIN vss_OPERATOR AS `Operator`',
                    'ON cpe.cid2 = Operator.account_name',
                    'INNER JOIN vss_ENTERPRISE AS `Enterprise`',
                    'ON Operator.account_parent = Enterprise.account_name',
                    'WHERE',
                    '(Operator.account_name = %(operator_name)s or ' \
                            'Enterprise.account_name = %(enterprise_name)s)']))

        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cid2', '=', 'operator1'])
        group_definition = self.grouping.search_groups_by_name('test2')[0]
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE', 'cpe.cid2 = operator1'
            ]))

        membership = self.grouping.get_group_membership('cpe.cpeid',
                                                        'ZZ0000000001')
        self.assertEqual(len(membership), 1)
        self.assertTrue(group_test2_id in membership)

        membership = self.grouping.get_group_membership('cpe.cpeid',
                                                        'ZZ0000000002')
        self.assertEqual(len(membership), 0)

        membership = self.grouping.get_group_membership('cpe.cpeid',
                                                        'ZZ0000000001')
        self.assertEqual(len(membership), 1)
        self.assertTrue(group_test2_id in membership)

        membership = self.grouping.get_group_membership('cpe.cpeid',
                                                        'ZZ0000000001')
        self.assertEqual(len(membership), 1)
        self.assertTrue(group_test2_id in membership)

    def test_is_member(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'lazy', ['cpe.cpeid'],
            [['Operator.account_name', '=', 'operator1'], 'or',
             ['Enterprise.account_name', '=', '%(enterprise_name)s']])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'lazy')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
                build_query(query_map),
                ' '.join(['SELECT', 'cpe.cpeid', 'FROM',
                    'CPEManager_CPEs AS `cpe`',
                    'INNER JOIN vss_OPERATOR AS `Operator`',
                    'ON cpe.cid2 = Operator.account_name',
                    'INNER JOIN vss_ENTERPRISE AS `Enterprise`',
                    'ON Operator.account_parent = Enterprise.account_name',
                    'WHERE',
                    '(Operator.account_name = operator1 or ' \
                            'Enterprise.account_name = %(enterprise_name)s)']))

        with self.assertRaises(ValueError) as context:
            self.grouping.is_member('cpe.cpeid', 'ZZ0000000001',
                                    group_test1_id)
        self.assertEqual("Cannot verify membership for " \
                "cpe.cpeid=ZZ0000000001 against group %d: " \
                "Cannot resolve filter: Key 'enterprise_name' not found" % group_test1_id,
                str(context.exception))

        with self.assertRaises(ValueError) as context:
            self.grouping.is_member(
                'cpe.cpeid',
                'ZZ0000000001',
                group_test1_id,
                lazy_filter={'operator_name': 'operator1'})
        self.assertTrue("Cannot verify membership for " \
                "cpe.cpeid=ZZ0000000001 against group %d: " \
                "lazy filters cannot be resolved" % group_test1_id,
                str(context.exception))

        self.assertTrue(
            self.grouping.is_member(
                'cpe.cpeid',
                'ZZ0000000001',
                group_test1_id,
                lazy_filter={
                    'enterprise_name': 'enterprise1',
                    'operator_name': 'operator1'
                }))
        self.assertFalse(
            self.grouping.is_member(
                'cpe.cpeid',
                'ZZ0000000002',
                group_test1_id,
                lazy_filter={'enterprise_name': 'enterprise1'}))
        self.assertTrue(
            self.grouping.is_member(
                'cpe.cpeid',
                'ZZ0000000003',
                group_test1_id,
                lazy_filter={'enterprise_name': 'enterprise1'}))
        self.assertTrue(
            self.grouping.is_member(
                'cpe.cpeid',
                'ZZ0000000004',
                group_test1_id,
                lazy_filter={'enterprise_name': 'enterprise1'}))


class TestAXGroupingStatic(unittest2.TestCase):
    def setUp(self):
        prepare_data()
        self.grouping = Grouping(GroupTestSchema, engine)

    def tearDown(self):
        cleanup_data()

    def test_create_group(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'static',
            ['cpe.cpeid', 'User.account_name'], [
                'cpe.cpeid', 'in', ('ZZ0000000001', 'ZZ0000000002',
                                    'ZZ0000000003', 'ZZ0000000004')
            ])
        group_definition = self.grouping.get_group_by_id(group_test1_id)
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'static')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid, User.account_name', 'FROM',
                'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_USER_CPE_RELATION AS `UserCPERelation`',
                'ON cpe.cpeid = UserCPERelation.cpeid',
                'INNER JOIN vss_USER AS `User`',
                'ON UserCPERelation.userid = User.account_name',
                'INNER JOIN AXGroupStaticRelation AS AXGroupStaticRelation',
                'ON cpe.cpeid = AXGroupStaticRelation.member_id', 'WHERE',
                'AXGroupStaticRelation.group_id = %d' % group_test1_id
            ]))

    def test_create_group_wrong_filter(self):
        with self.assertRaises(ValueError) as context:
            self.grouping.create_group(
                'test1', 'test group', 'test_user', 'static',
                ['cpe.cpeid', 'cpe.version'],
                [['Operator.account_name', '=', 'operator1'], 'or',
                 ['Operator.account_name', '=', 'operator2']])
        self.assertTrue("Cannot create group test1: Filter doesn't "
                        "comply with group type static:",
                        str(context.exception))

    def test_update_group(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                'Operator.account_name = operator1'
            ]))

        self.grouping.update_group(
            group_test1_id, 'test1', 'test group', 'test_user', 'lazy',
            ['Operator.account_name'], ['cpe.cpeid', '=', '%(cpeid)s'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'lazy')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'Operator.account_name', 'FROM',
                'vss_OPERATOR AS `Operator`',
                'INNER JOIN CPEManager_CPEs AS `cpe`',
                'ON Operator.account_name = cpe.cid2', 'WHERE',
                'cpe.cpeid = %(cpeid)s'
            ]))

        self.grouping.update_group(group_test1_id, 'test1', 'test group',
                                   'test_user', 'static',
                                   ['cpe.cpeid', 'cpe.version'],
                                   ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'static')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid, cpe.version', 'FROM',
                'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name',
                'INNER JOIN AXGroupStaticRelation AS AXGroupStaticRelation',
                'ON Operator.account_name = AXGroupStaticRelation.member_id',
                'WHERE', 'AXGroupStaticRelation.group_id = %d' % group_test1_id
            ]))

        self.grouping.update_group(group_test1_id, 'test1', 'test group',
                                   'test_user', 'dynamic', ['cpe.cpeid'],
                                   ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                'Operator.account_name = operator1'
            ]))

    def test_get_members(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'static',
            ['cpe.cpeid', 'User.account_name'], [
                'cpe.cpeid', 'in', ('ZZ0000000001', 'ZZ0000000002',
                                    'ZZ0000000003', 'ZZ0000000004')
            ])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'static')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid, User.account_name', 'FROM',
                'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_USER_CPE_RELATION AS `UserCPERelation`',
                'ON cpe.cpeid = UserCPERelation.cpeid',
                'INNER JOIN vss_USER AS `User`',
                'ON UserCPERelation.userid = User.account_name',
                'INNER JOIN AXGroupStaticRelation AS AXGroupStaticRelation',
                'ON cpe.cpeid = AXGroupStaticRelation.member_id', 'WHERE',
                'AXGroupStaticRelation.group_id = %d' % group_test1_id
            ]))

        all_results = []
        result = self.grouping.get_group_members(
            group_test1_id, limit=3, offset=0, return_as='dict')
        all_results.extend(result)
        self.assertEqual(len(result), 3)

        result = self.grouping.get_group_members(
            group_test1_id, limit=3, offset=3, return_as='dict')
        all_results.extend(result)
        self.assertEqual(len(result), 1)

        all_results = sorted(all_results, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(all_results[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(all_results[0]['User.account_name'], 'user1')
        self.assertEqual(all_results[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(all_results[1]['User.account_name'], 'user2')
        self.assertEqual(all_results[2]['cpe.cpeid'], 'ZZ0000000004')
        self.assertEqual(all_results[2]['User.account_name'], 'user1')
        self.assertEqual(all_results[3]['cpe.cpeid'], 'ZZ0000000004')
        self.assertEqual(all_results[3]['User.account_name'], 'user2')
        self.assertEqual(
            self.grouping.get_group_member_count(group_test1_id), 4)

    def test_get_group_unconsumed_members(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'static', ['cpe.cpeid'], [
                'cpe.cpeid', 'in', ('ZZ0000000001', 'ZZ0000000002',
                                    'ZZ0000000003', 'ZZ0000000004')
            ])

        result = self.grouping.get_group_unconsumed_members(
            group_test1_id, limit=4, offset=0, return_as='dict')

        result = sorted(result, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(len(result), 4)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000002')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[3]['cpe.cpeid'], 'ZZ0000000004')

        self.grouping.consume_member(group_test1_id, 'ZZ0000000001')
        self.grouping.consume_member(group_test1_id, 'ZZ0000000003')

        result = self.grouping.get_group_unconsumed_members(
            group_test1_id, limit=2, offset=0, return_as='dict')
        result = sorted(result, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000002')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000004')

        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000001'))
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000003'))
        self.assertFalse(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000004'))
        self.assertFalse(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000002'))

        self.grouping.consume_member(group_test1_id, 'ZZ0000000002')
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000002'))
        self.grouping.consume_member(group_test1_id, 'ZZ0000000004')
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000004'))

        result = self.grouping.get_group_unconsumed_members(
            group_test1_id, limit=4, offset=0, return_as='list')
        self.assertEqual(len(result), 0)

        self.grouping.reset_consumed_members(group_test1_id)
        result = self.grouping.get_group_unconsumed_members(
            group_test1_id, limit=4, offset=0, return_as='list')
        result = sorted(result)
        self.assertEqual(len(result), 4)
        self.assertEqual(result[0][0], 'ZZ0000000001')
        self.assertEqual(result[1][0], 'ZZ0000000002')
        self.assertEqual(result[2][0], 'ZZ0000000003')
        self.assertEqual(result[3][0], 'ZZ0000000004')

    def test_get_membership(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'static',
            ['cpe.cpeid', 'User.account_name'], [
                'cpe.cpeid', 'in', ('ZZ0000000001', 'ZZ0000000002',
                                    'ZZ0000000003', 'ZZ0000000004')
            ])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'static')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid, User.account_name', 'FROM',
                'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_USER_CPE_RELATION AS `UserCPERelation`',
                'ON cpe.cpeid = UserCPERelation.cpeid',
                'INNER JOIN vss_USER AS `User`',
                'ON UserCPERelation.userid = User.account_name',
                'INNER JOIN AXGroupStaticRelation AS AXGroupStaticRelation',
                'ON cpe.cpeid = AXGroupStaticRelation.member_id', 'WHERE',
                'AXGroupStaticRelation.group_name = test1 AND AXGroupStaticRelation.user = default'
            ]))

        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'static',
            ['cpe.cpeid', 'cpe.version'],
            ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.search_groups_by_name('test2')[0]
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'static')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid, cpe.version', 'FROM',
                'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name',
                'INNER JOIN AXGroupStaticRelation AS AXGroupStaticRelation',
                'ON Operator.account_name = AXGroupStaticRelation.member_id',
                'WHERE',
                'AXGroupStaticRelation.group_name = test2 AND AXGroupStaticRelation.user = default'
            ]))

        group_test3_id = self.grouping.create_group(
            'test3', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cpeid', '=', 'ZZ0000000001'])
        group_definition = self.grouping.search_groups_by_name('test3')[0]
        self.assertEqual(group_definition['name'], 'test3')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE', 'cpe.cpeid = ZZ0000000001'
            ]))

        membership = self.grouping.get_group_membership('cpe.cpeid',
                                                        'ZZ0000000004')
        self.assertEqual(len(membership), 2)
        self.assertTrue(group_test1_id in membership)
        self.assertTrue(group_test2_id in membership)

        membership = self.grouping.get_group_membership('cpe.cpeid',
                                                        'ZZ0000000001')
        self.assertEqual(len(membership), 3)
        self.assertTrue(group_test1_id in membership)
        self.assertTrue(group_test2_id in membership)
        self.assertTrue(group_test3_id in membership)

        membership = self.grouping.get_group_membership('User.account_name',
                                                        'user1')
        self.assertEqual(len(membership), 1)
        self.assertTrue(group_test1_id in membership)

    def test_get_membership(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'static',
            ['cpe.cpeid', 'User.account_name'], [
                'cpe.cpeid', 'in', ('ZZ0000000001', 'ZZ0000000002',
                                    'ZZ0000000003', 'ZZ0000000004')
            ])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'static')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid, User.account_name', 'FROM',
                'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_USER_CPE_RELATION AS `UserCPERelation`',
                'ON cpe.cpeid = UserCPERelation.cpeid',
                'INNER JOIN vss_USER AS `User`',
                'ON UserCPERelation.userid = User.account_name',
                'INNER JOIN AXGroupStaticRelation AS AXGroupStaticRelation',
                'ON cpe.cpeid = AXGroupStaticRelation.member_id', 'WHERE',
                'AXGroupStaticRelation.group_id = %d' % group_test1_id
            ]))

        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'static',
            ['cpe.cpeid', 'cpe.version'],
            ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.search_groups_by_name('test2')[0]
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'static')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid, cpe.version', 'FROM',
                'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name',
                'INNER JOIN AXGroupStaticRelation AS AXGroupStaticRelation',
                'ON Operator.account_name = AXGroupStaticRelation.member_id',
                'WHERE', 'AXGroupStaticRelation.group_id = %d' % group_test2_id
            ]))

        group_test3_id = self.grouping.create_group(
            'test3', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cpeid', '=', 'ZZ0000000001'])
        group_definition = self.grouping.search_groups_by_name('test3')[0]
        self.assertEqual(group_definition['name'], 'test3')
        self.assertEqual(group_definition['type'], 'dynamic')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE', 'cpe.cpeid = ZZ0000000001'
            ]))

        self.assertTrue(
            self.grouping.is_member('cpe.cpeid', 'ZZ0000000001',
                                    group_test1_id))
        self.assertTrue(
            self.grouping.is_member('cpe.cpeid', 'ZZ0000000001',
                                    group_test2_id))
        self.assertTrue(
            self.grouping.is_member('cpe', 'ZZ0000000001', group_test3_id))

        self.assertTrue(
            self.grouping.is_member('User', 'user1', group_test1_id))
        self.assertFalse(
            self.grouping.is_member('User.account_name', 'user1',
                                    group_test2_id))
        self.assertFalse(
            self.grouping.is_member('User.account_name', 'user1',
                                    group_test3_id))

        self.assertFalse(
            self.grouping.is_member('Operator.account_name', 'operator1',
                                    group_test1_id))


class TestAXGroupingSuper(unittest2.TestCase):
    def setUp(self):
        prepare_data()
        self.grouping = Grouping(GroupTestSchema, engine)

    def tearDown(self):
        cleanup_data()

    def test_create_group_on_lazy_groups_with_overlapping_placeholders(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'lazy', ['cpe.cpeid'],
            ['cpe.cpeid', '=', '%(cpeid)s'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'lazy')

        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'lazy', ['cpe.cpeid'],
            [['cpe.cpetype', '=', '%(cpetype)s'], 'and',
             ['cpe.cpeid', '=', '%(cpeid)s']])
        group_definition = self.grouping.search_groups_by_name('test2')[0]
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'lazy')

        group_super_test1_id = 0
        with self.assertRaises(ValueError) as context:
            group_super_test1_id = self.grouping.create_super_group(
                'super_test1', 'test group', 'test_user',
                [group_test2_id, group_test1_id])
        self.assertTrue("Cannot create super group %d: "
                        "Sub-groups have overlapping placeholders" %
                        group_super_test1_id, str(context.exception))

    def test_create_group_disjoint_resultsets(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic',
            ['cpe.cpeid', 'cpe.cid'], ['cpe.cpeid', '=', 'ZZ0000000002'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')

        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'dynamic',
            ['cpe.cpeid', 'cpe.cpetype'], ['User.account_name', '=', 'user2'])
        group_definition = self.grouping.search_groups_by_name('test2')[0]
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'dynamic')

        with self.assertRaises(ValueError) as context:
            group_test1_id = 0
            group_test1_id = self.grouping.create_super_group(
                'super_test1', 'test group', 'test_user',
                [group_test2_id, group_test1_id])
        self.assertTrue("Cannot create super group %d: "
                        "Sub-groups have disjoint resultsets" % group_test1_id,
                        str(context.exception))

    def test_create_group(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cpeid', '=', 'ZZ0000000002'])
        group_definition = self.grouping.get_group_by_id(group_test1_id)
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')

        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['User.account_name', '=', 'user2'])
        group_definition = self.grouping.get_group_by_id(group_test2_id)
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'dynamic')

        group_super_test1_id = self.grouping.create_super_group(
            'super_test1', 'test super group', 'test_user',
            [group_test1_id, group_test2_id])
        group_definition = self.grouping.get_group_by_id(group_super_test1_id)
        self.assertEqual(group_definition['name'], 'super_test1')
        self.assertEqual(group_definition['type'], 'super')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = ZZ0000000002", "UNION", "SELECT",
                "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "INNER JOIN vss_USER_CPE_RELATION AS `UserCPERelation`",
                "ON cpe.cpeid = UserCPERelation.cpeid",
                "INNER JOIN vss_USER AS `User`",
                "ON UserCPERelation.userid = User.account_name", "WHERE",
                "User.account_name = user2"
            ]))

        group_test3_id = self.grouping.create_group(
            'test3', 'test group', 'test_user', 'lazy', ['cpe.cpeid'],
            ['cpe.cpeid', '=', '%(cpeid)s'])
        group_definition = self.grouping.get_group_by_id(group_test3_id)
        self.assertEqual(group_definition['name'], 'test3')
        self.assertEqual(group_definition['type'], 'lazy')

        group_super_test2_id = self.grouping.create_super_group(
            'super_test2', 'test super group', 'test_user',
            [group_test3_id, group_super_test1_id])
        group_definition = self.grouping.get_group_by_id(group_super_test2_id)
        self.assertEqual(group_definition['name'], 'super_test2')
        self.assertEqual(group_definition['type'], 'super')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = ZZ0000000002", "UNION", "SELECT",
                "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "INNER JOIN vss_USER_CPE_RELATION AS `UserCPERelation`",
                "ON cpe.cpeid = UserCPERelation.cpeid",
                "INNER JOIN vss_USER AS `User`",
                "ON UserCPERelation.userid = User.account_name", "WHERE",
                "User.account_name = user2", "UNION", "SELECT", "cpe.cpeid",
                "FROM", "CPEManager_CPEs AS `cpe`", "WHERE",
                "cpe.cpeid = %(cpeid)s"
            ]))

        group_super_test3_id = self.grouping.create_super_group_with_condition(
            'super_test3',
            'test super group',
            'test_user', [group_test1_id],
            internal=False,
            cond_type='dynamic',
            cond_result_list=['cpe.cpeid'],
            cond_filter_list=['Enterprise.account_name', '=', 'enterprise1'])
        children = self.grouping.get_children(group_super_test3_id)
        self.assertEqual(2, len(children))
        group_definition = self.grouping.get_group_by_id(group_super_test3_id)
        self.assertEqual(group_definition['name'], 'super_test3')
        self.assertEqual(group_definition['type'], 'super')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = ZZ0000000002", "UNION", "SELECT",
                "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "INNER JOIN vss_OPERATOR AS `Operator`",
                'ON cpe.cid2 = Operator.account_name',
                "INNER JOIN vss_ENTERPRISE AS `Enterprise`",
                'ON Operator.account_parent = Enterprise.account_name',
                "WHERE", "Enterprise.account_name = enterprise1"
            ]))

    def test_group_search(self):
        # Create groups
        self.test_create_group()

        super_groups = self.grouping.get_groups_by_type('super')
        self.assertEqual(3, len(super_groups))
        self.assertEqual('super', super_groups[0]['type'])
        self.assertEqual('super', super_groups[1]['type'])
        self.assertEqual('super', super_groups[2]['type'])

        super_groups = self.grouping.search_groups_by_description('*super*')
        self.assertEqual(3, len(super_groups))
        self.assertEqual('super', super_groups[0]['type'])
        self.assertEqual('super', super_groups[1]['type'])
        self.assertEqual('super', super_groups[2]['type'])

        dynamic_groups = self.grouping.get_groups_by_type('dynamic')
        self.assertEqual(2, len(dynamic_groups))
        self.assertEqual('dynamic', dynamic_groups[0]['type'])
        self.assertEqual('dynamic', dynamic_groups[1]['type'])

        dynamic_groups = self.grouping.get_groups_by_type('lazy')
        self.assertEqual(1, len(dynamic_groups))
        self.assertEqual('lazy', dynamic_groups[0]['type'])

        groups = self.grouping.search_groups(
            filter_list=[['Group.type', '=', 'super'], 'and',
                         [['Group.name', 'like', '*test2'], 'or',
                          ['Group.name', 'like', '*test3']]],
            result_list=['Group.id', 'Group.name'],
            sort=[('Group.name', 'desc'), ('Group.id', 'asc')])
        self.assertEqual(2, len(groups))
        self.assertEqual('super_test3', groups[0]['Group.name'])
        self.assertEqual('super_test2', groups[1]['Group.name'])

    def test_delete_group(self):
        # Create groups
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']
        group_test2_id = self.grouping.search_groups_by_name('test2')[0]['id']
        group_test3_id = self.grouping.search_groups_by_name('test3')[0]['id']
        group_super_test1_id = self.grouping.search_groups_by_name(
            'super_test1')[0]['id']
        group_super_test2_id = self.grouping.search_groups_by_name(
            'super_test2')[0]['id']
        group_super_test3_id = self.grouping.search_groups_by_name(
            'super_test3')[0]['id']

        # Group for extra condition is an internal group
        internal_groups = self.grouping.get_all_groups(internal=True)
        for group in internal_groups:
            if group['name'] == 'super_test3_extra_condition':
                group_super_test3_extra_cond_id = group['id']

        with self.assertRaises(ValueError) as context:
            self.grouping.delete_group(group_test1_id)
        self.assertTrue("Cannot delete group %d: "
                        "Group is referenced by another group" %
                        group_test1_id, str(context.exception))

        with self.assertRaises(ValueError) as context:
            self.grouping.delete_group(group_test2_id)
        self.assertTrue("Cannot delete group %d: "
                        "Group is referenced by another group" %
                        group_test2_id, str(context.exception))

        with self.assertRaises(ValueError) as context:
            self.grouping.delete_group(group_test3_id)
        self.assertTrue("Cannot delete group %d: "
                        "Group is referenced by another group" %
                        group_test3_id, str(context.exception))

        with self.assertRaises(ValueError) as context:
            self.grouping.delete_group(group_super_test1_id)
        self.assertTrue("Cannot delete group %d: "
                        "Group is referenced by another group" %
                        group_super_test1_id, str(context.exception))

        self.grouping.delete_group(group_super_test2_id)
        group_definition = self.grouping.search_groups_by_name('super_test2')
        self.assertEqual(0, len(group_definition))

        self.grouping.delete_group(group_test3_id)
        group_definition = self.grouping.search_groups_by_name('test3')
        self.assertEqual(0, len(group_definition))

        with self.assertRaises(ValueError) as context:
            self.grouping.delete_group(group_test1_id)
        self.assertTrue("Cannot delete group %d: "
                        "Group is referenced by another group" %
                        group_test1_id, str(context.exception))

        with self.assertRaises(ValueError) as context:
            self.grouping.delete_group(group_test2_id)
        self.assertTrue("Cannot delete group %d: "
                        "Group is referenced by another group" %
                        group_test2_id, str(context.exception))

        self.grouping.delete_group(group_super_test1_id)
        group_definition = self.grouping.search_groups_by_name('super_test1')
        self.assertEqual(0, len(group_definition))

        self.grouping.delete_group(group_super_test3_id)
        group_definition = self.grouping.search_groups_by_name('super_test3')
        self.assertEqual(0, len(group_definition))
        group_definition = self.grouping.search_groups_by_name(
            'super_test3_extra_condition')
        self.assertEqual(0, len(group_definition))

        self.grouping.delete_group(group_test1_id)
        group_definition = self.grouping.search_groups_by_name('test1')
        self.assertEqual(0, len(group_definition))

        self.grouping.delete_group(group_test2_id)
        group_definition = self.grouping.search_groups_by_name('test2')
        self.assertEqual(0, len(group_definition))

    def test_force_delete_group(self):
        # Create groups
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']
        group_test2_id = self.grouping.search_groups_by_name('test2')[0]['id']
        group_test3_id = self.grouping.search_groups_by_name('test3')[0]['id']
        group_super_test1_id = self.grouping.search_groups_by_name(
            'super_test1')[0]['id']
        group_super_test3_id = self.grouping.search_groups_by_name(
            'super_test3')[0]['id']

        # Group for extra condition is an internal group
        internal_groups = self.grouping.get_all_groups(internal=True)
        for group in internal_groups:
            if group['name'] == 'super_test3_extra_condition':
                group_super_test3_extra_cond_id = group['id']

        self.grouping.delete_group(group_super_test1_id, force=True)
        group_definition = self.grouping.search_groups_by_name('super_test1')
        self.assertEqual(0, len(group_definition))

        self.grouping.delete_group(group_super_test3_extra_cond_id, force=True)
        group_definition = self.grouping.search_groups_by_name(
            'super_test3_extra_condition')
        self.assertEqual(0, len(group_definition))

        self.grouping.delete_group(group_super_test3_id, force=True)
        group_definition = self.grouping.search_groups_by_name('super_test3')
        self.assertEqual(0, len(group_definition))

        self.grouping.delete_group(group_test1_id)
        group_definition = self.grouping.search_groups_by_name('test1')
        self.assertEqual(0, len(group_definition))

        self.grouping.delete_group(group_test2_id)
        group_definition = self.grouping.search_groups_by_name('test2')
        self.assertEqual(0, len(group_definition))

        with self.assertRaises(ValueError) as context:
            self.grouping.delete_group(group_test3_id)
        self.assertTrue("Cannot delete group %d: "
                        "Group is referenced by another group" %
                        group_test3_id, str(context.exception))

    def test_update_group(self):
        # Create groups
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']
        group_super_test2_id = self.grouping.search_groups_by_name(
            'super_test2')[0]['id']

        with self.assertRaises(ValueError) as context:
            self.grouping.update_group(
                group_test1_id, 'test1', 'test group', 'test_user', 'dynamic',
                ['cpe.cpeid', '=', 'ZZ0000000001'], ['cpe.cpetype'])
        self.assertTrue("Cannot update group %d: "
                        "Group is referenced by another group" %
                        group_test1_id, str(context.exception))

        with self.assertRaises(ValueError) as context:
            self.grouping.update_group(
                group_super_test2_id, 'super_test2', 'test group', 'test_user',
                'dynamic', ['cpe.cpeid'], ['cpe.cpeid', '=', 'ZZ0000000002'])
        self.assertTrue("Cannot update group %d: "
                        "Update operation is not supported on super groups" %
                        group_super_test2_id, str(context.exception))

    def test_get_members(self):
        # Create groups
        self.test_create_group()
        group_super_test1_id = self.grouping.search_groups_by_name(
            'super_test1')[0]['id']
        group_super_test2_id = self.grouping.search_groups_by_name(
            'super_test2')[0]['id']

        result = self.grouping.get_group_members(
            group_super_test1_id, return_as='dict')
        result = sorted(result, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000002')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')
        self.assertEqual(
            self.grouping.get_group_member_count(group_super_test1_id), 3)

        with self.assertRaises(ValueError) as context:
            result = self.grouping.get_group_members(
                group_super_test2_id, return_as='dict')
        self.assertTrue("Cannot fetch members of group %d: "
                        "lazy filters cannot be resolved" %
                        group_super_test2_id, str(context.exception))

        result = self.grouping.get_group_members(
            group_super_test2_id,
            lazy_filter={'cpeid': 'ZZ0000000001'},
            return_as='dict')
        result = sorted(result, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(len(result), 4)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000002')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[3]['cpe.cpeid'], 'ZZ0000000004')
        self.assertEqual(
            self.grouping.get_group_member_count(
                group_super_test2_id, lazy_filter={'cpeid': 'ZZ0000000001'}),
            4)

        result = self.grouping.get_group_members(
            group_super_test2_id,
            lazy_filter={'cpeid': 'ZZ0000000002'},
            return_as='dict')
        result = sorted(result, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000002')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')
        self.assertEqual(
            self.grouping.get_group_member_count(
                group_super_test2_id, lazy_filter={'cpeid': 'ZZ0000000002'}),
            3)

    def test_get_group_unconsumed_members(self):
        # Create groups
        self.test_create_group()
        group_super_test1_id = self.grouping.search_groups_by_name(
            'super_test1')[0]['id']

        result = self.grouping.get_group_unconsumed_members(
            group_super_test1_id, limit=3, offset=0)
        result = sorted(result)
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0][0], 'ZZ0000000002')
        self.assertEqual(result[1][0], 'ZZ0000000003')
        self.assertEqual(result[2][0], 'ZZ0000000004')

        self.grouping.consume_member(group_super_test1_id, 'ZZ0000000002')
        self.grouping.consume_member(group_super_test1_id, 'ZZ0000000003')

        self.assertTrue(
            self.grouping.is_member_consumed(group_super_test1_id,
                                             'ZZ0000000002'))
        self.assertTrue(
            self.grouping.is_member_consumed(group_super_test1_id,
                                             'ZZ0000000003'))
        self.assertFalse(
            self.grouping.is_member_consumed(group_super_test1_id,
                                             'ZZ0000000004'))

        self.grouping.consume_member(group_super_test1_id, 'ZZ0000000004')
        self.assertTrue(
            self.grouping.is_member_consumed(group_super_test1_id,
                                             'ZZ0000000004'))

        result = self.grouping.get_group_unconsumed_members(
            group_super_test1_id, limit=3, offset=0, return_as='dict')
        self.assertEqual(len(result), 0)

        self.grouping.reset_consumed_members(group_super_test1_id)
        result = self.grouping.get_group_unconsumed_members(
            group_super_test1_id, limit=3, offset=0, return_as='dict')
        result = sorted(result, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000002')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')

    def test_get_membership(self):
        # Create groups
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']
        group_test2_id = self.grouping.search_groups_by_name('test2')[0]['id']
        group_super_test1_id = self.grouping.search_groups_by_name(
            'super_test1')[0]['id']
        group_super_test3_id = self.grouping.search_groups_by_name(
            'super_test3')[0]['id']

        # Group for extra condition is an internal group
        internal_groups = self.grouping.get_all_groups(internal=True)
        for group in internal_groups:
            if group['name'] == 'super_test3_extra_condition':
                group_super_test3_extra_cond_id = group['id']

        membership = self.grouping.get_group_membership('cpe.cpeid',
                                                        'ZZ0000000003')
        self.assertEqual(len(membership), 3)
        self.assertTrue(group_test2_id in membership)
        self.assertTrue(group_super_test1_id in membership)
        self.assertTrue(group_super_test3_id in membership)

    def test_is_member(self):
        # Create groups
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']
        group_test2_id = self.grouping.search_groups_by_name('test2')[0]['id']
        group_super_test1_id = self.grouping.search_groups_by_name(
            'super_test1')[0]['id']
        group_super_test2_id = self.grouping.search_groups_by_name(
            'super_test2')[0]['id']

        result = self.grouping.is_member('cpe.cpetype', 'genericTR69',
                                         group_super_test1_id)
        self.assertFalse(result)

        result = self.grouping.is_member('cpe.cpeid', 'XYZ',
                                         group_super_test1_id)
        self.assertFalse(result)

        result = self.grouping.is_member('cpe.cpeid', 'ZZ0000000003',
                                         group_super_test1_id)
        self.assertTrue(result)

        with self.assertRaises(ValueError) as context:
            self.grouping.is_member('cpe.cpeid', 'ZZ0000000004',
                                    group_super_test2_id)
        self.assertTrue("Cannot verify membership for " \
                "cpe.cpeid=ZZ0000000004 against group %d: " \
                "lazy filters cannot be resolved" %
                group_super_test2_id,
                str(context.exception))

        result = self.grouping.is_member(
            'cpe',
            'ZZ0000000004',
            group_super_test2_id,
            lazy_filter={'cpeid': 'ZZ0000000002'})
        self.assertTrue(result)

        result = self.grouping.is_member(
            'cpe.cpeid',
            'ZZ0000000001',
            group_super_test2_id,
            lazy_filter={'cpeid': 'ZZ0000000001'})
        self.assertTrue(result)

    def test_add_children(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cpeid', '=', 'ZZ0000000002'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')

        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['User.account_name', '=', 'user2'])
        group_definition = self.grouping.search_groups_by_name('test2')[0]
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'dynamic')

        group_test3_id = self.grouping.create_group(
            'test3', 'test group', 'test_user', 'lazy', ['cpe.cpeid'],
            ['cpe.cpeid', '=', '%(cpeid)s'])
        group_definition = self.grouping.search_groups_by_name('test3')[0]
        self.assertEqual(group_definition['name'], 'test3')
        self.assertEqual(group_definition['type'], 'lazy')

        group_test4_id = self.grouping.create_group(
            'test4', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cpeid', '=', 'blah'])
        group_definition = self.grouping.search_groups_by_name('test4')[0]
        self.assertEqual(group_definition['name'], 'test4')
        self.assertEqual(group_definition['type'], 'dynamic')

        group_super_test1_id = self.grouping.create_super_group(
            'super_test1', 'test group', 'test_user',
            [group_test1_id, group_test4_id])
        group_definition = self.grouping.search_groups_by_name('super_test1')[
            0]
        self.assertEqual(group_definition['name'], 'super_test1')
        self.assertEqual(group_definition['type'], 'super')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = ZZ0000000002", "UNION", "SELECT",
                "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`", "WHERE",
                "cpe.cpeid = blah"
            ]))
        children = self.grouping.get_children(group_super_test1_id)
        self.assertEqual(2, len(children))
        self.assertTrue(group_test1_id in children)
        self.assertTrue(group_test4_id in children)
        parents = self.grouping.get_parents(group_test1_id)
        self.assertEqual(1, len(parents))
        self.assertTrue(group_super_test1_id in parents)

        self.grouping.add_children(group_super_test1_id, 'test_user',
                                   [group_test2_id])
        group_definition = self.grouping.search_groups_by_name('super_test1')[
            0]
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = ZZ0000000002", "UNION", "SELECT",
                "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`", "WHERE",
                "cpe.cpeid = blah", "UNION", "SELECT", "cpe.cpeid", "FROM",
                "CPEManager_CPEs AS `cpe`",
                "INNER JOIN vss_USER_CPE_RELATION AS `UserCPERelation`",
                "ON cpe.cpeid = UserCPERelation.cpeid",
                "INNER JOIN vss_USER AS `User`",
                "ON UserCPERelation.userid = User.account_name", "WHERE",
                "User.account_name = user2"
            ]))
        children = self.grouping.get_children(group_super_test1_id)
        self.assertEqual(3, len(children))
        self.assertTrue(group_test1_id in children)
        self.assertTrue(group_test4_id in children)
        self.assertTrue(group_test2_id in children)
        parents = self.grouping.get_parents(group_test1_id)
        self.assertEqual(1, len(parents))
        self.assertTrue(group_super_test1_id in parents)
        parents = self.grouping.get_parents(group_test2_id)
        self.assertEqual(1, len(parents))
        self.assertTrue(group_super_test1_id in parents)

        group_super_test2_id = self.grouping.create_super_group(
            'super_test2', 'test group', 'test_user',
            [group_super_test1_id, group_test3_id])
        group_definition = self.grouping.search_groups_by_name('super_test2')[
            0]
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = %(cpeid)s", "UNION", "SELECT",
                "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`", "WHERE",
                "cpe.cpeid = ZZ0000000002", "UNION", "SELECT", "cpe.cpeid",
                "FROM", "CPEManager_CPEs AS `cpe`", "WHERE", "cpe.cpeid = blah",
                "UNION", "SELECT", "cpe.cpeid", "FROM",
                "CPEManager_CPEs AS `cpe`",
                "INNER JOIN vss_USER_CPE_RELATION AS `UserCPERelation`",
                "ON cpe.cpeid = UserCPERelation.cpeid",
                "INNER JOIN vss_USER AS `User`",
                "ON UserCPERelation.userid = User.account_name", "WHERE",
                "User.account_name = user2"
            ]))
        children = self.grouping.get_children(group_super_test2_id)
        self.assertEqual(2, len(children))
        self.assertTrue(group_super_test1_id in children)
        self.assertTrue(group_test3_id in children)
        parents = self.grouping.get_parents(group_super_test1_id)
        self.assertEqual(1, len(parents))
        self.assertTrue(group_super_test2_id in parents)
        parents = self.grouping.get_parents(group_test3_id)
        self.assertEqual(1, len(parents))
        self.assertTrue(group_super_test2_id in parents)

    def test_delete_children(self):
        # Create groups
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']
        group_test2_id = self.grouping.search_groups_by_name('test2')[0]['id']
        group_test3_id = self.grouping.search_groups_by_name('test3')[0]['id']
        group_super_test1_id = self.grouping.search_groups_by_name(
            'super_test1')[0]['id']
        group_super_test2_id = self.grouping.search_groups_by_name(
            'super_test2')[0]['id']

        with self.assertRaises(ValueError) as context:
            self.grouping.delete_children(group_test1_id, 'test_user',
                                          [group_test3_id])
        self.assertTrue("Cannot delete children from group %d: " \
                "Cannot delete children for non-super group %d" %
                (group_test1_id, group_test1_id),
                str(context.exception))

        with self.assertRaises(ValueError) as context:
            self.grouping.delete_children(group_super_test1_id, 'test_user',
                                          [group_test3_id])
        self.assertTrue("Cannot delete children from group %d: " \
                "Group is referenced by another group" % group_super_test1_id,
                str(context.exception))

        self.grouping.delete_children(
            group_super_test1_id, 'test_user', [group_test3_id], force=True)
        group_definition = self.grouping.search_groups_by_name('super_test1')[
            0]
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = ZZ0000000002", "UNION", "SELECT",
                "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "INNER JOIN vss_USER_CPE_RELATION AS `UserCPERelation`",
                "ON cpe.cpeid = UserCPERelation.cpeid",
                "INNER JOIN vss_USER AS `User`",
                "ON UserCPERelation.userid = User.account_name", "WHERE",
                "User.account_name = user2"
            ]))
        children = self.grouping.get_children(group_super_test1_id)
        self.assertEqual(2, len(children))
        self.assertTrue(group_test1_id in children)
        self.assertTrue(group_test2_id in children)
        parents = self.grouping.get_parents(group_test3_id)
        self.assertEqual(1, len(parents))
        self.assertTrue(group_super_test2_id in parents)

        self.grouping.delete_children(group_super_test2_id, 'test_user', [])
        group_definition = self.grouping.search_groups_by_name('super_test2')[
            0]
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = ZZ0000000002", "UNION", "SELECT",
                "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "INNER JOIN vss_USER_CPE_RELATION AS `UserCPERelation`",
                "ON cpe.cpeid = UserCPERelation.cpeid",
                "INNER JOIN vss_USER AS `User`",
                "ON UserCPERelation.userid = User.account_name", "WHERE",
                "User.account_name = user2", "UNION", "SELECT", "cpe.cpeid",
                "FROM", "CPEManager_CPEs AS `cpe`", "WHERE",
                "cpe.cpeid = %(cpeid)s"
            ]))
        children = self.grouping.get_children(group_super_test2_id)
        self.assertEqual(2, len(children))
        self.assertTrue(group_test3_id in children)
        self.assertTrue(group_super_test1_id in children)

        self.grouping.delete_children(group_super_test2_id, 'test_user',
                                      [group_super_test1_id])
        group_definition = self.grouping.search_groups_by_name('super_test2')[
            0]
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = %(cpeid)s"
            ]))
        children = self.grouping.get_children(group_super_test2_id)
        self.assertEqual(1, len(children))
        self.assertTrue(group_test3_id in children)
        self.assertFalse(group_super_test1_id in children)


class TestAXGroupingInternal(unittest2.TestCase):
    def setUp(self):
        prepare_data()
        self.grouping = Grouping(GroupTestSchema, engine)

    def tearDown(self):
        cleanup_data()

    def test_create_group(self):
        group_test1_id = self.grouping.create_group(
            'test1',
            'test group',
            'test_user',
            'dynamic', ['cpe.cpeid'], ['cpe.cpeid', '=', 'ZZ0000000001'],
            internal=True)
        self.grouping.get_group_by_id(group_test1_id)

        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'static', ['cpe.cpeid'],
            ['cpe.cpeid', '=', 'ZZ0000000001'])
        self.grouping.get_group_by_id(group_test2_id)

        groups = self.grouping.get_all_groups()
        self.assertEqual(1, len(groups))
        self.assertEqual('test2', groups[0]['name'])

        return {'test1': group_test1_id, 'test2': group_test2_id}

    def test_get_members(self):
        # Create groups
        groups = self.test_create_group()
        group_test1_id = groups['test1']

        members = self.grouping.get_group_members(
            group_test1_id, return_as='dict')
        self.assertEqual(1, len(members))
        self.assertEqual('ZZ0000000001', members[0]['cpe.cpeid'])
        self.assertEqual(1,
                         self.grouping.get_group_member_count(group_test1_id))

    def test_get_group_membership(self):
        # Create groups
        groups = self.test_create_group()
        group_test2_id = groups['test2']

        membership = self.grouping.get_group_membership('cpe.cpeid',
                                                        'ZZ0000000001')
        self.assertEqual(1, len(membership))
        self.assertEqual(group_test2_id, membership[0])

    def test_is_member(self):
        # Create groups
        groups = self.test_create_group()
        group_test1_id = groups['test1']

        self.grouping.is_member('cpe.cpeid', 'ZZ0000000001', group_test1_id)
