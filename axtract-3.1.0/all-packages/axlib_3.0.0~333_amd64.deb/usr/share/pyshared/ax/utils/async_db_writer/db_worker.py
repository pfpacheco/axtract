"""
Worker objects for async_writer.

These workers will send the given SQL requests asynchrounously to the db.
If a query fails to execute, it is retried once. If the retry fails, no further
attempts are made.

To instantiate a worker, use the create_worker() factory.

The BaseWorker is the base class for all DB workers. It contains no
functionality.

The PEP249Worker code assumes a db module that supports the DB API
specified in PEP-249. The db module must allow multiple threads to use
the module, i.e. module.threadsafety must at least be 1. One example is the
"MySQLdb" module.

"""
from ax.utils.logging import setup_logging_for_library

setup_logging_for_library("ax.utils.async_db_writer.db_worker")

def create_workers(queue, db_config, config):
    """Return BaseWorker instance(s) according to given parameters

    The $config parameter must be a dict.
    The $db_config contains configuration data for database connectivity. The
        format depends on the db_type you specify in $config.
    """
    logger = setup_logging_for_library("ax.utils.async_db_writer.db_worker")

    num_workers = config.get("num_workers", 1)
    db_type = config.get("db_type", "mysql")
    workers = []

    if db_type == "mysql":
        import MySQLdb
        for count in xrange(num_workers):
            worker = PEP249Worker(queue, db_config, db_module=MySQLdb)
            workers.append(worker)
        logger.info("Successfully created %s PEP249Worker instances",
                num_workers)
    elif db_type == "lazy":
        for count in xrange(num_workers):
            worker = DummyWorkerLazy(queue, db_config)
            workers.append(worker)
        logger.info("Successfully created %s DummyWorkerLazy instances",
                num_workers)
    elif db_type == "eager":
        for count in xrange(num_workers):
            worker = DummyWorkerEager(queue, db_config)
            workers.append(worker)
        logger.info("Successfully created %s DummyWorkerEager instances",
                num_workers)
    else:
        raise NotImplementedError(
                "db_type '%s' is unknown" % db_type)

    return workers


class BaseWorker(object):
    # Maximum time in seconds that the worker will block on internal stuff.
    # This determines how fast it can react to self.shutdown_requested.
    max_block_time = 1.0
    def __init__(self, query_queue, db_config, db_module=None):
        """
        query_queue: The queue from which queries are read.
        db_module: The module to use for building up a db
            connection.
        db_config: The db configuration to use.
        """
        # If this worker should stop its run() loop
        self.should_stop = False

        # The queue from which SQL queries are read
        self._query_queue = query_queue
        # The parameters needed to (re-)connect to the db.
        self._db_config = db_config
        self._db_module = db_module

        self.logger = setup_logging_for_library(
                "ax.utils.async_db_writer.db_worker")


    def run(self):
        """Starts the eternal loop of the worker

        This is intended to happen in a thread. The loop is aborted once
        self.should_stop evaluates True.
        """
        raise NotImplementedError

class DummyWorkerLazy(BaseWorker):
    """A worker module that does nothing, not even read from queue"""
    def run(self):
        import time
        while not self.should_stop:
            self.logger.debug("DummyWorkerLazy still doing nothing")
            time.sleep(self.max_block_time)
class DummyWorkerEager(BaseWorker):
    """A worker module that reads & discards everything from queue"""
    def run(self):
        while not self.should_stop:
            try:
                query = self._query_queue.get(True, self.max_block_time)
            except Exception:
                self.logger.debug("DummyWorkerEager got nothing from queue")
            else:
                self.logger.debug("DummyWorkerEager ignored this query: %s",
                        query)

class PEP249Worker(BaseWorker):
    """A worker for PEP-249 compliant database modules"""
    def __init__(self, query_queue, db_config, db_module=None):
        super(PEP249Worker, self).__init__(query_queue, db_config, db_module)
        self._connection = None
        self._cursor = None

    def _close(self):
        try:
            if self._cursor:
                self._cursor.close()
        except Exception:
            # TODO: count
            self.logger.exception("Failed to close DB cursor")
        finally:
            self._connection = None
        try:
            if self._connection:
                self._connection.close()
        except Exception:
            # TODO: count
            self.logger.exception("Failed to close DB connection")
        finally:
            self._connection = None

    def _reconnect(self):
        self._close()
        try:
            connection = self._db_module.connect(
                    **self._db_config)
            cursor = connection.cursor()
        except Exception:
            self._connection = None
            self._cursor = None
            self.logger.exception("Connecting to DB failed")
            raise
        else:
            self.logger.info("successfully connected to DB")
            self._connection = connection
            self._cursor = cursor


    def _ensure_connected(self):
        if not self._connection or not self._cursor:
            self._reconnect()
        self.logger.debug("db connectivity should be OK")

    def _attempt_query(self, query):
        """Attempt to execute the query, throw exception if it failed"""
        self._ensure_connected()
        self._cursor.execute(query)


    def run(self):
        count = 1
        while not self.should_stop:
            try:
                count += 1
                if count % 30 == 0:
                    self.logger.debug("Thread still running")
                # Get one query from queue
                try:
                    query = self._query_queue.get(True, self.max_block_time)
                    self.logger.debug("Got query from queue: %s", query)
                except Exception:
                    continue

                # First attempt.
                try:
                    self._attempt_query(query)
                except Exception:
                    # Query failed. Could be that our DB connection is broken.
                    self.logger.info("Query '%s' failed", query)
                    self._reconnect()
                else:
                    # Query was successful
                    self.logger.info("Query '%s' worked", query)
                    continue

                # Second (and last) attempt for this query.
                try:
                    self._attempt_query(query)
                except Exception:
                    # Query failed. Could be that our DB connection is broken.
                    self.logger.info("Query '%s' failed on second attempt", query)
                    self._reconnect()
                else:
                    self.logger.info("Query '%s' worked on second attempt", query)
            except Exception:
                # TODO: count
                self.logger.exception("Exception in main loop")

