#!/usr/bin/python -tt
import time
import unittest2
from ax.utils.blacklist import RatelimitBlacklist

class CallbackTestBlacklist(RatelimitBlacklist):
    """A blacklist that keeps track if certain callbacks were called

    To be used for unit testing.
    """
    def __init__(self, *args, **kwargs):
        self.log = {}
        # Decorate the following functions so that they will write to
        # self.log if they were called. For example self.foobar() will set
        # self.log['foobar'] to True when it is called.
        for name in ("get_itemid", "item_to_itemid", "get_tokenbucket",
                "get_block_duration", "get_track_duration", "notify_blocked",
                "update_blocked", "notify_explicit_unblock",
                "load_from_external", "open_external_connections"):
            logging_call = self.decorate_helper(name)
            old_func = getattr(self, name)
            decorated_func = logging_call(old_func)
            setattr(self, name, decorated_func)
            # Avoid index errors in Assertions.
            self.log[name] = False

        super(CallbackTestBlacklist, self).__init__(*args, **kwargs)

    def decorate_helper(self, name):
        # For internal Python reasons, this must be a separate function.
        def logging_call(decorated_method):
            def new_func(*args, **kwargs):
                # new_func is unbound, get the "self" reference from the method
                # we decorate, which is a bound method.
                decorated_method.im_self.log[name] = True
                return decorated_method(*args, **kwargs)
            return new_func
        return logging_call

class TestRatelimitBlacklist(unittest2.TestCase):
    def test_instantiate(self):
        RatelimitBlacklist(max_items=42, track_duration=43,
                block_duration=43, allowed_rate=45, allowed_burst=46)

    def test_auto_untrack(self):
        # track_duration seconds after the initial hit, we forget about items,
        # even if they have bugged us in the meantime.
        blacklist = RatelimitBlacklist(allowed_rate=100, track_duration=1)

        blacklist.count("foo")
        self.assertTrue(blacklist.get("foo"))

        time.sleep(0.5)
        self.assertTrue(blacklist.get("foo"))
        blacklist.count("foo")

        time.sleep(0.5)
        # Must not be tracked, even though it was counted 0.5 seconds ago.
        self.assertFalse(blacklist.get("foo"))

    def test_auto_block_unblock(self):
        blacklist = RatelimitBlacklist(allowed_rate=1, allowed_burst=1,
                max_items=1, block_duration=1)
        blacklist.count("foobar")
        self.assertFalse(blacklist.is_blocked("foobar"))
        # Now exceeding the allowed rate of 1 per second.
        blacklist.count("foobar")
        self.assertTrue(blacklist.is_blocked("foobar"))

        # pretend that the device keeps bugging us
        time.sleep(0.4)
        blacklist.count("foobar")
        time.sleep(0.4)
        blacklist.count("foobar")
        time.sleep(0.4)

        # At least 1.2 seconds have passed since the device was blocked. Must
        # be unblocked now so it has a chance of contacting us.
        self.assertFalse(blacklist.is_blocked("foobar"))

    def test_durations(self):
        """Blacklist with track_duration != block_duration"""
        # track_duration < block_duration
        blacklist = RatelimitBlacklist(allowed_rate=1, allowed_burst=1,
                max_items=2, track_duration=0.5, block_duration=1)
        blacklist.count("foo")
        blacklist.count("foo")
        blacklist.count("bar")
        # "foo" must be blocked, "bar" is being tracked but not blocked.
        self.assertTrue(blacklist.is_blocked("foo"))
        self.assertTrue(blacklist.get("bar"))
        self.assertFalse(blacklist.is_blocked("bar"))
        time.sleep(0.55)
        # "bar" is not tracked any more, because >0.5 seconds have passed.
        self.assertFalse(blacklist.get("bar"))
        # "foo" is still blocked, because blocking lasts for 1 second.
        self.assertTrue(blacklist.is_blocked("foo"))
        time.sleep(0.55)
        # Now, both must be untracked.
        self.assertFalse(blacklist.get("foo"))
        self.assertFalse(blacklist.get("bar"))

        # track_duration > block_duration
        blacklist = RatelimitBlacklist(allowed_rate=1, allowed_burst=1,
                max_items=2, track_duration=1, block_duration=0.5)
        blacklist.count("foo")
        blacklist.count("foo")
        blacklist.count("bar")
        # "foo" must be blocked, "bar" is being tracked but not blocked.
        self.assertTrue(blacklist.is_blocked("foo"))
        self.assertTrue(blacklist.get("bar"))
        self.assertFalse(blacklist.is_blocked("bar"))
        time.sleep(0.55)
        self.assertTrue(blacklist.get("bar"))
        # "foo" is not blocked, because blocking lasts for only 0.5 seconds.
        self.assertFalse(blacklist.is_blocked("foo"))
        # But "foo" should still be tracked.
        self.assertTrue(blacklist.get("foo"))
        time.sleep(0.55)
        # Now, both must be untracked since >1.1 seconds have passed.
        self.assertFalse(blacklist.get("foo"))
        self.assertFalse(blacklist.get("bar"))

    def test_explicit_block_unblock(self):
        blacklist = RatelimitBlacklist(allowed_rate=1, allowed_burst=1,
                max_items=1, block_duration=1)
        blacklist.block("foobar")
        self.assertTrue(blacklist.is_blocked("foobar"))
        blacklist.unblock("foobar")
        self.assertFalse(blacklist.is_blocked("foobar"))

    def xxx_test_performance(self):
        """Get some performance measurements"""
        start = time.time()
        # Track up to 1M items
        blacklist = RatelimitBlacklist(max_items=1000000, allowed_rate=1,
                allowed_burst=1)
        # Blacklist 100k items.
        for count in xrange(100000):
            item = str(count)
            # Create new entry. Quite expensive: new objects need to be created.
            blacklist.count(item)
            # Blacklist the entry by counting.
            blacklist.count(item)
            # Call count() on blacklisted entry
            blacklist.count(item)
        stop = time.time()
        print "Performance is ~%d count operations per second" % (
                300000 / (stop - start))

        start = time.time()
        # Unblacklist them again.
        for count in xrange(100000):
            item = str(count)
            blacklist.unblock(item)
        stop = time.time()
        print "Performance is ~%d unblock operations per second" % (
                100000 / (stop - start))

    def test_callbacks(self):
        """Check if callbacks are called when they should"""
        blacklist = CallbackTestBlacklist(allowed_rate=1, allowed_burst=1,
                max_items=1, block_duration=1)
        # These must be called by __init__ already
        self.assertTrue(blacklist.log['open_external_connections'])
        self.assertTrue(blacklist.log['load_from_external'])

        # Check by itemid
        self.assertFalse(blacklist.log['get_itemid'])
        blacklist.is_blocked_itemid("foobar")
        self.assertTrue(blacklist.log['get_itemid'])

        # Check by item: performs a item->itemid translation
        self.assertFalse(blacklist.log['item_to_itemid'])
        blacklist.is_blocked("foobar")
        self.assertTrue(blacklist.log['item_to_itemid'])

        # Create new entry
        self.assertFalse(blacklist.log['get_tokenbucket'])
        self.assertFalse(blacklist.log['get_track_duration'])
        blacklist.count("foobar")
        self.assertTrue(blacklist.log['get_tokenbucket'])
        self.assertTrue(blacklist.log['get_track_duration'])

        # Make the entry exceed the rate limit -> blacklisted
        self.assertFalse(blacklist.log['get_block_duration'])
        self.assertFalse(blacklist.log['notify_blocked'])
        blacklist.count("foobar")
        self.assertTrue(blacklist.log['get_block_duration'])
        self.assertTrue(blacklist.log['notify_blocked'])

        # Exceed again -> update_blocked must not be called.
        blacklist.count("foobar")
        self.assertFalse(blacklist.log['update_blocked'])

        # Explicitly block -> update_blocked must be called.
        self.assertFalse(blacklist.log['update_blocked'])
        blacklist.block("foobar")
        self.assertTrue(blacklist.log['update_blocked'])

        # Explicit unblock must also call a method
        self.assertFalse(blacklist.log['notify_explicit_unblock'])
        blacklist.unblock("foobar")
        self.assertTrue(blacklist.log['notify_explicit_unblock'])


if __name__ == "__main__":
    unittest2.main()
