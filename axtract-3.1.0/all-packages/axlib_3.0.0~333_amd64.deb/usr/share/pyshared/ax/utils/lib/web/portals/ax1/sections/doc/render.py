from ax1.django_tools import render_request
import yaml

SUBSECTS = yaml.load("""
- Layout
- Communication
- Framework
- Bootstrap:
  - CSS: ax_doc_official?p=css
  - Script: ax_doc_official?p=script
  - Components: ax_doc_official?p=components

""")

def get_subsections(context):
    return SUBSECTS


offi = {'css': 'official_base-css'}

def render_official(r, s, ctx, uri, app):
    tmpl = 'ax1/sections/doc/%s.html' % offi[r.form['p']]
    return render_request(r, tmpl, ctx)


def render_Layout(r, s, ctx, uri, app):
    tmpl = 'ax1/sections/doc/layout.html'
    return render_request(r, tmpl, ctx)


def render_Communication(r, s, ctx, uri, app):
    tmpl = 'ax1/sections/doc/main.html'
    return render_request(r, tmpl, ctx)


def render_Framework(r, s, ctx, uri, app):
    tmpl = 'ax1/sections/doc/main.html'
    return render_request(r, tmpl, ctx)

