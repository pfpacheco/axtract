"""
ax.utils.exceptions
~~~~~~~~~~~~~~~~~~~

This module defines a set of frequently used exceptions.

"""


class DataNotFoundException(Exception):
    def __init__(self, message):
        super(DataNotFoundException, self).__init__(message)


class InvalidInputException(ValueError):
    def __init__(self, message):
        super(InvalidInputException, self).__init__(message)


class InternalException(Exception):
    def __init__(self, message):
        super(InternalException, self).__init__(message)
