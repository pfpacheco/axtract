#include "Python.h"

/* This module was originally tested under python2.6.
 * In python2.4 the Py_ssize_t type does not exist,
 * see http://www.python.org/dev/peps/pep-0353/ for more details
 * The following snippet is taken from the PEP to backport Py_ssize_t
 */
#if PY_VERSION_HEX < 0x02050000 && !defined(PY_SSIZE_T_MIN)
typedef int Py_ssize_t;
#define PY_SSIZE_T_MAX INT_MAX
#define PY_SSIZE_T_MIN INT_MIN
#endif


int _recursive(PyObject * names, PyObject * to_add, PyObject * curr_node)
{
    PyObject *name, *value, *tmp;
    Py_ssize_t pos=0;
    if(PyDict_Check(curr_node))
    {
        while(PyDict_Next(curr_node, &pos, &name, &value))
        {
            PyList_Append(names, name);
            _recursive(names, to_add, value);
            PySequence_DelItem(names, PyList_Size(names)-1);
        }
    }
    else
    {
        tmp = _PyString_Join(PyString_FromString("."), names);
        PyDict_SetItem(to_add, tmp, curr_node);
        Py_DECREF(tmp);
    }
}

PyObject * tree_to_props(PyObject *p_self, PyObject *args)
{
    PyObject *tree, *props, *names;
    if(!PyArg_ParseTuple(args, "O!", &PyDict_Type, &tree))
        return NULL;
 
    props = PyDict_New();
    names = PyList_New(0);
    _recursive(names, props, tree);
    Py_DECREF(names);
    return props;
}

PyObject * props_to_tree(PyObject *p_self, PyObject *args)
{
    PyObject *name, *value, *props, *local, *tree, *tmp;
    Py_ssize_t pos = 0;


    int prev_start;
    int prev_stop;
    int cur_start;
    size_t index;
    char * raw_name;

    if(!PyArg_ParseTuple(args, "O!O", &PyDict_Type, &props, &tree))
        return NULL;
    
    while (PyDict_Next(props, &pos, &name, &value)) {
        local = tree;
        prev_start = -1;
        prev_stop = -1;
        cur_start = 0;
        raw_name = PyString_AsString(name);
        for(index=0; index<PyString_Size(name); index++)
        {
            if(raw_name[index] == '.')
            {
                if(prev_start != -1)
                {
                    tmp = PyString_FromStringAndSize(
                            (const char*)raw_name + prev_start,
                            prev_stop-prev_start);

                    local = PyObject_GetItem(local, tmp);
                    Py_DECREF(local);
                    Py_DECREF(tmp);
                }
                prev_start = cur_start;
                prev_stop = index;
                cur_start = index+1;
            }
        }
        if (prev_start != -1)
        {
            tmp = PyString_FromStringAndSize(
                        (const char*)raw_name+ prev_start,
                        prev_stop - prev_start);

            local = PyObject_GetItem(local, tmp);
            Py_DECREF(local);
            Py_DECREF(tmp);
        }
        tmp = PyString_FromStringAndSize(
                (const char*)raw_name+cur_start,
                PyString_Size(name) - cur_start);

        PyObject_SetItem(local, tmp, value);
        Py_DECREF(tmp);
    }
    Py_INCREF(tree);
    return tree;
}

static PyMethodDef props_to_tree_methods[] = {
    {"_props_to_tree", props_to_tree, METH_VARARGS, "Docu"},
    {"_tree_to_props", tree_to_props, METH_VARARGS, "Docu"},
    {NULL, NULL, 0, NULL}
};

void init_props_to_tree()
{
    Py_InitModule("ax.utils.props_to_tree._props_to_tree", props_to_tree_methods);
}
