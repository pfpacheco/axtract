"""
Type Conversion Tools.
=====================


Converters betweeen Yml - XML - nested tuples - OrderedDicts (odicts)

Json, normal unordered odicts are covered conveniently enough by the stdlib.

- All 4 types have the property of an order

- xml in this module is plain xml without a schema:
  That means conversion to xlm is LOSSY - you loose the type information,
  all bools and digits will be string.
  If you need schema aware conversions consider directly using the xmltodict
  module within here.

- for ..._to_xml we do not create the <?xml version=1.0> header by default

- the odict_to_... funcs take also normal dicts

- ordered dict types are called 'odict' in the functions

- nested tuples are called 'l', ('list type')
  since usually anyway required only for to json serialization, and json has no
  concept of tuples (that way we can transfer an order via json)
  json.dumps(odict_to_l(MyOrderedTuple))
  All such func have a as_list option, returning nested lists and not
  nested tuples

- base lib is Martin Blech's xmltodict, which we adapted to return our
  OrderedDict with Zope support plus deliver utf-8 str not unicode per default

- All keys and values are assumed to be 'simple' type, i.e. serializable by
  yaml.safe_dump

- It is common practice to convert sequences of equal keys into arrays like
  shown. This is also how Zope does it:

  >>> xml_to_odict('<p><a>1</a><b>2</b></p>')
  OrderedDict([('p', OrderedDict([('a', '1'), ('b', '2')]))])
  >>> xml_to_odict('<p><a>1</a><a>2</a></p>')
  OrderedDict([('p', OrderedDict([('a', ['1', '2'])]))])

"""

from xmltodict import unparse
from xmltodict import parse as _xml_to_odict
from yml import odict_to_safe_yaml, yaml_to_ordered_dict
from ax.utils.formatting.camel_snake import convert_keys as conv_keys


def convert_keys(struct, **kw):
    return conv_keys(struct, **kw)



def convert(struct, to):
    """
    Generic converter, autodetecting the structure type
    convert((('a', 'b'),), 'xml')
    """
    # more verbose alias:
    if to == 'tuples':
        to = 'l'
    frm = derive_type(struct)
    if frm == to:
        return struct
    converter = globals().get('%s_to_%s' % (frm, to))
    if not converter:
        raise Exception('Cannot convert: %s' % str(struct)[:600])
    return converter(struct)

def derive_type(struct):
    if not struct and not isinstance(struct, basestring):
        return None
    # works with dicts as well:
    if isinstance(struct, dict):
        return 'odict'
    if isinstance(struct, (tuple, list)):
        return 'l'
    # yaml or xml?
    if isinstance(struct, basestring):
        _s = struct.strip()
        if _s and _s[0] == '<':
            return 'xml'
        return 'yml'
    raise Exception('Cannot convert: %s' % str(struct)[:600])


# ------------------------------------------------------------------ xml_to_...
# using double conversions. build a scanner if double is too slow:
def xml_to_l(xml, as_list=0):
    return odict_to_l(xml_to_odict(xml), as_list=as_list)

def xml_to_yml(xml):
    return odict_to_yml(xml_to_odict(xml))

def xml_to_odict(xml):
    try:
        return _xml_to_odict(xml)
    except Exception, ex:
        return _xml_to_odict('<p_wrap>%s</p_wrap>' % xml)['p_wrap']


# ------------------------------------------------------------------ yml_to_...
def yml_to_odict(yml):
    return yaml_to_ordered_dict(yml)

def yml_to_xml(yml):
    return odict_to_xml(yml_to_odict(yml))

def yml_to_l(yml):
    return odict_to_l(yml_to_odict(yml))


# ---------------------------------------------------------------- odict_to_...
def odict_to_yml(m):
    return odict_to_safe_yaml(m)

def odict_to_xml(m, hir=0, full=0, strip_xml_tag=1, **kw):
    """ converts simple odicts w/o attrs.
        Opposite of xmltodict.parse

        For complex stuff we use:
        xmltodict.unparse(m, pretty=True, indent="    ")
        Force that with full=1

        We are 10 - 20 times faster than they.
        They mark attributes proprietary,
        -> converts only odicts from xml from them, 2 way.
    """
    def _odict_to_xml(m, hir=0):
        # fastmode, not xml aware:
        xml = []
        indent = hir * '  '
        for k, v in m.items():
            val = v
            sub_indent = br = ''
            if isinstance(v, (tuple, list)):
                # must add the key n times (sequence of equal keys)
                for item in v:
                    xml.append(_odict_to_xml({k: item}, hir=hir+1))
                continue
            elif isinstance(v, dict):
                sub_indent = '\n' + ('  ' * (hir + 1))
                br = '\n' + ('  ' * hir)
                val = _odict_to_xml(v, hir+1)
            xml.append('<%s>%s%s%s</%s>' % (k, sub_indent, val, br, k))
        return ('\n' + indent).join(xml)

    if kw or full:
        kw['pretty'] = kw.get('pretty', True)
        kw['indent'] = kw.get('indent', '  ')
        # full xml expat:
        res = unparse(m, **kw)
        if strip_xml_tag:
            res = res.split('\n', 1)[1]
    else:
        res = _odict_to_xml(m, 0)
        if not strip_xml_tag:
            res = '<?xml version="1.0" encoding="utf-8"?>\n%s' % res

    return res


def odict_to_l(m, as_list=0):
    """ odict to tuples """
    def _as_list(m):
        res = []
        if isinstance(m, (basestring, int, float, bool)):
            return m
        if isinstance(m, dict):
            for k, v in m.items():
                if isinstance(v, (list, tuple)):
                    res.extend([[k, _as_list(i)] for i in v])
                else:
                    res.append([k, _as_list(v)])
            return res
        return str(m)


    if as_list:
        return _as_list(m)
    res = ()
    if isinstance(m, (basestring, int, float, bool)):
        return m
    if isinstance(m, dict):
        for k, v in m.items():
            if isinstance(v, (list, tuple)):
                res += tuple([(k, odict_to_l(i)) for i in v],)
            else:
                res += ((k, odict_to_l(v)),)
        return res
    return str(m)



# -------------------------------------------------------------------- l_to_...
def l_to_xml(l, hir=0):
    if isinstance(l, (basestring, int, float, bool, type(None))):
            return l
    br = ''
    if len(l) == 2 and isinstance(l[0], (basestring, int, float, bool)):
        return '\n%s<%s>%s%s</%s>\n' % ('    ' * hir, l[0],
                l_to_xml(l[1], hir+1), br, l[0])
    xml = ''
    for s in l:
        xml += '\n%s<%s>%s%s</%s>\n' % ('    ' * hir, s[0],
                l_to_xml(s[1], hir+1), br, s[0])
    return xml


def l_to_odict(l):
    from ax.utils.ordereddict import OrderedDict
    if isinstance(l, (basestring, int, float, bool)):
        return l
    m = OrderedDict()
    haves = []
    for k, v in l:
        if k in m:
            if k in haves:
                m[k].append(l_to_odict(v))
            else:
                haves.append(k)
                m[k] = [m[k], l_to_odict(v)]
        else:
            m[k] = l_to_odict(v)
    return m



def l_to_yml(l):
    return odict_to_yml(l_to_odict(l))




if __name__ == '__main__':
    xml = '<a>True</a><a>true</a>'
    import pdb; pdb.set_trace()
    res =  convert(xml, 'odict')
    xml = '<a>1</a><a>2</a>'
    assert convert(convert(xml, 'l'), 'odict')['a'] == ['1', '2']

    def clean(x): return x.replace('\n', '').replace(' ', '')
    l = (('p', (('a', 1), ('a', '2'))),)
    d = {'p': {'a': [1, '2']}}
    od = l_to_odict(l)
    x = l_to_xml(l)
    xml_to_l(x)
    x2 = odict_to_xml(d)
    listed = odict_to_l(d, as_list=1)
    assert listed == [['p', [['a', 1], ['a', '2']]]]
    assert clean(x) == clean(x2) == clean('<p><a>1</a><a>2</a></p>')
    assert clean(odict_to_xml(l_to_odict(odict_to_l(d)))
            ) == clean(l_to_xml(l))
    import time
    x = odict_to_xml(d)
    y = odict_to_yml(d)
    assert clean(y) == clean("""
      p:
        a:
        - 1
        - '2'
    """)

    assert clean(x) == '<p><a>1</a><a>2</a></p>'

    xml = """<cmd>
       <serviceUserId>300081-attendant-00@300080.joina.swisscom.ch</serviceUserId>
    <submenuId>5345345</submenuId>
    <announcementSelection>Personal</announcementSelection>
    <audioFile>
        <name>balbalba3333</name>
        <mediaFileType>WAV</mediaFileType>
        <level>User</level>
    </audioFile>
    <enableLevelExtensionDialing>true</enableLevelExtensionDialing>
    <keyConfiguration>
        <key>0</key>
        <entry>
            <description>Empfang</description>
            <action>Transfer With Prompt</action>
            <phoneNumber>1234</phoneNumber>
        </entry>
    </keyConfiguration>
    <keyConfiguration>
        <key>1</key>
        <entry>
            <description>Lager</description>
            <action>Transfer Without Prompt</action>
            <phoneNumber>+41795678</phoneNumber>
        </entry>
    </keyConfiguration>
    <keyConfiguration>
        <key>9</key>
        <entry>
            <description>previous menu</description>
            <action>Return to Previous Menu</action>
        </entry>
    </keyConfiguration>
    </cmd>
    """
    y = xml_to_yml(xml)
    # only strings in the xml:
    Y = """
cmd:
  serviceUserId: 300081-attendant-00@300080.joina.swisscom.ch
  submenuId: '5345345'
  announcementSelection: Personal
  audioFile:
    name: balbalba3333
    mediaFileType: WAV
    level: User
  enableLevelExtensionDialing: 'true'
  keyConfiguration:
  - key: '0'
    entry:
      description: Empfang
      action: Transfer With Prompt
      phoneNumber: '1234'
  - key: '1'
    entry:
      description: Lager
      action: Transfer Without Prompt
      phoneNumber: '+41795678'
  - key: '9'
    entry:
      description: previous menu
      action: Return to Previous Menu
    """.strip()
    assert clean(convert(y, 'xml')) == clean(xml)
    assert y.strip() == Y
    assert clean(yml_to_xml(Y)) == clean(xml)
    assert odict_to_l(xml_to_odict(xml)) == xml_to_l(xml)
    d = xml_to_odict(xml)
    l = odict_to_l(d)
    assert clean(xml) == clean(l_to_xml(l))

    t1 = time.time()
    for i in xrange(100):
        s = odict_to_xml(d)
    print 'fastmode',  time.time() - t1
    t1 = time.time()
    for i in xrange(100):
        fs = odict_to_xml(d, full=1)
    print 'fullmode',  time.time() - t1
    assert clean(s) == clean(fs)

    X = yml_to_xml(
            xml_to_yml(
                odict_to_xml(
                    l_to_odict(
                        yml_to_l(
                            odict_to_yml(
                                xml_to_odict(
                                    l_to_xml(
                                        odict_to_l(
                                            yml_to_odict(
                                                l_to_yml(
                                                    xml_to_l(
                                                        xml))))))))))))
    assert(clean(X)) == clean(xml)

    # with numbers - no xml then:
    y += '  myint: 42\n  myfloat: 3.14'
    d = l_to_yml(odict_to_l(yml_to_odict(y)))
    assert d.strip() == y.strip()
    # one use case: serialize xml over json, with json structure on the wire:
    import json
    assert clean(l_to_xml(json.loads(json.dumps(xml_to_l(xml))))) == clean(xml)



