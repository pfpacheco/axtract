import unittest2
from ax.utils.consumer_producer import run

class TestRun(unittest2.TestCase):
    def test_run(self):
        x = range(100)
        def consumer(x):
            return x + 1
        def reduce(a, b):
            return a+b

        ret = run(x, consumer, 7, reduce, 0)
        ref = sum([x+1 for x in range(100)])
        self.assertEqual(ret, ref)
