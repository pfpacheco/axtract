import time
import thread
import contextlib

from .constants import KEY_SC_ID
from .constants import KEY_STEP
from .constants import KEY_STATUS
from .constants import KEY_METHOD_NAME
from .constants import KEY_INITARGS
from .constants import KEY_LAST_RESULT
from .constants import KEY_PARENT_ID
from .constants import KEY_LOCAL_STATE
from .constants import KEY_CREATION_TIME
from .constants import KEY_GLOBAL_STATE

from .constants import STATUS_READY
from .constants import STATUS_WAITING_FOR_RESULT
from .constants import STATUS_SUCCESS
from .constants import STATUS_FAILED

from .engine_hooks import EngineHooksInterface

_now = time.time


class StepEngine(object):
    def __init__(self, hooks, state=None):
        """Init the engine.

        hooks: Hooks for the protocol handler
        state: If given it contains the state from previous StepEngine execution
        """

        if not isinstance(hooks, EngineHooksInterface):
            raise Exception("hooks MUST implement the EngineHooksInterface")

        self._hooks = hooks

        # The 'scenarios' attribute keeps the state of the current scenarios.
        # Scenarios at the front/left have a higher prio than on the right.
        if state:
            self._global_state = state['global_state']
            self._scenarios = state['scenarios']
        else:
            self._global_state = {}
            self._scenarios = []

    def get_state(self):
        """Returns the current internal 'state'.

        Use the return value of this to instantiate StepEngine the next time you
        get a hit from the protocol handler.
        """
        return {
            'global_state': self._global_state,
            'scenarios': self._scenarios
        }

    def activate_scenario(self, method, initargs):
        """Adds a new scenario ready for execution."""

        # The scenario is added at the end of the state.
        # => ready scenarios before are called before.
        sc = self._gen_sc(method, initargs)
        self._scenarios.append(sc)

        return sc[KEY_SC_ID]

    def ensure_scenario(self, method, initargs):
        """Adds a scenario if no other with the same name is already active.

        If a new scenario was added return the scenario id.
        Otherwise None is returned.
        """

        for sc in self._scenarios:
            if sc[KEY_METHOD_NAME] == method and not self._is_sc_finished(sc):
                return

        return self.activate_scenario(method, initargs)

    def activate_next_step(self, sc_id, last_result, is_fault=False):
        """Wakes up a scenario in state 'wait_for_result'.

        If is_fault=True we have a 'protocol handler error'
        => Interaction with the device failed.
        => the next step is 'FAULT_<step>'

        KeyError is raised if no scenario with that id can be found.
        """

        found = False
        for sc in self._scenarios:
            if sc[KEY_SC_ID] == sc_id:
                found = True
                sc[KEY_STATUS] = STATUS_READY
                sc[KEY_LAST_RESULT] = last_result

                if is_fault:
                    sc[KEY_STEP] = "FAULT_%s" % sc[KEY_STEP]

        if not found:
            raise KeyError("No scenario with id (%s) found" % sc_id)

    def execute(self, **other_sc_args):
        """Do a single run of the step engine

        other_sc_args is given as keyword arguments to *every* scenario called.

        Executes steps until:
            * No scenario in state ready can be found.
              => execute returns None
            * A atomic scenario is triggered.
              => execute returns a dict with the following shape
              {
                KEY_SC_ID: <id of the scenario requesting the atomic call>
                KEY_METHOD_NAME: <name of the atomic scenario>
                KEY_INITARGS: <args for the atomic scenario>
              }
        """

        while True:
            sc = self._get_next_ready_sc()
            if not sc:
                return

            result = self._do_single_step(sc, other_sc_args)
            if result:
                return result

    # Here are some methods to manage finished scenarios on the state.
    def get_finished_scenarios(self):
        """Returns all the successful and failed scenarios. """

        return [sc for sc in self._scenarios if self._is_sc_finished(sc)]

    def remove_finished_scenarios(self):
        """Removes failed/successful scenarios from the state."""

        new_scenarios = []

        for sc in self._scenarios:
            if not self._is_sc_finished(sc):
                new_scenarios.append(sc)

        self._scenarios = new_scenarios

    def remove_scenarios_by_name(self, name):
        """Removes all scenarios + their children by methodname.

        Note: If a scenario matches the name, but is a CHILD scenario, it is not
        removed.
        """

        # Find all he ids which are considered for deletion.
        remove_ids = set()
        for sc in self._scenarios:
            if sc[KEY_METHOD_NAME] == name and not sc[KEY_PARENT_ID]:
                remove_ids.add(sc[KEY_SC_ID])
                for child in self._get_childs(sc, recursive=True):
                    remove_ids.add(child[KEY_SC_ID])

        # Keep the good ones.
        new_scenarios = []
        for sc in self._scenarios:
            if sc[KEY_SC_ID] not in remove_ids:
                new_scenarios.append(sc)

        self._scenarios = new_scenarios

    def clear_initargs(self, sc_names):
        """Clear initargs from *started* scenarios.

        Set the initargs of a scenario to None on the following conditions:
        - Name of the scenario is in 'sc_names'
        - step of the scenario is not 0 (=> should have been started)

        Why ? There are some scenarios which do not need the initargs for later
        steps. To avoid serialization of the initargs, this method can be used
        to set them to None after the first step has been executed.
        Use this for scenarios which expect very large initargs and where it is
        expensive to keep them.
        """

        for sc in self._scenarios:
            if sc[KEY_STEP] != 0 and sc[KEY_METHOD_NAME] in sc_names:
                sc[KEY_INITARGS] = None

    # Private methods. I use here 'sc' as a abbreviation for 'scenario'.
    def _do_single_step(self, sc, other_sc_args):
        try:
            sc_ret = self._call_sc(sc, other_sc_args)
        except Exception as error:
            self._hooks.handle_scenario_error(sc, error)

            parent = self._get_parent(sc)
            if parent:
                self._continue_parent(parent, error, as_fault=True)
                self._remove_sc(sc)
            else:
                # Stop the current scenario.
                sc[KEY_STATUS] = STATUS_FAILED
                sc[KEY_LAST_RESULT] = error
            return

        # Look at sc_ret to check if a new scenario is started.
        if self._is_sc_ret_child_trigger(sc_ret):
            next_step, sc_spec = sc_ret

            # Validate and sanitize sc_spec
            self._sanitize_sc_spec(sc, sc_spec)

            # Let the current scenario wait until the child/atomic is ready
            sc[KEY_STATUS] = STATUS_WAITING_FOR_RESULT
            sc[KEY_STEP] = next_step

            if self._hooks.is_atomic(sc_spec['method']):
                return {
                    KEY_SC_ID: sc[KEY_SC_ID],
                    KEY_METHOD_NAME: sc_spec['method'],
                    KEY_INITARGS: sc_spec['args']}
            else:
                # Add a new scenario on the _scenarios.
                self._scenarios.append(
                    self._gen_sc(
                        sc_spec['method'],
                        sc_spec['args'],
                        sc[KEY_SC_ID]))
        else:
            # Scenario is finished and the result can be used as lastResult for
            # the parent.
            parent = self._get_parent(sc)
            if parent:
                self._continue_parent(parent, sc_ret)
                self._remove_sc(sc)
            else:
                # Stop the current scenario and set the result
                sc[KEY_STATUS] = STATUS_SUCCESS
                sc[KEY_LAST_RESULT] = sc_ret

    def _continue_parent(self, parent, child_result, as_fault=False):
        # Activate the parent
        parent[KEY_STATUS] = STATUS_READY

        # Set the result from the children
        parent[KEY_LAST_RESULT] = child_result

        if as_fault:
            parent[KEY_STEP] = 'FAULT_%s' % parent[KEY_STEP]

    def _remove_sc(self, sc):
        for idx, ob in enumerate(self._scenarios):
            if ob[KEY_SC_ID] == sc[KEY_SC_ID]:
                del self._scenarios[idx]
                return

    def _gen_sc(self, method, initargs, parent_id=None):
        """Generates a new scenario state. """
        sc_id = self._hooks.gen_scenario_id(method, initargs, parent_id)

        return {
            KEY_SC_ID: sc_id,
            KEY_STEP: 0,
            KEY_STATUS: STATUS_READY,
            KEY_METHOD_NAME: method,
            KEY_INITARGS: initargs,
            KEY_LAST_RESULT: None,
            KEY_PARENT_ID: parent_id,
            KEY_LOCAL_STATE: {},
            KEY_GLOBAL_STATE: self._global_state,
            KEY_CREATION_TIME: _now()
        }

    def _call_sc(self, sc, other_sc_args):
        """Finally call the scenario."""
        sc_args = other_sc_args.copy()

        sc_args[KEY_STEP] = sc[KEY_STEP]
        sc_args[KEY_INITARGS] = sc[KEY_INITARGS]
        sc_args[KEY_LAST_RESULT] = sc[KEY_LAST_RESULT]

        # Search for the code to execute.
        script = self._hooks.lookup_method(sc[KEY_METHOD_NAME])

        # Ensure local and global state for the current thread.
        thread_id = thread.get_ident()
        _current_state['local'][thread_id] = sc[KEY_LOCAL_STATE]
        _current_state['global'][thread_id] = sc[KEY_GLOBAL_STATE]
        try:
            return script(**sc_args)
        finally:
            del _current_state['local'][thread_id]
            del _current_state['global'][thread_id]

    def _get_next_ready_sc(self):
        next_sc = None

        for sc in self._scenarios:
            if sc[KEY_STATUS] == STATUS_READY:
                if next_sc is None:
                    next_sc = sc

                # Prefer child scenarios.
                if sc[KEY_PARENT_ID]:
                    return sc

        # If there is no ready child scenario return the first ready one.
        return next_sc

    def _get_parent(self, child_sc):
        for sc in self._scenarios:
            if sc[KEY_SC_ID] == child_sc[KEY_PARENT_ID]:
                return sc

    def _get_childs(self, parent, recursive=False):
        childs = []
        for sc in self._scenarios:
            if sc[KEY_PARENT_ID] == parent[KEY_SC_ID]:
                childs.append(sc)

        if recursive:
            for child in list(childs):
                childs.extend(self._get_childs(child, recursive=True))

        return childs

    @staticmethod
    def _is_sc_ret_child_trigger(sc_ret):
        """Does the result of a scenario trigger a new child ?"""
        if isinstance(sc_ret, (tuple, list)):
            if len(sc_ret) == 2:
                if isinstance(sc_ret[0], (basestring, float, int, long)):
                    if isinstance(sc_ret[1], dict):
                        return True

        return False

    @staticmethod
    def _sanitize_sc_spec(sc, sc_spec):
        if 'method' not in sc_spec:
            msg = "This scenario (%s) triggers a child scenario via " \
                  "(%s) but the key 'method' is missing"

            raise Exception(msg % (sc[KEY_METHOD_NAME], sc_spec))

        if 'args' not in sc_spec:
            sc_spec['args'] = None

    @staticmethod
    def _is_sc_finished(sc):
        """Returns True if the scenario state indicates finished"""
        return sc[KEY_STATUS] in (STATUS_SUCCESS, STATUS_FAILED)

    # This methods are needed because engine hooks can return 'None' as logger.
    def _log_debug(self, *args, **kwargs):
        logger = self._hooks.logger
        if logger:
            logger.debug(*args, **kwargs)

    def _log_info(self, *args, **kwargs):
        logger = self._hooks.logger
        if logger:
            logger.info(*args, **kwargs)

    def _log_warning(self, *args, **kwargs):
        logger = self._hooks.logger
        if logger:
            logger.warning(*args, **kwargs)

    def _log_error(self, *args, **kwargs):
        logger = self._hooks.logger
        if logger:
            logger.error(*args, **kwargs)

    def _log_exception(self, *args, **kwargs):
        logger = self._hooks.logger
        if logger:
            logger.exception(*args, **kwargs)

    def _log_critical(self, *args, **kwargs):
        logger = self._hooks.logger
        if logger:
            logger.critical(*args, **kwargs)


# This will only work in threaded environments.
# As soon as you have greenlets the 'thread.get_ident()' is always the same.
# If two or more greenlets use the StepEngine in parallel race conditions are
# going to happen.
_current_state = {'global': {}, 'local': {}}


def get_local_state():
    return _current_state['local'][thread.get_ident()]


def get_global_state():
    return _current_state['global'][thread.get_ident()]
