"""Execute a function from a greenlet within a ordinary thread.

It is not ment for HIGH speed. For each call a
* socketpair
* thread is created.

If you need high speed go for the threadpool.
"""
import threading
import socket


# Make a class to support lazy import of gevent
class CallInThread(object):
    def __init__(self):
        import gevent.socket
        self.__make_green_socket = gevent.socket.socket

    def __call__(self, func, *args, **kwargs):
        parent, child = socket.socketpair()
        try:
            green_parent_sock = self.__make_green_socket(_sock=parent)
            t = threading.Thread(
                target=self.execute,
                args=(child, func, args, kwargs))
            t.daemon = True
            t.start()
            green_parent_sock.recv(1)
        finally:
            parent.close()
            child.close()

    @staticmethod
    def execute(child_sock, func, args, kwargs):
        try:
            func(*args, **kwargs)
        finally:
            child_sock.send('0')
