import os
# The config is loaded lazily, so that products (like Axtract) which dont have
# this file dont get an error at import time
_default_config = None


def get_axess_default_config():
    """
    returns a copy of the parsed confg file /etc/default/axess.
    A copy is returned, because the config MUST NOT be changed
    while running.
    Restart the ACS to activate changes
    """
    global _default_config
    if _default_config is None:
        _default_config = _parse_config()
    return _default_config.copy()


def _parse_config():
    #FIXME: We need global config file management, using templates
    # for now we provide the old mechanics, using /etc/deafult/axess:
    cfgfile = os.environ.get('AXESS_CONFIG', '/etc/default/axess')
    if not os.path.isfile(cfgfile):
        return {}

    fd = open(cfgfile)
    try:
        config = {}
        # inspect every line
        for line in fd:
            # do the strip becaus lines can end with '\n'
            # this strip also removes lines wich contains only '\t' or ' '
            line = line.strip()

            # continue at comment or empty lines:
            if not line or line.startswith("#"):
                continue

            try:
                key, value = line.split('=', 1)
            except:
                msg = "Error parsing config file: "
                msg += "expected 'key = value' but got '%s'"
                raise Exception(msg % line)
            # strip leading and trailing whitespaces:
            value = value.strip()
            # and quotes as well:
            if value.startswith('"') or value.startswith("'"):
                value = value[1:-1]
            config[key.strip()] = value
        return config
    finally:
        fd.close()


def get_cfg_val(key, default='', reload_cfg=None):
    """ we often need a value from the config file """
    c = _default_config
    if reload_cfg or not c:
        c = _parse_config()
    val = c.get(key, default)
    if isinstance(val, (str, unicode)):
        return val.strip()
    return val


def get_cfg_vals(key, default='', reload_cfg=None, ordered=0):
    """ we often need a list of values from a config key
    Note:
        Once we have a real config parser this call should except
        if the value is not list/set style:
    """
    c = _default_config
    if reload_cfg or not c:
        c = _parse_config()
    vals = c.get(key, default)
    l = [t.strip() for t in vals.split(',') if t.strip()]
    if ordered:
        return l
    # set does not guarantee an order !
    return set(l)


def get_cfg_val_map(key, default='', reload_cfg=None):
    """
    we often have map style configs (cfgkey="key1:var1, key2:var2")
    Note:
        Once we have a real config parser this call should except
        if the value is not dict style
    """
    ret = {}
    val = get_cfg_val(key, default, reload_cfg)
    if val:
        # parse like AllowReadFromScripts="FOO:/here/there, TMP:/tmp":
        for kv in val.split(','):
            k, v = kv.split(':', 1)
            ret[k.strip()] = v.strip()
    return ret


# Default ports for processes in this chroot from this:
PG = int(get_cfg_val('ProcessGroup', 0))
def get_process_group():
    return PG

DEF_PORTS = {'redis'     : 6379,
             'http_proxy': 8999,
             'sqlproxy'  : 4040,
             'sql'       : 3306}


def get_internal_svc_port(svc_name, default=0):
    """ deliver the port for service as reachable from internal hosts
    deliver 0 if service is not configured or known"""
    # forced in config?
    forced_port = get_cfg_val('INT_PORT_%s' % svc_name.upper())
    if forced_port:
        return int(forced_port)
    port = DEF_PORTS.get(svc_name) or default
    if port:
        port += (10000 * PG)
    return port

try:
    from Zope2.Startup.options import ZopeOptions
except Exception, ex:
    # no zope installation here -> no AXESS -> no problem.
    pass

def get_zope_conf(start_up_vars=None, c_path='/opt/axess/etc/zope.conf'):
    """ Full parsing of the zope.conf file in axess/etc/: """
    zopts = ZopeOptions()
    zopts.configfile = c_path
    zopts.load_schema()
    zopts.load_configfile()
    zopts.realize(args=start_up_vars)
    return zopts.configroot

zope_environ_is_set = False


def set_os_environ_from_zope_conf(start_up_vars=None):
    # start_up_vars given -> *don't* look at the sys.argv
    # vector for building the config.
    # (e.g. AXConfigurator start flags are not understood by the parser)
    global zope_environ_is_set
    # the parsing is expensive, don't do if already done:
    if zope_environ_is_set:
        return
    z_conf = get_zope_conf(start_up_vars)
    # this one we keep in the os.environ as well:
    os.environ['INSTANCEHOME'] = z_conf.instancehome
    zope_environ = z_conf.environment
    for k, v in zope_environ.items():
        os.environ[k] = v
    zope_environ_is_set = True

def get_chroot_name():
    if 'CHROOT' in os.environ:
        return str(os.environ['CHROOT'])

    if os.path.isfile('/etc/debian_chroot'):
        with open('/etc/debian_chroot') as fd:
            line = fd.readline().strip()
            line = line.replace("\[\e[0;32m\]", '')
            line = line.replace("\[\e[m\]", '')
            return line

    return 'Unknown'


_hosts = {}
def get_cluster_hosts(reload=0):
    """ deliver a map for INTERNAL cluster IPs, considering hosts
    sb01-sb09, db01, db02 and nb01-nb09, cm in /etc/hosts.
    We dont' use DNS !
    return like {<ip1>: ['db01', nb01], <ip2>: [sb01], ...}
    i.e. a list of matching hosts per IP address.
    """
    if _hosts and not reload:
        return _hosts.copy()
    # set up the ip to hostname map - using the conventional node names:
    # 9 hosts each should do the job for all setups in the next years (?)
    # we parse the hostfile, since we need local /etc/hosts definitions -
    # gethostbyname could result in stupid stuff (resolve everything DNS and so on)
    with open('/etc/hosts','r') as hf:
            f = hf.read()
    for line in f.split('\n'):
        try:
            line = line.replace('\t', ' ')
            ip, hosts = line.split(' ', 1)
            # is this an ip entry:
            if not len(ip.split('.')) == 4 or not ip.split('.')[0].isdigit():
                raise
        except:
            continue
        hosts = ' %s ' % hosts
        # TODO: one day we need more than 9:
        for i in range(0, 11):
            if i == 0:
                ns = 'db01'
                nn = 'db02'
            elif i == 10:
                ns = 'cm'
                nn = 'xxx'
            else:
                ns = 'sb0%s' % i
                nn = 'nb0%s' % i
            for k in [ns, nn]:
                if ' %s ' % k in hosts:
                    hosts_l = _hosts.get(ip, [])
                    hosts_l.append(k)
                    _hosts[ip] = hosts_l

    return _hosts.copy()


#print get_cluster_hosts()
