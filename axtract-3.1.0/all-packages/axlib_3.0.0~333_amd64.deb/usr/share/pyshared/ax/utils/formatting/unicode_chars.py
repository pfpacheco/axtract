# -*- coding: utf-8 -*-
class UCs:
    """ unicode characteres. type new ones in vi (insert mode) like:
        strg-v u 2500
    """
    # for table prettyfying:
    VU = "│"
    H  = "─"
    JUNC = "┼"

    NOTE  = "♩"
    NOTES = "♬"
    PIEK  = "♠"
    MARK  = "☀"
    SKULL = "☠"
    GOOD  = "☺"
    BAD   = "☹"
    # not curses complient, i. not in bpython:
    EMO_SMILE = "😀"


if __name__ == '__main__':
    print "─"
    for k in dir(UCs):
        print getattr(UCs, k)
