"""Module to handle time specifications in Vixie Cron Syntax

The CronTime class provides the functionality to handle cron time
specification, that means strings like "42 10 * * mon" that are used in
/etc/crontab to define when a cronjob should run. The module does not provide
any functionality to handle actual crontab files or interact with cron.

Functionality provided:
    - Parse a time specification like "42 10 * * mon", representing it as an
        object foo with properties like foo.minutes, foo.hours etc.
    - Check if a cron time specification matches a given datetime, i.e. if a
        cronjob would be run at that time.
    - Turn a (potentially modified) cron time specification into a
        - human readable form
        - cron readable form

As far as we can tell, this parser parses exactly like Vixie Cron, including
many odd corner cases.

For the forgetful people, the 5 fields of a cron time specification are

        minute              0-59
        hour                0-23
        day of month (DOM)  1-31
        month               1-12 or names
        day of week (DOW)   0-7 or names

Get the details from "man 5 crontab".
"""

from datetime import timedelta
from datetime import datetime

DOW_TO_NAME = {
        0 : "Sunday",
        1 : "Monday",
        2 : "Tuesday",
        3 : "Wednesday",
        4 : "Thursday",
        5 : "Friday",
        6 : "Saturday"
}
MONTH_TO_NAME = {
        1 : "January",
        2 : "February",
        3 : "March",
        4 : "April",
        5 : "May",
        6 : "June",
        7 : "July",
        8 : "August",
        9 : "September",
        10: "October",
        11: "November",
        12: "December"
}
DOW_NAME_TO_NUMBER = {
        "sun" : 0,
        "mon" : 1,
        "tue" : 2,
        "wed" : 3,
        "thu" : 4,
        "fri" : 5,
        "sat" : 6
}
MONTH_NAME_TO_NUMBER = {
        "jan" : 1,
        "feb" : 2,
        "mar" : 3,
        "apr" : 4,
        "may" : 5,
        "jun" : 6,
        "jul" : 7,
        "aug" : 8,
        "sep" : 9,
        "oct" : 10,
        "nov" : 11,
        "dec" : 12
}

class CronTime(object):
    """represent a single cron time specification

    A cron time specification is e.g. "5 0 * * *" to specify that something
    should be done every day at 00:05 am.
    Syntax and semantics should be the same as in the Vixie cron.
    """

    def __init__(self, cron_syntax=None):
        if cron_syntax is None:
            self.minutes = None
            self.hours = None
            self.dow = None
            self.month = None
            self.dom = None
            self.orig_string = None
        else:
            self.parse(cron_syntax)

    def __eq__(self, other):
        return (self.minutes == other.minutes and
                self.hours == other.hours and
                self.dow == other.dow and
                self.month == other.month and
                self.dom == other.dom)

    def __str__(self):
        return self.human_readable

    def __repr__(self):
        return self.__class__.__name__ + "('" + self.cron_readable + "')"

    def parse(self, cron_syntax):
        """this method is for parsing the cron fields
        """
        # here the cron string gets splitted in seperated fields and
        # gets appended to the cron_pos_list
        cron_pos_list = (cron_syntax.split())
        if len(cron_pos_list) != 5:
            raise Exception("Expected 5 fields, got %s instead!" %
                    len(cron_pos_list))

        self.minutes = self._parse_field(cron_pos_list[0], max_value=59)
        self.hours = self._parse_field(cron_pos_list[1], max_value=23)
        self.dom = self._parse_field(cron_pos_list[2], max_value=31,
                min_value=1)
        self.month = self._parse_field(cron_pos_list[3], is_month=True,
                max_value=12, min_value=1)
        self.dow = self._parse_day_of_week(cron_pos_list[4])
        self.orig_string = cron_syntax

    @property
    def human_readable(self):
        """Bring cronsyntax to human readable form"""
        humanreadable = ""
        # check if all minutes or only some minutes
        if len(self.minutes) == 60:
            humanreadable += "every minute"
        else:
            humanreadable += ("in minute " +
                    ", ".join(map(str, sorted(self.minutes))))
        # check if all hours or only some
        if len(self.hours) == 24:
            humanreadable += ", every hour"
        else:
            humanreadable += (", in hour " +
                    ", ".join(map(str, sorted(self.hours))))
        # check if all days or only one
        if len(self.dom) == 31:
            humanreadable += ", every day of month"
        else:
            humanreadable += (", on day " +
                    ", ".join(map(str, sorted(self.dom))))
        # check like above (special case: Months are posted in complete words)
        if len(self.month) == 12:
            humanreadable += ", every month, "
        else:
            humanreadable += ", in month "
            for one_month in sorted(self.month):
                humanreadable += MONTH_TO_NAME[one_month] + ", "
        # check like above (special case: Day of weeks are posted in complete
        # words
        if len(self.dow) == 7:
            humanreadable += "and every day of the week"
        else:
            humanreadable += "and on "
            dow = sorted(self.dow)
            for weekday in dow:
                if weekday == dow[-1]:
                    if len(dow) > 1:
                        # Multiple items, use "and" for the last one.
                        humanreadable += "and " + DOW_TO_NAME[weekday]
                    else:
                        # Only a single item, no "and" or commas needed.
                        humanreadable += DOW_TO_NAME[weekday]
                else:
                    humanreadable += DOW_TO_NAME[weekday] + ", "

        return humanreadable

    @property
    def cron_readable(self):
        """Return the current object as a cron-readable string.

        This is not necessarily the original string that was parsed. In most
        cases, for equivalent cron syntax this method returns identical
        strings. But border cases like "* * 30 jan,feb *" and "* * 30 jan *"
        will give different strings, even though they are equivalent.
        This function will cleverly use asterisks and ranges to shorten the
        output. But "*/2" for month will become 1,3,5,7,9,11.
        """
        return " ".join([
                self._collapse_ranges(self.minutes, 60),
                self._collapse_ranges(self.hours, 24),
                self._collapse_ranges(self.dom, 31),
                self._collapse_ranges(self.month, 12),
                self._collapse_ranges(self.dow, 7)])

    def runs_at(self, timestamp):
        """Return True if given timestamp matches this object, else False."""
        return self._check_if_execute(timestamp.timetuple())

    def runs_now(self):
        """Return True if this object matches current local time, else False."""
        return self._check_if_execute(datetime.now().timetuple())

    def _collapse_ranges(self, int_set, max_amount):
        """Turn integer set into cron readable string with collapsed ranges.

        Helper for self.cron_readable. Turns set([1,2,3,4,5,42]) into "1-5,42".
        The max_amount tells how many items may be in int_set. If int_set
        contains the maximum amount, "*" is returned.
        """
        def terminate_range(parts, first, last):
            """Helper that is used at when the end of a range was detected"""
            if first == last:
                # Range of length 1 -> single number
                parts.append(str(first))
            else:
                # A real range with multiple items.
                parts.append("%d-%d" % (first, last))

        if len(int_set) == max_amount:
            return "*"
        elif len(int_set) == 0:
            raise ValueError("Empty set was passed.")

        first = None
        last = None
        parts = []
        for number in sorted(int_set):
            if first is None:
                first = last = number
                continue
            if number == last + 1:
                # This continues our current range
                last = number
                continue
            # This does NOT continue the range. Abort current, start new range.
            terminate_range(parts, first, last)
            first = last = number
        terminate_range(parts, first, last)
        return ",".join(parts)

    def _check_if_execute(self, timetuple):
        """Return True if this CronTime matches, else False

        timetuple must be a time.timetuple, e.g. as returned by calling
        datetime.timetuple().
        Matching ignores seconds. E.g. if this object represents "42 12 * * *",
        this method returns True for all times between 12:42:00.0000 and
        12:42:59.9999.
        """

        if (timetuple.tm_min not in self.minutes or
                timetuple.tm_hour not in self.hours or
                timetuple.tm_mon not in self.month):
            # If one of these doesn't match, the job should not run.
            return False

        # datetime.timetuples have Mon == 0 but Cron uses Sun == 0 and
        # Mon == 1.
        weekday = timetuple.tm_wday + 1
        if weekday == 7:
            weekday = 0

        # The DOW and DOM restrictions are more complicated. In "man 5 crontab"
        # it says:
        #       Note: The day of a command's execution can be specified in the
        #           following two fields - 'day of month', and 'day of week'.
        #           If both fields are restricted (i.e., do not contain the "*"
        #           character), the  command  will be run when either field
        #           matches the current time.
        # Implicitly, this says that when only one of the fields is restricted,
        # then this restriction must be fulfilled. So there are three cases:
        #     - DOW and DOM are unrestricted --> always match
        #     - DOW and DOM are restricted --> match if one of them(!) matches
        #     - either DOW or DOM is restricted, but not both  --> match if
        #           the restricted field matches.
        if len(self.dow) == 7:
            # DOW is unrestricted, everything depends on DOM
            return timetuple.tm_mday in self.dom
        else:
            # DOW is restricted
            if len(self.dom) == 31:
                # DOM is unrestricted  --> DOW must match
                return weekday in self.dow
            else:
                # DOW and DOM are restricted --> match if one of them matches
                return (weekday in self.dow) or (timetuple.tm_mday in self.dom)

    def calc_next_run(self, now):
        """Returns a datetime obj when this CronTime will match next.

        Returns None if the next schedule is not within the next 366 days.
        NOTE: This method is *slow*, calling it on a high rate does not scale.
        """

        one_minute = timedelta(minutes=1)
        for _ in xrange(366 * 24 * 60):
            now += one_minute

            # cheap checks, no expensive conversion to 'timetuple' needed.
            if now.minute not in self.minutes:
                continue

            if now.hour not in self.hours:
                continue

            if now.month not in self.month:
                continue

            # Do the 'expensive' check.
            if self._check_if_execute(now.timetuple()):
                return now

        return None

    def _parse_day_of_week(self, dow_field):
        """Return the set of week days, specified by dow_field."""
        retval = self._parse_field(dow_field, is_dow=True, max_value=7)
        # Always represent Sunday with 0, never with 7.
        if 7 in retval:
            retval.remove(7)
            retval.add(0)
        return retval

    def _parse_field(self, cron_syntax, **kwargs):
        """Parse one of the 5 fields in a cron time specification

        This method splits by commas, parses the individual sub-fields and
        merges the results. Return value is a set(), e.g. for "1,3-5" you
        get set([1,3,4,5]).
        kwargs are passed down to subordinate methods and include "is_dow",
        "is_month", "min_value", and "max_value".
        """
        fields = cron_syntax.split(',')
        result = set()
        for field in fields:
            if not field:
                raise Exception("Empty field detected in '%s'." % cron_syntax)
            result |= self._parse_subfield(field, **kwargs)
        return result

    def _parse_asterisk(self, max_value=0, min_value=0, **kwargs):
        """Return a set of all values from min_value to max_value.

        kwargs are ignored.
        """
        return set(xrange(min_value, max_value + 1))

    def _parse_subfield(self, cron_syntax, **kwargs):
        """Parse a subfield that is produced _after_ splitting by commas.

        kwargs are passed down to subordinate methods and include "is_dow",
        "is_month", "min_value", and "max_value".
        """
        if cron_syntax == "*":
            return self._parse_asterisk(**kwargs)

        if "/" not in cron_syntax:
            return set(self._parse_range(cron_syntax, **kwargs))
        else:
            subfields = cron_syntax.split("/")
            if len(subfields) != 2:
                raise Exception("too many slashes")
            first, second = subfields
            if "-" in first and ("*" in second or second <= 0):
                raise Exception("Can't mix range with '0','*',or negative\
                numbers")
            #if type(first) == str and type(second) == int:
            #   raise Exception("Can't mix String and Integer in Range")
            if first == "*" and second == "*":
                raise Exception("Can't use Asterisk twice")
            if first == "*":
                first = self._parse_asterisk(**kwargs)
            else:
                first = set(self._parse_range(first, **kwargs))
            if second == "*":
                # Crazy stuff like 10/* is allowed in vixie cron, the second
                # part is ignored.
                return  first
            else:
                # Crazy stuff like 10/600 is allowed in vixie cron, for the
                # minute field. But parse_single_nummer would throw exception 
                try:
                    second = int(second)
                except Exception:
                    raise Exception("%s is not an integer" % second)
                helper_list = []
                for count in xrange(min(first), max(first) + 1, second):
                    helper_list.append(count)
                return set(helper_list)

    def _parse_range(self, cron_syntax, is_dow=False, **kwargs):
        """Parse what could be a range, return iterable of things in range

        kwargs are passed down to subordinate methods and include max_value,
        min_value, and is_month.
        """
        if "-" not in cron_syntax:
            # An ordinary number, not a range. Put it into a tuple.
            return (self._parse_single_number(cron_syntax, is_dow=is_dow,
                    **kwargs),)

        # This is really a range. Get both fields in lower-case.
        subfields = cron_syntax.split("-")
        if len(subfields) != 2:
            raise Exception("Range specification '%s'contains multiple '-'." %
                    cron_syntax)
        first, second = subfields
        first = first.lower()
        second = second.lower()

        # For the DOW field, "sun", "0", and "7" are equivalent according to
        # the cron manpage, but the following combinations are considered
        # invalid by Vixie cron version 4.2, release 37.9.1:
        #   7-sun
        #   7-0
        # Additionally, "sun-7" runs on every day. So internally, Vixie cron
        # treats "sun" as equivalent to "0". This also explains why Vixie cron
        # thinks "mon-sun" is invalid ("mon-sat" works fine) and why "sun-mon"
        # actually works (running on days 0 and 1).
        if is_dow:
            if first == "sun":
                first = "0"
            if second == "sun":
                second = "0"
            if second == "7":
                if first == "7":
                    # Special case "7-7", this works in Vixie cron.
                    return [0]
                # Otherwise, "7" is not different from "6".
                second = "6"
        first = self._parse_single_number(first, is_dow=is_dow, **kwargs)
        second = self._parse_single_number(second, is_dow=is_dow, **kwargs)
        if first <= second:
            return range(first, second + 1)
        else:
            raise Exception("Incorrect Range")

    def _parse_single_number(self, cron_syntax, is_month=False,
            is_dow=False, max_value=0, min_value=0):
        """Return integer representation of string $cron_syntax.

        Ranges and "/" signs are not allowed here, they are handled elsewhere.
        If is_month is True, month names like "Dec" are allowed.
        If is_dow is True, weekday names like "Wed" are allowed.
        max_value defines the highest valid value in $cron_syntax. If
        $cron_syntax is invalid an exception is thrown.

        example input:
            cron_syntax='Fri', max_value=7, is_month=False, is_dow=True
        example output:
            5
        """
        cron_syntax = cron_syntax.lower()
        if is_dow:
            if cron_syntax in DOW_NAME_TO_NUMBER:
                return DOW_NAME_TO_NUMBER[cron_syntax]
        if is_month:
            if cron_syntax in MONTH_NAME_TO_NUMBER:
                return MONTH_NAME_TO_NUMBER[cron_syntax]
        try:
            return_value = int(cron_syntax)
        except Exception:
            raise Exception("%s is not an integer" % cron_syntax)
        if min_value <= return_value <= max_value:
            return return_value
        else:
            raise Exception("value %s is not in allowed range (%s-%s)" % (
                return_value, min_value, max_value))

