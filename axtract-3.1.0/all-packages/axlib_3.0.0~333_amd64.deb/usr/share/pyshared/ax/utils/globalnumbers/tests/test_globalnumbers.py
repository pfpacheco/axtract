import time
import os
import stat
import unittest2
from ax.utils.globalnumbers import GlobalNumbers
from ax.utils.globalnumbers import destroy_resources
from ax.utils.globalnumbers import FakeGlobalNumbers
from ax.utils.globalnumbers import setup_global_numbers

FILENAME = "/tmp/bookkeepingfile"

class TestGlobalInts(unittest2.TestCase):
    def setUp(self):
        # This can happen if the previous test was aborted, e.g. with CTRL+C.
        if os.path.isfile(FILENAME):
            destroy_resources(FILENAME)
            os.unlink(FILENAME)

    def tearDown(self):
        if os.path.isfile(FILENAME):
            destroy_resources(FILENAME)
            os.unlink(FILENAME)

    def test_incrementor(self):
        gn = GlobalNumbers(FILENAME)

        inc1 = gn.build_incrementor('ns', 1)
        self.assertEqual(0, gn['ns'])

        inc1()
        self.assertEqual(1, gn['ns'])

        inc2 = gn.build_incrementor('ns', 2)
        self.assertEqual(1, gn['ns'])

        inc1()
        self.assertEqual(2, gn['ns'])

        inc2()
        self.assertEqual(4, gn['ns'])

        self.assertEqual('ns', inc1.namespace)
        self.assertEqual('ns', inc2.namespace)

        self.assertEqual(1, inc1.to_add)
        self.assertEqual(2, inc2.to_add)

    def test_init(self):
        GlobalNumbers(FILENAME)
        self.assertTrue(os.path.isfile(FILENAME))

    def test_get_empty_registry(self):
        gn = GlobalNumbers(FILENAME)
        self.assertEqual(gn.get_registry_data(), {})

    def test_get_registry_with_counters(self):
        gn = GlobalNumbers(FILENAME)
        gn.increment('foo', 1.0)
        gn.increment('bar', 1L)
        gn.increment('x', 1)

        data = gn.get_registry_data()

        self.assertEqual(data['foo'][0], "N/A")
        self.assertEqual(data['foo'][1], 'FLOAT_TYPE')
        self.assertEqual(data['foo'][2], 0)
        foo_val = data['foo'][3]


        self.assertEqual(data['bar'][0], "N/A")
        self.assertEqual(data['bar'][1], 'ULONG_TYPE')
        self.assertEqual(data['bar'][2], 8)
        bar_val = data['bar'][3]


        self.assertEqual(data['x'][0], "N/A")
        self.assertEqual(data['x'][1], 'UINT_TYPE')
        self.assertEqual(data['x'][2], 16)
        x_val = data['x'][3]


        gn.increment('foo', 1.12345)
        gn.increment('bar', 2**32)
        gn.increment('x', 1)

        data = gn.get_registry_data()

        self.assertAlmostEqual(data['foo'][3] - foo_val, 1.12345)
        self.assertEqual(data['bar'][3] - bar_val, 2**32)
        self.assertEqual(data['x'][3] - x_val, 1)


    def test_init_twice(self):
        GlobalNumbers(FILENAME)
        ret1 = os.stat(FILENAME)
        time.sleep(1)

        GlobalNumbers(FILENAME)
        ret2 = os.stat(FILENAME)

        self.assertEqual(ret1.st_ino, ret2.st_ino)

    def test_get_with_3_counter(self):
        gn = GlobalNumbers(FILENAME)
        gn.increment('foo', 1)
        gn.increment('bar', 1)
        gn.increment('x', 1)

        foo = gn.get('foo')
        bar = gn.get('bar')
        x = gn.get('x')

        gn.increment('foo', 3000)
        gn.increment('bar', 123456)
        gn.increment('x', 10000000)

        self.assertEqual(3000, gn.get('foo') - foo)
        self.assertEqual(123456, gn.get('bar') - bar)
        self.assertEqual(10000000, gn.get('x') - x)

    def test_too_big_namespace(self):
        gn = GlobalNumbers(FILENAME)
        gn.increment('x'*1024, 0)
        self.assertRaises(TypeError, gn.increment, 'x'*1025, 0)

    def test_with_wrong_filename(self):
        self.assertRaises(TypeError, GlobalNumbers)
        self.assertRaises(TypeError, GlobalNumbers, (None,))

    def test_auto_add(self):
        gn = GlobalNumbers(FILENAME)
        self.assertEqual(gn.increment('foo', 34), None)
        fd = open(FILENAME)
        try:
            self.assertEqual(fd.readline(), "foo N/A UINT_TYPE 0\n")
        finally:
            fd.close()

    def test_get(self):
        gn = GlobalNumbers(FILENAME)
        gn.increment('foo', 0)
        increased  = 100
        for x in range(100):
            old = gn.get('foo')
            gn.increment('foo', increased)
            self.assertEqual(gn.get('foo') - old, increased)

    def test_perf(self):
        start = time.time()
        gn = GlobalNumbers(FILENAME)
        gn.increment('foo', 0)
        counter = gn.get('foo')
        for _ in xrange(10**7):
            gn.increment('foo', 1)
        self.assertEqual(gn.get('foo') - counter, 10000000)

        # if it take smore then 10 secs something goes really wrong
        # normally it should take 4 sec
        duration = time.time() - start
        try:
            self.assertLess(duration, 10)
        except AssertionError:
            print self, 'takes longer then usual:', duration

    def test_long_minus_at_unsigned(self):
        gn = GlobalNumbers(FILENAME)
        gn.increment('x', 34L)
        self.assertRaises((TypeError, OverflowError), gn.increment, 'x', -1L)

    def test_int_minus_at_unsigned(self):
        gn = GlobalNumbers(FILENAME)
        gn.increment('x', 34)
        self.assertRaises((TypeError, OverflowError), gn.increment, 'x', -1)

    def test_float_minus(self):
        gn = GlobalNumbers(FILENAME)
        gn['x'] = 34.0
        gn.increment('x', -1)
        self.assertEqual(gn['x'], 33.0)
        gn.increment('x', -100)
        self.assertEqual(gn['x'], -67.0)


    def test_increment_wrong_value(self):
        gn = GlobalNumbers(FILENAME)
        self.assertRaises(TypeError, gn.increment, 'foo', [1,2])

    def test_space_in_namespace(self):
        gn = GlobalNumbers(FILENAME)
        self.assertRaises(TypeError, gn.increment, 'f f', 0)

    def test_reset_values(self):
        gn = GlobalNumbers(FILENAME)
        gn.increment('foo', 3L)
        gn.increment('bar', 6L)

        gn.reset_values()
        ref = {
            'foo': ('N/A', 'ULONG_TYPE', 0, 0),
            'bar': ('N/A', 'ULONG_TYPE', 8, 0)
        }

        self.assertEqual(ref, gn.get_registry_data())

    def test_set_value(self):
        gn = GlobalNumbers(FILENAME)
        self.assertIsNone(gn.set_value("namespace", 34))
        self.assertEqual(gn.get('namespace'), 34)

    def test_set_value_many(self):
        gn = GlobalNumbers(FILENAME)
        gn.set_value("n1", 34)
        gn.set_value("n2", 10)
        gn.set_value("n3", 10 ** 6)
        gn.set_value("n4", 1000)
        gn.set_value("n5", 40000)

        self.assertEqual(gn.get('n1'), 34)
        self.assertEqual(gn.get('n2'), 10)
        self.assertEqual(gn.get('n3'), 10 ** 6)
        self.assertEqual(gn.get('n4'), 1000)
        self.assertEqual(gn.get('n5'), 40000)

    def test_set_value_wrong_ns(self):
        gn = GlobalNumbers(FILENAME)
        with self.assertRaises(TypeError):
            gn.set_value([], 34)

    def test_set_value_float(self):
        gn = GlobalNumbers(FILENAME)
        gn.set_value('n1', 0.1)
        gn.set_value('n2', 1.01)

        self.assertEqual(gn.get('n1'), 0.1)
        self.assertEqual(gn.get('n2'), 1.01)

    def test_dict_access(self):
        gn = GlobalNumbers(FILENAME)
        gn.set_value('n1', 0.1)
        gn.set_value('n2', 1.01)
        gn.set_value('n3', 1L)

        self.assertEqual(gn['n1'], 0.1)
        self.assertEqual(gn['n2'], 1.01)
        self.assertEqual(gn['n3'], 1L)

    def test_dict_access_wrong_type(self):
        gn = GlobalNumbers(FILENAME)
        gn.set_value('n1', 0.1)

        with self.assertRaises(TypeError):
            gn[()]

    def test_set_with_dict_access(self):
        gn = GlobalNumbers(FILENAME)
        gn['n1'] = 0.1
        gn['n3'] = 100

        self.assertEqual(gn['n1'], 0.1)
        self.assertEqual(gn['n3'], 100)

    def test_set_with_dict_access_wrong_type(self):
        gn = GlobalNumbers(FILENAME)
        with self.assertRaises(TypeError):
            gn[()] = 1

    def test_dev_stuff_as_registry(self):
        with self.assertRaises(OSError):
             GlobalNumbers('/dev/zero')

        with self.assertRaises(OSError):
             GlobalNumbers('/dev/urandom')

        with self.assertRaises(OSError):
             GlobalNumbers('/dev/null')

    def test_ensure_int_type(self):
        gn = GlobalNumbers(FILENAME)
        gn.ensure_int_type('ns')
        gn.ensure_int_type('ns')

        ref = {'ns': ('N/A', 'INT_TYPE', 0, 0L)}
        self.assertEqual(ref, gn.get_registry_data())

    def test_ensure_int_type_but_float_there(self):
        gn = GlobalNumbers(FILENAME)
        gn['ns'] = 1.0
        with self.assertRaises(TypeError):
            gn.ensure_int_type('ns')


    def test_ensure_long_type(self):
        gn = GlobalNumbers(FILENAME)
        gn.ensure_long_type('ns')
        gn.ensure_long_type('ns')

        ref = {'ns': ('N/A', 'LONG_TYPE', 0, 0L)}
        self.assertEqual(ref, gn.get_registry_data())

    def test_increment_long_minus(self):
        gn = GlobalNumbers(FILENAME)
        gn.ensure_long_type('ns')
        gn.increment('ns', -1)

        self.assertEqual(gn['ns'], -1)

        gn.increment('ns', -10000)
        self.assertEqual(gn['ns'], -10001)

        gn.increment('ns', 11001)
        self.assertEqual(gn['ns'], 1000)

    def test_perm(self):
        GlobalNumbers(FILENAME)
        stat_res = os.stat(FILENAME)

        must_have_perms = (
            stat.S_IRUSR,
            stat.S_IWUSR,
            stat.S_IRGRP,
            stat.S_IWGRP,
            stat.S_IROTH,
            stat.S_IWOTH
        )

        for perm in must_have_perms:
            self.assertEqual(perm, stat_res.st_mode & perm)

        not_set_perms = (stat.S_IXUSR, stat.S_IXGRP, stat.S_IXOTH)
        for perm in not_set_perms:
            self.assertEqual(0, stat_res.st_mode & perm)

    def test_increment_and_fetch_int(self):
        gn = GlobalNumbers(FILENAME)
        gn.ensure_int_type('ns')
        gn.set_value('ns', 0)
        for x in xrange(1, 2**20):
            self.assertEqual(x, gn.increment_and_fetch('ns', 1))

    def test_increment_and_fetch_uint_overflow(self):
        gn = GlobalNumbers(FILENAME)
        gn.ensure_ulong_type('ns')
        overflow_val = 2 ** 64
        gn.set_value('ns', overflow_val - 2)

        self.assertEqual(overflow_val - 1, gn.increment_and_fetch('ns', 1))
        self.assertEqual(0, gn.increment_and_fetch('ns', 1))
        self.assertEqual(1, gn.increment_and_fetch('ns', 1))

    def test_setup(self):
        """Test the convenience function for setting up GlobalNumbers"""
        gn = setup_global_numbers(FILENAME,
                ensure_float=["my_float"],
                ensure_ulong=["my_ulong"])
        # Must be a proper GlobalNumbers instance, i.e. no fake.
        self.assertFalse(isinstance(gn, FakeGlobalNumbers))
        # my_float must really be a float
        self.assertEqual(type(gn.get("my_float")), float)
        # "my_ulong" must really be unsigned.
        self.assertRaises((TypeError, OverflowError), gn.increment, "my_ulong", -1)

    def test_failed_setup(self):
        """The convenience function must return a mock object if it fails"""
        gn = setup_global_numbers("/proc/this/does/not/exist")

        self.assertTrue(isinstance(gn, FakeGlobalNumbers))
        self.assertTrue(isinstance(gn, GlobalNumbers))

        # The operations on the fake GlobalNumbers object must not throw
        # exceptions, that's the whole point.
        gn.increment("foobar1", 42)
        self.assertEqual(gn.increment_and_fetch("foobar11", 42), 0)
        self.assertEqual(gn.get("foobar2"), 0)
        self.assertEqual(gn['foobar3'], 0)
        gn['foobar33'] = 42
        self.assertEqual(gn.get_registry_data(), {})
        gn.reset_values()
        gn.set_value("foobar4", 42)
        gn.ensure_int_type("asdf")
        gn.ensure_uint_type("asdf")
        gn.ensure_long_type("asdf")
        gn.ensure_ulong_type("asdf")
        gn.ensure_float_type("asdf")

    def test_del(self):
        gn = GlobalNumbers(FILENAME)
        with self.assertRaises(NotImplementedError):
            del gn['a']

    def test_init_with_ns_prefix(self):
        gn = GlobalNumbers(FILENAME, 'ns_prefix')
        self.assertTrue(os.path.isfile(FILENAME))
        self.assertEqual('ns_prefix', gn.ns_prefix)

    def test_init_without_ns_prefix(self):
        gn = GlobalNumbers(FILENAME)
        self.assertTrue(os.path.isfile(FILENAME))
        self.assertIsNone(gn.ns_prefix)

        gn = GlobalNumbers(FILENAME, '')
        self.assertIsNone(gn.ns_prefix)


    def test_ns_prefix_is_read_only(self):
        gn = GlobalNumbers(FILENAME)
        with self.assertRaises(TypeError):
            gn.ns_prefix = 'a'

        with self.assertRaises(TypeError):
            del gn.ns_prefix

    def test_increment_with_prefix(self):
        gn = GlobalNumbers(FILENAME, 'ns_prefix.')
        gn.increment('a', 1)
        gn.increment('a', 10)
        gn.increment('b', 2)

        ret = gn.get_registry_data()
        # Filter the offset, because it differs between 32/64 bit
        for key, value in ret.items():
            ret[key] = (value[0], value[1], value[3])

        ref = {
            'ns_prefix.a': ('N/A', 'UINT_TYPE', 11L),
            'ns_prefix.b': ('N/A', 'UINT_TYPE', 2L)
        }
        self.assertEqual(ref, ret)

    def test_increment_and_fetch_with_prefix(self):
        gn = GlobalNumbers(FILENAME, 'ns_prefix.')
        self.assertEqual(1, gn.increment_and_fetch('a', 1))
        self.assertEqual(3, gn.increment_and_fetch('a', 2))

        ret = gn.get_registry_data()
        ref = {'ns_prefix.a': ('N/A', 'UINT_TYPE', 0, 3L)}
        self.assertEqual(ref, ret)

    def test_set_with_prefix(self):
        gn = GlobalNumbers(FILENAME, 'ns_prefix.')
        gn.set_value('a', 10)
        gn['b'] = 20

        ret = gn.get_registry_data()
        # Filter the offset, because it differs between 32/64 bit
        for key, value in ret.items():
            ret[key] = (value[0], value[1], value[3])

        ref = {
            'ns_prefix.a': ('N/A', 'UINT_TYPE', 10L),
            'ns_prefix.b': ('N/A', 'UINT_TYPE', 20L)
        }
        self.assertEqual(ref, ret)


    def test_get_with_prefix(self):
        gn = GlobalNumbers(FILENAME, 'ns_prefix.')
        gn['b'] = 20

        self.assertEqual(20, gn['b'])
        self.assertEqual(20, gn.get('b'))

    def test_ensures_with_ns(self):
        gn = GlobalNumbers(FILENAME, 'ns_prefix.')
        gn.ensure_int_type('a')
        gn.ensure_uint_type('b')
        gn.ensure_long_type('c')
        gn.ensure_ulong_type('d')
        gn.ensure_float_type('e')
        ret = gn.get_registry_data()
        # Filter the offset, because it differs between 32/64 bit
        for key, value in ret.items():
            ret[key] = (value[0], value[1], value[3])
        ref = {
            'ns_prefix.a': ('N/A', 'INT_TYPE', 0L),
            'ns_prefix.b': ('N/A', 'UINT_TYPE', 0L),
            'ns_prefix.c': ('N/A', 'LONG_TYPE', 0L),
            'ns_prefix.d': ('N/A', 'ULONG_TYPE', 0L),
            'ns_prefix.e': ('N/A', 'FLOAT_TYPE', 0.0)
        }
        self.assertEqual(ref, ret)

    def test_decrement_int(self):
        gn = GlobalNumbers(FILENAME)
        gn.ensure_int_type('a')
        gn['a'] = 1

        gn.decrement('a', 1)
        self.assertEqual(0, gn['a'])

        gn.decrement('a', 1)
        self.assertEqual(-1, gn['a'])

        gn.decrement('a', 2**25)
        self.assertEqual(-33554433, gn['a'])

        gn['a'] = 300
        gn.decrement('a', 299)
        self.assertEqual(1, gn['a'])

    def test_decrement_uint(self):
        gn = GlobalNumbers(FILENAME)
        gn.ensure_uint_type('a')
        gn['a'] = 100

        gn.decrement('a', 1)
        self.assertEqual(gn['a'], 99)

        gn['a'] = 0
        gn.decrement('a', 1)
        self.assertTrue(gn['a'] > 0)

    def test_decrement_long(self):
        gn = GlobalNumbers(FILENAME)
        gn.ensure_long_type('a')
        gn['a'] = 1

        gn.decrement('a', 1)
        self.assertEqual(0, gn['a'])

        gn.decrement('a', 1)
        self.assertEqual(-1, gn['a'])

        gn.decrement('a', 2**25)
        self.assertEqual(-33554433, gn['a'])

        gn['a'] = 300
        gn.decrement('a', 299)
        self.assertEqual(1, gn['a'])

    def test_decrement_ulong(self):
        gn = GlobalNumbers(FILENAME)
        gn.ensure_ulong_type('a')
        gn['a'] = 100

        gn.decrement('a', 1)
        self.assertEqual(gn['a'], 99)

        gn['a'] = 0
        gn.decrement('a', 1)
        self.assertTrue(gn['a'] > 0)

    def test_decrement_double(self):
        gn = GlobalNumbers(FILENAME)
        gn.ensure_float_type('a')
        gn['a'] = 34.20

        gn.decrement('a', 0.2)
        self.assertEqual(34, gn['a'])

    def test_decrement_and_fetch_int(self):
        gn = GlobalNumbers(FILENAME)
        gn.ensure_int_type('a')
        gn['a'] = 0

        ret = gn.decrement_and_fetch('a', 1)
        self.assertEqual(-1, ret)

    def test_decrement_and_fetch_uint(self):
        gn = GlobalNumbers(FILENAME)
        gn.ensure_uint_type('a')
        gn['a'] = 0

        ret = gn.decrement_and_fetch('a', 1)
        self.assertTrue(ret > 0)

    def test_decrement_and_fetch_long(self):
        gn = GlobalNumbers(FILENAME)
        gn.ensure_long_type('a')
        gn['a'] = 0

        ret = gn.decrement_and_fetch('a', 1)
        self.assertTrue(ret < 0)

    def test_decrement_and_fetch_ulong(self):
        gn = GlobalNumbers(FILENAME)
        gn.ensure_ulong_type('a')
        gn['a'] = 0

        ret = gn.decrement_and_fetch('a', 1)
        self.assertTrue(ret > 0)

    def test_decrement_and_fetch_double(self):
        gn = GlobalNumbers(FILENAME)
        gn.ensure_float_type('a')
        gn['a'] = 32.5

        ret = gn.decrement_and_fetch('a', 0.5)
        self.assertEqual(32.0, ret)
