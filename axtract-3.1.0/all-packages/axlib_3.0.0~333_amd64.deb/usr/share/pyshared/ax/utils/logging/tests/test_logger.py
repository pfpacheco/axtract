#!/usr/bin/python -tt

import logging
import os
import shutil
import socket
import sys
import tempfile
import threading
import time
import traceback
import unittest2

from multiprocessing import Process
from stat import ST_DEV, ST_INO

from ax.utils.logging.handlers import WatchedFileHandler as WFH
# Python's own version, which fails test_logrotate() after <0.5 seconds.
#from logging.handlers import WatchedFileHandler as WFH

from ax.utils.logging.handlers import WatchedRotatingFileHandler as WRFH
# Python's own version, which fails test_concurrent_auto_rotate()
#from logging.handlers import RotatingFileHandler as WRFH

from ax.utils.logging.handlers import AxploreHandler as AH


class LoggingTestCase(unittest2.TestCase):
    # The logger class we are testing.
    logger_class = None
    logger_name_count = 0
    # Where to direct stderr of child processes
    tmp_stderr = None

    def setUp(self):
        """Set up temporary directory for logging operations"""
        self.log_dir = tempfile.mkdtemp()
        self.log_file = self.log_dir + "/wfh.log"

    def tearDown(self):
        """Clean up temporary directory created by setUp()"""
        shutil.rmtree(self.log_dir)
        self.tmp_stderr = None

    def _assert_same_file(self, statinfo_1, statinfo_2):
        """Given two outputs of os.stat() asserts these are the same files"""
        self.assertEqual(statinfo_1[ST_DEV], statinfo_2[ST_DEV])
        self.assertEqual(statinfo_1[ST_INO], statinfo_2[ST_INO])

    def _assert_different_file(self, statinfo_1, statinfo_2):
        """Given two outputs of os.stat() asserts these are different files"""
        self.assertTrue(
                statinfo_1[ST_DEV] != statinfo_2[ST_DEV] or
                statinfo_1[ST_INO] != statinfo_2[ST_INO])

    def do_fake_logrotation(self):
        """Perform fake log rotations on self.log_file

        This code will run in a separate process until SIGTERM is received.
        On a machine with 2 or more CPU cores, that means we get true
        parallelism.
        """
        # print "will do many logrotations pid=%s" % os.getpid()
        while True:
            try:
                os.unlink(self.log_file)
            except OSError:
                pass
            try:
                fd = os.open(self.log_file, os.O_CREAT)
                os.close(fd)
            except OSError:
                pass

    def do_broken_logrotation(self):
        """Perform broken log rotations similar to what "logrotate" command does

        Same as self.do_fake_logrotation(), but for a short moment, the log file
        becomes inaccessible. In the real logrotate, this happens when you use
        the "create" option (active by default) in combination with a daemon
        that runs unpriviliged. Logrotate creates the file as root with chmod
        600, and _then_ changes the ownership to the unprivileged user. So for a
        short moment, the daemon is not able to open the log file. This is
        simulated with a symlink to "/does/not/exist", which is a directory so
        open() fails.
        See AXOS-273 for details.
        """
        # print "will do many logrotations pid=%s" % os.getpid()
        while True:
            try:
                os.unlink(self.log_file)
            except OSError:
                pass
            try:
                os.symlink("/does/not/exist", self.log_file)
                # On single core system, give other processes a chance to run.
                # This increases the chances of hitting the race condition.
                time.sleep(0)
                os.unlink(self.log_file)
                fd = os.open(self.log_file, os.O_CREAT)
                os.close(fd)
            except OSError:
                pass

    def do_many_log_operations(self, amount, **kwargs):
        """Perform $amount many logging operations

        Any kwargs will be passed to the handler.
        """
        if self.tmp_stderr is not None:
            sys.stderr = self.tmp_stderr

        # print "will do many log operations. pid=%s" % os.getpid()
        try:
            self.logger_name_count += 1
            logger = logging.getLogger('MyLogger%s' % self.logger_name_count)
            logger.setLevel(logging.DEBUG)
            # self.logger_class must be set by subclasses.
            handler = self.logger_class(self.log_file, **kwargs)
            logger.addHandler(handler)
            for i in xrange(amount):
                logger.debug("hello, world")
        except KeyboardInterrupt:
            # That's OK, we were terminated by CTRL+C (=SIGINT)
            # print "terminating gracefully"
            sys.exit(0)
        except BaseException:
            traceback.print_exc()
            sys.exit(42)

    def do_threaded_log_operations(self, amount, num_threads):
        """Perform $amount log operations in $num_threads threads"""
        def _threaded_helper(logger, amount):
            for count in xrange(amount):
                logger.warn("The answer is: %s", 42)
                logger.debug("Another message")

        # print "starting worker threads..."
        logger = logging.getLogger('ThreadedLogger')
        logger.setLevel(logging.INFO)
        handler = WFH(self.log_file)
        logger.addHandler(handler)

        threads = []
        for thread_count in range(num_threads):
            thread = threading.Thread(target=_threaded_helper,
                    args=(logger, amount / num_threads))
            thread.daemon = True
            thread.start()
            threads.append(thread)

        for thread in threads:
            thread.join()
        # print "all worker threads terminated"

class TestWatchedFileHandler(LoggingTestCase):
    logger_class = WFH


    def test_logrotate(self):
        """Check if the logger survives log rotation"""
        process1 = Process(target=self.do_fake_logrotation)
        process2 = Process(target=self.do_many_log_operations, args=(20000,))
        try:
            process1.start()
            process2.start()
            process2.join()
            self.assertEqual(process2.exitcode, 0)
        finally:
            process1.terminate()

    def test_broken_logrotate(self):
        """Check if the logger survives an incorrect logrotate

        See docstring of do_broken_logrotation() for details.
        """
        process1 = Process(target=self.do_broken_logrotation)
        process2 = Process(target=self.do_many_log_operations, args=(20000,))
        try:
            process2.start()
            # Give process2 a head start: Creating the logger still relies on
            # opening the log file correctly at the beginning.
            while not os.path.exists(self.log_file):
                time.sleep(0.01)
            process1.start()
            process2.join()
            self.assertEqual(process2.exitcode, 0)
        finally:
            process1.terminate()

    def test_broken_logrotate_message(self):
        """Broken log rotation must create log entries that warn about this"""
        logger = logging.getLogger("")
        logger.setLevel(logging.DEBUG)
        handler = self.logger_class(self.log_file)
        logger.addHandler(handler)

        logger.warn("Hello world")
        handler.flush()

        # Pretend log rotation
        os.rename(self.log_file, self.log_dir + "/renamed.log")
        # Make sure the log file cannot be re-opened by the handler.
        # Symlinking to "/" does not do the job, the kernel of Squeeze will
        # implicitly create "/wfh.log", only later kernels cause exceptions.
        os.symlink(self.log_dir + "/does/not/exist", self.log_file)

        logger.warn("Hello again")
        # Ensure that libc has flushed the buffers of the log stream.
        handler.flush()

        data = open(self.log_dir + "/renamed.log", "r").read()
        self.assert_("Error opening log file" in data)
        self.assert_("Hello again" in data)

    def test_threaded_logrotate(self):
        """Log rotation when multiple threads are logging on same handler"""
        process1 = Process(target=self.do_fake_logrotation)
        process2 = Process(target=self.do_threaded_log_operations,
                args=(50000, 3))
        try:
            process1.start()
            process2.start()
            process2.join()
        finally:
            process1.terminate()


class TestWatchedRotatingFileHandler(TestWatchedFileHandler):
    logger_class = WRFH

    def test_auto_rotate(self):
        """WRFH must rotate by itself if nobody else does it"""
        logger = logging.getLogger('test_auto_rotate')
        logger.setLevel(logging.DEBUG)
        handler = self.logger_class(self.log_file, maxBytes=1000, backupCount=1)
        logger.addHandler(handler)

        # Will be ten bytes when logger adds newline
        nine_bytes = "123456789"
        for i in range(99):
            logger.debug(nine_bytes)

        # The first backup must not yet exist, log file should have 990 bytes
        # +/- a few bytes due to buffering.
        self.assertRaises(OSError, os.stat, self.log_file + ".1")
        first_statinfo = os.stat(self.log_file)

        logger.debug(nine_bytes)
        logger.debug(nine_bytes)
        logger.debug(nine_bytes)

        # Now a rollover should have happened
        second_statinfo = os.stat(self.log_file + ".1")
        # The ".1" file must be the old log file
        self._assert_same_file(first_statinfo, second_statinfo)
        # The ".1" file must not be the current file
        third_statinfo = os.stat(self.log_file)
        self._assert_different_file(third_statinfo, second_statinfo)

        # More logging must not create more backup files than configured.
        for i in range(111):
            logger.debug(nine_bytes)
        self.assertRaises(OSError, os.stat, self.log_file + ".2")

        # Log file should have been rotated yet another time
        fourth_statinfo = os.stat(self.log_file)
        self._assert_different_file(fourth_statinfo, third_statinfo)

        # ".lock" file must be cleaned up
        self.assertRaises(OSError, os.stat, self.log_file + ".lock")

        # Otherwise there is trouble when this test is run twice: The temporary
        # directory for logging does not exist any more.
        logger.removeHandler(handler)

    def test_concurrent_auto_rotate(self):
        """Auto rotate must work with multiple processes logging to same file"""

        # logging.handleError() will swallow exception, but print backtraces
        # on stderr, which we check for.
        self.tmp_stderr = tempfile.NamedTemporaryFile()
        process1 = Process(target=self.do_many_log_operations,
                args=(1000,), kwargs={'maxBytes': 100, 'backupCount': 20})
        process2 = Process(target=self.do_many_log_operations,
                args=(1000,), kwargs={'maxBytes': 100, 'backupCount': 20})
        process3 = Process(target=self.do_many_log_operations,
                args=(1000,), kwargs={'maxBytes': 100, 'backupCount': 20})
        try:
            process1.start()
            process2.start()
            process3.start()
        finally:
            process1.join()
            process2.join()
            process3.join()

        # We must have backups 1 through 20
        for count in range(1, 21):
            os.stat(self.log_file + "." + str(count))
        # And of course the actual log file
        os.stat(self.log_file)
        # ".lock" file must be cleaned up
        self.assertRaises(OSError, os.stat, self.log_file + ".lock")

        # Check for exception backtraces on STDERR
        stderr = open(self.tmp_stderr.name, "r")
        stderr_data = stderr.read()

        self.assert_("exception" not in stderr_data)
        self.assert_("Exception" not in stderr_data)
        self.assert_("Traceback" not in stderr_data)
        stderr.close()
        # will implicitly delete the file
        self.tmp_stderr.close()


class AxploreHandlerTester(unittest2.TestCase):
    def test_send_ipv4(self):
        # Get a UDP socket on any free port the OS assigns us.
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.bind( ("127.0.0.1", 0) )
        listen_port = sock.getsockname()[1]

        # Log 1 message to the assigned port
        handler = AH(address=('127.0.0.1', listen_port))
        logger = logging.getLogger("AxploreHandlerTester")
        logger.setLevel(logging.DEBUG)
        logger.addHandler(handler)
        message = "Hello, world!"
        try:
            logger.info(message)

            # We must see a log message on our port
            sock.settimeout(0.1)
            logged_message = sock.recv(4096)
        finally:
            logger.removeHandler(handler)
            sock.close()
        self.assertIn(message, logged_message)

    """
    Python's SysLogHandler does not support IPv6 (yet)
    def test_send_ipv6(self):
        # Get a UDP socket on any free port the OS assigns us.
        sock = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
        try:
            sock.bind( ("::1", 0) )
        except Exception:
            # Host has no IPv6 address on loopback interface
            return
        listen_port = sock.getsockname()[1]

        # Log 1 message to the assigned port
        handler = AH(address=('::1', listen_port))
        logger = logging.getLogger("AxploreHandlerTester")
        logger.setLevel(logging.DEBUG)
        logger.addHandler(handler)
        message = "Hello, world!"
        try:
            logger.info(message)

            # We must see a log message on our port
            sock.settimeout(0.1)
            logged_message = sock.recv(4096)
        finally:
            logger.removeHandler(handler)
            sock.close()
        self.assertIn(message, logged_message)
    """


if __name__ == "__main__":
    unittest2.main()
