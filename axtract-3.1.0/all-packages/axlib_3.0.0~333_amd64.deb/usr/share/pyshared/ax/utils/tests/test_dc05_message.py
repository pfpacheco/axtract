#!/usr/bin/python -tt

import unittest2

import ax.utils.dc05_message as dc05

class DC05MessageTests(unittest2.TestCase):
    def test_appendixA1(self):
        """Test example 1 of Appendix A"""
        text = "1234 18 1131 01 015 8"
        dc = dc05.DC05Message(text)
        self.assertEqual(dc.account, "1234")
        self.assertEqual(dc.message_type, "18")
        self.assertEqual(dc.qualifier, "1")
        self.assertEqual(dc.event_code, "131")
        self.assertEqual(dc.group, "01")
        self.assertEqual(dc.zone_number, "015")
        self.assertEqual(dc.checksum, "8")

        # Encoding must give same string, just without the whitespace.
        self.assertEqual(text.replace(" ", ""), dc.encode_message())

    def test_appendixA2(self):
        """Test example 2 of Appendix A"""
        text = "1234 18 3131 01 015 6"
        dc = dc05.DC05Message(text)
        self.assertEqual(dc.account, "1234")
        self.assertEqual(dc.message_type, "18")
        self.assertEqual(dc.qualifier, "3")
        self.assertEqual(dc.event_code, "131")
        self.assertEqual(dc.group, "01")
        self.assertEqual(dc.zone_number, "015")
        self.assertEqual(dc.checksum, "6")

        # Encoding must give same string, just without the whitespace.
        self.assertEqual(text.replace(" ", ""), dc.encode_message())

    def test_appendixA3(self):
        """Test example 3 of Appendix A"""
        text = "1234 18 1401 02 003 5"
        dc = dc05.DC05Message(text)
        self.assertEqual(dc.account, "1234")
        self.assertEqual(dc.message_type, "18")
        self.assertEqual(dc.qualifier, "1")
        self.assertEqual(dc.event_code, "401")
        self.assertEqual(dc.group, "02")
        self.assertEqual(dc.zone_number, "003")
        self.assertEqual(dc.checksum, "5")

        # Encoding must give same string, just without the whitespace.
        self.assertEqual(text.replace(" ", ""), dc.encode_message())

    def test_appendixA4(self):
        """Test example 4 of Appendix A"""
        text = "1234 18 3401 03 005 F"
        dc = dc05.DC05Message(text)
        self.assertEqual(dc.account, "1234")
        self.assertEqual(dc.message_type, "18")
        self.assertEqual(dc.qualifier, "3")
        self.assertEqual(dc.event_code, "401")
        self.assertEqual(dc.group, "03")
        self.assertEqual(dc.zone_number, "005")
        self.assertEqual(dc.checksum, "F")

        # Encoding must give same string, just without the whitespace.
        self.assertEqual(text.replace(" ", "").upper(), dc.encode_message())

    def test_whitespace(self):
        """More exotic whitespace variations of appendix A1"""
        text = "\t123418   1131\t01\t\t015 8  "
        dc = dc05.DC05Message(text)
        self.assertEqual(dc.account, "1234")
        self.assertEqual(dc.message_type, "18")
        self.assertEqual(dc.qualifier, "1")
        self.assertEqual(dc.event_code, "131")
        self.assertEqual(dc.group, "01")
        self.assertEqual(dc.zone_number, "015")
        self.assertEqual(dc.checksum, "8")

        # Encoding must give same string, just without the whitespace.
        self.assertEqual(text.replace(" ", "").replace("\t", ""), dc.encode_message())

    def test_lower(self):
        """Lower case version of Appendix A4, must convert to upper case"""
        text = "1234 18 3401 03 005 f"
        dc = dc05.DC05Message(text)
        self.assertEqual(dc.account, "1234")
        self.assertEqual(dc.message_type, "18")
        self.assertEqual(dc.qualifier, "3")
        self.assertEqual(dc.event_code, "401")
        self.assertEqual(dc.group, "03")
        self.assertEqual(dc.zone_number, "005")
        self.assertEqual(dc.checksum, "F")

        # Encoding must give same string, just without the whitespace and
        # with upper case letter.
        self.assertEqual(text.replace(" ", "").upper(), dc.encode_message())

    def test_invalid(self):
        """Obviously invalid messages must raise appropriate exceptions"""
        # Variations of Appendix A1
        too_short = "1234 18 1131 01 015 "
        too_long = "1234 18 1131 01 015 88"
        wrong_checksum = "1234 18 1131 01 015 7"
        invalid_chars1 = "AA34 18 1131 01 015 8"
        invalid_chars2 = "XX34 18 1131 01 015 8"

        self.assertRaises(dc05.DC05DecodeError, dc05.DC05Message, too_short)
        self.assertRaises(dc05.DC05DecodeError, dc05.DC05Message, too_long)
        self.assertRaises(dc05.DC05WrongChecksumError, dc05.DC05Message, wrong_checksum)
        self.assertRaises(dc05.DC05InvalidCharsError, dc05.DC05Message, invalid_chars1)
        self.assertRaises(dc05.DC05InvalidCharsError, dc05.DC05Message, invalid_chars2)


class DC05MessageAltiboxTests(unittest2.TestCase):

    def test_single(self):
        """Tests with a single message"""
        text = "006197 183456000047986"
        dc = dc05.DC05MessageAltibox(text)
        self.assertEqual(dc.account, "006197")
        self.assertEqual(dc.message_type, "18")
        self.assertEqual(dc.qualifier, "3")
        self.assertEqual(dc.event_code, "456")
        self.assertEqual(dc.group, "00")
        self.assertEqual(dc.zone_number, "004")
        self.assertEqual(dc.checksum, "7986")

        # Must reproduce the original exactly, including the whitespace.
        self.assertEqual(text, dc.encode_message())

    def test_mass_parse(self):
        """ Lots of sample messages from Altibox that must be parsable"""
        data = """006197 183456000047986
002120 181602000003B67
006197 181400000042079
002090 181602000008E6D
001512 18160200000736B
002417 18140100003A270
002145 18160200000986E
002086 18160200000CE72
003264 18160200000C671
001060 181602000005469
001455 18160200000C371
002148 18160200000BF71
004791 181400000140E78
005846 181602000003E79
001235 183400000088773
002096 18160200000DC73
005040 181401000016369
006309 18160200000F274
002539 18340000008F87B
001714 18160200000AB6F
003318 18160200000C371
001760 18160200000BD70
002035 18138300004A576
002036 18140000012706C
002036 18138400012B877
002035 18338300004B778
002948 18340000007347E
001623 18314700005C679
002035 18138300004A576
006343 18340100003DB74
002035 18338300004B778
002035 18138300004A576
002861 18140100001D471
005515 18160200000DA72
007083 18140100001E272
006411 18345600007EB7E
006878 18160200000927F
007245 183456000083C85
003354 18160200000C771
006427 183400000150079
001543 18160200000AA6F
002111 181602000003A67
001433 181602000008D6D
002123 18160200000626A
002124 181602000006F6B
001425 18160200000996E
003306 181602000009B6E
001894 18140000009177D
003670 183456000021B7D
001389 181602000001277
003843 18160200000F774
001525 18160200000A86F
004986 18160200000757D"""
        for message in data.split("\n"):
            dc = dc05.DC05MessageAltibox(message)
            # Encoding must preserve the space. The space must be included in
            # the calculation of the checksum, too.
            encoded = dc.encode_message()
            self.assertEqual(message, encoded)


if __name__ == "__main__":
    unittest2.main()

