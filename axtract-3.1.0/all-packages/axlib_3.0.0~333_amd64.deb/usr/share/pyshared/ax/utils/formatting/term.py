from ax.utils.ordereddict import OrderedDict
class ShellColors:
    """
    Black       0;30     Dark Gray     1;30
    Blue        0;34     Light Blue    1;34
    Green       0;32     Light Green   1;32
    Cyan        0;36     Light Cyan    1;36
    Red         0;31     Light Red     1;31
    Purple      0;35     Light Purple  1;35
    Brown       0;33     Yellow        1;33
    Light Gray  0;37     White         1;37
    """
    K = "0;30"
    B = "0;34"
    G = "0;32"
    C = "0;36"
    R = "0;31"
    P = "0;35"
    O = "0;33"
    Y = "1;33"
    W = "1;37"
    # bold:
    BK = "1;30"
    BW = "0;37"
    BB = "1;34"
    BG = "1;32"
    BC = "1;36"
    BR = "1;31"
    BP = "1;35"
    N = "0"
    # distingishable cols, to count up numbers:
    cols = ['BG', 'BB', 'BW', 'BC', 'BR', 'BP', 'BK',
            'G', 'P', 'B', 'C', 'R', 'P', 'O', 'Y', 'W']

def colors():
    ret = OrderedDict()
    for c in ShellColors.cols:
        ret[c] = getattr(ShellColors, c)
    return ret


def esc_code(fg, bg=None, for_ps1=0):
    l = len(ShellColors.cols)
    if str(fg).isdigit():
        fg = ShellColors.cols[int(fg) % l]
    fg = "\\033[" + getattr(ShellColors, fg) + 'm'
    if bg is not None:
        if str(bg).isdigit():
            bg = ShellColors.cols[int(bg) % l]
        bg = getattr(ShellColors, bg)
        # no bold for bgs, so no 0; or 1;:
        bg = "\\033[4" + bg[-1] + 'm'
    esc=""
    end_esc = ""
    if for_ps1:
        esc = "\["
        end_esc = "\]"
    ret = esc + fg
    if bg is not None:
        ret += esc + bg
    return ret + end_esc

def colorize(s, fg, bg=None, for_ps1=0):
    ret = '%s%s%s' % (esc_code(fg, bg, for_ps1),
                       s, esc_code('N', bg, for_ps1))
    return ret


if __name__ == '__main__':
    import os
    print colorize('/X' , 'G', for_ps1=1)

    # bold green on red hello, bold blue world:
    os.system('echo "%s %s"' % (colorize('hello', '0', 'R'),
                                colorize('world', 1)))
