from struct import pack, unpack
from netaddr import IPAddress


def decode_utf8_string(msg):
    new_string = ""
    data = ""

    str_len = unpack("!L", msg[:4])
    if len(str_len) > 0:
        str_len = str_len[0]
        msg = msg[4:]
        new_string = msg[:str_len]

        if len(msg) - str_len >= 0:
            data = msg[str_len:]
    return new_string, data

def decode_ipv4addr(data):
    if not data:
        return "", ""
    ip_as_int, data = decode_uint(data)
    new_string = str(IPAddress(ip_as_int))
    return new_string, data

def decode_int(data):
    return decode_uint(data)

def decode_uint(data):
    if len(data) < 4:
        return len(data), data
    decoded_int = unpack("!L", data[:4])
    data = data[4:]
    return decoded_int[0], data

def decode_double(data):
    if len(data) < 8:
        return len(data), data
    decoded_double = unpack("d", data[:8])
    data = data[8:]
    return decoded_double, data

def decode_float(data):
    if len(data) < 4:
        return len(data), data
    decoded_float = unpack("f", data[:4])
    data = data[4:]
    return decoded_float, data

def decode_boolean(data):
    return decode_char(data)

def decode_short(data):
    if len(data) < 2:
        return len(data), data
    decoded_short = unpack("h", data[:2])
    data = data[2:]
    return decoded_short, data

def decode_unsigned_short(data):
    if len(data) < 2:
        return len(data), data
    decoded_short = unpack("H", data[:2])
    data = data[2:]
    return decoded_short, data

def decode_uuid(data):
    return decode_ipv6addr(data, "-")

def decode_ip_address(data):
    length = unpack("!L", data[:4])
    if len(length[0]) == 16:
        return decode_ipv6addr(data)
    else:
        return decode_ipv4addr(data)

def decode_char(data):
    decoded_char = unpack("b", data[:1])
    data = data[1:]
    return decoded_char[0], data

def decode_unsigned_char(data):
    decoded_char = unpack("B", data[:1])
    data = data[1:]
    return decoded_char, data

def decode_mac(data):
    empty1, empty2, m1, m2, m3, m4, m5, m6 = unpack("BBBBBBBB", data[:8])
    mac = "%02x%02x.%02x%02x.%02x%02x" % (m1, m2, m3, m4, m5, m6)
    data = data[8:]
    return mac, data

def decode_long(data):
    return decode_64bit_number(data)

def decode_unsigned_long(data):
    return decode_64bit_u_number(data)

def decode_list(data):
    pass

def decode_ipv6addr(msg, separator=":"):
    ipv6addr_tuple = unpack("!LBBBBBBBBBBBBBBBB", msg[:20])
    ipv6addr = "%02x%02x%s%02x%02x%s%02x%02x%s%02x%02x%s%02x%02x%s%02x%02x%s%02x%02x%s%02x%02x" % \
        (ipv6addr_tuple[1], ipv6addr_tuple[2], separator, ipv6addr_tuple[3], ipv6addr_tuple[4], separator,
         ipv6addr_tuple[5], ipv6addr_tuple[6], separator, ipv6addr_tuple[7], ipv6addr_tuple[8], separator,
         ipv6addr_tuple[9], ipv6addr_tuple[10], separator, ipv6addr_tuple[11], ipv6addr_tuple[12], separator,
         ipv6addr_tuple[13], ipv6addr_tuple[14], separator, ipv6addr_tuple[15], ipv6addr_tuple[16])
    msg = msg[20:]
    return ipv6addr, msg

def decode_date_time(msg):
    return decode_uint(msg)

def decode_date_time_msec(msg):
    return decode_unsigned_long(msg)

def decode_date_time_usec(msg):
    part1, part2 = unpack("!LL", msg[:8])
    part1 = part1 << 32
    part1 += part2
    msg = msg[8:]
    return part1, msg

def decode_64bit_number(msg):
    long_int = unpack("!q", msg[:8])
    return long_int[0], msg[8:]

def decode_64bit_u_number(msg):
    long_int = unpack("!Q", msg[:8])
    msg = msg[8:]
    return long_int[0], msg

def decode_unknown(data, data_type):
    count = data.split("_")[1]
    data = data[int(count):]
    return data

def decode_hex_binary(data):
    length = unpack("!L", data[:4])
    length = length[0]
    data = data[4:]

    return data[:length], data[length:]

def encode_64bit_number(data):
    encoded_data = pack("!q", data)
    return encoded_data
