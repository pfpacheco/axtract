import unittest
from ax.utils.parsing.parse_timedelta import parse


class TestParse(unittest.TestCase):
    def test_parse_float(self):
        self.assertEqual(1, parse("1"))
        self.assertEqual(1, parse("1.0"))
        self.assertEqual(1.00001, parse("1.00001"))
        self.assertEqual(0.5, parse('0.5'))
        self.assertEqual(0.5, parse('.5'))

    def test_parse_seconds(self):
        self.assertEqual(1, parse("1s"))
        self.assertEqual(1, parse("1.0 s"))
        self.assertEqual(1, 00001, parse("1.00001S"))
        self.assertEqual(1, 00001, parse("1.00001 S"))

    def test_parse_minutes(self):
        self.assertEqual(120, parse('2m'))
        self.assertEqual(120, parse('2 m'))
        self.assertEqual(120, parse('2 M'))
        self.assertEqual(120, parse('2M'))

    def test_parse_hours(self):
        self.assertEqual(3 * 3600, parse('3h'))
        self.assertEqual(3 * 3600, parse('3 h'))
        self.assertEqual(3 * 3600, parse('3 H'))
        self.assertEqual(3 * 3600, parse('3H'))

    def test_parse_days(self):
        self.assertEqual(4 * 3600 * 24, parse('4d'))
        self.assertEqual(4 * 3600 * 24, parse('4 d'))
        self.assertEqual(4 * 3600 * 24, parse('4 D'))
        self.assertEqual(4 * 3600 * 24, parse('4D'))

    def test_parse_weeks(self):
        self.assertEqual(5 * 3600 * 24, parse('5d'))
        self.assertEqual(5 * 3600 * 24, parse('5 d'))
        self.assertEqual(5 * 3600 * 24, parse('5 D'))
        self.assertEqual(5 * 3600 * 24, parse('5D'))

    def test_parse_combinations(self):
        spec = "20d 20m 0.5s"
        ref = 20 * 3600 * 24 + 20 * 60 + 0.5
        self.assertEqual(ref, parse(spec))

        spec = "20d 20m 0.5s 1"
        ref = 20 * 3600 * 24 + 20 * 60 + 1.5
        self.assertEqual(ref, parse(spec))

        spec = "20d 20m 1w 2H 0.5s 1"
        ref = 20 * 3600 * 24 + 20 * 60 + 1.5 + 2 * 3600 + 1 * 3600 * 24 * 7
        self.assertEqual(ref, parse(spec))

    def test_wrong_keyword(self):
        with self.assertRaises(Exception):
            parse('1Y')

        with self.assertRaises(Exception):
            parse('1 y')
