import contextlib
import time
import unittest

import mock

import ax.utils.step_engine.engine as engine
import ax.utils.step_engine.engine_hooks as engine_hooks


@contextlib.contextmanager
def patch_now(ts):
    with mock.patch('ax.utils.step_engine.engine_hooks._now', lambda: ts):
        with mock.patch('ax.utils.step_engine.engine._now', lambda: ts):
            yield


def add_sc(step, initargs, lastResult, a, b):
    return step + initargs + a + b


class TestEngine(unittest.TestCase):
    def _gen(self, mr={}, am=(), st=None):
        hooks = engine_hooks.ExampleHooks(mr, am)
        return engine.StepEngine(hooks, st)

    def test_init(self):
        ob = self._gen()
        self.assertIsInstance(ob, engine.StepEngine)
        self.assertEqual(ob._scenarios, [])

    def test_get_state(self):
        ob = self._gen(st={'scenarios': 'hmm', 'global_state': 'wow'})
        ref = {'scenarios': 'hmm', 'global_state': 'wow'}
        self.assertEqual(ref, ob.get_state())

    def test_activate_scenario(self):
        ob = self._gen()
        with patch_now(1234):
            ret = ob.activate_scenario('new_method', {'init': 'rocks'})

        self.assertEqual('1234', ret)

        ref = [{
            'status': 'ready',
            'local_state': {},
            'global_state': {},
            'step': 0,
            'envid': '1234',
            'callerEnvId': None,
            'lastResult': None,
            'initargs': {'init': 'rocks'},
            'id': 'new_method',
            'ts': 1234
        }]

        self.assertEqual(ref, ob._scenarios)

    def test_get_next_ready_sc(self):
        ob = self._gen()
        self.assertIsNone(ob._get_next_ready_sc())

        ob.activate_scenario('m1', [])
        self.assertEqual('m1', ob._get_next_ready_sc()['id'])

        ob.activate_scenario('m2', [])
        self.assertEqual('m1', ob._get_next_ready_sc()['id'])

        ob._scenarios[0]['status'] = 'bogus'
        self.assertEqual('m2', ob._get_next_ready_sc()['id'])

    def test_call_sc(self):
        ob = self._gen({'add': add_sc})
        sc = ob._gen_sc('add', 1, None)
        sc['step'] = 1

        ret = ob._call_sc(sc, {'a': 2, 'b': 3})
        self.assertEqual(7, ret)

    def test_call_sc_with_local_state_get(self):
        def test(step, initargs, lastResult):
            state = engine.get_local_state()
            return state + initargs['hmm']

        ob = self._gen({'t': test})
        sc = ob._gen_sc('t', {'hmm': 1})
        sc['local_state'] = 1

        ret = ob._call_sc(sc, {})
        self.assertEqual(2, ret)

    def test_call_sc_with_local_state_set(self):
        def test(step, initargs, lastResult):
            state = engine.get_local_state()
            ret = state['hmm'] + initargs['hmm']
            state['new'] = ret
            return ret

        ob = self._gen({'t': test})
        sc = ob._gen_sc('t', {'hmm': 1})
        sc['local_state'] = {'hmm': 1}

        ret = ob._call_sc(sc, {})
        self.assertEqual(2, ret)
        self.assertEqual({'hmm': 1, 'new': 2}, sc['local_state'])

    def test_call_sc_with_global_state_set(self):
        def test(step, initargs, lastResult):
            state = engine.get_global_state()
            ret = state['hmm'] + initargs['hmm']
            state['new'] = ret
            return ret

        ob = self._gen({'t': test})
        sc = ob._gen_sc('t', {'hmm': 1})
        sc['global_state'] = {'hmm': 1}

        ret = ob._call_sc(sc, {})
        self.assertEqual(2, ret)
        self.assertEqual({'hmm': 1, 'new': 2}, sc['global_state'])

    def test_is_ret_child_sc_trigger(self):
        ob = self._gen()
        self.assertTrue(ob._is_sc_ret_child_trigger(('next_step', {})))
        self.assertTrue(ob._is_sc_ret_child_trigger((1, {})))
        self.assertTrue(ob._is_sc_ret_child_trigger((1.5, {})))
        self.assertFalse(ob._is_sc_ret_child_trigger(None))
        self.assertFalse(ob._is_sc_ret_child_trigger(({}, {})))
        self.assertFalse(ob._is_sc_ret_child_trigger(('next_step', {}, None)))
        self.assertFalse(ob._is_sc_ret_child_trigger(('next_step', '')))

    def test_get_finished_scenarios(self):
        ob = self._gen()

        sc = ob._gen_sc('m1', '')
        ob._scenarios.append(sc)

        sc = ob._gen_sc('m2', '')
        sc['status'] = 'success'
        ob._scenarios.append(sc)

        sc = ob._gen_sc('m3', '')
        sc['status'] = 'failed'
        ob._scenarios.append(sc)

        sc = ob._gen_sc('m3', '')
        sc['status'] = 'wait_for_result'
        ob._scenarios.append(sc)

        ret = ob.get_finished_scenarios()
        ret = [sc['id'] for sc in ret]

        self.assertEqual(['m2', 'm3'], ret)

    def test_remove_finished_scenarios(self):
        ob = self._gen()

        sc = ob._gen_sc('m1', '')
        ob._scenarios.append(sc)

        sc = ob._gen_sc('m2', '')
        sc['status'] = 'success'
        ob._scenarios.append(sc)

        sc = ob._gen_sc('m3', '')
        sc['status'] = 'failed'
        ob._scenarios.append(sc)

        sc = ob._gen_sc('m3', '')
        sc['status'] = 'wait_for_result'
        ob._scenarios.append(sc)

        ob.remove_finished_scenarios()
        self.assertEqual([], ob.get_finished_scenarios())

        st = ob.get_state()
        st = [sc['id'] for sc in st['scenarios']]
        self.assertEqual(['m1', 'm3'], st)

    def test_remove_scenarios_by_name(self):
        ob = self._gen()

        sc = ob._gen_sc('m', '')
        ob._scenarios.append(sc)

        sc = ob._gen_sc('c0', '', sc['envid'])
        ob._scenarios.append(sc)

        sc = ob._gen_sc('c1', '', sc['envid'])
        ob._scenarios.append(sc)

        sc = ob._gen_sc('f', '')
        ob._scenarios.append(sc)

        sc = ob._gen_sc('m', '', sc['envid'])
        ob._scenarios.append(sc)

        sc = ob._gen_sc('x', '')
        ob._scenarios.append(sc)

        ob.remove_scenarios_by_name('m')

        st = ob.get_state()
        st = [sc['id'] for sc in st['scenarios']]

        self.assertEqual(['f', 'm', 'x'], st)

    def test_get_childs(self):
        ob = self._gen()

        sc1 = ob._gen_sc('m1', '')
        sc2 = ob._gen_sc('m2', '', sc1['envid'])
        sc3 = ob._gen_sc('m3', '', sc2['envid'])

        ob._scenarios.append(sc1)
        ob._scenarios.append(sc2)
        ob._scenarios.append(sc3)

        ret = [sc['id'] for sc in ob._get_childs(sc1)]
        self.assertEqual(['m2'], ret)

        ret = [sc['id'] for sc in ob._get_childs(sc2)]
        self.assertEqual(['m3'], ret)

        ret = [sc['id'] for sc in ob._get_childs(sc3)]
        self.assertEqual([], ret)

        ret = [sc['id'] for sc in ob._get_childs(sc1, recursive=True)]
        self.assertEqual(['m2', 'm3'], ret)

        ret = [sc['id'] for sc in ob._get_childs(sc2, recursive=True)]
        self.assertEqual(['m3'], ret)

        ret = [sc['id'] for sc in ob._get_childs(sc3, recursive=True)]
        self.assertEqual([], ret)

    def test_last_result_is_last_return_value(self):
        def workflow(step, initargs, lastResult):
            return "hello world"

        ob = self._gen({'workflow': workflow})
        ob.activate_scenario('workflow', {})
        ob.execute()
        ret = ob.get_finished_scenarios()

        self.assertEqual('hello world', ret[0]['lastResult'])

    def test_last_result_set_if_none(self):
        def workflow(step, initargs, lastResult):
            pass

        ob = self._gen({'workflow': workflow})
        ob.activate_scenario('workflow', {})
        ob._scenarios[0]['lastResult'] = 'hello world'

        ob.execute()

        ret = ob.get_finished_scenarios()
        self.assertIsNone(ret[0]['lastResult'])

    def test_call_child_sc_first(self):
        calls = []

        def sc_a(step, initargs, lastResult):
            calls.append(('sc_a', step))

            if step == 0:
                return 1, {'method': 'sc_child'}

            if step == 1:
                pass

        def sc_child(step, initargs, lastResult):
            calls.append(('sc_child', step))

        def sc_b(step, initargs, lastResult):
            calls.append(('sc_b', step))

        ob = self._gen({'sc_a': sc_a, 'sc_b': sc_b, 'sc_child': sc_child})
        ob.activate_scenario('sc_a', None)
        ob.activate_scenario('sc_b', None)

        while ob.execute():
            pass

        ref = [('sc_a', 0), ('sc_child', 0), ('sc_a', 1), ('sc_b', 0)]
        self.assertEqual(ref, calls)

    def test_populate_exception_to_parent(self):
        calls = []

        def sc_a(step, initargs, lastResult):
            calls.append(('sc_a', step))
            if step == 0:
                return 1, {'method': 'sc_child'}

        def sc_child(step, initargs, lastResult):
            calls.append(('sc_child', step))
            raise Exception("error")

        ob = self._gen({'sc_a': sc_a, 'sc_child': sc_child})
        ob.activate_scenario('sc_a', None)

        while ob.execute():
            pass

        ref = [('sc_a', 0), ('sc_child', 0), ('sc_a', 'FAULT_1')]
        self.assertEqual(ref, calls)

    def test_ensure_scenario(self):
        now = time.time()
        ob = self._gen({'sc1': mock.Mock(return_value=None)})

        ret1 = ob.ensure_scenario('sc1', None)
        self.assertGreater(ret1, now)

        ret2 = ob.ensure_scenario('sc1', None)
        self.assertIsNone(ret2)

        ob.execute()

        ret3 = ob.ensure_scenario('sc1', None)
        self.assertGreater(ret3, now)
        self.assertGreater(ret3, ret2)

    def test_remove_initargs(self):
        calls = []

        def sc(step, initargs, lastResult):
            calls.append((step, initargs))
            if step == 0:
                return 1, {'method': 'atomic'}

        ob = self._gen({'sc': sc}, ['atomic'])
        ob.activate_scenario('sc', [1, 2, 3])
        ob.clear_initargs(['sc'])
        ret = ob.execute()
        ob.clear_initargs(['sc'])
        ob.activate_next_step(ret['envid'], {})
        ob.execute()

        ref = [(0, [1, 2, 3]), (1, None)]
        self.assertEqual(ref, calls)

        ob.remove_finished_scenarios()
        calls[:] = []

        ob.activate_scenario('sc', [1, 2, 3])
        ret = ob.execute()
        ob.clear_initargs([])
        ob.activate_next_step(ret['envid'], {})
        ob.execute()

        ref = [(0, [1, 2, 3]), (1, [1, 2, 3])]
        self.assertEqual(ref, calls)

    def test_auto_remove_finished_child_scenarios(self):
        calls = []

        def sc(step, initargs, lastResult):
            calls.append((step, initargs))
            if step == 0 and initargs:
                return 1, {'method': 'sc', 'args': initargs - 1}

        ob = self._gen({'sc': sc})
        ob.activate_scenario('sc', 2)
        ob.execute()
        state = ob.get_state()
        self.assertEqual(1, len(state['scenarios']))
        self.assertEqual([(0, 2), (0, 1), (0, 0), (1, 1), (1, 2)], calls)
