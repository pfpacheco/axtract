# py2/3 compat helpers, collecting first helpers. to ax.utils.py_compat (?)
from ax.utils.func.filters import is_str, is_func, PY2

from threading import current_thread
from time      import time


# debug helper - print, with current thread:
def p(*s):
    print ('%s %s: %s' % ( time(), current_thread().name,
                           ' '.join([str(i) for i in s])))
