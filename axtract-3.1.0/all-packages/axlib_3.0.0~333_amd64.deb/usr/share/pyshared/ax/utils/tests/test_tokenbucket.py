#!/usr/bin/python -tt

import random
import sys
import threading
import time
import unittest2
import sqlalchemy
import os
import mock
import contextlib

from ax.utils import tokenbucket as tb
class FakeTime(object):
    """Completely static time() and sleep() functions for testing
        Time keeping is done completely internally and has no connection
        to the real time. Everything is really precise this way and takes
        little time.

        Warning: If you use this module, you must set both $sleepfunc and $timefunc
    """
    def __init__(self):
        self.now_ts = 0.0

    def sleep(self, sleeptime):
        # Enforce that simulated time advances by at least 1 microsecond.
        # Otherwise, limited floating point precision can freeze time.
        # See comments in AXOS-60 for details.
        self.now_ts += (sleeptime + 0.0000001)

    def time(self):
        return self.now_ts

class RandomizedTime(FakeTime):
    """Slightly randomized time() and sleep() functions for testing"""
    def __init__(self):
        super(RandomizedTime, self).__init__()
        # How much we lag behind the current time
        self.time_lag = 0.0

    def time(self):
        """emulate time.time() with 'lag'
        """
        have_lag = (random.randint(1, 5) == 3)
        if have_lag:
            self.time_lag += random.random() * 20

        return super(RandomizedTime, self).time() - self.time_lag

    def sleep(self, sleeptime):
        """emulate time.sleep() that sometimes gets interrupted by a signal"""
        # do we simulate an incoming signal?
        have_signal = (random.randint(1, 5) == 3)
        # do we simulate high load that lets sleep() sleep much longer?
        have_extra_delay = (random.randint(1, 5) == 3)
        if have_signal:
            sleeptime *= random.random()
            super(RandomizedTime, self).sleep(sleeptime)
            raise Exception("interrupted by a signal")
        else:
            if have_extra_delay:
                sleeptime *= 1 + random.random()
            super(RandomizedTime, self).sleep(sleeptime)

class TokenbucketTests(unittest2.TestCase):
    def testTakeOne(self):
        """Test the take_token() function using real time"""
        for tb_class in (tb.Tokenbucket, tb.ThreadsafeTokenbucket):
            self.bucket = tb_class(10, 10)
            start = time.time()
            for count in range(0, 5):
                self.bucket.take_token()
            stop = time.time()
            delta = stop - start
            # the above should have taken 0.5 seconds
            self.assertGreaterEqual(delta, 0.5)
            self.assertLess(delta, 0.55)

    def testTakeMany(self):
        """Test the take_tokens() function using real time"""
        for tb_class in (tb.Tokenbucket, tb.ThreadsafeTokenbucket):
            self.bucket = tb_class(10, 100.0)
            start = time.time()
            for count in range(0, 5):
                self.bucket.take_tokens(10)
            stop = time.time()
            delta = stop - start
            # the above should have taken 0.5 seconds
            self.assertGreaterEqual(delta, 0.5)
            self.assertLess(delta, 0.55)

    def testAddWait(self):
        """Test wait_for_tokens() and _add_tokens()
        """
        for tb_class in (tb.Tokenbucket, tb.ThreadsafeTokenbucket):
            bucket = tb_class(10, 10.0)
            self.assertEqual(bucket.tokens, 0)
            bucket._add_tokens()
            self.assertEqual(bucket.tokens, 0)

            # After this time, another token must appear.
            time.sleep(0.1)
            bucket._add_tokens()
            self.assertEqual(bucket.tokens, 1)


            bucket.wait_for_tokens(2)
            # If wait_for_tokens did not sleep long enough, this fails:
            self.assertEqual(bucket.tokens, 2)
            # If wait_for_tokens() slept too long, this fails:
            bucket._add_tokens()
            self.assertEqual(bucket.tokens, 2)

    def testTryTake(self):
        """See if try_take_tokens does not block and returns correct info"""
        for tb_class in (tb.Tokenbucket, tb.ThreadsafeTokenbucket):
            bucket = tb_class(10, 10.0)
            self.assertEqual(bucket.try_take_tokens(1), False)

            time.sleep(0.1)
            start = time.time()
            self.assertEqual(bucket.try_take_tokens(1), True)
            self.assertEqual(bucket.try_take_tokens(1), False)
            self.assertLess(time.time() - start, 0.05)

            time.sleep(0.2)
            start = time.time()
            self.assertEqual(bucket.try_take_tokens(3), False)
            self.assertEqual(bucket.try_take_tokens(2), True)
            self.assertEqual(bucket.try_take_tokens(1), False)
            self.assertLess(time.time() - start, 0.05)

    def testTryTakeThreadsafe(self):
        """ThreadsafeTokenbucket.try_take_tokens() must not block if another
            thread is holding the lock.
            This tests if AXOS-69 is really fixed.
        """
        bucket = tb.ThreadsafeTokenbucket(1, 1, prefill=0)

        def threaded_helper(bucket_to_use):
            bucket_to_use.take_token()

        helper = threading.Thread(target=threaded_helper, args=(bucket,))
        helper.daemon = True
        helper.start()

        time.sleep(0.1)
        # Assume the thread is now running and has taken the lock

        start = time.time()
        bucket.try_take_tokens(1)
        stop = time.time()

        self.assertLess(stop - start, 0.1)

    def testGetNumTokens(self):
        """See if get_num_tokens() really updates and returns correct info"""
        for tb_class in (tb.Tokenbucket, tb.ThreadsafeTokenbucket):
            bucket = tb_class(10, 10.0)
            self.assertEqual(bucket.get_num_tokens(), 0)
            time.sleep(0.1)
            self.assertEqual(bucket.get_num_tokens(), 1)

    def testPrefill(self):
        """Test the prefill=xx keyword arg of the Tokenbucket"""
        for tb_class in (tb.Tokenbucket, tb.ThreadsafeTokenbucket):
            bucket = tb_class(10, 1.0, prefill=3)
            self.assertEqual(bucket.tokens, 3)
            bucket = tb_class(10, 1.0, prefill=0)
            self.assertEqual(bucket.tokens, 0)

            # Invalid prefill parameter must raise Exception
            self.assertRaises(ValueError, tb_class, 10, 1.0, prefill=11)
            self.assertRaises(ValueError, tb_class, 1, 1.0, prefill=2)

    def testStrangeTime(self):
        """See what happens when time behaves strangely.
            This uses the randomized time function to bypass the real
            world time.
        """
        randomized_time = RandomizedTime()

        for tb_class in (tb.Tokenbucket, tb.ThreadsafeTokenbucket):
            for x in xrange(0, 100):
                for bucketsize in (1, 2, 3, 11, 300):
                    for rate in (0.1, 0.9, 4, 1000):
                        for repeats in (1, 2, 5, 20, 101):
                            self.bucket = tb_class(bucketsize, rate,
                                    timefunc=randomized_time.time,
                                    sleepfunc=randomized_time.sleep)
                            start = randomized_time.now_ts
                            tokencount = 0
                            for count in range(0, repeats):
                                num_tokens = random.randint(1, min(1000, bucketsize))
                                self.bucket.take_tokens(num_tokens)
                                tokencount += num_tokens
                            stop = randomized_time.now_ts
                            delta = stop - start
                            real_rate = tokencount / delta
                            #print "rate: %30.20f  expected: %30.20f" % (real_rate, rate * 1.00001)

                            # Thanks to unprecise floating point calculation, this does not work:
                            #self.assert_(real_rate <= rate)
                            # This results in e.g. rate==0.9 and real_rate==0.9000000000000205
                            # So we compensate by allowing a rate that is 0.001 percent too high.
                            self.assertLessEqual(real_rate, rate * 1.00001)

    def RateRunner(self, rate, burst, amount):
        """Check if rates are really as configured"""
        for tb_class in (tb.Tokenbucket, tb.ThreadsafeTokenbucket):
            start = time.time()
            self.bucket = tb_class(burst, rate)
            for count in range(0, amount):
                self.bucket.take_token()
            stop = time.time()
            real_rate = amount / (stop - start)
            # Must not be faster than configured rate, but at least be 98% as fast.
            self.assertLessEqual(real_rate, rate)
            self.assertGreater(real_rate, rate * 0.98)

    def testAXOS60(self):
        """ Test for AXOS-60

        Bug summary is: Tokenbucket sleeps too long while waiting for a token
        Ensure that fractional tokens are considered in the calculation of the
        sleep time.
        """
        bucket = tb.Tokenbucket(1, 1, prefill=0)
        time.sleep(0.8)
        start = time.time()
        bucket.take_token()
        stop = time.time()

        # Delta should be ~0.2 second, since the bucket accumulated fractional
        # tokens during the time.sleep(0.8). The broken implementation would
        # unnecessarily produce a delta of 1 second instead.
        delta = stop - start
        self.assertLess(delta, 0.3)
        self.assertGreater(delta, 0.1)

class RatelimitTests(unittest2.TestCase):
    """Test the Ratelimit class and the @ratelimit decorator"""
    def testDecoratorDirectly(self):
        """Decorator function can directly wrap functions/methods"""
        amount = 11
        rate = 17
        class Foo(object):
            def foo(self):
                pass
        foo = Foo()
        def bar():
            pass

        # Token bucket starts counting as soon as applied to function.
        start = time.time()
        bar = tb.ratelimit(rate, 1, "wait")(bar)
        foo.foo = tb.ratelimit(rate, 1, "wait")(foo.foo)

        # The "@ratelimit" is instantiated with a bit of prefill. This prefill
        # is min(rate, burst), which is 1 in our case. To compensate for that,
        # we take one extra token to get exactly the defined rate.
        for count in range(0, amount + 1):
            foo.foo()
            bar()

        stop = time.time()
        real_rate = amount / (stop - start)
        # Must not be faster than configured rate, but at least be 98% as fast.
        self.assertLessEqual(real_rate, rate)
        self.assertGreater(real_rate, rate * 0.98)

    def testUnlimitedDecoratorDirectly(self):
        """Unlimited decorator function can directly wrap functions/methods

        Unlimited decorators are implemented with special code -> They must
        be tested seperately to achieve statement coverage.
        """
        amount = 1000
        class Foo(object):
            def foo(self):
                pass
        foo = Foo()
        def bar():
            pass

        # Token bucket starts counting as soon as applied to function.
        start = time.time()
        bar = tb.ratelimit(None, None, None)(bar)
        foo.foo = tb.ratelimit(None, None, None)(foo.foo)

        for count in range(0, amount):
            foo.foo()
            bar()
        stop = time.time()

        # Since almost nothing is done, it should take almost no time.
        delta = stop - start
        if delta > 0:
            real_rate = amount / (stop - start)
            self.assertGreater(real_rate, 100000)
        else:
            # delta == 0 is perfectly fine
            pass

    def testDecoratorDefaults(self):
        """Must default to burst=1 policy=wait

        Correct prefill is already implicitly tested everywhere.
        TODO: Check if decorator uses bucket_class=ThreadsafeTokenbucket
        """
        amount = 11
        rate = 17
        # Token bucket starts counting as soon as applied to function.
        start = time.time()
        @tb.ratelimit(rate)
        def foo():
            pass
        # The "@ratelimit" is instantiated with a bit of prefill. This prefill
        # is min(rate, burst), which is 1 in our case. To compensate for that,
        # we take one extra token to get exactly the defined rate.
        for count in range(0, amount + 1):
            foo()
        stop = time.time()
        real_rate = amount / (stop - start)
        # Must not be faster than configured rate, but at least be 98% as fast.
        self.assertLessEqual(real_rate, rate)
        self.assertGreater(real_rate, rate * 0.98)

    def testDecoratorForFunctionWait(self):
        """Use decorator on plain function, policy=wait"""
        amount = 11
        rate = 17
        # Token bucket starts counting as soon as applied to function.
        start = time.time()
        @tb.ratelimit(rate, 1, "wait")
        def foo():
            pass
        # The "@ratelimit" is instantiated with a bit of prefill. This prefill
        # is min(rate, burst), which is 1 in our case. To compensate for that,
        # we take one extra token to get exactly the defined rate.
        for count in range(0, amount + 1):
            foo()
        stop = time.time()
        real_rate = amount / (stop - start)
        # Must not be faster than configured rate, but at least be 98% as fast.
        self.assertLessEqual(real_rate, rate)
        self.assertGreater(real_rate, rate * 0.98)

    def testDecoratorPrefill(self):
        """Use decorator's "prefill" feature

        Test for AXOS-55
        """
        amount = 30
        rate = 17
        prefill = 17
        # otherwise, the math below will blow up.
        assert(amount > prefill)
        # Token bucket starts counting as soon as applied to function.
        start = time.time()
        @tb.ratelimit(rate, 17, "wait", prefill=17)
        def foo():
            pass
        for count in range(amount):
            foo()
        stop = time.time()
        delta = stop - start
        expected_delta = float(amount - prefill) / rate
        # Must not be faster than configured rate, but at least be 98% as fast.
        self.assertGreaterEqual(delta, expected_delta)
        self.assertLess(delta * 0.98, expected_delta)

    def testDecoratorAXOS56(self):
        """ Test for AXOS-56

        Bug summary is: Tokenbucket's "@ratelimit" misbehaves if rate<burst and rate is a float
        In that case, the TokenBucket will always give out Tokens.
        """
        amount = 1
        rate = 1.1
        burst = 2
        assert(rate < burst)
        assert(type(rate) == float)

        # Token bucket starts counting as soon as applied to function.
        start = time.time()
        @tb.ratelimit(rate, burst=burst)
        def foo():
            pass

        # The "@ratelimit" is instantiated with a bit of prefill. This prefill
        # is min(rate, burst), which is 1 in our case. To compensate for that,
        # we take one extra token to get exactly the defined rate.
        for count in range(amount + 1):
            foo()
        stop = time.time()

        real_rate = amount / (stop - start)
        # Must not be faster than configured rate, but at least be 98% as fast.
        self.assertLessEqual(real_rate, rate)
        self.assertGreater(real_rate, rate * 0.98)

    def testDecoratorForFunctionDrop(self):
        """Use decorator on plain function, policy=drop"""
        amount = 21
        rate = 17

        # Check if it really drops..
        start = time.time()
        @tb.ratelimit(rate, 1, "drop")
        def foo():
            pass
        for count in range(0, amount):
            foo()
        stop = time.time()
        # If tb.ratelimit() really drops, the only thing that can consume time
        # is if we get interrupted by the OS scheduler.
        self.assertLess(stop - start, 0.05)

        # Check if it really calls.
        my_list = []
        @tb.ratelimit(rate, 1, "drop")
        def foo(list_object):
            list_object.append(42)
        time.sleep(0.1)
        foo(my_list)
        self.assert_(len(my_list))

    def testDecoratorForFunctionRaise(self):
        """Use decorator on plain function, policy=raise"""
        amount = 21
        rate = 0.1

        # Check if it really drops..
        start = time.time()
        @tb.ratelimit(rate, 1, "raise")
        def foo():
            pass
        for count in range(0, amount):
            self.assertRaises(tb.RatelimitError, foo)
        stop = time.time()
        # The only thing that can consume time is if we get interrupted by
        # the OS scheduler.
        self.assertLess(stop - start, 0.05)

        # Check if it really calls.
        my_list = []
        rate = 100
        @tb.ratelimit(rate, 1, "raise")
        def foo(list_object):
            list_object.append(42)
        time.sleep(0.01)
        foo(my_list)
        self.assertEqual(my_list, [42])

    def testDropIsNonblocking(self):
        """Even when multi-threaded, Ratelimit with policy="drop" must not block

        This checks for AXOS-195
        """
        def use_ratelimit(ratelimit):
            """Use given Ratelimit instance for 0.3 seconds in a thread"""
            start = time.time()
            try:
                while time.time() - start < 0.3:
                    ratelimit.enforce()
            except Exception:
                ratelimit.is_buggy = True

        # The special sleepfunc will alert us if any sleeping is to be
        # performed, which must not happen with policy="drop".
        def throw_exception():
            raise Exception()
        ratelimit = tb.Ratelimit(100, 1, "drop", prefill=1,
                sleepfunc=throw_exception)
        ratelimit.is_buggy = False

        # The race condition was between calls to get_num_tokens() and
        # take_token(). Both methods are threadsafe (=protected by a lock).
        # To increase our chances of hitting the race condition, add some
        # artificial delay after get_num_tokens() .
        def slow_get_num_tokens(self):
            retval = self._tb._fast_get_num_tokens()
            time.sleep(0.1)
            return retval
        ratelimit._tb._fast_get_num_tokens = ratelimit._tb.get_num_tokens
        ratelimit._tb.get_num_tokens = slow_get_num_tokens

        # Create threads for multi-threaded access to $ratelimit
        helpers = []
        for count in range(10):
            helper = threading.Thread(target=use_ratelimit, args=(ratelimit,))
            helper.daemon = True
            helpers.append(helper)

        old_interval = sys.getcheckinterval()
        try:
            sys.setcheckinterval(1)
            for helper in helpers:
                helper.start()
            for helper in helpers:
                helper.join()
        finally:
            sys.setcheckinterval(old_interval)

        self.assertFalse(ratelimit.is_buggy)

    def testDecoratorForMethodWait(self):
        """Use decorator on method, policy=wait"""
        amount = 11
        rate = 17
        # Token bucket starts counting as soon as applied to function.
        start = time.time()
        class Foo(object):
            @tb.ratelimit(rate, 1, "wait")
            def foo(self):
                pass
        foo = Foo()
        # The "@ratelimit" is instantiated with a bit of prefill. This prefill
        # is min(rate, burst), which is 1 in our case. To compensate for that,
        # we take one extra token to get exactly the defined rate.
        for count in range(0, amount + 1):
            foo.foo()
        stop = time.time()
        real_rate = amount / (stop - start)
        # Must not be faster than configured rate, but at least be 98% as fast.
        self.assertLessEqual(real_rate, rate)
        self.assertGreater(real_rate, rate * 0.98)

    def testDecoratorUnlimited(self):
        """Test the 'unlimited' mode of @ratelimit"""
        # Token bucket starts counting as soon as applied to function.
        start = time.time()
        class Foo(object):
            # Unlimited rate
            @tb.ratelimit(None, None, None)
            def foo(self):
                pass
            @tb.ratelimit(None)
            def bar(self):
                pass
        amount = 1000

        foo = Foo()
        for count in xrange(amount):
            foo.foo()
            foo.bar()
        stop = time.time()

        # Since almost nothing is done, it should take almost no time.
        delta = stop - start
        if delta > 0:
            real_rate = amount / delta
            self.assertGreater(real_rate, 100000)
        else:
            # delta == 0 is perfectly fine
            pass

    def testDecoratorIndependence(self):
        """Two decorators must implement their rates independently"""
        amount = 11
        rate = 17
        # Token bucket starts counting as soon as applied to function.
        start = time.time()
        class Foo(object):
            @tb.ratelimit(rate, 1, "wait")
            def foo(self):
                pass
            @tb.ratelimit(rate, 1, "wait")
            def bar(self):
                pass

        foo = Foo()
        # The "@ratelimit" is instantiated with a bit of prefill. This prefill
        # is min(rate, burst), which is 1 in our case. To compensate for that,
        # we take one extra token to get exactly the defined rate.
        for count in range(0, amount + 1):
            foo.foo()
            foo.bar()
        stop = time.time()
        real_rate = amount / (stop - start)
        # If foo.bar() and foo.foo() used the same token bucket, we would get
        # real_rate = rate / 2
        self.assertLessEqual(real_rate, rate)
        self.assertGreater(real_rate, rate * 0.98)

class RedisTokenbucketTests(unittest2.TestCase):
    rtb = tb.RedisTokenBucket('127.0.0.1', 6379)

    def setUp(self):
        self.key = "%s" % (time.time() / random.randint(1, 1000000))

    def tearDown(self):
        redis_conn = self.rtb._get_redis_conn('127.0.0.1', 6379)
        self.rtb.delete_token(redis_conn, self.key)

    def testBasic(self):
        _s = 0
        for _ in xrange(10):
            _s += self.rtb.try_take_tokens(self.key, 1, 1)
        self.assertEqual(_s, 1)

    def testBurst(self):
        _s = 0
        for _ in xrange(10):
            _s += self.rtb.try_take_tokens(self.key, 1, 3, 5)
        self.assertLessEqual(_s, 5)
        time.sleep(2)
        _s = 0
        for _ in xrange(10):
            _s += self.rtb.try_take_tokens(self.key, 1, 3, 5)
        self.assertLessEqual(_s, 5)

    def testMoreTokensThanAvailable(self):
        _s = 0
        for _ in xrange(10):
            _s += self.rtb.try_take_tokens(self.key, 10, 3)
        self.assertEqual(_s, 0)

    def testTakeMultipleTokensAtATime(self):
        _s = 0
        for _ in xrange(10):
            _s += self.rtb.try_take_tokens(self.key, 2, 3, 10)
        self.assertEqual(_s, 1)

    def testThroughput(self):
        _s = 0
        for _ in xrange(100):
            _s += self.rtb.try_take_tokens(self.key, 1, 500)
        self.assertLessEqual(_s, 300)

    def testDeleteToken(self):
        redis_conn = self.rtb._get_redis_conn('127.0.0.1', 6379)
        self.rtb.delete_token(redis_conn, self.key)
        self.assertEqual(redis_conn.exists(self.key), False)

    def testBucketWithoutInstance(self):
        redis_conn = self.rtb._get_redis_conn('127.0.0.1', 6379)
        local_tb = tb.RedisTokenBucket
        _s = 0
        for _ in xrange(10):
            _s += local_tb.try_take_tokens_dyn_conn(redis_conn, self.key, 1, 3)
        self.assertEqual(_s, 1)

class FakeResultProxy(object):
    def __init__(self, result):
        self.result = result

    def fetchone(self):
        return self.result

class FakeEngine(object):
    def __init__(self, engine, version):
        self.engine = engine
        self.mysql_version = version

    def execute(self, sql, params=None):
        if sql.startswith("CREATE TABLE"):
            return
        elif sql.startswith("SELECT VERSION()"):
            return FakeResultProxy([self.mysql_version])
        if 'LEAST' in sql:
            sql = sql.replace('LEAST', 'min')
        if 'GREATEST' in sql:
            sql = sql.replace('GREATEST', 'max')
        if params is not None:
            sql %= params
        return self.engine.execute(sql)


class MySQLTokenbucketTests(unittest2.TestCase):
    basedir = os.path.dirname(os.path.realpath(__file__))
    SQLALCHEMY_DATABASE_URI = 'sqlite:///' + os.path.join(
            basedir, 'mysql_token_bucket.db')
    engine = sqlalchemy.create_engine(SQLALCHEMY_DATABASE_URI,
            echo=False)
    engine.execute('PRAGMA journal_mode=WAL')
    engine = FakeEngine(engine, '5.5')
    mtb = tb.MySQLTokenBucket(engine)

    def setUp(self):
        self.key = "%s" % (time.time() / random.randint(1, 1000000))

    def tearDown(self):
        self.engine.execute("delete from %s" % self.mtb.table_name)

    def testBasic(self):
        _s = 0
        for _ in xrange(10):
            _s += self.mtb.try_take_tokens(self.key, 1, 1)
        self.assertEqual(_s, 1)

    def testBurst(self):
        _s = 0
        for _ in xrange(10):
            _s += self.mtb.try_take_tokens(self.key, 1, 3, 5)
        self.assertLessEqual(_s, 5)
        time.sleep(2)
        _s = 0
        for _ in xrange(10):
            _s += self.mtb.try_take_tokens(self.key, 1, 3, 5)
        self.assertLessEqual(_s, 5)

    def testMoreTokensThanAvailable(self):
        _s = 0
        for _ in xrange(10):
            _s += self.mtb.try_take_tokens(self.key, 10, 3)
        self.assertEqual(_s, 0)

    def testTakeMultipleTokensAtATime(self):
        _s = 0
        for _ in xrange(10):
            _s += self.mtb.try_take_tokens(self.key, 2, 3, 10)
        self.assertEqual(_s, 1)

    def testThroughput(self):
        _s = 0
        for _ in xrange(100):
            _s += self.mtb.try_take_tokens(self.key, 1, 500)
        self.assertLessEqual(_s, 300)

    def testDeleteToken(self):
        engine = self.mtb.engine
        self.mtb.delete_token(engine, self.key)
        sql = "SELECT COUNT(*) FROM %s WHERE id=%%s" % self.mtb.table_name
        res = engine.execute(sql, (self.key,))
        self.assertEqual(res.fetchone()[0], 0)

    def testBucketWithoutInstance(self):
        engine = self.mtb.engine
        local_tb = tb.MySQLTokenBucket
        _s = 0
        for _ in xrange(10):
            _s += local_tb.try_take_tokens_dyn_engine(engine, self.key, 1, 1)
        self.assertEqual(_s, 1)

if __name__ == "__main__":
    unittest2.main()

