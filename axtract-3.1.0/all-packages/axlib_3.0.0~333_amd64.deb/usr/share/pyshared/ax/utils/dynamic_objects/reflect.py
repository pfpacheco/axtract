import inspect
from ax.utils.parsing import check_condition

"""
Code inspection functions

"""

def is_method(obj):
    # c-extensions appear as bulitins:
    return inspect.ismethod(obj) or inspect.isbuiltin(obj)

def get_public_callables(container, sig=None, match=''):
    """
    Return the callable functions of a module or class
    Does not return functions beginning with '_'

    :param container: Module or Class
    :param sig: function signature match
    :param match: substring match
    :rtype: List of functionnames (as strings)
    """
    res = []
    for name, method in inspect.getmembers(obj, is_method):
        if name.startswith("_"):
            continue
        if match and not check_condition(name, match):
            continue
        if not sig or inspect.getargspec(getattr(container, meth))[0] == sig:
            res.append(name)
    return res
