import datetime
import json
import numbers

from ax.utils.cron_time import CronTime

# Marker object to match any day of week/day of month/month
ALWAYS = object()
# Marker object to match no day of week/day of month/month
NEVER = object()

class RepeatSpec(object):
    """Specify time ranges that repeat on certain days

    Repeating days are specified using days_of_week, days_of_month and months.
    All of these must match for this schedule to match. If you do not want
    to have a restriction on the month, specify it as range(1, 12) or use the
    global variable ALWAYS. Proceed likewise for the other parameters.

    The intervals are lists of (start, stop) tuples. They define at which time
    of the day this spec should match.
    start<stop, start>=0 and stop<=24*60*60 (the number of seconds in a day).
    When you specify overlapping time ranges, no merging or other magic will
    occur. Everything is stored as is.

    If start or stop are provided, this spec will never match before/after those
    dates.
    """
    def __init__(self, days_of_week=ALWAYS, days_of_month=ALWAYS, months=ALWAYS,
            intervals=ALWAYS, start=None, stop=None):

        # On which days of the week this spec matches
        self.days_of_week = days_of_week

        # On which days of the month this spec matches
        self.days_of_month = days_of_month

        # In which months this spec matches
        self.months = months

        # Multiple time ranges that define on which times of the above-defined
        # days this spec should match.
        self.intervals = intervals

        # The spec will not match before start or after stop
        self.start = start
        self.stop = stop

        self.convert_values()
        self.check_values()

    def __eq__(self, other):
        # Note: It is possible to create Specs that do not compare as equal, 
        #       but still match on the same days. E.g. if one spec is for
        #       month February, days_of_month == [29] and the other is for
        #       month February, days_of_month == [29, 30, 31].
        return (self.days_of_week == other.days_of_week and
                self.days_of_month == other.days_of_month and
                self.months == other.months and
                sorted(self.intervals) == sorted(other.intervals) and
                self.start == other.start and
                self.stop == other.stop)

    def __ne__(self, other):
        return not self == other

    def __repr__(self):
        """Machine readable string representation, suitable for eval()"""
        class_template = self.__class__.__name__ + "(%s)"
        values = ("days_of_week=%r, days_of_month=%r, months=%r, "
                "intervals=%r, start=%r, stop=%r")
        values %= (self.days_of_week, self.days_of_month, self.months,
                self.intervals, self.start, self.stop)
        return class_template % values

    def __str__(self):
        return self.human_readable

    @property
    def human_readable(self):
        """Human readable string representation"""
        pieces = []
        if self.start:
            pieces.append("from %s" % self.start)
        if self.stop:
            pieces.append("until %s" % self.stop)

        dow_restricted = len(self.days_of_week) < 7
        dom_restricted = len(self.days_of_month) < 31
        if dow_restricted:
            if self.days_of_week == set([1, 2, 3, 4, 5]):
                pieces.append("on weekdays")
            elif self.days_of_week == set([6, 7]):
                pieces.append("on weekends")
            else:
                dow_to_name = {
                        1 : "Monday",
                        2 : "Tuesday",
                        3 : "Wednesday",
                        4 : "Thursday",
                        5 : "Friday",
                        6 : "Saturday",
                        7 : "Sunday"}
                day_names = map(dow_to_name.get, sorted(self.days_of_week))
                pieces.append("on %s" % (", ".join(day_names)))
        if dom_restricted:
            collapsed = self._collapse_ranges(self.days_of_month)
            pieces.append("on day of month %s" % (
                ", ".join(map(str, collapsed))))
        if not dow_restricted and not dom_restricted:
            pieces.append("every day")

        if len(self.months) != 12:
            from cron_time import MONTH_TO_NAME
            months = map(MONTH_TO_NAME.get, sorted(self.months))
            pieces.append("in " + ", ".join(months))


        interval_pieces = []
        for start, stop in self.intervals:
            start = int(start)
            stop = int(stop)
            start = "%02d:%02d:%02d" % (
                    start / 3600, (start % 3600) / 60, start % 60)
            stop = "%02d:%02d:%02d" % (
                    stop / 3600, (stop % 3600) / 60, stop % 60)
            interval_pieces.append("between %s and %s" % (start, stop))
        pieces.append(", ".join(interval_pieces))

        return " ".join(pieces)

    def convert_values(self):
        """Convert marker objects / names to numbers"""
        if self.days_of_week is ALWAYS:
            self.days_of_week = range(1, 8)
        if self.days_of_week is NEVER:
            self.days_of_week = []
        if not isinstance(self.days_of_week, set):
            self.days_of_week = set(self.days_of_week)

        if self.days_of_month is ALWAYS:
            self.days_of_month = range(1, 32)
        if self.days_of_month is NEVER:
            self.days_of_month = []
        if not isinstance(self.days_of_month, set):
            self.days_of_month = set(self.days_of_month)

        if self.months is ALWAYS:
            self.months = range(1, 13)
        if self.months is NEVER:
            self.months = []
        if not isinstance(self.months, set):
            self.months = set(self.months)

        if self.intervals is ALWAYS:
            self.intervals = [(0, 24 * 60 * 60)]
        if self.intervals is NEVER:
            self.intervals = []
        if not isinstance(self.intervals, list):
            self.intervals = list(self.intervals)

    def check_values(self):
        """Perform some basic sanity checks on our properties"""
        for day in self.days_of_week:
            if not (0 < day < 8):
                raise ValueError("Day of week '%s' is out of range." % day)

        for day in self.days_of_month:
            if not (0 < day < 32):
                raise ValueError("Day of month '%s' is out of range." % day)

        for month in self.months:
            if not (0 < month < 13):
                raise ValueError("Month '%s' is out of range." % month)

        for start, stop in self.intervals:
            if start > stop:
                raise ValueError("Interval's start is greater than its stop: "
                        "%s-%s" % (start, stop))
            if not (0 <= start <= 24 * 60 * 60):
                raise ValueError("Interval start '%s' is out of range." % start)
            if not (0 <= stop <= 24 * 60 * 60):
                raise ValueError("Interval stop '%s' is out of range." % stop)

        if not isinstance(self.start, (datetime.datetime, type(None))):
            raise ValueError("Start is neither None nor a datetime: '%s'" %
                    self.start)
        if not isinstance(self.stop, (datetime.datetime, type(None))):
            raise ValueError("Stop is neither None nor a datetime: '%s'" %
                    self.stop)

    @staticmethod
    def _collapse_ranges(int_set):
        """Convert set() of integers into sorted list with collapsed ranges.

        Turns set([1,2,3,4,5,42]) into ["1-5", 42], which is suitable input for
        self._expand_ranges(). This helps generate more compact JSON.
        """
        def terminate_range(parts, first, last):
            """Helper that is used at when the end of a range was detected"""
            if first == last:
                # Range of length 1 -> single number
                parts.append(first)
            else:
                # A real range with multiple items.
                parts.append("%d-%d" % (first, last))

        first = None
        last = None
        parts = []
        for number in sorted(int_set):
            if first is None:
                # Start a new range.
                first = last = number
                continue
            if number == last + 1:
                # This continues our current range.
                last = number
                continue
            # This does NOT continue the range. Abort current, start new range.
            terminate_range(parts, first, last)
            first = last = number

        if first is not None:
            terminate_range(parts, first, last)
        return parts

    @staticmethod
    def _expand_ranges(iterable):
        """Expand range definitions in iterable, return resulting set()

        For example, if iterable is [1, "3-5", 8], you will get back
        set([1, 3, 4, 5, 8]) since "3-5" was expanded to [3, 4, 5]
        """
        result = set()
        for item in iterable:
            if isinstance(item, numbers.Integral):
                result.add(item)
            elif isinstance(item, basestring):
                start, stop = item.split("-")
                start = int(start)
                stop = int(stop)
                if start > stop:
                    raise ValueError("Start is greater than stop: %d %d" % (
                        start, stop))
                result.update(set(xrange(start, stop + 1)))
            else:
                raise ValueError("Item is no string or integer: %r" % item)
        return result

    @classmethod
    def _adjust_json_config(cls, config):
        # JSON cannot encode datetime, so use strftime() / strptime().
        if config['start'] is not None:
            config['start'] = datetime.datetime.strptime(
                    config['start'], "%Y-%m-%d %H:%M:%S")
        if config['stop'] is not None:
            config['stop'] = datetime.datetime.strptime(
                    config['stop'], "%Y-%m-%d %H:%M:%S")
        # JSON does not know about tuples, only lists. So we need to ensure
        # that self.intervals is made of tuples.
        config['intervals'] = [tuple(interval) for interval in
                config['intervals']]
        for key in ('days_of_week', 'days_of_month', 'months'):
            config[key] = cls._expand_ranges(config[key])

    @classmethod
    def from_json(cls, json_string):
        """Returns a RepeatSpec based on a json_string"""
        config = json.loads(json_string)
        cls._adjust_json_config(config)

        new = cls(**config)
        return new

    def to_json(self, collapse_ranges=True):
        """Returns a JSON representation of this RepeatSpec

        If collapse_ranges is True, you get a much more compact representation.
        However, this format requires some extra parsing.
        """
        # Only call strftime() if the value is not None
        start = self.start and self.start.strftime("%Y-%m-%d %H:%M:%S")
        stop = self.stop and self.stop.strftime("%Y-%m-%d %H:%M:%S")

        collapser = self._collapse_ranges if collapse_ranges else list

        config = {
                'days_of_week': collapser(self.days_of_week),
                'days_of_month': collapser(self.days_of_month),
                'months': collapser(self.months),
                'intervals': self.intervals,
                'start': start,
                'stop': stop
                }
        return json.dumps(config, separators=(',', ':'))

    def matches(self, at_date=None):
        """Return True if this spec matches now (or on at_date), else False

        If no at_date is given, the check is made against the current local
        time.
        """
        at_date = at_date or datetime.datetime.now()

        # Check start/stop
        if self.start is not None and at_date < self.start:
            return False
        if self.stop is not None and at_date > self.stop:
            return False
        timetuple = at_date.timetuple()

        # Check if day matches
        # Timetuple has Monday==0, but we want Monday==1 -> use +1
        day_matches = (timetuple.tm_mon in self.months and \
                timetuple.tm_wday + 1 in self.days_of_week and \
                timetuple.tm_mday in self.days_of_month)
        if not day_matches:
            return False

        # Check if time of day matches
        fractional_second = at_date.microsecond / 1000000.0
        second_of_day = (timetuple.tm_hour * 3600 + timetuple.tm_min * 60 +
                timetuple.tm_sec + fractional_second)

        for start, stop in self.intervals:
            if start <= second_of_day and stop >= second_of_day:
                return True

        return False


class RepeatSchedule(object):
    """Represent multiple RepeatSpec objects

    This schedule will match if any of its RepeatSpec objects matches.
    """
    def __init__(self, repeat_specs=None):
        self.repeat_specs = repeat_specs or []

    def __eq__(self, other):
        if len(self.repeat_specs) != len(other.repeat_specs):
            return False

        for mine, his in zip(self.repeat_specs, other.repeat_specs):
            if mine != his:
                return False
        return True

    def __ne__(self, other):
        return not self == other

    def __repr__(self):
        return "%s(repeat_specs=[%s])" % (self.__class__.__name__,
                ", ".join(map(repr, self.repeat_specs)))

    def __str__(self):
        return self.human_readable

    @property
    def human_readable(self):
        """Human readable string representation"""
        return "will run " + ", ".join(map(str, self.repeat_specs))

    @staticmethod
    def _merge_ranges(sorted_ranges):
        """Merge a sorted list of (start, stop) tuples whereever possible

        Merging occurs for pairs like [(10, 43), (43, 100)] which is merged
        into set([(10, 100)]).
        """
        retval = set()
        if not sorted_ranges:
            return retval

        current_start, current_stop = sorted_ranges[0]
        for next_start, next_stop in sorted_ranges[1:]:
            if next_start == current_stop:
                # Can be merged.
                current_stop = next_stop
                continue
            # Cannot be merged.
            retval.add( (current_start, current_stop) )
            current_start = next_start
            current_stop = next_stop
        retval.add( (current_start, current_stop) )
        return retval

    @classmethod
    def from_cron_syntax(cls, cron_syntax):
        """For cron syntax like "* * * * *", return equivalent RepeatSchedule"""
        cron_time = CronTime(cron_syntax=cron_syntax)
        return cls.from_cron_time(cron_time)

    @classmethod
    def from_cron_time(cls, cron_time):
        """For a ax.utils.cron_time.CronTime instance, return RepeatSchedule"""
        # Create an interval tuple for every minute, store in sorted order.
        intervals = []
        minutes = cron_time.minutes
        hours = cron_time.hours
        for hour in sorted(hours):
            for minute in sorted(minutes):
                first_second = hour * 3600 + minute * 60
                intervals.append( (first_second, first_second + 60) )
        # Merge those ranges (could be up to 24*60 of them).
        intervals = cls._merge_ranges(intervals)

        # Months need no conversion at all.
        months = cron_time.month

        # Convert DOW + DOM restrictions, keeping in mind AXOS-369.
        dows = cron_time.dow
        doms = cron_time.dom
        specs = []
        if len(dows) == 7:
            # DOW is unrestricted, everything depends on DOM
            specs.append(RepeatSpec(months=months, intervals=intervals,
                days_of_month=doms))
        else:
            # DOW is restricted
            if len(doms) == 31:
                # DOM is unrestricted  --> DOW must match
                specs.append(RepeatSpec(months=months, intervals=intervals,
                    days_of_week=dows))
            else:
                # DOW and DOM are restricted --> match if one of them matches
                specs.append(RepeatSpec(months=months, intervals=intervals,
                    days_of_month=doms))
                specs.append(RepeatSpec(months=months, intervals=intervals,
                    days_of_week=dows))
        return cls(repeat_specs=specs)

    @classmethod
    def from_json(cls, json_string):
        """Returns a RepeatSchedule based on a json_string"""
        configs = json.loads(json_string)
        specs = []
        for config in configs:
            RepeatSpec._adjust_json_config(config)
            specs.append(RepeatSpec(**config))
        return cls(repeat_specs=specs)

    def to_json(self, collapse_ranges=True):
        """Returns a JSON representation of this RepeatSchedule

        If collapse_ranges is True, you get a much more compact representation.
        However, this format requires some extra parsing.
        """
        json_pieces = [spec.to_json(collapse_ranges=collapse_ranges)
                for spec in self.repeat_specs]
        return "[%s]" % ", ".join(json_pieces)

    def matches(self, at_date=None):
        """Return True if this schedule matches now (or on at_date), else False

        If no at_date is given, the check is made against the current local
        time.
        """
        date = at_date or datetime.datetime.now()
        return any((spec.matches(at_date=date) for spec in self.repeat_specs))

