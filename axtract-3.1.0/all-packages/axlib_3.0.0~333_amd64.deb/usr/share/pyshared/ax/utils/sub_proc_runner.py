#!/usr/bin/env python
"""
Start and get results from subprocesses, after a while (by a proc id).
(e.g. for tcpflowing or capturing).
Controlled for max run time via a checker.
"""

import time
from time import sleep
import os
from thread import start_new_thread
import subprocess

def start_terminating_subproc(args, shell=False, pidfile=None, kill_sig=15):
    """
    This proc dies when the caller proc dies, no questions asked.
    Only Linux C Python, clear.

    Example:
        args = 'hg serve -p %s -R "%s"' % (port, base_dir())
        start_terminating_subproc(args, shell=True, kill_sig=15)
    ->The server will be down when the parent process is down.
    """
    import ctypes
    libc = ctypes.CDLL('/lib/x86_64-linux-gnu/libc.so.6')
    # 15 -> cleans up its pidfile:
    PR_SET_PDEATHSIG = 1; TERM = kill_sig
    implant_bomb = lambda: libc.prctl(PR_SET_PDEATHSIG, kill_sig)
    p = subprocess.Popen(args, shell=shell, preexec_fn=implant_bomb)
    if pidfile:
        with open(pidfile, 'w') as f:
            f.write(str(p.pid))
    return p




def pid_alive(pid):
    import errno
    try:
        # does nothing but fails if not present:
        os.kill(int(pid), 0)
        return 1
    except OSError as exc:
        # coudl be security exception:
        if exc.errno == errno.ESRCH:
            # not running
            return
        elif exc.errno == errno.EPERM:
            # EPERM clearly means there's a process to deny access to
            return 2
        else:
            # never.should.:
            raise



# below yet more questionable stuff, use at your own risk / fix:

# the default:
MAX_RUN_SECS = 60
PROCS = {}

# Note: Code is at prototype status and only used for temporary
# tcpflow catching currently in AXPAND proxy.
# Use at your own risk, see ticket AXOS-159
"""
ax.utils.sub_proc_runner has multiple issues:

Subprocesses are not terminated. The stop_procs_runner() thread is supposed to do that, but that function returns immediately and leaves the process running. Only when you start the next process, the previous one is terminated.
Once this works, care must be taken that the stop_procs_runner thread does not prevent the program that uses sub_proc_runner from shutting down. For this, the thread must be a daemon thread. At the same time, it should still ensure that subprocesses are properly terminated.
Processes that you start will freeze after some time if they print a lot of stuff to stdout. This happens because stdout=subprocess.PIPE, and that pipe will only buffer a certain amount of data and block when more is written.
Process termination may terminate the wrong process. The process launched by sub_proc_runner may terminate for some reason (e.g. invalid command line parameters, manual kill). In that case, the stop_procs_runner() will kill the wrong process if the operating system re-used the process ID for a new process. POSIX does not allow to do this properly, but at least we can greatly reduce the chances of the race condition.
calling kill_proc() fails to return what was written to STDOUT if the stop_procs_runner terminated the process first.
Command line parameters cannot contain spaces, because start_proc() does a cmd.split(' '). This limitation results from the function's API and should at least be documented.
To address the above issues, the easiest approach would be a rewrite where 1 thread is used to control one process. The number of external processes should be low enough to make that possible.
"""



def start_proc(cmd, maxrun = MAX_RUN_SECS):
    """ start a new process and leave running maxrun seconds """
    global PROCS
    proc = subprocess.Popen(cmd.split(' '),
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            shell=False)
    procid = time.time()
    start_checker = 0
    if not PROCS:
        start_checker = 1
    PROCS[procid] = [proc, maxrun]
    if start_checker:
        start_new_thread(stop_procs_runner, ())
    return procid


def kill_proc(procid):
    """ since there are 2 kill methods (get_res and checker)
    we must catch exceptions """
    global PROCS
    try:
        proc = PROCS[procid][0]
        proc.kill()
    except Exception:
        pass
    try:
        del PROCS[procid]
    except Exception:
        pass
    try:
        return proc.communicate()[0]
    except Exception:
        return "No result - maybe expired?"


def get_proc_res(procid):
    global PROCS
    return kill_proc(procid)


def stop_procs_runner():
    """ run as thread.
    stop all running captures of 60 secs
    to not fill the RAM
    """
    global PROCS
    if not PROCS:
        # nothing to check:
        return
    now = time.time()
    for k, proc in PROCS.items():
        proc, maxrun = proc
        if now - k > maxrun:
            kill_proc(k)


#########################################
#
# Convenience meths for common processes
#
#########################################
def start_flow_capt(caller, host = None, port = None, maxrun = MAX_RUN_SECS):
    """ a tcpflow with host and port set in caller """
    host = getattr(caller, 'host', host)
    port = getattr(caller, 'port', port)
    sleep(1)
    if host and port:
        # -p: non promiscous, for stability:
        cmd = 'tcpflow -p -ec -i any host %s and port %s'\
                % (host, port)
        procid = start_proc(cmd, maxrun = maxrun)
        return [procid, cmd]
    else:
        raise Exception("No host and port set - can't capture")


# a helper to kill processes by substring match:
# needed in the axchange workbook startup profile:
def kill_procs(substrings, killmode=15):
    """ Killing all processes with one of the substrings in it

    killmode can be supplied, like '-9'
    """
    if isinstance(substrings, (str, unicode)):
        substrings = [substrings]
    killed = ''
    pids = [pid for pid in os.listdir('/proc') if pid.isdigit()]
    for pid in pids:
        try:
            with open(os.path.join('/proc', pid, 'cmdline'), 'rb') as f:
                cmdline = f.read()
        except Exception:
            # maybe closed since getting:
            continue

        for substring in substrings:
            if substring in cmdline and not 'sub_proc_runner' in cmdline:
                os.kill(int(pid), killmode)
                killed += str(pid) + ': ' + cmdline +'\n'
    if not killed:
        killed = 'nothing'
    return 'Killed %s' % killed

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 2:
        if sys.argv[1] == 'kill_procs':
            print kill_procs(sys.argv[2:])
        elif sys.argv[1] == 'force_kill_procs':
            print kill_procs(sys.argv[2:], killmode=9)


