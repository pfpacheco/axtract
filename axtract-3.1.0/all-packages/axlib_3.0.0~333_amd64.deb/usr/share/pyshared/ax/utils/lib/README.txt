In libs we store non axiros created libraries which can't be installed via setting a dependency only.

Licenses:
- bootstrap is covered by apache license, see LICENSE-APACHE
- blessings is covered by a BSD-like license, LICENSE-BLESSINGS


