import unittest
from ax.utils.parsing.parse_bytes_spec import parse

class TestParse(unittest.TestCase):

    def test_parse_bytes(self):
        self.assertEqual(1, parse('1'))
        self.assertEqual(1, parse('1b'))
        self.assertEqual(1, parse('1 b'))
        self.assertEqual(1, parse('1B'))
        self.assertEqual(1, parse('1 B'))

    def test_parse_kb(self):
        self.assertEqual(2 * 1024, parse('2kb'))
        self.assertEqual(2 * 1024, parse('2 kb'))
        self.assertEqual(2 * 1024, parse('2KB'))
        self.assertEqual(2 * 1024, parse('2 KB'))
        self.assertEqual(2 * 1024, parse('2k'))
        self.assertEqual(2 * 1024, parse('2 K'))

    def test_parse_mb(self):
        self.assertEqual(3 * 1024 ** 2, parse('3mb'))
        self.assertEqual(3 * 1024 ** 2, parse('3 mb'))
        self.assertEqual(3 * 1024 ** 2, parse('3MB'))
        self.assertEqual(3 * 1024 ** 2, parse('3 MB'))
        self.assertEqual(3 * 1024 ** 2, parse('3M'))
        self.assertEqual(3 * 1024 ** 2, parse('3 M'))

    def test_parse_gb(self):
        self.assertEqual(4 * 1024 ** 3, parse('4gb'))
        self.assertEqual(4 * 1024 ** 3, parse('4 gb'))
        self.assertEqual(4 * 1024 ** 3, parse('4GB'))
        self.assertEqual(4 * 1024 ** 3, parse('4 GB'))
        self.assertEqual(4 * 1024 ** 3, parse('4G'))
        self.assertEqual(4 * 1024 ** 3, parse('4 G'))

    def test_parse_floats(self):
        self.assertEqual(7838316851, parse('1.5kb 7.3 GB'))

    def test_parse_combo(self):
        spec = '1G 1MB'
        ref = 1074790400
        self.assertEqual(ref, parse(spec))
