import logging

class NullHandler(logging.Handler):
    """Replacement for logging.NullHandler introduced in Python2.7

    The main intention is to provide libraries with a way to log that does not
    create error messages about unconfigured logging. For details, see
    http://docs.python.org/2.7/howto/logging.html#configuring-logging-for-a-library

    Can be imported via "import ax.utils.logging.NullHandler. Once we have
    Python2.7, you just "import logging.NullHandler"
    """
    def emit(self, record):
        pass


def setup_logging_for_library(logger_name):
    """Return a logger of the given name, suitable for logging in a library.

    If logging is not configured, a NullHandler is added to the logger to
    prevent error messages on the shell.
    """
    logger = logging.getLogger(logger_name)
    # If logger already has handlers, a NullHandler would be a waste of CPU.
    if not logger.handlers:
        logger.addHandler(NullHandler())
    return logger
