import urllib
import os
from ax.utils import get_object_from_module
import inspect

""" dynamic building of classes from names and search folders """

CLASSES_CACHE = {}


def find_class_in_subdirs(class_name, sf, case_aware = True):
    """ locate the class definition in a physical file
    w/o search folder sf and return the full module name
    ready to be instantiated by get_object_by_name
    i.e. we return like 'subdir1.sub2.module_name.class_name'
    """
    # case awareness
    ca = 'i'
    if case_aware:
        ca = ''
    search_res = os.popen('grep -%sr "^class %s" %s|grep -v "\.svn"' % (ca, class_name, sf)).read()
    # that delivers back like:
    # <sf>/sub1/sub2/module:class <class_name>(params):
    for res in search_res.split('\n'):
        if res.startswith(sf):
            res = res[len(sf):].replace(':class ', '/').split('(',1)[0]
            res = res.replace('/', '.').replace('.py.', '.').strip()
            if res.startswith('.'):
                res = res[1:]
            return res


def get_class_by_name(class_name, search_folders = None, force_reload = None):
    """
    $class_name: python style, like module.class
    $search_folders: a list of folders to search for the class.
    If empty we take sys.path
    $force_reload: handy for debugging, when single threaded we 
    can reload the class via it

    NEW: if we conly supply a class_name w/o '.' (module) we search
    the search path for the file containing 'class <name>' and use it
    """
    exceptions = ''
    o_class = CLASSES_CACHE.get(class_name)
    # the reload flag is really just for debug runs, won't work if 
    # the module is in use at another thread!
    if o_class and force_reload:
        module = '.'.join(class_name.split('.')[:-1])
        del sys.modules[module]
        del CLASSES_CACHE[class_name]
        o_class = None

    if o_class:
        return o_class

    if not search_folders:
        # search only paths in axos:
        search_folders = '.'

    if type(search_folders) in (str, unicode):
        search_folders = [search_folders,]
        
    for sf in search_folders:
        if not '.' in class_name:
            class_name_with_module = find_class_in_subdirs(class_name, sf)
            if not class_name_with_module:
                continue
        else:
            class_name_with_module = class_name

        try:
            o_class = get_object_from_module(class_name_with_module, sf)
            break
        except Exception, ex:
            exceptions += '\n  when trying folder %s: %s, ' % (sf, ex)
            pass

    if not o_class:
        raise Exception, "Class %s not found. Supply 'class' argument like a.b.c where c is a class in the module a.b within sys.path or search folders (%s).\nExceptions seen while searching folders: %s" % \
                (class_name, search_folders, exceptions[:-2])
    CLASSES_CACHE[class_name] = o_class
    return o_class


def get_class_by_name_with_mix_in(class_name, search_folders = None, \
        force_reload = None, mix_in = None):
    """ a mix_in by name or class into the main class.
    Caution: this can only be done ONCE, processwide, the classloader only loads a class once!
    # we tag if it's already done and refuse to mix anything else in.
    """
    o_class = get_class_by_name(class_name, search_folders, force_reload)
    if mix_in and not hasattr(o_class, '_mix_in_present'):
        if not inspect.isclass(mix_in):
            mix_in_class = get_class_by_name(mix_in, search_folders, force_reload)
        o_class.__bases__ += (mix_in_class,)
        setattr(o_class, '_mix_in_present', True)
    return o_class


def get_class_via_uri (uri):
    """ getting a class from the source code string loaded from somewhere
    is curently deemed too unsecure"""
    raise NotImplemented
    try:
        file_obj = urllib.urlopen(uri)
        code = file_obj.read()
        file_obj.close()
        del(file_obj)
    except Exception, exc:
        raise Exception("Error while loading external mix_in resource from %s: %s"\
            % (mix_in, exc))

    # a first start of implementation, can't mess globals in production:
    classname = code.split('\nclass ',1)[1].split(':')[0]
    exec compile(codestring, "<class>", "exec")
    return globals().get(classname)


#############
#
# TESTS
# 
#############
class test1( object):
    def test1(self):
        return 'test1'

class test2(object):
    # mix in must sometimes (pattern not yet understood) by oldstyle
    # otherwise we get an MRO exception (search order not consistent)
    def test1(self):
        return 'test1.2'

    def test2(self):
        return 'test2'


if __name__ == "__main__":
    
    import sys
    sys.path.append('.')
    os.system('mkdir -p test_dir/subdir2/')
    os.system('touch test_dir/__init__.py')
    os.system('touch test_dir/subdir2/__init__.py')
    open('test_dir/subdir2/mod.py', 'w').write\
            ('class WorldClass (object): pass')
    cl = find_class_in_subdirs('WorldClass', '.')
    assert cl == 'test_dir.subdir2.mod.WorldClass'
    cl = find_class_in_subdirs('worldclass', '.', case_aware = None)
    assert cl == 'test_dir.subdir2.mod.WorldClass'
    assert cl == 'test_dir.subdir2.mod.WorldClass'
    cl = get_class_by_name('WorldClass', search_folders = '.')
    assert str(cl.__module__) == 'test_dir.subdir2.mod'
    os.system('rm -rf test_dir')



    mc = get_class_by_name_with_mix_in('class_loader.test1', mix_in = 'class_loader.test2')
    mc1 = get_class_by_name_with_mix_in('class_loader.test1', mix_in = 'class_loader.test2')
    assert mc == mc1
    assert mc1().test1() == 'test1'
    assert mc().test2() == 'test2'
    print "Tests passed"



