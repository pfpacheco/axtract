import hashlib
import time
def web_md5 (challenge, secret):
    response = '%s-%s' % (challenge, secret)
    response = hashlib.md5(response.encode('UTF-16LE')).hexdigest()
    response = '%s-%s' % (challenge, response)
    return response


def client_cache(expiry_secs, set_func):
    """ call like: client_cache(3600, reponse.setHeaders) on zope or
                   client_cache(3600, headers.set) on dict style headers.
    """
    set_func('Cache-Control', 'max-age=%s, must-revalidate' % expiry_secs)
    set_func('Expires', time.strftime('%a, %d %b %Y %H:%M:%S %Z',
                        time.gmtime(time.time() + 86400)))

