# coding: utf-8
"""
Password generators
"""
def pw_gen(user=None, oldpw=None, pwtype=None, symbols=None):
    """ pw gen with reasonable policies """
    from random import randint

    min = 8
    max = 16
    nums = '0123456789'
    strs = 'abcdefghijklmnopqrstuvwxyz'
    ustrs = 'ABCDEFGHIJKLMNOPQRSTUFVXZY'
    # no % !! (we match for string substitutions often:
    if symbols == None:
        symbols = '!@$^*()_{}|'

    if pwtype == 'SIPPassword':
        symbols = "_*!@?$."

    def check_policies(pw):
        # Das Passwort muss eine Länge von mindestens 8 Zeichen und maximal 16 Zeichen haben.
        if len(pw) < min or len(pw) > max:
            return
        # Alle folgenden Zeichentypen müssen enthalten sein:
        # Numerisch, Alphanumerisch klein, Symbol (nicht Alphanumerisch).
        for t in (nums, strs, symbols, ustrs):
            if not t:
                # symbols may be empty, e.g.:
                continue
            got_one = 0
            for char in t:
                if char in pw:
                    got_one = 1
                    break
            if not got_one:
                return
        # Jedes Zeichen darf maximal dreimal verwendet werden
        for char in pw:
            if pw.count(char) > 3:
                return
        # das Passwort darf nicht gleich dem Benutzernamen und dem letzten Passwort sein:
        if user and pw == user:
            return
        if oldpw and pw == oldpw:
            return
        # tschakka:
        return 1

    all = nums + strs + symbols + ustrs

    for j in xrange(10000):
        pw = ''
        chars = 8 + randint(0, 7)
        for i in xrange(chars):
            pw += all[randint(0, len(all)-1)]
        if check_policies(pw):
            break
        pw = ''
    if not pw:
        raise Exception("Failed pw creation")    
    return pw


