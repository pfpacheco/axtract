# the decision point which python funcs to call
from urlparse import urlsplit
from django.shortcuts import render_to_response
from django.conf import settings


def render_request(r, t, c={}):
    ctx = {}
    usplit = urlsplit(r.URL)
    ctx['url_split'] = usplit
    p = usplit.path.rsplit('/', 1)
    ctx['STATIC_URL'] = ('./' + p[1] + settings.STATIC_URL).replace('//', '/')
    ctx.update(c)
    return render_to_response(t, ctx).content

