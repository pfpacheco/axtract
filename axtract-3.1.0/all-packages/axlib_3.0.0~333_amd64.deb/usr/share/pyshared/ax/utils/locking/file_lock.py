import os
import errno
import time
# In Python version smaller than 2.5 with-statement and 'context'-managers are
# not available. The current class can be used in a 'with'-statment.
# the public interface (lock/unlock) is for python-version smaller 2.5
class MachineWideFileLock(object):
    def __init__(self, filename, file_txt=None, maxwait=-1):
        self.filename = filename
        self.maxwait = maxwait
        self._fd = None
        self.file_txt = file_txt

    def __enter__(self, maxwait=-1):
        """Acquire the lock. Return None if operation successful, else -1"""
        # If self.filename was a relative path, ensure we find the file, even
        # if the process changes its working directory.
        self.filename = os.path.abspath(self.filename)

        if maxwait == -1:
            maxwwait = self.maxwait

        if maxwait > -1:
            tstart = time.time()
        while True:
            try:
                self._fd = os.open(
                        self.filename, os.O_CREAT | os.O_EXCL | os.O_WRONLY
                                  )
                if self.file_txt:
                    os.write(self._fd, self.file_txt)
                return
            except OSError, e:
                if e.errno ==  errno.EEXIST:
                    if maxwait > -1:
                        # indicate that we did not get the lock:
                        if time.time() > tstart + maxwait:
                            return -1
                        else:
                            time.sleep(0.05)
                    else:
                        time.sleep(0.01)
                else:
                    raise

    def __exit__(self, ex_type, ex_value, trace):
        os.close(self._fd)
        os.remove(self.filename)
        # Return false => DONT supress exceptions
        return False

    # only for 2.4 and smaller - or if nowait is needed:
    def lock(self, maxwait=-1):
        return self.__enter__(maxwait=maxwait)

    def unlock(self):
        self.__exit__(None, None, None)

    def try_unlock(self):
        """ if maxwait was reached then we might not have a filehandle """
        try:
            os.close(self._fd)
        except Exception:
            pass
        try:
            os.remove(self.filename)
        except Exception:
            pass


class FileLock(MachineWideFileLock):
    """ shorter name for what it does """
    pass
