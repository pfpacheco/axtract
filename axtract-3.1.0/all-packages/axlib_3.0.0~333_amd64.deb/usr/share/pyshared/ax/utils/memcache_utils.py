from Queue import Queue
from cmemcached import Client #@UnresolvedImport

# MY pool benchmarks on the laptop dont show a significant speedup
class MemCachePool(object):
    def __init__(self, host, port):
        self.queue = Queue()
        for i in range(7):
            self.queue.put(Client(['%s:%s'%(host, port)]))

    def disconnect_all(self):
        for i in range(7):
            con = self.queue.get()
            con.disconnect_all()

    def get(self, key):
        con = self.queue.get()
        try:
            return con.get(key)
        finally:
            self.queue.put(con)
    def set(self, key, value):
        con = self.queue.get()
        try:
            con.set(key, value)
        finally:
            self.queue.put(con)
