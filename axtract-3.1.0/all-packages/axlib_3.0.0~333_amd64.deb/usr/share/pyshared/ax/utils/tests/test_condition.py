#!/usr/bin/python -tt
import unittest2
from time import time
from ax.utils.ax_tree import AXTree
from ax.utils.condition import sanitize_input, parse, evaluate
from ax.utils.condition import to_mongo_aggregation, \
        to_mongo_filter, \
        to_axsearch_filter
ev = evaluate

class Tools:
    '''removing a bit of clutter for the assertions, we need 100s of them...'''
    eq    = lambda self, v, *a: self.assertEqual(v, ev(*a))
    true  = lambda self, *a: self.eq(True , *a)
    false = lambda self, *a: self.eq(False, *a)
    @property
    def true_false(self):
        return self.true, self.false


class ConditionTests(unittest2.TestCase, Tools):
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_sanitize_input_re1(self):
        s = 'group*'
        self.assertEqual(sanitize_input(s), "^group.*$")

    def test_sanitize_input_re2(self):
        s = 'group\*'
        self.assertEqual(sanitize_input(s), "^group\\*$")

    def test_sanitize_input_re3(self):
        s = 'group.*'
        self.assertEqual(sanitize_input(s), "^group\\..*$")

    def test_sanitize_input_re4(self):
        s = 'group*\*\**'
        self.assertEqual(sanitize_input(s), "^group.*\*\*.*$")

    def test_sanitize_input_mysql1(self):
        s = 'group*'
        self.assertEqual(sanitize_input(s, 'mysql'), "group%")

    def test_sanitize_input_mysql2(self):
        s = 'group\*'
        self.assertEqual(sanitize_input(s, 'mysql'), "group*")

    def test_sanitize_input_mysql3(self):
        s = 'group.?*'
        self.assertEqual(sanitize_input(s, 'mysql'), "group.?%")

    def test_sanitize_input_mysql4(self):
        s = 'group\h'
        self.assertEqual(sanitize_input(s, 'mysql'), "group\h")

    def test_sanitize_input_mysql5(self):
        s = 'group\h\g\\'
        self.assertEqual(sanitize_input(s, 'mysql'), "group\h\g\\")

    def test_empty(self):
        condition = []
        context = AXTree({
            "cpe": {
                "cpetype": "genericTR69"
            },
            "other": 1
        })
        self.assertEqual(True, evaluate(condition, context))


    def test_simple_condition(self):
        condition = ["cpe.cpetype", "=", "genericTR69"]
        context = AXTree({
            "cpe": {
                "cpetype": "genericTR69"
            },
            "other": 1
        })
        self.assertTrue(ev(condition, context))

    def test_equal_operation(self):
        condition = ["cpe.cpetype", "=", "genericTR69"]
        context = AXTree({
            "cpe": {
                "cpetype": "genericTR69"
            },
            "other": 1
        })
        self.assertTrue(ev(condition, context))

    def test_less_operation(self):
        condition = ["param", "<", 5]
        context = AXTree({
            "param": 1
        })
        self.assertTrue(ev(condition, context))

    def test_lessequals_operation(self):
        condition = ["param", "<=", 5]
        context = AXTree({
            "param": 5
        })
        self.assertTrue(ev(condition, context))

    def test_greater_operation(self):
        condition = ["param", ">", 5]
        context = AXTree({
            "param": 8
        })
        self.assertTrue(ev(condition, context))

    def test_greaterequals_operation(self):
        condition = ["param", ">=", 5]
        context = AXTree({
            "param": 8
        })
        self.assertTrue(ev(condition, context))

    def test_or_operation(self):
        condition = [True, "or", False]
        context = AXTree({
            "param": 8
        })
        self.assertTrue(ev(condition, context))

    def test_and_operation(self):
        condition = [True, "and", False]
        context = AXTree({
            "param": 8
        })
        self.assertEqual(False, ev(condition, context))


    def test_and_not_operation(self):
        cond = parse('''a in abcd,and not,a in cdef''', sep=',')
        self.assertTrue (ev(cond, {'a': 'abc'}))
        self.assertFalse(ev(cond, {'a': 'cd' }))


    def test_or_not_operation(self):
        T, F = self.true_false
        cond = parse('''a in abcd,or not,a in cdef''', sep=',')
        T(cond, {'a': 'abc'})
        T(cond, {'a': 'cd' })
        T(cond, {'a': 'xx' })
        F(cond, {'a': 'def'})


    def test_another_in_operation(self):
        condition = ["cpe.cpeid", "in", ["FF11", "FF22"]]
        context = AXTree({
            "cpe": {
                "cpeid": "FF11"
            }
        })
        self.assertTrue(ev(condition, context))


    def test_in_operation(self):
        T, F = self.true_false
        condition = ["param", "in", ["value1", "value2", "value3"]]
        context = { "param": "value1" }
        T(condition, context)
        context['param'] = 'value4'
        F(condition, context)
        condition[1] = 'not in'
        T(condition, context)

    def test_contains_operation(self):
        T, F = self.true_false
        condition = ["param", "contains", "value1"]
        context = { "param": ["value1", 'value2']}
        T(condition, context)
        context['param'] = ['value4']
        F(condition, context)
        condition[1] = 'not contains'
        T(condition, context)


    def test_starts_operation(self):
        T, F = self.true_false
        condition = ["param", "starts", '/Foo/Bar']
        context = { "param": "/Foo/Bar/baz" }
        T(condition, context)
        context = { "param": "/Bar/baz" }
        F(condition, context)
        condition[1] = 'not starts'
        T(condition, context)


    def test_ends_operation(self):
        T, F = self.true_false
        condition = ["param", "ends", '/Foo/Bar']
        context = { "param": "A//Foo/Bar" }
        T(condition, context)
        context = { "param": "/Bar/baz" }
        F(condition, context)
        condition[1] = 'not ends'
        T(condition, context)


    def test_complex_right(self):
        condition = [
            ["param1", "=", 5],
            'or',
            [
                ["param2", "=", False],
                "and",
                ["param3", "=", True]
            ]
        ]
        context = AXTree({
            "param1": 5,
            "param2": True,
            "param3": False
        })
        self.assertTrue(ev(condition, context))

    def test_complex_left(self):
        condition = [
            [
                ["param2", "=", False],
                "and",
                ["param3", "=", True]
            ],
            'or',
            ["param1", "=", 5]
        ]
        context = AXTree({
            "param1": 5,
            "param2": True,
            "param3": False
        })
        self.assertTrue(ev(condition, context))

    def test_complex(self):
        condition = [
            [
                [
                    ["cpe.cpetype", "=", "genericTR69"],
                    "or",
                    ["cpe.cpetype", "=", "avm"],
                ],
                "and",
                [
                    ["cpe.roles", "intersects", ["unsupportedFW", 'WiFi']],
                    "or",
                    ["cpe.roles", "intersects", ["supportedFW"]]
                ]
            ],
            "or",
            [
                ["cpe.cpeid", "=", "cpe1"],
                "and",
                ["cpe.cpeid", "=", "cpe2"]
            ]
        ]
        context = AXTree({
            "cpe": {
                "cpetype": "genericTR69",
                "roles": ["unsupportedFW", "VoIP", "WiFi"],
                "cpeid": "cpe2"
            },
            "whatever": "ok"
        })
        T, F = self.true_false
        T(condition, context)
        context['cpe.roles'].remove('unsupportedFW')
        T(condition, context)
        context['cpe.roles'].remove('WiFi')
        F(condition, context)

    def test_complex2(self):
        condition = [
            ["cond1", "=", 1],
            'and',
            ["cond2", "=", 2],
            'and',
            ["cond3", "=", 3],
            'and',
            ["cond4", "=", 4],
            "and",
            [
                ["cond5", "intersects", [1]],
                "or",
                ["cond5", "intersects", [4]]
            ]
        ]
        context = {
            "cond1": 1,
            "cond2": 2,
            "cond3": 3,
            "cond4": 4,
            "cond5": [1, 5]
        }
        self.assertEqual(True, evaluate(condition, context))

        context = {
            "cond1": 1,
            "cond2": 2,
            "cond3": 3,
            "cond4": 4,
            "cond5": [3, 5]
        }
        self.assertEqual(False, evaluate(condition, context))

    def test_tr069(self):
        condition = ["cpe.events", "intersects", ["2 PERIODIC"]]
        context = AXTree({'cpe': {'IP': '127.0.0.1',
        'cid': '',
        'cid2': '',
        'comments': '',
        'cpeid': 'ZZ0000000001',
        'cpetype': 'genericTR69',
        'events': ['2 PERIODIC'],
        'firstMsg': 1475150918,
        'lastMsg': 1481298039,
        'logLevel': 5,
        'methods': [{'envelopeId': 'I-1-1481298039.13935',
                     'id': 'processInform',
                     'initargs': '',
                     'processing': 1,
                     'step': '0',
                     'ts': 1481298039.139414}],
        'nextDue': 0,
        'parentID': '-',
        'path': '/initial',
        'pendingProps': {},
        'props': {'D': {'DI': {'HV': 'HardwareVersion1',
                               'M': 'LoadClient',
                               'MN': 'ModelName',
                               'MO': 'FAFAFA',
                               'PC': 'Test',
                               'PrC': '',
                               'SN': 'ZZ0000000001',
                               'SV': 'version1',
                               'SpV': '1.011',
                               'UT': 1600},
                        'MS': {'CRP': 'n9KA9dRFvZSI',
                               'CRU': 'http://localhost:35000/cpeid/ZZ0000000001',
                               'CRUs': '',
                               'P': 'femtocell',
                               'PIE': 1,
                               'PII': 5,
                               'U': 'http://localhost:9675/live/CPEManager/CPEs/genericTR69',
                               'UM': 0}}},
        'protocolVersion': 'cwmp-1-1',
        'roles': '',
        'scProps': {'_last_retry_count': 0, 'myflag': False},
        'state': 7,
        'unmanagedProps': [],
        'version': 'version1__HardwareVersion1__1.011'}})
        self.assertTrue(ev(condition, context))
        self.assertTrue(ev(["cpe.events", "not intersects", ["x"]], context))

    def test_is_operator(self):
        condition = ['cpe.cid', 'is', 43]
        context = AXTree({
            "cpe": {
                "cid": 45
            }
        })
        self.assertEqual(False, evaluate(condition, context))

    def test_is_operator2(self):
        condition = ['cpe.cid', 'is', None]
        context = AXTree({
            "cpe": {
                "cid": None
            }
        })
        self.assertEqual(True, evaluate(condition, context))

    def test_is_not_operator(self):
        condition = ['cpe.cid', 'is_not', 43]
        context = AXTree({
            "cpe": {
                "cid": 45
            }
        })
        self.assertEqual(True, evaluate(condition, context))

    def test_is_operator2(self):
        condition = ['cpe.cid', 'is_not', None]
        context = AXTree({
            "cpe": {
                "cid": None
            }
        })
        self.assertEqual(False, evaluate(condition, context))

    def test_like_operator1(self):
        uinput = "group*"
        condition = ['cpe.cid', 'like', uinput]
        context = AXTree({
            "cpe": {
                "cpetype": "genericTR69",
                "roles": ["unsupportedFW", "VoIP", "WiFi"],
                "cpeid": "cpe2",
                "cid": "group123"
            },
            "whatever": "ok"
        })
        self.assertEqual(True, evaluate(condition, context))

    def test_like_operator2(self):
        uinput = "group\*"
        condition = ['cpe.cid', 'like', uinput]
        context = AXTree({
            "cpe": {
                "cpetype": "genericTR69",
                "roles": ["unsupportedFW", "VoIP", "WiFi"],
                "cpeid": "cpe2",
                "cid": "group*"
            },
            "whatever": "ok"
        })
        self.assertEqual(True, evaluate(condition, context))

    def test_like_operator2(self):
        uinput = "group\*"
        condition = ['cpe.cid', 'like', uinput]
        context = AXTree({
            "cpe": {
                "cpetype": "genericTR69",
                "roles": ["unsupportedFW", "VoIP", "WiFi"],
                "cpeid": "cpe2",
                "cid": "group*"
            },
            "whatever": "ok"
        })
        self.assertEqual(True, evaluate(condition, context))

    def test_not_like_operator(self):
        uinput = "group*"
        condition = ['cpe.cid', 'not like', uinput]
        context = AXTree({
            "cpe": {
                "cpetype": "genericTR69",
                "roles": ["unsupportedFW", "VoIP", "WiFi"],
                "cpeid": "cpe2",
                "cid": "AAAAAA"
            },
            "whatever": "ok"
        })
        self.assertEqual(True, evaluate(condition, context))

    def test_many_ands(self):
        condition = [
          ['cond1', '=', 1],
          'and',
          ['cond2', '=', 2],
          'and',
          ['cond3', '=', 3],
          'and',
          ['cond4', '=', 4]
        ]

        context = {
           "cond1": 1,
           "cond2": 2,
           "cond3": 3,
           "cond4": 4
        }
        self.assertEqual(True, evaluate(condition, context))

        context = {
           "cond1": 1,
           "cond2": 2222222222,
           "cond3": 3,
           "cond4": 4
        }
        self.assertEqual(False, evaluate(condition, context))

    """
    def test_like_operator3(self):
        uinput = "group+yes"
        condition = ['cpe.cid', 'like', uinput]
        context = AXTree({
            "cpe": {
                "cpetype": "genericTR69",
                "roles": ["unsupportedFW", "VoIP", "WiFi"],
                "cpeid": "cpe2",
                "cid": "groupAAAyes"
            },
            "whatever": "ok"
        })
        self.assertEqual(True, evaluate(condition, context))

    def test_like_operator4(self):
        uinput = "group?yes"
        condition = ['cpe.cid', 'like', uinput]
        context = AXTree({
            "cpe": {
                "cpetype": "genericTR69",
                "roles": ["unsupportedFW", "VoIP", "WiFi"],
                "cpeid": "cpe2",
                "cid": "groupAByes"
            },
            "whatever": "ok"
        })
        self.assertEqual(False, evaluate(condition, context))

    def test_like_operator5(self):
        uinput = "group?yes"
        condition = ['cpe.cid', 'like', uinput]
        context = AXTree({
            "cpe": {
                "cpetype": "genericTR69",
                "roles": ["unsupportedFW", "VoIP", "WiFi"],
                "cpeid": "cpe2",
                "cid": "groupAyes"
            },
            "whatever": "ok"
        })
        self.assertEqual(True, evaluate(condition, context))

    def test_like_operator6(self):
        uinput = "group*.*.\*lala?\??lolo+\+*"
        condition = ['cpe.cid', 'like', uinput]
        context = AXTree({
            "cpe": {
                "cpetype": "genericTR69",
                "roles": ["unsupportedFW", "VoIP", "WiFi"],
                "cpeid": "cpe2",
                "cid": "groupAA.BBBB.*lalaX?XloloXXX+AA",
            },
            "whatever": "ok"
        })
        self.assertEqual(True, evaluate(condition, context))

    def test_like_operator7(self):
        uinput = "+"
        condition = ['cpe.cid', 'like', uinput]
        context = AXTree({
            "cpe": {
                "cpetype": "genericTR69",
                "roles": ["unsupportedFW", "VoIP", "WiFi"],
                "cpeid": "cpe2",
                "cid": "AAA"
            },
            "whatever": "ok"
        })
        self.assertEqual(True, evaluate(condition, context))
    """


class TemplateConditionsTests(unittest2.TestCase):
    def test_one(self):
        cond = [['foo', '=', 'bar%(ph)s'], 'or', ['a', '=', '%b']]
        self.assertTrue(ev(cond, {'foo': 'barbar'}, {'ph': 'bar'}))
        self.assertTrue(ev(cond, {'a': '%b'}, {'ph': 'bar'}))



class ConvenienceFuncTests(unittest2.TestCase):
    ''' check also the utils.aaa.http tests'''
    def test_multiline1(self):
        s = '''
        foo = bar
        or
        bar = foo'''
        cond = [['foo', '=', 'bar'], 'or', ['bar', '=', 'foo']]
        self.assertEqual(parse(s), cond)

    def test_multiline2(self):
        s = '''
        foo = bar
        bar = foo'''
        cond = [['foo', '=', 'bar'], 'and', ['bar', '=', 'foo']]
        self.assertEqual(parse(s), cond)

    def test_multiline3(self):
        s = '''
        foo = bar
        or
            a = b
            b = c
        '''

        cond = [['foo', '=', 'bar'], 'or', [['a', '=', 'b'], 'and', ['b', '=', 'c']]]
        self.assertEqual(parse(s), cond)

    def test_sep(self):
        s = 'foo = bar,or, a = b, b = c'
        cond = [['foo', '=', 'bar'], 'or', [['a', '=', 'b'], 'and', ['b', '=', 'c']]]
        self.assertEqual(parse(s, sep=','), cond)


    def test_multiline_deep(self):
        s = '''
        role = admin
        or
            role = ent_adm
            path starts string with spaces
        or
            role = ent_ops
            path starts /Ent/%(ent_id)s/
                    verb = get
                    foo in path
                or
                    verb in post, put
                    ops in path
        '''
        cond=[['role', '=', 'admin'],
              'or',
              [['role', '=', 'ent_adm'], 'and', ['path', 'starts', 'string with spaces']],
              'or',
              [['role', '=', 'ent_ops'],
               'and',
               ['path', 'starts', '/Ent/%(ent_id)s/'],
               'and',
               [[['verb', '=', 'get'], 'and', ['foo', 'in', 'path']],
                'or',
                [['verb', 'in', 'post, put'], 'and', ['ops', 'in', 'path']]]]]
        self.assertEqual(parse(s), cond)


class TestReversion(unittest2.TestCase, Tools):
    def test_rev_in(self):
        T, F = self.true_false
        cond = ['event_code', 'rev in', '0 BOOT']
        ect = ['0 BOOT', 'x', 'y']
        for ec in ect, tuple(ect), ' '.join(ect):
            T(cond, {'event_code': ec})
        ect.remove('0 BOOT')
        F(cond, {'event_code': ect})
        cond[1] = 'rev not in'
        T(cond, {'event_code': ect})





# don't run tests at import:
uc_url_cond = lambda: parse('''
    role = admin
    or
        role = ent_adm
        path starts /Ent/%(ent_id)s/
    or
        role = ent_ops
        path starts /Ent/%(ent_id)s/
            verb = get
            or
                verb in put post
                path contains /ops/
    ''')

class TestCache(unittest2.TestCase, Tools):
    def test_speed(self):
        '''cache perf effect at 100% hit rate'''
        from ax.utils.condition import evaluate_cached as ec
        c, props = uc_url_cond(), {'ent_id': '234'}
        facts = { 'role': 'ent_ops', 'path': '/Ent/1234/ops/', 'verb': 'put' }
        cps = tuple(props.values() + facts.values())
        ec('mycond', cps, c, facts, props) # -> hot
        t1 = time()
        for i in range(1000):
            ev(c, facts, props)
        dt = time() - t1
        t1 = time()
        for i in range(1000):
            ec('mycond', cps, c, facts, props)
        dt2 = time() - t1
        print '\nCache Perf Speedup:', dt / dt2
        self.assertGreater(dt, dt2 * 5)


class UC_UrlConditionTests(unittest2.TestCase, Tools):
    ''' Use case test'''

    def test_cond(self):
        path = '/AX/Foo'
        condition = ['path', 'starts', '/AX']
        facts = {'path': path}
        self.eq(True, condition, facts)


    def test_cond1(self):
        T, F = self.true_false
        c, props = uc_url_cond(), {'ent_id': '1234'}
        T(c, {'role': 'ent_adm', 'path': '/Ent/1234/'}, props)
        F(c, {'role': 'ent_adm', 'path': '/Ent/1234' }, props)
        F(c, {'role': 'ent_adm', 'path': 'Ent/1234/'}, props)
        for v in 'get', 'post', 'put':
            T(c, { 'role': 'ent_ops'
                 , 'path': '/Ent/1234/ops/'
                 , 'verb': v}
              , props)
        F(c, { 'role': 'ent_ops'
             , 'path': '/Ent/1234/ops'
             , 'verb': 'delete'}
          , props)

class AXSearchTranslationsTests(unittest2.TestCase, Tools):
    def test_basic_filter(self):
        cond = ['a', '=', 4]
        res = (('crits[0][field]', 'a'),
               ('crits[0][value][operator]', 'eq'),
               ('crits[0][value][value]', 4),
               ('crits[0][precondition]', 'is'),
               ('crits[0][and_or_or]', 'and'))
        self.assertEqual(to_axsearch_filter(cond), res)

    def test_complex_filter(self):
        cond = [
            ['a', '=', 4],
            'and',
            ['b', '>=', 5],
            'or',
            ['c', '=', 'OK']
        ]
        res = (('crits[0][field]', 'a'),
               ('crits[0][value][operator]', 'eq'),
               ('crits[0][value][value]', 4),
               ('crits[0][precondition]', 'is'),
               ('crits[0][and_or_or]', 'and'),
               ('crits[1][field]', 'b'),
               ('crits[1][value][operator]', 'gte'),
               ('crits[1][value][value]', 5),
               ('crits[1][precondition]', 'is'),
               ('crits[1][and_or_or]', 'or'),
               ('crits[2][field]', 'c'),
               ('crits[2][value]', 'OK'),
               ('crits[2][precondition]', 'is'),
               ('crits[2][and_or_or]', 'and'),
               ('search_type', 'crits'))
        self.assertEqual(to_axsearch_filter(cond), res)

    def test_nested(self):
        cond = [
            ['a', '=', 4],
            'and',
            [
                ['b', '>=', 5],
                'or',
                ['c', '=', 'OK']
            ]
        ]
        with self.assertRaises(Exception) as context:
            to_axsearch_filter(cond)
            self.assertTrue('Nested conditions are not supported' in context.exception)


class MongoTransaltionsTests(unittest2.TestCase, Tools):

    def test_basic_filter(self):
        cond = ['a', '=', 4]
        self.assertEqual(to_mongo_filter(cond), {'a': {'$eq': 4}})
        self.assertEqual(to_mongo_aggregation(cond), {'$eq': ['$a', 4]})

    def test_complex_filter(self):
        cond = [
            ['a', '=', 4],
            'and',
            ['b', '>=', 5],
            'and',
            [
                ['c', '<', 6],
                'or',
                ['d', '<=', 7]
            ],
            'and',
            [
                ['e', '!=', 8],
                'or',
                [
                    ['f', '>', 9],
                    'and',
                    ['g', '=', 6]
                ]
            ]
        ]
        filter_ = {'$and': [
            {'a': {'$eq': 4}},
            {'$and': [
                {'b': {'$gte': 5}},
                {'$and': [
                    {'$or': [
                       {'c': {'$lt': 6}},
                       {'d': {'$lte': 7}}
                    ]},
                    {'$or': [
                        {'e': {'$ne': 8}},
                        {'$and': [
                            {'f': {'$gt': 9}},
                            {'g': {'$eq': 6}}
                        ]}
                    ]}
                ]}
            ]}
        ]}

        aggregation_ = {'$and': [
            {'$eq': ['$a', 4]},
            {'$and': [
                {'$gte': ['$b', 5]},
                {'$and': [
                    {'$or': [
                        {'$lt': ['$c', 6]},
                        {'$lte': ['$d', 7]}
                    ]},
                    {'$or': [
                        {'$ne': ['$e', 8]},
                        {'$and': [
                            {'$gt': ['$f', 9]},
                            {'$eq': ['$g', 6]}
                        ]}
                    ]}
                ]}
            ]}
        ]}
        self.assertEqual(to_mongo_filter(cond), filter_)
        self.assertEqual(to_mongo_aggregation(cond), aggregation_)


if __name__ == "__main__":
    unittest2.main()
