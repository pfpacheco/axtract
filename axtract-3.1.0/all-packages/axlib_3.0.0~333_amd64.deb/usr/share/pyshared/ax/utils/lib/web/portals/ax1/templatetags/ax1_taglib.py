from django import template
register = template.Library()


# test filter:
@register.filter
def ax_hello(var='unknown'):
    return 'hello <b>%s</b>' % var


# test tag:
class AXGreeterNode(template.Node):
    def render(self, context):
        return 'hi'
@register.tag
def ax_greeter(parser, token):
    return AXGreeterNode()


# simpletag:
@register.simple_tag
def simple_greeter(context, who):
    import ipdb; ipdb.set_trace()
    return "hi <b>%(who)s</b>" % context

def _str(s):
    return isinstance(s, (str, unicode))

BS_MENU = '<li><a href="#ax_%s">%s</a></li>'
@register.simple_tag(takes_context=True)
def build_menu(context, section):
    mod = context.get('MODULES')[section]
    subsects = None
    if hasattr(mod, 'get_subsections'):
        subsects = mod.get_subsections(context)

    if not subsects:
        return BS_MENU % (section, section)


    ret = ['<li class="dropdown">',
           ("""<a href="#" class="dropdown-toggle" data-toggle="dropdown">"""
            """%s <b class="caret"></b></a>""") %  section,
           '<ul class="dropdown-menu">'
           ]
    for s in subsects:
        if _str(s):
            ret.append(BS_MENU % ('%s_%s' % (section, s), s))
        else:
            if _str(s.values()[0]):
                name, link = s.items()[0]
                ret.append(BS_MENU % (link, name))
                continue

            # s is 1 elem map like: {'Skin': [{'Slate': 'link'}, {'Syborg': 'link2'}]},
            ret.append('<li class="divider"></li>')
            ret.append('<li class="nav-header">%s</li>' % s.keys()[0])
            for l in s.values()[0]:
                name, link = l.items()[0]
                ret.append('<li><a href="#%s">%s</a></li>' % (link, name))
            ret.append('<li class="divider"></li>')

    ret.append('</ul></li>')
    return '\n'.join(ret)


