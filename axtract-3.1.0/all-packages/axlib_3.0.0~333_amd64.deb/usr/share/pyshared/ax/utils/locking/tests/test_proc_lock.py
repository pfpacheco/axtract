import os, time, thread, unittest2
from threading                  import Lock, current_thread
from ax.utils.locking.proc_lock import check_for, proc_lock, run_once
from ax.utils.locking.proc_lock import auto_cached, cached
from ax.utils.locking.proc_lock import _item_or_attr, p

# often used:
eq         =  lambda self, a, b: self.assertEqual(a, b)
wait       =  time.sleep
parall     =  thread.start_new_thread
thread_nr  =  0

# concurrent starter of run_once:
def p_run_once(runner, args, cond, item, name=None, lock=None):
    'concurrent tries to do work'
    parall(run_once, (runner, args, cond, item, name, lock))


class TestProcLock(unittest2.TestCase):

    def test_item_or_attr(self):
        m, c = {'a': 1}, lambda m, k, v: eq(self, _item_or_attr(m, k), v)

        m = {'a': 1}

        c(m, 'a', 1)
        c(m, 'b', None)

        class d(dict): a, x = 2, 'bar'
        c(d(m), 'a', 1    ) # getitem has precedence over getattr
        c(d(m), 'b', None )
        c(d(m), 'x', 'bar')

        class d: bar = 'foo'
        c(d  , 'bar', 'foo')
        c(d(), 'bar', 'foo')


    def test_check_for_multi_threaded(self):
        '''multithreaded tries to run stuff.
        to understand the test remove the comment under wait below
        '''
        threads = 5

        def do_it(nr, build_dt, obj):
            '''wraps the tested check_for ctx with some stats'''
            ts = time.time()
            # The function tested:
            with check_for(obj, 'stuff') as missing:
                if missing:
                    wait(build_dt) if build_dt else None
                    obj['stuff'] = nr
                    obj[nr] = 'runner'
            obj['dts'][nr] = time.time() - ts

        # Caution: don't go smaller with these timings.
        # There has to be *some* difference between instant and delayed res.
        for build_dt , start_delay in (
            (  0    ,    0      )
           ,(  0.01 ,    0      )
           ,(  0.01 ,    0.005  )):
            p('build, start delay', build_dt, start_delay)

            obj = {'dts': {}}

            for i in range(0, threads):
                parall(do_it, (i, build_dt, obj))
                wait(start_delay)

            wait(threads * (build_dt + start_delay) + 0.01)

            # print out obj here to understand this test:
            # import pdb; pdb.set_trace()
            # then pp obj

            eq(self, [k for k in obj if obj.get(k) == 'runner'], [obj['stuff']])
            do_it('sync', 10, obj)
            # did not run it:
            eq(self, obj.get('sync'), None)
            eq(self, max(obj['dts']['sync'], 0.01), 0.01)
            eq(self, len(obj['dts']), threads + 1)

            if not start_delay:
                continue

            # here nr 0 must be the runner, dt[0] > build_dt
            eq(self, obj['stuff'], 0)
            eq(self, obj[0], 'runner')
            self.assertGreater(obj['dts'][0], build_dt)

            # and nr one, since kicked off after start_delay,
            # is NOT instant but had to remain waiting for the rest
            # build time of nr 0:
            dt1 = obj['dts'][1]
            remain_wait_time = build_dt-start_delay
            # on a busy server the remaining time can get very small actually:
            # but we don't want to delay testing too long with high delays...
            # so we comment this out to not crash builds:
            #self.assertGreater(dt1 + 0.002, remain_wait_time)
            self.assertLess(dt1, build_dt)

            # while the others are fast:
            [self.assertLess(obj['dts'][k], remain_wait_time/2)
                    for k in obj['dts'] if k not in (0, 1)]


    def test_proc_lock(self):
        class parser: document = None
        try:
            with proc_lock(getattr, (parser, 'document')):
                pass
            raise Exception("Expected TypeError")
        except TypeError as ex:
            pass

        for i in (1, 2):
            with proc_lock(getattr, (parser, 'document'), 'test_lock') as do:
                if do:
                    parser.document = i
        eq(self, parser.document, 1)


class TestRunOnce(unittest2.TestCase):
    ''' testing the convenience function to run build'''
    def test_list_cond(self):
        '''tests also the list containment condition:'''
        res = []
        build = lambda i: res.append(i)
        p_run_once(build, 1, res, 1)
        p_run_once(build, 1, res, 1)
        time.sleep(0.001)
        # only one occurrance of 1 in the list:
        eq(self, res, [1])


    def test_lock_frm_client_and_cls_cond(self):

        for lock in None, Lock():

            class res: parsed=None

            def build(i):
                time.sleep(0.003)
                res.parsed = i

            p_run_once(build, 1, res, 'parsed', lock=lock)
            time.sleep(0.0001) # just to assure 1 is it, dt << build_dt->conc.
            p_run_once(build, 2, res, 'parsed', lock=lock)
            # setting 2 was not done:
            time.sleep(0.005)
            eq(self, res.parsed, 1)

        # single argument ok, arg tuple possible:
        for i in (1, (1,), {'a': 'b'}):
            res.parsed = None
            run_once(build, i, res, 'parsed')
            if i == (1,):
                i = 1
            eq(self, res.parsed, i)


    def test_first_try_excepts(self):
        '''If a run of the run_once build function fails, due to adverse state
        of the running thread, then it will be tried again
        '''
        class res:
            parsed = None
            was_run = 0
        def build(i):
            res.parsed = 1./i # will fail for first
            res.was_run += 1
        # i == 0 is bad state, the try will crash:
        for i in (0, 0, 1, 2):
            try:
                run_once(build, i, res, 'parsed')
            except ZeroDivisionError as ex:
                eq(self, i, 0)
        # was run for the first good state (i = 1)
        eq(self, res.parsed, 1./1)
        eq(self, res.was_run, 1)


    def test_first_try_excepts_with_waiting_other_threads(self):
        '''When the crash occurs while others are waiting, one of the waiting
        ones will run it
        '''
        class res:
            parsed = None
            was_run = 0
        def build(i):
            # block a little to have other threads waiting to get the lock:
            time.sleep(0.003)
            res.parsed = 1./i # will fail for first
            res.was_run += 1

        # not making readers of the testlog nervous:
        m = '\n\nExpected ZeroDivisionError following:'
        print (m)
        print ('*' * len(m))

        for i in (0, 1, 2):
            p_run_once(build, i, res, 'parsed')
            if i == 0:
                wait(0.001)
        wait(0.05)
        assert res.parsed in (1./1, 1./2)
        eq(self, res.was_run, 1)




class TestCached(unittest2.TestCase):
    def test_sync(self):

        build = lambda i: i

        eq(self, cached('res_key', build, 1), 1)
        eq(self, cached('res_key', build, 2), 1)
        eq(self, cached('res_key', build, 2, invalidate=True), 2)
        eq(self, cached('res_key', build, 1), 2)


    def test_async(self):
        '''
        Legend: Time from left to right
        Tx        : Thread [nr]
        s         : Thread start, calling `cached` function
        build[dt] : build, takes time dt
        w[res]    : work (with built state res)

        T0---s<build[0.002]>w[0]--------
        T1-------s----------w[0]--------
        T2-------------s----w[0]--------
        '''
        built = []
        started_work = {}
        ts = time.time()
        def build(i):
            wait(0.002)
            built.append(i)
            return i

        def work(i, exp_state):
            work_state = cached('res_key_a', build, i)
            started_work[i] = time.time() - ts
            eq(self, exp_state, work_state)

        for i in (0, 1, 2):
            parall(work, (i, 0))
            # second one blocking for the first to finish build:
            wait(0.0005)

        wait(0.01)
        for i in (0, 1, 2):
            self.assertGreater(started_work[0], 0.002)
            self.assertLess   (started_work[0], 0.004)

        # cache built only once:
        eq(self, built, [0])




    def test_invalidation(self):
        '''
        new symbol:
        S: Like 's' but with invalidate set

        T0--s<build[0.01]>w[0]------------
        T1------S<build[0.01]>w[1]--------
        T2---------S----------w[1]--------
        T3------------S-------w[1]--------
        T4--------------s-w[0]------------
        T5-----------------------S<build[0.01]>w[5]--

        T0, T4 use 0's result as work state, while 2 and 3 have the new
        one, since they invalidated.

	# log with some debug out:
        T0: : cached called 0 invalidate set:  False
	T0: : building 0
	T1: : cached called 1 invalidate set:  True
	T1: : cached invalid. build 1
	T0: : built 0
	T0: : working with 0
	T1: : building 1
	T4: : cached called 4 invalidate set:  False
	T4: : working with 0
	T3: : cached called 3 invalidate set:  True
	T2: : cached called 2 invalidate set:  True
	T1: : built 1
	T1: : working with 1
	T3: : working with 1
	T2: : working with 1
	T5: : cached called 5 invalidate set:  True
	T5: : cached invalid. build 5
	T5: : building 5
	T5: : built 5
	T5: : working with 5

        '''
        built = []
        started_work = {}
        working_with = {}
        ts = time.time()
        def build(i):
            #p('building', i)
            wait(0.01)
            built.append(i)
            #p('built', i)
            return i

        def work(i, exp_state, inv=False):
            current_thread().name = 'T%s: ' % i
            work_state = cached('res_key_inv', build, i, invalidate=inv)
            started_work[i] = time.time() - ts
            working_with[i] = work_state
            #p('working with', work_state)
            eq(self, exp_state, work_state)

        parall(work, (0, 0))
        wait(0.005)
        parall(work, (1, 1, True)) # invalidation during build -> no build
        wait(0.005)
        parall(work, (2, 1, True))
        wait(0.0001)
        parall(work, (3, 1, True))
        parall(work, (4, 0)) # expected: 0
        wait(0.02)
        parall(work, (5, 5, True))
        wait(0.05)
        eq(self, built, [0, 1, 5])
        self.assertLess(started_work[4], started_work[1])



    def test_auto_cached(self):
        '''
        auto invalidate on facts change
        '''
        global thread_nr
        thread_nr = -1
        built = []
        started_work = {}
        working_with = {}
        ts = time.time()
        def build(i):
            p('building', i)
            wait(0.01)
            built.append(i)
            p('built', i)
            return i

        def work(i, exp_state):
            global thread_nr
            thread_nr += 1
            current_thread().name = 'T%s[%s]: ' % (thread_nr, i)
            # invalidate auto = default:
            work_state = auto_cached('res_key_auto', build, i)
            started_work[i] = time.time() - ts
            working_with[i] = work_state
            p('working with', work_state)
            eq(self, exp_state, work_state)

        parall(work, (0, 0))
        parall(work, (0, 0))
        wait(0.005)
        parall(work, (0, 0))
        wait(0.005)
        parall(work, (1, 1))
        wait(0.005)
        # still sees the 0 as arg. for the built facts - wont' rebuild, use 0
        parall(work, (0, 0))
        wait(0.03)
        # now the facts=1 version is built, so:
        work(1, 1)
        # only 2 builds in total ran:
        eq(self, built, [0, 1])


if __name__ == '__main__':
    unittest2.main()

