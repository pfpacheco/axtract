#!/usr/bin/python -tt
"""
Unit tests for ax.utils.crc.CrcCalculator
"""

import unittest2
import struct

from ax.utils.crc import CrcCalculator

class TestCRC(unittest2.TestCase):
    def test_crc16(self):
        """Check if CRC-16 calculation works"""
        calc = CrcCalculator()
        self.assertEqual(calc.crc16("123456789"), 47933)
        self.assertEqual(calc.crc16("axiros"), 59769)
        self.assertEqual(calc.crc16(""), 0)

    def test_crc16_poly_invariant(self):
        """Verify that crc(message + crc(message)) == 0"""
        calc = CrcCalculator()
        #for i in xrange(0, 2**16 - 1):
        for i in xrange(0, 255):
            message = "hello%s" % struct.pack("<H", i)
            crc = calc.crc16(message)

            # When binary representation of CRC is appended to message, the
            # resulting message must have CRC==0.
            message += struct.pack("<H", crc)
            self.assertEqual(calc.crc16(message), 0)


if __name__ == "__main__":
    unittest2.main()
