import unittest2
from ast import literal_eval
from ax.utils.formatting.pretty_print import dict_to_txt
from ax.utils.parsing.parse_text import *
from ax.utils import package_home

CWD = package_home(globals()).replace('__main__', '')

LS = '\n'
class TextParsing(unittest2.TestCase):
    def setUp(self):
        self.eq = self.assertEqual
        self.deq = self.assertDictEqual

    def test_empty(s):
        s.eq(parse_line(""), '')



    def test_parse_flat_map(s):
        m = 'InternetGatewayDevice.ManagementServer.PeriodicInformInterval : 56\r\nInternetGatewayDevice.ManagementServer.Username : tr069\r\nInternetGatewayDevice.ManagementServer.Password :  tr069\r\nInternetGatewayDevice.ManagementServer.ConnectionRequestURL : Axiros\r\nInternetGatewayDevice.ManagementServer.ParameterKey : Axiros\r\nInternetGatewayDevice.DeviceInfo.Manufacturer : Axiros\r\nInternetGatewayDevice.DeviceInfo.ManufacturerOUI : axiros\r\nInternetGatewayDevice.DeviceInfo.ProductClass : Axiros'
        mp = parse(m)
        assert mp['InternetGatewayDevice.ManagementServer.PeriodicInformInterval'] == 56
        assert len(mp) == 8


    def test_fix_types(s):
        txt = """
######################################################
#
# a file_tr069 cache type compliant parameter set
# note that we push values to ast's literal_eval.
#
######################################################

Events: BOOT, BOOTSTRAP

Parameters:
    DeviceInfo
        SerialNumber:       File Cache Demo
        SoftwareVersion:    v1.0
        HardwareVersion:    v1.0
        PeriodicInformTime: 0|datetime
    WANDevice
        1
            WANConnectionDevice
                1
                    WANPPPConnection
                        1
                            Name:    Internet
                            Uptime:  12342
    LANDevice
        1
            Hosts
                Host
                    1
                        Active:     1
                        HostName:   MyHost
                Host
                    2
                        Active:     1
                        HostName:   MyHost2
    """
        m = parse(txt)
        s.eq(m['Events'] , 'BOOT, BOOTSTRAP')
        v = m['Parameters']['DeviceInfo']['PeriodicInformTime']
        # datetime?
        assert hasattr(v, 'utctimetuple')
        s.eq(v.year, 1970)


    def test_trivial(s):
        m = "axtest\n-"
        p = parse(m)
        s.eq(p, ['axtest'])
        s.eq(parse('foo'), 'foo')
        s.eq(parse('   trivial ', ), '   trivial ')
        s.eq(parse('   trivial ', leave_trivial_text = 0), ['trivial'])
        s.eq(parse('key: val'), {'key': 'val'})

    def test_numbers(s):
        for text, m in  (
                ("key: '3", {'key': "'3"}),
                ("key: 3", {'key': 3}),
                ("key: '3'", {'key': "3"})
                ):
            p = parse(text)
            # is the text key equal to the map value?
            s.eq(p, m)
            # try the reverse function.
            # it won't work at one point: when the value is a number
            # given as string:
            try:
                s.eq(parse(dict_to_txt(p, fmt = {'ax': 1})), p)
            except:
                s.eq(text, "key: '3'")



    def test_line_parse(s):
        # like in trutils:
        conversions = 'AVM: 0043 , Foo:Bar : foo '
        s.deq(parse_line(conversions), {'AVM': '0043', 'Foo': 'Bar : foo'})
        conversions += (LS + conversions)
        s.deq(parse_line(conversions), {'AVM': '0043', 'Foo': 'Bar : foo'})

    def test_dict1(s):
        m = {'Operations': [
                   {
                    'URL': 'http://your.url.com',
                    'Username': '',
                    'Password': '',
                    'UUID': 42,
                    'ExecutionEnvRef': ''},
                   {'URL': 'http://your.url.com',
                    'Username': '',
                    'Password': '',
                    'Version': '00023',
                    'UUID': ''},
                   {'Version': 1.1,
                    'UUID': '',
                    'ExecutionEnvRef': ''
                     }
                   ],
             'CommandKey': ''}
        pretty = dict_to_txt(m, fmt = {'ax': 1})
        # have the pretty print out parsed into a map, and compared with
        # the original one:
        s.eq(parse(pretty), m)

    def test_dict2(s):
        # AXESS.ACS is with spaces, rest with tabs:
        # AXESS.ACS.Version is ':' separated.
        # Version is once a string, once a float:
        text = open(CWD + '/dict.txt').read()
        p = parse(text)
        expected = {'DeploymentUnits': {'ApacheProxy':
            {'Version 1.1': '', 'From': 'apt:apache2',
             'EUs': ['/etc/init.d/apache2'],
             'CFG': {'TR069SSL.ProxyTo': \
                    ('http://%(ApacheWsgi.TR069.Bind)s/%(setup_path)s/'
                    'CPEManager/CPEs/genericTR69'),
                    'GUISSL_ProxyTo': 'http://%(ApacheWsgi.GUI.Bind)s/$1',
                    'GUI_ProxyTo': 'http://%(ApacheWsgi.GUI.Bind)s/$1',
                    'TR069.ProxyTo': \
                    ('http://%(ApacheWsgi.TR069.Bind)s/%(setup_path)s/'
                     'CPEManager/CPEs/genericTR69'),
                    'SBPUT_ProxyTo': 'http://%(ApacheWsgi.GUI.Bind)s/$1',
                    'TR069SSL.Bind   0.0.0.0:7547': '',
                    'GUI.Bind': '0.0.0.0:80',
                    'SBGET.Bind  0.0.0.0:88': '',
                    'TR069.Bind  0.0.0.0:7547': '',
                    'SBPUT.Bind  0.0.0.0:7548': '',
                    'GUISSL.Bind 0.0.0.0:443': '',
                    'SBGET_ProxyTo': 'http://%(ApacheWsgi.GUI.Bind)s/$1'}},
             'AXESS.ACS': {'CFG': {'NBI.Bind': '0.0.0.0:9676',
                 'TR069.Bind  0.0.0.0:9675': '', 'GUI.Bind': '0.0.0.0:9673',
                 'Unauth.Bind 127.0.0.1:9672': ''}, 'Version': "'1.1",
                 'From': 'file:///data2/cluster_rcs/acs.ax/',
                 'EUs': ['/etc/init.d/axess',
                     '/etc/init.d/axess_configurator']}},
                 'Nodes': {'ApacheWsgi': {'From': 'apt:apache2'}}}
        s.deq(p, expected)
        s.assertNotEqual(parse(text + '\nfoo'), expected)
        s.eq(parse(dict_to_txt(p, fmt = {'ax': 1})), p)

    def test_dict_weired(s):
        """ make sure no changes break weired setups """
        text = open(CWD + '/dict2.txt').read()
        p = parse(text)
        s.deq(p, {'node': 'DB01',
                  'bar': '',
                  'foo': '',
                  'force': ['agent', 'axos', '"""', 'p = parse(text2)',
                    'pprint.pprint(p)',
                    "assert p == {'force': ['agent', 'axos'], 'node': 'DB01'}",
                    'text1 = """']})
        s.eq(parse(dict_to_txt(p, fmt = {'ax': 1})), p)

    def test_dict4(s):
        text = open(CWD + '/dict2.txt').read().split('"""', 1)[0]
        p = parse(text)
        s.deq(p, {'node': 'DB01', 'force': ['agent', 'axos']})
        s.eq(parse(dict_to_txt(p, fmt = {'ax': 1})), p)

    def test_dict5(s):
        text1 = """
foo
bar
"""
        p = parse(text1)
        s.eq(p, ['foo', 'bar'])
        s.eq(parse(dict_to_txt(p, fmt = {'ax': 1})), p)


    def test_types(s):
        text = """
foo: 2
bar: 2.4
baz: True
baz1: 0x23
baz2: 02
baz3: 0b2
"""
        p = parse(text)
        s.eq(type(p['bar']), type(2.4))
        s.eq(p['baz'], True)
        s.eq(p['foo'], 2)
        s.eq(p['baz1'], '0x23')
        s.eq(p['baz2'], '02')
        s.eq(p['baz3'], '0b2')
        s.eq(parse(dict_to_txt(p, fmt = {'ax': 1})), p)


    def test_dict6(s):
        text = """
  2:  
    3
    3
  sdf:    '5
  bla:    3 
    """
        p = parse(text)
        s.eq(p, {2:[3,3], 'sdf': "'5", 'bla': 3})
        s.eq(parse(dict_to_txt(p, fmt = {'ax': 1})), p)

    def test_colons(s):
        text = """
foo:bar:baz:
    key1: val1
    """
        p = parse(text)
        assert p == {'foo:bar:baz': {'key1': 'val1'}}
        s.eq(parse(dict_to_txt(p, fmt = {'ax': 1})), p)


    def test_dict8(s):
        text = """
customer1:
    cpeid: test123
    cid: mycustomer
    services:
        device:
            hostname: myhost
            defaultgw: 1.1.1.1
        acl:
            name: NAT_LIST
            iface: GigabitEthernet0/0
            deny_network_addr: 10.98.3.166
            permit_network_addr: 10.10.10.0 0.0.0.255
        dhcp:
            poolid: 11
            pool: 10.10.10.0 255.255.255.0
            gateway: 10.10.10.1
            dns1: 8.8.8.8
            dns2: 4.2.2.2
        mgmt:
            cli_username: cisco
            cli_password: cisco
            cli_access: 1
        iface1:
            name: Loopback0
            description: Operator Management
            network_addr: 10.98.3.166 255.255.255.255
        iface2:
            name: GigabitEthernet0/0
            description: WAN
            network_addr: 83.137.137.111 255.255.255.224
            natmode: outside
        iface3:
            name: GigabitEthernet0/1
            description: LAN
            network_addr: 10.10.10.1 255.255.255.0
            natmode: inside
"""
        p = parse(text)
        s.deq(p, {'customer1':
            {'cpeid': 'test123', 'services':
                {'iface1': {'network_addr': '10.98.3.166 255.255.255.255',
                    'name': 'Loopback0', 'description': 'Operator Management'},
                    'iface2': {'network_addr': '83.137.137.111 255.255.255.224',
                        'natmode': 'outside', 'name': 'GigabitEthernet0/0',
                        'description': 'WAN'},
                    'iface3': {'network_addr': '10.10.10.1 255.255.255.0',
                        'natmode': 'inside', 'name': 'GigabitEthernet0/1',
                        'description': 'LAN'},
                    'acl': {'deny_network_addr': '10.98.3.166',
                        'permit_network_addr': '10.10.10.0 0.0.0.255',
                        'iface': 'GigabitEthernet0/0', 'name': 'NAT_LIST'},
                    'mgmt': {'cli_username': 'cisco', 'cli_access': 1,
                        'cli_password': 'cisco'},
                    'device': {'defaultgw': '1.1.1.1', 'hostname': 'myhost'},
                    'dhcp': {'dns2': '4.2.2.2', 'dns1': '8.8.8.8',
                        'gateway': '10.10.10.1',
                        'pool': '10.10.10.0 255.255.255.0', 'poolid': 11}},
                    'cid': 'mycustomer'}})
        s.eq(parse(dict_to_txt(p, fmt = {'ax': 1})), p)

if __name__ == '__main__':
    unittest2.main(verbosity=2)



