from ._simple_deepcopy import deepcopy
