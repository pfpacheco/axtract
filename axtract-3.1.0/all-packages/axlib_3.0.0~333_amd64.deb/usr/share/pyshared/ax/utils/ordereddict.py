"""Provide an OrderedDict that is usable in Zope"""
from collections import OrderedDict

# Zope RestrictedPython assumess structures (that are not dict or list) to
# have __guarded_setitem__, __guarded_delitem__, __guarded_setattr__, and
# __guarded_delattr__ attributes. For instance, classes not having these
# attributes are not allowed to do assignments or del operations.
# These statements will fail if the attributes are not included:
#     x['5'] = 1
#     del x['7']
# Some background can be found in the RestrictedPython/Guards.py:103
# Safe types don't need these attributes and skip the check for
# guarded attributes (Guards.py:118 => {dict: True, list: True}).
OrderedDict.__guarded_setitem__ = OrderedDict.__setitem__
OrderedDict.__guarded_delitem__ = OrderedDict.__delitem__


# attaching a pretty printer, mainly for debug sessions
def to_yaml(od):
    """Converts ordered dict to yaml which is convertable back to O.D. """
    from convert import odict_to_yml
    return odict_to_yml(od)

# we should not change the __repr__ (which is ugly at pp)
OrderedDict.yml  = to_yaml

if __name__ == '__main__':
    d = OrderedDict([("main",
                  OrderedDict([("window",
                                OrderedDict([("size", [500, 500]),
                                             ("position", [100, 900])])),
                               ("splash_enabled", True),
                               ("theme", "Dark")])),
                 ("updates",
                  OrderedDict([("automatic", True),
                               ("servers",
                                [OrderedDict([("url", "http://server1.com"),
                                              ("name", "Stable")]),
                                 OrderedDict([("url", "http://server2.com"),
                                              ("name", "Beta")]),
                                 OrderedDict([("url", "http://server3.com"),
                                              ("name", "Dev")])]),
                               ("prompt_restart", True)])),
                 ("logging",
                  OrderedDict([("enabled", True),
                               ("rotate", True)]))])

    assert d.yml().strip() == """
main:
  window:
    size:
    - 500
    - 500
    position:
    - 100
    - 900
  splash_enabled: true
  theme: Dark
updates:
  automatic: true
  servers:
  - url: http://server1.com
    name: Stable
  - url: http://server2.com
    name: Beta
  - url: http://server3.com
    name: Dev
  prompt_restart: true
logging:
  enabled: true
  rotate: true
""".strip()
    import pdb; pdb.set_trace()
