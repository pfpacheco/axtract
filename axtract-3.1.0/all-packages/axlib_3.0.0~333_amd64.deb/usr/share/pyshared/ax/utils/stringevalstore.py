import os
class StringEvalStore(object):
    def __init__(self, file_name, default=None):
        self.file_name = file_name
        os.system('touch %s' % file_name)

        # Is the file empyt default is returned
        self.default = default

    def write_data(self, data):
        # FIXME: python >= 2.5 use 'with'-statement
        file_handler = open(self.file_name, 'w')
        try:
            file_handler.write(str(data))
        finally:
            file_handler.close()

    def read_data(self):
        file_handler = open(self.file_name, 'r')
        try:
            data = file_handler.read()
            if data:
                return eval(data)
            return self.default
        finally:
            file_handler.close()

