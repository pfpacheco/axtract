country_codes = {1: u'UM', 598: u'UY', 7: u'KZ', 20: u'EG', 1284: u'VG', 27: u'ZA', 30: u'GR', 31: u'NL', 32: u'BE', 33: u'FR', 34: u'ES', 36: u'HU', 39: u'IT', 40: u'RO', 41: u'CH', 43: u'AT', 44: u'GB', 45: u'DK', 46: u'SE', 47: u'SJ', 48: u'PL', 49: u'DE', 51: u'PE', 52: u'MX', 53: u'CU', 54: u'AR', 55: u'BR', 56: u'CL', 57: u'CO', 58: u'VE', 60: u'MY', 61: u'CX', 62: u'ID', 63: u'PH', 64: u'NZ', 65: u'SG', 66: u'TH', 353: u'IE', 590: u'MF', 591: u'BO', 592: u'GY', 593: u'EC', 594: u'GF', 595: u'PY', 596: u'MQ', 597: u'SR', 86: u'CN', 599: u'SX', 90: u'TR', 91: u'IN', 92: u'PK', 93: u'AF', 94: u'LK', 95: u'MM', 98: u'IR', 358: u'FI', 1649: u'TC', 1664: u'MS', 1784: u'VC', 1670: u'MP', 1671: u'GU', 441481: u'GG', 1684: u'AS', 670: u'TL', 672: u'NF', 673: u'BN', 674: u'NR', 675: u'PG', 676: u'TO', 677: u'SB', 678: u'VU', 679: u'FJ', 680: u'PW', 681: u'WF', 682: u'CK', 683: u'NU', 685: u'WS', 686: u'KI', 687: u'NC', 688: u'TV', 689: u'PF', 690: u'TK', 691: u'FM', 692: u'MH', 441534: u'JE', 961: u'LB', 886: u'TW', 211: u'SS', 212: u'MA', 213: u'DZ', 216: u'TN', 1242: u'BS', 220: u'GM', 221: u'SN', 1246: u'BB', 223: u'ML', 224: u'GN', 225: u'CI', 226: u'BF', 227: u'NE', 228: u'TG', 229: u'BJ', 230: u'MU', 231: u'LR', 232: u'SL', 233: u'GH', 234: u'NG', 235: u'TD', 236: u'CF', 237: u'CM', 238: u'CV', 239: u'ST', 1264: u'AI', 241: u'GA', 242: u'CG', 243: u'CD', 244: u'AO', 245: u'GW', 246: u'IO', 248: u'SC', 249: u'SD', 250: u'RW', 251: u'ET', 252: u'SO', 253: u'DJ', 254: u'KE', 255: u'TZ', 256: u'UG', 257: u'BI', 258: u'MZ', 260: u'ZM', 261: u'MG', 262: u'YT', 263: u'ZW', 264: u'NA', 265: u'MW', 266: u'LS', 267: u'BW', 268: u'SZ', 269: u'KM', 1809: u'DO', 441624: u'IM', 218: u'LY', 290: u'SH', 291: u'ER', 297: u'AW', 298: u'FO', 299: u'GL', 222: u'MR', 1340: u'VI', 1345: u'KY', 1758: u'LC', 1868: u'TT', 1869: u'KN', 850: u'KP', 1876: u'JM', 853: u'MO', 855: u'KH', 856: u'LA', 350: u'GI', 351: u'PT', 352: u'LU', 84: u'VN', 354: u'IS', 355: u'AL', 356: u'MT', 357: u'CY', 870: u'PN', 359: u'BG', 1767: u'DM', 880: u'BD', 370: u'LT', 371: u'LV', 372: u'EE', 373: u'MD', 967: u'YE', 375: u'BY', 376: u'AD', 377: u'MC', 378: u'SM', 379: u'VA', 380: u'UA', 381: u'RS', 382: u'ME', 385: u'HR', 386: u'SI', 387: u'BA', 389: u'MK', 1939: u'PR', 240: u'GQ', 420: u'CZ', 421: u'SK', 423: u'LI', 1268: u'AG', 960: u'MV', 1473: u'GD', 962: u'JO', 963: u'SY', 964: u'IQ', 965: u'KW', 966: u'SA', 1441: u'BM', 968: u'OM', 970: u'PS', 971: u'AE', 972: u'IL', 973: u'BH', 974: u'QA', 975: u'BT', 976: u'MN', 977: u'NP', 505: u'NI', 992: u'TJ', 993: u'TM', 994: u'AZ', 995: u'GE', 996: u'KG', 374: u'AM', 998: u'UZ', 81: u'JP', 35818: u'AX', 82: u'KR', 500: u'FK', 501: u'BZ', 502: u'GT', 503: u'SV', 504: u'HN', 852: u'HK', 506: u'CR', 507: u'PA', 508: u'PM', 509: u'HT'}


def local_nr(nr, clean=0):
    nr = str(nr)
    while not nr[0].isdigit():
        nr = nr[1:]
    if not nr.startswith('0'):
        nr = '0%s' % nr
    if not clean:
        return nr
    r = ''
    for c in nr:
        if c.isdigit():
            r += c
    return r


def split_country_code(nr, clean=0):
    """ return country code and local numer tuple"""
    nr = str(nr)
    if nr.startswith('0'):
        # can't deliver CC:
        return None, local_nr(nr, clean)
    if nr.startswith('+'):
        nr = nr[1:]
    pos = 1
    while pos < len(nr):
        pref = nr[:pos]
        if not pref.isdigit():
            raise Exception("Unknown country code: %s" % nr)
        cc = country_codes.get(int(pref))
        if cc:
            ret = int(pref), local_nr(nr[pos:], clean)
            return ret
        pos += 1
    raise Exception("Unknown country code: %s" % nr)



if __name__ == '__main__':
    assert split_country_code('+41123') == (41, '0123')
    assert split_country_code('41123') == (41, '0123')
    assert split_country_code('41-123') == (41, '0123')
    assert split_country_code('+41-123') == (41, '0123')
    assert split_country_code('+41.123') == (41, '0123')
    assert split_country_code('+41.123.123') == (41, '0123.123')
    assert split_country_code('+41.123.123', clean=1) == (41, '0123123')
    assert split_country_code('+1.123.123', clean=1) == (1, '0123123')
