import re
import datetime
import simplejson as json

from ax.utils.listables import get_listables
from ax.utils.listables import SqlListable
from ax.utils.condition import sanitize_input

GROUP_CREATE_TABLE_SQL = """CREATE TABLE IF NOT EXISTS AXGroup (
        id INT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        name VARCHAR(250) NOT NULL,
        description VARCHAR(250) DEFAULT NULL,
        author VARCHAR(50) DEFAULT NULL,
        editor VARCHAR(50) DEFAULT NULL,
        creation_time DATETIME DEFAULT NULL,
        last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        type ENUM('static', 'dynamic', 'lazy', 'super') NOT NULL,
        internal TINYINT(1) UNSIGNED DEFAULT 0,
        persistent TINYINT(1) UNSIGNED DEFAULT 1,
        query_map TEXT,
        INDEX name(name),
        PRIMARY KEY(id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"""

GROUP_CONSUMED_MEMBERS_CREATE_TABLE_SQL = \
    """CREATE TABLE IF NOT EXISTS AXGroupConsumedMembers (
        group_id INT(20) UNSIGNED NOT NULL,
        member_id VARCHAR(200) NOT NULL,
        INDEX group_id(group_id),
        INDEX member_id(member_id),
        PRIMARY KEY(group_id, member_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"""

GROUP_STATIC_RELATION_CREATE_TABLE_SQL = \
    """CREATE TABLE IF NOT EXISTS AXGroupStaticRelation (
        group_id INT(20) UNSIGNED NOT NULL,
        member_id VARCHAR(200) NOT NULL,
        INDEX group_id(group_id),
        INDEX member_id(member_id),
        PRIMARY KEY(group_id, member_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"""

GROUP_SUPER_RELATION_CREATE_TABLE_SQL = \
    """CREATE TABLE IF NOT EXISTS AXGroupSuperRelation (
        group_id INT(20) UNSIGNED NOT NULL,
        parent_group_id INT(20) UNSIGNED NOT NULL,
        INDEX group_id(group_id),
        INDEX parent_group_id(parent_group_id),
        PRIMARY KEY(group_id, parent_group_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"""

GROUP_INSERT_SQL = """INSERT INTO AXGroup(
        name,
        description,
        author,
        creation_time,
        type,
        internal,
        persistent,
        query_map) VALUES (
        %s, %s, %s, %s, %s, %s, %s, %s)"""

GROUP_CONSUMED_MEMBERS_INSERT_SQL = """INSERT INTO AXGroupConsumedMembers (
        group_id,
        member_id) VALUES (
        %s, %s)"""

GROUP_STATIC_RELATION_INSERT_SQL = """INSERT INTO AXGroupStaticRelation (
        group_id,
        member_id) VALUES (
        %s, %s)"""

GROUP_SUPER_RELATION_INSERT_SQL = """INSERT INTO AXGroupSuperRelation (
        group_id,
        parent_group_id) VALUES (
        %s, %s)"""

GROUP_DELETE_SQL = """DELETE FROM AXGroup
        WHERE id=%s"""

GROUP_CONSUMED_MEMBERS_DELETE_SQL = """DELETE FROM AXGroupConsumedMembers
        WHERE group_id=%s"""

GROUP_STATIC_RELATION_DELETE_SQL = """DELETE FROM AXGroupStaticRelation
        WHERE group_id=%s"""

GROUP_SUPER_RELATIONS_DELETE_SQL = """DELETE FROM AXGroupSuperRelation
        WHERE (group_id=%s OR parent_group_id=%s)"""

GROUP_TEMP_COND_DELETE_SQL = """DELETE g FROM AXGroup g
        INNER JOIN AXGroupSuperRelation r
        ON g.id = r.group_id
        WHERE g.persistent = 0
        AND r.parent_group_id = %s"""

GROUP_SUPER_SUB_RELATION_DELETE_SQL = """DELETE FROM AXGroupSuperRelation
        WHERE group_id=%s AND parent_group_id=%s"""

GROUP_QUERY_MAP_UPDATE_SQL = """UPDATE AXGroup SET
        query_map=%s
        WHERE id=%s"""

GROUP_UPDATE_SQL = """UPDATE AXGroup SET
        name=%s,
        description=%s,
        editor=%s,
        type=%s,
        query_map=%s
        WHERE id=%s"""

GROUP_SELECT_BY_ID_SQL = """SELECT
        name,
        description,
        author,
        editor,
        creation_time,
        last_updated,
        type,
        query_map
        FROM AXGroup
        WHERE id=%s"""

GROUP_SELECT_BY_ATTR_SQL = """SELECT
        id,
        name,
        description,
        author,
        editor,
        creation_time,
        last_updated,
        type,
        query_map
        FROM AXGroup
        WHERE internal=0
        AND %s %s %s"""

GROUP_SELECT_BY_CRITERIA_SQL = """SELECT
        id,
        name,
        description,
        author,
        editor,
        creation_time,
        last_updated,
        type,
        query_map
        FROM AXGroup
        WHERE %s"""

GROUP_SELECT_MULTIPLE_SQL = """SELECT
        type,
        query_map
        FROM AXGroup
        WHERE id IN (%s)"""

GROUP_SELECT_ALL_SQL = """SELECT
        id,
        name,
        description,
        author,
        editor,
        creation_time,
        last_updated,
        type,
        query_map
        FROM AXGroup
        WHERE internal=%s
        LIMIT %s OFFSET %s"""

GROUP_PARENTS_SELECT_SQL = """SELECT
        parent_group_id
        FROM AXGroupSuperRelation
        WHERE group_id=%s"""

GROUP_CHILDREN_SELECT_SQL = """SELECT
        group_id
        FROM AXGroupSuperRelation
        WHERE parent_group_id=%s"""

GROUP_CONSUMED_MEMBERS_SELECT_SQL = """SELECT
        group_id,
        member_id
        FROM AXGroupConsumedMembers
        WHERE group_id=%s AND member_id=%s
        LIMIT 1"""


class GroupSchema(object):
    class Group(SqlListable):
        table = 'AXGroup'
        primary_id = 'id'
        master_params = ['name', 'description', 'type']
        parent_types = []


class Grouping(object):
    def __init__(self, schema, db_engine):
        self.db_handle = db_engine

        # Create group table if it doesn't exists
        self.db_handle.execute(GROUP_CREATE_TABLE_SQL)

        # Create group consumed members table if it doesn't exist
        self.db_handle.execute(GROUP_CONSUMED_MEMBERS_CREATE_TABLE_SQL)

        # Create group static relation table if it doesn't exist
        self.db_handle.execute(GROUP_STATIC_RELATION_CREATE_TABLE_SQL)

        # Create group super relation table if it doesn't exist
        self.db_handle.execute(GROUP_SUPER_RELATION_CREATE_TABLE_SQL)

        # Initialize group listable(mainly used to build search queries)
        self.group_listable = get_listables(GroupSchema, db_engine)

        # Creates/gets an instance of listables for the schema
        self.listables = get_listables(schema, db_engine)
    def _filter_complies_with_type(self, filter_list, type_):
        placeholder_found = False
        format_specifiers = [
            '%s', '"%s"', '\%\([a-zA-Z0-9_]+\)s', '\"\%\([a-zA-Z0-9_]+\)s\"'
        ]

        def traverse(object_, container_types=(list, tuple)):
            if isinstance(object_, container_types):
                for value in object_:
                    for sub_value in traverse(value, container_types):
                        yield sub_value
            else:
                yield object_

        flat_list = [element for element in traverse(filter_list)]
        for element in flat_list:
            if isinstance(element, basestring) and \
                    re.match('|'.join(format_specifiers), element):
                placeholder_found = True
                break

        if type_ == 'lazy':
            return True if placeholder_found else False

        return False if placeholder_found else True

    def _rebuild_query_with_static_filters(self, group_id, query_map):
        try:
            # static filter table and column
            filter_column = query_map['filters'][0]

            # Replace filters
            where_index = query_map['full_query'].index('WHERE')
            if 'ORDER BY' in query_map['full_query']:
                end_index = query_map['full_query'].index('ORDER BY')
                del query_map['full_query'][where_index + 1:end_index]
            else:
                del query_map['full_query'][where_index + 1:]
            filters = ('AXGroupStaticRelation.group_id = %d' % group_id)
            query_map['full_query'].insert(where_index + 1, filters)

            # Clear filter params
            del query_map['filter_params'][:]

            # Append to query tables
            extra_join = (
                'INNER JOIN AXGroupStaticRelation AS AXGroupStaticRelation',
                'ON %s = AXGroupStaticRelation.member_id' % filter_column)
            query_map['full_query'][where_index:where_index] = extra_join
        except (ValueError, IndexError, TypeError):
            raise ValueError("Filter doesn't comply with group type static")

    def _insert_static_relations(self, group_id, filter_list):
        try:
            prop, op, values = filter_list

            # Check is the filter is not a nested list
            if isinstance(prop, list) or isinstance(op, list):
                raise ValueError('Invalid filter')

            filters = []
            if isinstance(values, (list, tuple)):
                filters.extend(values)
            else:
                filters.append(values)

            # Add new group definition
            for value in filters:
                self.db_handle.execute(
                    GROUP_STATIC_RELATION_INSERT_SQL,
                    (str(group_id), value.strip().strip('"')))
        except (ValueError, IndexError, TypeError, AttributeError) as err:
            raise ValueError(
                "Filter doesn't comply with group type static: %s" % str(err))

    def _insert_super_relation(self, group_id, parent_group_id):
        self.db_handle.execute(GROUP_SUPER_RELATION_INSERT_SQL,
                               (str(group_id), parent_group_id))

    def _create_group(self,
                      name,
                      description,
                      user,
                      type_,
                      result_list,
                      filter_list=None,
                      internal=False,
                      persistent=True,
                      base_group=None):
        try:
            if not filter_list:
                filter_list = []

            # Load base group(if provided)
            if base_group:

                base = self.get_group_by_id(base_group)
                base_query_map = json.loads(base['query_map'])

                if type_ == 'super' or base['type'] == 'super':
                    raise ValueError('Cannot extend from or to super group')

                if type_ == 'static' or base['type'] == 'static':
                    raise ValueError('Cannot extend from or to static group')

                # Calculate new filters
                new_filter_list = base_query_map['filters']
                new_filter_list.append('and')
                new_filter_list.append(filter_list)
                filter_list = new_filter_list

                # Prepend base result_list
                result_list.extend(base_query_map['show'])

            # Check if resultset exists
            if not result_list:
                raise ValueError("No resultset provided")

            # Check if filter satisfies group type
            if not self._filter_complies_with_type(filter_list, type_):
                raise ValueError("Filter doesn't comply with group type %s" %
                                 type_)

            # Initialize query map
            query_map = self.listables.create_query_map()

            # Pick a root listable to start building the query from
            root = result_list[0].split('.')[0]
            lt = self.listables[root]

            # Sort resultset ascii only(useful when it comes to super groups)
            result_list = list(set(result_list))
            result_list.sort(key=lambda x: x.lower())

            # Set group filters(WHERE clause)
            lt.set_filters(query_map, filter_list, None)

            # Set group resultset(SELECT clause)
            result_list.insert(
                0, 'kv')  # Key-value option used for post processing
            lt.set_resultset(query_map, result_list)

            # Add new group definition
            res = self.db_handle.execute(GROUP_INSERT_SQL, (
                name, description, user,
                datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), type_,
                int(internal), int(persistent), json.dumps(query_map)))
            id_ = res.lastrowid

            # Overwrite static filter and add relations with auto generated group id
            if type_ == 'static':
                self._rebuild_query_with_static_filters(id_, query_map)
                self._insert_static_relations(id_, filter_list)
                self.db_handle.execute(GROUP_QUERY_MAP_UPDATE_SQL,
                                       (json.dumps(query_map), str(id_)))

            return id_
        except ValueError as err:
            raise ValueError("Cannot create group %s: %s" % (name, str(err)))

    def _create_or_update_super_group(self,
                                      user,
                                      sub_groups,
                                      name=None,
                                      description=None,
                                      group_definition=None,
                                      internal=False,
                                      overwrite=False,
                                      create_links=True):

        if not sub_groups:
            raise ValueError(
                "Super group cannot be created without sub-groups")

        sub_groups = set(sub_groups)
        result_list = []
        query = []
        filter_params = []
        placeholders = []

        # Check if the group already exists
        id_ = None
        if group_definition:
            id_ = group_definition['id']
            if group_definition['type'] != 'super':
                raise ValueError("Cannot update group %s of type %s here" %
                                 (id_, group_definition['type']))

            # Load query map and extend this group(Used by add_children)
            if not overwrite:
                query_map = json.loads(group_definition['query_map'])
                query = query_map['full_query']
                result_list = query_map['show']

                # Load placeholders from super group
                filter_params.extend(query_map['filter_params'])
                placeholders.extend(query_map['filter_placeholders'])

        # Fetch each sub-group and combine their queries
        operator = 'UNION'
        format_specifiers = ("%s, " * len(sub_groups))
        sql = GROUP_SELECT_MULTIPLE_SQL % (format_specifiers.rstrip(', '))
        arguments = tuple(sub_groups)
        res = self.db_handle.execute(sql, arguments)

        row_count = 0
        for row in res:
            row_count += 1
            sub_group_type = row[0]
            sub_group_query_map = json.loads(row[1])
            group_result_list = sub_group_query_map['show']
            group_query = sub_group_query_map['full_query']
            group_filter_params = sub_group_query_map['filter_params']
            group_filter_placeholders = sub_group_query_map[
                'filter_placeholders']

            if sub_group_type == "lazy":
                if set(placeholders).intersection(group_filter_placeholders):
                    raise ValueError(
                        "Sub-groups have overlapping placeholders")

                placeholders.extend(group_filter_placeholders)

            if not result_list:
                result_list = group_result_list

            if (not set(result_list).symmetric_difference(
                    set(group_result_list))) is False:
                raise ValueError("Sub-groups have disjoint resultsets")

            # Append group query to super group query
            # query.extend([operator, '(']) if query else query.extend('(')
            if query:
                query.extend([operator])
            query.extend(group_query)
            filter_params.extend(group_filter_params)
            # query.extend(')')

        if row_count < len(sub_groups):
            raise ValueError('Cannot fetch all sub-groups')

        # Pick a root listable to start building the query from
        root = result_list[0].split('.')[0]
        lt = self.listables[root]

        # Get a query map
        query_map = self.listables.create_query_map()

        # Set group resultset(SELECT clause)
        result_list.insert(0,
                           'kv')  # Key-value option used for post processing
        lt.set_resultset(query_map, result_list)

        query_map['full_query'] = query
        query_map['filter_params'] = filter_params
        query_map['filter_placeholders'] = placeholders

        # Add/update group definition(argument internal is ignored in case of updates)
        if group_definition:
            self.db_handle.execute(GROUP_UPDATE_SQL,
                                   (name, description, user, 'super',
                                    json.dumps(query_map), str(id_)))
        else:
            res = self.db_handle.execute(GROUP_INSERT_SQL, (
                name, description, user,
                datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'super',
                internal, True, json.dumps(query_map)))
            id_ = res.lastrowid

        # Link sub-group to super group
        for sub_group_id in sub_groups:
            if create_links:
                self._insert_super_relation(sub_group_id, id_)

        return id_

    def create_group(self,
                     name,
                     description,
                     user,
                     type_,
                     result_list,
                     filter_list=None,
                     internal=False,
                     base_group=None):
        """
        Creates a group based on filters and result parameters
        @param name: Group name
        @param description: Group description
        @param user: Group author
        @param type_: Group type(static, dynamic, lazy)
        @param result_list: Group show parameters
        @param filter_list: Group filters as nested list(with AND/OR connectors)
        @param internal: Is the group for internal use?
        @param base_group: Group to build on top of
        """
        return self._create_group(
            name,
            description,
            user,
            type_,
            result_list,
            filter_list,
            internal=internal,
            persistent=True,
            base_group=base_group)

    def create_super_group(self,
                           name,
                           description,
                           user,
                           sub_groups,
                           internal=False):
        """
        Creates a super group by combining queries from given sub-groups
        @param name: Group name
        @param description: Group description
        @param user: Group author
        @param sub_groups: A list of sub-group IDs
        @param internal: Is the group for internal use?
        """
        try:
            # Check if group exists
            group_definition = self._get_group_by_id(name)
            if group_definition:
                raise ValueError("Group %s already exists" % name)

            return self._create_or_update_super_group(
                user,
                sub_groups,
                name,
                description,
                internal=internal,
                overwrite=True)
        except ValueError as err:
            raise ValueError("Cannot create super group %s: %s" %
                             (name, str(err)))

    def create_super_group_with_condition(self,
                                          name,
                                          description,
                                          user,
                                          sub_groups,
                                          internal=False,
                                          cond_type=None,
                                          cond_result_list=None,
                                          cond_filter_list=None):
        """
        Creates a super group by combining queries from given sub-groups
        and an extra condition
        @param name: Group name
        @param description: Group description
        @param user: Group author
        @param sub_groups: A list of sub-group IDs
        @param internal: Is the group for internal use?
        @param cond_type: Extra condition group type(static, dynamic, lazy)
        @param cond_result_list: Extra condition group show parameters
        @param cond_filter_list: Extra condition group filters as nested list(with AND/OR connectors)
        """

        # Create a condition(which is a group deleted alongside its super group)
        cond_name = name + '_extra_condition'
        cond_id = self._create_group(
            cond_name,
            'Extra condition for super group: ' + name,
            user,
            cond_type,
            cond_result_list,
            cond_filter_list,
            internal=True,
            persistent=False)

        # Create super group with sub-groups and condition
        sub_groups.append(cond_id)
        return self.create_super_group(name, description, user, sub_groups,
                                       internal)

    def add_children(self, id_, user, sub_groups, force=False):
        """
        Adds(or links) sub-groups to a super group
        @param id_: Group id of the super group
        @param user: Group editor
        @param sub_groups: A list IDs of the sub-groups to be added
        @param force: Add children even if the super group is referenced by another?
        """
        try:
            # Check if the group is part referenced by a super group
            if not force and self._has_super_group(id_):
                raise ValueError("Group is referenced by another group")

            # Check if group exists
            group_definition = self.get_group_by_id(id_)
            if group_definition['type'] != 'super':
                raise ValueError("Cannot add children to non-super group %s" %
                                 str(id_))

            self._create_or_update_super_group(
                user,
                sub_groups,
                name=group_definition['name'],
                description=group_definition['description'],
                overwrite=False,
                group_definition=group_definition)
        except ValueError as err:
            raise ValueError("Cannot add children to group %s: %s" %
                             (str(id_), str(err)))

    def delete_children(self, id_, user, sub_groups, force=False):
        """
        Deletes(or unlinks) sub-groups from a super group
        @param id_: Group id of the super group
        @param user: Group editor
        @param sub_groups: A list IDs of the sub-groups to be deleted
        @param force: Delete children even if the super group is referenced by another?
        """
        try:
            # Check if group exists
            group_definition = self.get_group_by_id(id_)
            if group_definition['type'] != 'super':
                raise ValueError(
                    "Cannot delete children for non-super group %s" % id_)

            # Check if the group is part referenced by a super group
            if not force and self._has_super_group(id_):
                raise ValueError("Group is referenced by another group")

            # Get sub-groups for the super groups
            subs = self.get_children(id_)
            sub_groups_to_be_retained = set(subs).difference(sub_groups)
            if sub_groups_to_be_retained:
                # Delete sub-group links
                for sub_group in sub_groups:
                    self._delete_group_super_sub_relation(sub_group, id_)

                # Update super group
                if not set(sub_groups_to_be_retained) == set(subs):
                    self._create_or_update_super_group(
                        user,
                        sub_groups_to_be_retained,
                        name=group_definition['name'],
                        description=group_definition['description'],
                        group_definition=group_definition,
                        internal=False,
                        overwrite=True,
                        create_links=False)

            if set(sub_groups) == set(subs):
                self.delete_group(id_, force=True)
        except ValueError as err:
            raise ValueError("Cannot delete children from group %s: %s" %
                             (str(id_), str(err)))

    def delete_group(self, id_, force=False):
        """
        Deletes a group
        @param id_: ID of the group to be deleted
        @param force: Delete group even if it is referenced by another?
        """
        try:
            # Check if the group is part referenced by a super group
            if not force and self._has_super_group(id_):
                raise ValueError("Group is referenced by another group")

            # Reset group consumed members
            self.reset_consumed_members(id_)

            # Clean up group relations of static group
            group_type = self.get_group_by_id(id_)['type']
            if group_type == 'static':
                self._delete_group_static_relations(id_)

            # Clean up group relations of super group
            if group_type == 'super':
                self._delete_group_super_relations(id_)

            # Delete group definition
            self.db_handle.execute(GROUP_DELETE_SQL, (str(id_)))
        except ValueError as err:
            raise ValueError("Cannot delete group %s: %s" % (id_, str(err)))

    def _has_super_group(self, group_id):
        res = self.db_handle.execute(GROUP_PARENTS_SELECT_SQL, (str(group_id)))
        return True if res.first() else False

    def _delete_group_static_relations(self, id_):
        # Delete group relations
        self.db_handle.execute(GROUP_STATIC_RELATION_DELETE_SQL, (str(id_)))

    def _delete_group_super_relations(self, id_):
        # Delete temporary groups associated with the super group
        self.db_handle.execute(GROUP_TEMP_COND_DELETE_SQL, (str(id_)))

        # Delete group relations
        self.db_handle.execute(GROUP_SUPER_RELATIONS_DELETE_SQL,
                               (str(id_), str(id_)))

    def _delete_group_super_sub_relation(self, group_id, parent_group_id):
        # Delete group relations
        self.db_handle.execute(GROUP_SUPER_SUB_RELATION_DELETE_SQL,
                               (str(group_id), str(parent_group_id)))

    def update_group(self,
                     id_,
                     new_name,
                     new_description,
                     user,
                     new_type,
                     new_result_list,
                     new_filter_list=None,
                     force=False):
        """
        Update group with new name, description, type, filters and show parameters
        @param id_: ID of the group to be updated
        @param new_name: New group name
        @param new_description: New group description
        @param user: Group editor
        @param new_type: New group type(static, dynamic, lazy)
        @param new_result_list: New group show parameters
        @param new_filter_list: New group filters as nested list(with AND/OR connectors)
        @param force: Update group even if it is referenced by another?
        """
        try:
            if not new_filter_list:
                new_filter_list = []

            if not new_result_list:
                raise ValueError("No resultset provided")

            # Check if super group
            group_definition = self.get_group_by_id(id_)
            if group_definition['type'] == 'super':
                raise ValueError(
                    "Update operation is not supported on super groups")

            # Check if filter satisfies group type
            if not self._filter_complies_with_type(new_filter_list, new_type):
                raise ValueError("Filter doesn't comply with type %s" % type_)

            # Check if the group is part referenced by a super group
            if not force and self._has_super_group(id_):
                raise ValueError("Group is referenced by another group")

            # Initialize query map
            query_map = self.listables.create_query_map()

            # Pick a root listable to start building the query from
            root = new_result_list[0].split('.')[0]
            lt = self.listables[root]

            # Set group filters(WHERE clause)
            lt.set_filters(query_map, new_filter_list, None)

            # Set group resultset(SELECT clause)
            new_result_list.insert(
                0, 'kv')  # Key-value option used for post processing
            lt.set_resultset(query_map, new_result_list)

            # Overwrite static filter and add tables
            if new_type == 'static':
                self._rebuild_query_with_static_filters(id_, query_map)
                self._insert_static_relations(id_, new_filter_list)

            # Clean up old group relations(may be the group was static before)
            group_type = self.get_group_by_id(id_)['type']
            if group_type == 'static':
                self._delete_group_static_relations(id_)

            # Update group definition
            self.db_handle.execute(GROUP_UPDATE_SQL,
                                   (new_name, new_description, user, new_type,
                                    json.dumps(query_map), str(id_)))

            # Reset group consumed members
            self.reset_consumed_members(id_)

        except ValueError as err:
            raise ValueError("Cannot update group %s: %s" %
                             (str(id_), str(err)))

    def _get_group_by_id(self, id_):
        try:
            return self.get_group_by_id(id_)
        except ValueError:
            return None

    def get_group_by_id(self, id_):
        """
        Returns a group definition for the id_ or raises ValueError
        @param id_: ID of the group to be fetched
        """
        result = {}

        # Fetch group definition
        res = self.db_handle.execute(GROUP_SELECT_BY_ID_SQL, (str(id_)))
        row = res.first()
        if row:
            result = {
                'id': id_,
                'name': row[0],
                'description': row[1],
                'author': row[2],
                'editor': row[3],
                'creation_time': row[4].strftime("%Y-%m-%d %H:%M:%S") \
                        if isinstance(row[4], datetime.datetime) \
                        else str(row[4]),
                'last_updated': row[5].strftime("%Y-%m-%d %H:%M:%S") \
                        if isinstance(row[5], datetime.datetime) \
                        else str(row[5]),
                'type': row[6],
                'query_map': row[7]
            }
        else:
            raise ValueError("Group %s does not exist" % id_)

        return result

    def _get_groups_by_attr(self, attr_name, attr_value, operator='='):
        result_list = []

        # Put attribute name and operator
        sql = GROUP_SELECT_BY_ATTR_SQL % (attr_name, operator, '%s')

        if operator == 'like':
            # Replace wildcard * with %
            attr_value = sanitize_input(attr_value, 'mysql')

        res = self.db_handle.execute(sql, (str(attr_value)))
        for row in res:
            result_list.append({
                'id': row[0],
                'name': row[1],
                'description': row[2],
                'author': row[3],
                'editor': row[4],
                'creation_time': row[5].strftime("%Y-%m-%d %H:%M:%S") \
                        if isinstance(row[5], datetime.datetime) \
                        else str(row[5]),
                'last_updated': row[6].strftime("%Y-%m-%d %H:%M:%S") \
                        if isinstance(row[6], datetime.datetime) \
                        else str(row[6]),
                'type': row[7],
                'query_map': row[8]
            })

        return result_list

    def get_groups_by_type(self, type_):
        """
        Returns group definitions for given type
        @param type_: Type of the groups to be fetched(* as wildcard)
        """
        return self._get_groups_by_attr('type', type_)

    def search_groups_by_name(self, name):
        """
        Returns group definitions for matching name
        @param name: Name of the groups to be fetched(* as wildcard)
        """
        return self._get_groups_by_attr('name', name, operator='like')

    def search_groups_by_description(self, desc):
        """
        Returns group definitions for matching description
        @param desc: Description of the groups to be fetched(* as wildcard)
        """
        return self._get_groups_by_attr('description', desc, operator='like')

    def search_groups(self,
                      filter_list=None,
                      result_list=None,
                      sort=None,
                      limit=100,
                      offset=0):
        """
        Returns requested group attributes for matching filters
        @param filter_list: Search criteria as listable filter
        @param result_list: List of group attributes as result
        @param sort: Sort criteria as a listable sort list
        @param limit: Records to be fetched
        @param offset: Offset from which the records to be fetched
        """

        if not filter_list and not result_list:
            return []

        query_map = self.group_listable.create_query_map()
        lt = self.group_listable['Group']
        if filter_list: lt.set_filters(query_map, filter_list)
        if result_list: lt.set_resultset(query_map, result_list)
        if sort: lt.set_query_options(query_map, sort)
        data = lt.get_data(query_map, self.db_handle, limit, offset)
        return self.group_listable.post_process(data, query_map,
                                                self.db_handle)

    def get_children(self, id_):
        """
        Returns a list of IDs of the sub-groups
        @param id_: ID of the parent group
        """
        children = []
        res = self.db_handle.execute(GROUP_CHILDREN_SELECT_SQL, (str(id_)))
        for row in res:
            children.append(row[0])

        return children

    def get_parents(self, id_):
        """
        Returns a list of IDs of the parent groups
        @param id_: ID of the child group
        """
        parents = []
        res = self.db_handle.execute(GROUP_PARENTS_SELECT_SQL, (str(id_)))
        for row in res:
            parents.append(row[0])

        return parents

    def get_all_groups(self, limit=100, offset=0, internal=False):
        """
        Returns group definitions of all the non-internal groups
        @param limit: Records to be fetched
        @param offset: Offset from which the next records to be fetched
        """
        # Fetch all group definition
        result_list = []
        res = self.db_handle.execute(GROUP_SELECT_ALL_SQL,
                                     (str(1)
                                      if internal else str(0), limit, offset))
        for row in res:
            result_list.append({
                'id': row[0],
                'name': row[1],
                'description': row[2],
                'author': row[3],
                'editor': row[4],
                'creation_time': row[5].strftime("%Y-%m-%d %H:%M:%S") \
                        if isinstance(row[5], datetime.datetime) \
                        else str(row[5]),
                'last_updated': row[6].strftime("%Y-%m-%d %H:%M:%S") \
                        if isinstance(row[6], datetime.datetime) \
                        else str(row[6]),
                'type': row[7],
                'query_map': row[8]
            })

        return result_list

    def get_group_members(self,
                          id_,
                          lazy_filter=None,
                          sort=None,
                          limit=100,
                          offset=0,
                          return_as='list'):
        """
        Returns members(show parameters) of a group
        @param id_: ID of a group whose members to be fetched
        @param lazy_filter: Values to be resolved for lazy placeholders
        @param sort: One or more group show parameters based on which the results are sorted
        @param limit: Records to be fetched
        @param offset: Offset from which the next records to be fetched
        @param return_as: Returned as 'list' or 'dict'
        """
        try:
            # Get group definition
            group = self.get_group_by_id(id_)

            # Extract query map from the group definition
            query_map = json.loads(group['query_map'])

            # Update query options(ORDER BY)
            root = query_map['show'][0].split('.')[0]
            lt = self.listables[root]
            lt.set_query_options(query_map, sort)

            # Fetch group members and post process
            data_list = lt.get_data(
                query_map,
                self.db_handle,
                limit=limit,
                offset=offset,
                lazy_filter=lazy_filter)

            if return_as == 'dict':
                data_list = self.listables.post_process(data_list, query_map,
                                                        self.db_handle)

            return data_list
        except KeyError as err:
            raise ValueError(
                "Cannot fetch members of group %s: Key %s not found" %
                (str(id_), str(err)))
        except (ValueError, TypeError) as err:
            raise ValueError("Cannot fetch members of group %s: %s" %
                             (str(id_), str(err)))

    def get_group_unconsumed_members(self,
                                     id_,
                                     lazy_filter=None,
                                     sort=None,
                                     limit=100,
                                     offset=0,
                                     return_as='list'):
        """
        Returns unique members(show parameters) of a group across
        all calls(even if the lazy_filters change).
        @param id_: ID of a group whose members to be fetched
        @param lazy_filter: Values to be resolved for lazy placeholders
        @param sort: One or more group show parameters based on which the results are sorted
        @param limit: Records to be fetched
        @param offset: Offset from which the next records to be fetched
        @param return_as: Returned as 'list' or 'dict'
        """
        try:
            # Get group definition
            group = self.get_group_by_id(id_)

            # Extract query map from the group definition
            query_map = json.loads(group['query_map'])

            # Amend the query to skip the consumed members(this is a hack)
            amendment_prefix = ""
            amendment_suffix = ""
            sub_query = "NOT IN ( SELECT member_id FROM AXGroupConsumedMembers " \
                    "WHERE group_id = %s )" % id_
            primary_object = query_map['show'][0].split('.')[0]
            primary_id = self.listables.get_primary_id(primary_object)

            if group['type'] != 'super':
                amendment_suffix = "AND %s.%s %s" % (primary_object,
                                                     primary_id, sub_query)
            else:
                amendment_prefix = "SELECT %s FROM ( " \
                    % ' '.join([p.split('.')[1] for p in query_map['show']])
                amendment_suffix = " ) AS AXSuperQuery WHERE AXSuperQuery.%s %s" \
                    % (primary_id, sub_query)

            query_map['full_query'].extend(amendment_suffix.split(' '))
            query_map['full_query'][0:0] = amendment_prefix.split(' ')

            # Update query options(ORDER BY)
            root = query_map['show'][0].split('.')[0]
            lt = self.listables[root]
            lt.set_query_options(query_map, sort)

            # Fetch group members and post process
            data_list = lt.get_data(
                query_map,
                self.db_handle,
                limit=limit,
                offset=offset,
                lazy_filter=lazy_filter)

            if return_as == 'dict':
                data_list = self.listables.post_process(data_list, query_map,
                                                        self.db_handle)

            return data_list
        except KeyError as err:
            raise ValueError(
                "Cannot fetch members of group %s: Key %s not found" %
                (str(id_), str(err)))
        except (ValueError, TypeError) as err:
            raise ValueError("Cannot fetch members of group %s: %s" %
                             (str(id_), str(err)))

    def consume_member(self, group_id, member_id):
        """
        Sets member of group as consumed i.e. never to be returned again
        by get_group_unique_members call until reset_consumed_members is called
        @param group_id: ID of the group whose member to be tagged as consumed
        @param member_id: Primary ID of the member of the group to be tagged as consumed
        """
        # Add memebr to consumed members for a group
        self.db_handle.execute(GROUP_CONSUMED_MEMBERS_INSERT_SQL,
                               (str(group_id), str(member_id)))

    def is_member_consumed(self, group_id, member_id):
        """
        Returns True if member of group is consumed already
        by get_group_unique_members call until reset_consumed_members is called
        @param group_id: ID of the group whose member to be tagged as consumed
        @param member_id: Primary ID of the member of the group to be tagged as consumed
        """
        res = self.db_handle.execute(GROUP_CONSUMED_MEMBERS_SELECT_SQL,
                                     (str(group_id), str(member_id)))
        return True if res.first() else False

    def reset_consumed_members(self, group_id):
        """
        Resets the consumed members for a group
        @param group_id: ID of the group to reset
        """
        # Reset group consumed members
        self.db_handle.execute(GROUP_CONSUMED_MEMBERS_DELETE_SQL,
                               (str(group_id)))

    def get_group_member_count(self, id_, lazy_filter=None):
        """
        Returns member count of a group
        @param id_: ID of a group whose member count to be fetched
        @param lazy_filter: Values to be resolved for lazy placeholders
        """
        try:
            # Get group definition
            group = self.get_group_by_id(id_)

            # Extract query map from the group definition
            query_map = json.loads(group['query_map'])

            # Instantiate listables
            root = query_map['show'][0].split('.')[0]
            lt = self.listables[root]

            return lt.get_count(
                query_map,
                self.db_handle,
                lazy_filter=lazy_filter,
                wrap=True if group['type'] == 'super' else False)
        except ValueError as err:
            raise ValueError("Cannot get member count for group %s: %s" %
                             (str(id_), str(err)))

    def get_group_membership(self, property_name, value):
        """
        Returns a list of non-lazy groups that the property value is member of
        @param property_name: Name of the property to be looked in
        @param value: Property value to be matched with group members
        """
        membership = []
        last_fetch_count = limit = 100
        offset = 0
        try:
            # Resolve property name if required
            property_name = self._resolve_property_name(property_name)

            # Don't fetch all groups at once but 100 at a time
            while last_fetch_count == limit:
                # Fetch a bunch of groups
                groups = self.get_all_groups(limit, offset)

                # Fetch count and set new offset for the next run
                last_fetch_count = len(groups)
                offset += limit

                # Iterate over groups to check if the requested value is a member
                for group in groups:
                    # Ignore lazy groups
                    if group['type'] == 'lazy':
                        continue

                    # Extract query map from the group definition
                    query_map = json.loads(group['query_map'])

                    # Skip the group if the object is not in its result set
                    if property_name not in query_map['show']:
                        continue

                    # Skip super group if it has lazy filters
                    if group['type'] == 'super':
                        # Instantiate listables
                        root = query_map['show'][0].split('.')[0]
                        lt = self.listables[root]
                        if lt.has_lazy_filter(query_map):
                            continue

                    if self.is_member(property_name, value, group['id']):
                        membership.append(group['id'])
        except ValueError as err:
            raise ValueError("Cannot fetch memberships for %s=%s: %s" %
                             (property_name, value, str(err)))

        return membership

    def _is_member_scan(self, property_name, value, group_id,
                        lazy_filter=None):
        # Don't fetch all records at once but 100 at a time
        record_last_fetch_count = record_limit = 100
        record_offset = 0
        while record_last_fetch_count == record_limit:
            members = self.get_group_members(
                group_id,
                lazy_filter,
                limit=record_limit,
                offset=record_offset,
                return_as='dict')

            # Fetch count and set new offset for the next run
            record_last_fetch_count = len(members)
            record_offset += record_limit

            # Fetch members of the super group and look through them
            for record in members:
                # Strip quotes from the value for comparision
                compare_value = value.strip('"')

                # Check if requested value in group
                if record[property_name] == compare_value:
                    return True

        return False

    def is_member(self, property_name, value, group_id, lazy_filter=None):
        """
        Checks if a property value is a memebr of a given group
        @param property_name: Name of the property to be looked in
        @param value: Property value to be matched with group members
        @param group_id: ID of a group against which the membership is verified
        @param lazy_filter: Values to be resolved for lazy placeholders
        """
        try:
            # Resolve property name if required
            property_name = self._resolve_property_name(property_name)

            # Get group definition
            group = self.get_group_by_id(group_id)

            # Extract query map from the group definition
            query_map = json.loads(group['query_map'])

            # Not a member if the object is not in its result set
            if property_name not in query_map['show']:
                return False

            # Special handling for super groups
            if group['type'] == 'super':
                return self._is_member_scan(property_name, value, group_id,
                                            lazy_filter)

            # Add the object id to the group filter and check is record exists
            root = query_map['show'][0].split('.')[0]
            lt = self.listables[root]
            filter_list = query_map['filters']
            extra_filter = ['and', [property_name, '=', value]]
            lt.set_filters(query_map, filter_list, extra_filter)

            data_list = lt.get_data(
                query_map, self.db_handle, limit=1, lazy_filter=lazy_filter)

            return True if data_list else False
        except KeyError as err:
            raise ValueError("Cannot verify membership for %s=%s against group %s: " \
                             "Key %s not found" % (property_name, value, str(group_id), str(err)))
        except (ValueError, TypeError) as err:
            raise ValueError(
                "Cannot verify membership for %s=%s against group %s: %s" %
                (property_name, value, str(group_id), str(err)))

    def _resolve_property_name(self, property_name):
        if not property_name:
            return None

        # Resolve property name if required
        if len(property_name.split('.')) == 1:
            property_name = '.'.join(
                (property_name, self.listables.get_primary_id(property_name)))

        return property_name
