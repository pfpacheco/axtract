from collections import defaultdict


def endless():
    return defaultdict(endless)


try:
    from _props_to_tree import _props_to_tree
    from _props_to_tree import _tree_to_props
    _use_c = True
except ImportError:
    _use_c = False


def py_props_to_tree(props):
    tree = endless()
    for name, value in props.iteritems():
        local = tree
        n = name.split('.')
        for x in n[:-1]:
            local = local[x]
        local[n[-1]] = value
    return tree


def c_props_to_tree(props):
    return _props_to_tree(props, endless())


if _use_c:
    props_to_tree = c_props_to_tree
else:
    props_to_tree = py_props_to_tree


def py_tree_to_props(tree):
    props = {}
    _recursive([], props, tree)
    return props


def _recursive(names, to_add, curr_node):
    if isinstance(curr_node, dict):
        for name, value in curr_node.iteritems():
            names.append(name)
            _recursive(names, to_add, value)
            names.pop()
    else:
        to_add['.'.join(names)] = curr_node


if _use_c:
    tree_to_props = _tree_to_props
else:
    tree_to_props = py_tree_to_props
