from ax.utils import listables as lt

class VSS(lt.SqlListable):
    """
    Template for Services Lists
    """
    is_axss            = 1 # just informational
    primary_id         = 'cid'
    count_childs_every = 600
    _excl_params       = ('servicetype', 'realStatusDetails')
    #actions = {"": [{'id': 'delete', 'label': 'del', 'title': 'wipe', 'confirm': 'sure?', 'target': ['delete', 'http://foo.com/bar/#: cid#']}]}
    @property
    def table(self):
        """we use the virtual view tables which can be automatically created from AXSS"""
        return 'vss_%s' % self.typ



p_ent      = {'type': 'Enterprise', 'on': ('cid2', 'cid')}
p_ent_EID  = {'type': 'Enterprise', 'on': 'EID'}
p_grp      = {'type': 'Location',   'on': ('cid2', 'cid')}
p_usr      = {'type': 'User',       'on': ('cid',  'cid')}
p_cpe      = {'type': 'CPE',        'on': ('cid2', 'cid')}
p_grp_esid = {'type': 'Location',   'on': 'extServiceid'}
p_enterprise_bw    = {
            'type': 'Enterprise',
            'on': ('broadworksEnterpriseId', 'EID')
        }

class MySchema(lt.Listables, lt.AxessSchema):
    class Enterprise(VSS):
        parent_types = []
        ico = 'fa-book'
        master_params = ['EID', 'count_User', 'cid', 'EnterpriseName', 'City',
                        'FirmenIndex']

    class DDI(VSS):
        parent_types = p_ent
        master_params = ['PhoneNumberStart', 'cid', 'RangeLength', 'Status']


    class Location(VSS):
        table = 'vss_Group'
        parent_types = p_ent
        master_params = ['extServiceid', 'cid', 'GroupName', 'DDI', 'City', 'Street']

    class User(VSS):
        parent_types = [p_grp, p_ent_EID]
        master_params = ['Alias', 'cid', 'Lastname', 'Firstname', 'Extension', 'DDI', 'UserID']

    class CPE(VSS):
        parent_types = [p_grp, p_ent_EID]
        master_params = ['MAC', 'cid', 'DeviceName', 'DeviceType']

    class VPN(VSS):
        parent_types = p_ent
        master_params = ['CvlanId', 'VrfId']

    class UserCpeRelation(VSS):
        parent_types = [p_usr, p_cpe]

MySchema.cpe.parent_types = [ { 'type': 'CPE', 'on': 'cpeid' } ]
MySchema.Ticket.parent_types.extend([
                {
                    'type': 'Enterprise',
                    'on': ('cid')
                    },
                {
                    'type': 'DDI',
                    'on': ('cid')
                    },
                {
                    'type': 'Location',
                    'on': ('cid')
                    },
                {
                    'type': 'User',
                    'on': ('cid')
                    },
                {
                    'type': 'CPE',
                    'on': ('cid')
                    },
                {
                    'type': 'UserCpeRelation',
                    'on': ('cid')
                    },
                ])
MySchema.Ticket.sort = [['last_updated', 'desc']]




from ax.utils.listables.adapters.axess.data.listz import List, ListUrlSchema

class Query(ListUrlSchema):
    """
    The default hirarchy we want to understand (and potentially restrict)
    in URLs
    """
    listables = MySchema
    class Enterprise(List):
        dflt_id = 'EID' # allows value only url filtering
        class DDI(List):
            dflt_id = 'cid'
        class UserCpeRelation(List):
            pass
        class Location(List):
            dflt_id = 'extServiceId'
            class User(List):
                dflt_id = 'UserID'
            class CPE(List):
                dflt_id = 'DeviceName'
            class cpe(List):
                dflt_id = 'cpeid'
        class Ticket(List):
            dflt_id = 'ticketid'
        class VPN(List):
            dflt_id = 'cid'

    top = Enterprise # default if root url is called


'''
# few example urls:

on [local vm](http://127.0.0.1:9063/live/API/WS/v1/project:MBC/AX/List/wax_list/Query/Enterprise/List/)

- [filters](http://127.0.0.1:9063/live/API/WS/v1/project:MBC/AX/List/wax_list/Query/Enterprise/Location/User/List/show/kv:ts,Las*/filters/Enterprise.City=%22M*%22%20and%20User.Lastname=%22Kilm*%22)
  `/filters/Enterprise.City="M*" and User.Lastname="Kilm*"`

- [postprocessing](http://127.0.0.1:9063/live/API/WS/v1/project:MBC/AX/List/wax_list/Query/Enterprise/300000/Location/User/List/show/kv:ts,creation_time:iso8601,Lastname,Enterprise.City,Enterprise.EID/_/Index/1/_/Get/data/_/Each/_/Get/E.City/E.EID)
(prevent overfetching)


- [even to
gui](http://127.0.0.1:9063/live/API/WS/v1/project:MBC/AX/List/wax_list/Query/Enterprise/Location/User/List/show/kv:/_/Index/1/_/Get/data/_/GUI/Table/Data)


http://127.0.0.1:9063/live/API/WS/v1/project:MBC/AX/List/wax_list/Query/Enterprise/200110/Location/User/List/show/kv:,Location.*,Enterprise.EID,Enterprise.City,User.Fir*,User.Las*/filters/Enterprise.City=%22*%22%20and%20User.Lastname=%22Schle*%22/_/Index/1/_/Get/data/_/GUI/Table/Data
ssh f -L9063:127.0.0.1:9063

```
-----

http://sd1:8085/live/ axgk 11po...

http://sd2:8085/dbui/sme/

http://sd2:9063/live/API/WS/v1/AX/List/wax_list_sme/SMEServiceList/SMEEnterprise/List/limit/10/

http://sd2:9063/live/API/WS/v1/project:MBC/AX/List/wax_list_mbc/MBCServiceList/Enterprise/Location/User/Params/
http://sd2:9063/live/API/WS/v1/project:MBC/AX/List/wax_list_mbc/MBCServiceList/Enterprise/Location/User/List/
http://sd2:9063/live/API/WS/v1/project:MBC/AX/List/wax_list_mbc/MBCServiceList/Enterprise/Location/User/List/show/cid,cid2,Enterprise.Stre*
http://sd2:9063/live/API/WS/v1/project:MBC/AX/List/wax_list_mbc/MBCServiceList/Enterprise/Location/User/List/show/cid,UserCpeRelation.*
http://sd2:9063/live/API/WS/v1/project:MBC/AX/List/wax_list_mbc/MBCServiceList/Enterprise/city:%22Munich%22/Location/User/List/show/cid,UserCpeRelation.*,Enterprise.City
http://sd2:9063/live/API/WS/v1/project:MBC/AX/List/wax_list_mbc/MBCServiceList/Enterprise/Location/User/List/show/kv:kva:ts,creation_time:iso8601
http://sd2:9063/live/API/WS/v1/project:MBC/AX/List/wax_list_mbc/MBCServiceList/Enterprise/Location/User/List/show/kv:ts,creation_time:iso8601,Lastname,Enterprise.City/_/Each/_/Out/filter/data
http://sd2:8085/live/API/WS/v1/project:MBC/Fmt/LT/_/AX/List/wax_list_mbc/MBCServiceList/Enterprise/999958/Location/User/List/show/kv:ts,creation_time:iso8601,Lastname,Enterprise.City,Enterprise.EID/
http://sd2:8085/live/API/WS/v1/project:MBC/AX/List/wax_list_mbc/MBCServiceList/Enterprise/999958/Location/User/List/show/kv:ts,creation_time:iso8601,Lastname,Enterprise.City,Enterprise.EID/_/Index/1/_/Get/data/_/Each/_/Get/E.City/E.EID

'''

