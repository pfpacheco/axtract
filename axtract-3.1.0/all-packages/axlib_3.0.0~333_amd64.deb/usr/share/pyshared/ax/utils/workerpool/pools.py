# workerpool.py - Module for distributing jobs to a pool of worker threads.
# Copyright (c) 2008 Andrey Petrov
#
# This module is part of workerpool and is released under
# the MIT license: http://www.opensource.org/licenses/mit-license.php

from ax.utils.ax_queue import AXQueue as Queue
from ax.utils.logging import setup_logging_for_library

from workers import Worker
from jobs import SimpleJob
from jobs import SuicideJob
from jobs import RendezvousJob

__all__ = ['WorkerPool', 'default_worker_factory']


def default_worker_factory(job_queue):
    return Worker(job_queue)


class WorkerPool(Queue):
    """
    WorkerPool servers two functions: It is a Queue and a master of Worker
    threads. The Queue accepts Job objects and passes it on to Workers, who are
    initialized during the construction of the pool and by using grow().

    Jobs are inserted into the WorkerPool with the `put` method.
    Hint: Have the Job append its result into a shared queue that the caller
    holds and then the caller reads an expected number of results from it.

    The shutdown() method must be explicitly called to terminate the Worker
    threads when the pool is no longer needed.

    Construction parameters:

    size = 1
        Number of active worker threads the pool should contain.

    maxsize = 0
        Maximum number of active worker threads the pool should contain.
        An IndexError will be raised if you attempt to grow the pool beyond
        that limit. A value of 0 indicates that no limit should be applied.

    maxjobs = 0
        Maximum number of jobs to allow in the queue at a time. Will block on
        `put` if full.

    default_worker = default_worker_factory
        The default worker factory is called with one argument, which is the
        jobs Queue object that it will read from to acquire jobs. The factory
        will produce a Worker object which will be added to the pool.

    logger = 'ax.utils.workerpool'
        The logger to use for logging throughout the pool. This can either be a
        string (=interpreted as name of the logger to use) or a logger object
        that is ready to be used.
    """
    def __init__(self, size=1, maxsize=0, maxjobs=0,
                 worker_factory=default_worker_factory,
                 logger='ax.utils.workerpool'):
        if not callable(worker_factory):
            raise TypeError("worker_factory must be callable")

        self.worker_factory = worker_factory  # Used to build new workers
        self._size = 0  # Number of active workers we have
        self._maxsize = maxsize

        # Initialize the Queue
        # The queue contains job that are read by workers
        super(WorkerPool, self).__init__(maxjobs)

        if isinstance(logger, basestring):
            self.logger = setup_logging_for_library(logger)
        else:
            # Assume it is some already-instantiated logger object.
            self.logger = logger

        # Hire some workers!
        for i in xrange(size):
            self.grow()

    def grow(self):
        "Add another worker to the pool."
        if self._maxsize and self._size >= self._maxsize:
            raise IndexError("WorkerPool already at the limit of %s threads" %
                    self._maxsize)
        worker = self.worker_factory(self)
        worker.start()
        self._size += 1

    def shrink(self):
        "Get rid of one worker from the pool. Raises IndexError if empty."
        if self._size <= 0:
            raise IndexError("pool is already empty")
        self._size -= 1
        self.put(SuicideJob())

    def shutdown(self):
        "Retire the workers."
        for i in xrange(self.size()):
            self.put(SuicideJob())

    def size(self):
        """Return approximate number of active workers

        If a shrinking is in progress, there could temporarily be more worker
        threads than this method reports.
        """
        return self._size

    def map(self, fn, *seq):
        """Perform map operation distributed to the workers, return the results

        This call will block until the map operation is done. It returns a
        list of the individual results.
        """
        results = Queue()
        args = zip(*seq)
        for seq in args:
            job = SimpleJob(results, fn, seq)
            self.put(job)

        # Aggregate results
        retval = []
        for i in xrange(len(args)):
            retval.append(results.get())

        return retval

    def run_on_all_threads(self, job, timeout=60):
        # The job.run() method *must* be thread-safe
        # Set the _timeout to None if you want to wait endless

        wrapped_job = RendezvousJob(self, job, timeout)
        for _ in range(self.size()):
            self.put(wrapped_job)
