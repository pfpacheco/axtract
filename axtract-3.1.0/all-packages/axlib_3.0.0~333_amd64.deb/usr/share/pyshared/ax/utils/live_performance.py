#!/usr/bin/python -tt
"""Print live performance numbers based on log files/streams

The log file is parsed for time stamps, and all log lines for a certain second
are counted together and the number is printed. Use this program like

    ./live_performance.py whatever.log

to analyze all of whatever.log, then terminate. Use it like

    ./live_performance.py -f whatever.log

to follow any new data in whatever.log, which replaces "tail". You can also

    grep Exception whatever.log | ./live_performance.py

to see how many exceptions (or anything else) you had per second.

There are currently two parsers available. The default parser will understand
log lines like

2014-06-25 15:16:55

followed by any arbitrary stuff. With --mode=apache it understands

127.0.0.1:80 212.42.121.244 - - [14/Sep/2014:11:06:28 +0200]

followed by arbitrary stuff.
"""
from __future__ import print_function

import datetime
import os
import sys
import time
from optparse import OptionParser
from stat import ST_DEV, ST_INO


# Stuff that would be nice to have:
# - Currently, performance is given per second. Allow other intervals, too.
# - When no more log output is received, the last 2 seconds remain invisible.

DEBUG = False
NO_TIME = datetime.datetime(1970, 1, 1)
TEN_MINUTES = datetime.timedelta(minutes=10)

class LivePerformance(object):
    def __init__(self):
        self.cur_ts = self.last_ts = NO_TIME
        self.cur_count = self.last_count = 0

        self.device = self.inode = self.fd = None
        self.buf = ""

        self.output_format = None
        self.follow = None
        self.fd = self.fd_name = None
        self.parse_cli_args()
        self.open_file()
        if self.fd is None:
            sys.exit(1)

    def parse_cli_args(self):
        parser = OptionParser()

        parser.add_option("--format", dest="output_format",
                default="{time}: {count} /sec",
                help="Use {time} and {count} in the format")
        parser.add_option("--mode",
                default="iso8601",
                help="Either 'iso8601' or 'apache'")
        parser.add_option("-f", "-F", "--follow",
                action="store_true", dest="follow", default=False,
                help="Behave like 'tail --follow=name --retry'.")

        options, args = parser.parse_args()
        if len(args) > 2:
            raise ValueError("Too many args: %s" % args)
        elif len(args) == 1:
            self.fd_name = args[0]
        else:
            self.fd_name = "-"

        self.output_format = options.output_format
        self.follow = options.follow

        if options.mode == "iso8601":
            self.parse_line = self.parse_line_iso8601
        elif options.mode == "apache":
            self.parse_line = self.parse_line_apache
        else:
            raise ValueError("Invalid parse mode: '%s'" % parser.mode)

    def open_file(self):
        if self.fd_name == "-":
            self.fd = sys.stdin
            return

        try:
            new_file = open(self.fd_name, "r", 0)
            stat = os.fstat(new_file.fileno())
            device, inode = stat[ST_DEV], stat[ST_INO]
        except Exception:
            print("Could not (re-)open file.", file=sys.stderr)
            self.device, self.inode = None, None
            self.fd = None
            return

        # Potentially re-opening a file, maybe after a logrotate.
        if device == self.device and inode == self.inode:
            # This is still the same file, keep the old file
            # descriptor, close the new one.
            new_file.close()
        else:
            # New file has appeared.
            if self.fd is not None:
                self.fd.close()
            self.fd = new_file
            self.device, self.inode = device, inode

            if self.follow:
                self.fd.seek(0, os.SEEK_END)

    def print_stats(self):
        """Print stats for last second, switch to next second"""
        if self.last_ts is NO_TIME:
            # Nothing to print so far
            pass
        else:
            try:
                print(self.output_format.format(
                        time=self.last_ts, count=self.last_count))
            except IOError:
                # Happens when our output is piped to another program and that
                # program terminates (e.g. "head").
                sys.exit(0)

        self.last_ts = self.cur_ts
        self.last_count = self.cur_count

    def parse_line(self, line):
        """Will be overwritten according to --mode"""
        pass

    def parse_line_iso8601(self, line):
        """For the given line of log file, return the datetime"""
        # Log format is like
        #   2014-09-22 11:50:56,891 asfd asf asdf a sd asd
        # We don't care about the fractional seconds -> first 19 bytes.
        return datetime.datetime.strptime(line[:19], "%Y-%m-%d %H:%M:%S")

    def parse_line_apache(self, line):
        """For the given line of log file, return the datetime"""
        # Date format is like
        #   127.0.0.1:80 10.0.0.42 - - [06/Sep/2014:06:49:37 +0200] "POST /cwmpWeb/CPEMgt HTTP/1.1" 204 197 "-" "foobar"
        fields = line.split(" ", 5)

        if len(fields) < 6:
            raise ValueError

        # This should give us "06/Sep/2014:06:49:37".
        time_spec = fields[4][1:]
        if DEBUG: print("time spec:", time_spec)
        return datetime.datetime.strptime(time_spec, "%d/%b/%Y:%H:%M:%S")

    def process_line(self, line):
        try:
            date = self.parse_line(line)
        except ValueError:
            # When backtraces are logged, the lines do not contain valid dates.
            # This is expected, nothing to count here.
            return

        if date == self.cur_ts:
            # Still on the same second.
            self.cur_count += 1
        elif date == self.last_ts:
            # This one is a bit late, but we still count it.
            self.last_count += 1
        elif date > self.cur_ts:
            # Next second has started.
            self.print_stats()
            self.cur_ts = date
            self.cur_count = 1
        elif date < self.last_ts - TEN_MINUTES:
            # It seems time jumped back. Either daylight saving time or someone
            # activated NTP.
            self.print_stats()
            self.cur_ts = date
            self.cur_count = 1
        else:
            # This one must be very late, cannot count it
            # TODO: write to stderr.
            pass

    def next_line(self):
        """Return the next line from self.fd, or None

        Python's readline() on STDIN is too magic, with this code we actually
        know what is happening.
        """
        if self.fd is None:
            return None
        # Make sure we have at least one new line or EOF.
        while "\n" not in self.buf:
            new_data = self.fd.read(4096)
            if not new_data:
                return None
            self.buf += new_data

        line, self.buf = self.buf.split("\n", 1)
        return line

    def run(self):
        while True:
            try:
                if DEBUG: print("reading from", self.fd)
                while True:
                    line = self.next_line()
                    if line is None:
                        # EOF
                        break
                    #if DEBUG: print("line is", line)
                    self.process_line(line)

                # We got EOF.
                if DEBUG: print("Got EOF", file=sys.stderr)
                if self.fd_name == "-":
                    # We were reading from STDIN. Whoever opened the pipe that
                    # provided us with data has terminated, so we should also
                    # terminate. Still print stats for the previous and current
                    # second, though.
                    self.print_stats()
                    self.print_stats()
                    return
                if not self.follow:
                    # We parsed the entire file now and were NOT told to follow
                    # further updates -> terminate successfully.
                    sys.exit(0)

                # We are reading from a normal file and got EOF, but we were
                # told to keep following that file.
                time.sleep(0.5)
                self.open_file()
            except KeyboardInterrupt:
                self.print_stats()
                self.print_stats()
                return


if __name__ == "__main__":
    LivePerformance().run()

