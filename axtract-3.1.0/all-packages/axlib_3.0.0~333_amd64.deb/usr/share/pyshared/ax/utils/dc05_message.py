"""
Module for handling DC-05 messages

Provides methods for de/encoding, checksum calculation and basic sanity checks.
"""
class DC05Error(Exception):
    """Base class for all exceptions in DC05 message de/encoding"""
    pass
class DC05DecodeError(Exception):
    """Base class for all exceptions in DC05 message decoding"""
    pass

class DC05WrongChecksumError(DC05DecodeError):
    """Is thrown when a message has the wrong checksum."""
    pass

class DC05InvalidCharsError(DC05DecodeError):
    """Is thrown if a message contains invalid characters."""
    pass

class DC05Message(object):
    """Represent a single message of DC-05 (SIA DC-05-1999.09)
    """
    # These can appear in a message an need not be converted
    allowed_upper = "0123456789BCDEF"
    # These can appear in a message and must be converted to upper case.
    allowed_lower = "bcdef"
    def __init__(self, message=None):

        # The parts of the message, see section 4.1.2.2 in the DC-05 standard.
        # 4 digits (0-9,B-F)
        self.account = None
        # Either "18" or "98".
        self.message_type = None
        # One of "1", "3", "6"
        self.qualifier = None
        # 3 digits (0-9,B-F)
        self.event_code = None
        # 2 digits (0-9,B-F), also called "partition number" in DC-05
        self.group = None
        # 3 digits (0-9,B-F)
        self.zone_number = None
        # 1 digit. (sum_of_all_digits + self.checksum) % 15 == 0)
        self.checksum = None

        # The normalized message string that this object represents
        self.message_string = None

        if message is not None:
            self.decode_message(message)

    def encode_message(self):
        """Encode self, verify and return encoded data.

        Will raise an instance of DC05ParserException if the encoded data
        is incorrect (=some self.xxx field is invalid).
        """
        body = "".join((self.account, self.message_type, self.qualifier,
                self.event_code, self.group, self.zone_number))
        checksum = self.get_checksum(body)

        message = body + checksum
        self.verify_normalized_message(message)
        return message

    def decode_message(self, message_string):
        """Decode and verify given message_string"""
        normalized = self.normalize_message_string(message_string)
        self.verify_normalized_message(normalized)

        try:
            self.account = normalized[0:4]
            self.message_type = normalized[4:6]
            self.qualifier = normalized[6:7]
            self.event_code = normalized[7:10]
            self.group = normalized[10:12]
            self.zone_number = normalized[12:15]
            self.checksum = normalized[15:16]
            self.message_string = normalized
        except Exception:
            # Should never get here.
            raise DC05DecodeError("Unexpected error")

    def verify_normalized_message(self, normalized_message_string):
        """Perform checks on an already normalized message string

        Raises an instance of DC05ParserException if something is wrong.
        """
        if len(normalized_message_string) != 16:
            raise DC05DecodeError(
                    "Message has incorrect length %s" % (
                        len(normalized_message_string)))

        # Check if fields are valid
        message_type = normalized_message_string[4:6]
        if message_type not in ("18", "98"):
            raise DC05DecodeError(
                    "Message type is '%s'. Expected '18' or '98'" % (
                        message_type))
        qualifier = normalized_message_string[6]
        if qualifier not in ("1", "3", "6"):
            raise DC05DecodeError(
                    "Qualifier type is '%s'. Expected 1, 3, or 6" % qualifier)

        # Verify checksum
        checksum = normalized_message_string[15:16]
        expected_checksum = self.get_checksum(normalized_message_string[:-1])
        if checksum != expected_checksum:
            raise DC05WrongChecksumError(
                    "Wrong checksum. Expected: '%s' In message: '%s'" % (
                        expected_checksum, self.checksum))

    def normalize_message_string(self, message_string):
        """Return normalized form of message_string.

        Normalizations performed:
            * remove whitespace
            * convert lower case to upper case
        Exception is thrown if an invalid character is found. No check is made
        if the message itself is correct.
        """
        normalized = []
        for pos, char in enumerate(message_string):
            if char == " " or char == "\t":
                pass
            elif char in self.allowed_upper:
                normalized.append(char)
            elif char in self.allowed_lower:
                normalized.append(char.upper())
            else:
                raise DC05InvalidCharsError(
                        "Invalid character at index %s, ASCII code=%s" % (
                            pos, ord(char)))
        return "".join(normalized)

    @classmethod
    def get_checksum(cls, message_string):
        """Return checksum digit for given message_string

        message_string must only contain valid digits. See section 4.1.2.2 and
        Appendix A, Example 1 for instructions.
        """
        sum_of_all_digits = 0
        for char in message_string:
            if char == "0":
                sum_of_all_digits += 10
            else:
                sum_of_all_digits += int(char, 16)

        checksum = 15 - (sum_of_all_digits % 15)
        if checksum == 0:
            retval = "F"
        else:
            retval = hex(checksum)[2:].upper()
        return retval

class DC05MessageAltibox(DC05Message):
    """DC05 message with modifications, as used by Altibox

    Modifications are:
        * Account number is 6 digits, not 4
        * There must be a space after the Account number
        * Checksum is 16 bit instead of 8, custom algorithm
            * This means that "A" is a legitimate character
    This format is used at Altibox, probably also at Lyse and maybe elsewhere.
    """
    # These can appear in a message an need not be converted
    allowed_upper = "0123456789ABCDEF"
    # These can appear in a message and must be converted to upper case.
    allowed_lower = "abcdef"

    def __init__(self, message=None):
        super(DC05MessageAltibox, self).__init__(message)

    def get_checksum(self, message_string):
        """Modified checksum algorithm used at Altibox

        There's no spec for this one, it was reverse-engineered from the output
        of Altibox's message generator.
        Input: String to checksum
        Ouput: String of 4 upper case hex characters that is the checksum.
        """
        crc1 = 0
        crc2 = 0
        for char in message_string:
            temp = ord(char)
            crc1 = (crc1 + crc2 + temp) % 256
            crc2 = (crc2 + temp) % 256

        return "%02X%02X" % (crc1, crc2)

    def encode_message(self):
        # Outgoing messages must have a " " after the account number.
        body = "".join((self.account, " ", self.message_type, self.qualifier,
                self.event_code, self.group, self.zone_number))
        checksum = self.get_checksum(body)

        return body + checksum

    def decode_message(self, message_string):
        """Decode and verify given message_string"""
        # Verify checksum
        # Checksum calculation includes the space character after the account
        # number, so this must be done before normalization.
        checksum = message_string[-4:]
        expected_checksum = self.get_checksum(message_string[:-4])
        if checksum != expected_checksum:
            raise DC05WrongChecksumError(
                    "Wrong checksum. Expected: '%s' In message: '%s'" % (
                        expected_checksum, self.checksum))

        normalized = self.normalize_message_string(message_string)
        self.verify_normalized_message(normalized)

        try:
            self.account = normalized[0:6]
            self.message_type = normalized[6:8]
            self.qualifier = normalized[8:9]
            self.event_code = normalized[9:12]
            self.group = normalized[12:14]
            self.zone_number = normalized[14:17]
            self.checksum = normalized[17:21]
            self.message_string = normalized
        except Exception:
            # Should never get here.
            raise DC05DecodeError("Unexpected error")

    def verify_normalized_message(self, normalized_message_string):
        """Perform checks on an already normalized message string

        Raises an instance of DC05ParserException if something is wrong.
        """
        if len(normalized_message_string) != 21:
            raise DC05DecodeError(
                    "Message has incorrect length %s" % (
                        len(normalized_message_string)))

        # Check if fields are valid
        message_type = normalized_message_string[6:8]
        if message_type not in ("18", "98"):
            raise DC05DecodeError(
                    "Message type is '%s'. Expected '18' or '98'" % (
                        message_type))
        qualifier = normalized_message_string[8]
        if qualifier not in ("1", "3", "6"):
            raise DC05DecodeError(
                    "Qualifier type is '%s'. Expected 1, 3, or 6" % qualifier)
