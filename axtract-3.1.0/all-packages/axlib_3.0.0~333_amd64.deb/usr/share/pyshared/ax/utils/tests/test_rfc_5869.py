#!/usr/bin/python -tt
import unittest
from Crypto.Hash import SHA, SHA256

from ax.utils.rfc_5869 import HKDF

# Convert binary string to hex-string.
BIN2HEX = lambda binary: "".join(["%02x" % ord(char) for char in binary])

class TestHKDF(unittest.TestCase):
    def test_appendix_A_case_1(self):
        """Test case taken from RFC 5869 Appendix A.1"""
        ikm = "\x0b" * 22
        salt = "".join(map(chr, range(13)))
        info = "".join(map(chr, range(240, 250)))
        dkLen = 42

        # Must implicitly use SHA256.
        okm = HKDF(ikm, salt=salt, dkLen=dkLen, info=info)

        expected_okm = "3cb25f25faacd57a90434f64d0362f2a2d2d0a90cf1a5a4c5db02d56ecc4c5bf34007208d5b887185865"
        self.assertEqual(BIN2HEX(okm), expected_okm)

    def test_appendix_A_case_2(self):
        """Test case taken from RFC 5869 Appendix A.2"""
        hashAlgo = SHA256
        ikm = "".join([chr(x) for x in range(0, 80)])
        salt = "".join([chr(x) for x in range(0x60, 0x60 + 80)])
        info = "".join([chr(x) for x in range(0xb0, 0xb0 + 80)])
        dkLen = 82

        # Explicitly provide SHA256.
        okm = HKDF(ikm, salt=salt, dkLen=dkLen, info=info, hashAlgo=hashAlgo)

        expected_okm = "b11e398dc80327a1c8e7f78c596a49344f012eda2d4efad8a050cc4c19afa97c59045a99cac7827271cb41c65e590e09da3275600c2f09b8367793a9aca3db71cc30c58179ec3e87c14c01d5c1f3434f1d87"
        self.assertEqual(BIN2HEX(okm), expected_okm)

    def test_appendix_A_case_3(self):
        """Test case taken from RFC 5869 Appendix A.3"""
        hashAlgo = SHA256
        ikm = "\x0b" * 22
        salt = ""
        info = ""
        dkLen = 42

        okm = HKDF(ikm, salt=salt, dkLen=dkLen, info=info, hashAlgo=hashAlgo)

        expected_okm = "8da4e775a563c18f715f802a063c5a31b8a11f5c5ee1879ec3454e5f3c738d2d9d201395faa4b61a96c8"
        self.assertEqual(BIN2HEX(okm), expected_okm)

    def test_appendix_A_case_4(self):
        """Test case taken from RFC 5869 Appendix A.4"""
        hashAlgo = SHA
        ikm = "\x0b" * 11
        salt = "".join([chr(x) for x in range(0, 13)])
        info = "".join([chr(x) for x in range(0xf0, 0xf0 + 10)])
        dkLen = 42

        okm = HKDF(ikm, salt=salt, dkLen=dkLen, info=info, hashAlgo=hashAlgo)

        expected_okm = "085a01ea1b10f36933068b56efa5ad81a4f14b822f5b091568a9cdd4f155fda2c22e422478d305f3f896"
        self.assertEqual(BIN2HEX(okm), expected_okm)

    def test_appendix_A_case_5(self):
        """Test case taken from RFC 5869 Appendix A.5"""
        hashAlgo = SHA
        ikm = "\x0b" * 11
        salt = "".join([chr(x) for x in range(0, 13)])
        info = "".join([chr(x) for x in range(0xf0, 0xf0 + 10)])
        dkLen = 42

        okm = HKDF(ikm, salt=salt, dkLen=dkLen, info=info, hashAlgo=hashAlgo)

        expected_okm = "085a01ea1b10f36933068b56efa5ad81a4f14b822f5b091568a9cdd4f155fda2c22e422478d305f3f896"
        self.assertEqual(BIN2HEX(okm), expected_okm)

    def test_appendix_A_case_6(self):
        """Test case taken from RFC 5869 Appendix A.6"""
        hashAlgo = SHA
        ikm = "\x0b" * 22
        salt = ""
        info = ""
        dkLen = 42

        okm = HKDF(ikm, salt=salt, dkLen=dkLen, info=info, hashAlgo=hashAlgo)

        expected_okm = "0ac1af7002b3d761d1e55298da9d0506b9ae52057220a306e07b6b87e8df21d0ea00033de03984d34918"
        self.assertEqual(BIN2HEX(okm), expected_okm)

    def test_appendix_A_case_7(self):
        """Test case taken from RFC 5869 Appendix A.7"""
        hashAlgo = SHA
        ikm = "\x0c" * 22
        info = ""
        dkLen = 42

        okm = HKDF(ikm, dkLen=dkLen, info=info, hashAlgo=hashAlgo)

        expected_okm = "2c91117204d745f3500d636a62f64f0ab3bae548aa53d423b0d1f27ebba6f5e5673a081d70cce7acfc48"
        self.assertEqual(BIN2HEX(okm), expected_okm)


if __name__ == "__main__":
    unittest.main()

