#!/usr/bin/python -tt

import unittest2
from datetime import datetime
from ax.utils.cron_time import CronTime

class CronSynTester(unittest2.TestCase):

    def test_parse_single_number(self):
        cron = CronTime()
        friday = cron._parse_single_number("Fri", is_dow=True, max_value=7)
        self.assertEqual(friday, 5)
        monday = cron._parse_single_number("1", is_dow=True, max_value=7)
        self.assertEqual(monday, 1)
        saturday = cron._parse_single_number("SAT", is_dow=True, max_value=7)
        self.assertEqual(saturday, 6)
        sunday = cron._parse_single_number("suN", is_dow=True, max_value=7)
        self.assertEqual(sunday, 0)

    def test_parse_range(self):
        cron = CronTime()
        seperated_values = cron._parse_range("8-12", is_month=True, max_value=12)
        self.assertEqual(seperated_values, [8, 9, 10, 11, 12])
        seperated_values = cron._parse_range("Mon-Wed", is_dow=True, max_value=7)
        self.assertEqual(seperated_values, [1, 2, 3])
        seperated_values = cron._parse_range("Fri-Sat", is_dow=True, max_value=7)
        self.assertEqual(seperated_values, [5, 6])
        seperated_values = cron._parse_range(
                "Jan-Mar", is_month=True, max_value=31)
        self.assertEqual(seperated_values, [1, 2, 3])

    def test_parse_asterisk(self):
        cron = CronTime()
        all_values = cron._parse_asterisk(max_value=12, min_value=1)
        self.assertEqual(all_values, set(range(1, 13)))
        all_values = cron._parse_asterisk(max_value=59)
        self.assertEqual(all_values, set(range(60)))
        all_values = cron._parse_asterisk(max_value=6)
        self.assertEqual(all_values, set([0, 1, 2, 3, 4, 5, 6]))
        all_values = cron._parse_asterisk(max_value=23)
        self.assertEqual(all_values, set(range(24)))
        all_values = cron._parse_asterisk(max_value=31, min_value=1)
        self.assertEqual(all_values, set(range(1, 32)))

    def test_parse_minute(self):
        cron = CronTime()
        test_min = cron._parse_field("1,2,3,4,5", max_value=59)
        self.assertEqual(test_min, set([1, 2, 3, 4, 5]))
        test_min = cron._parse_field("1,2,3-5", max_value=59)
        self.assertEqual(test_min, set([1, 2, 3, 4, 5]))
        test_min = cron._parse_field("1-10/2", max_value=59)
        self.assertEqual(test_min, set([1, 3, 5, 7, 9]))
        test_min = cron._parse_field("0-59", max_value=59)
        self.assertEqual(test_min, set(range(60)))
        test_min = cron._parse_field("*", max_value=59)
        self.assertEqual(test_min, set(range(60)))

    def test_parse_hour(self):
        cron = CronTime()
        test_hour = cron._parse_field("*", max_value=23)
        time_list = list(xrange(24))
        self.assertEqual(test_hour, set(time_list))

    def test_parse_day_of_month(self):
        cron = CronTime()
        test_dom = cron._parse_field("*", max_value=31, min_value=1)
        self.assertEqual(test_dom, set(range(1, 32)))

        test_dom = cron._parse_field("1,13-18,20,1-31/2",
                max_value=31, min_value=1)
        self.assertEqual(test_dom,
                set([1,3,5,7,9,11,13,14,15,16,17,18,19,20,21,23,25,27,29,31]))

    def test_parse_month(self):
        cron = CronTime()
        test_month = cron._parse_field("Jan,Feb,Jun,Jul", is_month=True, max_value=12, min_value=1)
        self.assertEqual(test_month, set([1, 2, 6, 7]))
        test_month = cron._parse_field("Jul-Oct", is_month=True, max_value=12, min_value=1)
        self.assertEqual(test_month, set([7, 8, 9, 10]))
        test_month = cron._parse_field("*", is_month=True, max_value=12, min_value=1)
        self.assertEqual(test_month, set(range(1, 13)))

    def test_parse_day_of_week(self):
        cron = CronTime()
        test_dow = cron._parse_day_of_week("MON-FRI/2")
        self.assertEqual(test_dow, set([1, 3, 5]))
        test_dow = cron._parse_day_of_week("1")
        self.assertEqual(test_dow, set([1]))
        test_dow = cron._parse_day_of_week("7")
        self.assertEqual(test_dow, set([0]))
        test_dow = cron._parse_day_of_week("Sun")
        self.assertEqual(test_dow, set([0]))
        test_dow = cron._parse_day_of_week("1-7")
        self.assertEqual(test_dow, set([1, 2, 3, 4, 5, 6]))
        with self.assertRaises(Exception):
            cron._parse_day_of_week("Mon-Sun")
        test_dow = cron._parse_day_of_week("0-7")
        self.assertEqual(test_dow, set([0, 1, 2, 3, 4, 5, 6]))
        test_dow = cron._parse_day_of_week("*")
        self.assertEqual(test_dow, set([0, 1, 2, 3, 4, 5, 6]))

    def test_human_readable(self):
        cron = CronTime("* * * * *")
        expected = ("every minute, every hour, every day of month, "
                "every month, and every day of the week")
        self.assertEqual(cron.human_readable, expected)

        cron.parse("1 1 1 1 *")
        expected = ("in minute 1, in hour 1, on day 1, in month "
                "January, and every day of the week")
        self.assertEqual(cron.human_readable, expected)

        cron.parse("1-10/2      10-17/2       3-4,5  1  Mon-Wed")
        expected = ("in minute 1, 3, 5, 7, 9, in hour 10, 12, 14, "
                "16, on day 3, 4, 5, in month January, and on Monday, "
                "Tuesday, and Wednesday")
        self.assertEqual(cron.human_readable, expected)

    def test_cron_readable(self):
        cron = CronTime()

        cron.parse("* * * * *")
        self.assertEqual(cron.cron_readable, "* * * * *")

        cron.parse("1,2,3 * * * 4,3,2,1")
        self.assertEqual(cron.cron_readable, "1-3 * * * 1-4")

        cron.parse("10-15,3-5,9 * * * mon")
        self.assertEqual(cron.cron_readable, "3-5,9-15 * * * 1")

        cron.parse("0-59 6,4,2 * * *")
        self.assertEqual(cron.cron_readable, "* 2,4,6 * * *")

    def test_crazy_dow(self):
        """Test strange day-of-week fields

        Mostly, this tests how the various "Sunday" definitions are implemented.
        """
        cron = CronTime()

        ret = cron._parse_day_of_week("sun-7")
        self.assertEqual(ret, set([0, 1, 2, 3, 4, 5, 6]))

        ret = cron._parse_day_of_week("0-7")
        self.assertEqual(ret, set([0, 1, 2, 3, 4, 5, 6]))

        ret = cron._parse_day_of_week("sun-mon")
        self.assertEqual(ret, set([0, 1]))

        ret = cron._parse_day_of_week("sun-sun")
        self.assertEqual(ret, set([0]))

        ret = cron._parse_day_of_week("0-sun")
        self.assertEqual(ret, set([0]))

        ret = cron._parse_day_of_week("sun-0")
        self.assertEqual(ret, set([0]))

        ret = cron._parse_day_of_week("0-0")
        self.assertEqual(ret, set([0]))

        ret = cron._parse_day_of_week("7-7")
        self.assertEqual(ret, set([0]))

        ret = cron._parse_day_of_week("1-7")
        self.assertEqual(ret, set([1, 2, 3, 4, 5, 6]))

        # Vixie cron thinks these are invalid:
        for invalid_range in ("7-sun", "7-0", "mon-sun"):
            with self.assertRaises(Exception):
                cron._parse_day_of_week(invalid_range)

    def test_crazy_cases(self):
        """Various syntactically correct but highly unusual cases"""
        cron = CronTime()

        # Various "/" constructs should behave as in Vixie Cron.
        retval = cron._parse_field("*/60", max_value=59)
        self.assertEqual(retval, set([0]))
        retval = cron._parse_field("*/600", max_value=59)
        self.assertEqual(retval, set([0]))
        retval = cron._parse_field("10/600", max_value=59)
        self.assertEqual(retval, set([10]))
        retval = cron._parse_field("10/*", max_value=59)
        self.assertEqual(retval, set([10]))
        retval = cron._parse_field("10/1", max_value=59)
        self.assertEqual(retval, set([10]))
        test_odd = cron._parse_field("*/13", max_value=59)
        self.assertEqual(test_odd, set([0, 13, 26, 39, 52]))
        with self.assertRaises(Exception):
            cron._parse_field("*/*", max_value=59)

        # Ranges, ranges with "/"
        retval = cron._parse_field("2-2", max_value=59)
        self.assertEqual(retval, set([2]))
        retval = cron._parse_field("1-10/1", max_value=59)
        self.assertEqual(retval, set(range(1, 11)))
        with self.assertRaises(Exception):
            cron.parse_minute("4-2")

        # February 30th will never happen, but is syntactically correct.
        retval = CronTime("* * 30 Feb *")
        expected = ("every minute, every hour, on day 30, in month "
                "February, and every day of the week")
        self.assertEqual(retval.human_readable, expected)

    def test_external_properties(self):
        """External properties must be set after parsing"""
        cron = CronTime()
        self.assertTrue(cron.minutes is None)
        self.assertTrue(cron.hours is None)
        self.assertTrue(cron.dow is None)
        self.assertTrue(cron.dom is None)
        raw = "1 2 3 4 5"
        cron.parse(raw)
        self.assertEqual(cron.minutes, set([1]))
        self.assertEqual(cron.hours, set([2]))
        self.assertEqual(cron.dom, set([3]))
        self.assertEqual(cron.month, set([4]))
        self.assertEqual(cron.dow, set([5]))
        self.assertEqual(cron.cron_readable, raw)

        expected = ("in minute 1, in hour 2, on day 3, in month "
                "April, and on Friday")
        self.assertEqual(cron.human_readable, expected)

        raw = "2 3 4 5 6"
        cron.parse(raw)
        # Parsing something else must change the @property
        self.assertNotEqual(cron.human_readable, expected)
        # And of course the other values
        self.assertEqual(cron.minutes, set([2]))
        self.assertEqual(cron.hours, set([3]))
        self.assertEqual(cron.dom, set([4]))
        self.assertEqual(cron.month, set([5]))
        self.assertEqual(cron.dow, set([6]))
        self.assertEqual(cron.cron_readable, raw)

    def test_runs_at(self):
        # December 24th 2013, 20:15:42.456789, which was a Tuesday.
        christmas_eve = datetime(2013, 12, 24, 20, 15, 42, 456789)

        self.assertTrue(CronTime("* * * * *").runs_at(christmas_eve))
        self.assertTrue(CronTime("* * * * *").runs_now())

        self.assertTrue(CronTime("* * * 12 *").runs_at(christmas_eve))
        self.assertFalse(CronTime("* * * 11 *").runs_at(christmas_eve))
        self.assertTrue(CronTime("* 20 * * *").runs_at(christmas_eve))
        self.assertFalse(CronTime("* 21 * * *").runs_at(christmas_eve))
        self.assertTrue(CronTime("15 * * * *").runs_at(christmas_eve))
        self.assertFalse(CronTime("16 * * * *").runs_at(christmas_eve))

        # DOW / DOM restrictions are more complicated, see the
        # _check_if_execute() method for details.
        # Restrict both -> one must match
        self.assertTrue(CronTime("* * 24 * tue ").runs_at(christmas_eve))
        self.assertTrue(CronTime("* * 24 * wed ").runs_at(christmas_eve))
        self.assertTrue(CronTime("* * 25 * tue").runs_at(christmas_eve))
        self.assertFalse(CronTime("* * 25 * wed ").runs_at(christmas_eve))

        # Restrict DOW -> it must match
        self.assertTrue(CronTime("* * * * tue").runs_at(christmas_eve))
        self.assertFalse(CronTime("* * * * wed").runs_at(christmas_eve))

        # Restrict DOM -> it must match
        self.assertTrue(CronTime("* * 24 * *").runs_at(christmas_eve))
        self.assertFalse(CronTime("* * 27 * *").runs_at(christmas_eve))

        # Restrict none of them -> tested above

    def test_calc_next_run(self):
        # This date was a Tuesday
        timestamp = datetime(2015, 6, 23, 13, 15)

        ret = CronTime("* * * * *").calc_next_run(timestamp)
        self.assertEqual(datetime(2015, 6, 23, 13, 16), ret)

        ret = CronTime("17 * * * *").calc_next_run(timestamp)
        self.assertEqual(datetime(2015, 6, 23, 13, 17), ret)

        ret = CronTime("14 13 23 6 *").calc_next_run(timestamp)
        self.assertEqual(datetime(2016, 6, 23, 13, 14), ret)

    def test_whitespace(self):
        """Cron parser must be able to handle some whitespace"""
        with_whitespace = [ "*  *  *  *  *",
                "*\t*\t*\t*\t*",
                "* \t * \t\t *\t\t*  \t*",
                "\t  * * * * * \t",
                "\t  \t* * * * *\t"
        ]
        reference = CronTime("* * * * *").cron_readable
        for item in with_whitespace:
            self.assertEqual(CronTime(item).cron_readable, reference, item)

    def test_underbar_underbar(self):
        """Test several __xxx__ methods"""
        cron1 = CronTime("* * * * *")
        cron2 = CronTime("* * * * *")
        cron3 = CronTime("42 * * * *")

        self.assertEqual(cron1, cron1)
        self.assertEqual(cron1, cron2)
        self.assertEqual(cron2, cron1)
        self.assertNotEqual(cron2, cron3)
        self.assertNotEqual(cron3, cron2)

        self.assertEqual(str(cron1), ("every minute, every hour, every day of "
                "month, every month, and every day of the week"))
        self.assertEqual(repr(cron1), "CronTime('* * * * *')")
        self.assertEqual(eval(repr(cron1)), cron1)

        self.assertEqual(str(cron3), ("in minute 42, every hour, every day of "
                "month, every month, and every day of the week"))
        self.assertEqual(repr(cron3), "CronTime('42 * * * *')")
        self.assertEqual(eval(repr(cron3)), cron3)

        # repr() must honor subclassing
        class CronSubclass(CronTime):
            pass
        subclass = CronSubclass("* * * * *")
        eval_repr = eval(repr(subclass))
        self.assertEqual(eval_repr, subclass)
        self.assertEqual(type(subclass), CronSubclass)


if __name__ == "__main__":
    unittest2.main()

