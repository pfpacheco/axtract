import os
from ax.tr069.ax_tr069_parser import AXTR069PropertiesParser
from os.path import join as path_join
from ax.utils.config_mgmt.ConfigManager import get_axess_default_config

# the highest index value in an object list, we dynamically raise it
# when we fill the lookup cache in getVal.
# it is needed for dependency lookups when we need to find all keys below a
# certain point in the cpe.props
# i *assume* that
MAXOBJECTS = 2

# TR69 like {'InternetGatewayDevice.WANConnection_x.PPPConnection_x.Password'
# -> 'short69':'1.1_x.3_x.4', size=3...}
TR69 = {}

# SHORT69 like {'1.1_x.3_x.4' ->
# {'tr69':'InternetGatewayDevice.WANConnection_x.  PPPConnection_x.Password',
# size=3...}
SHORT69 = {}

# here only the defs of a certain props file are stored:
SHORT69_BY_PROPS_FILE = {}

# the lookup caches:
# TR69_LOOKUP_CACHE  like:
#    {'InternetGatewayDevice.WANConnection_23.PPPConnection_1.Password' ->
#       ('1.1_23.3_1.4',
#           'InternetGatewayDevice.WANConnection_x.PPPConnection_x.Password')
TR69_LOOKUP_CACHE = {}
# SHORT69 like {'1.1_23.3_1.4' ->
#       ('InternetGatewayDevice.WANConnection_23.PPPConnection_1.Password',
#         '1.1_x.3_x.4')
SHORT69_LOOKUP_CACHE = {}

# the second nodes only, the nodes after InternetGatewayDevice. or Device
TR69_SECOND_NODES = set()

def autoShort(props):
    """ 'autoShort' is  just a somewhat more descriptive name for what this
    thing does.
    The autoconversion itself has been built into the pack_long_to_short
    function anyway
    """
    if props:
        return pack_long69_to_short69(props, ignoreUndefinedKeys=1)

    return props


def autoLong(props):
    if props:
        return pack_short69_to_long69(props, ignoreUndefinedKeys=1)

    return props


def convertPropToCorrectRootObject(key, isIGD):
    # convert "InternetGatewayDevice" to "Device" or contrary
    is_long = autoDetectLongFmt(key)

    root, rest = key.split('.', 1)

    if isIGD:
        if is_long:
            if root == 'InternetGatewayDevice':
                return key
            else:
                return "InternetGatewayDevice." + rest
        else:
            if root == 'I':
                return key
            else:
                return "I." + rest
    else:
        if is_long:
            if root == 'Device':
                return key
            else:
                return "Device." + rest
        else:
            if root == 'D':
                return key
            else:
                return "D." + rest


def buildSPVArgument (cpe, pendingProps, log = None, add_type=True):
    """ including a set of the dependent props and omitting of readonlies
    Assumes that a GPV was successfully completed before the SPV
    """
    par = []
    pP = {}
    short69_deps = getattr(cpe, 'short69_deps', {})
    for key in pendingProps:
        orig_key = key
        val = pendingProps.get(key)
        # check if dependent:
        for dk in short69_deps.keys():
            index = short69_deps.get(dk).get('fixedIndex')

            if key.find(index) > 0:
                # a dependent one. Insert the real index instead.
                scan, foundIndex = getDepIndex(
                        dk,
                        cpe,
                        noMatchReturnFirst = None)

                if not foundIndex:
                    log and log(3,
                        "Cannot set the dependent property %s - omitting it"
                               % key)
                    continue

                # key like 'I.WD.d301.WCD.x.WC.x.PMNOE.B', keyLeaf = PMNOE.B
                keyLeaf = '.'.join(key.split('.')[len(scan.split('.'))-1:])
                key = scan + keyLeaf
                break

        attrs = getVal(key)
        if not cpe.isUnmanaged(key):
            if log and attrs and attrs.get('readOnly'):
                log(3, cpe, "Warning: Setting a 'read-only' parameter: %s" % key)

            key = convertPropToCorrectRootObject(key, cpe.isIGD())
            longP = getVal(key, 'long')
            pP[key] = val
            if add_type:
                ptype = getVal(key,'type')
                if isinstance(val, dict) and \
                        sorted(val.keys()) == ['type', 'value']:
                            ptype = val['type']
                            val = val['value']
                            pendingProps[orig_key] = val
                else:
                    ptype = getVal(key,'type')
                par.append({'Name':longP, 'Value': val, 'Type': ptype})
            else:
                par.append({'Name':longP, 'Value': val})

    return pP, par


def setDependentCPEProps(cpe):
    """ a GPV call has set the dependent cpe.props.
    Now we also set the Deps accordingly into cpe.props
    pending(dependent)Props are not affected, they are cleared after a SPV result

    """

    """ Reminder:
    >>> short69_deps
       short69_deps = {
     'I.WD.1.WCD.1.WC': {'fixedIndex': 'd101', 'depValue': 'Internet',
                         'description': 'Data uplink', 'depKey': 'N'},\
     'I.WD': {'fixedIndex': 'd301', 'depValue': 'default', 'description':
                   'Super Node matching', 'depKey': 'WCD.x.WC.x.N'},\
     'I.WD.1.WCD.1.WC': {'fixedIndex': 'd200', 'depValue': 'default',
             'description': 'Data uplink', 'depKey': 'N'}\
    """
    short69_deps = getattr(cpe, 'short69_deps', {})
    # first clear all dependencies:
    l = []
    l.extend(cpe.props.keys())
    for key in l:
        if key.find('.d') > -1:
            del cpe.props[key]

    for key in short69_deps.keys():
        # if the dependent prop is not yet in the properties,
        # then ignore it, maybe the user does not use it at all.
        # if was inserted to pendingProps, it will be in props after
        # the setState to up to date
        match, foundIndex = getDepIndex (key, cpe, noMatchReturnFirst = None)

        # that logic returned the first object or the matching one.
        if not foundIndex:
            continue

        # fill all subvalues of the found index into the depKey:
        # we copy the whole subtree into the dep key node:
        # FIXME: write this in c, this could get performance intense:
        depIndex = short69_deps.get(key).get('fixedIndex')
        depKeyNode = ".x.".join(short69_deps.get(key).get(
                               'depKey').split(".x.")[:-1])+".x"
        insert = "%s.%s.%s." % (key, depIndex, depKeyNode)

        for cpekey in cpe.props.keys():
            l = cpekey.split(match)
            if len(l) > 1 and l[0] == '':
                # key began with match, insert it like:
                # '1.i1.1.i1.1.d100.12' -> val
                cpe.props[insert + '.'.join(l[1:])] = cpe.props.get(cpekey)


def buildGPVArgument (initargs):
    """
    This does nothing else than insert scans of the CPE for deps
    so initargs from ['a.b.c', 'f.b.d100.a.c'] -> ['a.b.c', 'f.b.']
    without avoiding double scans
    """
    # for empty string GPV ([""])
    # An empty string indicates the top of the name hierarchy.
    if '' in initargs:
        return [""]

    ret = []
    for i in range(0, len(initargs)):
        arg = initargs[i]
        if arg.find('.d') > -1:
            arg = arg[:arg.find('.d')+1]
            initargs[i] = arg

    for arg in initargs:
        insert = 1
        for chk in initargs:
            # avoid insert of 'foo.bar.' if 'foo.' already is there:
            if not arg == chk and arg.find(chk) ==0 and chk[-1] == '.':
                insert = None
                break

        if insert:
            # ... if it is not mentioned in the TR-069 properties
            try:
                ret.append (getVal(arg, 'long'))
            except:
                # ... and is not a "short" name
                if len (arg) > 2 and arg[1] != ".":
                    # ... then let's keep it in the parmeter list as is and let
                    # the CPE deal with it
                    ret.append (arg)
                else:
                    # ... otherwise let a proper error message bubble up
                    raise

    return ret


def getDepIndex(dep, cpe, noMatchReturnFirst = 1):
    """
    Returns the index of the 'real' CPE object matching the dependency.
    Assumes: cpe.props already set correctly, i.e.

    """
    short69_deps = getattr(cpe, 'short69_deps', {})

    # the object tree to scan
    scan = dep
    foundIndex = None
    map = short69_deps.get(dep)

    depVal = map.get('depValue')
    depKey = map.get('depKey')

    # depKey = "WLC.x.N" -> DepKeyLeaf ='.N'
    DepKeyLeaf = '.'+depKey.split('.')[-1]
    lenDepKeyLeaf = len(DepKeyLeaf)

    depKeyX = '%s.%s.%s' % (dep, 'x' , depKey)

    for key in cpe.props:
        if key.find('.d') > -1:
            # ommit alread set dep trees.
            # Interwoven dep strucutures we'll do sometimes later
            continue

        if key[-lenDepKeyLeaf:] == DepKeyLeaf:
            # an interesting one, it ends like our dep key:
            val = cpe.props.get(key)
            if str(val) == str(depVal):
                # wow, value matches. But .Name = 'default' may happen more
                # often in the tree, so:
                if getVal(key, 'short69') == depKeyX:
                    # it's it. Get Index and scan path.
                    splitList = key[len(dep)+1:].split('.')
                    foundIndex = splitList[0]
                    # scanpath is the path until the *last* index,
                    # can be longer than dep
                    for i in range(len(splitList) -1, 0, -1):
                        if isIndex(splitList[i]):
                            scan = '%s.%s.' % (dep, '.'.join(splitList[:i+1]))
                            return scan, foundIndex
    return None, None


def getVersionStringFromLong69(long69):
    """
    Called at every inform
    Currently we just manage Internet Gateway Devices....
    """
    VERSION_SEP = "__"
    m = long69

    assert type(m) == type({}), "getVersionStringFromLong69 needs a map"

    sw =  m.get("InternetGatewayDevice.DeviceInfo.SoftwareVersion",
            m.get("Device.DeviceInfo.SoftwareVersion", 'NA'))
    hw = m.get("InternetGatewayDevice.DeviceInfo.HardwareVersion",
            m.get("Device.DeviceInfo.HardwareVersion", 'NA'))
    spec = m.get("InternetGatewayDevice.DeviceInfo.SpecVersion",
            m.get("Device.DeviceInfo.SpecVersion", 'NA'))

    sw = replaceSpecialChars(sw)
    hw = replaceSpecialChars(hw)
    spec = replaceSpecialChars(spec)

    return VERSION_SEP.join((sw, hw, spec))

def getSVHVFromLong69(long69):
    """
    Called at every inform
    """
    m = long69

    assert type(m) == type({}), "getSVHVFromLong69 needs a map"

    sv =  m.get("InternetGatewayDevice.DeviceInfo.SoftwareVersion",
            m.get("Device.DeviceInfo.SoftwareVersion", 'NA'))
    hv = m.get("InternetGatewayDevice.DeviceInfo.HardwareVersion",
            m.get("Device.DeviceInfo.HardwareVersion", 'NA'))
    sv = replaceSpecialChars(sv)
    hv = replaceSpecialChars(hv)

    return sv, hv

def replaceSpecialChars(s):
    return s.replace('!','').replace(' ', '').replace('(','_').replace(
            ')', '_').replace('\\','_').replace('/', '_').strip()


def get_short69_by_long69(long69):
    '''
    '''
    return getVal(long69, 'short')


def get_long69_by_short69(short69):
    '''
    '''
    return getVal(short69, 'long' )


def get_pendant_pack(pack, ignoreUndefinedKeys, mode = 'short'):
    '''
    This method would replace keys in format long69 with keys in format short69
    or vice versa:
    '''
    pPack ={}
    keys_to_convert = {}

    if mode == 'long':
        for name, value in pack.iteritems():
            if autoDetectLongFmt(name):
                pPack[name] = value
            else:
                keys_to_convert[name] = value

    elif mode == 'short':
        for name, value in pack.iteritems():
            if autoDetectLongFmt(name):
                keys_to_convert[name] = value
            else:
                pPack[name] = value
    else:
        raise Exception(
                "Mode %s for TR-069-Prop Convertion NOT supported" % str(mode))

    for key,value in keys_to_convert.iteritems():
        try:
            pPack[getVal (key, mode)] = value
        except ValueError, e:
            if not ignoreUndefinedKeys:
                raise e

    return pPack


def pack_short69_to_long69(short69_pack, ignoreUndefinedKeys = None):
    '''
    This method would replace keys in format short69 with keys in format long69
    '''
    return get_pendant_pack (short69_pack, ignoreUndefinedKeys, mode = 'long')


def pack_long69_to_short69(long69_pack, ignoreUndefinedKeys = None):
    '''
    This method would replace keys in format short69 with keys in format long69
    '''
    return get_pendant_pack (long69_pack, ignoreUndefinedKeys, mode = 'short')


def autoDetectLongFmt(key):
    """ return True if the key is in long format """
    if key.startswith('InternetGatewayDevice') or key.startswith('Device'):
        return True

    if key[0] == "." and key.split('.')[1] in TR69_SECOND_NODES:
        return True

    return False


def clearAllResources():
    SHORT69.clear()
    TR69.clear()
    SHORT69_BY_PROPS_FILE.clear()
    TR69_LOOKUP_CACHE.clear()
    SHORT69_LOOKUP_CACHE.clear()
    TR69_SECOND_NODES.clear()


def parse_global_properties (xmlpath, specific_files='', index_path=None, verbose_output=False):
    AX_DEF_CFG = get_axess_default_config()

    TR069Props = AXTR069PropertiesParser (short_tr069_index_path=index_path, verbose_output=verbose_output)

    print "Parsing Property XML Files"
    if isinstance(specific_files, (list, tuple, set)):
        specific_files = ','.join(specific_files)

    files = []
    # we read all TRxxx xml files in the TR69 folder and all xml files in
    # the Properties Folder
    getPropsFiles(files, xmlpath, "TR")
    getPropsFiles(files, path_join(xmlpath, "Properties"))
    specific_files += AX_DEF_CFG.get('AXESS_PROPERTY_FILES',
            '').strip()

    omitted_files = ''
    do_files = ()
    for f in files:
        if specific_files:
            if not f.rsplit('/',1)[1] in specific_files:
                omitted_files +="%s, " % f.rsplit('/', 1)[1]
                continue

        do_files += (f,)

    for f in do_files:
        TR069Props.parse_xml_file (f)
    # we need to UPDATE the existing maps, they are imported by
    # various modules:
    TR69.update(TR069Props.get_tr069_props ())
    SHORT69.update(TR069Props.get_short_tr069_props ())
    SHORT69_BY_PROPS_FILE.update(TR069Props.get_short_tr069_by_file ())
    if omitted_files:
        print "Omitted files: %s" % omitted_files[:-2]

    # Generate "SECOND_NODES" mapping
    for key in (x.split('.') for x in TR69):
        if len(key) == 1:
            continue
        if key[0] == 'InternetGatewayDevice' or key[0] == 'Device':
            TR69_SECOND_NODES.add(key[1])

    # save the new full short names index
    TR069Props.save_short_tr069_index()

    return TR69


def getPropsFiles (files, path, prefix = ""):
    all_files = os.listdir(path)
    all_files.sort()
    for f in all_files:
        if f[-4:] == ".xml" and f[:len(prefix)] == prefix:
            files.append(path_join(path, f))


def isIndex (s):
    """ is s an index like 1 or i1"""
    if s.isdigit ():
        return True

    if s and s[0] == "i" and s[1:].isdigit ():
        return True

    if '[' in s and ']' in s:
        return True

    return False


def repairRootProperty(rootObject, res):
    if rootObject == "I":
        return res
    elif rootObject == ".":
        return "."+".".join(res.split(".")[1:])
    elif res[0:2]=="I.":
        return "D."+".".join(res.split(".")[1:])

    return "Device."+".".join(res.split(".")[1:])


def getVal(key, attr = None):
    ATTRS = ('short', 'long', 'pendant')

    if attr in ('pendant',):
        print "The use of 'pendant' as parameter to getVal is deprecated"

    rootObject = key[0]
    if rootObject=="I":
        # the key like InternetGatewayDevice
        pass
    elif rootObject==".":
        if autoDetectLongFmt(key):
            key="InternetGatewayDevice"+key
        else:
            key="I"+key
    elif rootObject=="D":
        if key[1]==".":
            key="I"+ key[1:]
        else:
            key="InternetGateway"+key
            rootObject="Device"

    if attr in ATTRS:
        return repairRootProperty(rootObject, getValRoot(key, attr))
    else:
        res = getValRoot(key)
        res['tr69']=repairRootProperty(rootObject, res['tr69'])
        res['short69']=repairRootProperty(rootObject, res['short69'])
        if not attr:
            return res
        else:
            return res[attr]


def getValRoot(key, attr = None):
    '''
    return an attributes value from SHORT69 or TR69
    key like InternetGatewayDevice.Services.VoiceService.9.foo
               (if keyIsLong)
    or like I.S.V.9.f
    We check if we directly have the attrs for the 9th element in the
    mapping and return
    else:
    we put it into the chache
    Inserted an autodetection if key is long or short
    '''
    global MAXOBJECTS, TR69_LOOKUP_CACHE, SHORT69_LOOKUP_CACHE,  SHORT69, TR69
    key=str(key)
    # check if key is long or short:
    if key and key[-1] == ".":
        lastDot = '.'
        key = key[:-1]
    else:
        lastDot = ''

    keyIsLong69 = autoDetectLongFmt(key)

    # Note: (1, 2)[False] = 1 and (1, 2)[True] = 2
    map, cache, pendantkey = (
            (SHORT69, SHORT69_LOOKUP_CACHE, 'tr69'),
            (TR69,    TR69_LOOKUP_CACHE,    'short69' )
            )[keyIsLong69]

    val = cache.get(key + lastDot)
    # the cache is like:
    # {'I.S.VS.9.F'->('InternetGa...Servcies.VoiceService.9.foo',
    # {'tr69'='IGW.S.VoiceService.ix.foo', 'readOnly' = 1,..})}
    if val:
        # done :-)
        if attr in ('long', 'short'):
            if (attr == 'long' and keyIsLong69) or \
                    (attr == 'short' and not keyIsLong69):
                return key + lastDot
            else:
                return val[0] + lastDot
        if attr == 'pendant':
            return val[0] + lastDot
        map = val[1]

        if not attr:
            return map.to_dict ()
        else:
            return map[attr]

    # Key not found - put it into the cache for next time:
    # follows stupid parsing, but we just do it once:
    # we have 1.i2 (short) or IGW.2 (long)
    # in the map we find 1 and 1.ix (short) or IGW and IGW.x

    # s will be like '1.ix' (short) or IGW.x (long) to look it up in the map
    s = ""
    # pendant is the IGW.2 if s is 1.i2 and vice versa
    pendant = ""
    # here we store the indices occuring in the key,
    # like: 'I.3.G.4.S' -> indexList = [3, 4]
    # or: I.WD.d302.WCD.x.WC.x.PCT' -> iL = [302, x, x]
    indexList = []

    for part in key.split("."):
        if isIndex (part) or part == 'x' or \
                (len(part) > 0 and part[0] == 'd' and part[1:].isdigit ()):
            s += ".x"
            indexList.append(part)
            continue

        if s== "":
            s = part
        else:
            s += "." + part

    attrs = map.get(s)
    if not attrs or (lastDot == '.' and map.get(s+'.x')):
        attrs = map.get(s+'.x')

    if not attrs:
        # just for the exception description below:
        if s == key:
            s = '- (nothing)'
        else:
            s = "'"+s+"'"
        raise ValueError, ("TR-069 parameter not found: '%s' - found so far: "
                "%s. Input format of initial arguments correct?") % (key, s)

    # care for the MAXOBJECTS:
    for i  in indexList:
        if not (i[0] == 'd' or i == 'x' or i[0] == '['):
            if int(i) > MAXOBJECTS:
                MAXOBJECTS = int(i)
    # now insert the found indices into the neutral pendant key:
    pendant = ''
    i = 0
    indexList.append('x')

    for part in attrs.get(pendantkey).split('.x.'):
        try:
            pendant += part + '.'+ indexList[i]+'.'
        except Exception, e:
            raise Exception, "Splitting error - %s, %s, %s, %s " % (pendant,
                                                      part, indexList, str(e))
        i += 1

    pendant = pendant.replace('.x', '')
    if pendant[-1] == ".":
        pendant = pendant[:-1]

    cache[key+lastDot] = (pendant, attrs)

    # now we will find it directly:
    g = getValRoot (key + lastDot, attr)
    if not g:
        # FIXME (marat):
        # Why must we define attribute for all parameters?
        # if attribute missing, we must return None
        # Or?
        if attr=="emptyfromcpe": return None
        raise Exception, "Did not find attr %s for key %s " % (attr, key)

    res=getValRoot (key+ lastDot, attr)

    return res
