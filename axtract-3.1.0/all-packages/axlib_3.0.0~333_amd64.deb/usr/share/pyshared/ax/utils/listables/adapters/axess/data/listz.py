"""
URL Hirarchy Aware API Into Zope
"""
from ax.utils.exceptions import InvalidInputException
from ax.utils.exceptions import DataNotFoundException
from ax.utils.listables import get_listables
from ax.utils.listables.listable import lit_eval
nil = '\x01'


# ------------------------------------------------------ URL Matching (Web API)

class Endpoint(object):
    @property
    def type(self):
        return self.__class__.__name__

    def err(self, msg, details=None):
        self._WS.API.err(msg, details)

    def meta(self, **kw):
        ra = self._req['response_add']
        if not ra.get('meta'):
            ra['meta'] = {}
        ra['meta'].update(kw)

    def __call__(self, id=None, **kw):
        self.id = id
        for k, v in kw.items():
            self.k = v


def find_idx_within_master_params(defs):
    """ must be always in. unique id """
    return defs['primary_id']


class ListUrlSchema(object):
    def execute(self, sql, params=None):
        '''We provide ourselves as DB handler, listables will call execute '''
        return self._WS.CPEManager.manage_runSQL(None, sql, params)

    def __getitem__(self, k, d=None):
        return getattr(self, k, d)

    def __call__(self):
        """Requiring the API, i.e. must be checked at any request, once"""
        self._req['slschema'] = self # quick access to the root schema for Lists
        # running the db exploration:
        self.listables = get_listables(self._WS.AXSchema.get_schema(),
                                       self._WS.CPEManager.get_engine())

    def ChildsByParent(self):
        return [[dict(i)['typ'],
                [k['type'] for k in dict(i)['child_types']]] \
                for i in self.Params()]


    def Params(self, st=None, framework=None, **kw):
        """ Configure browser frameworks with json.
        This is delivering all service types with params and their types
        Also we deliver a suited index keys for master detail use cases
        """
        u = self._req.AUTHENTICATED_USER
        # TODO: all claims from token if present:
        res = self.listables.dict(st, claims={'roles': u.roles})
        if st:
            idx = find_idx_within_master_params(res)
        if framework:
            # hack!
            F = getattr(Framework, framework, None)
            if not F:
                raise InvalidInputException('Undefined framework %s' % framework)
            res = F.adapt(res, user=u, **kw)
        if st:
            res['idx'] = idx
        return res


    def Count(self, lt=None, filters=None):
        """
        Method to return the count
        """
        return self.listables.count(self, filters, root=lt)


    def List(self, lt=None, show=None, filters=None,
                  sort=None, cost=1, offset=0, limit=None, _list=None):
        """
        Main Method, called from any listable.Get (then with _list = that obj)
        lt = _list.type by default

        """
        # self._list is the listable obj:
        #<listp.User object at 0xa41ded0>, type is User
        listables = self.listables

        self.add_history('urls', self._req['full_resource_path'])
        # called from a Listable?
        self._list = _list

        # list type:
        if not lt and _list:
            lt = _list.type
        loc = dict(locals())
        for k in 'self', '_list':
            loc.pop(k)

        # supporting Enterprise/Location/List/show/[r]meta,kv:,Enterprise.EID:
        show_qmap = False
        sh = loc.get('show')
        if sh:
            for m in 'meta', 'rmeta':
                if sh.startswith(m):
                    p1 = len(m)
                    i = p1 if not (sh + 'x')[p1] in (',', ':') else p1 + 1
                    loc['show'] = sh = sh[i:]
                    show_qmap = m
        # default:
        if not sh or sh=='show':
            loc['show'] = ['kva:', '*']
        else:
            show_params = lit_eval(loc['show'], key='show', into=list)
            show_params.insert(0, 'kva:')
            loc['show'] = show_params

        self.lt = lt
        # listable object, ref to the 'static' list API object
        try:
            lo = listables[self.lt]
        except KeyError as err:
            raise InvalidInputException('Unknown type or query option: %s' % str(err))
        url_filter = []
        p = self._list

        # url (path) filters: up the parents, check for ids given:
        while p and isinstance(p, List):
            # is a value following the type? /Location/<id>/CPE:
            if p.id:
                # if quoted its value only, not key:value:
                if ':' in p.id and not p.id[0] in ('"', "'"):
                    idk, id = p.id.split(':', 1)
                else:
                    idk, id = p.dflt_id, p.id
                if not idk:
                    self._WS.err('WrongArguments',
                            '%s: No id key defined or given: %s' % (p, p.id))
                url_filter.extend(['and', ['.'.join((p.type, idk)), '=', id]])
            p = p._parent

        # make the url filters readable (optional via _ at 1), ' ' fubars urls:
        if isinstance(filters, basestring) and filters:
            if filters.startswith('_'):
                loc['filters'] = filters = filters[1:].replace('_', ' ')
        # url_filter like [['Enterprise.EID', '=', '999950']]

        # realized filters (e.g. for SQL):
        q_map = lo.realize_filters(filters, url_filter) or {}
        q_map['cost'] = cost
        lo.realize_meta(q_map, loc)
        try:
            # limit offset already in:
            data = lo.get_data(q_map, limit=limit, offset=offset, API=self)
        except InvalidInputException, ex:
            raise ex
        except Exception, ex:
            raise DataNotFoundException(str(ex))
        if not isinstance(data, list):
            raise InternalException("Unable to process results")

        data = self.listables.post_process(data, q_map, API=self)
        #data = lo.get_data(rfilters, show, sorting, cost, offset, limit)
        if show_qmap == 'meta':
            return [q_map, {'data': data}]
        elif show_qmap == 'rmeta':
            return [{'data': data}, q_map]
        return data


    # ---------------------------------------------------------------- Features
    @property
    def breadcrumb(self):
        """ navigating up """
        op = self._obj_path
        base = self._req.BASE4[len(self._req.BASE0):]
        base += '/v1/' + '/'.join(op[:op.index(self.type)])
        bc = ((self.type, base), )
        if self._list:
            for p in self._list.parents:
                base += '/' + p.type
                bc += ((p.type, base),)
                if p.id:
                    base += '/' + p.id
                    bc += ((p.id, base),)
        return bc

    def cache(self, key, value=nil, dflt=nil):
        # TODO: redis, per user or global
        store = self._req.SESSION or Cache
        if value is nil:
            res = store.get(key)
            if res in (None, nil) and dflt is not nil:
                self.cache(key, dflt)
                res = dflt
            return res
        store[key] = value

    def add_history(self, key, value, entries=10, unique=1):
        vals = self.cache('history.%s' % key, dflt=[])
        if unique:
            while value in vals:
                vals.remove(value)
        vals.insert(0, value)
        while len(vals) > entries:
            vals.pop()

Cache = {}

class List(Endpoint):
    ''' an actual queryable list, nested in an url schema -
    handing all over to the root'''
    dflt_id = None
    @property
    def parents(self):
        res, p = [], self
        while not isinstance(p, ListUrlSchema):
            res.insert(0, p)
            p = p._parent
        return res


    @property
    def schema(self):
        """ returning the base ListUrlSchema (root class of our tree) """
        return self._req['slschema']

    def List(self, lt=None, show=None, filters=None,
                  sort=None, cost=1, offset=0, limit=None):
        l = dict(locals())
        l['_list'] = l.pop('self')
        return self.schema.List(**l)

    def Count(self, filters=None):
        return self.schema.Count(self.type, filters)

    def Params(self, *a, **kw):
        return self.schema.Params(self.type, *a, **kw)





# just to test what we have
def render(sls):
    res = ['''<html><body>''']
    def a(*s):
        for ss in s:
            res.append(ss)
    a('breadcrumb')
    a('/'.join(['<a href="%s">%s</a>' % (bc[1], bc[0]) for bc in sls.breadcrumb]))
    a('history')
    a('<ul><li>' + '</li><li>'.join(['<a href="%s">%s</a>' % (s, s) for s in \
            sls.cache('history.urls')]))
    a('filters %(rfilters)s' % sls)
    return '<br>'.join(res) + '</body></html>'



class InlineSchemaAdapter(object):
    """
    Allow direct inline calls w/o the API mountpoint:
        schema = Inl(MBCServiceList, api())
        res = schema.List('User', show=...)
    instantiated per request
    """
    _schema = None
    def __init__(self, schema_cls, api):
        s = self._schema = schema_cls()
        s._req, s._WS = api.REQUEST, api
        s()
    def List(self, *a, **kw):
        return self._schema.List(*a, **kw)
    def Count(self, *a, **kw):
        return self._schema.Count(*a, **kw)
    def Params(self, *a, **kw):
        return self._schema.Params(*a, **kw)
    def ChildsByParent(self, *a, **kw):
        return self._schema.ChildsByParent(*a, **kw)


    def listables(self):
        return listables

    def get(self, list_type):
        ''' .get('User')'''
        return listables[list_type]

