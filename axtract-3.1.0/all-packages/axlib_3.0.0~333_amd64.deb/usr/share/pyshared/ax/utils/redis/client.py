"""
A redis client with meta pool management (chooses real connection pools
        according to given availability situation and job nature)

r = RedisClient(host='nb01', failover='nb02')

Features:

- Instant exceptions when server is not availble - also in packet drop
        situations, which let the std client block minutes (setting socket to
        small is no option since blpops fail then)
- Fast timeouts for fast calls, still allowing long blocking calls
    (via a secondary connection)
- Failover and (early) switchback
- No uncecessary checks, no 'server down after check' race condition)
- Process wide reuse of std lib connection pools with same specifications
- Process wide synchronization of switchback checking
"""
try:
    import ssl
except:
    print "Import ssl failed - No redis over ssl"

from redis import connection





from time import sleep, time
from threading import Lock, Thread, Event
from redis.client import PubSub, Pipeline, StrictRedis
from redis.exceptions import ConnectionError

class ConnectionProblem(Exception):
    pass

try:
    from ax.utils.config_mgmt.ConfigManager import get_internal_svc_port
    REDIS_PORT = get_internal_svc_port('redis')
except:
    REDIS_PORT=6379

import logging
logger = logging.getLogger(__name__)

# check switchback minimum every:
CHK_INT  = 1.0

# clients can specify it:
REDIS_SOCK_TIMEOUT  = 1

# blocking ops idle longer but every 60 we reconnect, effectively a client
# triggered keep alive:
REDIS_BSOCK_TIMEOUT = 60
# *these* ops:
BLOCK_CALLS = ['BRPOPLPUSH', 'BLPOP', 'BRPOP', 'PUBSUB']

# Sine the std lib provides nice threadsafe connection pool mgmt, we use them
# process wide, for all AXRedisClients:
META_POOLS = {}
META_POOL_CREATION_LOCK = Lock()


# prefixing std.lib connection pools in our meta connection pool:
PRIMARY  = 'p_'
FAILOVER = 'f_'
# marking a pool as to be used for blocking calls (with BSOCK_TIMEOUT):
BLOCKING = 'b'

# state of db avail checking, NO = not checked
NO   = 0
UP   = 1
DOWN = 2


SSL_PATCHED = None
def enable_ssl(certfile):
    """
    this is patching ALL redis sockets into SSL try mode
    if an initial PING is not working
    """
    connection.Connection.ssl_certfile = certfile
    connection.Connection.orig_connect = connection.Connection._connect
    connection.Connection._connect = _try_ssl_connect
    global SSL_PATCHED
    SSL_PATCHED = True

SSL_SOCKS = {}
def _try_ssl_connect(self):
    ident = '%s:%s' % (self.host, self.port)
    def try_comm(sock):
        self._sock = sock
        try:
            self.send_command('PING')
            if not 'PONG' in sock.recv(1024):
                raise
            return 1
        except:
            return 0
    if not ident in SSL_SOCKS:
        #logger.debug('Trying : %s' % ident)
        sock = self.orig_connect()
        if try_comm(sock):
            logger.debug('%s connection successful' % ident)
            return sock
    logger.debug('Trying SSL to %s' % ident)
    sock = self.orig_connect()
    f = getattr(self, 'ssl_certfile', None)
    if f:
        sock = ssl.wrap_socket(sock, cert_reqs=ssl.CERT_NONE,
                               keyfile = f, certfile= f)
    else:
        sock = ssl.wrap_socket(sock, cert_reqs=ssl.CERT_NONE)
    if try_comm(sock):
        logger.debug('%s SSL connection successful' % ident)
        SSL_SOCKS[ident] = 1
    return sock

class SwitchbackChecker(Thread):
    """
    Checking within one thread all primary servers around which are fail
    and informing connection pools using it once one is back
    """
    def __init__(self):
        super(SwitchbackChecker, self).__init__()
        # db@ip -> list of connection pools needed info if up again:
        self.servers = {}
        self.have_servers = Event()

    def register_meta_pool(self, mp):
        mp_pri_sig = mp.get_pool(PRIMARY, 1)[1]
        # is it already checked:
        mps = self.servers.get(mp_pri_sig)
        if mps:
            if not mp in mps:
                mps.append(mp)
        else:
            self.servers[mp_pri_sig] = [mp]
        self.have_servers.set()

    def run(self):
        while 1:
            if not self.servers:
                logger.debug("Checker thread idle")
                self.have_servers.clear()
            self.have_servers.wait()
            # sleep not to short and not too long:
            # with one server we sleep 1 sec:
            slp = max(0.1, CHK_INT / len(self.servers))
            for srv, mps in self.servers.items():
                sleep(slp)
                if not mps:
                    del self.servers[srv]
                    break
                mp = mps[-1]
                if not single_conn_check(mp, PRIMARY):
                    # reappand:
                    continue
                while 1:
                    # all connection pool registered with this primary server
                    # can switchback:
                    mp = mps.pop()
                    mp.switchback()
                    if not mps:
                        break


CHECKER        = SwitchbackChecker()
CHECKER.daemon = True

def check_switchback_async(mp):
    """ a meta pool wants his primary server checked """
    CHECKER.register_meta_pool(mp)
    with META_POOL_CREATION_LOCK:
        if CHECKER.isAlive():
            return
        try:
            CHECKER.start()
            logger.info("Started switchback checker thread")
        except:
            pass




def single_conn_check(meta_pool, which):
    """ this is only running ONCE at failover time on the failover DB,
    and every 2 on the PRI DB when its not up """
    try:
        pool = meta_pool.get_pool(which)
        conn = pool.get_connection('PING')
        conn.send_command('PING')
        return 1
    except ConnectionError:
        return
    finally:
        conn.disconnect()
        pool.release(conn)


class MetaPool(object):
    """ Meta Pool managing up to 4 standard redis connection pools:
            p_pool: small timeout primary pool
            p_bpool: long timeout primary pool (for blocking ops)
            f_pool and f_bpool: same for secondary.
                                ONLY set if failover argument was
                                given in RedisClient constructor
        """
    def __init__(self, pools, check_lock, setup_descr, cert=None):
        self.f_tested = NO
        self.mypools = pools
        # primary or secondary:
        self.using = PRIMARY
        self.check_lock = check_lock
        self._descr = str(setup_descr) + '-%s' %  time()
        self.no_db  = None
        self.cert = cert
        if not SSL_PATCHED:
            enable_ssl(self.cert)


    def get_pool(self, which, with_sig=None, blk=None):
        if blk:
            blk = BLOCKING
        else:
            blk = ''
        p = self.mypools.get('%s%spool' % (which, blk))
        if with_sig:
            if not p:
                return None, None
            sign = '%(db)s@%(host)s:%(port)s' % p.connection_kwargs
            if blk:
                sign += "[%s]" % BLOCKING
            return p, sign
        return p

    def get_connection(self, command_name, *args, **kw):
        """ return a connection fast, w/o test roundtrips """
        blk = ''
        if command_name.upper() in BLOCK_CALLS:
            # use the pool with the long socket timeout:
            blk = BLOCKING
        poolname = self.using + blk + 'pool'
        conn = self.mypools.get(poolname).get_connection(command_name, *args, **kw)
        # to find it at release time:
        conn.poolname = poolname
        return conn

    def release(self, connection):
        self.mypools[connection.poolname].release(connection)

    def switchback(self):
        """ The switchback informs us that the primary is up again """
        # run connection tests on the failover one again, once pri is down
        # again:
        self.f_tested = NO
        # make the meta pool return the primary pool again:
        self.using    = PRIMARY
        # build the __repr__ string again:
        self._descr   = None
        # stop instant failings:
        self.no_db    = None
        logger.warn('SWITCHBACK %s' % self)

    def __repr__(self):
        """ good to have a descriptive status at str(self) ops """
        # a bit lengthy to calc and we might use in each log statment, so only
        # change when connection state changes, using _descr as a 'cache':
        if self._descr:
            return self._descr
        self._descr = ''
        for (prefix, which) in (('PRI: ', PRIMARY), (', BCKP: ', FAILOVER)):
            sig = self.get_pool(which, with_sig=1)[1]
            if not sig:
                continue
            self._descr += prefix + sig
            if self.using == which:
                self._descr +='(ACT)'
        return self._descr

    def try_failover(self):
        """
        A productive data exchange try failed.
        Check if we can (and do) switch to failover pools -
        by setting the self.using variable, causing get_connection to give out
        connections from failover pools from now on
        """
        if not 'f_pool' in self.mypools:
            # have no secondary, got a fail -> can't help execpt trying to see
            # it back
            logger.warn("%s - no failover configured, waiting for primary" \
                    % self)
            check_switchback_async(self)
            return
        if self.using == FAILOVER:
            # are already on secondary, got a fail -> can't help
            return
        # we are on primary and have a secondary. One thread must test it:
        # has it already been tested?:
        if self.f_tested:
            # client may retry with new connection
            return self.f_tested == UP

        with self.check_lock:
            if self.f_tested:
                return self.f_tested == UP
            logger.debug('Checking failover to %s' % \
                self.get_pool(FAILOVER, with_sig=1)[1])
            # async primary switchback testing:
            check_switchback_async(self)
            self._descr = None
            if single_conn_check(self, FAILOVER):
                self.using = FAILOVER
                self.f_tested = UP
                logger.warn('FAILOVER: %s' % self)
            else:
                self.using = None
                self.f_tested = DOWN
                logger.warn('FAILOVER DB DOWN!: %s' % self)
        return self.f_tested == UP




class FailingOver(object):
    def _with_failover(self, call, is_pipe=None, *args, **kw):
        """
        run a std client method involving a get connection with a
        failover try when pri is down
        """
        pool = self.connection_pool
        # instant failures if another transaction failed:
        if pool.no_db:
            raise ConnectionProblem('No DB available')

        retried = 0
        cmd = ''
        if is_pipe:
            command_stack = self.command_stack
        if args:
            cmd = args[0]
            if args[0] in BLOCK_CALLS:
                ts = time()
                timeout = args[-1]
                if args[1] == 'CHK':
                    args = (args[0],) + args[2:]
                    logger.debug('General availability check before %s on %s' % \
                                (cmd, self))
                    self.ping()
                    logger.debug('Passed check: %s' % self)

        while 1:
            try:
                return call(*args, **kw)
            except ConnectionError, ex:
                # unfortunatelly we can see only via the ex msg if the error was
                # at sending or at receiving on the socket (don't want to
                # overload the Connection object just for this).
                # We want to *ignore* receive timeouts if the client wants to
                # block longer (or infinte):
                err_msg = str(ex)
                if args and args[0] in BLOCK_CALLS:
                    if 'timed out' in err_msg:
                        if 'while reading' in err_msg:
                            timeout = args[-1]
                            if timeout == 0 or time() - ts < timeout:
                                retried = 0
                                continue

                if retried < 2:
                    # Note: the lib itself also does retries.
                    # allow a little downtime and try again:
                    sleep(0.5)
                    if not cmd.lower() == 'ping':
                        # trigger failover with short socket timeout:
                        self.ping()
                    if is_pipe:
                        self.command_stack = command_stack
                    retried += 1
                    continue

            # Connection Error Treatment follows:
            # pusbub remembers it, so:
            self.connection = None

            # are we on primary and did we not already failover?
            logger.warn("%s - checking failover possibilitiesr %s"  % (ex,
                            self.connection_pool))
            if self.connection_pool.try_failover():
                # anything to set after failover?
                if is_pipe:
                    # reset the command stack to original value:
                    self.command_stack = command_stack
                # call should work now, meta pool will give out failover conn:
                retried = 0
                continue

            # bad - no db anymore, fail instant from now on, until the checker
            # says primary there again:
            pool.no_db = 1
            raise ConnectionProblem(str(ex))


class RedisClient(FailingOver, StrictRedis):
    """
    Strategy:
        * Providing a meta connection pool, having up to 4 redis std lib
            conn.pools under control:
           (long/short sock timeout, primary and secondary server)
        * No availabilty checks at connection giveout time, but failover at
           command execution calls
        # Giveout real pool according to current failover mode (self.cpool.using)
        * Async testing to see when primary is up again (and instant switchback)
    """

    def __init__(self, host='127.0.0.1', **kw):
        """ setting up the up to 4 parametrizations of the pools
        """
        cert = kw.pop('cert', None)
        s_bto  = int(kw.pop('block_timeout', REDIS_BSOCK_TIMEOUT))

        # allow "1.1.1.1:6378" as host:
        if ':' in host:
            host, port = host.rsplit(':', 1)
            if host == '127':
                host = '127.0.0.1'
            kw['port'] = int(port)

        with META_POOL_CREATION_LOCK:
            mysetup = '%s:%s' % (host, kw)
            mp = META_POOLS.get(mysetup)
            failover  = kw.pop('failover',  None)
            if mp:
                logger.debug('Reusing exiting meta pool for %s' % mysetup)
                super(RedisClient, self).__init__(**kw)
                self.connection_pool = mp
            else:
                logger.info('Creating meta connection pool for %s' % mysetup)
                # socket timeouts:
                s_to  = kw.get('socket_timeout', REDIS_SOCK_TIMEOUT)

                # params pool creations:
                kwsets = {}
                for ip in (host, failover):
                    if not ip:
                        # no failover:
                        continue
                    kw['host'] = ip

                    prefix = PRIMARY
                    if ip == failover:
                        prefix = FAILOVER
                    # s_to, s_bto = (1, 60) by default:
                    for timeout in (s_to, s_bto):
                        blck = ''
                        if timeout == s_bto:
                            blck = BLOCKING

                        kw['socket_timeout'] = timeout
                        # let the std lib build the pools, we just steal it:
                        super(RedisClient, self).__init__(**kw)
                        # prefix + blck + 'pool' like p_pool for the prim.pool:
                        # and p_bpool for the primary blocking one:
                        kwsets[prefix + blck + 'pool'] = self.connection_pool

                # now hand all pools to the super pool:
                self.connection_pool = MetaPool(kwsets, Lock(), mysetup, cert)
                # and register for the next client with the same parameters,
                # so that we reuse this pool:
                META_POOLS[mysetup]  = self.connection_pool
        logger.info('Instantiated Redis Connection: %s' % self)


    def __repr__(self):
        """ returns current failover state """
        return 'RedisClient: %s' % self.connection_pool

    def execute_command(self, *args, **kw):
        """ redis client method """
        return self._with_failover(super(RedisClient, self).execute_command,
                                  None, *args, **kw)

    def pipeline(self, transaction=True, shard_hint=None):
        return MyPipeline(self.connection_pool, self.response_callbacks,
                          transaction, shard_hint)

    def pubsub(self, shard_hint=None):
        # normal pubsub:
        #TODO: Provide a MyPubSub which has a listen_many function, async
        return PubSub(self.connection_pool.get_pool(PRIMARY, blk=1), shard_hint)

    def pubsub_listen(self, channel, err_ignore=1, shard_hint=None):
        p = MyPubSub(self.connection_pool.get_pool(PRIMARY, blk=1), shard_hint)
        for i in p.subscribe_listen(channel, err_ignore=err_ignore):
            yield i

class MyPipeline(FailingOver, Pipeline):
    def execute(self):
        # don't want to loose the command stack over the reset after the fail:
        return self._with_failover(super(MyPipeline, self).execute, is_pipe=1)


class MyPubSub(PubSub):
    def subscribe_listen(self, chans, err_ignore=None):
        """
        Allowing subscription and ignoring
        of all errors  in the listen loop

        We just keep trying endless to connect.
        """
        logger.info("Trying to subscribe to %s" % chans)
        failmsg = 0
        while 1:
            try:
                self.subscribe(chans)
                failmsg = 0
                logger.info("Subscription to %s successful" % chans)
                for i in self.listen():
                    yield i
            except Exception, ex:
                if not err_ignore:
                    raise ex
                if not failmsg:
                    failmsg = 1
                    logger.warning("Can't subscribe to %s - keep trying" % chans)
                sleep(1)

    def listen(self):
        while 1:
            try:
                for i in super(MyPubSub, self).listen():
                    yield i
            except ConnectionError, ex:
                # ignore socket errors only, else use the subs_listen wrapper:
                if 'while reading' in str(ex) and 'timed out' in str(ex):
                    self.subscribe(self.channels)
                    continue
                raise ex


if __name__ == '__main__':
    # very basic tests:

    r = RedisClient(host='127.0.0.1')
    p = r.pubsub()
    for l in r.pubsub_listen('chann'): print l

    logging.basicConfig(level=logging.DEBUG)
    #import redis
    #r = redis.Redis()
    #print r.blpop('blk')

    r = RedisClient(failover='127.0.0.1', host='1.1.1.1')
    foo = r.blpop(('CHK', 'blk'), 0)
    print foo
    p = r.pubsub()
    p.subscribe('chan')

    r = RedisClient(host='1.1.1.1', failover='127.0.0.1')
    r.publish('chan', 'bar')
    p = r.pipeline()
    p.set('test:mykey2', 'pipesuccess')
    # slow, failover:
    p.execute()
    # fast, value kept:
    print r.get('test:mykey2')

    r = RedisClient(host='1.1.1.1', failover='127.0.0.1')
    print r.connection_pool
    ts = time()
    r.set('test:mykey', 'success')
    print 'Failover check time (2 times sock timeout): %s' % (time() - ts)
    ts = time()
    print r.get('test:mykey')
    print 'Failed over, checking primary for comming back, operation time now short (%s)' % (time() - ts)
    print 'Running ping transaction every second now, pull up and down 1.1.1.1 locally to see me switching back and failover again:'
    while 1:
        sleep(1)
        r.ping()


