'''
# Intra Process Locking and Related Tools ( Locking over threads in a process )

Main purpose is to ease the problems of working with

> Derived/Secondary, Global, [potentially Mutable] State (DGS, DGMS)


## Background

In general global state should be avoided whenever possible, working solely
based on facts (by definition immutable) which get into the program from
outside.

As we proceed and process those facts we will build secondary datastructures
('derived state').

Sometimes that building is expensive and we don't want to do that over and
over again - then we have DG[M]S, since we typically store the build result in
datastructures, not only accessible by the functions within the current
processing chain.


## Examples

- Parsed Config
- Session Cache
- Autobuilt APIs
- Parsed rarely changing infos from DBs or Web
- ...

This module delivers the functions in order to deal with DG[M]S efficiently
and safely, in concurrent access situations.

- efficiently
    * Only build once although many clients require the result concurrently.
    * Minimize blocking of clients
    * Provide more or less elegant invokation functions

- safely: Handle the problems of invalidation, i.e. when DGMS has to be
  rebuilt, due to facts detected to have changed by client(s) - at possibly the
  same time.


See also the examples in the tests regarding how this works.


## Non Examples

In the current form the module manages concurrency **process local only**, i.e.
using in-process locking primitives.

So this is not to be used when multiproc/multinode access to global state is
to be done efficiently and safely (e.g. a thing should only run once in a
cluster).

It should be possible though, to swap the locks and the result holding
structures(if serializable), with inter-process capable ones.

'''
# author, date: gk, 4.2017

from tools      import is_str, p # p is a debug print tool with cur thread
from operator   import methodcaller # handy e.g. for dict 'get' conditions
from contextlib import contextmanager
from threading  import Lock, current_thread


def check_for(obj, item, name=None, lock=None):
    '''
    # Process Locked Condition Checking Context

    ## Use Cases

    For state changing expensive actions, e.g. parsing.

    When stuff has to be done only ONCE in a process and the checking if it is
    done is CHEAP (i.e. via dict or attr or list lookup):

    ## Params

    - obj(any)    : Object which holds the done work (or indicator of it)
    - item(str)   : Name of state holding item or attr to check on obj
    - name(str)   : Name of lock to create for the syncronisation of threads
    - lock(Lock()): Callers can also pass their locks, then we'll use it

    > if name is not given we use the state check flag name (item)

    ## Example

    Be `def parse(facts)` an expensive function, building secondary state.

    Then this

        with check_for(Parser, 'document') as todo:
            if todo:
                Parser.document = parse(facts)

    is equivalent to:

        from threading import Lock
        my_lock = Lock() # must be process global
        if not getattr(Parser, 'document', None):
            with my_lock:
                if not getattr(Parser, 'document', None): # often forgotten
                    Parser.document = parse(facts)


    Based on this we added further utilities (below):

        run_once(parse, facts, Parser, 'document')

        # with mydoc a uniquely chosen key for the result of the parsing:
        parsed = cached('mydoc', parse, facts, invalidate=[True|False])

        # or with autoinvalidation on facts change:
        parsed = auto_cached('mydoc', parse, facts)


    '''

    name = item if (name, lock) == (None, None) else name
    # our condition: is item already 'in' obj?
    return proc_lock('in', (obj, item), name=name, lock=lock)


def run_once( builder, facts, state, item, name=None, lock=None
            , set_state=False ):
    '''
    # Run an Expensive Build For Secondary State Only Once Per Process

    ## Use Cases

    - Parsers of static files
    - Builders of API
    - Config Explorers
    ...

    > Caution: This is only for startup syncronization, NOT for re-runs (i.e.
    caching) since it does not offer safe invalidation of the build.

    In other words: Once created you can not change a build anymore later -
    - otherwise threads using the old build, while you rebuild will see
    inconsistent state after new state was built.

    - facts: Arguments for the builder.
            tuple maybe omitted for single parameter facts which are not tuples
    '''

    with check_for(state, item, name, lock) as do:
        if do:
            if not isinstance(facts, tuple):
                facts = (facts,)
            res = builder(*facts)
            # for the cache function:
            if set_state:
                state[item] = res
            if set_state == 2:
                _facts_by_key[item] = facts



_builds_by_key = {}
_facts_by_key  = {}
state, state_and_facts = 1, 2
def cached(key, builder, facts, invalidate=False, lock=None, _set=state):
    '''
    # Caching of Secondary State

    => can be rebuilt safely, even after first run.

    Here the result of the build is *returned*, i.e. consistent throughout a
    client's using thread (must be passed around though - client could still
    make the result thread local if that is not possible)

    ## Params

    - invalidate(bool): Rebuild the cache

    While rebuilding, clients who do not set invalidate get the old result,
    while ones which do set it wait for new

    '''
    cur_res = _builds_by_key.get(key)
    #p('cached called', facts, 'invalidate set: ', invalidate)
    if invalidate:
        # more threads can detect a necessary invalidation at the same time
        # rebuild only once then:
        with _create_lock(key+'_invalidation'):
            new_res = _builds_by_key.get(key)
            # there is no way to tell if the change was caused by a builder
            # started, before invalidation need was first realized by this or
            # another thread - or by another invalidator:
            if new_res == cur_res:
                m = {}
                #p('cached invalid. build', facts)
                run_once(builder, facts, m, key, lock=lock, set_state=_set)
                _builds_by_key.update(m)

    run_once(builder, facts, _builds_by_key, key, lock=lock, set_state=_set)
    return _builds_by_key.get(key)


def auto_cached(key, builder, facts, lock=None):
    '''
    # Automatic Caching of Secondary State When Build Facts Changed

    This sets the invalidation flag whenever facts have changed.

    Make sure that the facts comparision facts == cur_facts is fast, you may
    want to provide your own __eq__.

    While a new build is running, clients with old known state will get the old
    result.

    ## Usage

        docu = auto_cached('docuparser', build, source_csv_cont)

    '''

    run = lambda inv: cached(
            key, builder, facts, inv, lock, _set=state_and_facts)

    facts_changed = invalidate = False
    # de-convenience the facts (we accept e.g. facts = 1)
    if not isinstance(facts, tuple):
        facts = (facts,)
    cur_facts = _facts_by_key.get(key)
    #p('cur_facts', cur_facts, 'new', facts)

    if facts == cur_facts:
        return run(False)

    with _create_lock(key+'_facts_change'):
        if facts == _facts_by_key.get(key):
            return run(False)
        return run(True)





def _item_or_attr(obj, item):
    'if "in" argument is given as condition'
    if hasattr(obj, '__getitem__'):
        return item in obj or (getattr(obj, item, None)
                               if is_str(item) else None)
    return getattr(obj, item, None)


_lock_creation_lock, _locks_by_name = Lock(), {}
def _create_lock(name):
    lock = _locks_by_name.get(name)
    if lock is not None:
        return lock
    with _lock_creation_lock:
        if not _locks_by_name.get(name):
            _locks_by_name[name] = Lock()
    return _locks_by_name[name]



@contextmanager
def proc_lock(condition, args, name=None, lock=None):
    '''
    # Process Lock ( callable condition )

    Like `check_for` but accepting a generalized condition callable with args,
    to check if the work has been done in the process.

    This is the core function for all functions in this module.

    ## condition == 'in' shortcut

    To check for item occurrance in a dict, e.g. a cache we offer 'in' as a
    convience condition tag like:

    `with proc_lock('myjob', 'in', (Cache, 'stuff'))` - equal to
    `with proc_lock('myjob', _item_or_attr, (Cache, 'stuff'))`
    (nearly, that is: we default to getattr, not to None)

    > If a work timeout variable is needed in later, it can be added here, by
    > changing the lock to an event to wait for.

    '''
    # convenience condition
    condition = _item_or_attr if condition == 'in' else condition

    # after first run all clients will NOT run it:
    if condition(*args) is not None:
        yield False
        return

    # (only) before first completion one of these is needed:
    if (name, lock) == (None, None):
        raise TypeError("proc_lock: Require name or lock argument")

    if lock is None:
        # one lock per use case in the process. If we don't have it we must
        # create it (and creation must be locked):
        lock = _create_lock(name)


    # block:
    lock.acquire()

    if condition(*args) is None:
        try:
            yield True
            # work in progress now.... (may crash)
            return
        finally:
            # realease in any case:
            lock.release()
    else:
        lock.release()
        yield False



