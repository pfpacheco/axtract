#!/usr/bin/python -tt
"""Test cases for the "agnad" command line utility"""
import simplejson
import subprocess
import tempfile
import unittest2

from ax.utils.globalnumbers import destroy_resources

class TestAgnad(unittest2.TestCase):

    def __init__(self, *args, **kwargs):
        super(TestAgnad, self).__init__(*args, **kwargs)

    def check_call(self, params):
        args = [
            "/usr/bin/agnad",
            self.registry_path
        ]

        args.extend(params)

        with open('/dev/null', 'w') as stdout:
            subprocess.check_call(args, stdout=stdout, stderr=stdout)

    def setUp(self):
        # The registry we will be working with
        self.registry_file = tempfile.NamedTemporaryFile()
        self.registry_path = self.registry_file.name

        # The values we will be working with
        self.check_call(["--name=stats_int", "--ensure_int"])
        self.check_call(["--name=stats_uint", "--ensure_uint"])
        self.check_call(["--name=stats_long", "--ensure_long"])
        self.check_call(["--name=stats_ulong", "--ensure_ulong"])
        self.check_call(["--name=stats_fp", "--ensure_fp"])

    def tearDown(self):
        """Destroy the IPC we have created together with the registry

        Otherwise, the system will eventually run out of IPCs, and creating a
        new registry will fail.
        """
        destroy_resources(self.registry_path)
        self.registry_file.close()

    def read_stats(self):
        """Helper method to get all stats from our registry"""
        process = subprocess.Popen([
            "/usr/bin/agnad",
            "--print-json",
            self.registry_path],
            stdout=subprocess.PIPE)

        output, unused_err = process.communicate()

        stats = simplejson.loads(output)
        return stats[self.registry_path]

    def test_ensure_type_and_set(self):
        """Test --ensure_xxx and --set operations

        --ensure_xxx is already done by setUpClass, so just check if this worked correctly
        """
        # Basic check for existence. This one cannot differentiate between
        # signed/unsigned, though.
        stats = self.read_stats()
        self.assert_(isinstance(stats['stats_int'], int))
        self.assert_(isinstance(stats['stats_uint'], int))
        self.assert_(isinstance(stats['stats_long'], int))
        self.assert_(isinstance(stats['stats_ulong'], int))
        self.assert_(isinstance(stats['stats_fp'], float))

        # Setting signed variables to negative numbers must succeed
        self.check_call(["--name=stats_int", "--set=-10"])
        self.check_call(["--name=stats_long", "--set=-10"])
        self.check_call(["--name=stats_fp", "--set=-10.7"])

        # Setting unsigned variables to positive number must succeed
        self.check_call(["--name=stats_uint", "--set=10"])
        self.check_call(["--name=stats_ulong", "--set=10"])
        # Setting unsigned variables to negative numbers must fail and not
        # modify anything.
        self.assertRaises(
            subprocess.CalledProcessError,
            self.check_call, ["--name=stats_uint", "--set=-10"])

        self.assertRaises(
            subprocess.CalledProcessError,
            self.check_call, ["--name=stats_ulong", "--set=-10"])

        # Verify that stats are as expected
        stats = self.read_stats()
        self.assertEqual(stats['stats_int'], -10)
        self.assertEqual(stats['stats_long'], -10)
        self.assertAlmostEqual(stats['stats_fp'], -10.7, 4)
        self.assertEqual(stats['stats_uint'], 10)
        self.assertEqual(stats['stats_ulong'], 10)

        # To be on the safe side, also set the unsigned values to something.
        self.check_call(["--name=stats_uint", "--set=10"])
        self.check_call(["--name=stats_ulong", "--set=10"])
        stats = self.read_stats()
        self.assertEqual(stats['stats_int'], -10)
        self.assertEqual(stats['stats_long'], -10)
        self.assertAlmostEqual(stats['stats_fp'], -10.7, 4)
        self.assertEqual(stats['stats_uint'], 10)
        self.assertEqual(stats['stats_ulong'], 10)

        # Setting values back to 0 (=decrementing) must also work for unsigned.
        self.check_call(["--name=stats_int", "--set=0"])
        self.check_call(["--name=stats_uint", "--set=0"])
        self.check_call(["--name=stats_long", "--set=0"])
        self.check_call(["--name=stats_ulong", "--set=0"])
        self.check_call(["--name=stats_fp", "--set=0"])

        stats = self.read_stats()
        self.assertEqual(stats, {
            'stats_int': 0,
            'stats_long': 0,
            'stats_fp': 0.0,
            'stats_uint': 0,
            'stats_ulong': 0})

    def test_add_sub(self):
        """Test --add and --sub operations"""
        # Ensure variables are really 0 (=no leftovers)
        self.check_call(["--name=stats_fp", "--ensure_fp"])
        self.check_call(["--name=stats_int", "--set=0"])
        self.check_call(["--name=stats_uint", "--set=0"])
        self.check_call(["--name=stats_long", "--set=0"])
        self.check_call(["--name=stats_ulong", "--set=0"])
        self.check_call(["--name=stats_fp", "--set=0"])

        # Add, check for correct value.
        self.check_call(["--name=stats_int", "--add=10"])
        self.check_call(["--name=stats_uint", "--add=11"])
        self.check_call(["--name=stats_long", "--add=12"])
        self.check_call(["--name=stats_ulong", "--add=13"])
        self.check_call(["--name=stats_fp", "--add=13.37"])

        stats = self.read_stats()
        self.assertEqual(stats['stats_int'], 10)
        self.assertEqual(stats['stats_uint'], 11)
        self.assertEqual(stats['stats_long'], 12)
        self.assertEqual(stats['stats_ulong'], 13)
        self.assertAlmostEqual(stats['stats_fp'], 13.37, 4)

        # Subtracting from the unsigned values should work, too.
        self.check_call(["--name=stats_int", "--sub=5"])
        self.check_call(["--name=stats_uint", "--sub=5"])
        self.check_call(["--name=stats_long", "--sub=3"])
        self.check_call(["--name=stats_ulong", "--sub=3"])
        self.check_call(["--name=stats_fp", "--sub=3.3"])

        # Check results
        stats = self.read_stats()
        self.assertEqual(stats['stats_int'], 5)
        self.assertEqual(stats['stats_uint'], 6)
        self.assertEqual(stats['stats_long'], 9)
        self.assertEqual(stats['stats_ulong'], 10)
        self.assertAlmostEqual(stats['stats_fp'], 10.07, 4)

    def test_reset(self):
        """Test --reset"""
        # Ensure that there is something that needs to be reset
        self.check_call(["--name=stats_int", "--set=1234"])
        self.check_call(["--reset"])
        stats = self.read_stats()
        self.assertEqual(stats, {
            'stats_int': 0,
            'stats_long': 0,
            'stats_fp': 0.0,
            'stats_uint': 0,
            'stats_ulong': 0})

    def test_regexp(self):
        """Test --variables, which allows regular expressions"""
        self.check_call(["--reset"])
        # This should modify "stats_int" and "stats_uint"
        self.check_call(["--set=20", "--variables=int"])

        stats = self.read_stats()
        self.assertEqual(stats, {
            'stats_int': 20,
            'stats_long': 0,
            'stats_fp': 0.0,
            'stats_uint': 20,
            'stats_ulong': 0})
        # This should modify "stats_long" and "stats_ulong"
        self.check_call(["--set=30", "--variables=sta.*g"])
        stats = self.read_stats()
        self.assertEqual(stats, {
            'stats_int': 20,
            'stats_long': 30,
            'stats_fp': 0.0,
            'stats_uint': 20,
            'stats_ulong': 30})

        # Regular expressions must also work when printing.
        process = subprocess.Popen(["/usr/bin/agnad", "--print-json",
                self.registry_path, "--variables=sta.*g"],
                stdout=subprocess.PIPE)
        output, unused_err = process.communicate()
        stats = simplejson.loads(output)[self.registry_path]
        self.assertEqual(stats, {
            'stats_long': 30,
            'stats_ulong': 30})


    def test_print(self):
        """Test --print and --print-machine

        --print-json is implicitly tested in all the other tests that use the
        self.read_stats() method.
        """
        # For --print, the output format is not defined,
        # so just check that variable names appear somewhere
        process = subprocess.Popen(["/usr/bin/agnad", "--print",
                self.registry_path], stdout=subprocess.PIPE)
        output, unused_err = process.communicate()
        for varname in ('stats_int', 'stats_long', 'stats_fp', 'stats_uint',
                'stats_ulong'):
            self.assertIn(varname, output)

        # --print-machine. First, set up data so we know what to expect.
        self.check_call(["--name=stats_int", "--set=1",])
        self.check_call(["--name=stats_uint", "--set=2"])
        self.check_call(["--name=stats_long", "--set=3"])
        self.check_call(["--name=stats_ulong", "--set=4"])
        self.check_call(["--name=stats_fp", "--set=5.4"])

        # Get stats and parse
        process = subprocess.Popen(["/usr/bin/agnad",
                "--print-machine", self.registry_path], stdout=subprocess.PIPE)
        output, unused_err = process.communicate()
        stats = {}
        for line in output.split("\n"):
            if not line:
                continue
            name, value = line.split(" ")
            stats[name] = value

        self.assertEqual(stats, {
            'stats_int': "1",
            'stats_uint': "2",
            'stats_long': "3",
            'stats_ulong': "4",
            'stats_fp': "5.4"})


if __name__ == "__main__":
    unittest2.main()

