from pyparsing import Word
from pyparsing import Or
from pyparsing import Optional
from pyparsing import nums
from pyparsing import Literal
from pyparsing import Suppress
from pyparsing import CaselessLiteral
from pyparsing import StringEnd
from pyparsing import Combine
from pyparsing import OneOrMore


def parse(delta_string):
    result = PARSER.parseString(delta_string)
    return result[0]


def _gen_parser():
    dot = Literal('.')
    number = Word(nums)

    fraction = dot + number
    float_nb = Or([number, Optional(number) + fraction, number + dot])
    float_nb = Combine(float_nb)
    float_nb.setParseAction(lambda tokens: float(tokens[0]))

    seconds = float_nb + Optional(Suppress(CaselessLiteral('s')))

    minutes = number + CaselessLiteral('m')
    minutes.setParseAction(lambda tokens: int(tokens[0]) * 60)

    hours = number + CaselessLiteral('h')
    hours.setParseAction(lambda tokens: int(tokens[0]) * 60 * 60)

    days = number + CaselessLiteral('d')
    days.setParseAction(lambda tokens: int(tokens[0]) * 60 * 60 * 24)

    weeks = number + CaselessLiteral('w')
    weeks.setParseAction(lambda tokens: int(tokens[0]) * 60 * 60 * 24 * 7)

    exp = OneOrMore(Or([seconds, minutes, hours, days, weeks]))
    exp.setParseAction(lambda tokens: sum(tokens))

    return exp + StringEnd()

PARSER = _gen_parser()
