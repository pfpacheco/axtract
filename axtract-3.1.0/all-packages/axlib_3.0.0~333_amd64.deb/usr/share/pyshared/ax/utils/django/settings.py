"""
Loading the process wide django settings via the config manager
- We ask config manager for global settings which we set here
- we ask config manager for application paths, and add there settings here


Usage:

Set globals in /etc/default/axess like:
    DJANGO_DEBUG=False (resulting in DEBUG=False)

Create settings.py in your project folders and enable via:
    DJANGO_AXAPPS="AXPAND:AXPAND.cfg, otherapp:otherapp.appcfg
    with the settings.py in those folders and the paths are in the sys.path.
    (AXESS:Products.AXDjangoTemplateEngine is always set, for backward compat.
     To disable overwrite in default/axess)

Note that you can point to config manager in your process also to another
config file now os.environ['AXESS_CONFIG'] is your friend here.

Conflict Resolution:
-  Flat settings: LAST ONE RULES at conflicts.
 - List settings are built as superset of all, last app's values come first
 - Dicts are updated, last apps overrule
"""

from os import environ
from ax.utils.config_mgmt.ConfigManager import get_axess_default_config
from ax.utils.config_mgmt.ConfigManager import get_cfg_vals

environ['DJANGO_SETTINGS_MODULE'] = 'ax.utils.django.settings'

# should be supplied in the config. used for making hashes:
SECRET_KEY = '%axiros_axess_12%'

# allow to specify global settings directly in the main cfg, via
# DJANGO_<keyname>:
cfg = get_axess_default_config()
_strconv = {'True': True, 'False': False, 'None': None}
for key, val in cfg.items():
    if not key.startswith('DJANGO_'):
        continue
    # strip DJANGO_ off:
    djkey = key[7:]
    # convert?
    val = _strconv.get(val, val)
    # only strings and flat lists for now:
    if isinstance(val, (str, unicode)) and ',' in val:
        val = val.replace(' ', '').split(',')
    locals()[djkey] = val

# now for the project settings:

apps = get_cfg_vals('DJANGO_AXAPPS', ordered=1)
if not 'AXESS' in apps:
    apps.insert(0, "AXESS:Products.AXDjangoTemplateEngine")

# from https://code.djangoproject.com/wiki/SplitSettings
for app in apps:
    appname, fpath = app.split(':', 1)
    _tmp = None
    try:
        _tmp = __import__(fpath.strip(), globals(), locals(),
                            ['settings'], -1)
    except ImportError:
        print 'Could not import django settings for %s' % appname
        apps.remove(app)
        continue

    for setting in dir(_tmp.settings):
        if not setting == setting.upper():
            continue

        val = getattr(_tmp.settings, setting)
        if not setting in locals():
            locals()[setting] = val
            continue

        # current value:
        cval = locals()[setting]

        # lists must be inserted at 0 (last one rules):
        if val and isinstance(val, (list, tuple)):
            cval = list(cval)
            for v in val:
                if not v in cval:
                    cval.insert(0, v)
        elif val and isinstance(val, dict):
            cval.update(val)
        else:
            cval = val

        # whew:
        locals()[setting] = cval


print 'Django Settings (from %s)' % apps
for k, v in locals().items():
    if k.upper() == k:
        if 'SECRET' in k or 'PASSW' in k:
            v = '***'
        print '%s: %s' % (k, v)

