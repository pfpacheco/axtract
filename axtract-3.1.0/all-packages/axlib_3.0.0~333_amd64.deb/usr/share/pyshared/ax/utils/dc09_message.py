"""
Module for handling DC-09 messages, based on the draft for ANSI/SIA DC-09-2012A

"""
import datetime
import os
import traceback

try:
    from Crypto.Cipher import AES
except ImportError:
    AES = None

from ax.utils.crc import CrcCalculator

class DC09Error(Exception):
    """Base class for all exceptions in DC09 message de/encoding"""
    pass

class DC09EncodeError(DC09Error):
    """Base class for all exceptions in DC09 message encoding"""
    pass

class DC09DecodeError(DC09Error):
    """Base class for all exceptions in DC09 message decoding"""
    pass

# Line Feed and Carriage Return
LF = "\x0A"
CR = "\x0D"


class DC09Message(object):
    """Represent a single DC-09 message"""
    # Internal value: Was the CRC stored as 2-byte binary? In that case,
    # encoding must also use 2-byte binary, even though the standard does
    # not define this.
    _binary_crc = False

    # Message IDs are stored in self.id_. These are the ones defined in
    # SIA DC-07-2001.04, Appendix A. Any other message ID will produce a
    # DC09DecodeError upon decode().
    valid_ids = ["NULL", "ACK", "NAK", "RTN", "DUH", "SIA-UD",
            "SIA-CSE", "SIA-PUL", "ACR-SF", "ADM-CID", "ADM-41E", "ADM-42E",
            "ADM-HS", "DSC-43", "FBI-SF", "ITI-I", "SCN-S8", "SCN-S16",
            "SCN-S24", "SES-SS", "SIA-DCS", "SIA-S2K", "SIA-FSK1"]

    def __init__(self, message=None, encryption_key=None):
        # 16 bit CRC (see section 5.5.1.1) converted to signed int.
        self.crc = None
        # length of message body. Converted to unsigned integer.
        self.length = None
        # ASCII token to indicate the format used in the data field.
        # When it starts with "*" to indicate an encrypted message, the "*"
        # is removed and self.is_encrypted is set instead.
        self.id_ = None

        # Boolean indicating if message body is/was encrypted.
        self.is_encrypted = None
        # If the message is encrypted, it will be decrypted using this key.
        self.encryption_key = encryption_key
        # The encrypted data section. Only set if parsed message was encrypted.
        # It does not include the leading "[" and trailing Carriage Return.
        self.encrypted_data = None

        # Sequence number, converted to unsigned integer
        self.seq = None
        # Receiver number. 1-6 hex digits, prefixed with "R" in the raw message.
        # Internally stored as string or as None if no Receiver Number was
        # in the message. Must be string to preserve leading zeros.
        self.rcvr = None
        # Account prefix. 1-6 hex digits, prefixed with "L" in the raw message.
        # Internally stored as string. Must be string to preserve leading zeros.
        self.pref = None
        # Account number. 3-16 hex digits, prefixed with "#" in the raw message.
        # Internally stored as string. Must be string to preserve leading zeros.
        self.acct = None

        # For supported formats, this is an object representing the parsed data
        # section of the message. For unsupported formats, this is the raw data
        # section. Check class definitions below for supported formats.
        self.data = None

        # The Timestamp field as datetime.datetime object. Stays None if no date
        # was transmitted.
        self.timestamp = None

        self.crc_calculator = CrcCalculator()

        if message is not None:
            self.decode(message)

    def decode(self, message):
        try:
            if message[0] != LF:
                raise DC09DecodeError("First character is not a Line Feed")
            if message[-1] != CR:
                raise DC09DecodeError("Last character is not a Carriage Return")

            # Standard defines the CRC to be 4 hex characters, but
            # implementations (e.g. at Altibox) send it binary encoded as
            # two bytes. We can tell these formats apart by checking for the
            # position of the " that starts the message type.
            if message[7] == '"':
                # CRC must be binary 2 byte version
                self._binary_crc = True
                crc = ord(message[1]) * 256 + ord(message[2])
                length = message[3:7]
                body = message[7:-1]
            elif message[9] == '"':
                # CRC is compliant 4 byte hex version
                self._binary_crc = False
                try:
                    crc = int(message[1:5], 16)
                except ValueError:
                    raise DC09DecodeError("CRC field is not valid hexadecimal")
                length = message[5:9]
                body = message[9:-1]
            else:
                # Invalid message
                raise DC09DecodeError("Neither msg[7] nor msg[9] is a "
                        "quotation mark")

            # Check CRC
            # CRC calculation does not include the length field and is applied
            # to the ENcrypted message if encryption is used. See section
            # 5.5.1.2 for details.
            expected_crc = self.crc_calculator.crc16(body)
            if crc != expected_crc:
                raise DC09DecodeError("Wrong CRC. Expected: %X Have: %X" % (
                    expected_crc, crc))

            # Check length
            # The length only counts the actual body, not the CRC, the \n, \r
            # or the length field itself.
            if length[0] != "0":
                raise DC09DecodeError("No '0' found at start of length field.")
            try:
                length = int(length, 16)
            except Exception:
                raise DC09DecodeError("Length field is not valid hexadecimal")
            if len(body) != length:
                raise DC09DecodeError(
                        "Length field is %s but message body has %s bytes" % (
                            length, len(body)))

            # Parse body. Stuff that is already parsed gets removed from $body,
            # so $body gets shorter as the code processes it.

            # ID field is first in the body and enclosed by "".
            if not body.startswith('"'):
                raise DC09DecodeError('ID field does not start with a <">')
            # Find the second "
            id_end = body.find('"', 1)
            if id_end == -1:
                raise DC09DecodeError('No closing <"> for the ID field')
            id_ = body[1:id_end]
            if id_.startswith("*"):
                id_ = id_[1:]
                is_encrypted = True
            else:
                is_encrypted = False

            if id_ not in self.valid_ids:
                raise DC09DecodeError("Message id '%s' is invalid. Valid "
                        "messages are %s" % (id_, self.valid_ids))

            body = body[id_end + 1:]
            # Sequence number. Four decimal digits.
            seq = body[0:4]
            if len(seq) != 4:
                raise DC09DecodeError("Message too short: No sequence number.")
            try:
                seq = int(seq, 10)
            except ValueError:
                raise DC09DecodeError("Sequence number is invalid.")

            body = body[4:]
            # Receiver Number starts with "R", it is optional, though.
            if body.startswith("R"):
                # we do have the optional Receiver Number
                pref_start = body.find("L")
                if pref_start == -1:
                    raise DC09DecodeError("No 'L' after Receiver Number")
                rcvr = body[1:pref_start]
                if not(1 <= len(rcvr) <= 6):
                    raise DC09DecodeError(
                            "Receiver number has invalid length %s" % len(rcvr))
                try:
                    int(rcvr, 16)
                except ValueError:
                    raise DC09DecodeError("Receiver number is no valid hex.")
                body = body[pref_start:]
            else:
                rcvr = None

            # Account Prefix starts with "L" and ends at "#"
            if not body.startswith("L"):
                raise DC09DecodeError(
                        "No 'L' found where the Account Prefix should be")
            acct_start = body.find("#")
            if acct_start < 0:
                raise DC09DecodeError("No '#' found after Account Prefix")
            pref = body[1:acct_start]
            if not(1 <= len(pref) <= 6):
                raise DC09DecodeError(
                        "Account Prefix has invalid length %s" % len(pref))
            try:
                int(pref, 16)
            except ValueError:
                raise DC09DecodeError("Account Prefix is no valid hex")

            body = body[acct_start:]
            # Account Number starts at "#" and ends at "["
            if not body.startswith("#"):
                raise DC09DecodeError("No '#' where Account Number should be")
            data_start = body.find("[")
            if data_start < 0:
                raise DC09DecodeError(
                        "No '[' found that terminates Account Number")
            acct = body[1:data_start]
            if not(3 <= len(acct) <= 16):
                raise DC09DecodeError(
                        "Invalid length %s for Account Number" % len(acct))
            try:
                int(acct, 16)
            except ValueError:
                raise DC09DecodeError("Account number is no valid hex")
            body = body[data_start:]

            self.crc = crc
            self.length = length
            self.is_encrypted = is_encrypted
            self.id_ = id_
            self.seq = seq
            self.rcvr = rcvr
            self.pref = pref
            self.acct = acct


            # The rest is the Data section which may include a timestamp.
            if not body.startswith("["):
                raise DC09DecodeError("No '[' at beginning of Data section")
            body = body[1:]
            # This section may be encrypted, and we may not (yet) have the
            # decryption key. It makes sense that each customer (=self.acct)
            # uses a different encryption key, so our caller needs to get the
            # partially decoded DC09 message with the account number before he
            # can decrypt the data/timestamp part.

            if is_encrypted:
                self.encrypted_data = body
                if self.encryption_key is None:
                    # We don't (yet) have the key.
                    return
                body = self.decrypt()

            self.decode_data(body)
        except DC09DecodeError:
            raise
        except Exception:
            raise DC09DecodeError("Unknown error during decoding: %s" %
                    traceback.format_exc())

    def decode_data(self, data):
        """Decode the data section of a DC-09 message"""
        data_stop = data.rfind("]")
        if data_stop < 0:
            raise DC09DecodeError("No ']' found in Data section")

        try:
            actual_data = data[:data_stop]
            timestamp_data = data[data_stop + 1:]

            # self.id_ defines the format of the $actual_data. For a select
            # few, parse $actual_data in more detail.
            if self.id_ == "ADM-CID":
                # Message format is [#aaaaaa|QXYZsGGsCCC] according to DC-07
                # At Altibox, there is no "#", though.
                actual_data = DataADMCID(actual_data)
            # len(actual_data)==0 is OK, e.g. for ACK/NAK/DUH

            # Optional date at the end of the data section.
            if timestamp_data:
                if timestamp_data.startswith("_"):
                    timestamp = self.decode_timestamp(timestamp_data[1:20])
                else:
                    raise DC09DecodeError("Found trailing garbage data")
            else:
                timestamp = None

            self.data = actual_data
            self.timestamp = timestamp
        except DC09DecodeError:
            raise
        except Exception:
            raise DC09DecodeError("Unknown error during decoding: %s" %
                    traceback.format_exc())

    def decrypt(self):
        """Return the decrypted, unpadded data section (self.encrypted_data).

        The returned string looks like the string you would get for an
        unencrypted message, and is suitable input for self.decode_data().
        """
        if AES is None:
            raise DC09DecodeError("You need to install python-crypto.")
        if self.encryption_key is None:
            raise DC09DecodeError("Message is encrypted, but no encryption "
                    "key was given.")
        encrypted = self.encrypted_data

        # Data must be padded to be a multiple of 16 bytes. Since each byte is
        # encoded as 2 hex digits, the number of hex digits must be a multiple
        # of 32.
        if len(encrypted) % 32 != 0:
            raise DC09DecodeError(
                    "Length of encrypted data (%d) is not a multiple of 32." %
                    len(encrypted))

        encrypted_bin = []
        try:
            for index in xrange(0, len(encrypted), 2):
                hex_digits = encrypted[index:index + 2]
                encrypted_bin.append(chr(int(hex_digits, 16)))
        except Exception, exc:
            raise DC09DecodeError("Error in un-hexifying encrypted data: %s." %
                    exc)
        encrypted_bin = "".join(encrypted_bin)

        decrypter = AES.new(self.encryption_key, AES.MODE_CBC, 16 * "\x00")
        decrypted = decrypter.decrypt(encrypted_bin)
        return self.unpad(decrypted)

    @staticmethod
    def decode_timestamp(timestamp):
        """Decode a DC-09 timestamp in 'HH:MM:SS,MM-DD-YYY' form.

        The preceding "_" must already be removed. Returns a datetime.datetime
        instance with no timezone set.
        """
        if len(timestamp) != 19:
            raise DC09DecodeError("Invalid length for timestamp: %s" %
                    len(timestamp))
        if (timestamp[2] != ":" or timestamp[5] != ":" or timestamp[8] != "," or
                timestamp[11] != "-" or timestamp[14] != "-"):
            raise DC09DecodeError("Incorrect separators in timestamp")

        time_dict = {
            'hour': timestamp[0:2],
            'minute': timestamp[3:5],
            'second': timestamp[6:8],
            'month': timestamp[9:11],
            'day': timestamp[12:14],
            'year': timestamp[15:20]
        }

        # datetime does not accept strings, so convert to int.
        for key, value in time_dict.items():
            try:
                int_value = int(value)
            except ValueError:
                raise DC09DecodeError(
                        "The %s field is not a valid integer" % key)
            time_dict[key] = int_value

        # Let datetime object check if the integers are really valid.
        try:
            time_object = datetime.datetime(**time_dict)
        except ValueError, exc:
            raise DC09DecodeError("Invalid date specified: %s" % exc)

        return time_object

    def encode(self):
        """Return this object in encoded form"""
        if self.id_:
            # Somebody forcing ID, regardless of self.data. But still ensure
            # that a "*" appears for encrypted messages.
            if self.is_encrypted and not self.id_.startswith('"*'):
                id_ = '"*%s"' % self.id_
            else:
                id_ = '"%s"' % self.id_
        elif isinstance(self.data, DataADMCID):
            id_ = '"*ADM-CID"' if self.is_encrypted else '"ADM-CID"'
        else:
            raise DC09EncodeError("No 'id_' for this DC09 message.")

        seq = "%04d" % self.seq
        if self.rcvr is None:
            rcvr = ""
        else:
            rcvr = "R%s" % self.rcvr
        if self.pref is None:
            # Specifically noted in section 5.5.1.6.2
            pref = "L0"
        else:
            pref = "L%s" % self.pref
        acct = "#%s" % self.acct

        # self.data could be some special parsed object
        if isinstance(self.data, basestring):
            data = "%s]" % self.data
        else:
            data = "%s]" % self.data.encode()
        if self.timestamp is None:
            timestamp = ""
        else:
            timestamp = self.encode_timstamp(self.timestamp)
        data_timestamp = data + timestamp
        if self.is_encrypted:
            data_timestamp = self.encrypt(data_timestamp)
        # Add the "[" down here, because it must not be encrypted.
        data_timestamp = "[" + data_timestamp

        body = "".join((id_, seq, rcvr, pref, acct, data_timestamp))
        if self._binary_crc:
            crc_int = self.crc_calculator.crc16(body)
            crc = chr(crc_int / 256) + chr(crc_int % 256)
        else:
            crc = "%04X" % self.crc_calculator.crc16(body)
        length = "0%03X" % len(body)

        return "".join((LF, crc, length, body, CR))

    def encrypt(self, data):
        """Return encrypted data, take care of proper padding

        Also set self.encrypted_data.
        """
        if AES is None:
            raise DC09DecodeError("You need to install python-crypto.")
        if self.encryption_key is None:
            raise DC09DecodeError("Message should be encrypted, but no "
                    "encryption key was given.")

        padded_data = self.pad(data)
        encrypter = AES.new(self.encryption_key, AES.MODE_CBC, 16 * "\x00")
        encrypted = encrypter.encrypt(padded_data)

        # Convert binary data hexadecimal text
        hexified = "".join(["%02x" % ord(char) for char in encrypted])

        self.encrypted_data = hexified
        return hexified

    @staticmethod
    def pad(data, long_pad=True):
        """Pads $data according to section 5.4.4

        If long_pad is True, the algorithm will ensure that the padding contains
        at least 16 random bytes. If long_pad is False, the shortest possible
        padding will be used, which may result in just a pad separator being
        sent, and no random bytes at all.
        """
        pad_length = 16 - (len(data)) % 16
        assert(1 <= pad_length <= 16)
        if long_pad:
            pad_length += 16
        # The pad-separator also counts as one character, the rest is random
        # padding data.
        random_length = pad_length - 1

        random_padding = []
        while len(random_padding) < random_length:
            random_character = os.urandom(1)
            # Padding must not contain "|", "[" or "]", see section 5.4.4.2.
            if random_character not in ("|", "[", "]"):
                random_padding.append(random_character)
        random_padding = "".join(random_padding)

        return random_padding + "|" + data

    @staticmethod
    def unpad(data):
        """Removes padding from data, thus reversing self.pad()"""
        pad_end = data.find("|")
        if pad_end < 0:
            raise DC09DecodeError("No pad separator found while unpadding.")
        return data[pad_end + 1:]

    @staticmethod
    def encode_timstamp(timestamp):
        """Return DC-09 timestamp for given datetime.datetime object"""
        return "_%02d:%02d:%02d,%02d-%02d-%04d" % (
                timestamp.hour, timestamp.minute,
                timestamp.second, timestamp.month,
                timestamp.day, timestamp.year)


class DataADMCID(object):
    """Represent parsed data section of DC-09 message in ADM-CID format

    ADM-CID stands for "Ademco Contact-ID".
    The format of the data section is "[#aaaaaa|QXYZsGGsCCC]" with
        aaaaaa: The communicator's account number
        Q:      Qualifier, 1=New event or opening, 3=New restore or closing,
                6=Previous event
        XYZ:    Class code and event code
        s:      One space
        GG:     Group number
        CCC:    Zone codes or user ID
    Note from reality: At Altibox, there is no "#" before the account number.
    This code does not depend on the "#".
    """
    # Remembers if the original message had the "#" before the account
    # number. For messages created from scratch, this defines the default
    # behavior.
    with_hash = True

    def __init__(self, data=None):
        """Setup object. $data is the data section without surrounding []"""
        if data is None:
            self.account = None
            self.qualifier = None
            self.event_code = None
            self.group = None
            self.zone_number = None
        else:
            self.decode(data)

    def __eq__(self, other):
        return (self.account == other.account and
                self.qualifier == other.qualifier and
                self.event_code == other.event_code and
                self.group == other.group and
                self.zone_number == other.zone_number)

    def __ne__(self, other):
        return not self == other

    def decode(self, data):
        if data[0] == "#":
            # This message has a "#" before the account number.
            data = data[1:]
            self.with_hash = True
        else:
            self.with_hash = False

        if len(data) != 18:
            msg = "data section has wrong length: expected 18 bytes, got %d."
            raise DC09DecodeError(msg % len(data))
        try:
            # These names match with the DC05Message class. All values
            # are strings.
            self.account = data[0:6]
            self.qualifier = data[7]
            self.event_code = data[8:11]
            self.group = data[12:14]
            self.zone_number = data[15:19]
        except Exception:
            raise DC09DecodeError("Splitting of '%s' excepted" % data)

        # The actual value remain strings, but they need to be valid
        # decimal/hex integers.
        try:
            int(self.account, 16)
        except ValueError:
            raise DC09DecodeError("Account number '%s' is invalid" %
                    self.account)
        if self.qualifier not in ("1", "3", "6"):
            raise DC09DecodeError("Qualifier '%s' is invalid" % self.qualifier)
        try:
            int(self.event_code, 16)
        except ValueError:
            raise DC09DecodeError("Event code '%s' is invalid" %
                    self.event_code)
        try:
            int(self.group, 16)
        except ValueError:
            raise DC09DecodeError("Group '%s' is invalid" % self.group)
        try:
            int(self.zone_number, 16)
        except ValueError:
            raise DC09DecodeError("Zone number '%s' is invalid" %
                    self.zone_number)

    def encode(self):
        """Return message string created from member variables

        This string will not include the surrounding []. Depending on
        self.with_hash, a hash will be added or not.
        """
        retval = "%s|%s%s %s %s" % (self.account, self.qualifier,
                self.event_code, self.group, self.zone_number)
        if len(retval) != 18:
            raise DC09EncodeError("Encoded message '%s' has invalid length." %
                    retval)
        return "#" + retval if self.with_hash else retval

