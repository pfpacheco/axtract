#!/usr/bin/python -OttO
"""A server for UDP Echo Plus, as described in TR-143 Appendix A.

UDP Echo Plus is the good old UDP Echo as defined in

http://www.ietf.org/rfc/rfc862.txt

with some additional interpretation of the payload as defined in the TR, see

http://www.broadband-forum.org/technical/trlist.php

for the latest version.

This program depends on python-netaddr (installed by default). It also needs
axlib, all versions (arwen, bilbo, celeborn, dwalin...) should work.
"""

import select
import socket
import struct
import sys
import time

from netaddr import IPAddress, IPNetwork

from ax.daemon import daemon


class EchoPlusServer(daemon.AxDaemon):
    def __init__(self):
        super(EchoPlusServer, self).__init__()

        # IP and port where this server will bind to
        self.bind_ip = None
        self.listen_port = None

        # Which hosts are allowed to contact this Echo Plus server. this will
        # be a netaddr.IPNetwork object.
        self.allow_from = None

        # The socket on which we receive requests & send replies.
        self.sock = None

        # The "TestRespSN" field (response serial number) from TR-143
        self.resp_sn = 0
        # Unix time stamp of when the daemon started. Needed to generate the
        # TestResp(Recv|Reply)TimeStamp fields from TR-143.
        self.daemon_start_ts = time.time()

    def define_command_line(self):
        super(EchoPlusServer, self).define_command_line()

        self.option_parser.add_option("-b", dest="bind_ip", default="0.0.0.0",
                help="IP to bind to (default: 0.0.0.0)")
        self.option_parser.add_option("--port", dest="listen_port", default=7,
                type="int", help="UDP port to listen on")
        self.option_parser.add_option("--allow", dest="allow_from",
                default="0.0.0.0/0",
                help="Who is allowed to use this server. Default is 0.0.0.0/0")

    def parse_command_line(self):
        super(EchoPlusServer, self).parse_command_line()

        try:
            # Only support IPv4 for now
            bind_ip = IPAddress(self.options.bind_ip, 4)
        except Exception, exc:
            raise Exception("'%s' is not a valid IPv4 IP address: %s" % (
                    self.options.bind_ip, exc))
        self.bind_ip = str(bind_ip)

        listen_port = self.options.listen_port
        if listen_port < 0 or listen_port > 65535:
            raise Exception("Listen port '%s' is invalid" % listen_port)
        self.listen_port = listen_port

        allow_from = self.options.allow_from
        try:
            self.allow_from = IPNetwork(allow_from)
        except Exception, exc:
            raise Exception("'%s' is not a valid IPNetwork: %s" % (
                allow_from, exc))

    def adapt_uid_gid(self, *args, **kwargs):
        """Method to change UID/GID

        This method is the last place where we still have root privileges. So
        before calling super(), we open our socket.
        """
        self.setup_socket()
        super(EchoPlusServer, self).adapt_uid_gid(*args, **kwargs)

    def setup_socket(self):
        # For now, only support IPv4 and only support a single socket, i.e.
        # not multiple bind IPs.
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sock.bind((self.bind_ip, self.listen_port))
        except Exception:
            self.exception("Could not set up socket to listen to %s:%s:",
                    self.bind_ip, self.listen_port)
            sys.exit(1)
        else:
            self.info("Successfully created socket, listening on %s:%s.",
                    self.bind_ip, self.listen_port)

    def client_is_allowed(self, address):
        ip_address = IPAddress(address[0])
        return ip_address in self.allow_from

    def reply_to_echo_plus(self, sock, address, raw_packet, receive_ts):
        """Create and send a reply packet for raw_packet"""
        # Emulate unsigned 32 bit counters that wrap around -> use "% (2**32)"
        resp_sn = self.resp_sn % (2**32)
        recv_ts = int((receive_ts - self.daemon_start_ts) * 1000000) % (2**32)
        reply_ts = int((time.time() - self.daemon_start_ts) * 1000000) % (2**32)
        # TODO: Failure count is always 0 for now.
        failures = 0

        reply = struct.pack("!IIII", resp_sn, recv_ts, reply_ts, failures)
        try:
            sock.sendto(raw_packet[0:4] + reply + raw_packet[20:], address)
        except Exception:
            self.exception("Error sending reply:")
        self.debug("Responded with resp_sn: %s, recv_ts: %s, reply_ts: %s "
                "failures: %s", resp_sn, recv_ts, reply_ts, failures)
        self.resp_sn += 1

    def handle_readable_socket(self, sock):
        """Read one UDP packet from sock and send the reply packet"""
        raw_packet, address = sock.recvfrom(8192)
        received_at = time.time()

        if not self.client_is_allowed(address):
            self.info("Client %s is not allowed to use the server, dropping "
                    "it's request.", address)
            return

        if len(raw_packet) < 20:
            # Too short to be UDP Echo Plus, handle it as ordinary UDP Echo.
            self.info("Received ordinary UDP Echo request from %s.", address)
            sock.sendto(raw_packet, address)
            return

        self.info("Received a UDP Echo Plus request from %s", address)
        self.reply_to_echo_plus(sock, address, raw_packet, received_at)

    def run(self):
        while not self.shutdown_requested:
            try:
                readables = select.select([self.sock], [], [], 5.0)[0]

                if not readables:
                    self.debug("No incoming packets")
                    continue

                for readable in readables:
                    self.handle_readable_socket(readable)
            except Exception:
                if self.shutdown_requested:
                    # Exception was triggered by SIGINT/SIGTERM. This is normal.
                    pass
                else:
                    self.exception("Error in main loop:")

        self.info("EchoPlusServer terminating")

    def load_configuration(self):
        pass


def run():
    daemon = EchoPlusServer()
    daemon.setup()
    daemon.run()
    daemon.cleanup()

if __name__ == "__main__":
    run()

