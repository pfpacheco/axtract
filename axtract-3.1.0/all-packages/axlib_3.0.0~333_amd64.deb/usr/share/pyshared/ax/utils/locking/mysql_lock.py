from tools      import p # p = a debug print tool with cur. thread name
from contextlib import contextmanager


@contextmanager
def mysql_get_lock(engine, lock_name, timeout=10000, block=True):
    '''
    # Requesting a Sql Server Wide Mutually Exclusive Lock

    Blocks until the resource is available.

    ## Params

    - timeout(int): Max time to wait in SECONDS (not milliseconds)
    - lock_name   : Unique name for the lock.
    - block(bool) : Internal use only

    ## Use Cases

    Serializing otherwise conflicting work throughout a cluster.

    ## Example

        with mysql_get_lock(eng, 'mylock'):
            do_stuff_which_only_one_should_do_at_a_time()

    With three clients calling we have then:

        C1: ----call(do_stuff....done)--------------------------------------
        C2: -----call-----------------(do_stuff....done)--------------------
        C3: ----- call----------------------------------(do_stuff....done)--

        C2 and C3 block until the mutex is available.

    ## Dev

    ### Implementation Notes

    - RELEASE_LOCK HAS to be done by the same connection otherwise the
      lock will not be released

    - Getting another lock in the same session will [release](https://dev.mysql.com/doc/refman/5.7/en/miscellaneous-functions.html#function_get-lock)
      the first before MySQL 5.7.5(!)

    - If a connection is closed any locks are released => on the CLI you cannot
      set a lock (CLI closes every command).
    '''

    raw_connection = engine.raw_connection()
    try:
        with mysql_lock(raw_connection, lock_name, timeout, block) as res:
            yield res
    finally:
        raw_connection.close()

is_engine = lambda engine: hasattr(engine, 'raw_connection')

@contextmanager
def mysql_lock(conn, lock_name, timeout=10000, block=True):
    '''
    This accepts normal MySQLdb connections as well as engines
    '''
    if is_engine(conn):
        with mysql_get_lock(conn, lock_name, timeout, block) as res:
            yield res
        return


    # prevent wrong expections - while 0 might make sense:
    if timeout < 1 and timeout > 0:
        raise AttributeError('Timeout must be > 1 second, got', timeout)

    cursor = conn.cursor()

    timeout = 0 if not block else timeout

    try:
        # this blocks:
        cursor.execute('SELECT GET_LOCK("%s", %s)', (lock_name, timeout))
        go_lock = cursor.fetchone()[0]
        if go_lock:
            try:
                yield True
                # client enters context now and does his work - or crashes
            finally:
                cursor.execute('SELECT RELEASE_LOCK("%s")', (lock_name,))
        else:
            yield False
    finally:
        cursor.close()


@contextmanager
def run_once(conn, lock_name, timeout=10000):
    '''
    # Running Stuff Once, Rejecting Other Clients

    This primitive allows to run stuff only once, with all clients calling
    during stuff run time doing nothing.

    ## Example

        if backup_due():
            with run_once(conn, 'run_a_backup') as do:
                if do:
                    backup_db() # takes long

    With 4 clients detecting the need for a backup we have then

        C1: ----call(backing up....done)------------------------------------
        C2: -----------call-------------------------------------------------
        C3: ---------------------call---------------------------------------
        C4: -------------------------------------call(backing up...done)----


        Client 1 will backup.
        Clients 2 and 3 won't be blocked and do nothing.
        Client 4 will run the backup again since he detected due and no backup
        was running.

    '''


    with mysql_lock(conn, lock_name, timeout, block=False) as do:
        yield do


