"""CODE_CACHE
Loading, Compilation and Execution of code during run time.

 Currently a rather trivial implementation, might add needed further
 features later.
 """

import urllib

MAX_CACHE_OBJECTS = 10000
# code by URI in RAM for this process:
CODE_CACHE = {}

# This dictionary contains everything that was loaded via the 'load_ext_uri'
# command below. It is suitable for giving it to an
# eval() statement as $globals parameter
# We need this cache since the server URL might not be always available:

# err_ids for clients which can make use of it:
class CodeLoadingException(Exception):
    """ we could not load the code """
    err_id = 32500

class CodeExecutionException(Exception):
    """ we could not execute the code """
    err_id = 32501

class MaxCodeObjectsExceededException(Exception):
    """ Max Code Objects In The Cache Reached """
    err_id = 32502


def invalidate_cache():
    CODE_CACHE.clear()


def set_global_code_cache_size(size):
    global MAX_CACHE_OBJECTS
    MAX_CACHE_OBJECTS = size



def load_ext_uri(uri, env={},
                cache_code = 1,
                force_reload = None,
                interprocess_cache = None,
                interserver_cache = None):
    """Load code from external URI and exec it.
    $env is a map of exec environment variables.
    Note:
    The client has to take care to have the execing function making itself
    known in the env, so that the slow exec is not called all the time.
    (like setting or updating a loaded model into the MODELS cache)
    """
    #FIXME: get the IPC cache hack from AXWorkflows.py over here
    code = None

    if cache_code:
        cache = CODE_CACHE
        if interserver_cache:
            raise NotImplementedError(
                "Currently no interserver cache supported")
        elif interprocess_cache:
            raise NotImplementedError(
                "Currently no interprocess cache supported")

        code = CODE_CACHE.get(uri)

    if not code or force_reload:
        try:
            #FIXME: Use the contextmgr:
            file_obj = urllib.urlopen(uri)
            code = file_obj.read()
            file_obj.close()
            del(file_obj)
            # before execing the code lets treat the special but frequent case
            # of code downloaded from the AXESS server, which is the 'natural'
            # environment of customizable code:
            # We want to allow pdb style debugging of that code.
            # To get pdb line numbers matching those on the server we move the
            # zope specific comment lines down to the end:

            if uri.endswith('document_src') and code.startswith(
                    '## Script (Python)'
                                                               ):
                pre, code = code.split('##\n', 1)
                code = '%s\n\n#### - SHIFTED:\n%s' % (
                            code,
                            pre
                            )
        except Exception, exc:
            raise CodeLoadingException("Could not load code from %s: %s"\
                    % (uri, exc))

        if cache_code:
            if len(cache) > MAX_CACHE_OBJECTS - 1:
                raise MaxCodeObjectsExceededException \
                        ("Code %s cache has reached %s objects" %
                                (cache, MAX_CACHE_OBJECTS))
            cache[uri] = code

    run_exec_command(code, env)
    return code


def run_exec_command(code, env = {}):
    try:
        exec code in env
    except Exception, exc:
        raise CodeExecutionException("Error executing %s: %s" % (code, exc))




