#!/usr/bin/python -tt
import unittest
import threading
import thread

from Queue import Empty
from ax.utils.ax_queue import AXQueue as Queue

import ax.utils.workerpool as workerpool



class TestWorkerPool(unittest.TestCase):
    def double(self, i):
        return i * 2

    def add(self, *args):
        return sum(args)

    def test_map(self):
        """Map a list to a method to a pool of two workers."""
        pool = workerpool.WorkerPool(2)

        result = pool.map(self.double, [1, 2, 3, 4, 5])
        # Cannot rely on the order of results, use set() for comparison.
        result_set = set(result)
        self.assertEquals(result_set, set([2, 4, 6, 8, 10]))
        pool.shutdown()
        pool.join()

    def test_map_multiparam(self):
        """Test map with multiple parameters."""
        pool = workerpool.WorkerPool(2)
        result = pool.map(self.add, [1, 2, 3], [4, 5, 6])
        # Cannot rely on the order of results, use set() for comparison.
        result_set = set(result)
        self.assertEquals(result_set, set([5, 7, 9]))

        pool.shutdown()
        pool.join()

    def test_join(self):
        """Make sure each task gets marked as done so pool.join() works."""
        pool = workerpool.WorkerPool(5)
        q = Queue()
        for i in xrange(100):
            pool.put(workerpool.SimpleJob(q, sum, [range(5)]))
        pool.join()
        pool.shutdown()
        pool.join()

    def test_init_size(self):
        pool = workerpool.WorkerPool(1)
        self.assertEquals(pool.size(), 1)
        pool.shutdown()

    def test_shrink(self):
        pool = workerpool.WorkerPool(1)
        pool.shrink()
        self.assertEquals(pool.size(), 0)
        pool.shutdown()

    def test_grow(self):
        pool = workerpool.WorkerPool(1)
        pool.grow()
        self.assertEquals(pool.size(), 2)
        pool.shutdown()
        pool.join()

    def test_changesize(self):
        """Change sizes and make sure pool doesn't work with no workers."""
        pool = workerpool.WorkerPool(5)
        for i in xrange(5):
            pool.grow()
        self.assertEquals(pool.size(), 10)
        for i in xrange(10):
            pool.shrink()
        pool.join()
        self.assertEquals(pool.size(), 0)

        # Make sure nothing is reading jobs anymore
        q = Queue()
        for i in xrange(5):
            pool.put(workerpool.SimpleJob(q, sum, [range(5)]))
        try:
            q.get(block=False)
        except Empty:
            pass  # Success
        else:
            assert False, ("Something returned a result, even though we are"
            "expecting no workers.")
        pool.shutdown()

    def test_maxsize(self):
        """Pool should not grow beyond given maxsize"""

        # Instantiate 1 worker, limit workers to 2
        pool = workerpool.WorkerPool(1, maxsize=2)

        # Instantiate second worker. This reaches the limit.
        pool.grow()

        # Now we would exceed the limit -> exception must be raised
        self.assertRaises(IndexError, pool.grow)

        pool.shutdown()
        pool.join()

    def test_daemon_thread(self):
        """Even if pool.shutdown is forgotten, WorkerPool must not hang"""
        pool = workerpool.WorkerPool(1)
        # Do nothing. The pool's worker threads should terminate by themselves.

    def test_join_on_excepting_job(self):
        """workerpool subclasses Queue. So join() must work, even if jobs except

        This checks if AXOS-104 is really fixed.
        """
        pool = workerpool.WorkerPool(1)
        # Invalid parameters that will lead to exception as soon as job.run() is called.
        broken_job = workerpool.jobs.SimpleJob(None, None)

        pool.put(broken_job)

        # This must not block
        pool.join()

        pool.shutdown()
        pool.join()

    def test_works_after_exception(self):
        """If one job excepts, the next one must still work"""
        q = Queue()
        # Invalid parameters that will lead to exception as soon as job.run() is called.
        broken_job = workerpool.jobs.SimpleJob(None, None)
        good_job = workerpool.SimpleJob(q, sum, [range(5)])
        # Just a single thread. If broken_job messes it up, no further
        # processing happens.
        pool = workerpool.WorkerPool(1, maxsize=1)

        pool.put(broken_job)
        pool.put(good_job)

        # Make sure both jobs ran.
        pool.join()

        result = q.get()
        self.assertEqual(result, 10)

        pool.shutdown()
        pool.join()

    def test_run_on_all_threads(self):
        class Job(object):
            def __init__(self):
                self.called = set()
                self._lock = threading.RLock()

            def run(self):
                with self._lock:
                    self.called.add(thread.get_ident())

        pool = workerpool.WorkerPool(50)
        job = Job()
        pool.run_on_all_threads(job)
        pool.join()

        try:
            self.assertEqual(50, len(job.called))
        finally:
            pool.shutdown()
            pool.join()


if __name__ == "__main__":
    unittest.main()
