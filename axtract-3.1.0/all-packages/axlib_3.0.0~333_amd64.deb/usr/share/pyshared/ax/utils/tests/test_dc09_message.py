#!/usr/bin/python -tt

import datetime
import unittest2

import ax.utils.dc09_message as dc09

class DC09MessageTests(unittest2.TestCase):
    def test_annex_B_1(self):
        """Test example 1 of Annex B"""
        message = '\x0ACE110032"SIA-DCS"9876R579BDFL789ABC#12345A[#12345A|NFA129]\x0D'
        dc = dc09.DC09Message(message)

        #self.assertEqual(dc.crc, int("CE11", 16))
        self.assertEqual(dc.crc, int("CE11", 16))
        self.assertEqual(dc.length, int("032", 16) )
        self.assertEqual(dc.id_, "SIA-DCS")
        self.assertEqual(dc.is_encrypted, False)
        self.assertEqual(dc.seq, 9876)
        self.assertEqual(dc.rcvr, "579BDF")
        self.assertEqual(dc.pref, "789ABC")
        self.assertEqual(dc.acct, "12345A")

        # TODO: Properly check data field
        self.assertEqual(dc.data, "#12345A|NFA129")
        self.assertEqual(dc.timestamp, None)

        # Re-encoding must yield identical message
        self.assertEqual(dc.encode(), message)

    def test_annex_B_3(self):
        """Test example 3 of Annex B"""
        message = '\x0ADC530046"SIA-DCS"9876R579BDFL789ABC#12345A[#12345A|NFA129]_13:14:15,02-15-2006\x0D'
        dc = dc09.DC09Message(message)

        self.assertEqual(dc.crc, int("DC53", 16))
        self.assertEqual(dc.length, int("046", 16) )
        self.assertEqual(dc.id_, "SIA-DCS")
        self.assertEqual(dc.is_encrypted, False)
        self.assertEqual(dc.seq, 9876)
        self.assertEqual(dc.rcvr, "579BDF")
        self.assertEqual(dc.pref, "789ABC")
        self.assertEqual(dc.acct, "12345A")

        # TODO: Properly check data field
        self.assertEqual(dc.data, "#12345A|NFA129")
        self.assertEqual(dc.timestamp,
                datetime.datetime(
                    year=2006, month=2, day=15, hour=13, minute=14, second=15)
                )

        # Re-encoding must yield identical message
        self.assertEqual(dc.encode(), message)

    def test_leading_zeros(self):
        """Leading zeros must be padded during encoding

        Some fields are defined as fixed length an must be zero-padded when
        they are shorter. This includes the CRC.
        """
        message = '\x0A0829003E"SIA-DCS"0001R42L1234#12345A[some_message]_01:04:05,02-05-2006\x0D'
        dc = dc09.DC09Message(message)

        self.assertEqual(dc.crc, int("0829", 16))
        self.assertEqual(dc.length, int("03E", 16) )
        self.assertEqual(dc.id_, "SIA-DCS")
        self.assertEqual(dc.is_encrypted, False)
        self.assertEqual(dc.seq, 1)
        self.assertEqual(dc.rcvr, "42")
        self.assertEqual(dc.pref, "1234")
        self.assertEqual(dc.acct, "12345A")

        # Re-encoding must yield identical message
        self.assertEqual(dc.encode(), message)

    def test_parsed_data_section(self):
        """DC09 message with a data section that can be parsed.

        Particularly, the encode() method must handle the data object
        correctly.
        """
        message = '\n2F89003E"ADM-CID"0005L0#007015[007015|1710 42 123]_11:53:08,08-28-2012\r'
        dc = dc09.DC09Message(message)

        self.assertEqual(dc.data.account, "007015")
        self.assertEqual(dc.data.qualifier, "1")
        self.assertEqual(dc.data.event_code, "710")
        self.assertEqual(dc.data.group, "42")
        self.assertEqual(dc.data.zone_number, "123")
        self.assertEqual(dc.data.with_hash, False)

        # Re-encoding must yield identical message
        self.assertEqual(dc.encode(), message)

    def test_altibox_binary(self):
        """Message with a binary CRC as used at Altibox"""
        # The binary checksum is "Z#", which happens to be printable ASCII.
        message = '\nZ#003E"ADM-CID"0008L0#961056[961056|1710 00 002]_11:37:09,09-03-2012\r'
        dc = dc09.DC09Message(message)

        # Re-encoding must yield identical message. Especiall the CRC must
        # be encoded in binary format.
        self.assertEqual(dc.encode(), message)

    def test_encode_adm_cid_data(self):
        """When .data is a DataADMCID object, message format must be set"""
        dc = dc09.DC09Message()
        data = dc09.DataADMCID(data="007015|1710 42 123")

        dc.data = data
        dc.acct = "007015"
        dc.seq = 42

        encoded = dc.encode()

        # Even though not explicitly set, DC09Message must infer the message
        # type from its .data property.
        self.assertTrue('"ADM-CID"' in encoded)

    def test_encrypted_no_key(self):
        """Parsing encrypted message w/o key must produce partial message"""
        message = '\x0A3AB80032"*SIA-DCS"0001R42L1234#12345A[SOME_ENCRYPTED_STUFF\x0D'
        dc = dc09.DC09Message(message)

        # This information is in the unencrypted part -> must be parsed
        self.assertEqual(dc.crc, int("3AB8", 16))
        self.assertEqual(dc.length, int("032", 16) )
        self.assertEqual(dc.id_, "SIA-DCS")
        self.assertEqual(dc.seq, 1)
        self.assertEqual(dc.rcvr, "42")
        self.assertEqual(dc.pref, "1234")
        self.assertEqual(dc.acct, "12345A")

        # These 2 properties are in the encrypted part -> still None
        self.assertIsNone(dc.data)
        self.assertIsNone(dc.timestamp)
        self.assertEqual(dc.is_encrypted, True)
        self.assertIsNone(dc.encryption_key)
        self.assertEqual(dc.encrypted_data, "SOME_ENCRYPTED_STUFF")

    def test_padding_unpadding(self):
        for msg_length in range(0, 50):
            message = "X" * msg_length
            padded_message = dc09.DC09Message.pad(message, long_pad=False)
            long_padded_message = dc09.DC09Message.pad(message)
            self.assertEqual(len(padded_message) % 16, 0)
            self.assertEqual(len(long_padded_message) % 16, 0)
            # Even when message length is already a multiple of 16, padding
            # must be added, so padded_message is always longer.
            self.assertGreater(len(padded_message), len(message))
            self.assertGreater(len(long_padded_message), len(padded_message))

            # Message contains only "X". Padded message must contain exactly
            # one pad separator and neither "[" nor "]"
            self.assertEqual(padded_message.count("|"), 1)
            self.assertEqual(padded_message.count("["), 0)
            self.assertEqual(padded_message.count("]"), 0)
            self.assertEqual(long_padded_message.count("|"), 1)
            self.assertEqual(long_padded_message.count("["), 0)
            self.assertEqual(long_padded_message.count("]"), 0)

            unpadded_message = dc09.DC09Message.unpad(padded_message)
            self.assertEqual(message, unpadded_message)

            unpadded_message = dc09.DC09Message.unpad(long_padded_message)
            self.assertEqual(message, unpadded_message)

    def test_lyse_decryption1(self):
        # First sample message provided by Trond Kvarnes
        # CRC and length field manually corrected.
        encrypted = ('\x0aecf600a4"*ADM-CID"0019R579BDFL789ABC#12345A'
                '[452bb6489d5b929e28092c7eaa40011f6d53e0474bef9fd1132d91d8c98a'
                'b75d0fdaa5580012a364f2cff0964241543ac54f6d62a63270b05e11acce8'
                '193de01\x0d')
        decrypted = ('\x0a6773004B"ADM-CID"0019R579BDFL789ABC#12345A'
                '[#12345A|1110 00 016]_13:11:11,06-18-2014\x0d')
        enc_msg = dc09.DC09Message(encrypted, encryption_key="Sixteen byte key")
        dec_msg = dc09.DC09Message(decrypted)

        self.assertEqual(enc_msg.id_, dec_msg.id_)
        self.assertEqual(enc_msg.seq, dec_msg.seq)
        self.assertEqual(enc_msg.rcvr, dec_msg.rcvr)
        self.assertEqual(enc_msg.pref, dec_msg.pref)
        self.assertEqual(enc_msg.acct, dec_msg.acct)
        self.assertEqual(enc_msg.timestamp, dec_msg.timestamp)
        self.assertEqual(enc_msg.data, dec_msg.data)

        # Re-encrypting does not yield the original message string, since
        # random padding is used.
        reencrypted = enc_msg.encode()
        redecrypted = dc09.DC09Message(reencrypted,
                encryption_key="Sixteen byte key")
        self.assertEqual(enc_msg.id_, redecrypted.id_)
        self.assertEqual(enc_msg.seq, redecrypted.seq)
        self.assertEqual(enc_msg.rcvr, redecrypted.rcvr)
        self.assertEqual(enc_msg.pref, redecrypted.pref)
        self.assertEqual(enc_msg.acct, redecrypted.acct)
        self.assertEqual(enc_msg.timestamp, redecrypted.timestamp)
        self.assertEqual(enc_msg.data, redecrypted.data)

    def test_lyse_decryption2(self):
        # Second sample message provided by Trond Kvarnes
        # CRC and length field manually corrected.
        encrypted = ('\x0afd5000a4"*ADM-CID"0020R579BDFL789ABC#12345A'
                '[9f400d84e56adf488edd82ae4a3e9480c83f806d5f2ed0197a6902ab661d'
                'a10312f7ad17a79d842d040dea705d5e945b16b082bad40a8df13d0f9ec4b'
                'a8a3f46\x0d')
        decrypted = ('\x0aF77F004b"ADM-CID"0020R579BDFL789ABC#12345A'
                '[#12345A|1110 00 016]_13:11:21,06-18-2014\x0d')

        enc_msg = dc09.DC09Message(encrypted, encryption_key="Sixteen byte key")
        dec_msg = dc09.DC09Message(decrypted)

        self.assertEqual(enc_msg.id_, dec_msg.id_)
        self.assertEqual(enc_msg.seq, dec_msg.seq)
        self.assertEqual(enc_msg.rcvr, dec_msg.rcvr)
        self.assertEqual(enc_msg.pref, dec_msg.pref)
        self.assertEqual(enc_msg.acct, dec_msg.acct)
        self.assertEqual(enc_msg.timestamp, dec_msg.timestamp)
        self.assertEqual(enc_msg.data, dec_msg.data)

        # Re-encrypting does not yield the original message string, since
        # random padding is used.
        reencrypted = enc_msg.encode()
        redecrypted = dc09.DC09Message(reencrypted,
                encryption_key="Sixteen byte key")
        self.assertEqual(enc_msg.id_, redecrypted.id_)
        self.assertEqual(enc_msg.seq, redecrypted.seq)
        self.assertEqual(enc_msg.rcvr, redecrypted.rcvr)
        self.assertEqual(enc_msg.pref, redecrypted.pref)
        self.assertEqual(enc_msg.acct, redecrypted.acct)
        self.assertEqual(enc_msg.timestamp, redecrypted.timestamp)
        self.assertEqual(enc_msg.data, redecrypted.data)


class DataADMCIDTests(unittest2.TestCase):
    def test_empty_create(self):
        data = dc09.DataADMCID()
        self.assertEqual(data.account, None)
        self.assertEqual(data.qualifier, None)
        self.assertEqual(data.event_code, None)
        self.assertEqual(data.group, None)
        self.assertEqual(data.zone_number, None)

        # Ensure that the default is not modified
        self.assertEqual(data.with_hash, True)

    def test_decode(self):
        data = dc09.DataADMCID(data="007015|1710 42 123")
        self.assertEqual(data.account, "007015")
        self.assertEqual(data.qualifier, "1")
        self.assertEqual(data.event_code, "710")
        self.assertEqual(data.group, "42")
        self.assertEqual(data.zone_number, "123")
        self.assertEqual(data.with_hash, False)

        data = dc09.DataADMCID(data="#007015|1710 42 123")
        self.assertEqual(data.account, "007015")
        self.assertEqual(data.qualifier, "1")
        self.assertEqual(data.event_code, "710")
        self.assertEqual(data.group, "42")
        self.assertEqual(data.zone_number, "123")
        self.assertEqual(data.with_hash, True)

    def test_encode(self):
        msg = "007015|1710 42 123"
        data = dc09.DataADMCID(msg)
        self.assertEqual(data.encode(), msg)

        msg = "#007015|1710 42 123"
        data = dc09.DataADMCID(msg)
        self.assertEqual(data.encode(), msg)

    def test_exceptions(self):
        # Last number is cut off -> message is too short
        self.assertRaises(dc09.DC09DecodeError,
                dc09.DataADMCID, "007015|1710 42 12")
        # Last number is invalid
        self.assertRaises(dc09.DC09DecodeError,
                dc09.DataADMCID, "007015|1710 42 XYZ")

        # Encoding when you forgot to set some value
        data = dc09.DataADMCID(data="#007015|1710 42 123")
        data.account = None
        self.assertRaises(dc09.DC09EncodeError, data.encode)

    def test_equality(self):
        msg1 = "007015|1710 42 123"
        msg2 = "007016|1710 42 123"
        msg3 = "007015|1711 42 123"
        msg4 = "007015|1710 43 123"
        msg5 = "007015|1710 42 124"

        # Equal messages
        data1 = dc09.DataADMCID(msg1)
        data2 = dc09.DataADMCID(msg1)
        self.assertTrue(data1 == data2)
        self.assertFalse(data1 != data2)

        # Unequal for various reasons
        data3 = dc09.DataADMCID(msg2)
        self.assertTrue(data1 != data3)
        self.assertFalse(data1 == data3)

        data3 = dc09.DataADMCID(msg3)
        self.assertTrue(data1 != data3)
        self.assertFalse(data1 == data3)

        data3 = dc09.DataADMCID(msg4)
        self.assertTrue(data1 != data3)
        self.assertFalse(data1 == data3)

        data3 = dc09.DataADMCID(msg5)
        self.assertTrue(data1 != data3)
        self.assertFalse(data1 == data3)


if __name__ == "__main__":
    unittest2.main()

