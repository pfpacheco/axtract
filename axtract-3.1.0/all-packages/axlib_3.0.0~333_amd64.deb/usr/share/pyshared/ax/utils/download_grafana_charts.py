#!/usr/bin/env python
"""
Download Grafana Charts from given dashboards from a given endpoint 
"""
from time import strptime, localtime, mktime
from copy import deepcopy
import simplejson as json
import sqlite3
import requests
import argparse

GRAFANA_ENDPOINT = "http://127.0.0.1:3000/render/dashboard-solo/db/"
GRAFANA_DB_PATH = "/var/lib/grafana/grafana.db"
CHART_WIDTH, CHART_HEIGTH = 700, 250

def print_error_and_exit(value):
    print "Invalid option value (%s)" % value
    parser.print_help()
    import sys; sys.exit()

def parse_args():
    parser.add_argument("-d", "--date")
    parser.add_argument("-t", "--time", required=True)
    parser.add_argument("-l", "--duration", type=int, required=True)
    parser.add_argument("-s", "--slugs", nargs='*')
    parser.add_argument("-g", "--grafana-endpoint")
    return parser.parse_args()


class ChartsDownloader(object):
    def __init__(
            self,
            grafana_endpoint,
            grafana_db_path,
            time_settings,
            image_settings):

        self.grafana_endpoint = grafana_endpoint
        self.grafana_db_path = grafana_db_path
        chart_start_ts, chart_stop_ts = self._get_time_boundaries(**time_settings)
        self.qs_params = {
            'from': 1000 * chart_start_ts,
            'to': 1000 * chart_stop_ts,
            'width': image_settings['width'],
            'height': image_settings['heigth']
        }

    def _get_time_boundaries(self, date, time, duration):
        try:
            start_time = strptime(time, '%H%M')
            start_time = (start_time.tm_hour, start_time.tm_min)
        except ValueError:
            print_error_and_exit(time)

        if date:
            try:
                start_date = strptime(date, '%Y%m%d')
            except ValueError:
                print_error_and_exit(date)
        else:
            start_date = localtime()
        start_date = (start_date.tm_year, start_date.tm_mon, start_date.tm_mday)
        self.chart_ts = "%04d%02d%02d_%02d%02d" % (start_date + start_time)

        start_ts = int(mktime(start_date + start_time + (0, 0, 0, -1)))
        return start_ts, start_ts + 60 * duration

    def _get_dashboard_templating_context(self, tpl_list):
        tpl_context = []
        for tpl in tpl_list:
            tpl_choices = tpl['current']['text']
            if isinstance(tpl_choices, list):
                tpl_choices = '-'.join(tpl_choices)
            tpl_context.append(tpl_choices)
        return tpl_context

    def _merge_panel_scoped_vars(self, scoped_vars, context):
        if scoped_vars:
            scoped_vars = [
                var['text'] for var in scoped_vars.values()
                if var['selected'] == True
            ]

            for sv in scoped_vars:
                for tv in context:
                    if sv in tv:
                        i = context.index(tv)
                context[i] = sv

    def _handle_tpl_multi_values(self, rows, hostnames):
        repeat_panel_id = 100
        for row in rows:
            first_panel = row['panels'][0]
            scoped_hostname = first_panel['scopedVars']['hostname']
            scoped_hostname['text'] = hostnames[0]
            scoped_hostname['value'] = hostnames[0]
            row['panels'][1:] = []

            if len(hostnames) > 1:
                panel_copy = deepcopy(first_panel)
                panel_copy['repeat'] = None
                scoped_hostname = panel_copy['scopedVars']['hostname']
                for hostname in hostnames[1:]:
                    repeat_panel_id += 1
                    panel_copy['id'] = repeat_panel_id
                    panel_copy['repeatPanelId'] = first_panel['id']
                    scoped_hostname['text'] = hostname
                    scoped_hostname['value'] = hostname
                    row['panels'].append(panel_copy)

    def get_grafana_dash_configs(self, dashboards):
        assert dashboards is None or isinstance(dashboards, list), \
            "Argument dashboards must be a list"

        self.conn = sqlite3.connect(self.grafana_db_path)
        cur = self.conn.cursor()

        query = "SELECT slug, data FROM dashboard"
        if dashboards:
            if len(dashboards) == 1:
                query += " WHERE slug='%s'" % dashboards[0]
            if len(dashboards) > 1:
               query += " WHERE slug in %s" % str(tuple(dashboards))

        cur.execute(query)
        return cur

    def set_template_hostnames(self, dashboard, hostnames):
        assert isinstance(dashboard, str), "Argument dashboard must be a string"

        assert isinstance(hostnames, list) and hostnames, \
            "Argument hostnames must be a non-empty list"

        dash_config = self.get_grafana_dash_configs([dashboard])
        data = json.loads(str(next(dash_config)[1]))

        hostname_tpl = data['templating']['list'][0]
        tpl_current = hostname_tpl['current']
        multi = hostname_tpl['multi']

        assert multi or len(hostnames) == 1, \
            "Hostname template is not multi-values. Only one hostname allowed."

        tpl_current['value'] = hostnames
        tpl_current['text'] = ' + '.join(hostnames)

        if multi:
            self._handle_tpl_multi_values(data['rows'], hostnames)

        data = buffer(json.dumps(data))
        cur = self.conn.cursor()
        cur.execute("""UPDATE dashboard SET data=? WHERE slug=?""", (data, dashboard))
        self.conn.commit()

    def download_png(self, dashboard, row_title, panel_id, panel_context):
        filename = [
            '_'.join((dashboard, row_title, '_'.join(panel_context))),
            self.chart_ts,
        ]
        params = self.qs_params.copy()
        params['panelId'] = panel_id
        r = requests.get(self.grafana_endpoint + dashboard, params=params, stream=True)
        with open('_'.join(filename) + '.png', 'wb') as fd:
            for chunk in r.iter_content(chunk_size=128):
                fd.write(chunk)
            return True

    def run(self, dashboards):
        dash_configs = self.get_grafana_dash_configs(dashboards)
        downloads_num = 0
        for slug, data in dash_configs:
            data = json.loads(str(data))
            try:
                tpl_context = self._get_dashboard_templating_context(data['templating']['list'])
            except KeyError:
                print "ERROR: some template variable is not defined in dashboard (%s)" % slug
                print "Skipping dashboard charts."
                continue

            for row in data['rows']:
                row_title = row['title'].lower().replace(' ', '-')
                for panel in row['panels']:
                    panel_context = tpl_context[:]
                    self._merge_panel_scoped_vars(panel.get('scopedVars'), panel_context)
                    if self.download_png(slug, row_title, panel['id'], panel_context):
                        print "%s %s: %s" % (slug, row_title, panel_context)
                        downloads_num += 1

        return downloads_num

    def close(self):
        self.conn.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser("Fetch Benchmarks Charts from Grafana")
    args = parse_args()

    downloader = ChartsDownloader(
        args.grafana-endpoint or GRAFANA_ENDPOINT,
        GRAFANA_DB_PATH,
        {'date': args.date, 'time': args.time, 'duration': args.duration},
        {'width': CHART_WIDTH, 'heigth': CHART_HEIGTH}
    )

    # For a couple of dashboards, the template variables must be set appropriately
    # because the variables stored in the dashboards are only one option.
    CHARTS_TPL_VARS = {
        'host-overview': (['axtract'], ['mongo1', 'mongo2']),
        'mongodb-overview': (['mongo1'], ['mongo2'])
    }
    if not args.slugs:
        common_dashboards = CHARTS_TPL_VARS.keys()
    else:
        common_dashboards = set(CHARTS_TPL_VARS.keys()) & set(args.slugs)

    num_common = 0
    if common_dashboards:
        for d in common_dashboards:
            downloader.set_template_hostnames(d, CHARTS_TPL_VARS[d][0])
        num_common = downloader.run(list(common_dashboards))

        for d in common_dashboards:
            downloader.set_template_hostnames(d, CHARTS_TPL_VARS[d][1])

    num = downloader.run(args.slugs)
    print "Downloads completed: %d" % (num_common + num,)
