"""
Module to look into the current state of a running process.

Provides the ThreadAnalyzer class that will start an observer thread. Once
a certain trigger-file appears in the file system, it starts dumping thread
information (call stack, locals, globals) until that trigger-file disappears.

By default, the trigger file is /tmp/ta_trigger_<PID> where PID is the process
ID of the process you want to analyze.
"""
import os
import os.path
import sys
import tempfile
import thread
import threading
import time
import traceback

from ax.utils.thread_anal.thread_anal_formatters import formatter_factory

class ThreadAnalyzer(object):
    def __init__(self, interval=5.0, trigger_dir="/tmp", style="pprint",
            show_globals=True, show_locals=True):
        """
            interval: Every how many seconds to check for trigger file. Also
                the interval in which dumps are made.
            trigger_dir: Directory in which to look for the trigger file.
            style: How dumped variables should be formatted. See
                thread_anal_formatters.py -> formatter_factory() for a list
                of supported styles.
            show_globals/locals: If the dump should include the global/local
                variables.
        """
        self.interval = float(interval)
        if self.interval <= 0:
            raise Exception("Interval '%s' is invalid" % self.interval)

        if not os.path.isdir(trigger_dir):
            raise Exception("trigger_dir '%s' does not exist or is not a "
                    "directory" % trigger_dir)
        # The output file uses the same names, just with an extra suffix
        self.trigger_dir = trigger_dir
        self.trigger_file = "ta_trigger_%s" % os.getpid()
        self.trigger_path = os.path.join(self.trigger_dir, self.trigger_file)

        self.formatter = formatter_factory(style)
        self.formatter.show_globals = show_globals
        self.formatter.show_locals = show_locals

        # The thread in which our run() runs
        self.run_thread = None

    def write_dump(self, data):
        """Write $data to disc without any changes.
        """
        prefix = self.trigger_file + "_%.3f_" % time.time()
        descriptor = tempfile.mkstemp(prefix=prefix, dir=self.trigger_dir)[0]
        # For testing only:
        #descriptor = sys.stdin.fileno()

        try:
            os.write(descriptor, data)
        finally:
            # Do not close if this is STDIN/STDOUT/STDERR.
            # Careful: sys.__stdout__.fileno() will except if it is closed. In
            # that case, descriptors 0, 1 and 2 might be recycled as ordinary
            # file descriptors.
            protected_fds = []
            for std in (sys.__stdin__, sys.__stdout__, sys.__stderr__):
                try:
                    protected_fds.append(std.fileno())
                except Exception:
                    # That's OK if it is closed.
                    pass
            if descriptor not in protected_fds:
                os.close(descriptor)

    def get_dump(self):
        """Get and format a dump.
            Returns the dump as a string.
        """
        data = self.get_data()
        return self.format_data(data)

    def format_data(self, data):
        return  self.formatter.format(data)

    def get_data(self):
        """Returns a dict with info about our threads
            Structure of the dict is
            {<thread ID>: {'stack': [..], 'globals': {..}, 'locals': {..}, ..}
        """
        retval = {}
        # The _current_frames() gives us only a shallow copy. We must prevent
        # other threads from running, otherwise they will modify the data
        # and the information returned by us may become inconsistent.
        old_interval = sys.getcheckinterval()
        try:
            sys.setcheckinterval(1000000000)
            frames = sys._current_frames()

            for tid, frame in frames.items():
                # Do not show this thread if it is an observer thread.
                if self.run_thread and tid == thread.get_ident():
                    continue
                entry = {}
                entry['stack'] = traceback.extract_stack(frame)

                # f_globals
                copy = dict(frame.__getattribute__("f_globals"))
                for keyname in ("__builtins__", "copyright"):
                    if copy.has_key(keyname):
                        del(copy[keyname])
                entry['globals'] = copy

                # f_locals
                entry['locals'] = frame.__getattribute__("f_locals")

                retval[tid] = entry
        finally:
            sys.setcheckinterval(old_interval)

        return retval

    def _run(self):
        """Run threaded and wait for trigger file to appear"""
        while True:
            try:
                if os.path.isfile(self.trigger_path):
                    self.write_dump(self.get_dump())
            except Exception:
                # No log to write to...
                pass
            time.sleep(self.interval)

    def start(self):
        """Launch observer thread"""
        self.run_thread = threading.Thread(target=self._run)
        self.run_thread.daemon = True
        self.run_thread.start()

