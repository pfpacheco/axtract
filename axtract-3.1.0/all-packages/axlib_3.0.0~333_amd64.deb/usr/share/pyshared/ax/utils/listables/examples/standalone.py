#!/usr/bin/env python
"""
Inline Usage of the API

"""
#import os, sys
#sys.path.insert(0, '/opt/axess/Extensions')

from ax.utils.listables import AxessSchema
from ax.utils.listables import get_listables
from ax.utils.listables import listable
import MySQLdb

native = {'sql': None}
def sql_runner(req, sql, params):
    native['sql'].execute(sql, params)
    res = cursor.fetchall()
    return res

def my_api(api, type):
    if type == 'sql':
        return {'run': sql_runner}

# simply duck punch this (could also handle it over as API):
listable.get_api = my_api

def test(listables):
    lt = listables['Enterprise']
    # no base filters:
    q_map = lt.realize_filters([['Operator.account_name', '=', '"operator1"']], None)
    q_map = lt.realize_filters(
        [
            [
                ['cpe.cpetype', '=', '"genericTR69"'],
                'and',
                ['cpe.roles', '=', '"unsupportedFW"']
            ],
            'or',
            ['cpe.cpeid', '=', '"ZZ0000000001"']
        ],
        None)
    print "Ralized Filters:"
    print q_map
    lt.realize_meta(q_map, {'limit': 10, 'offset': 0,
                            'show': ['kv', 'cpe.cpeid', 'cpe.IP', 'cpe.version'],
                            'sort': None})
    # q_map is now a value only (NO! objects) data structure which you can store
    # and reapply as often as you want.
    # give it a name and you have groups (?)
    try:
        print "Query Map:"
        print q_map
        print "Result:"
        data = lt.get_data(q_map, API={})
        print data
        data = listables.post_process(data, q_map, API={})
        print data
    except Exception, ex:
        print "Exception: " + str(ex)

if __name__ == '__main__':
    db = MySQLdb.connect(user='admin', port = 3306, host='127.0.0.1', passwd='ax', db='live')
    db.autocommit(True)
    cursor = db.cursor()
    native['sql'] = cursor
    listables = get_listables(AxessSchema)
    print "Paths:"
    print listables.paths
    test(listables)

