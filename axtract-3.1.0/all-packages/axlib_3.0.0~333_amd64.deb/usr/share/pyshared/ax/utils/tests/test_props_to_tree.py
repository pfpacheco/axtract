import unittest
from ax.utils.props_to_tree import py_props_to_tree
from ax.utils.props_to_tree import c_props_to_tree

from ax.utils.props_to_tree import py_tree_to_props
from ax.utils.props_to_tree import _tree_to_props

import time
import cPickle


class TestPropsToTree(unittest.TestCase):
    NB = 10**6
    NB = 1
    example = {
            "I.MS.FOO" : 1,
            "I.FS.XXX" : 2,
            "I.MS.XXX" : 3,
            "I.SH.IR.FR.SN.GK.KP" : "MB",
            "X" : 4,
            "XXX.FFFF" : 4
        }

    def _check(self, tree):
        self.assertEqual(tree['I']['MS']['FOO'], 1)
        self.assertEqual(tree['I']['FS']['XXX'], 2)
        self.assertEqual(tree['I']['MS']['XXX'], 3)
        self.assertEqual(tree['I']['SH']['IR']['FR']['SN']['GK']['KP'], 'MB')
        self.assertEqual(tree['X'], 4)
        self.assertEqual(tree["XXX"]['FFFF'], 4)

    def test_simple_py(self):
        start = time.time()
        for _ in xrange(self.NB):
            self._check(py_props_to_tree(self.example))
        #print 'simple', time.time() - start

    def test_c_version(self):
        start = time.time()
        for _ in xrange(self.NB):
            self._check(c_props_to_tree(self.example))
        #print 'real c', time.time() - start

    def test_simple_py_complex_tree(self):
        start = {
            "I.MS.FOO" : {
                "WAN.LAN" : {
                    "NUM.FAB" : 1}
                }
        }
        # IMPORTANT: Props to tree is not capable to convert the values also
        # the problem is the convert backwards ! we dont know the orgiginal
        # structure
        ref = {"I" : {"MS" : {"FOO" : {"WAN.LAN" : {"NUM.FAB" : 1}}}}}
        self.assertEqual(ref, py_props_to_tree(start))

    def test_pickle_result(self):
        doc = {'I.MS.FOO': 1, "I.MS.BAR": 2}
        ref = {'I': {'MS': {'FOO': 1, 'BAR': 2}}}

        ret = cPickle.loads(cPickle.dumps(py_props_to_tree(doc)))
        self.assertEqual(ref, ret)

        ret = cPickle.loads(cPickle.dumps(c_props_to_tree(doc)))
        self.assertEqual(ref, ret)


class TestTreeToProps(unittest.TestCase):
    NB = 10**6
    NB = 1
    tree = {
        "I" : {
            "F" : {
                "X" : 1
            },
            "XXXX" : {
                "FFF" : 3,
                "FD" : 7
            }
        },
        "Foo" : 1,
        "aaa" : {
            "b" : {
                "c" : {
                    "d" : 1
                }
            }
        }
    }

    def _check(self, props):
        self.assertEqual(props['I.F.X'], 1)
        self.assertEqual(props["I.XXXX.FFF"], 3)
        self.assertEqual(props["I.XXXX.FD"], 7)
        self.assertEqual(props["Foo"], 1)
        self.assertEqual(props["aaa.b.c.d"], 1)

    def test_simple(self):
        start = time.time()
        for _ in xrange(self.NB):
            self._check(py_tree_to_props(self.tree))
        #print 'simple tree to props', time.time() - start

    def test_fast(self):
        start = time.time()
        for _ in xrange(self.NB):
            self._check(_tree_to_props(self.tree))
        #print 'fast tree to props', time.time() - start
