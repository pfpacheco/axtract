"""
A robust implementation of a Token Bucket, plus goodies using it.

There are also hooks to provide your own measure of time (to replace
the time.time() function) or your own way of sleeping (to replace the
time.sleep() function). Check __init__() for details.

Usage example that will print "hello world" 3 times per second:
    >>> from ax.utils import tokenbucket
    >>> tb = tokenbucket.Tokenbucket(1, 3)
    >>> while 1:
    >>>  tb.take_token()
    >>>  print "hello world"
"""

import os
import ax.utils
import time

# this StrictRedis import points to the normal redis library
# and not the ax.utils one
from redis.client import StrictRedis
from ax.utils import thread_proxy


class Tokenbucket(object):
    """A robust Tokenbucket implementation with some goodies.
        Robust means that the Tokenbucket is prepared for stuff like system time
        jumping backwards or signals interrupting a sleep().

        This version is _not_ threadsafe. See ThreadsafeTokenbucket below if
        you intend to share a bucket among threads.
        Performance is roughly 460k take_token() operations per second. Of
        course assuming that the rate is very high and "python -OO".
    """
    def _get_rate(self):
        return self._rate

    def _set_rate(self, value):
        """Ensure that self.rate is a float, not an int.
            This makes setting self.rate expensive, but _add_tokens()
            does not need to cast each time.
        """
        self._rate = float(value)
    rate = property(_get_rate, _set_rate)

    def __init__(self, bucketsize, rate, sleepfunc=None, timefunc=None, prefill=0):
        """Parameters:
            - bucketsize, rate: Define how big the bucket is and how fast it
                fills up. The bucket will start up empty.
            - sleepfunc: the function to use for sleeping. Defaults to
                time.sleep, but you may want e.g. gevent.sleep.
            - timefunc: the function to measure the passing of time. It defaults
                to time.time, but any other function that returns float numbers
                is acceptable. That way you cannot just implement rate of
                tokens per time, but also tokens per something else.
            - prefill: The amount of tokens that are initially in the bucket.
        """
        self.bucketsize = int(bucketsize)
        if self.bucketsize < 1:
            raise ValueError("Invalid bucketsize: '%s'" % self.bucketsize)
        self._rate = float(rate)
        if self._rate <= 0.0:
            raise ValueError("Invalid rate: '%s'" % self._rate)
        if prefill > bucketsize or prefill < 0:
            raise ValueError("Invalid prefill parameter: '%s'" % prefill)

        # Set timefunc and sleepfunc. Only import the "time" module if we
        # have to.
        if sleepfunc is None:
            import time
            self.sleepfunc = time.sleep
        else:
            self.sleepfunc = sleepfunc
        assert(callable(self.sleepfunc))
        if timefunc is None:
            import time
            self.timefunc = time.time
        else:
            self.timefunc = timefunc
        assert(callable(self.timefunc))

        self._last_ts = self.timefunc()
        self.tokens = int(prefill)
        # To keep track of 'fractions' of a token
        self._leftovers = 0.0

    def _sleep(self, duration):
        """Try to sleep for $duration seconds
            This may get interrupted, e.g. by a signal. In this case we'd sleep
            shorter, but will not raise an exception.
        """
        try:
            self.sleepfunc(duration)
        except Exception:
            pass

    def _add_tokens(self):
        """Adds new tokens, depending on the time that has passed.
            Only for internal use! Reason is that it is NOT marked
            as threadsafe in the ThreadsafeTokenbucket, instead it
            relies on the caller to ensure this.
        """
        now_ts = self.timefunc()
        # $delta could be negative if someone played with the system
        # clock, e.g. the admin or the ntp daemon.
        delta = max(now_ts - self._last_ts, 0.0)
        self._last_ts = now_ts

        num_new_float = delta * self._rate + self._leftovers

        num_new = int(num_new_float)
        self._leftovers = num_new_float - num_new

        # Enforce bucketsize. But even if the bucket is full, we keep
        # our self._leftovers.
        self.tokens = min(self.bucketsize, self.tokens + num_new)

    def wait_for_tokens(self, amount):
        """Waits long enough so that $amount tokens will be available.
            If this amount is already available, does nothing.
        """
        if amount > self.bucketsize:
            raise ValueError("You want more tokens than the bucket can hold")

        # You wonder why the code is in a loop? Because whatever syscall is
        # used by self._sleep() might get interrupted by a signal, See
        # nanosleep(2) for an example.
        while self.tokens < amount:
            self._sleep((amount - self.tokens - self._leftovers) / self._rate)
            # The OS guarantees that we sleep at least the given amount of time,
            # but it could have been significantly longer. So better not do
            #       self.tokens += amount
            # but a proper calculation
            self._add_tokens()

    # In ThreadsafeTokenbucket, this one remains unprotected to improve speed.
    _wait_for_tokens = wait_for_tokens

    def take_token(self):
        """Takes one token out of the bucket.
            Triggers a recalculation of available tokens. Will wait using
            self._sleepfunc if no token is available.
        """
        self._add_tokens()
        if self.tokens:
            self.tokens -= 1
            return

        self._wait_for_tokens(1)
        assert(self.tokens) >= 1
        self.tokens -= 1

    def take_tokens(self, amount):
        """Takes $amount tokens out of the bucket.
            Triggers a recalculation of available tokens. Will wait using
            self._sleepfunc if not enough tokens are available.
        """
        self._add_tokens()
        if self.tokens < amount:
            self._wait_for_tokens(amount)
        assert(self.tokens >= amount)
        self.tokens -= amount

    def try_take_tokens(self, amount):
        """Tries to take $amount tokens from the bucket without waiting.
            Returns True if tokens were successfully taken, else False.
            This is useful in multithreaded environments where you do not
            want a race condition between get_num_tokens() and take_tokens().
            Or to make your code shorter.
        """
        self._add_tokens()
        if self.tokens >= amount:
            self.tokens -= amount
            return True
        else:
            return False

    def get_num_tokens(self):
        """Returns the number of tokens that are currently in the bucket
            In contrast to reading self.tokens, this will also recalculate
            the number of tokens based on the current time.
        """
        self._add_tokens()
        return self.tokens


class ThreadsafeTokenbucket(Tokenbucket):
    """A Tokenbucket that can be used by multiple threads in parallel.
        Performance is roughly 280k take_token() operations per second
        with "python -OO". Of course assuming that the rate is very high.
    """

    def __init__(
            self,
            bucketsize,
            rate,
            sleepfunc=None,
            timefunc=None,
            prefill=0, lock_class=None):

        super(ThreadsafeTokenbucket, self).__init__(
                bucketsize, rate, sleepfunc, timefunc, prefill)

        # We do not need a recursive lock, since functions do not call each
        # other. In cases where they do, there is an unprotected _foo() for
        # internal use and a protected foo() for external use. Allow people
        # to provide their own Lock, e.g. if "threading" cannot beimported.
        if lock_class is None:
            from threading import Lock
            self._lock_class = Lock
        else:
            self._lock_class = lock_class
        # It must be called "lock" because the decorator expects it.
        self.lock = self._lock_class()

    # _add_tokens is NOT threadsafe to get more speed. That gives
    # almost 40% more performance for take_token() because we save
    # the lock->try->call->finally->unlock that is expensive.
    wait_for_tokens = thread_proxy.thread_safe_call(Tokenbucket.wait_for_tokens)
    take_token = thread_proxy.thread_safe_call(Tokenbucket.take_token)
    take_tokens = thread_proxy.thread_safe_call(Tokenbucket.take_tokens)
    get_num_tokens = thread_proxy.thread_safe_call(Tokenbucket.get_num_tokens)

    def try_take_tokens(self, amount):
        """Tries to take $amount tokens from the bucket without waiting.
            Returns True if tokens were successfully taken, else False.
            This is useful in multithreaded environments where you do not
            want a race condition between get_num_tokens() and take_tokens().
            Or to make your code shorter.
            If "False" is returned, it does not necessarily mean there are no
            tokens in the bucket. It can also mean that the bucket's lock
            could not be acquired without blocking.
        """
        if not self.lock.acquire(False):
            return False
        try:
            self._add_tokens()
            if self.tokens >= amount:
                self.tokens -= amount
                return True
            else:
                return False
        finally:
            self.lock.release()

"""Section to supply a threadsafe function-call ratelimit. Use it like this:


from ax.utils.tokenbucket import ratelimit

@ratelimit(2, 20, policy="wait")
def foo():
    print "hello world"

for x in xrange(0, 30)
    foo()


This makes foo() be callable 2 times per second with a 20 call burst. If the
rate is exceeded, it waits to slow you down. This also works with methods on
objects and is thread-safe.
"""


class RatelimitError(Exception):
    """Raised by [Rr]atelimit for policy="raise" when no token is available"""
    pass


class Ratelimit(object):
    """A helper object used by the "ratelimit" function.
        It basically holds a (threadsafe) Tokenbucket and enforces the policy.
    """
    def __init__(
            self,
            rate,
            burst,
            policy,
            bucket_class=ThreadsafeTokenbucket,
            sleepfunc=None,
            timefunc=None,
            prefill=None):
        """
            $bucket_class: The class to use as token bucket. Usually you want
                ThreadsafeTokenbucket or Tokenbucket.
        """
        # The function we a decorating
        self._func = None
        # A tokenbucket to limit the calls
        if prefill is None:
            # rate may be float, so enforce integer
            prefill = int(min(burst, rate))

        self._tb = bucket_class(
            burst,
            rate,
            sleepfunc=sleepfunc,
            timefunc=timefunc,
            prefill=prefill)

        # $policy is our policy if there are no tokens. We translate it here
        # and set self.enforce according to it. The self.enforce() call returns
        # 1 if the ratelimit allows making the call. It will also wait if
        # needed (and the policy says so).
        if policy == "wait":
            self.enforce = self.token_or_wait
        elif policy == "drop":
            self.enforce = self.token_or_drop
        elif policy == "raise":
            self.enforce = self.token_or_raise
        else:
            msg = "Policy '%s' is invalid. Use 'drop' or 'wait'."
            raise ValueError(msg % policy)

    def token_or_drop(self):
        """Return 1 if a token can be taken right now, else return 0."""
        return 1 if self._tb.try_take_tokens(1) else 0

    def token_or_raise(self):
        """Return 1 if a token can be taken right now, else raise an Exception

        The exception raised is always an instance of RatelimitError
        """
        if self._tb.try_take_tokens(1):
            return 1
        else:
            raise RatelimitError("Ratelimit is exceeded")

    def token_or_wait(self):
        """Always return 1, wait for available token if needed"""
        self._tb.take_token()
        return 1

# The "wraps" decorator makes our @ratelimit decorator 'more transparent'.
# E.g. the __docs__ is preserved after decorating. Only for Python 2.5 and
# above, use a dummy if we do not have it.
try:
    from functools import wraps
except ImportError:
    # Python 2.4, create a dummy decorator that does nothing.
    wraps = lambda x: lambda y: y


# The ratelimit() function can be used as a decorator. Since it is a decorator
# with parameters and an internal state (the token bucket), we need to nest
# two times. Google for "closure" to know what is going on here. Also, check
# out PEP 318, especially the "Current Syntax" section which explains how
# decorators with parameters work.
# Performance is roughly 125k calls per second (140k with "python -OO") to a
# function that does nothing. Of course assuming the rate is very high.
def ratelimit(
        rate,
        burst=None,
        policy=None,
        bucket_class=ThreadsafeTokenbucket,
        prefill=None):
    """Return a function that acts as ratelimiting wrapper for another function

    rate: The allowed calls per second. If rate is None, no ratelimiting
        is done.
    burst: Max. burst that may occur. Translates to the TokenBucket's size.
        Defaults to 1 if not given
    policy: What to do if no token is available. Either "wait", "drop", or
        "raise", defaults to "wait" if not given. Using "raise" will produce
        a tokenbucket.RatelimitError exception.
    bucket_class: What class to use as Tokenbucket implementation
    """
    if rate is None:
        # Special case when no rate limiting is wanted. Produce a decorator
        # that returns the original function.
        def factory(function):
            return function
    else:
        burst = burst or 1
        policy = policy or "wait"
        limit = Ratelimit(
            rate,
            burst,
            policy,
            bucket_class=bucket_class,
            prefill=prefill)

        def factory(function):
            @wraps(function)
            def real_function(*args, **kwargs):
                if limit.enforce():
                    return function(*args, **kwargs)
                else:
                    # happens if policy is drop and we are out of tokens
                    return None
            return real_function
    return factory


class LoggerRatelimit(Ratelimit):
    """A rate-limiting filter object for the builtin "logging" module.
        Filter objects must have a filter() method, which returns 0 if the
        given record should not be logged, else nonzero. This is exactly what
        self.enforce() does, anyway.
    """
    def filter(self, log_entry):
        return self.enforce()


def log_limit(
        logger,
        rate,
        burst=None,
        policy="drop",
        bucket_class=ThreadsafeTokenbucket,
        sleepfunc=None,
        timefunc=None,
        prefill=None):
    """Allow $logger to only log at a certain rate.
        $logger must be an object as returned by logging.getLogger(). If the
        rate is exceeded, log entries will silently be dropped. The limit does
        not(!) count messages that were filtered out before, e.g. if they are
        not important enough for the logger's log level.
    """
    if burst is None:
        burst = rate

    new_filter = LoggerRatelimit(
        rate,
        burst,
        policy,
        bucket_class=bucket_class,
        sleepfunc=sleepfunc,
        timefunc=timefunc,
        prefill=prefill)

    logger.addFilter(new_filter)


class RedisTokenBucket(object):
    tk_src_fn = os.path.join(
        ax.utils.package_home(globals()),
        'token_bucket.lua')

    def __init__(self, redis_host, redis_port, db=0, password=None):
        """Token bucket implementation in redis. The storage format is a given
        key and a 2 item list like [<# of tokens>, <last timestamp>].
        Requires a redis-server instance >= 2.6 due to the TIME and SCRIPT
        commands"""
        self.conn = self._get_redis_conn(redis_host, redis_port, db, password)
        self._tb = self._register_tk(self.conn)

    def _get_redis_conn(self, host, port, db=0, password=None):
        return StrictRedis(host=host, port=port, db=db, password=password)

    @classmethod
    def _register_tk(cls, redis_conn):
        with open(cls.tk_src_fn) as fd:
            tpl = fd.read().strip()

        # register the lua script at the redis server.
        return redis_conn.register_script(tpl)

    @classmethod
    def _get_ts(cls, redis_conn):
        # we have to ask redis for the server time seperately
        # because redis does not allow the method TIME to run atomically
        epoch, micro = redis_conn.time()
        return (epoch * 1000) + (micro / 1000)

    @classmethod
    def delete_token(cls, redis_conn, key):
        """
        method to delete a key just for managing the lifecycle of redis
        """
        redis_conn.delete(key)

    def try_take_tokens(self, key, amount, rate, burst=1):
        """the amount is the same like the other tb implementations above.
        the rate and burst options are more dynamic so that the same instance
        of the token bucket can be used for different redis keys with different
        settings. The key is added to choose on which redis key the token bucket
        will be saved."""
        try:
            return self._tb(
                keys=[key],
                args=[amount, rate, burst, self._get_ts(self.conn)])
        except Exception:
            return 0

    @classmethod
    def try_take_tokens_dyn_conn(cls, redis_conn, key, amount, rate, burst=1):
        """This is the same as try_take_tokens but it works without an instance
        of the class. It requires a redis connection though. It exists because
        then the token bucket can be easily be used from ZODB objects"""
        _tb = cls._register_tk(redis_conn)
        try:
            return _tb(
                keys=[key],
                args=[amount, rate, burst, cls._get_ts(redis_conn)])
        except Exception:
            return 0

class MySQLTokenBucket(object):
    table_name = 'TokenBucket'
    table_created = False
    mysql_version = None

    def __init__(self, engine):
        """Token bucket implementation in MySQL"""
        self.engine = engine
        self._create_table(engine)
        self._get_mysql_version(engine)

    @classmethod
    def _get_mysql_version(cls, engine):
        if not cls.mysql_version:
            sql = "SELECT VERSION()"
            res = engine.execute(sql)
            cls.mysql_version = res.fetchone()[0]

    @classmethod
    def _create_table(cls, engine):
        if not cls.table_created:
            sql = """CREATE TABLE IF NOT EXISTS `%s` (
                `id` varchar(255) NOT NULL DEFAULT '',
                `ts` bigint(11) NOT NULL,
                `tokens` float unsigned NOT NULL,
                PRIMARY KEY (`id`)
                ) ENGINE=MEMORY DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci""" % cls.table_name
            engine.execute(sql)
            cls.table_created = True

    @classmethod
    def _do_token_bucket(cls, engine, key, amount, rate, burst):
        # Fill the bucket
        # We do not do INSERT ... ON DUPLICATE KEY UPDATE cause of the unit tests
        if cls.mysql_version.startswith('5.5'):
            # MySQL versions < 5.6 do not support subsecond precision in the
            # CURTIME method so we will use the server time hoping that
            # NTP works well
            now_ts = int(time.time() * 1000)
            sql = "UPDATE %s SET tokens=LEAST(%%s, tokens + GREATEST(0, (%%s - ts) / 1000) * %%s), "\
                "ts=%%s WHERE id=%%s" % cls.table_name
            values = (burst, now_ts, rate, now_ts, key)
            res = engine.execute(sql, values)
            if res.rowcount == 0:
                sql = "INSERT INTO %s (tokens, ts, id) VALUES "\
                    "(LEAST(%%s, %%s), %%s, %%s)" % cls.table_name
                values = (burst, rate, now_ts, key)
                try:
                    res = engine.execute(sql, values)
                except Exception, e:
                    # some other process inserted so no need to do anything
                    pass
        else:
            sql = "UPDATE %s SET tokens=LEAST(%%s, tokens + "\
                "GREATEST(0, (ROUND(UNIX_TIMESTAMP(CURTIME(4)) * 1000) - ts)/ 1000) * %%s), "\
                "ts=ROUND(UNIX_TIMESTAMP(CURTIME(4)) * 1000) WHERE id=%%s" % cls.table_name
            values = (burst, rate, key)
            res = engine.execute(sql, values)
            if res.rowcount == 0:
                sql = "INSERT INTO %s (tokens, ts, id) VALUES "\
                    "(LEAST(%%s, %%s), ROUND(UNIX_TIMESTAMP(CURTIME(4)) * 1000), %%s) "%\
                    cls.table_name
                values = (burst, rate, key)
                try:
                    res = engine.execute(sql, values)
                except Exception, e:
                    # some other process inserted so no need to do anything
                    pass

        # Take tokens
        sql = "UPDATE %s SET tokens=tokens-%%s WHERE tokens >= %%s AND id=%%s"%\
                cls.table_name
        res = engine.execute(sql, (amount, amount, key))
        if res.rowcount:
            return 1
        else:
            return 0

    @classmethod
    def delete_token(cls, engine, key):
        """
        method to delete a row just for managing the lifecycle of the rows
        """
        sql = "DELETE FROM %s WHERE id=%%s" % cls.table_name
        engine.execute(sql, (key,))

    def try_take_tokens(self, key, amount, rate, burst=1):
        """the amount is the same like the other tb implementations above.
        the rate and burst options are more dynamic so that the same instance
        of the token bucket can be used for different keys with different
        settings. The key is added to choose on which row the token bucket
        will be saved."""
        try:
            return self._do_token_bucket(self.engine, key, amount, rate, burst)
        except Exception, e:
            return 0

    @classmethod
    def try_take_tokens_dyn_engine(cls, engine, key, amount, rate, burst=1):
        """This is the same as try_take_tokens but it works without an instance
        of the class. It exists because then the token bucket can be easily be
        used from ZODB objects"""
        cls._create_table(engine)
        cls._get_mysql_version(engine)
        try:
            return cls._do_token_bucket(engine, key, amount, rate, burst)
        except Exception, e:
            return 0

