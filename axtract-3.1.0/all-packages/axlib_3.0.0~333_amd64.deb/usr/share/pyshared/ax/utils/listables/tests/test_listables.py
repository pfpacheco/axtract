import os
import time
import unittest2

from sqlalchemy import create_engine

from schema import ListablesTestSchema
from ax.utils.listables import get_listables
from ax.utils.listables import SqlListable

"""
Test data:

    enterprise1
        |
        +-- operator1
                |
                +-- user1
                |     |
                |     +-- Z1
                |     |
                |     +-- Z4
                |         |
                +-- user2 +
                      |
                      + --Z3
"""

# MySQL engine
DB_NAME = os.getenv('DB_NAME', 'test')
DB_USER = os.getenv('DB_USER','ax')
DB_PWD = os.getenv('DB_PWD', 'ax')
DB_HOST = os.getenv('DB_HOST', '127.0.0.1')
DB_PORT = os.getenv('DB_PORT', 3306)
url = 'mysql://%s:%s@%s:%s/%s' %  (
        DB_USER,
        DB_PWD,
        DB_HOST,
        DB_PORT,
        DB_NAME)
engine = create_engine(url, echo=False)


def build_query(query_map):
    query_params =  query_map.get('filter_params', [])
    sql_query = ' '.join(query_map['full_query'])
    sql_query = sql_query.replace('?', '%s')

    return sql_query % tuple(query_params)


# New schema for listables
class IoTSchema(ListablesTestSchema):
    def register_with_listables(self, listables):
        super(IoTSchema, self).register_with_listables(listables)
        listables.register_listable(self.SmartDevice)
        #listables.register_listable(self.UserSmartDeviceRelation)

    class SmartDevice(SqlListable):
        table = 'vss_SmartDevice'
        primary_id = 'deviceid'
        master_params = ['deviceid', 'device_name', 'operatorid']
        parent_types = [{'type': 'Operator', 'on': ('operatorid', 'account_name')}]


def prepare_data():
    # Add CPEs
    engine.execute("INSERT INTO CPEManager_CPEs("
                   "cid, cid2, cpeid, cpetype, path, version, IP, "
                   "unmanagedProps, pendingProps, props, scProps, "
                   "events, methods, comments, roles) "
                   "VALUES('', 'operator1', 'ZZ0000000001', 'genericTR69', '',"
                   "'version1__HardwareVersion1__1.011', '10.0.0.135', '[]',"
                   "'{}','{}','{}','[]','','','unsupportedFW')")
    engine.execute("INSERT INTO CPEManager_CPEs("
                   "cid, cid2, cpeid, cpetype, path, version, IP, "
                   "unmanagedProps, pendingProps, props, scProps, "
                   "events, methods, comments, roles) "
                   "VALUES('', '', 'ZZ0000000002', 'genericTR69', '',"
                   "'version2__HardwareVersion2__2.022', '10.0.0.137', '[]',"
                   "'{}','{}','{}','[]','','','unsupportedFW')")
    engine.execute("INSERT INTO CPEManager_CPEs("
                   "cid, cid2, cpeid, cpetype, path, version, IP, "
                   "unmanagedProps, pendingProps, props, scProps, "
                   "events, methods, comments, roles) "
                   "VALUES('', 'operator1', 'ZZ0000000003', 'genericTR69', '',"
                   "'version1__HardwareVersion1__1.011', '10.0.0.136', '[]',"
                   "'{}','{}','{}','[]','','','unsupportedFW')")
    engine.execute("INSERT INTO CPEManager_CPEs("
                   "cid, cid2, cpeid, cpetype, path, version, IP, "
                   "unmanagedProps, pendingProps, props, scProps, "
                   "events, methods, comments, roles) "
                   "VALUES('', 'operator1', 'ZZ0000000004', 'genericTR69', '',"
                   "'version1__HardwareVersion1__1.011', '10.0.0.138', '[]',"
                   "'{}','{}','{}','[]','','','unsupportedFW')")

    # Add enterprise
    engine.execute("INSERT INTO vss_ENTERPRISE("
                   "servicetype, comments, props, account_name, account_role, "
                   "account_parent) "
                   "VALUES('ENTERPRISE', '', '{}', 'enterprise1', "
                   "'enterprise', '')")

    # Add operators
    engine.execute("INSERT INTO vss_OPERATOR("
                   "servicetype, comments, props, account_name, account_role, "
                   "account_parent) "
                   "VALUES('OPERATOR', '', '{}', 'operator1', "
                   "'operator', 'enterprise1')")

    # Add users
    engine.execute("INSERT INTO vss_USER("
                   "servicetype, comments, props, account_name, account_role, "
                   "account_parent) "
                   "VALUES('USER', '', '{}', 'user1', "
                   "'user', 'operator1')")
    engine.execute("INSERT INTO vss_USER("
                   "servicetype, comments, props, account_name, account_role, "
                   "account_parent) "
                   "VALUES('USER', '', '{}', 'user2', "
                   "'user', 'operator1')")

    # Add user-cpe relations
    engine.execute("INSERT INTO vss_USER_CPE_RELATION("
                   "servicetype, comments, props, cpeid, sip_url, userid) "
                   "VALUES('USER_CPE_RELATION', '', '{}', 'ZZ0000000001', "
                   "'sip:user1@ZZ0000000001', 'user1')")
    engine.execute("INSERT INTO vss_USER_CPE_RELATION("
                   "servicetype, comments, props, cpeid, sip_url, userid) "
                   "VALUES('USER_CPE_RELATION', '', '{}', 'ZZ0000000004', "
                   "'sip:user1@ZZ0000000004', 'user1')")
    engine.execute("INSERT INTO vss_USER_CPE_RELATION("
                   "servicetype, comments, props, cpeid, sip_url, userid) "
                   "VALUES('USER_CPE_RELATION', '', '{}', 'ZZ0000000003', "
                   "'sip:user2@ZZ0000000003', 'user2')")
    engine.execute("INSERT INTO vss_USER_CPE_RELATION("
                   "servicetype, comments, props, cpeid, sip_url, userid) "
                   "VALUES('USER_CPE_RELATION', '', '{}', 'ZZ0000000004', "
                   "'sip:user2@ZZ0000000004', 'user2')")

    # Add smart device
    engine.execute("INSERT INTO vss_SmartDevice("
                   "servicetype, comments, props, deviceid, device_name, "
                   "operatorid) "
                   "VALUES('SmartDevice', '', '{}', 'device1', "
                   "'smart_device_1', 'operator1')")
    engine.execute("INSERT INTO vss_SmartDevice("
                   "servicetype, comments, props, deviceid, device_name, "
                   "operatorid) "
                   "VALUES('SmartDevice', '', '{}', 'device2', "
                   "'smart_device_2', 'operator1')")

def cleanup_data():
    # Delete CPEs
    engine.execute("DELETE FROM CPEManager_CPEs WHERE cpeid IN "
                   "('ZZ0000000001',"
                   "'ZZ0000000002',"
                   "'ZZ0000000003',"
                   "'ZZ0000000004',"
                   "'ZZ0000000005',"
                   "'ZZ0000000006')")

    # Delete enterprise
    engine.execute("DELETE FROM vss_ENTERPRISE WHERE account_name IN "
                   "('enterprise1')")

    # Delete operator
    engine.execute("DELETE FROM vss_OPERATOR WHERE account_name IN "
                   "('operator1')")

    # Delete user
    engine.execute("DELETE FROM vss_USER WHERE account_name IN "
                   "('user1', 'user2')")

   # Delete user-cpe relation
    engine.execute("DELETE FROM vss_USER_CPE_RELATION WHERE cpeid IN "
                   "('ZZ0000000001', "
                   "'ZZ0000000002', "
                   "'ZZ0000000003', "
                   "'ZZ0000000004')")

    # Delete smart devices
    engine.execute("DELETE FROM vss_SmartDevice WHERE deviceid IN "
                   "('device1', 'device2')")

class TestAXListablesDefaultSchema(unittest2.TestCase):

    def setUp(self):
        self.listables = get_listables(ListablesTestSchema, engine)
        prepare_data()

    def tearDown(self):
        cleanup_data()

    def test_query_simple_filter(self):
        lt = self.listables['Enterprise']
        q_map = lt.realize_filters(
            [['Enterprise', '=', 'enterprise1']],
            None)
        lt.realize_meta(q_map, {
            'limit': 10, 'offset': 0,
            'show': ['kv', 'cpe', 'cpe.cid2', 'cpe.version'],
            'sort': ['cpe.cpeid']})
        data = lt.get_data(q_map, engine, limit=None)
        self.assertEqual(len(data), 3)
        self.assertEqual(data[0][0], 'ZZ0000000001')
        self.assertEqual(data[1][0], 'ZZ0000000003')
        self.assertEqual(data[2][0], 'ZZ0000000004')
        data = self.listables.post_process(data, q_map, engine)
        self.assertEqual(len(data), 3)
        self.assertEqual(data[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(data[0]['cpe.cid2'], 'operator1')
        self.assertEqual(data[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(data[1]['cpe.cid2'], 'operator1')
        self.assertEqual(data[2]['cpe.cpeid'], 'ZZ0000000004')
        self.assertEqual(data[2]['cpe.cid2'], 'operator1')
        count = lt.get_count(q_map, engine)
        self.assertEqual(count, 3)

    def test_query_no_filter(self):
        query_map = self.listables.create_query_map()
        lt = self.listables['cpe']

        lt.set_resultset(
            query_map,
            ['kv', 'cpeid'])

        self.assertEqual(
            build_query(query_map),
            ' '.join(['SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE', '1 = 1']))

        lt.set_filters(
            query_map,
            path_filters=['and', ['User.account_name', '=', 'user1']])
        self.assertEqual(
            build_query(query_map),
            ' '.join(['SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_USER_CPE_RELATION AS `UserCPERelation`',
                'ON cpe.cpeid = UserCPERelation.cpeid',
                'INNER JOIN vss_USER AS `User`',
                'ON UserCPERelation.userid = User.account_name',
                'WHERE', 'User.account_name = user1']))

        lt.set_filters(
                query_map,
                [
                    ['cpe.cpetype', '=', 'genericTR69'],
                    'or',
                    ['cpe.version', '=', '42.0']
                ],
                ['and', ['User.account_name', '=', 'user1']])

        realized_filters = lt.get_realized_filters(query_map)
        self.assertEqual('((cpe.cpetype = genericTR69 or cpe.version = 42.0) '
                         'and User.account_name = user1)',
                         realized_filters[0].replace('?', '%s') % realized_filters[1])

        self.assertEqual(
            build_query(query_map),
            ' '.join(['SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_USER_CPE_RELATION AS `UserCPERelation`',
                'ON cpe.cpeid = UserCPERelation.cpeid',
                'INNER JOIN vss_USER AS `User`',
                'ON UserCPERelation.userid = User.account_name',
                'WHERE',
                '((cpe.cpetype = genericTR69 or cpe.version = 42.0) '
                'and User.account_name = user1)']))

    def test_query_nested_filter(self):
        lt = self.listables['User']
        q_map = lt.realize_filters(
        [
            [
                ['cpe.cpetype', '=', 'genericTR69'],
                'and',
                ['cpe.roles', '=', '%(role)s']
            ],
            'or',
            ['cpe.cpeid', '=', '%(cpeid)s']
        ],
        None)
        lt.realize_meta(q_map, {
            'show': ['kv', 'User.account_name', 'UserCPERelation.sip_url'],
            'sort': ['User.account_name', 'UserCPERelation.sip_url']})
        with self.assertRaises(ValueError) as context:
            data = lt.get_data(
                q_map,
                engine,
                lazy_filter={
                    'role': 'unsupportedFW'})
        self.assertTrue("Cannot resolve query filter: Key 'cpeid' not found",
                        str(context.exception))
        data = lt.get_data(
            q_map,
            engine,
            lazy_filter={
                'role': 'unsupportedFW','cpeid': 'cpe1'})
        self.assertEqual(len(data), 4)
        self.assertEqual(data[0][0], 'user1')
        self.assertEqual(data[1][0], 'user1')
        self.assertEqual(data[2][0], 'user2')
        self.assertEqual(data[3][0], 'user2')
        data = self.listables.post_process(data, q_map, engine)
        self.assertEqual(len(data), 4)
        self.assertEqual(data[0]['User.account_name'], 'user1')
        self.assertEqual(data[0]['UserCPERelation.sip_url'], 'sip:user1@ZZ0000000001')
        self.assertEqual(data[1]['User.account_name'], 'user1')
        self.assertEqual(data[1]['UserCPERelation.sip_url'], 'sip:user1@ZZ0000000004')
        self.assertEqual(data[2]['User.account_name'], 'user2')
        self.assertEqual(data[2]['UserCPERelation.sip_url'], 'sip:user2@ZZ0000000003')
        self.assertEqual(data[3]['User.account_name'], 'user2')
        self.assertEqual(data[3]['UserCPERelation.sip_url'], 'sip:user2@ZZ0000000004')

    def test_default_resultset(self):
        lt = self.listables['cpe']
        query_map = self.listables.create_query_map()
        lt.set_filters(query_map, ['cpe.cpeid', '=', '%(cpeid)s'])
        self.assertEqual(1, lt.get_count(query_map,
                                         engine,
                                         lazy_filter={'cpeid': 'ZZ0000000001'}))
        data = lt.get_data(query_map, engine, lazy_filter={'cpeid': 'ZZ0000000001'})
        self.assertEqual(len(data), 1)
        self.assertEqual(data[0][0], 'ZZ0000000001')
        self.assertEqual(data[0][1], 'version1__HardwareVersion1__1.011')
        self.assertEqual(data[0][2], '')
        self.assertEqual(data[0][3], 'operator1')

    def test_key_expansion(self):
        lt = self.listables['cpe']
        query_map = self.listables.create_query_map()
        lt.set_filters(
            query_map,
            [
                ['cpe', '=', '%(cpeid)s'],
                'and',
                ['Enterprise', '=', 'enterprise1']
            ])
        lt.set_resultset(query_map, ['cpe', 'Enterprise'])
        data = lt.get_data(
            query_map,
            engine,
            lazy_filter = {'cpeid': 'ZZ0000000001'})
        data = self.listables.post_process(data, query_map, engine)
        self.assertEqual(len(data), 1)
        self.assertEqual(data[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(data[0]['Enterprise.account_name'], 'enterprise1')

    def test_condition_none(self):
        lt = self.listables['cpe']
        query_map = self.listables.create_query_map()
        lt.set_filters(
            query_map,
            [
                ['cpe.cpetype', '!=', None],
                'and',
                ['cpe.roles', '=', None]
            ])
        lt.set_resultset(query_map, ['cpe.cpeid'])
        # SQL Alchemy automatically takes case of Python None
        self.assertEqual(
            build_query(query_map),
            ' '.join(['SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE', '(cpe.cpetype is not None and cpe.roles is None)']))

    def test_coount_with_group_by(self):
        lt = self.listables['cpe']
        query_map = self.listables.create_query_map()
        lt.set_filters(query_map, ['cpe.cpetype', '=', 'genericTR69'])
        lt.set_query_options(query_map, sort=[('cpe.version', 'asc')])
        res = lt.get_count(query_map, engine, group_by=['version'])
        self.assertEqual(res[0][0], 3)
        self.assertEqual(res[0][1], 'version1__HardwareVersion1__1.011')
        self.assertEqual(res[1][0], 1)
        self.assertEqual(res[1][1], 'version2__HardwareVersion2__2.022')


class TestAXListablesNewSchema(unittest2.TestCase):

    def setUp(self):
        self.listables = get_listables(IoTSchema, engine)
        prepare_data()

    def tearDown(self):
        cleanup_data()

    def test_query(self):
        lt = self.listables['Operator']
        q_map = lt.realize_filters(
            [['account_name', '=', 'operator1']],
            None)
        lt.realize_meta(q_map, {
            'limit': 10, 'offset': 0,
            'show': ['kv', 'SmartDevice.deviceid', 'SmartDevice.device_name'],
            'sort': 'SmartDevice.deviceid'})
        data = lt.get_data(q_map, engine, limit=None)
        self.assertEqual(len(data), 2)
        self.assertEqual(data[0][0], 'device1')
        self.assertEqual(data[1][0], 'device2')
        data = self.listables.post_process(data, q_map, engine)
        self.assertEqual(len(data), 2)
        self.assertEqual(data[0]['SmartDevice.deviceid'], 'device1')
        self.assertEqual(data[0]['SmartDevice.device_name'], 'smart_device_1')
        self.assertEqual(data[1]['SmartDevice.deviceid'], 'device2')
        self.assertEqual(data[1]['SmartDevice.device_name'], 'smart_device_2')

class TestAXListablesSetFunctions(unittest2.TestCase):

    def setUp(self):
        self.listables = get_listables(ListablesTestSchema, engine)
        prepare_data()

    def tearDown(self):
        cleanup_data()

    def test_set_path_filter(self):
        query_map = self.listables.create_query_map()
        lt = self.listables['cpe']

        lt.set_filters(
                query_map,
                [
                    ['cpe.cpetype', '=', 'genericTR69'],
                    'or',
                    ['cpe.version', '=', '42.0']
                ],
                ['and', ['User.account_name', '=', 'user1']])

        self.assertEqual(
            query_map['realized_filters'].replace(
                '?', '%s') % tuple(query_map['filter_params']),
            '((cpe.cpetype = genericTR69 or cpe.version = 42.0) and ' \
                    'User.account_name = user1)')
        self.assertEqual(len(query_map['filter_tables']), 2)
        self.assertTrue('cpe' in query_map['filter_tables'])
        self.assertTrue('User' in query_map['filter_tables'])
        self.assertEqual(
            build_query(query_map),
            ' '.join(['SELECT', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_USER_CPE_RELATION AS `UserCPERelation`',
                'ON cpe.cpeid = UserCPERelation.cpeid',
                'INNER JOIN vss_USER AS `User`',
                'ON UserCPERelation.userid = User.account_name', 'WHERE',
                '((cpe.cpetype = genericTR69 or cpe.version = 42.0) and ' \
                        'User.account_name = user1)']))

    def test_filter_operators(self):
        query_map = self.listables.create_query_map()
        lt = self.listables['cpe']

        lt.set_filters(
                query_map,
                [
                    ['cpe.cpetype', '!=', 'genericTR69'],
                    'and',
                    ['cpe.pii', '>=', 30],
                    'and',
                    ['cpe.version', 'not like', '42.*']
                ],
                ['or', ['cpe.state', 'not in', [5, 10]]])
        self.assertEqual(
            query_map['realized_filters'].replace(
                '?', '%s') % tuple(query_map['filter_params']),
            '((cpe.cpetype != genericTR69 and (cpe.pii >= 30 and cpe.version not like 42.%%)) ' \
            'or cpe.state not in (5,10))')
        self.assertEqual(len(query_map['filter_tables']), 1)
        self.assertTrue('cpe' in query_map['filter_tables'])
        self.assertEqual(
            build_query(query_map),
            ' '.join(['SELECT', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE',
                      '((cpe.cpetype != genericTR69 and (cpe.pii >= 30 and cpe.version not like 42.%%)) ' \
                'or cpe.state not in (5,10))']))

    def test_set_and_update_filter(self):
        query_map = self.listables.create_query_map()
        lt = self.listables['cpe']

        lt.set_filters(
                query_map,
                [
                    ['cpe.cpetype', '=', 'genericTR69'],
                    'and',
                    ['User.account_name', '=', 'user1']
                ],
                None)

        self.assertEqual(
            query_map['realized_filters'].replace(
                '?', '%s') % tuple(query_map['filter_params']),
            '(cpe.cpetype = genericTR69 and User.account_name = user1)')
        self.assertEqual(len(query_map['filter_tables']), 2)
        self.assertTrue('cpe' in query_map['filter_tables'])
        self.assertTrue('User' in query_map['filter_tables'])
        self.assertEqual(
            build_query(query_map),
            ' '.join(['SELECT', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_USER_CPE_RELATION AS `UserCPERelation`',
                'ON cpe.cpeid = UserCPERelation.cpeid',
                'INNER JOIN vss_USER AS `User`',
                'ON UserCPERelation.userid = User.account_name', 'WHERE',
                '(cpe.cpetype = genericTR69 and User.account_name = user1)']))

        lt.set_filters(
                query_map,
                ['cpe.cpetype', '=', 'genericTR69'],
                None)
        self.assertEqual(
            query_map['realized_filters'].replace(
                '?', '%s') % tuple(query_map['filter_params']),
            'cpe.cpetype = genericTR69')
        self.assertEqual(len(query_map['filter_tables']), 1)
        self.assertTrue('cpe' in query_map['filter_tables'])
        self.assertEqual(
            build_query(query_map),
            ' '.join(['SELECT', 'FROM', 'CPEManager_CPEs AS `cpe`', 'WHERE',
                'cpe.cpetype = genericTR69']))

        lt.set_filters(
                query_map,
                [
                    ['cpe.cpetype', '=', 'genericTR69'],
                    'or',
                    ['Operator.account_name', '=', 'operator1']
                ],
                None)

        self.assertEqual(
            query_map['realized_filters'].replace(
                '?', '%s') % tuple(query_map['filter_params']),
            '(cpe.cpetype = genericTR69 or Operator.account_name = operator1)')
        self.assertEqual(len(query_map['filter_tables']), 2)
        self.assertTrue('cpe' in query_map['filter_tables'])
        self.assertTrue('Operator' in query_map['filter_tables'])
        self.assertEqual(
            build_query(query_map),
            ' '.join(['SELECT', 'FROM','CPEManager_CPEs AS `cpe`',
                'INNER JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name',
                'WHERE',
                '(cpe.cpetype = genericTR69 or '
                      'Operator.account_name = operator1)']))

    def test_set_and_update_resultset(self):
        query_map = self.listables.create_query_map()
        lt = self.listables['User']

        lt.set_resultset(
            query_map,
            ['kv', 'User.account_na*', 'UserCPERelation.sip_url'])

        self.assertEqual(len(query_map['show']), 3)
        self.assertTrue('User.account_name' in query_map['show'])
        self.assertTrue('UserCPERelation.sip_url' in query_map['show'])
        self.assertEqual(len(query_map['resultset_tables']), 2)
        self.assertTrue('User' in query_map['resultset_tables'])
        self.assertTrue('UserCPERelation' in query_map['resultset_tables'])
        self.assertEqual(query_map['to_kv'], 'kv')
        self.assertEqual(
            build_query(query_map),
            ' '.join(['SELECT', 'User.account_name, User.account_namePending, '
                      'UserCPERelation.sip_url', 'FROM', 'vss_USER AS `User`',
                      'INNER JOIN vss_USER_CPE_RELATION AS `UserCPERelation`',
                      'ON User.account_name = UserCPERelation.userid', 'WHERE',
                      '1 = 1']))

        lt.set_resultset(
            query_map,
            ['UserCPERelation.sip_url', 'cpe.cpeid'])

        self.assertEqual(len(query_map['show']), 2)
        self.assertTrue('UserCPERelation.sip_url' in query_map['show'])
        self.assertTrue('cpe.cpeid' in query_map['show'])
        self.assertEqual(len(query_map['resultset_tables']), 2)
        self.assertTrue('UserCPERelation' in query_map['resultset_tables'])
        self.assertTrue('cpe' in query_map['resultset_tables'])
        self.assertEqual(query_map['to_kv'], 'kva')

        self.assertEqual(
            build_query(query_map),
            ' '.join(['SELECT', 'UserCPERelation.sip_url, cpe.cpeid', 'FROM',
                'vss_USER_CPE_RELATION AS `UserCPERelation`',
                'INNER JOIN CPEManager_CPEs AS `cpe`',
                'ON UserCPERelation.cpeid = cpe.cpeid', 'WHERE', '1 = 1']))

        lt.set_resultset(
            query_map,
            ['UserCPERelation.sip_url', 'cpe.cpeid', 'User.account_name'])

        self.assertEqual(len(query_map['show']), 3)
        self.assertTrue('UserCPERelation.sip_url' in query_map['show'])
        self.assertTrue('cpe.cpeid' in query_map['show'])
        self.assertTrue('User.account_name' in query_map['show'])
        self.assertEqual(len(query_map['resultset_tables']), 3)
        self.assertTrue('UserCPERelation' in query_map['resultset_tables'])
        self.assertTrue('cpe' in query_map['resultset_tables'])
        self.assertTrue('User' in query_map['resultset_tables'])
        self.assertEqual(query_map['to_kv'], 'kva')
        self.assertEqual(
            build_query(query_map),
            ' '.join(['SELECT', 'UserCPERelation.sip_url, cpe.cpeid, User.account_name',
                'FROM', 'vss_USER_CPE_RELATION AS `UserCPERelation`',
                'INNER JOIN CPEManager_CPEs AS `cpe`',
                'ON UserCPERelation.cpeid = cpe.cpeid',
                'INNER JOIN vss_USER AS `User`',
                'ON UserCPERelation.userid = User.account_name', 'WHERE', '1 = 1']))

    def test_set_and_update_query_options(self):
        query_map = self.listables.create_query_map()
        lt = self.listables['User']

        lt.set_query_options(
            query_map,
            sort=[('User.account_name', 'desc'), ('cpe.version', 'asc')])

        self.assertEqual(len(query_map['sort_tables']), 2)
        self.assertTrue('User' in query_map['sort_tables'])
        self.assertTrue('cpe' in query_map['sort_tables'])
        self.assertEqual(
                query_map['native_joins']['sql'],
                [['User', 'UserCPERelation'], ['UserCPERelation', 'cpe']])
        self.assertEqual(
            query_map['sort'],
            [('User.account_name', 'desc'), ('cpe.version', 'asc')])
        self.assertEqual(
            build_query(query_map),
            ' '.join(['SELECT', 'FROM', 'vss_USER AS `User`',
                'INNER JOIN vss_USER_CPE_RELATION AS `UserCPERelation`',
                'ON User.account_name = UserCPERelation.userid',
                'INNER JOIN CPEManager_CPEs AS `cpe`',
                'ON UserCPERelation.cpeid = cpe.cpeid',
                'WHERE', '1 = 1', 'ORDER BY', 'User.account_name desc, cpe.version asc']))

        lt.set_query_options(
            query_map,
            sort='User.account_role')

        self.assertEqual(len(query_map['sort_tables']), 1)
        self.assertTrue('User' in query_map['sort_tables'])
        self.assertEqual(
            query_map['sort'],
            [('User.account_role', 'asc')])
        self.assertEqual(
            build_query(query_map),
            ' '.join(['SELECT', 'FROM', 'vss_USER AS `User`',
                'WHERE', '1 = 1', 'ORDER BY', 'User.account_role asc']))

        lt.set_query_options(
            query_map,
            sort=[('Enterprise.account_name', 'asc'), ('Operator.account_name', 'asc')])

        self.assertEqual(len(query_map['sort_tables']), 2)
        self.assertTrue('Enterprise' in query_map['sort_tables'])
        self.assertTrue('Operator' in query_map['sort_tables'])
        self.assertEqual(
                query_map['native_joins']['sql'],
                [['Enterprise', 'Operator']])
        self.assertEqual(
            build_query(query_map),
            ' '.join(['SELECT', 'FROM', 'vss_ENTERPRISE AS `Enterprise`',
                'INNER JOIN vss_OPERATOR AS `Operator`',
                'ON Enterprise.account_name = Operator.account_parent',
                'WHERE', '1 = 1', 'ORDER BY', 'Enterprise.account_name asc, Operator.account_name asc']))

    def test_set_filters_resultset_options(self):
        query_map = self.listables.create_query_map()
        lt = self.listables['User']

        lt.set_filters(
                query_map,
                ['Operator.account_name', '=', 'operator1'],
                None)
        lt.set_resultset(
            query_map,
            ['cpe.cpeid', 'User.account_name'])
        lt.set_query_options(
            query_map,
            sort='Enterprise.account_name')

        self.assertEqual(
            query_map['realized_filters'].replace('?', '%s') % tuple(
                query_map['filter_params']),
            'Operator.account_name = operator1')
        self.assertEqual(len(query_map['filter_tables']), 2)
        self.assertTrue('Operator' in query_map['filter_tables'])
        self.assertEqual(len(query_map['show']), 2)
        self.assertTrue('cpe.cpeid' in query_map['show'])
        self.assertTrue('User.account_name' in query_map['show'])
        self.assertEqual(len(query_map['resultset_tables']), 2)
        self.assertTrue('cpe' in query_map['resultset_tables'])
        self.assertTrue('User' in query_map['resultset_tables'])
        self.assertEqual(len(query_map['sort_tables']), 1)
        self.assertTrue('Enterprise' in query_map['sort_tables'])
        self.assertEqual(
            build_query(query_map),
            ' '.join(['SELECT', 'cpe.cpeid, User.account_name', 'FROM',
                'vss_USER AS `User`',
                'INNER JOIN vss_OPERATOR AS `Operator`',
                'ON User.account_parent = Operator.account_name',
                'INNER JOIN vss_USER_CPE_RELATION AS `UserCPERelation`',
                'ON User.account_name = UserCPERelation.userid',
                'INNER JOIN CPEManager_CPEs AS `cpe`',
                'ON UserCPERelation.cpeid = cpe.cpeid',
                'INNER JOIN vss_ENTERPRISE AS `Enterprise`',
                'ON Operator.account_parent = Enterprise.account_name',
                'WHERE', 'Operator.account_name = operator1',
                'ORDER BY', 'Enterprise.account_name asc']))

    def test_set_filters_options_resultset(self):
        query_map = self.listables.create_query_map()
        lt = self.listables['User']

        lt.set_filters(
                query_map,
                ['Operator.account_name', '=', 'operator1'],
                None)
        lt.set_query_options(
            query_map,
            sort='Enterprise.account_name')
        lt.set_resultset(
            query_map,
            ['cpe.cpeid', 'User.account_name'])

        self.assertEqual(
            query_map['realized_filters'].replace(
                '?', '%s') % tuple(query_map['filter_params']),
            'Operator.account_name = operator1')
        self.assertEqual(len(query_map['filter_tables']), 2)
        self.assertTrue('Operator' in query_map['filter_tables'])
        self.assertEqual(len(query_map['show']), 2)
        self.assertTrue('cpe.cpeid' in query_map['show'])
        self.assertTrue('User.account_name' in query_map['show'])
        self.assertEqual(len(query_map['resultset_tables']), 2)
        self.assertTrue('cpe' in query_map['resultset_tables'])
        self.assertTrue('User' in query_map['resultset_tables'])
        self.assertEqual(len(query_map['sort_tables']), 1)
        self.assertTrue('Enterprise' in query_map['sort_tables'])
        self.assertEqual(
            build_query(query_map),
            ' '.join(['SELECT', 'cpe.cpeid, User.account_name', 'FROM',
                'vss_USER AS `User`',
                'INNER JOIN vss_OPERATOR AS `Operator`',
                'ON User.account_parent = Operator.account_name',
                'INNER JOIN vss_USER_CPE_RELATION AS `UserCPERelation`',
                'ON User.account_name = UserCPERelation.userid',
                'INNER JOIN CPEManager_CPEs AS `cpe`',
                'ON UserCPERelation.cpeid = cpe.cpeid',
                'INNER JOIN vss_ENTERPRISE AS `Enterprise`',
                'ON Operator.account_parent = Enterprise.account_name',
                'WHERE', 'Operator.account_name = operator1',
                'ORDER BY', 'Enterprise.account_name asc']))

    def test_set_resultset_options_filters(self):
        query_map = self.listables.create_query_map()
        lt = self.listables['Enterprise']

        lt.set_resultset(
            query_map,
            ['Enterprise.account_name', 'Operator.account_name'])
        lt.set_query_options(
            query_map,
            sort=[('Enterprise.account_name', 'desc')])
        lt.set_filters(
                query_map,
                ['cpe.cpetype', '=', 'genericTR69'],
                None)

        self.assertEqual(
            query_map['realized_filters'].replace('?', '%s') % tuple(query_map['filter_params']),
            'cpe.cpetype = genericTR69')
        self.assertEqual(len(query_map['filter_tables']), 2)
        self.assertTrue('cpe' in query_map['filter_tables'])
        self.assertTrue('Enterprise' in query_map['filter_tables'])
        self.assertEqual(len(query_map['show']), 2)
        self.assertTrue('Enterprise.account_name' in query_map['show'])
        self.assertTrue('Operator.account_name' in query_map['show'])
        self.assertEqual(len(query_map['resultset_tables']), 2)
        self.assertTrue('Enterprise' in query_map['resultset_tables'])
        self.assertTrue('Operator' in query_map['resultset_tables'])
        self.assertEqual(len(query_map['sort_tables']), 1)
        self.assertTrue('Enterprise' in query_map['sort_tables'])
        self.assertEqual(
            build_query(query_map),
            ' '.join(['SELECT', 'Enterprise.account_name, Operator.account_name', 'FROM',
                'vss_ENTERPRISE AS `Enterprise`',
                'INNER JOIN vss_OPERATOR AS `Operator`',
                'ON Enterprise.account_name = Operator.account_parent',
                'INNER JOIN CPEManager_CPEs AS `cpe`',
                'ON Operator.account_name = cpe.cid2',
                'WHERE', 'cpe.cpetype = genericTR69',
                'ORDER BY', 'Enterprise.account_name desc']))

    def test_set_resultset_filters_options(self):
        query_map = self.listables.create_query_map()
        lt = self.listables['Enterprise']

        lt.set_resultset(
            query_map,
            ['Enterprise.account_name', 'Operator.account_name'])
        lt.set_query_options(
            query_map,
            sort=[('Enterprise.account_name', 'desc')])
        lt.set_filters(
                query_map,
                ['cpe.cpetype', '=', 'genericTR69'],
                None)

        self.assertEqual(
            query_map['realized_filters'].replace('?', '%s') % tuple(query_map['filter_params']),
            'cpe.cpetype = genericTR69')
        self.assertEqual(len(query_map['filter_tables']), 2)
        self.assertTrue('cpe' in query_map['filter_tables'])
        self.assertTrue('Enterprise' in query_map['filter_tables'])
        self.assertEqual(len(query_map['show']), 2)
        self.assertTrue('Enterprise.account_name' in query_map['show'])
        self.assertTrue('Operator.account_name' in query_map['show'])
        self.assertEqual(len(query_map['resultset_tables']), 2)
        self.assertTrue('Enterprise' in query_map['resultset_tables'])
        self.assertTrue('Operator' in query_map['resultset_tables'])
        self.assertEqual(len(query_map['sort_tables']), 1)
        self.assertTrue('Enterprise' in query_map['sort_tables'])
        self.assertEqual(
            build_query(query_map),
            ' '.join(['SELECT', 'Enterprise.account_name, Operator.account_name', 'FROM',
                'vss_ENTERPRISE AS `Enterprise`',
                'INNER JOIN vss_OPERATOR AS `Operator`',
                'ON Enterprise.account_name = Operator.account_parent',
                'INNER JOIN CPEManager_CPEs AS `cpe`',
                'ON Operator.account_name = cpe.cid2',
                'WHERE', 'cpe.cpetype = genericTR69',
                'ORDER BY', 'Enterprise.account_name desc']))

    def test_set_options_filters_resultset(self):
        query_map = self.listables.create_query_map()
        lt = self.listables['Operator']

        lt.set_query_options(
            query_map,
            sort=[
                ('User.account_name', 'asc'),
                ('Enterprise.account_name', 'desc')])
        lt.set_filters(
                query_map,
                ['Operator.account_parent', '=', 'enterprise1'],
                None)
        lt.set_resultset(
            query_map,
            ['kv', 'User.account_name', 'Enterprise.account_name'])

        self.assertEqual(
            query_map['realized_filters'].replace('?', '%s') % tuple(query_map['filter_params']),
            'Operator.account_parent = enterprise1')
        self.assertEqual(len(query_map['filter_tables']), 1)
        self.assertTrue('Operator' in query_map['filter_tables'])
        self.assertEqual(len(query_map['show']), 2)
        self.assertTrue('User.account_name' in query_map['show'])
        self.assertTrue('Enterprise.account_name' in query_map['show'])
        self.assertEqual(query_map['to_kv'], 'kv')
        self.assertEqual(len(query_map['resultset_tables']), 2)
        self.assertTrue('User' in query_map['resultset_tables'])
        self.assertTrue('Enterprise' in query_map['resultset_tables'])
        self.assertEqual(len(query_map['sort_tables']), 2)
        self.assertTrue('User' in query_map['sort_tables'])
        self.assertTrue('Enterprise' in query_map['sort_tables'])
        self.assertEqual(
            build_query(query_map),
            ' '.join(['SELECT', 'User.account_name, Enterprise.account_name', 'FROM',
                'vss_OPERATOR AS `Operator`',
                'INNER JOIN vss_USER AS `User`',
                'ON Operator.account_name = User.account_parent',
                'INNER JOIN vss_ENTERPRISE AS `Enterprise`',
                'ON Operator.account_parent = Enterprise.account_name',
                'WHERE', 'Operator.account_parent = enterprise1',
                'ORDER BY', 'User.account_name asc, Enterprise.account_name desc']))

    def test_set_options_resultset_filters(self):
        query_map = self.listables.create_query_map()
        lt = self.listables['Operator']

        lt.set_query_options(
            query_map,
            sort=[
                ('User.account_name', 'asc'),
                ('Enterprise.account_name', 'desc')])
        lt.set_resultset(
            query_map,
            ['kv', 'User.account_name', 'Enterprise.account_name'])
        lt.set_filters(
                query_map,
                ['Operator.account_parent', '=', 'enterprise1'],
                None)

        self.assertEqual(
            query_map['realized_filters'].replace('?', '%s') % tuple(query_map['filter_params']),
            'Operator.account_parent = enterprise1')
        self.assertEqual(len(query_map['filter_tables']), 1)
        self.assertTrue('Operator' in query_map['filter_tables'])
        self.assertEqual(len(query_map['show']), 2)
        self.assertTrue('User.account_name' in query_map['show'])
        self.assertTrue('Enterprise.account_name' in query_map['show'])
        self.assertEqual(query_map['to_kv'], 'kv')
        self.assertEqual(len(query_map['resultset_tables']), 2)
        self.assertTrue('User' in query_map['resultset_tables'])
        self.assertTrue('Enterprise' in query_map['resultset_tables'])
        self.assertEqual(len(query_map['sort_tables']), 2)
        self.assertTrue('User' in query_map['sort_tables'])
        self.assertTrue('Enterprise' in query_map['sort_tables'])
        self.assertEqual(
            build_query(query_map),
            ' '.join(['SELECT', 'User.account_name, Enterprise.account_name', 'FROM',
                'vss_OPERATOR AS `Operator`',
                'INNER JOIN vss_USER AS `User`',
                'ON Operator.account_name = User.account_parent',
                'INNER JOIN vss_ENTERPRISE AS `Enterprise`',
                'ON Operator.account_parent = Enterprise.account_name',
                'WHERE', 'Operator.account_parent = enterprise1',
                'ORDER BY', 'User.account_name asc, Enterprise.account_name desc']))


class TestAXListablesDataAPI(unittest2.TestCase):

    def setUp(self):
        self.listables = get_listables(ListablesTestSchema, engine)
        prepare_data()

    def tearDown(self):
        cleanup_data()
        self.listables.invalidate_select_cache()

    def test_select_data(self):
        data = self.listables.select(
            engine,
            ['User.account_name', 'cpe.cpeid'],
            ['cpe.cpetype', '=', 'genericTR69'],
            [('User.account_name', 'desc'), ('cpe.cpeid', 'asc')],
            root='UserCPERelation')
        self.assertEqual(len(data), 4)
        self.assertEqual(data[0][0], 'user2')
        self.assertEqual(data[0][1], 'ZZ0000000003')
        self.assertEqual(data[1][0], 'user2')
        self.assertEqual(data[1][1], 'ZZ0000000004')
        self.assertEqual(data[2][0], 'user1')
        self.assertEqual(data[2][1], 'ZZ0000000001')
        self.assertEqual(data[3][0], 'user1')
        self.assertEqual(data[3][1], 'ZZ0000000004')

    def test_select_data2(self):
        data = self.listables.select(
            engine,
            ['cpe.cpeid'],
            [
                [
                    ['cpe.cpetype', '=', 'genericTR69'],
                    'and',
                    ['cpe.roles', '=', 'unsupportedFW']
                ],
                'or',
                ['cpe.cpeid', '=', 'ZZ0000000001']
            ],
            [('cpe.cpeid', 'desc')],
            limit=1,
            offset=0)
        self.assertEqual(len(data), 1)
        self.assertEqual(data[0][0], 'ZZ0000000004')

        data = self.listables.select(
            engine,
            ['cpe.cpeid'],
            [
                [
                    ['cpe.cpetype', '=', 'genericTR69'],
                    'and',
                    ['cpe.roles', '=', 'unsupportedFW']
                ],
                'or',
                ['cpe.cpeid', '=', 'ZZ0000000001']
            ],
            [('cpe.cpeid', 'desc')],
            limit=5,
            offset=1)
        self.assertEqual(len(data), 3)
        self.assertEqual(data[0][0], 'ZZ0000000003')
        self.assertEqual(data[1][0], 'ZZ0000000002')
        self.assertEqual(data[2][0], 'ZZ0000000001')

    def test_select_error(self):
        with self.assertRaises(ValueError) as context:
            data = self.listables.select(
                engine,
                ['cpeid'],
                ['cpetype', '=', 'genericTR69'])
        self.assertEqual("Unknown root element cpeid",
                        str(context.exception))

    def test_count(self):
        count = self.listables.count(
            engine,
            ['cpe.cpetype', '=', 'genericTR69'])
        self.assertEqual(count, 4)

    def test_count_group_by(self):
        counts = self.listables.count(
            engine,
            group_by=['cpe.cpetype'])
        self.assertEqual(len(counts), 1)
        self.assertEqual(counts[0][0], 4)
        self.assertEqual(counts[0][1], 'genericTR69')

    def test_count_error(self):
        with self.assertRaises(ValueError) as context:
            count = self.listables.count(engine)
        self.assertEqual("Not enough information for counting",
                        str(context.exception))

    def test_count_without_filter_and_group(self):
        count = self.listables.count(engine, root='cpe')
        self.assertEqual(count, 4)

    def test_delete(self):
        count = self.listables.count(
            engine,
            [
                ['cpe.cpeid', '=', 'ZZ0000000003'],
                'and',
                ['Operator.account_name', '=', 'operator1']
            ])

        count = self.listables.delete(
            engine,
            [
                ['cpe.cpeid', '=', 'ZZ0000000003'],
                'and',
                ['Operator.account_name', '=', 'operator1']
            ],
            root='cpe')
        self.assertEqual(count, 1)

        count = self.listables.count(
            engine,
            [
                ['cpe.cpeid', '=', 'ZZ0000000003'],
                'and',
                ['Operator.account_name', '=', 'operator1']
            ])
        self.assertEqual(count, 0)

        count = self.listables.count(
            engine,
            ['Operator.account_name', '=', 'operator1'])
        self.assertEqual(count, 1)

    def test_update(self):
        count = self.listables.count(
            engine,
            [
                ['cpetype', '=', 'genericTR69'],
                'and',
                ['cpeid', '=', 'ZZ0000000003']
            ],
            root='cpe')
        self.assertEqual(count, 1)

        count = self.listables.update(
            engine,
            {'cpe.cpetype': 'avm'},
            ['cpe.cpeid', '=', 'ZZ0000000003'])
        self.assertEqual(count, 1)

        count = self.listables.count(
            engine,
            [
                ['cpetype', '=', 'genericTR69'],
                'and',
                ['cpeid', '=', 'ZZ0000000003']
            ],
            root='cpe')
        self.assertEqual(count, 0)

    def test_insert(self):
        old_count = self.listables.count(engine, ['cpe.cpeid', '=', 'ZZ0000000005'])
        insert_count = self.listables.insert(
            engine,
            {
                'cpe.cid': '',
                'cpe.cid2': '',
                'cpe.cpeid': 'ZZ0000000005',
                'cpe.cpetype': 'avm',
                'cpe.path': '',
                'cpe.version': '1.0',
                'cpe.IP': '192.0.0.1',
                'cpe.parentID': '',
                'cpe.protocolVersion': '1.0',
                'cpe.state': 1,
                'cpe.pendingProps': '',
                'cpe.unmanagedProps': '',
                'cpe.pendingProps': '',
                'cpe.props': '',
                'cpe.scProps': '',
                'cpe.lastCookie': '',
                'cpe.events': '',
                'cpe.methods': '',
                'cpe.comments': '',
                'cpe.roles': 'supportedFW'})
        self.assertEqual(1, insert_count)
        new_count = self.listables.count(engine, ['cpe.cpeid', '=', 'ZZ0000000005'])
        self.assertEqual(new_count, old_count + insert_count)

        old_count = self.listables.count(engine, ['cpe.cpeid', '=', 'ZZ0000000006'])
        insert_count = self.listables.insert(
            engine,
            {
                'cid': '',
                'cid2': '',
                'cpeid': 'ZZ0000000006',
                'cpetype': 'avm',
                'path': '',
                'version': '1.0',
                'IP': '192.0.0.1',
                'parentID': '',
                'protocolVersion': '1.0',
                'state': 1,
                'pendingProps': '',
                'unmanagedProps': '',
                'pendingProps': '',
                'props': '',
                'scProps': '',
                'lastCookie': '',
                'events': '',
                'methods': '',
                'comments': '',
                'roles': 'supportedFW'
            },
            root='cpe')
        self.assertEqual(1, insert_count)
        new_count = self.listables.count(engine, ['cpe.cpeid', '=', 'ZZ0000000006'])
        self.assertEqual(new_count, old_count + insert_count)
