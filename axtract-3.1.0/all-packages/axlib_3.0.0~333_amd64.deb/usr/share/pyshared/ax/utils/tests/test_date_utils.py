#!/usr/bin/python -tt

import datetime
import pytz
import unittest2

from ax.utils import date_utils as du


class DateUtilsTests(unittest2.TestCase):

    def test_long_delta(self):
        """timedelta_to_seconds for long timedelta"""
        # timedelta of 10,000 days
        delta = datetime.timedelta(10000)
        seconds = du.timedelta_to_seconds(delta)
        self.assertEqual(seconds, 10000 * 24 * 3600)

    def test_short_delta(self):
        """timedelta_to_seconds for short timedelta"""
        # 100 microseconds
        delta = datetime.timedelta(0, 0, 100)
        seconds = du.timedelta_to_seconds(delta)
        self.assertEqual(seconds, 100.0 / 1000000)

    def test_mixed_delta(self):
        """timedelta that contains days, seconds, microseconds

        These three are what a timedelta stores internally
        """
        delta = datetime.timedelta(22, 33, 44)
        seconds = du.timedelta_to_seconds(delta)

        seconds_from_days = 22 * 24 * 3600
        seconds_from_seconds = 33
        seconds_from_microsenconds = 44.0 / 1000000

        ref = 0
        ref += seconds_from_days
        ref += seconds_from_seconds
        ref += seconds_from_microsenconds
        self.assertEqual(seconds, ref)


class TestDateUtilsTZHandler(unittest2.TestCase):
    def test_init(self):
        inst = du.TimeZoneHelper('local')
        self.assertIsInstance(inst, du.TimeZoneHelper)

    def test_local_zone_init(self):
        inst = du.TimeZoneHelper('local')
        self.assertEqual(inst.zone, du.TimeZoneHelper._local_tz)

    def test_german_zone_init(self):
        inst = du.TimeZoneHelper("Europe/Berlin")
        self.assertEqual('Europe/Berlin', inst.zone.zone)

    def test_german_zone_start_of_day(self):
        # Keep in mind these are the UTC timestamps
        inst = du.TimeZoneHelper("Europe/Berlin")

        ref1 = datetime.datetime(2015, 1, 8, 23, 0, 0)
        ref2 = datetime.datetime(2015, 1, 9, 23, 0, 0)

        dt = datetime.datetime(2015, 1, 9, 22, 0, 0)
        self.assertEqual(ref1, inst.start_of_day(dt))

        dt = datetime.datetime(2015, 1, 9, 23, 0, 0)
        self.assertEqual(ref2, inst.start_of_day(dt))

        dt = datetime.datetime(2015, 1, 10, 0, 0, 0)
        self.assertEqual(ref2, inst.start_of_day(dt))

    def test_german_zone_start_of_week(self):
        # Keep in mind these are the UTC timestamps
        inst = du.TimeZoneHelper("Europe/Berlin")

        ref1 = datetime.datetime(2015, 1, 4, 23, 0)
        ref2 = datetime.datetime(2015, 1, 11, 23, 0)

        # Check the basic stuff for the entire week.
        for hour in range(7 * 24):
            start = datetime.datetime(2015, 1, 4, 23, 0)
            dt = start + datetime.timedelta(hours=hour)
            self.assertEqual(ref1, inst.start_of_week(dt))

        # Check the borders
        dt = datetime.datetime(2015, 1, 11, 22, 0, 0)
        self.assertEqual(ref1, inst.start_of_week(dt))

        dt = datetime.datetime(2015, 1, 11, 23, 0, 0)
        self.assertEqual(ref2, inst.start_of_week(dt))

        dt = datetime.datetime(2015, 1, 12, 0, 0, 0)
        self.assertEqual(ref2, inst.start_of_week(dt))

    def test_german_zone_start_of_month(self):
        inst = du.TimeZoneHelper("Europe/Berlin")

        ref1 = datetime.datetime(2014, 12, 31, 23, 0)
        ref2 = datetime.datetime(2015, 1, 31, 23, 0)

        # Check the basic stuff for the entire January
        for hour in range(31 * 24):
            start = datetime.datetime(2014, 12, 31, 23)
            dt = start + datetime.timedelta(hours=hour)
            self.assertEqual(ref1, inst.start_of_month(dt))

        # Check the borders
        dt = datetime.datetime(2015, 1, 31, 22, 0, 0)
        self.assertEqual(ref1, inst.start_of_month(dt))

        dt = datetime.datetime(2015, 1, 31, 23, 0, 0)
        self.assertEqual(ref2, inst.start_of_month(dt))

        dt = datetime.datetime(2015, 2, 1, 0, 0, 0)
        self.assertEqual(ref2, inst.start_of_month(dt))

    def test_german_zone_start_of_year(self):
        inst = du.TimeZoneHelper("Europe/Berlin")

        ref1 = datetime.datetime(2013, 12, 31, 23, 0)
        ref2 = datetime.datetime(2014, 12, 31, 23, 0)

        # Check the basic stuff
        for hour in range(365 * 24):
            start = datetime.datetime(2013, 12, 31, 23)
            dt = start + datetime.timedelta(hours=hour)
            self.assertEqual(ref1, inst.start_of_year(dt))

        # Check the borders
        dt = datetime.datetime(2014, 12, 31, 22, 0, 0)
        self.assertEqual(ref1, inst.start_of_year(dt))

        dt = datetime.datetime(2014, 12, 31, 23, 0, 0)
        self.assertEqual(ref2, inst.start_of_year(dt))

        dt = datetime.datetime(2015, 1, 1, 0, 0, 0)
        self.assertEqual(ref2, inst.start_of_year(dt))


if __name__ == "__main__":
    unittest2.main()
