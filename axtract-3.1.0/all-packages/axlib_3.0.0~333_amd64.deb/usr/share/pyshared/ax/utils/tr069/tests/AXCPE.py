"""

AXCPE.py is part of the commercial product Axess.

This file is copyrighted (C) 2002 - 2012 by Axiros GmbH.
Under no circumstance any distribution, derived work, analysis
and/or decompilation of this module is allowed.

Usage is restricted to parties legally owning a license
for the whole product. German copyright laws apply!

For details please read the license.

"""

__author__ = "Axiros GmbH, Germany"
__date__ = "$Date: 2005-08-31 16:10:56 +0200 (Wed, 31 Aug 2005) $"
__version__ = "$Revision: 2592 $"[11:-2]


import datetime
import time
import simplejson

from ax.utils.tr069 import TR69Utils
def do_nothing(*args, **kwargs):
    return ''

try:

    from zope.interface import implements
    from Products.WPSCommon.TR69.IAXCPE import IAXCPE
    from Products.WPSCommon.WPSGlobals import prettyPrintSCs
    from Products.WPSCommon.WPSGlobals import makeAJAXImg
    from Products.WPSCommon.WPSGlobals import makeJSImg
    from Products.WPSCommon.WPSGlobals import htmlMark
    from Products.WPSCommon.WPSGlobals import htmlFormatMap
    from Products.WPSCommon.WPSGlobals import HTML_LIGHT_BY_STATE

    from Products.WPSCommon.WPSGlobals import CPE_STATE_UP_TO_DATE
    from Products.WPSCommon.WPSGlobals import CPE_STATES_PRETTY
    from Products.WPSCommon.WPSGlobals import SC_STATE_FINISHED

    from Products.WPSCommon.WPSGlobals import SC_KEY_INTERVAL
    from Products.WPSCommon.WPSGlobals import SC_KEY_STEP
    from Products.WPSCommon.WPSGlobals import SC_KEY_ID
    from Products.WPSCommon.WPSGlobals import SC_KEY_ENV_ID
    from Products.AXCommon.PrettyPrinter import PrettyPrinter
except:
    htmlMark, makeAJAXImg = (do_nothing, do_nothing)
    htmlFormatMap, prettyPrintSCs = (do_nothing, do_nothing)
    makeAJAXImg = do_nothing

    HTML_LIGHT_BY_STATE, CPE_STATE_UP_TO_DATE = 0, 0
    SC_KEY_LASTRESULT = "lastResult"
    SC_KEY_INTERVAL = "interval"
    SC_KEY_NEXT_DUE = "nextDue"
    SC_KEY_ID = "id"
    SC_KEY_STEP = "step"
    SC_KEY_TIMESTAMP = "ts"
    SC_KEY_INITARGS = "initargs"
    SC_KEY_ENV_ID = "envelopeId"
    SC_KEY_CALLER_ENV_ID = 'callerEnvId'
    SC_KEY_PROCESSING = 'processing'
    SC_KEY_NO_RESPONSE = "noResponse"
    SC_KEY_REBOOTING = "rebooting"
    SC_KEY_RESTART_ON_FAIL = "restartOnFail"
    SC_KEY_AUTHOR = "author"
    SC_KEY_BACKUP = "backup"


    # state
    SC_STATE_FINISHED = -1

    # for marat, there was a change in API:
    SC_KEY_FINISHED = 'finished'


    # cpe config vars:
    CPE_STATE_UP_TO_DATE = 0
    CPE_STATE_CONFIGURING = 2
    CPE_STATE_PENDING = 1
    CPE_STATE_INITIAL = 3

    CPE_STATE_NO_REACH_CONFIGURING = 4
    CPE_STATE_NO_REACH_UP_TO_DATE = 5
    CPE_STATE_NO_REACH_PENDING = 6

    CPE_STATE_CONFIGURE_FAILED = 7

    CPE_STATE_FW_DOWNLOADING = 8
    CPE_STATE_REBOOTING = 9


    CPE_STATES_PRETTY = {
      CPE_STATE_UP_TO_DATE: 'UP TO DATE (0)',\
      CPE_STATE_CONFIGURING: 'CONFIGURING (2)',\
      CPE_STATE_PENDING: 'PENDING (1)',\
      CPE_STATE_INITIAL: 'INITIAL (3)',\
      CPE_STATE_NO_REACH_CONFIGURING: 'NO REACH CONFIGURING (4)',\
      CPE_STATE_NO_REACH_UP_TO_DATE: 'NO REACH UP TO DATE (5)',\
      CPE_STATE_NO_REACH_PENDING: 'NO REACH PENDING (6)',\
      CPE_STATE_CONFIGURE_FAILED: 'CONFIGURE FAILED (7)',\
      CPE_STATE_FW_DOWNLOADING: 'FW DOWNLOADING (8)', \
      CPE_STATE_REBOOTING: 'REBOOTING (9)'
      }

    HTML_LIGHT_BY_STATE = {
    0: "upToDate",
    1: "pending",
    2: "configuring",
    3: "initial",
    4: "configuringUnreachable",
    5: "upToDateUnreachable",
    6: "pendingUnreachable",
    7: "configureFailed",
    8: "firmwareDownload",
    9: "booting"
    }


from copy import deepcopy

CPEAttributes = (
        'cid',
        'cid2',
        'cpeid',
        'cpetype',
        'path',
        'version',
        'IP',
        'state',
        'lastMsg',
        'logLevel',
        'unmanagedProps',
        'pendingProps',
        'nextDue',
        'props',
        'methods',
        'comments',
        'transID',
        'parentID',
        'scProps',
        'firstMsg',
        'events',
        'lastCookie',
        'roles',
        'protocolVersion',
        'pii',
    )


def create_cpe_obj_by_map(cpe_attributes):
    default = {
        'cid' : '',
        'cid2' : '',
        'cpeid' : None,
        'cpetype' : '',
        'path' : '/',
        'version' : '',
        'IP' : '0.0.0.0',
        'state' : 0,
        'lastMsg' : int(time.time()),
        'logLevel' : 0,
        'unmanagedProps' : (),
        'pendingProps' : {},
        'nextDue' : 0,
        'props' : {},
        'methods' : [],
        'comments' : '',
        'transID' : 1,
        'parentID' : '',
        'scProps' : {},
        'firstMsg' : int(time.time()),
        'events' : [],
        'lastCookie' : '',
        'roles' : [],
        'protocolVersion' : '',
    }

    if not 'cpeid' in cpe_attributes:
        raise Exception("Need cpeid to create a CPE-Obj")
    elif not cpe_attributes['cpeid']:
        err_stmt = "Not suitable value for cpeid (%s)"
        raise Exception(err_stmt % cpe_attributes['cpeid'])

    # convert the incoming cpe_attributes to integers
    # (for this attrs which it make sens)
    for n in ('state', 'lastMsg', 'logLevel', 'nextDue', 'transID', 'firstMsg'):
        if n in cpe_attributes:
            cpe_attributes[n] = int(cpe_attributes[n])

    if not isinstance(default['props'], dict):
        raise Exception("Props must be a dict")

    if not isinstance(default['pendingProps'], dict):
        raise Exception("pendingProps must be a dict")

    for attr_name in default:
        if attr_name in cpe_attributes:
            default[attr_name] = cpe_attributes[attr_name]

    if not 'version' in default:
        longs = TR69Utils.autoLong(default['props'])
        default['version'] = TR69Utils.getVersionStringFromLong69(longs)

    default['props'] = TR69Utils.autoShort(default['props'])
    default['pendingProps'] = TR69Utils.autoShort(default['pendingProps'])

    return CPE(**default)

def getCPEObjByDBRecord( dbrecord, log = None):
    if dbrecord:
        nextDue,
        cid,
        cid2,
        cpeid,
        cpetype,
        path,
        version,
        IP,
        state,
        lastMsg,
        logLevel,
        unmanagedProps,
        pendingProps,
        props,
        methods,
        comments,
        transID,
        parentID,
        scProps,
        firstMsg,
        events,
        lastCookie,
        roles,
        protocolVersion = dbrecord

        cpe = CPE(
                cid,
                cid2,
                cpeid,
                cpetype,
                path,
                version,
                IP,
                state,
                lastMsg,
                logLevel,
                unmanagedProps,
                pendingProps,
                nextDue,
                props,
                methods,
                comments,
                transID,
                parentID,
                scProps,
                firstMsg,
                events,
                lastCookie,
                roles,
                protocolVersion,
                log)

        return cpe


SPACER = "&nbsp;&nbsp;"
def getTitle(key, showProps):
    """ returns the titles for the htmlFormatMap - pretty print
    function"""
    try:
        # getVal returns possible unicode => transform it to a string.
        # It is sufficent to use the default-encoding 'ascii' because NO UTF-8
        # chars are expected here
        s =  htmlMark('..'+ str(TR69Utils.getVal(key, 'long'))[-50:], showProps)
    except:
        s = ""
    return s


class CPE:
    """
    The CPE as read from the database
    Used / inherited by zope and autonmous configurators.
    Known to the DB Classes
    There is no registry whatsoever for CPEs, sharing them for persistent
    objects of paralles threads, so the object belongs to one thread.
    Therefore we allow for a log method to be given.
    """
    try:
        implements(IAXCPE)
    except Exception, ex:
        pass

    def hasActiveMethods(self, method_name=None, envid=None):
        """ check if we have an active scenario or
        just none or scheduled ones """
        for sc in self.methods:
            if sc.get(SC_KEY_STEP) != SC_STATE_FINISHED and not sc.get(SC_KEY_INTERVAL):
                if (method_name is None) and (envid is None):
                    return True
                elif not None in (method_name, envid):
                    if sc.get(SC_KEY_ID) == method_name and sc.get(SC_KEY_ENV_ID) == envid:
                        return True
                elif method_name is not None:
                    if sc.get(SC_KEY_ID) == method_name:
                        return True
                elif envid is not None:
                    if sc.get(SC_KEY_ENV_ID) == envid:
                        return True
        return False

    def manage_setLogLevel (self, r, l):
        CM = r.get('CM')
        assert CM, "Need a CPE Manager"
        self.log(3, "Changing logLevel from %s to %s"  % (self.logLevel, l))
        self.logLevel = int(l)
        CM.manage_writeCPE(r, self)


    def __repr__(self):
        return self.__str__()


    def __str__(self, *args):
        return "ID: %s, state: %s" % (self.cpeid, CPE_STATES_PRETTY.get(self.state))

    def log(self, level, *args):
        # also filled CPEHandlerSpecificFrame.py:

        self.dblog += (( time.time(), level,  args),)
        if self.callerlog:
            self.callerlog(level, args)
        else:
            print str(self) + ": " + str( level) +str( args)


    def __init__ (self,
            cid,
            cid2,
            cpeid,
            cpetype,
            path,
            version,
            IP,
            state,
            lastMsg,
            logLevel,
            unmanagedProps,
            pendingProps,
            nextDue,
            props,
            methods,
            comments,
            transID,
            parentID,
            scProps,
            firstMsg,
            events,
            lastCookie,
            roles,
            protocolVersion,
            log=None):
        """
        A new CPE Instance
        """
        self.inittime = time.time()
        # good for later DB ts comparisons - 
        # db drivers deliver the ts as datetime:
        self.initdatetime =  datetime.datetime.now()
        try:
            self.transID = int(transID)
        except:
            self.transID = 0
        self.cid = cid
        self.cid2 = cid2
        self.cpeid = cpeid
        self.cpetype = cpetype
        self.path = path
        self.version = version
        self.IP = IP
        # to be able to detect IP changed when saveing the inform:
        self.oldIP = IP
        self.state = state
        self.logLevel = logLevel
        self.lastMsg = lastMsg

        self.dblog = ()
        self.nextDue = nextDue

        # FIXME Marat
        # cwmp version must bes saved in database
        #self.cwmpVersion="cwmp-1-0"
        self.protocolVersion=protocolVersion

        self.parentID=parentID
        self.lastCookie=lastCookie
        self.firstMsg = firstMsg

        if isinstance(unmanagedProps, basestring):
            try:
                unmanagedProps = tuple(simplejson.loads(unmanagedProps))
            except ValueError, error:
                # making a tuple out of a json list did not work,
                # the db record is probably old (stringyfied dict)
                try:
                    unmanagedProps = tuple(eval(unmanagedProps))
                except Exception, error:
                    unmanagedProps = ()
            except Exception, error:
                unmanagedProps = ()

        self.unmanagedProps = unmanagedProps
        self.unmanagedPropsPretty = " ".join(unmanagedProps)

        if lastMsg == 0:
            self.lastMsgPretty = "n.a."
        else:
            self.lastMsgPretty = time.ctime(self.lastMsg)

        self.callerlog = log


        if isinstance(methods, basestring):
            e = None
            try:
                self.methods = simplejson.loads(methods)
            except ValueError, e:
                # making a tuple out of a json list did not work,
                # the db record is probably old (stringyfied dict)
                try:
                    self.methods = eval(methods)
                    e = None
                except Exception, error:
                    pass
            except Exception, e:
                pass

            if e is not None:
                self.log(3, "Could not evaluate methods - clearing them")
                self.log(9, "Methods are %s. Error is %s " % (methods, e))
                self.methods = []
        else:
            # given ready to use?:
            if type(methods) == type([]):
                self.methods = methods
            else:
                self.methods = []

        self.comments = comments

        if isinstance(props, basestring):
            e = None
            try:
                props = simplejson.loads(props)
            except ValueError, e:
                # making a dict out of a json map did not work,
                # the db record is probably old (stringyfied dict)
                try:
                    props = eval(props)
                    e = None
                except Exception, error:
                    pass
            except Exception, e:
                pass

            if e is not None:
                self.log(2, "Could not eval props", props, str(e))
                #props = {'I.MS.DI' : 'Could not eval properties %s ' % str(e)}
                props = {}

        self.props = props
        self.adjustRootObject()

        if isinstance(pendingProps, basestring):
            e = None
            try:
                pendingProps = simplejson.loads(pendingProps)
            except ValueError, e:
                # making a dict out of a json map did not work,
                # the db record is probably old (stringyfied dict)
                try:
                    pendingProps = eval(pendingProps)
                    e = None
                except Exception, error:
                    pass
            except Exception, e:
                pass
            if e is not None:
                self.log(2, "Could not eval pendingProps", pendingProps,
                        str(e))
                pendingProps = {}

        self.pendingProps = pendingProps
        self.adjustRootObject(adjustPendings = 1)

        # set scenario props
        if isinstance(scProps, basestring):
            e = None
            try:
                scProps = simplejson.loads(scProps)
            except ValueError, e:
                # making a dict out of a json map did not work,
                # the db record is probably old (stringyfied dict)
                try:
                    scProps = eval(scProps)
                    e = None
                except Exception, error:
                    pass
            except Exception, e:
                pass
            if e is not None:
                self.log(2, "Could not eval scProps", scProps, str(e))
                scProps = {}
        self.scProps = scProps


        # set events
        if isinstance(events, basestring):
            e = None
            try:
                events = simplejson.loads(events)
            except ValueError, e:
                # making a dict out of a json map did not work,
                # the db record is probably old (stringyfied dict)
                try:
                    events = eval(events)
                    e = None
                except Exception, error:
                    pass
            except Exception, e:
                pass
            if e is not None:
                self.log(2, "Could not eval events", events, str(e))
                events = []
        self.events = events


        # set roles
        if isinstance(roles, basestring):
            try:
                roles = roles.split(',')
            except Exception, error:
                self.log(2, "Could not split roles", roles, str(error))
                roles = []
        elif roles==None:
            roles=[]
        self.roles = roles
        self.pii = self.getPII()
        self.backupCurState()

    def getPII(self):
        """
        get current PII.
        It checks also PIE.
        If PIE is zero then we return here also 0
        So this method informs you if the PeriodicInform is enabled and if so
        then you get the current value.
        """
        try:
            if self.isIGD():
                if str(self.props.get("I.MS.PIE", None)) == '0':
                    return 0
                return self.props.get('I.MS.PII', 0)
            else:
                if str(self.props.get("D.MS.PIE", None)) == '0':
                    return 0
                return self.props.get('D.MS.PII', 0)
        except Exception:
            return 0

    def backupCurState(self):
        """ to control the changes in CPE Object, we should store intial state """
        setattr(self, "initState", {})
        for attr in CPEAttributes:
            self.initState[attr] = deepcopy(getattr(self, attr, None))

    def getChangedAttributes(self):
        """get changed parameters only"""
        changedParams = []
        self.pii = self.getPII()
        for attr in CPEAttributes:
            if getattr(self, attr) != self.initState[attr]: changedParams.append(attr)
        return changedParams


    def isUnmanaged(self, key):
        if not self.unmanagedProps:
            return
        longP = TR69Utils.getVal(key, 'long')
        shortP = TR69Utils.getVal(key, 'short')
        for uM in self.unmanagedProps:
            if longP.find(uM) > -1 or shortP.find(uM) > -1:
                return 1
        return


    def getProps(self):
        return self.props


    def setState(self, state):
        if self.state != state:
            self.log(6, "State %s to %s" % (self.state, state))

        if state == CPE_STATE_UP_TO_DATE:
            """ set the pending props into the props """
            self.props.update (TR69Utils.autoShort(self.pendingProps))
            self.pendingProps = {}

        self.state = state


    def addProps (self, props):
        self.props.update(TR69Utils.autoShort(props))

    def checkAndReducePropsMaxSize(self, size):
        """
        reduce props size
        """
        if size==0: return
        if len(str(self.props))<=size: return
        # sort props on size
        keys = self.props.keys()
        # sorting all properties by size
        keys.sort(lambda x,y:  len(str(self.props[y]))-len(str(self.props[x])))
        # check properties.
        # Don't delete Password, because impossible from get cpe
        deletedKeys=[]
        for key in keys:
            if TR69Utils.getVal(key, 'emptyfromcpe')=='1':
                continue
            if u'I.MS.' in key:
                continue

            del self.props[key]
            deletedKeys.append(key)
            if len(str(self.props))<=size:
                break

        if len(deletedKeys)>0:
            self.log(6,"This properties %s deleted" % deletedKeys)


        if len(str(self.props))>size:
            self.log(2,"Too big properties size %s" % len(str(self.props)))

    def adjustRootObject(self, adjustPendings = None):
        # adjust the root object. I. or D.
        # In next release Root Object will be removed in props
        if adjustPendings:
            m = self.pendingProps
        else:
            m = self.props

        keys = m.keys()
        if self.isIGD(): rootObject = "I"
        else: rootObject = "D"
        for key in keys:
            if key[0] == rootObject: continue
            # if we have the both properties D.MS.PII and I.MS.PII?
            #if not self.props.has_key(rootObject + key[1:]):
            m[rootObject + key[1:]] = m[key]
            del m[key]


    def addPendingProps(self, props, clear = 1):
        """ this autodetects long to short"""
        if clear:
            self.pendingProps = {}
        self.pendingProps.update(TR69Utils.autoShort(props))
        #if props:
        #       self.state = CPE_STATE_PENDING


    def getPending (self, key, default = None):
        # performance hint: if key is surely short,
        # take it directly from props.
        key = TR69Utils.getVal(key, 'short')
        return self.pendingProps.get(key, default)


    def get(self, key, default = None):
        # performance hint: if key is surely short,
        # and you know the root object:
        # take it directly from props.
        key = TR69Utils.getVal(key, 'short')
        key = self.correct_root(key)
        return self.props.get(key, default)


    def set (self, key, value):
        if hasattr(self, key):
            setattr(self, key, value)
            return
        key = TR69Utils.getVal(key, 'short')
        key = self.correct_root(key)
        self.props[key] = value


    def correct_root(self, short):
        if self.isIGD():
            rootObject = "I"
        else:
            rootObject = "D"
        if short[0] == '.':
            short = rootObject + short
        elif short[0] != rootObject:
            short = rootObject + short[1:]
        return short


    def tagCPEForWrite(self):
        # at the end of a SOAP call the CPE iis written back to the'
        # db if the 'writeCPE' attr exists.
        # By using this, many manage_writeCPE's can be spared
        setattr(self,'writeCPE',True)



    #######################################################################
    #
    # HTML-OUTPUT FORMATTING:
    #
    #######################################################################

    def toHtml (self, request, showProps = {}):
        """ the entry function called by the web pages when showing a CPE"""
        # via the request we get to the CM, where we could configure
        # what to show here:
        s = ()


        # compat:
        if type(showProps) != type({}):
            err_str = "Please supply the second argument in toHtml() as a dict"
            raise Exception(err_str)

        showProps['mark'] = request.get('mark')

        # convenience:
        if showProps.get('default'):
            showProps['state'] = 1
            showProps['cpeattrs'] = ('cpeid', 'cpetype')
            showProps['layoutMain'] = 'table'

        if showProps.get('layoutMain') == 'table':
            showProps.setdefault('layoutPre', '<table><tr><td>')
            showProps.setdefault('layoutPost', '</td></tr></table>')
            showProps.setdefault('layoutInter', '</td><td>'+SPACER+'</td><td>')

        showProps.setdefault('layoutInter', SPACER)
        showProps.setdefault('layoutPost','')
        showProps.setdefault('layoutPre','')
        showProps.setdefault('propsFmt','long')

        if showProps.get('delete'):
            s += (self.cpeDeleteLink(request,showProps),)

        if showProps.get('directProps'):
            s += (self.cpeDirectPropsLink(request,showProps),)

        if showProps.get('scenario'):
            s += (self.cpeScenarioLink(request,showProps),)

        if showProps.get('support'):
            s += (self.cpeSupportPortalLink(request,showProps),)

        if showProps.get('tester'):
            s += (self.cpeTesterLink(request,showProps),)

        if showProps.get('ramLog'):
            s += (makeJSImg('log'+self.cpeid, 'infogif', 'Current (RAM) Log of CPE Instance.  LogLevel: %s' % self.logLevel, self.ramLogToHtml(showProps)) ,)

        if showProps.get('log'):
            s += (self.cpeLogLink(request,showProps),)

        if showProps.get('state'):
            s += (makeAJAXImg('props'+self.cpeid, HTML_LIGHT_BY_STATE.get(self.state), CPE_STATES_PRETTY.get(self.state)),)

        if showProps.get('cpeattrs'):
            p = showProps.get("layoutAttrsPre", "")
            for key in showProps.get('cpeattrs'):
                p+=getattr(self, key)+showProps.get("layoutAttrsInter", "&nbsp;")
            p+= showProps.get("layoutAttrsPost", "")
            s += (p,)

        if showProps.get('xmlProps'):
            s += (self.xmlProps(request),)

        if showProps.get('cpeInfo'):
            s += (self.cpeInfoPopup(request, showProps),)

        if showProps.get('markBox'):
            s += (self.cpeMarkBox(request, showProps),)

        if showProps.get('propsList'):
            s += (self.cpeParametersValues(request, showProps),)

        return showProps['layoutPre'] + showProps['layoutInter'].join(s)+showProps['layoutPost']


    def cpeParametersValues(self,request,showProps):
        """Show parameters values"""

        s = "<table>"
        for param in showProps.get('propsList',[]):
            l = param.split(':')
            param = l[0].strip()
            if len(l) == 2:
                prettyId = l[1].strip()
            else:
                prettyId = param

            if not hasattr(self, param):
                try:
                    tr69short = TR69Utils.getVal(param, 'short')
                    val = self.get(tr69short, '-')
                    pval = self.pendingProps.get(tr69short)
                    if pval:
                        val += " (%s)" % pval
                except:
                    val = 'n.a.'
            else:
                val = getattr(self, param, '')
                # special version treatment: make red if unknown:
                if param == 'version' and not self.checkVersionKnown():
                    val = '<font color="grey" title="UnknownVersion"><b>' + val + '</b></font>'

            s += '<tr><td class="propsListKey">%s&nbsp;</td><td class="propsListVal">%s</td></tr>\n'%(prettyId,val)
        return s+"</table>"


    def cpeMarkBox(self, request, showProps):
        """ show the mark box (for highlighting stuff)"""
        return """Mark: <input title="Mark all occurrances of this" type="text" name="mark" value="%s"/>""" % (request.get('mark', ''))


    def cpeDeleteLink(self, request, showProps):
        targeturl = 'manage_cpeinfos'
        if 'index_html' in request.get('HTTP_REFERER',''): # if CPE was deleted by SearchAndProcess Tool
            targeturl = 'index_html'
        s = """<a target="%s" title="delete cpe" onclick="if (confirm('Delete this CPE ?')) {window.location.href='%s?deleteCPE=%s';};"><img border="0" src="delete" alt="deleteCPE"/></a>""" % (showProps.get('target', '_self'), targeturl, self.cpeid)
        return s


    def cpeLogLink(self, request, showProps):
        log_url = request.CM.absolute_url(relative=True)
        s = """<a target="%s" title="database log" href="/%s/manage_objlog?objid=%s">
            <img border="0" src="loggif" alt="Log"/></a>""" \
            % (showProps.get('target', '_self'), log_url, self.cpeid)
        return s


    def cpeDirectPropsLink(self, request, showProps):
        s = """<a target="%s" title="direct properties" href="manage_cpeinfos?viewprops=%s"><img border="0" src="edit" alt="Edit"/></a>""" % (showProps.get('target', '_self'), self.cpeid)
        return s


    def cpeScenarioLink(self, request, showProps):
        # show the link to the scenario tester  :
        s = """<a target="%s" title="scenarios" href="manage_scenario?cpeid=%s&amp;activateRefr=1"><img border="0" src="configure" alt="Scenario"/></a>""" % (showProps.get('target', '_self'), self.cpeid)
        return s


    def cpeSupportPortalLink(self, request, showProps):
        # show the link to the RTS :
        s = """<a target="%s" title="support portal" href="../AXSupportPortal/portal/?cpeid=%s&amp;activateRefr=1"><img border="0" src="supportportal" height="16" alt="Support Portal"/></a>""" % (showProps.get('target', '_self'), self.cpeid)
        return s




    def cpeTesterLink(self, request, showProps):
        # show the link to the scenario tester  :
        # if this is a test, then link to the testsetup:
        if request.CM.meta_type == "AXTestManager":
            sc = getattr(request.PARENTS[0], 'Scenarios')
            for f in self.cpeid.split('.'):
                sc = getattr(sc, f)
            s = """<a target="%s" title="test setup" href="%s/manage"><img border="0" src="tester" alt="tester"/></a>""" % (showProps.get('target', '_self'), sc.absolute_url())
            return s

        return ""


    def cpeInfoPopup(self, request, showProps):
        """ shows the little info button for the popup"""
        s = """<a href="javascript:openPop('Tools/cpePopUp?cpeid=%s', 'cpepopup', 550, 700);"><img src="folder"  border="0" title="Open the CPE TR69 Parameters Popup" alt="infopopup"/></a>""" % self.cpeid
        return s


    def cpeAddLocalPropsPopup(self, request, showProps):
        """ shows the little info button for the popup for the new version"""
        s = """<a href="javascript:openPop('addNewLocalPropsForm?cpeid=%s', 'addLocalProps', 600, 150)"><img title="Version unkown - auto add it"  src="plussmall" border="0" alt=""/></a>""" % self.cpeid
        return s

    def checkVersionKnown(self):
        # should we show the small plus ?
        if TR69Utils.LOCAL_PROPS_BY_TYPE_BY_VERSION.get(self.cpetype, {}).get(self.version) != None:
            return 1

    def xmlProps(self):
        """ shows the hierarchical cpe props with change function - requires some divs in the form where displayed - see AXCPEManager-XMLProperties"""
        #s = """<a href="#" onClick="openPop('addNewLocalPropsForm?cpeid=%s', 'addLocalProps', 600, 150)"><img src="plussmall" border="0" alt=""/></a>""" % self.cpeid
        s = """<a title="change properties" href="javascript:onclick="parseXML('%s')"><img border="0" src="edit" alt="props"/></a>""" % (self.cpeid)
        return s


    def formatProps (self, showProps, filters = []):
        ret = ""
        if not self.isIGD():
            newfilters= []
            for m in filters:
                newfilters.append("D" + m[1:])
            filters=newfilters
        for key in ('cid', 'cid2', 'cpetype','version', 'IP', 'parentID', 'path', 'roles', 'logLevel', 'firstMsg', 'lastMsg', 'protocolVersion',  'nextDue','unmanagedProps', 'pendingProps', 'scProps', 'props', 'comments',  'lastCookie', 'events', 'methods'):
            val = getattr(self, key)
            if key == 'methods' and val:
                val = "%s" % prettyPrintSCs (val, val)

            if key == 'scProps':
                if val:
                    val = PrettyPrinter().make_html(val)

            if key in ['lastMsg', 'firstMsg']:
                val = time.ctime(val)

            if showProps.get('propsFmt') == 'long' and val and (key == 'props' or key == 'pendingProps'):
                if key == 'props':
                    f = filters
                else:
                    f = []
                val = htmlFormatMap (val, showProps,  getTitle, f)
            else:
                val = htmlMark(val, showProps)
            subs = ""
            if key == 'props':
                subs = "&nbsp; <font size='-2'>%s</font>" % filters
            ret += "<hr/><b>%s:&nbsp;</b>%s%s<br/>" % (key, subs, val)
        return ret


    def ramLogToHtml(self, showProps):
        ret = "<a href='manage_log?CPELogID="+self.cpeid+"'><u>Click</u></a> to see the database log<hr/>"
        if len(self.dblog) < 2:
            return ret+"Nothing logged within this session. "
        oldTime = 0
        for i in range(len(self.dblog)-1, -1, -1):
            line = self.dblog[i]
            if line[0] < oldTime - 1:
                ret+="<hr/>"
            oldTime = line[0]
            content = htmlMark(line[2], showProps)
            ret+="<b>%s - %s:</b> %s<br/>" % (str(time.ctime(line[0]))[10:], line[1], content[1:-1].replace('\\n\\t', '<br/>&nbsp;&nbsp;').replace('\\n', '').replace('\\t', ''))
        return ret

    def isIGD(self):
        """
        Is CPE InternteGatewayDevice or Normal
        """
        # we are filling partentID in inform, any cpe with root object Device, 
        # will have not empty parentID. Hopefully nobody used this field
        if self.parentID: return False
        if "I.DI.SN" in self.props: return True
        if "D.DI.SN" in self.props: return False
        return True

    """
    Methods for CPE role
    """
    def hasRole(self, role):
        return role in self.roles

    def addRole(self, role):
        self.roles.append(role)
        self.roles = unique(self.roles)

    def delRole(self, role):
        try:
            self.roles.remove(role)
            self.roles = unique(self.roles)
        except:
            pass

    def clearRoles(self):
        self.roles=[]

    def getEvents(self, ev_code):
        events = getattr(self, 'events', [])
        return [ ev for ev in events if ev_code in str(ev.get('EventCode', ''))]

    def clone(self, cpeid):
        """ Returns a clone of the CPE-Object """
        return CPE(
                self.cid,
                self.cid2,
                cpeid,
                self.cpetype,
                self.path,
                self.version,
                self.IP,
                self.state,
                self.lastMsg,
                self.logLevel,
                simplejson.dumps(tuple(self.unmanagedProps)),
                simplejson.dumps(self.pendingProps),
                self.nextDue,
                self.props,
                self.methods,
                simplejson.dumps(self.comments),
                0,
                self.parentID,
                simplejson.dumps(self.scProps),
                self.firstMsg,
                simplejson.dumps(self.events),
                self.lastCookie,
                 ','.join(self.roles),
                self.protocolVersion,
                self.log)


def unique(seq):
    # order preserving
    noDupes = []
    [noDupes.append(i) for i in seq if not noDupes.count(i)]
    return noDupes


try:
    # security:
    from AccessControl import allow_class
    allow_class(CPE)
except:
    # not in zope but external configurator:
    pass

