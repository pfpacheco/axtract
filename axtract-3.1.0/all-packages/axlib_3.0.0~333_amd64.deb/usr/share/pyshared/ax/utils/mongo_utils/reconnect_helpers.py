import time
import pymongo


def build_call_op_with_reconnect(retries, sleep_time):
    """This function creates a new function to wrap calls to pymongo.
    This wrapper detects if pymongo.error.AutoReconnect is raised.
    In that case the wrapper waits 'sleep_time' and does the query again.
    This retry and sleep is done 'retries' times, then the 'AutoReconnect'
    exception is raised to the caller.

    Example:
    import pymongo

    conn = pymongo.Connection()
    call_op_with_reconnect = build_call_op_with_reconnect(45, 1)

    doc = call_op_with_reconnect(conn['db']['coll'].find_one, {"_id": "foo"})
    """
    _number_of_retries = range(retries)
    def call_op_with_reconnect(op, *args, **kwargs):
        # Do it in this loop because failover can take some time
        # http://docs.mongodb.org/manual/faq/replica-sets
        for _ in _number_of_retries:
            try:
                return op(*args, **kwargs)
            except pymongo.errors.AutoReconnect:
                # cann happen if the replicaset primary is down
                # => wait some time for another server to become primary
                time.sleep(sleep_time)

        # If this raises an AutoReconnect *again* this function can't do
        # anything more. Let the error through => caller can deal with it.
        # The caller needs to deal with database outage anyway.
        return op(*args, **kwargs)

    return call_op_with_reconnect

def build_yield_docs_with_reconnect(retries, sleep_time):
    """This function creates a new one which wraps 'find' calls to pymongo.

    The new function returns a *generator* of mongo-documents.

    This is needed, because pymongo returns a *Cursor* on a find, not connecting
    to mongodb at all. => On a find the traditional 'call_op_with_reconnect'
    does not work. This first hit to mongo is done, as soon as the first element
    is requested from the cursor.

    This function 'peeks' now into the cursors for the first document.
    This 'peek' triggers now a AutoReconnect exception, if the primary has
    changed. In such case the find is rexecuted until the new primary is found
    or the timeout has happened.

    IMPORTANT: It is impossible handle a 'failover to new primary' if the cursor
    is already exhausted a bit. It is impossible to connect to the new primary
    and continue the stream of documents exactly at the same point as on the
    old primary.
    """
    _number_of_retries = range(retries)
    def yield_docs_with_reconnect(op, *args, **kwargs):
        for _ in _number_of_retries:
            # This operation does not raise a AutoReconnect.
            # It just creates a cursor object with no mongo interaction at all.
            cursor = op(*args, **kwargs)

            # Get the first document from the cursor.
            # This connects to mongo now.
            try:
                ob = next(cursor)
            except pymongo.errors.AutoReconnect:
                cursor.close()
                time.sleep(sleep_time)
                continue

            # No AutoReconnect => we have a connection to primary.
            yield ob

            # Break out from the 'try loo' and exhaust the cursor ot the end.
            break

        else:
            # This else of a for-loop is reached if the loop ends 'normaly',
            # wich means *NO* break has happened.
            # In our case it means:
            # "_number_of_retries has reached and still no master found."
            # In that case we do it once again and let the caller deal with the
            # error.
            cursor = op(*args, **kwargs)

        # Iterate over the remaining cursor.
        for doc in cursor:
            yield doc

    return yield_docs_with_reconnect
