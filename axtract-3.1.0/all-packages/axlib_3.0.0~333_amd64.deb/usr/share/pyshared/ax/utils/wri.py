"""
This module contains two versions of a Weighted Round-robin Iterator (WRI)

You can use it if you have a number of servers to which you want to send
requests (round-robin). You can also specify if one of the servers should
get more or less requests (weighted).

You initialize them with an iterable of (item, weight) pairs. Then you can
iterate over those objects. They return a random-looking (but repeating) stream
of the items you provided, keeping exactly the ratio that was defined by the
weights. For example:
    >>> from ax.utils.wri import WRI
    >>> foo = WRI( [("hello", 1), ("world", 2)] )
    >>> for item in foo:
            print item
        world
        world
        hello
        world
        world
        hello
        world
        world
        hello
        ........

The WRI2 class extends this by allowing you to specify that one of the items
is now considered broken. For a specified amount of iterations, the broken
item will not be returned. If you are doing round-robin over servers, that
means you will run into timeouts less frequently, but still keep trying the
formerly broken server every now and then.
"""

class WRI(object):
    """Weighted Round-robin Iterator without support for broken items"""
    def __init__(self, weighted_items):
        self.current_item = 0
        sequencer = _Sequencer(weighted_items)
        self.items = sequencer.find_sequence()

    def __iter__(self):
        return self

    def next(self):
        """Returns next item as part of the iterator protocol
        """
        self.current_item = (self.current_item + 1) % len(self.items)
        return self.items[self.current_item]

class WRI2(WRI):
    """A WRI subclass which keeps track of broken items.
        Items for which you call "report_broken(<item>)" will not be returned
        during iteration because they are considered broken. Every x
        iterations, all information about broken items is forgotten. This
        amount x can be set by the "forget_after" parameter of __init__ or
        at runtime with the "forget_after" property.
    """
    def __init__(self, weighted_items, forget_after=100):
        """Initialize a WRI2 object.
            The $forget_after defines after at most(!!!) how many iterations
            all info about brokenness is discarded (=nothing is considered
            broken any more). On average it is only half that, because
            self.count is most likely not 0 when this happens the first time.
            See self.next() for details.
        """
        super(WRI2, self).__init__(weighted_items)

        self.broken = set()
        # weighted_items could contain duplicates, only count _really_ unique.
        self.num_unique_items = len(set((item[0] for item in weighted_items)))
        self.count = 0
        self.forget_after = forget_after

    def report_broken(self, item):
        """Mark $item as broken for some time.
            Broken items are not returned when you iterate over this object.
        """
        self.broken.add(item)
        if len(self.broken) == self.num_unique_items:
            # All items are broken. We could
            #  * waste CPU by looping many times in self.next(), then forget
            #       all broken items.
            #  * forget all broken items right now (=no waste of CPU).
            self.broken = set()

    def next(self):
        """Returns next item as part of the iterator protocol
        """
        # Could be that almost everything is marked as broken. Don't do
        # recursion in this case, as we might kill the stack. Keep looping
        # until we find a non-broken item or we forget about the brokenness.
        while True:
            self.current_item = (self.current_item + 1) % len(self.items)
            item = self.items[self.current_item]
            if item in self.broken:
                continue

            self.count += 1
            if self.count >= self.forget_after:
                self.count = 0
                if self.broken:
                    self.broken = set()
            return item


class _Sequencer(object):
    """Produces a good item sequence based on given item/weight pairs.

    'Good' means that it avoids unnecessary repetition of an element. E.g. with
            a:2     b:1     c:1
    you don't want to get "abca" or "aabc". Because when repeated, they form
            abcaabcaabca...
    or
            aabcaabcaabc...
    which both contain "aa". If you are sending requests to servers, server "a"
    will get 2 requests in a row. It is better to use the sequence "abac" or
    "acab". When repeated, they translate to
            abacabacabac...
    or
            acabacabacab...
    which does not repeat the "a".
    The implementation inserts the items one by one into the final ordering. At
    each insertion, it applies a metric to figure out which place is the best
    for inserting the current element. This approach alone results in O(n^2)
    time consumption. Considering the list operations, it is actually O(n^3).
    To keep calculation times reasonable, a faster approach is used when
    numbers get bigger, even though that approach is not as good.
    """
    def __init__(self, weight_tuples):
        self.weight_tuples = list(weight_tuples)
        self.reduce_weights()
        # Sort by weight (not item) in ascending order.
        self.weight_tuples.sort(key=lambda x: x[1], reverse=True)
        self.weight_dict = self.weight_tuples_to_dict(self.weight_tuples)

        # This is the length of the result we will produce.
        self.total_weight = sum([weight for item, weight in weight_tuples])

        # Set of items that have already been placed. We only need to calculate
        # scores for these.
        self.items_in_dist = set()

    def weight_tuples_to_dict(self, weight_tuples):
        ret = {}
        for item, weight in weight_tuples:
            # Needs to be float.
            ret[item] = float(weight)
        return ret

    def get_pressure(self, indexes, num_total, expected_distance):
        """Return the pressure for the given indexes

        Only neighboring items are calculated.
        For a really good solution, all itertools.combinations(indexes, 2)
        should be calculated, but this is O(n^2) with n = len(indexes). If
        this was done, most CPU time would be spent here.
        """
        if len(indexes) < 2:
            return 0.0
        pressure = 0.0
        # Compare first element to the last.
        previous = indexes[-1]
        for index in indexes:
            dist1 = (index - previous) % num_total
            dist2 = (previous - index) % num_total
            pressure += expected_distance / min(dist1, dist2)
            previous = index
        return pressure

    def sum_weighted_pressures(self, distribution):
        total_pressure = 0.0
        for item in self.items_in_dist:
            # List of indexes where item can be found.
            indexes = [index for index, listelem in enumerate(distribution)
                    if listelem == item]
            expected_distance = self.total_weight / self.weight_dict[item]
            pressure = self.get_pressure(indexes, len(distribution),
                    expected_distance)
            total_pressure += pressure
        return total_pressure

    def best_extension_index(self, distribution, new_item):
        least_pressure = 2**64
        least_pressure_index = 0
        # len(distribution)+1 would produce another valid index (=end of list),
        # but it is equivalent to 0 (=start of list).
        for possible_index in xrange(0, len(distribution)):
            dist = list(distribution)
            dist.insert(possible_index, new_item)
            pressure = self.sum_weighted_pressures(dist)
            if pressure < least_pressure:
                least_pressure = pressure
                least_pressure_index = possible_index
        return least_pressure_index

    def reduce_weights(self):
        # Check if all weights can be divided by 2, 3, 5, 7. If so, do it. The
        # remaining algorithm is O(n**3), so this time is well invested.
        for divider in (2, 3, 5, 7):
            # Break if any weight cannot be divided by divider
            while not any([weight % divider for item, weight in self.weight_tuples]):
                self.weight_tuples = [(item, weight / divider) for
                        item, weight in self.weight_tuples]

    def dhondt_sequence(self):
        """Emulates the D'Hondt method for assigning seats in parliament

        Not quite perfect for this use-case, but O(n*log(n))ish and better than
        random.shuffle(). To be used if weights are large and cannot be reduced.
        """
        numbers = []
        for item, weight in self.weight_tuples:
            weight = float(weight)
            numbers.extend(
                    [(weight / count, item) for count in
                        xrange(1, self.total_weight + 1)])
        numbers.sort(reverse=True)
        # The first self.total_weight items with the highest numbers.
        retval = [number[1] for number in numbers[:self.total_weight]]
        return retval

    def find_sequence(self):
        if not self.weight_tuples:
            raise ValueError("No weights were given")
        if self.total_weight > 100:
            # self.reduce_weights() was not very successful. Use a faster
            # algorithm to avoid O(n**3).
            return self.dhondt_sequence()

        # Add the first (=most frequent) item blindly. No point in making
        # any calculations here.
        first_item = self.weight_tuples[0][0]
        first_weight = self.weight_tuples[0][1]
        distribution = [first_item] * first_weight
        self.items_in_dist.add(first_item)

        items_to_add = []
        for item, weight in self.weight_tuples[1:]:
            items_to_add.extend([item] * weight)

        for item in items_to_add:
            index = self.best_extension_index(distribution, item)
            distribution.insert(index, item)
            self.items_in_dist.add(item)
        return distribution

class DynamicWRI(object):
    """
    Weighted Round-robin Iterator with support for adding and removing elements on the the fly
    however this flexibility comes at a cost; the initial ground work like weight reduction,
    sequence generation, fair distribution etc. cannot be implemented efficiently or at all. So
    what you get is the most simpleton implementation of WRR.

    Important note: This implementation is NOT thread-safe. Adding locks here may be an overkill,
    find a better solution for multi-threaded implementation (you've been warned ;))
    """
    def __init__(self):
        self.weighted_tuples = []

        # item to be executed next
        self.exec_index = 0

        # execution count(for weight considration)
        self.exec_count = 0

    def __iter__(self):
        return self

    def next(self):
        item = self._next_item()
        if item:
            return item
        else:
            raise StopIteration

    def size(self):
        return len(self.weighted_tuples)

    def add(self, weighted_tuple):
        # allow no duplicates
        for tup in self.weighted_tuples:
            if tup[0] == weighted_tuple[0]:
                return

        # add new tuple in the end
        self.weighted_tuples.append(weighted_tuple)

    def remove(self, item):
        # find index of the item to be deleted
        del_index = 0
        for tup in self.weighted_tuples:
            if tup[0] == item:
                break
            del_index += 1
        else:
            return

        # delete item
        del self.weighted_tuples[del_index]

        # adjust counters
        if del_index == self.exec_index:
            # when an item at the exec_index is deleted, indices are adjusted
            # automatically, just reset the exec_count
            self.exec_count = 0
        elif del_index < self.exec_index:
            # when an item is deleted, indices are adjusted hence adjust
            # the exec index accordingly
            self.exec_index -= 1

        # check if exec_index lies within bounds
        if self.exec_index:
            self.exec_index %= len(self.weighted_tuples)

    def _next_item(self):
        if not self.weighted_tuples:
            return None

        exec_index = self.exec_index

        # increment exec_count and adjust exec_index if weight is reached
        self.exec_count += 1
        if self.exec_count >= self.weighted_tuples[self.exec_index][1]:
            self.exec_count = 0
            self.exec_index += 1
            if self.exec_index >= len(self.weighted_tuples):
                self.exec_index = 0

        # return item
        return self.weighted_tuples[exec_index][0]
