import os
import ctypes
import collections
from itertools import islice

def chunk_iterable(iterable, chunksize, iterlength=None):
    """Chunking iterator for iterables.
        This allows you to cut an iterator into pieces of a predefined size
        and then process them one at a time. Great for bulk database operations
        where you want to e.g. INSERT bulks of up to 100 customers at a time to
        improve performance, but not all 1 million customers in the same query.

        Performance is greatly improved if the iterable supports the len() call
        or if you can provide the length via $iterlength. This parameter also
        allows you to chunkate only part of your iterable, maybe you want to
        send the other half to a different DB...
    """
    if iterlength is None:
        try:
            iterlength = len(iterable)
        except (TypeError, AttributeError):
            # This happens if the iterable has no __len__(). Use the old, slow
            # implementation with lists.
            wrapped_iter = iter(iterable)
            chunk = list(islice(wrapped_iter, chunksize))
            while chunk:
                yield chunk
                chunk = list(islice(wrapped_iter, chunksize))
            return

    # Below you find a variant of the iterator above. It has a much higher
    # performance, but can only work with iterables than have a __len__()
    # function (lists, tuples, sets...) or where the caller can tell us the
    # length with the $iterlength parameter (e.g. dict.iteritems()) . This
    # iterator will also yield iterators again, not lists like chunk_iterable().

    # Performance goes up by 6 times (10 million items, chunksize=10) up to
    # 1200 times (10 million items, chunksize=10000). So performance gain
    # heavily depends on the chunksize, simply because the above code
    # instantiates lists of length $chunksize for each chunk and then
    # garbage collects them. We instead, create a single iterator object. If
    # you turn your iterators into lists again, you will obviously lose the
    # extra performance.

    # When doing "for i in chunk_iterable( [], 42)", the loop should not be
    # entered at all. So nothing is yielded.
    if iterlength == 0:
        return

    # This ensures that  chunk([1,2], 2, 1) only gives us the [1].
    if iterlength <= chunksize:
        # Do not manually slice here, e.g. like iterable[:iterlength]. This
        # fails for $iterlength==0.
        yield islice(iterable, 0, iterlength)
        return
    wrapped_iter = iter(iterable)

    # This part produces the pieces of length $chunksize
    for chunk_count in xrange(0, iterlength / chunksize):
        yield islice(wrapped_iter, chunksize)

    # This will produce a piece of length>0 and length<$chunksize.
    # The leftovers if you will.
    # Special case here:
    #   chunk([1,2,3,4,5], 2, 3) should give us [1,2] and [3]
    # The size of the last chunk is given by $modulus.
    modulus = iterlength % chunksize
    if modulus != 0:
        yield islice(wrapped_iter, modulus)


def set_procname(name):
    libc = ctypes.cdll.LoadLibrary("libc.so.6")
    PR_SET_NAME = 15
    libc.prctl(PR_SET_NAME, str(name), 0, 0, 0)


def set_parent_death_signal(sig):
    """If the parent process of us dies, the kernel sends 'sig' to us"""
    libc = ctypes.cdll.LoadLibrary("libc.so.6")
    PR_SET_PDEATHSIG = 1
    libc.prctl(PR_SET_PDEATHSIG, sig, 0, 0, 0)


def get_resident_memory(pid=None):
    """Returns the resident memory of a process (in bytes)

    If pid is None RES of the current process will be returned.
    Otherwise RES of the specified pid will be returned
    """

    if pid is None:
        pid = os.getpid()

    name = "/proc/%s/statm" % pid
    if not os.path.isfile(name):
        raise Exception("Unable to access %s for memory information" % name)

    with open(name) as fd:
        try:
            rss = int(fd.readline().split()[1])
        except Exception as error:
            raise Exception("Cannot parse %s: %s" % (name, error))

    return rss * os.sysconf("SC_PAGE_SIZE")


class ProcessLocal(collections.MutableMapping):
    def __init__(self):
        self._store = collections.defaultdict(dict)

    def __getitem__(self, key):
        return self._store[os.getpid()][key]

    def __setitem__(self, key, value):
        self._store[os.getpid()][key] = value

    def __delitem__(self, key):
        del self._store[os.getpid()][key]

    def __iter__(self):
        return iter(self._store[os.getpid()])

    def __len__(self):
        return len(self._store[os.getpid()])

    def __contains__(self, key):
        return key in self._store[os.getpid()]
