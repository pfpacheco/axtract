import types
import inspect
import threading
# WOHO i love python for that
# Make all method calls to an object 'thread'-safe with a Lock

def thread_safe_call(unbound_fun):
    # create the new function (fun is the closure value)
    def new_func(self, *args, **kwargs):
        self.lock.acquire()
        try:
            return unbound_fun(self, *args, **kwargs)
        finally:
            self.lock.release()
    return new_func

def thread_safe_call_bound_method(bound_fun):
    def new_func(self, *args, **kwargs):
        self.lock.acquire()
        try:
            return bound_fun(*args, **kwargs)
        finally:
            self.lock.release()
    return new_func


def _my_is_method(obj):
    check1 = inspect.ismethod(obj)
    # grrrr methods of C-Excetions appear as BUILTINS !! what da hell
    check2 = inspect.isbuiltin(obj)
    return check2 or check1

class ThreadSafeProx(object):
    """
    Important:
     * No!! attributes are proxied, only methods
     * No!! __* method are proxied
    """
    def __init__(self, obj):
        # This is the lock we access in the wrapper
        self.lock = threading.RLock()

        for name, method in inspect.getmembers(obj, _my_is_method):
            if not name.startswith("__"):
                # Method must be from type MethodType to have the
                # 'self'-argument aviable in the wrapper
                new_meth = types.MethodType(
                                thread_safe_call_bound_method(method),
                                self,
                                ThreadSafeProx)

                # Assing the wrapper to us
                setattr(self, name, new_meth)
