""" Module that helps with condition checking - primary use for transport.py

parsing parametrizations of anything a client -> server interaction could run
into is a tedious thing - it's done here:
"""

import re
# we assume that the condition checks (for prompts and other
# server or library returns) which are parsed into
# python objects like lambda functions doing condition checks
# in read_until_condition are finite.

# So it makes sense to cache them within this map:
# If a subclass does not want this it can overwrite
# /not use the parse_condition function:
CONDITION_OBJ_CACHE = {}
CONDITION_PARSER_CACHE = {}


def check_condition (data, condition, **kwargs):
    """
    This is used heavily inside here, when reading from the transport
    but also for error_prompt checking from outside.

    The check procedure must match the condition obj built below!
    By default we just APPLY the condition object, assuming
    it's a lambda functions:
    """
    if type(condition) in (str, unicode):
        condition, meta_terminator = build_condition_object(condition)
    return condition(data, **kwargs)



def build_condition_object(condition):
    """ helper for check_condition """
    # Split what we have into $plain_terminator, $regexp_terminator and
    # $eval_terminator.
    cached_condition_obj = CONDITION_OBJ_CACHE.get(condition)
    if cached_condition_obj:
        return cached_condition_obj

    # the number of conditions parsed must be matched here:
    cmap = parse_condition (condition)
    (plain_terminator,
     plain_match,
     regexp_terminator,
     eval_terminator,
     meta_terminator) = (
            cmap.get('plain'),
            cmap.get('plain_match'),
            cmap.get('regexp'),
            cmap.get('eval'),
            cmap.get('meta')
                )

    # Create $condition1 from $plain_terminator.
    condition1 = None
    if plain_match:
        if plain_match == 'in':
            condition1 = lambda data, **kwargs: plain_terminator in data
        elif plain_match == 'starts':
            condition1 = lambda data, **kwargs: data.startswith(
                                                              plain_terminator)
        elif plain_match == 'ends':
            condition1 = lambda data, **kwargs: data.endswith(plain_terminator)
        elif plain_match == 'is':
            condition1 = lambda data, **kwargs: data == plain_terminator
    if not condition1:
        condition1 = lambda data, **kwargs: 0

    # Create $condition2 from $regexp_terminator.
    if regexp_terminator is None:
        condition2 = lambda data, **kwargs: 0
    else:
        condition2 = lambda data, **kwargs: regexp_terminator.search(data)

    # Create $condition3 from $eval_terminator.
    if eval_terminator is None:
        condition3 = lambda data, **kwargs: 0
    else:
        #FIXME: Could not pass the caller_obj (e.g. the transport) into the
        #       lambda function!
        # to do sth with it in the checking:
        condition3 = lambda data, **kwargs: \
            eval(eval_terminator)

    # Create big condition.
    big_condition = (lambda data, **kwargs:
            condition1(data, **kwargs) or \
            condition2(data, **kwargs) or \
            condition3(data, **kwargs),
            meta_terminator)
    CONDITION_OBJ_CACHE[condition] = big_condition
    return big_condition


def parse_condition (value):
    """
        Parses a general condition string (a prompt or until statment)
        Returns a tuple of two elements:
        First entry is either an object that is suitable for passing to
        self.read_until_condition or one of the special values
        UNTIL_EOF, UNTIL_TIMEOUT or NO_READ. UNTIL_EOF/TIMEOUT are also
        suitable for passing to self.transport.read_until_condition and
        will read as much as they can. When an exception is raised, you
        have to react accordingly.
        Second entry is a textified version for logging, since the
        function in the first entry is not really informative for this
        purpose.

        Only one of $until and $prompt may have a value, the other must
        be None. If both are None, $prompt defaults to $self.prompt. If
        $prompt is given, $self.prompt is set to $prompt.
        The parameter must be a string having one of the following forms:
            <plain_terminator>
            <plain_terminator>|Re: <regexp_terminator>
            <plain_terminator>|Eval: <eval_terminator>

        <plain_terminator> may be the empty string, which means it is
        ignored. The <plain_terminator> may start with "/A" and/or end
        with "/Z". This means it will only match at the beginning (/A)
        or end (/Z) of the string. If both are provided, it means the
        string must be identical to <plain_terminator>. If none is given,
        it will match anywhere in the string.

        <regexp_terminator> must be a regular expression, it will be
        passed to re.compile(). It will be applied using re.search(),
        not using re.match()!

        <eval_terminator> will be passed to eval(), giving it the full(!)
        globals. That includes a "data" variable containing the freshly
        read data from the CPE. It also have a $handler (this
        object) and $transport (which is this object's transport).

        The following special values exist for $until:
            "/NOREAD"
            "/EOF"
            "/TIMEOUT"
        "/NOREAD" means that no read is performed at all. "/EOF" means
        that reading should be done until the other side closes the
        connection, "/TIMEOUT" will read until a timeout occurs. In both
        cases, the expected event is _not_ considered to be an error,
        which means no exception is raised.

    """
    pc = CONDITION_PARSER_CACHE.get(value)
    if pc:
        return pc

    plain_terminator = regexp_terminator = \
    eval_terminator = meta_terminator = None

    ret = {}
    CONDITION_PARSER_CACHE[value] = ret

    if "|Meta: " in value:
        value, ret['meta'] = value.split("|Meta: ", 1)
    if "|Eval: " in value:
        value, ret['eval'] = value.split("|Eval: ", 1)
    if "|Re: " in value:
        value, regexp_terminator = value.split("|Re: ", 1)
        ret['regexp'] = re.compile(regexp_terminator)

    plain_terminator = value
    plain_match = ''
    if value:
        ret['plain_value'] = value
        if value.startswith("/A"):
            if value.endswith("/Z"):
                plain_match = 'is'
                plain_terminator = plain_terminator[2:-2]
            else:
                plain_match = 'starts'
                plain_terminator = plain_terminator[2:]
        elif value.endswith("/Z"):
            plain_match = 'ends'
            plain_terminator = plain_terminator[:-2]
        else:
            plain_match = 'in'
        ret['plain'] = plain_terminator
        ret['plain_match'] = plain_match
    return ret
