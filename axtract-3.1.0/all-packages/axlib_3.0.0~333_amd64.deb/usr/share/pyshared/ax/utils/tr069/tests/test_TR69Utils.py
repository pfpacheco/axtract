import unittest2
from time import time

from ax.utils.tr069.TR69Utils import SHORT69_LOOKUP_CACHE
from ax.utils.tr069.TR69Utils import convertPropToCorrectRootObject
from ax.utils.tr069.TR69Utils import parse_global_properties
from ax.utils.tr069.TR69Utils import TR69_SECOND_NODES, getValRoot
from ax.utils.tr069.TR69Utils import pack_short69_to_long69, get_pendant_pack
from ax.utils.tr069.TR69Utils import pack_long69_to_short69, getVal, autoLong
from ax.utils.tr069.TR69Utils import getVersionStringFromLong69, autoShort
from ax.utils.tr069.TR69Utils import TR69_LOOKUP_CACHE, buildSPVArgument
from ax.utils.tr069.TR69Utils import buildGPVArgument, replaceSpecialChars
from ax.utils.tr069.TR69Utils import get_short69_by_long69, isIndex
from ax.utils.tr069.TR69Utils import get_long69_by_short69
from ax.utils import package_home
from ax.utils.tr069.TR69Utils import TR69 as TR69Imported
from ax.utils.tr069.TR69Utils import SHORT69 as SHORT69Imported

from mock import MagicMock

# we have some xml files here:
CWD = package_home(globals())
TEST_XML_FOLDER = CWD + '/xmlfiles'
# adapt on changes in the xml files:
# we have 1606 + 1 in small2.xml created in the cache tests
TOTAL_VARS = 1984

I = 'InternetGatewayDevice'

class TR069UtilsTest(unittest2.TestCase):
    class PropertiesSingleton (object):
        def __new__ (cls):
            if not "TR069" in dir (cls):
                cls.TR069 = parse_global_properties(TEST_XML_FOLDER)

            return cls


    def setUp (self):
        self.TR069 = self.PropertiesSingleton ().TR069


    def test_imports_exist(self):
        # are the global maps filled?
        self.assertIn('InternetGatewayDevice', TR69Imported)
        self.assertIn('I', SHORT69Imported)

    def test_x_to_nr(self):
        res = getValRoot('I.S.VS.1.VP.2.FT.E')
        self.assertEqual (res["tr69"],
                "InternetGatewayDevice.Services.VoiceService.x.VoiceProfile.x.FaxT38.Enable")


    def test_filename (self):
        AXP = 'InternetGatewayDevice.AxirosAxess.CpeHandler.Axpand.'
        node = getVal ('I.')
        self.assertEqual (node["file"], "multi")
        node = getVal ('I.WD.1.WCD.1.WC.0.EIA')
        self.assertEqual (node["file"], "TR69")
        node = getVal (AXP + 'Transport.HandShake.AutoClose')
        self.assertEqual (node["file"], "axiros")
        node = getVal ('InternetGatewayDevice.OldNode')
        self.assertEqual (node["file"], "small, small2")
        

    def test_getval_root_objects (self):
        res = getVal ('.WD.1.WCD.1.WC.0.EIA')
        self.assertEqual (res["tr69"],
                ".WANDevice.x.WANConnectionDevice.x.WANPPPConnection.x.ExternalIPAddress")

        res = getVal ('I.WD.1.WCD.1.WC.0.EIA')
        self.assertEqual (res["tr69"],
                "InternetGatewayDevice.WANDevice.x.WANConnectionDevice.x.WANPPPConnection.x.ExternalIPAddress")

        res = getVal ('D.WD.1.WCD.1.WC.0.EIA')
        self.assertEqual (res["tr69"],
                "Device.WANDevice.x.WANConnectionDevice.x.WANPPPConnection.x.ExternalIPAddress")


    def test_getval_specific_objects (self):
        res = getVal ('.WD.1.WCD.1.WC.0.EIA', "long")
        self.assertEqual (res,
                ".WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0.ExternalIPAddress")

        res = getVal ('I.WD.1.WCD.1.WC.0.EIA', "long")
        self.assertEqual (res,
                "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0.ExternalIPAddress")

        res = getVal ('D.WD.1.WCD.1.WC.0.EIA', "long")
        self.assertEqual (res,
                "Device.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0.ExternalIPAddress")

        res = getVal ('.WD.1.WCD.1.WC.0.EIA', "short")
        self.assertEqual (res,
                '.WD.1.WCD.1.WC.0.EIA')

        res = getVal ('I.WD.1.WCD.1.WC.0.EIA', "short")
        self.assertEqual (res,
                'I.WD.1.WCD.1.WC.0.EIA')

        res = getVal ('D.WD.1.WCD.1.WC.0.EIA', "short")
        self.assertEqual (res,
                'D.WD.1.WCD.1.WC.0.EIA')

        res = getVal ('.WD.1.WCD.1.WC.0.EIA', "pendant")
        self.assertEqual (res,
                ".WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0.ExternalIPAddress")

        res = getVal ('I.WD.1.WCD.1.WC.0.EIA', "pendant")
        self.assertEqual (res,
                "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0.ExternalIPAddress")

        res = getVal ('D.WD.1.WCD.1.WC.0.EIA', "pendant")
        self.assertEqual (res,
                "Device.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0.ExternalIPAddress")

        res = getVal ("Device.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0.", "pendant")
        self.assertEqual (res,
                'D.WD.1.WCD.1.WC.0.')

        res = getVal ("Device.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0", "pendant")
        self.assertEqual (res,
                'D.WD.1.WCD.1.WC.0')


    def test_getvalroot_specific_objects (self):
        with self.assertRaises (ValueError):
            res = getValRoot ('.WD.1.WCD.1.WC.0.EIA', "long")

        res = getValRoot ('I.WD.1.WCD.1.WC.0.EIA', "long")
        self.assertEqual (res,
                "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0.ExternalIPAddress")

        with self.assertRaises (ValueError):
            res = getValRoot ('D.WD.1.WCD.1.WC.0.EIA', "long")

        with self.assertRaises (ValueError):
            res = getValRoot ('.WD.1.WCD.1.WC.0.EIA', "short")

        res = getValRoot ('I.WD.1.WCD.1.WC.0.EIA', "short")
        self.assertEqual (res,
                'I.WD.1.WCD.1.WC.0.EIA')

        with self.assertRaises (ValueError):
            res = getValRoot ('D.WD.1.WCD.1.WC.0.EIA', "short")

        with self.assertRaises (ValueError):
            res = getValRoot ('.WD.1.WCD.1.WC.0.EIA', "pendant")

        res = getValRoot ('I.WD.1.WCD.1.WC.0.EIA', "pendant")
        self.assertEqual (res,
                "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0.ExternalIPAddress")

        with self.assertRaises (ValueError):
            res = getValRoot ('D.WD.1.WCD.1.WC.0.EIA', "pendant")

        with self.assertRaises (ValueError):
            res = getValRoot ("Device.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0.", "pendant")

        with self.assertRaises (ValueError):
            res = getValRoot ("Device.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0", "pendant")


    def test_len(self):
        # adapt on changes:
        self.assertIn(len(self.TR069), (TOTAL_VARS,))


    def test_second_nodes(self):
        sns = []
        for p in self.TR069.keys():
            if not '.' in p:
                continue

            sn = p.split('.')

            if len(sn) > 0:
                if not sn[1] in sns:
                    sns.append(sn[1])

        for k in sns:
            self.assertIn(k, TR69_SECOND_NODES)

        self.assertEqual(len(sns), len(TR69_SECOND_NODES))


    def test_units(self):
        # unit is only for GUIs, template ready:
        self.assertEqual(
                self.TR069['InternetGatewayDevice.OldNode']['unit'],
                'Unit: Kcal/mol')


    def test_index_handling(self):
        self.assertEqual(
                getVal('D.WD.1.WCD.1.WC.0.EIA'),
                getVal('D.WD.2.WCD.2.WC.2.EIA')
                )
        self.assertEqual(
                getVal('D.WD.12345.WCD.1.WC.0.EIA'),
                getVal('D.WD.x.WCD.2.WC.3.EIA')
                )


    def test_index_error(self):
        with self.assertRaises (ValueError):
            getVal('D.WD.-12345.WCD.1.WC.0.EIA')


    def test_blank_in_parametername (self):
        with self.assertRaises (ValueError):
            getVal('D.WD. 1.WCD.1.WC.0.EIA')

        with self.assertRaises (ValueError):
            a = "InternetGatewayDevice. ManagementServer.ConnectionRequestUsername"
            get_short69_by_long69 (a)


    def test_isIndex(self):
        self.assertEqual (isIndex ('-12345'), False)
        self.assertEqual (isIndex ('i12345'), True)
        self.assertEqual (isIndex ('12345'), True)


    def test_get_short69_by_long69 (self):
        a = "InternetGatewayDevice.ManagementServer.ConnectionRequestUsername"
        self.assertEqual (get_short69_by_long69 (a), "I.MS.CRUs")

        a = "Device.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0.ExternalIPAddress"
        self.assertEqual (get_short69_by_long69 (a), "D.WD.1.WCD.1.WC.0.EIA")

        a = "InternetGatewayDevice.ManagementServer.ConnectionRequestUsername"
        self.assertEqual (get_short69_by_long69 (a),
                get_short69_by_long69 (get_short69_by_long69 (a)))

        a = "Device.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0.ExternalIPAddress"
        self.assertEqual (get_short69_by_long69 (a),
                get_short69_by_long69 (get_short69_by_long69 (a)))

        a = "."
        self.assertEqual (get_short69_by_long69 (a), ".")

        a = "Device.WANFooDevice."
        with self.assertRaises (ValueError):
            get_short69_by_long69 (a)

        # TODO: Shouldn't this be considered a bug?
        a = "Device.WANDevice.x.WANConnectionDevice.1.WANPPPConnection.0.ExternalIPAddress"
        self.assertEqual (get_short69_by_long69 (a), "D.WD.WCD.1.WC.0.EIA")

        # TODO: Shouldn't this be considered a bug?
        a = ""
        with self.assertRaises (IndexError):
            get_short69_by_long69 (a)


    def test_get_long69_by_short69 (self):
        a = "I.MS.CRUs"
        self.assertEqual (get_long69_by_short69 (a), 
                "InternetGatewayDevice.ManagementServer.ConnectionRequestUsername")

        a = "D.WD.1.WCD.1.WC.0.EIA"
        self.assertEqual (get_long69_by_short69 (a),
                "Device.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0.ExternalIPAddress")

        a = "I.MS.CRUs"
        self.assertEqual (get_long69_by_short69 (a), 
                get_long69_by_short69 (get_long69_by_short69 (a)))

        a = "D.WD.1.WCD.1.WC.0.EIA"
        self.assertEqual (get_long69_by_short69 (a), 
                get_long69_by_short69 (get_long69_by_short69 (a)))

        a = "."
        self.assertEqual (get_long69_by_short69 (a), ".")

        a = "D.WFD."
        with self.assertRaises (ValueError):
            get_long69_by_short69 (a)

        # TODO: Shouldn't this be considered a bug?
        a = "D.WD.x.WCD.1.WC.0.EIA"
        self.assertEqual (get_long69_by_short69 (a), 
                "Device.WANDevice.WANConnectionDevice.1.WANPPPConnection.0.ExternalIPAddress")

        # TODO: Shouldn't this be considered a bug?
        a = ""
        with self.assertRaises (IndexError):
            get_long69_by_short69 (a)


    def test_value_error(self):
        with self.assertRaises(ValueError):
            getVal('I.FuckedUp')
        with self.assertRaises(ValueError):
            getVal('D.WD.1.WCD.1.WC.EIA')
        with self.assertRaises(ValueError):
            getVal('D.WD.-1.23.WCD.1.WC.0.EIA')


    def test_getVal(self):
        eq = self.assertEqual
        eq(getVal('D.WD.1.WCD.1.WC.0.EIA',
            'short'), 'D.WD.1.WCD.1.WC.0.EIA')
        eq(getVal('D.WD.1.WCD.1.WC.0.EIA',
            'long'), ("Device.WANDevice.1.WANConnectionDevice.1."
            "WANPPPConnection.0.ExternalIPAddress"))
        node = getVal('D.WD.1.WCD.1.WC.0.EIA')
        self.assertEqual (isinstance (node, dict), True)
        eq(not node['islist'], True)
        eq(node['unit'], None)
        eq(node['file'], 'TR69')
        eq(node['tr69'],
             ('Device.WANDevice.x.WANConnectionDevice.x.'
              'WANPPPConnection.x.ExternalIPAddress'))
        eq(node['short69'], 'D.WD.x.WCD.x.WC.x.EIA')
        self.assertIn('IP address', node['TR_description'])
        eq(node['write'], '-')
        eq(node['readOnly'], 1)
        eq(node['emptyfromcpe'], None)
        eq(node['typeLength'], '')
        self.assertGreater(int(node['id']), 0)
        self.assertGreater(int(node['size']), 0)


    def test_parseAxirosXMl(self):
        """ are the secondary/failover transport param lists set? """
        AXP = 'InternetGatewayDevice.AxirosAxess.CpeHandler.Axpand.'
        # A list of all nodes to check for similar child nodes. The commented
        # parts did not qualify to be cloned as per the automatic cloning code
        # so they're just here as reference.
        pril = [AXP + 'Transport.AAA.User',
            # AXP + 'Transport.AAA.AllowedCmds',
            AXP + 'Transport.DataExchange.Flow.PreFlow',
            AXP + 'Transport.HandShake.AutoProlog',
            # AXP + 'Transport.HandShake.DirectSettings',
            AXP + 'Transport.Control.TransportDebugFlag',
            AXP + 'Transport.FileWriting.ResetAtConnect',
            AXP + 'Transport.Control.TransportGroups.SleepTime',
            AXP + 'Transport.Http.Html.Host',
            AXP + 'Transport.CwmpTR069.DoHistory',
            AXP + 'Transport.AAA.Password',
            AXP + 'Transport.Control.ViaClassSearchFolders',
            AXP + 'Transport.Http.Html.Data',
            AXP + 'Transport.CwmpTR069.ModelUri',
            AXP + 'Transport.FileWriting.FormatTemplate',
            AXP + 'Transport.Control.TransportGroups.RetryBackoffFactor',
            AXP + 'Transport.Process',
            AXP + 'Transport.Control.TransportGroups.HistorySize',
            AXP + 'Transport.DataExchange.Condition',
            AXP + 'Transport.Http.Soap',
            AXP + 'Transport.Control',
            AXP + 'Transport.CwmpTR069',
            AXP + 'Transport.DataBase.Sql.DataBase',
            # AXP + 'Transport.AAA.AllowedCmdSubs',
            AXP + 'Transport.DataExchange.MaxData',
            AXP + 'Transport.Http.Html.NeutralizeScripts',
            AXP + 'Transport.Control.ConnectionIdent',
            AXP + 'Transport.Http.Html.Cookies',
            AXP + 'Transport.FileWriting.TargetFile',
            AXP + 'Transport.Control.TransportGroups.ExceptionPolicies',
            AXP + 'Transport.Http',
            AXP + 'Transport.Control.TransportGroups.GroupSize',
            AXP + 'Transport.AAA.DefaultUser',
            AXP + 'Transport.HandShake.Epilog',
            AXP + 'Transport.DataBase.Sql',
            AXP + 'Transport.Control.TransportGroups.WaitResults',
            AXP + 'Transport.DataExchange.CmdOutro',
            AXP + 'Transport.Socket',
            AXP + 'Transport.DataBase',
            # AXP + 'Transport.AAA.AllowedArgs',
            AXP + 'Transport.Process.Command',
            AXP + 'Transport.Icmp.PacketSize',
            AXP + 'Transport.HandShake',
            AXP + 'Transport.Control.TransportGroups',
            AXP + 'Transport.CwmpTR069.Params',
            AXP + 'Transport.AAA.DefaultPassword',
            AXP + 'Transport.Control.TransportGroups.RetrySecs',
            AXP + 'Transport.HandShake.Prolog',
            AXP + 'Transport.Http.Html',
            AXP + 'Transport.CwmpTR069.CpeIp',
            AXP + 'Transport.AAA',
            AXP + 'Transport.Control.TransportGroups.CommCalls',
            AXP + 'Transport.Socket.Port',
            AXP + 'Transport.CwmpTR069.Events',
            AXP + 'Transport.Control.TransportGroups.Active',
            AXP + 'Transport.DataExchange.CmdIntro',
            AXP + 'Transport.FileWriting.MaxFileSize',
            AXP + 'Transport.DataExchange.ErrorCondition',
            AXP + 'Transport.Http.Soap.WsdlUrl',
            AXP + 'Transport.CwmpTR069.AcsUrl',
            AXP + 'Transport.Socket.Host',
            AXP + 'Transport.Control.TransportGroups.Background',
            AXP + 'Transport.FileWriting',
            AXP + 'Transport.Control.InitCodeURI',
            AXP + 'Transport.DataExchange.Flow.PostFlow',
            # AXP + 'Transport.AAA.AllowedArgsSubs',
            AXP + 'Transport.Control.TransportGroups.ExceptionRecoverSecs',
            AXP + 'Transport.DataExchange.Timeout',
            AXP + 'Transport.CwmpTR069.Serial',
            AXP + 'Transport.Control.ConnectedPoolSize',
            AXP + 'Transport.Http.Html.Sid',
            AXP + 'Transport.Control.TransportGroups.ConnectAtStart',
            AXP + 'Transport.DataExchange.Flow',
            AXP + 'Transport.Control.Via',
            AXP + 'Transport.FileWriting.Flush',
            AXP + 'Transport.DataExchange',
            AXP + 'Transport.Control.TransportType',
            AXP + 'Transport.HandShake.AutoClose',
            AXP + 'Transport.Icmp']

        for p in pril:
            s = p.replace (".Transport.", ".TransportsSecondary.x.")
            self.assertTrue (p in self.TR069, "%s not in TR-069 properties" % p)
            self.assertTrue (s in self.TR069, "%s not in TR-069 properties" % s)
            pri = self.TR069[p]
            sec = self.TR069[s]
            self.assertEqual(pri['short69'], sec['short69'].replace('S.x', ''))


    def test_map_pack_ops(self):
        m = {'D.WD.1.WCD.1.WC.0.EIA': 1, 'D.WD.2.WCD.1.WC.0.EIA': 2}
        self.assertEqual(pack_short69_to_long69(m),
            {('Device.WANDevice.2.WANConnectionDevice.1.WANPPPConnection.0'
              '.ExternalIPAddress'): 2,
              ('Device.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0'
               '.ExternalIPAddress'): 1})
        m = {'D.WD.1.WCD.1.WC.0.EIA': 1, '.WD.2.WCD.1.WC.10.EIA': 2}
        self.assertEqual(pack_short69_to_long69(m),
            {('.WANDevice.2.WANConnectionDevice.1.WANPPPConnection.10'
              '.ExternalIPAddress'): 2,
              ('Device.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0'
               '.ExternalIPAddress'): 1})

        self.assertEqual(
                pack_long69_to_short69(pack_short69_to_long69(m)),
                m)


    def test_pack_short69_to_long69_error (self):
        m = {'D.WD.1.WCD.x.WC.0.EIA' : 1, 'D.WD.2.WCD.a.WC.0.EIA': 2}
        with self.assertRaises (ValueError):
            pack_short69_to_long69 (m)


    def test_pendant_ops (self):
        m = {'D.WD.1.WCD.1.WC.0.EIA' : 1, 'D.WD.2.WCD.1.WC.0.EIA': 2}
        self.assertEqual(
                pack_long69_to_short69 (pack_short69_to_long69 (m)),
                get_pendant_pack (m, True, mode = 'short'))

        self.assertEqual(
                pack_short69_to_long69 (m),
                get_pendant_pack (m, True, mode = 'long'))

        self.assertEqual(
                pack_short69_to_long69 (m),
                get_pendant_pack (m, False, mode = 'long'))

        with self.assertRaises (Exception):
                get_pendant_pack (m, True,  mode = 'foo')

        m1 = {"I.MS.CRUs" : 1, "I.MS.CRF" : 2}
        m2 = {"InternetGatewayDevice.ManagementServer.ConnectionRequestUsername" : 1}
        self.assertEqual (get_pendant_pack (m1, True, mode = 'long'), m2)

        with self.assertRaises (Exception):
            self.assertEqual (get_pendant_pack (m1, False, mode = 'long'), m2)

        m1 = {"I.MS.CRUs" : 1}
        m2 = {
                "InternetGatewayDevice.ManagementServer.ConnectionRequestUsername" : 1,
                "InternetGatewayDevice.ManagementServer.ConnectionRequestFart" : 2
             }
        self.assertEqual (get_pendant_pack (m2, True, mode = 'short'), m1)

        with self.assertRaises (Exception):
            self.assertEqual (get_pendant_pack (m2, False, mode = 'short'), m1)


    def test_pendant_ops_long_short_mixed (self):
        m1 = {"I.MS.CRUs" : 1,
              "InternetGatewayDevice.ManagementServer.ConnectionRequestPassword" : 2
             }
        m2 = {
                "InternetGatewayDevice.ManagementServer.ConnectionRequestUsername" : 1,
                "InternetGatewayDevice.ManagementServer.ConnectionRequestPassword" : 2
             }
        self.assertEqual (get_pendant_pack (m1, False, mode = 'long'), m2)

        m1 = {"I.MS.CRUs" : 1,
              "InternetGatewayDevice.ManagementServer.ConnectionRequestUsername" : 1,
              "InternetGatewayDevice.ManagementServer.ConnectionRequestPassword" : 2
             }
        m2 = {
                "InternetGatewayDevice.ManagementServer.ConnectionRequestUsername" : 1,
                "InternetGatewayDevice.ManagementServer.ConnectionRequestPassword" : 2
             }
        self.assertEqual (get_pendant_pack (m1, True, mode = 'long'), m2)


    def test_version(self):
        self.assertEqual(getVersionStringFromLong69({}), 'NA__NA__NA')

        with self.assertRaises (AssertionError):
            getVersionStringFromLong69 ("")

        m = {'I.DI.SV': 'SW', 'I.DI.HV': 'HW'}
        self.assertEqual(getVersionStringFromLong69(
            pack_short69_to_long69(m)), 'SW__HW__NA')

        m = {'D.DI.SV': 'SW', 'D.DI.HV': 'HW'}
        self.assertEqual(getVersionStringFromLong69(
            pack_short69_to_long69(m)), 'SW__HW__NA')

        m = {'I.DI.SV': """'/.,?><\';|":!@#$%^&*()_}{PO|":LK'"""}
        v = getVersionStringFromLong69(pack_short69_to_long69(m))
        self.assertEqual(v, """'_.,?><';|":@#$%^&*___}{PO|":LK'__NA__NA""")

        m = {'D.DI.SV': 'SW', 'D.DI.HV': 'HW', 'D.DI.SpV' : "1.1"}
        self.assertEqual (getVersionStringFromLong69 (
            pack_short69_to_long69(m)), 'SW__HW__1.1')


    def test_replace_special_chars (self):
        s = "a!b"
        self.assertEqual (replaceSpecialChars (s), "ab")

        s = "a b"
        self.assertEqual (replaceSpecialChars (s), "ab")

        s = " a b"
        self.assertEqual (replaceSpecialChars (s), "ab")

        s = "a b "
        self.assertEqual (replaceSpecialChars (s), "ab")

        s = "a)b"
        self.assertEqual (replaceSpecialChars (s), "a_b")

        s = "a(b"
        self.assertEqual (replaceSpecialChars (s), "a_b")

        s = "a(b)"
        self.assertEqual (replaceSpecialChars (s), "a_b_")

        s = "a\\b"
        self.assertEqual (replaceSpecialChars (s), "a_b")

        s = "a/b"
        self.assertEqual (replaceSpecialChars (s), "a_b")

        s = "   "
        self.assertEqual (replaceSpecialChars (s), "")


    def test_conversions(self):
        """  in the xml: conversions="Foo: Bar, NoMatch:no"
        -> Foo replaced with Bar w/o shorting of it:"""
        self.assertEqual(
                self.TR069['InternetGatewayDevice.AaBbSome.Foo.Node']['short69'],
                'I.ABS.Bar.N')
        self.assertEqual(
                self.TR069[I + '.AaBbSomeOther.x.Foobar.CoolNode']['short69'],
                'I.ABSO.x.Bar.YN')


    def test_var_cache(self):
        """ lookups are cached """
        SHORT69_LOOKUP_CACHE.clear()
        TR69_LOOKUP_CACHE.clear()
        pack_long69_to_short69(self.TR069)
        self.assertEqual(len(TR69_LOOKUP_CACHE), TOTAL_VARS)
        m = {'D.WD.1.WCD.1.WC.0.EIA': 1, '.WD.2.WCD.1.WC.10.EIA': 2}
        pack_short69_to_long69(m)
        self.assertEqual(len(SHORT69_LOOKUP_CACHE), 2)


    def test_convertRoot(self):
        v = convertPropToCorrectRootObject('D.WD.1.WCD.1.WC.0.EIA', isIGD=1)
        self.assertEqual(v, 'I.WD.1.WCD.1.WC.0.EIA')

        v = convertPropToCorrectRootObject('D.WD.1.WCD.1.WC.0.EIA', isIGD=0)
        self.assertEqual(v, 'D.WD.1.WCD.1.WC.0.EIA')

        v = convertPropToCorrectRootObject('I.WD.1.WCD.1.WC.0.EIA', isIGD=1)
        self.assertEqual(v, 'I.WD.1.WCD.1.WC.0.EIA')

        v = convertPropToCorrectRootObject('I.WD.1.WCD.1.WC.0.EIA', isIGD=0)
        self.assertEqual(v, 'D.WD.1.WCD.1.WC.0.EIA')

        # Short-cuts for better reading tests
        conv = convertPropToCorrectRootObject
        name = '.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0'

        v = conv('Device' + name, isIGD=1)
        self.assertEqual(v, I + name)

        v = conv('Device' + name, isIGD=0)
        self.assertEqual(v, 'Device' + name)

        v = conv(I + name, isIGD=1)
        self.assertEqual(v, I + name)

        v = conv(I + name, isIGD=0)
        self.assertEqual(v, 'Device' + name)

        # Test it with no root object in front
        v = conv('.WD.1.WCD.1.WC.0.EIA', isIGD=1)
        self.assertEqual(v, 'I.WD.1.WCD.1.WC.0.EIA')

        v = conv('.WD.1.WCD.1.WC.0.EIA', isIGD=0)
        self.assertEqual(v, 'D.WD.1.WCD.1.WC.0.EIA')

        v = conv(name, isIGD=1)
        self.assertEqual(v, I + name)

        v = conv(name, isIGD=0)
        self.assertEqual(v, 'Device' + name)

    def test_buildSPVArgument (self):
        cpe = MagicMock ()
        cpe.pendingProps = {'I.S.VS.1.VP.2.FT.E' : 1}
        cpe.isUnmanaged = lambda k: False
        i, v = buildSPVArgument(cpe, cpe.pendingProps)
        self.assertEqual (i, {'I.S.VS.1.VP.2.FT.E': 1})
        self.assertEqual (v, [{'Name': 'InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.2.FaxT38.Enable', 'Value': 1, 'Type': 'boolean'}])


    def test_buildGPVArgument (self):
        props = ['I.S.VS.1.VP.2.FT.E']
        args = buildGPVArgument (props)
        self.assertEqual (args,
                ['InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.2.FaxT38.Enable'])

        props = ['I.S.VS.1.VP.2.FT.E', 'I.S.VS.1']
        args = buildGPVArgument (props)
        self.assertEqual (args,
                ['InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.2.FaxT38.Enable',
                    'InternetGatewayDevice.Services.VoiceService.1'])

        props = ['I.S.VS.1', 'I.S.VS.1.VP.2.FT.E']
        args = buildGPVArgument (props)
        self.assertEqual (args,
                ['InternetGatewayDevice.Services.VoiceService.1',
                    'InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.2.FaxT38.Enable'])

        props = ['I.S.VS.1.', 'I.S.VS.1.VP.2.FT.E']
        args = buildGPVArgument (props)
        self.assertEqual (args,
                ['InternetGatewayDevice.Services.VoiceService.1.'])

        props = ['I.S.VS.1.VP.2.FT.E', 'I.S.VS.1.']
        args = buildGPVArgument (props)
        self.assertEqual (args,
                ['InternetGatewayDevice.Services.VoiceService.1.'])

        props = ['I.S.', 'I.']
        args = buildGPVArgument (props)
        self.assertEqual (args, ['InternetGatewayDevice.'])

        props = ['I.S.', 'I.', 'I.S.VS.1.VP.2.FT.E']
        args = buildGPVArgument (props)
        self.assertEqual (args, ['InternetGatewayDevice.'])

        # TODO: Shouldn't this be considered a bug?
        props = ['I.S.', 'I.',
                'InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.2.FaxT38.Enable']
        args = buildGPVArgument (props)
        self.assertEqual (args, ['InternetGatewayDevice.',
            'InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.2.FaxT38.Enable'])

        props = ['InternetGatewayDevice.',
                'InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.2.FaxT38.Enable']
        args = buildGPVArgument (props)
        self.assertEqual (args, ['InternetGatewayDevice.'])

        props = []
        args = buildGPVArgument (props)
        self.assertEqual (args, [])

        props = ['']
        args = buildGPVArgument (props)
        self.assertEqual (args, [''])

        props = ('')
        args = buildGPVArgument (props)
        self.assertEqual (args, [''])


    def test_auto_long(self):
        s = {'I.DI.SV': 'SW', 'I.DI.HV': 'HW'}
        l = {'InternetGatewayDevice.DeviceInfo.HardwareVersion': 'HW', 'InternetGatewayDevice.DeviceInfo.SoftwareVersion': 'SW'}
        self.assertEqual (autoLong (l), l)
        self.assertNotEqual (autoLong (s), s)
        self.assertEqual (autoLong (s), l)
        self.assertEqual (autoLong ({}), {})


    def test_auto_short(self):
        s = {'I.DI.SV': 'SW', 'I.DI.HV': 'HW'}
        l = {'InternetGatewayDevice.DeviceInfo.HardwareVersion': 'HW', 'InternetGatewayDevice.DeviceInfo.SoftwareVersion': 'SW'}
        self.assertNotEqual (autoShort (l), l)
        self.assertEqual (autoShort (s), s)
        self.assertEqual (autoShort (l), s)
        self.assertEqual (autoShort ({}), {})


    def test_zope_compatibility (self):
        node = getVal ('I.')
        self.assertEqual (type (node), type (dict (node)))
        node = getValRoot('I.S.VS.1.VP.2.FT.E')
        self.assertEqual (type (node), type (dict (node)))


if __name__ == '__main__':
    unittest2.main(verbosity=2)

"""
Leaving it in as a ref, as long the deps are tested:


class Foo:

    from time import time
    TR69 = parse_global_properties('/etc/axess'+'/TR69')

    print getVal('D.WD.1.WCD.1.WC.0.EIA', 'short')
    print getVal('.WD.1.WCD.1.WC.0.EIA', 'short')
    print "fff"

#    print getVal('InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0.ExternalIPAddress', 'long')
#    print getVal('Device.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0.ExternalIPAddress', 'long')
#    print getVal('.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0.ExternalIPAddress', 'long')

    class CPE:

        short69_deps = {
      #'I.WD.1.WCD.1.WC': {'fixedIndex': 'd101', 'depValue': 'Internet',     'description': 'Data uplink', 'depKey': 'N'},\
      'I.WD': {'fixedIndex': 'd301', 'depValue': 'default', 'description': 'Super Node matching', 'depKey': 'WCD.x.WC.x.N'},\
      'I.WD.1.WCD.1.WC': {'fixedIndex': 'd200', 'depValue': 'default',     'description': 'Data uplink', 'depKey': 'N'}\
     }

        props = pack_long69_to_short69( {'InternetGatewayDevice.WANDevice.1.WANConnectionDevice.2.WANPPPConnection.35.IdleDisconnectTime' : 0
     ,'InternetGatewayDevice.WANDevice.1.WANConnectionDevice.2.WANPPPConnection.35.RSIPAvailable': 1
     ,'InternetGatewayDevice.WANDevice.1.WANConnectionDevice.2.WANPPPConnection.35.NATEnabled' : 1
     ,'InternetGatewayDevice.WANDevice.1.WANConnectionDevice.2.WANPPPConnection.35.Name' : 'default'
     ,'InternetGatewayDevice.WANDevice.1.WANConnectionDevice.2.WANPPPConnection.35.PortMappingNumberOfEntries' : 0
     ,'InternetGatewayDevice.WANDevice.1.WANConnectionDevice.2.WANPPPConnection.35.Username' : '1und1/2854-813@online.de'
     ,'InternetGatewayDevice.WANDevice.1.WANConnectionDevice.2.WANPPPConnectionNumberOfEntries' : 1
     ,'InternetGatewayDevice.WANDevice.1.WANConnectionDevice.8.WANDSLLinkConfig.ATMEncapsulation' : 'VCMUX'
     ,'InternetGatewayDevice.WANDevice.1.WANConnectionDevice.8.WANDSLLinkConfig.ATMMaximumBurstSize' : 0},1)

    #i = getDepIndex( 'I.WD' , CPE())
    cpe = CPE()
    setDependentCPEProps(cpe)
    cpe.pendingProps = {'I.WD.d301.WCD.x.WC.x.PMNOE':2}
    #i , v = buildSPVArgument(cpe, cpe.pendingProps)
    i = 9

    try:

        assert getVal('InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0.ExternalIPAddress', 'short') ==\
                'I.WD.1.WCD.1.WC.0.EIA'
        assert getVal('InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.1.Name', 'short')== \
                   'I.WD.1.WCD.1.WC.1.N'
        assert getVal ('I.WD.1.WCD.1.WC.1.N', 'long') == \
                   'InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.1.Name'
    except Exception, e:
        raise Exception, "Error in TR69Utils.getVal: %s " % e

    s = getVal ('InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.0.ExternalIPAddress', 'short')
    s = getVal ('InternetGatewayDevice.DeviceInfo.ProvisioningCode', 'short')

    s = getVal('InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.3', 'pendant')
    #s2 = getVal(s)

    pendingProps = {'1.telseyVoIP.i2.1.i3.1.2': 'new', '1.1.i1.1.i1.1.d100.1': 'foo'}
    props = {'1.1.i1.1.i1.1.i1.1':'ppoe', '1.1.i1.1.i1.1.i1.3': 'Internet'}

    cpe = CPE('cid','cid2', 'cpeid','cpetype','path','version','IP','state', 'lastMsg', 'logLevel', '', pendingProps, props, '', '', log = None)
    GPV = getGPV(cpe.pendingProps)
    # must be:
    # [u'InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.']

    SPV = setSPVArgument(cpe)

    i = 9
    if s2.get('short69') != s.get('short69'):
        raise "parsing problems"
    t = time()
    i = get_long69_by_short69 ("1.2.TR104_34.1_23.1.3")
    t2 =  time() - t
    t = time()
    i = get_long69_by_short69 ("1.2.TR104_34.1_23.1.3")
    t3 =  time() - t
    print t2 / t3 # about 10 times faster the second time
    i = pack_short69_to_long69 ({'1.3.4': 'foo'})
    i = 9
    i = getVal('1.1_1.1_1.1_1.1', 'short69', None)
    pass
"""
