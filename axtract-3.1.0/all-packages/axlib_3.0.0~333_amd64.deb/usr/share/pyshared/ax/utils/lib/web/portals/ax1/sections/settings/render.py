
from ax1.django_tools import render_request
import yaml


SUBSECTS = yaml.load("""
- Profile
- Skin:
  - Slate: ax_settings_skin?skin=slate
  - Cyborg: ax_settings_skin?skin=cyborg
  - xxxborg: ax_settings_skin?skin=cyborg
  - Cyborg Default: ax_settings_skin?skin=cyborg_def
  - Spaceleb: ax_settings_skin?skin=spacelab
- Settings: link3
""")

def get_subsections(context):
    return SUBSECTS
    # also supported - calling like #ax_settings_foo:
    # return ['foo', 'bar', 'baz']


def render_Profile(r, s, ctx, uri, app):
    # that easy:
    return '<script>alert("yes, this is dynamic js");</script>profile content'


def render_skin(r, s, ctx, uri, app):
    # yes, also js:
    skin = r.form.get('skin')
    dflt = ''
    if '_' in skin:
        dflt = '-default'
    return """
    <script type="text/javascript">
        ss = document.getElementById('stylesheet');
        ss.href = ss.href.split('bootstrap/css/')[0] + 'bootstrap/css/%s/bootstrap%s.css';
    </script>""" % (skin.split('_', 1)[0], dflt)


def render_settings(r, s, ctx, uri, app):
    return 'ab1'
    tmpl = 'ax1/sections/settings/main.html'
    return render_request(r, tmpl, ctx)
