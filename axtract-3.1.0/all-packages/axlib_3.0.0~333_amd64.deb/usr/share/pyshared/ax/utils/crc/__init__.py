"""
Wrapper around the Crc module that is much easier to use.

Example usage:
>>> from ax.utils.crc import CrcCalculator
>>> calc = CrcCalculator()
>>> print calc.crc16("123456789")
>>> print hex(calc.crc16("123456789"))[2:].upper()
"""

from crc_algorithms import Crc

class CrcCalculator(object):
    """Wrapper around the Crc module"""
    def __init__(self):
        """Set up the crc.algorithms.Crc instances and calculation methods"""

        # Crc instance for calculating CRC-16. Add more objects as needed.
        self._crc16_calc = Crc(width=16, poly=0x8005, reflect_in=True,
                xor_in=0x0000, reflect_out=True, xor_out=0x0000)

        # Calculation method, similar to what zlib provides for CRC-32. But
        # in contrast to zlib, this one returns UNsigned integers.
        self.crc16 = self._crc16_calc.bit_by_bit_fast

