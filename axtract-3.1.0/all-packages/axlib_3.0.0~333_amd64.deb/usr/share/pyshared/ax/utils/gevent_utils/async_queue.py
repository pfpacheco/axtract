import socket
from ax.utils.ax_queue import AXQueue
from ax.utils.ax_queue import Full


"""This implements a queue which

- can be feed by a ordinary thread
- can be consumed by a thread running the gevent main loop

So its a bridge between a threaded environment and a single thread running
gevent inside.

* On the 'put()' side only one ordinary thread is allowed
* On the 'get()' side only one thread is allowed running the gevent loop
"""

class IncomingQueue(object):
    def __init__(self, maxsize=0):
        self._queue = AXQueue(maxsize)
        self.sender, self.receiver = socket.socketpair()

        # Wrapp the receiving side with a gevent socket.
        # Lazy import, bause gevent can only be imported in one thread.
        import gevent.socket
        self.receiver = gevent.socket.socket(_sock=self.receiver)

    def get(self):
        self.__wait()
        return self._queue.get(block=False)

    def put(self, item):
        self._queue.put(item, block=True)
        self.__notify()

    def __notify(self):
        self.sender.sendall('x')

    def __wait(self):
        self.receiver.recv(1)


"""This implements a queue which

- can be feed by any number of greenlets
- can be consumed from one/multiple ordinary threads

So its like a queue above, just with sided flipped.
* On the 'put()' only greenlets are allowed
* On the 'get()' side only ordinary threads are allowed.
"""


class OutgoingQueue(object):
    def __init__(self, maxsize=0):
        import gevent
        self.waiting_count = 0

        self._queue = AXQueue(maxsize)
        self._green_sleep = gevent.sleep

    def get(self):
        return self._queue.get(block=True)

    # This is a 'green put' => Call it ONLY from greenlets
    def put(self, item):
        # Yes its busy waiting, but it slows down as soon as more greenlets wait
        # on it.
        self.waiting_count += 1
        try:
            while True:
                try:
                    self._queue.put(item, block=False)
                    return
                except Full:
                    self._green_sleep(0.0005 * self.waiting_count)
        finally:
            self.waiting_count -= 1

    # This is a 'threading put' => Never call it from greenlets.
    def put_from_thread(self, item):
        self._queue.put(item, block=True)
