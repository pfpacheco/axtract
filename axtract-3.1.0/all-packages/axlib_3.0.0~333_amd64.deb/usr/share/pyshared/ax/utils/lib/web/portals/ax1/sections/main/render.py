from ax1.django_tools import render_request


def render_main(r, s, ctx, uri, app):
    tmpl = 'ax1/sections/main/main.html'
    return render_request(r, tmpl, ctx)
