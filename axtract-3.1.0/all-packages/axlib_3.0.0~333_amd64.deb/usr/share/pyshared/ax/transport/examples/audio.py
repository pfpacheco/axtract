#!/opt/axess/bin/call_with_eggs
"""
Example for Model usage. Defined is a model for cisco.IOS
"""

import logging, sys
# set to DEBUG if needed:
logging.basicConfig(level=logging.DEBUG)

from ax.transport import axpand
from ax.utils.tr069 import TR69Utils
from pprint import pformat
# read in all xml definition files:
# root object:
R = 'InternetGatewayDevice'

#IP = 'aida.axiros.com'
IP = '217.111.58.25'

#import pdb; pdb.set_trace()
t = axpand.get_transport_object(
 'audiocodes.ACCLI_IGD', settings={'via': 'ssh',
                        'user': 'Admin',
                        'password': 'a3211',
                        'enable_pass': 'Admin',
                        'invoke_shell': 1,
                        'page_fwd': '--MORE--',
                        'condition': '# /Z|Re: --MORE--',
                        'host': IP,
                        'port': 22,
                        'allowed_cmds': None,
                        'prolog': "/F:LIB:ac_ena_ssh",
                        'model': 'audiocodes.ACCLI_IGD'
                       })
# direct commands still work:
import pdb; pdb.set_trace() 
res = t.model.GetParameterValues('InternetGatewayDevice.', t)
print res
