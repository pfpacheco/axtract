"""Implementation of a http based interaction """
import logging
import gzip
import StringIO
from ax.transport.base import \
        ErrorConditionException, ConnectionClosedException,\
        TransportException, TimeoutException
from ax.transport.connected_transport import ConnectedGetter
from ax.utils.lib.web.poster.encode import multipart_encode
from ax.utils.lib.web.poster.streaminghttp import register_openers
import urllib, urllib2, httplib
from urlparse import urlparse, parse_qsl
import re
from ax.utils.formatting.html import rewrite_links, neutralize_script_tags

# multipart boundaries, for sure compliant with broken
# CPEs web frontends:
MP_BOUNDS = "---------------------------500782188657821123753799505"

logger = logging.getLogger( __name__)
req = None


class HTTP(ConnectedGetter):
    """
    Using urllib2
    """

    identification     = "%(host)s"
    allowed_args       = None
    allowed_cmds       = None
    host               = None
    data               = ''
    neutralize_scripts = True
    enable_cookies     = True
    follow_redirects   = True
    handle_multipart   = False
    proxy              = None
    auth               = None
    user               = None
    password           = None
    get_http_errs      = 1
    # strange characters w/o that and the client can't handle it as well
    # if not set to ignore:
    # client has to set it:
    # handle_unicode = 'ignore'
    handle_unicode = None

    def open_connection (self):
        if not self.host.startswith('http'):
            self.host = 'http://' + self.host
        if self.host.endswith('/'):
            self.host = self.host[:-1]

        if not self.handle_multipart:
            logger.debug("adding multipart support")
            if self.proxy:
                if not self.proxy.startswith('http'):
                    self.proxy = 'http://' + self.proxy
                proxy_handler = urllib2.ProxyHandler({
                    'http': self.proxy, 'https': self.proxy})
                conn_obj = urllib2.build_opener(proxy_handler)
            else:
                conn_obj = urllib2.build_opener()
        else:
            conn_obj = register_openers()

        if self.enable_cookies:
            logger.debug("adding cookie support")
            conn_obj.add_handler(urllib2.HTTPCookieProcessor())

        if self.follow_redirects:
            logger.debug("adding redirect support")
            conn_obj.add_handler(urllib2.HTTPRedirectHandler())

        if self.auth:
            if not self.user or not self.password:
                raise  TransportException("Need user and password to authenticate")
            pwdmgr = urllib2.HTTPPasswordMgrWithDefaultRealm()
            pwdmgr.add_password(None, self.host, self.user, self.password)
            if 'digest' in self.auth:
                logger.debug("adding digest auth support")
                conn_obj.add_handler(urllib2.HTTPDigestAuthHandler(pwdmgr))
            if 'basic' in self.auth:
                logger.debug("adding basic auth support")
                conn_obj.add_handler(urllib2.HTTPBasicAuthHandler(pwdmgr))

        return conn_obj

    # FXIME: TWILL !
    def communicate(self, cmd, conn_obj, condition,\
            error_condition, timeout, data=None, headers={}, **kwargs):

        global POSTER_IS_REGISTERED

        url = self.get_url(cmd)
        logger.info("calling %s", url)

        # maybe supplied quoted already, as a string:
        post_data = kwargs.get('post_data', None)
        if 'file_upload' in kwargs:
            logger.info("this is a multipart upload")
            client_headers = headers
            post_data, headers = multipart_encode(data, boundary= MP_BOUNDS)
            headers.update(client_headers)
        elif data is not None:
            try:
                post_data = urllib.urlencode(data)
            except TypeError:
                # try to post data as is, maybe from proxy
                post_data = data

        logger.debug("posting %s", str(post_data)[:1000])
        try:
            # try http://sun.de -> 302 fails with host hard in:
            pass
            #del headers['host']
        except:
            pass
        # if post_data = None this is a GET, POST otherwise:
        req = urllib2.Request(url=url, data=post_data, headers=headers)
        if 0 and 'file_upload' in kwargs:
            resp = urllib2.urlopen(req, timeout=timeout)
        else:
            # the cookie handler takes care of sending any
            # cookies previously gotten
            try:
                resp = conn_obj.open(req, timeout=timeout)
            except urllib2.URLError, ex:
                if 'time' in str(ex):
                    raise TimeoutException(ex)
                if self.get_http_errs and hasattr(ex, 'code'):
                    return self.get_return_dict(ex)
                err = str(ex)
                if self.proxy:
                    err = 'Using proxy %s: %s' % (self.proxy, err)
                raise TransportException(ex_str=err)

        r_data = self.preprocess(resp)
        # can be set via /LOAD switch:
        if hasattr(self, 'parse_response'):
            r_data = self.parse_response(self, r_data, cmd, **kwargs)

        if self.neutralize_scripts and type(r_data) in (str, unicode):
            r_data = neutralize_script_tags(r_data)
        if self.handle_unicode:
            r_data = unicode(r_data, errors = self.handle_unicode)
        logger.info("response code %s", resp.code)
        if logger.level <= logging.DEBUG:
            ppstr = str(r_data)
            logger.debug("received %s", ppstr[:1000] + (ppstr[1000:] and '...'))
        return self.get_return_dict(resp, r_data=r_data)

    def preprocess(self, resp):
        r_data = resp.read()
        if resp.headers.get('content-encoding', '').find('gzip') >= 0:
            compressed = StringIO.StringIO(r_data)
            gzipper = gzip.GzipFile(fileobj=compressed)
            r_data = gzipper.read()
            del resp.headers['content-encoding']
        return r_data


    def get_return_dict(self, resp, r_data='', headers_dict=None):
        try:
            r_data = r_data or resp.read()
        except Exception, ex:
            raise TransportException(ex)

        return {'status' : resp.code,
                'reason' : resp.msg,
                'headers': resp.headers.items(),
                'data'   : r_data}

    def get_url(self, cmd):
        """does not much anymore, can replace"""
        l_cmd = cmd.lower()
        if not l_cmd.startswith('http://') and not l_cmd.startswith('https://'):
            if not self.host.endswith('/') and not cmd.startswith('/'):
                if cmd:
                    cmd = '/' + cmd
            cmd = self.host + cmd
        p = urlparse(cmd)
        port = ''
        if p.port:
            port = ':%s' % p.port
        server = '%s%s' % (p.hostname, port)
        q = ''
        if p.query:
            q = '?%s' % urllib.urlencode(parse_qsl(p.query))
        url = '%s://%s%s%s' % (p.scheme, server, urllib.quote(p.path), q)
        return url


    def fmt_html_pretty(self, ret_as, cmd, res, spec = None):
        """ Fixing relative and absolute links, removing shell formatting """
        # called from flow_handler if a client wants it
        data = res['data']
        data = data.replace('\t', '').replace('\n', '')
        data = rewrite_links(self.get_url(cmd), data)
        res['data'] = data
        return res



