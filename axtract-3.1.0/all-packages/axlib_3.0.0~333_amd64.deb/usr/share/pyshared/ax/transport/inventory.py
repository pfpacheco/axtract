from ax.utils.dynamic_objects.class_loader import find_class_in_subdirs
import ax.transport

# these are just registered to save the find_class_in_files
# would work w/o registry as well:
bases = {
'gevent':   {'via': 'ax.transport.via.gevent_socket.GeventSocketTelnetter'},
'mysql':    {'via': 'ax.transport.via.mysqldb.MySQLClient'},
'snmp':     {'via': 'ax.transport.via.snmp.PyNetSnmp'},
'tr069':    {'via': 'ax.transport.via.tr069.tr069.TR069'},
'http':     {'via': 'ax.transport.via.http.HTTP'},
'http2':    {'via': 'ax.transport.via.http2.HTTP2'},
'xmlrpc':   {'via': 'ax.transport.via.xmlrpc.XMLRPC'},
'pexpect':  {'via': 'ax.transport.via.pexpecter.PexpectTelnetter'},
'popen':    {'via': 'ax.transport.via.popen.Popen'},
'popen2':   {'via': 'ax.transport.via.popen_comm.PopenComm'},
'soap':     {'via': 'ax.transport.via.soap.SOAPClient'},
'ftp':      {'via': 'ax.transport.via.ftp.FTPClient'},
'socket':   {'via': 'ax.transport.via.tcp_socket.PythonSocketTelnetter'},
'file':     {'via': 'ax.transport.via.file.FileWriter'},
'telnet':   {'via': 'ax.transport.via.telnet_lib.PyTelnetLib'},
'redis_pubsub': {'via': 'ax.transport.via.redis_pubsub.RedisPubSub'},
'ssh':      {'via': 'ax.transport.via.ssh_paramiko.Paramiko'},
'cnr':      {'via': 'ax.transport.via.cnr.CNR'},
'cache':    {'via': 'ax.transport.via.cache.Cache'},
'explore':  {'via': 'ax.transport.via.explore.Explore'},
'group':    {'via': 'ax.transport.via_transport_group.TransportGroup'},
# servers:
'publisher':{'via': 'ax.transport.servers.publisher.Publisher'},
'fifoproc':  {'via': 'ax.transport.servers.fifo_processor.FifoProcessor'},
            }


def check_inventory(name, where = None):
    """ we search for $name in the folders given in $where"""
    if name in bases:
        # caching:
        return bases[name]
    if '.' in name:
        # the name is already given full with module path
        return

    if not where:
        where = []
    if type(where) in (str, unicode):
        where = [where]
    # look in the system paths first:
    for t_sys in ('/via/', '/vendors/'):
        axpand_t_path = ax.transport.__path__[0] + t_sys
        if not axpand_t_path in where:
            where.insert(0, axpand_t_path)

    for p in where:
        fn = find_class_in_subdirs(name, p, case_aware = None)
        if fn:
            bases[name] = {'via': fn, 'path': p}
            return check_inventory(name)




