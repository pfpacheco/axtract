"""Implementation of a SocketTelnetter using the gevent module.

Note that gevent can only be imported in a single thread. This means
you cannot "import GeventSocketTelnetter ...... start_a_thread()" since
that would mean gevent is imported in 2 threads. It also means that
there can only be exactly 1 thread that uses this module.

If you really want to scale up with this, it probably makes sense to use a
gevent greenlet pool and have the greenlets instantiate this class. You
will need to adapt the limit of open file descriptors in that case, as
the default limits you to <1024 concurrent connections. Edit
/etc/security/limits.conf for that and read limits.conf(5).
"""
from ax.transport.base import ConnectionClosedException, TimeoutException
from ax.transport.generic_socket import SocketTelnetter
try:
    from gevent import socket
except ImportError:
    raise ImportError("You need to 'apt-get install python-gevent'")

class GeventSocketTelnetter(SocketTelnetter):
    """Implementation of a SocketTelnetter using the gevent module
    """
    _socket_module = socket

    def send_data(self, data, conn_obj):
        super(GeventSocketTelnetter, self).send_data(data, conn_obj)
        try:
            conn_obj.sendall(data)
        except socket.error, exc:
            # Maybe the other side has closed the connection
            raise ConnectionClosedException(str(exc))
