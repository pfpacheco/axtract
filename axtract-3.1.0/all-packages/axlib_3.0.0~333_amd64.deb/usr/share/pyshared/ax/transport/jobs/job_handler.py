#!/usr/bin/python

############################
#
# Execution of Queued Jobs
#
############################

from ax.utils.config_mgmt.py_configurable import AXDaemonCfg
from ax.utils.config_mgmt.ConfigManager import get_cluster_hosts, get_cfg_vals
from ax.daemon import daemon
from os import getpid, path, system, unlink
from ast import literal_eval
from time import sleep
from socket import gethostname
from thread import start_new_thread
import logging
from ax.transport.jobs.queue_worker import Worker, listen_pubsub,\
        SYSTEM_STATS_KEY

from ax.utils.redis.client import RedisClient, REDIS_PORT
# system layout: one map
from ax.transport.jobs.queue_worker import SL, REDIS0
from ax.transport.jobs.async import shutdown_all
try:
    from yaml import load as yaml_load
except:
    print "No yaml support. Run apt-get install python-yaml."


WORKERS = {}


# SL(system layout), might be queried by clients:
# contains also the whole config:
SL['pid']       = getpid()
SL['hostname']  = gethostname()

ld = '/var/log/axess/jobs/'
if not path.exists(ld):
    system('mkdir -p %s' % ld)



class AxpandJobHandler(daemon.AxDaemon, AXDaemonCfg):
    from os import getpid

    # [c] Config file to try reading from / dumping into:
    config_file = '/opt/plugins.ax/services/config.py'

    # [q] Which queues we are listening at. "q1:3, q2" listens with 3 threads at q1
    # and with default (--worker_threads) on q2
    # State '-' to disable listening to jobs.
    my_queues = []

    # [S] Servers to connect to. If empty we check /etc/hosts and connect to all
    # configured nodes there. You may specify like '<ip|host>:<port>' to
    # connect to this port. Autodetection if the server is requiring SSL is
    # given.
    # Comma separated entries.
    servers = []

    # [w] Default number of worker threads per mq per server.
    # Can be overwritten via -q
    worker_threads = 10

    # Don't start a dedicated process queue listener
    no_proc_queue = 0

    # When do stats expire. Renewed on any collect run from a client
    stats_expiry = 86400

    # How much stats sets do we keep
    stats_items = 1000

    # Format for statistics groups.
    # "host:11.1.1.1, via:*" will check first for match on the host param the
    # on the via.
    # "*" will name the group with the value replaced, i.e. you get groups
    # via:ssh, via:telnet, ... from via:*
    stats_format = 'via:*'

    # [P] HTTP port, for local commands and proxy jobs
    http_port = None

    # [H] HTTP proxy server.
    http_proxy = '127.0.0.1'

    # Use this cert file to authenticate against an SSL server
    cert = None

    # startup jobs. Filename with job spec or direct: yaml or python list or map
    startup_jobs = None

    # Name of this daemon in the logfiles:
    daemon_name = 'AXJobHandler (%s)' % getpid()

    # [l] Our logfile:
    log_file = '/var/log/axess/jobs/job_handler.log'


    def __init__(self):
        self.initialize_cfg()
        super(AxpandJobHandler, self).__init__()
        # cope with the f*** up:
        self.reinit()
        self.redirect_print = False

    def run(self):
        self.info('starting poller threads')
        # thread nr:
        t_nr = -1
        servers = SL['servers'].items()
        if self.my_queues != ['-']:
            # start pubsub listening if we have at least one real queue:
            for ip, hostlist in servers:
                self.info('starting pubsub <- %s' % ip)
                start_new_thread(listen_pubsub, (ip, self.logger))

        for mq, qprops in SL['queues'].items():
            threads = qprops['threads']
            if mq == '-':
                # no real connection, just worker thread:
                for t in xrange(threads):
                    t_nr += 1
                    w = Worker(t_nr, '-', mq, self.logger)
                    WORKERS[t_nr] = w
                    # allow shutdown via this thread:
                    w.daemon = True
                    w.start()
                continue

            # Per queue connect to all(!) servers:
            # we pick really by queue and not from all queues,
            # since we can't impose prios. Only the clients can.
            for ip, hostlist in servers:
                if not ip in REDIS0:
                    # redis connection to db 0 - writing back into user sessions:
                    # all threads share this connection for a specific server
                    REDIS0[ip] = RedisClient(host=ip, cert=SL['cert'])

                self.info('poll from queue %s at %s (%s) with threads: %s'\
                        % (mq, ip, ', '.join(hostlist), threads))
                # start count worker threads per queue and target:
                for t in xrange(threads):
                    if mq == SYSTEM_STATS_KEY:
                        raise Exception("cannot use queue with name '%s'" \
                                % SYSTEM_STATS_KEY)
                    else:
                        t_nr += 1
                        w = Worker(t_nr, ip, mq, self.logger)
                        WORKERS[t_nr] = w
                        # allow shutdown via this thread:
                        w.daemon = True
                        w.start()

        # run all startup jobs in jobfile:
        # (that could include starting servers)
        jf = self.startup_jobs
        if jf:
            # is it a fs path?
            jf = str(jf)
            if path.exists(jf):
                with open(jf) as f:
                    jobs = f.read()

                if jf.startswith('/tmp/tmp_start_job_'):
                    # startspec created by a 'ASNC:STARTPROC job -> delete it:
                    unlink(jf)
            else:
                jobs = self.startup_jobs

            if not type(jobs) in (list, dict):
                try:
                    jobs = yaml_load(jobs)
                except Exception:
                    try:
                        jobs = literal_eval(jobs)
                    except Exception:
                        pass
            if type(jobs) == dict:
                jobs = [jobs]
            if not type(jobs) == list:
                raise Exception("Can't handle startup jobs: %s" % jobs)
        else:
            jobs = []

        if SL.get('http_port'):
            # starting a http server thread:
            jobs.append({
                'cmd': '/ASNC:STARTTHREAD',
                'pool_id': 'JobHTTPProxy',
                'settings': {
                    'via': ('ax.transport.servers.threaded_http_server.'
                            'AxThreadedHTTPServer'),
                    'http_proxy': SL.get('http_proxy', None),
                    'model': 'servers.http.HTTP_TO_MQProxy',
                    'port': SL['http_port'],
                }})

        for nr in xrange(len(jobs)):
            # run sequnetially, using the 0th thread:
            self.logger.info('Running startup job %s' % jobs[nr])
            WORKERS[0].run_job('startup_%s' % nr, jobs[nr])

        try:
            self.logger.info('Entering main loop')
            while 1:
                # waiting for guidos eventloop:
                sleep(0.1)
                if self.shutdown_requested:
                    # all subprocs and threads:
                    shutdown_all()
                    break
        finally:
            self.info("ending job handler")


    def parse_cli_configfile(self):
        # we can tolerate if file is not there:
        pass

    def define_command_line(self):
        self.option_parser = self.setup_optparse()

    def load_configuration(self):
        try:
            self.reconfigure(self.options.config_file)
        except IOError:
            print 'No config file'
        #self.optparse(self.option_parser)
        self.optparse()


    def setup(self):
        super(AxpandJobHandler, self).setup()
        # set our config state:
        SL.update(self.get_state_map(main_only=1))

        # better format:
        log_format = "%(asctime)s %(levelname)5s %(name)5s %(message)s"
        if self.logger.handlers:
            formatter = logging.Formatter(log_format)
            self.logger.handlers[0].setFormatter(formatter)

        qs_list = self.my_queues
        if not qs_list:
            qs_list = get_cfg_vals('MyMQs', ordered=1)

        # the one to listen for jobs only for this proces:
        if not self.no_proc_queue and not qs_list == ['-']:
            qs_list.append('proc')
        pid_host = '%(pid)s@%(hostname)s' % SL

        qs = {}
        for cq in qs_list:
            if ':' in cq:
                mq, threads = cq.split(':')
                threads = int(threads.strip())
            else:
                mq, threads = cq, self.worker_threads
            mq = mq.strip()
            if mq == 'proc':
                mq = 'proc:' + pid_host
            if not mq in qs:
                qs[mq] = {'threads': threads, 'stats': {}}

        SL['queues'] = qs
        SL['qs_str'] = ','.join(qs.keys()).replace(':' + pid_host, '')

        # by default we connect to all hosts in /etc/hosts:
        # like  {'1.1.1.1': ['nb01']}
        cfg_servers = get_cluster_hosts()
        servers = self.servers

        # server restrictions via command line options:
        if servers:
            # the user wants us to connect to specified hosts only:
            q_servers = {}
            for s in servers:
                # strip the default, so that it matches below with host entries:
                # (if one specifies another port we assume the user wants a
                # specific connection to a non default port redis
                s = s.replace(':%s' % REDIS_PORT, '')
                found = 0
                # try find in hosts:
                for ip, cservers  in cfg_servers.items():
                    # s can be the ip or like 'nb01':
                    if s == ip or s in cservers:
                        q_servers[ip] = cservers
                        found = 1
                if not found:
                    q_servers[s] = ['cmd option', ]
                cfg_servers = q_servers
        SL['servers'] = cfg_servers



if __name__ == "__main__":
    jh = AxpandJobHandler()
    jh.setup()
    # starting not as thread:
    jh.run()
    jh.cleanup()

