#!/usr/bin/env /opt/axess/bin/call_with_eggs
"""
tr069.py is part of the commercial products WPS and Ax.

This file is copyrighted (C) 2002 - 2010 by Axiros GmbH.
Under no circumstance any distribution, derived work, analysis
and/or decompilation of this module is allowed.

Usage is restricted to parties legally owning a license
for the whole product. German copyright laws apply!

For details please read the license.
"""


VER = 1.93


import sys
from os import getenv

try:
    from httplib import HTTPSConnection
except:
    print "Couldn't import HTTPS"
    pass
import sha
from hashlib                   import md5
from hashlib                   import sha1
from ax.transport.helper       import examples
from urlparse                  import urlparse
from ax.utils                  import package_home
from ax.tr069.events           import build_events
from ast                       import literal_eval
from optparse                  import OptionParser
from httplib                   import HTTPConnection
from ax.utils.formatting       import ax_xml, pretty_print
from thread                    import get_ident as get_thread_ident
from time                      import localtime, strftime, ctime, time as s_time

from ax.utils.lib.SOAPpy_ax.Config           import SOAPConfig
from ax.transport.via.tr069.AXTR069Exception import AXTR069CPEFaultType
from ax.transport.via.tr069.TR69SOAPClasses  import FaultStruct
from ax.transport.via.tr069.TR69SOAPClasses  import EventStruct
from ax.transport.via.tr069.TR69SOAPClasses  import convertToSOAPStruct
from ax.transport.via.tr069.TR69SOAPClasses  import ParameterInfoStruct
from ax.transport.via.tr069.TR69SOAPClasses  import ParameterValueStruct

# for diagnostics:
import base64
import logging
import datetime
import ax.utils.lib.SOAPpy_ax as SOAPpy
from ax.transport.via.tr069 import TR69JobsInfo
from ax.utils.lib.SOAPpy_ax.Types import faultType
from ax.utils.lib.SOAPpy_ax.Types import arrayType
from ax.utils.lib.SOAPpy_ax.Types import booleanType
from ax.utils.lib.SOAPpy_ax.Types import stringType
from ax.utils.lib.SOAPpy_ax.Types import floatType
from ax.utils.lib.SOAPpy_ax.Types import integerType
from ax.utils.lib.SOAPpy_ax.Types import headerType
from ax.utils.lib.SOAPpy_ax.Types import untypedType
from ax.utils.lib.SOAPpy_ax.Types import dateTimeType
from ax.utils.lib.SOAPpy_ax.Server import parseSOAPRPC
from ax.utils.lib.SOAPpy_ax.SOAPBuilder import buildSOAP
from ax.transport.connected_transport import ConnectedGetter
from ax.transport.transport_access import get_transport_object
from urllib2 import parse_keqv_list, parse_http_list, randombytes

logger = logging.getLogger( __name__)


###############################################################################
#
# Stateless TR-069 Client Using Models
#
###############################################################################

"""
This module offers access to tweak the TR-069 sent to an ACS across the OSI
layers, from HTTP(s), via SOAP to CWMP.

For modifications of the parameter models themselves please check back at
ax.transport.model.

"""




# -----------------------AXPAND Framework - in the end this is a transport via:
class TR069(ConnectedGetter):
    # append all transactions to 'call_history'?
    call_history = None
    t            = None
    t_ident      = None
    t_settings   = None
    ext_params   = None
    style        = None
    events       = None
    proxy        = None


    def open_connection(self):
        if not self.t:
            # ident from a (connected?) pool?
            if not self.t_ident:
                # no -> create a unique one:
                self.t_ident = 'proxied69_%s' % s_time()
            if not self.t_settings:
                cwd = package_home(globals())
                self.t_settings = {'via': 'cache', 'ctype': 'file_tr069',
                        'source': '%s/cache.txt' % cwd}

            t = get_transport_object(self.t_ident,
                       settings = self.t_settings)

            t.session_cache['ext_params'] = self.ext_params
        if not self.events:
            self.events = [0]

        self.evs = build_events(self.events)
        do_trans_compl = 0
        for ev in self.evs:
            if ev['EventCode'] == '7 TRANSFER COMPLETE':
                tcs = self.settings.get('transfer_settings', {})
                ck = tcs.get('CommandKey', '')
                ev['CommandKey'] = ck
                do_trans_compl = 1

        if self.call_history and not isinstance(self.call_history, list):
            self.call_history = []

        conn_obj = SOAPClientTR69(
                    t,
                    self.evs,
                    self.proxy,
                    call_history=self.call_history,
                    style=self.style)

        # Add Inform method - not yet send, just assemble & add to self.methods
        conn_obj.add_inform_method()
        if do_trans_compl:
            start_ts = tcs.get('StartTs', 0)
            TC = self.make_transfer_complete(conn_obj, tcs, start_ts)
            conn_obj.methods.append(TC)
        return conn_obj




    def close(self, conn_obj=None):
        # close the transport obj:
        cobj = self.get_connection_obj()
        if not cobj:
            return
        for obj in (cobj.t, cobj):
            try:
                obj.close()
            except:
                pass


    def add_infos(self, conn_obj, res):
        if self.call_history != None:
            h = conn_obj.call_history
            res['call_log'] = h[0]
            res['cwmp'] = h[1:]
            res['comm_log'] = conn_obj.t.input_buf
        b = conn_obj.output_buf
        if b:
            res['output_buf'] = b

    def c(self, cmd, conn_obj, condition, error_condition, timeout, **kwargs):
        if cmd == 'Inform':
            conn_obj.start_cwmp()
            pj = conn_obj.t.session_cache.get('diag_job_ping')
            if pj:
                del conn_obj.t.session_cache['diag_job_ping']
                conn_obj.do_ping_test(pj)
            res = {'res': 'Inform sent', 'status': 0}
            self.add_infos(conn_obj, res)

            if getattr(conn_obj, 'in_transfer', None):
                # causing the queue handler running next method:
                res['cmd'] = 'TransferComplete'
            return res

        elif cmd == 'TransferComplete':
            args = conn_obj.in_transfer
            start_ts = s_time()
            # actually run the download now:
            res = conn_obj.Download(**args)

            if isinstance(res, dict) and res.get('Status') == 1:
                # a reboot is triggered, dont' send but inform the nb:
                res = {'res': 'RebootAfterTransfer', 'status': 0}
                self.add_infos(conn_obj, res)
                args['StartTs'] = int(start_ts)
                res['TransferSettings'] = args
                return res

            TC = self.make_transfer_complete(conn_obj, args, start_ts, res)
            conn_obj.add_inform_method()
            conn_obj.methods.append(TC)
            return self.c('Inform', conn_obj, condition, error_condition,
                          timeout, **kwargs)

    communicate = c

    def make_transfer_complete(self, conn_obj, args, start_ts, res=None):
        # check if we need a reboot here.
        cmd_key = args.get('CommandKey', '')
        fault = FaultStruct()
        fault.update({'FaultCode':ut('0'), 'FaultString':ut('')})
        startDownload=strftime('%Y-%m-%dT%H:%M:%S', localtime(start_ts))
        if res:
            if hasattr(res, 'faultcode'):
                fault = res
            conn_obj.evs= [{"CommandKey": cmd_key,
                            "EventCode" : "7 TRANSFER COMPLETE"}]

        endDownload=strftime('%Y-%m-%dT%H:%M:%S',localtime(s_time()))
        par = {'CommandKey'  : ut(cmd_key),
                'FaultStruct' : fault,
                'StartTime'   : ut(startDownload),
                'CompleteTime': ut(endDownload)}
        conn_obj.in_transfer = None
        TC = SOAPMethod(conn_obj.t,
                        'TransferComplete',
                        ID='axpand_%s' % str(s_time()),
                        body_map=par,
                        cwmp=conn_obj.cwmp)
        return TC







jobslog = TR69JobsInfo.JobsStateInfo
CWMP_VER = "cwmp-1-2"

CWMPConfig = SOAPConfig()

CWMPConfig.argsOrdering = {
    'cwmp:Inform'                     : ['DeviceId',
                                         'Event',
                                         'MaxEnvelopes',
                                         'CurrentTime',
                                         'RetryCount',
                                         'ParameterList'],
    'cwmp:SetParameterValues'         : ['ParameterList', 'ParameterKey'],
    'cwmp:GetParameterNames'          : ['ParameterPath', 'NextLevel'],
    'cwmp:AddObject'                  : ['ObjectName', 'ParameterKey'],
    'cwmp:DeleteObject'               : ['ObjectName', 'ParameterKey'],
    'cwmp:Download'                   : ['CommandKey',
                                         'FileType',
                                         'URL',
                                         'Username',
                                         'Password',
                                         'FileSize',
                                         'TargetFileName',
                                         'DelaySeconds',
                                         'SuccessURL',
                                         'FailureURL'],
    'cwmp:Kicked'                     : ['Command',  'Referer', 'Arg','Next'],
    'cwmp:RequestDownload'            : ['FileType', 'FileTypeArg'],

    'cwmp:AutonomousTransferComplete' : ['AnnounceURL',
                                         'TransferURL',
                                         'IsDownload',
                                         'FileType',
                                         'FileSize',
                                         'TargetFileName',
                                         'FaultStruct',
                                         'StartTime',
                                         'CompleteTime']}


CWMPConfig.DicArgsOrdering = {
    'cwmp:Inform': {'DeviceId'        : ['Manufacturer',
                                         'OUI',
                                         'ProductClass',
                                         'SerialNumber'],
                    'EventStruct'     : ['EventCode','CommandKey' ]},
    'cwmp:GetParameterNamesResponse'  : {"ParameterInfoStruct" : ['Name',
                                                                  'Writable' ]},
    'cwmp:SetParameterAttributes'     : {
        'SetParameterAttributesStruct': ['Name',
                                         'NotificationChange',
                                         'Notification',
                                         'AccessListChange',
                                         'AccessList']},
    'cwmp:GetParameterAttributesResponse': {
         'ParameterAttributeStruct' : ['Name', 'Notification', 'AccessList']}}

SOAP_TO_CWMP_REPL = {
    '<ParameterList SOAP-ENC:arrayType="xsd:SOAPStruct[':
                  ('<ParameterList soap:arrayType="cwmp:'
                   'ParameterValueStruct['),
    'SOAP-ENC:arrayType="xsd:EventStruct':
                   'soap-enc:arrayType="cwmp:EventStruct',
    'SOAP-ENC:arrayType="xsd:ArgStruct':
                   'soap-enc:arrayType="cwmp:ArgStruct',
    'SOAP-ENC:arrayType="xsd:ParameterValueStruct':
                   'soap-enc:arrayType="cwmp:ParameterValueStruct',
    'SOAP-ENC:arrayType="xsd:ParameterAttributeStruct':
                   'soap-enc:arrayType="cwmp:ParameterAttributeStruct',
    'SOAP-ENV:mustUnderstand=' : 'soap:mustUnderstand=',
    ' xsi:type="SOAP-ENC:Array"': '',
    ' xsi:type="soap-enc:Array"': '',
    'xsi:type="xsd3:dateTime'  : 'xsi:type="xsd:dateTime',
    'SOAP-ENC'   : 'soap-enc',
    '<SOAP-ENV:' : '<soap:',
    '</SOAP-ENV:': '</soap:',
    '>True<'     : '>1<',
    '>\n</cwmp:' : '></cwmp:',
    'xsi:type="soap-enc:Array"': ""}



def conv_env(body):
    env_conv = {
        '<ParameterList soap:arrayType="cwmp:ParameterValueStruct[':
                '<ParameterList SOAP-ENC:arrayType="xsd:SOAPStruct[',
        "soap:mustUnderstand": "SOAP-ENV:mustUnderstand",
        "soapenc" : "SOAP-ENC",
        "soap-enc": "SOAP-ENC",
        "<soap:"  : "<SOAP-ENV:",
        "</soap:" : "</SOAP-ENV:",
        "<cwmp:"  : "<",
        "</cwmp:" : "</",
        ">true<"  : ">True<",
        ">false<" : ">False<",
        "soapenc" : "SOAP-ENC"}


    for k, v in env_conv.items():
        body = body.replace(k, v)

    if (body.find('<SOAP-ENV:Header') != -1):
        delimiter = '<SOAP-ENV:Header'
    else:
        delimiter = '<SOAP-ENV:Body'

    arEnvSoap    = body.split(delimiter)
    arEnvSoap[0] = arEnvSoap[0].replace("soap:", "SOAP-ENV:")
    arEnvSoap[0] = arEnvSoap[0].replace(":soap", ":SOAP-ENV")

    body = delimiter.join(arEnvSoap)
    return body


#------------------------------------------------------------- output formatting
# just seperators for console logging:
ll = {}
for c in ('*', '-', '.'):
    ll[c] = '\n' + c * 30 + '%s' + c * 30
log_line1 = ll['*']
log_line2 = ll['-']
log_line3 = ll['.']

#  term -> tag -> 8 means: format a tag to terminal color nummer 8.
# ax_xml __main__ prints colors all out:
DEF_STYLE = {
'client': 'tr069_client',
'markup':{
  'term':
        {'tag': 8, 'text': 2, 'attr': 0, 'noxml': 12, 'attr_val': 8,
        'tr_node': 8, 'tr_leaf': 5, 'tr_serial': 1},
  'html':
        {'tag': 'rgb(142, 162, 162)',
         'text': '#00F', 'attr': '#aaa',
         'text_bold': 1,
         'tr_leaf_bold': 1,
         'noxml': 'rgb(92, 124, 132)', 'attr_val': '#aaa',
         'tr_node': 'rgb(104, 107, 200)', 'tr_leaf': '#rgb(240, 232, 211)',
         'tr_serial': 'rgb(228, 50, 0)'}
        }
    }




def convertParams(par):
    """
    This function does a recursive convertion from SOAPpy.Types into
    python types
    """

    # Convert dict types
    if isinstance(par, SOAPpy.Types.structType):
        # Make par to a python dict
        par = par._asdict()
    if isinstance(par, dict):
        new_par = {}
        for key, value in par.iteritems():
            new_par[key] = convertParams(value)
        return new_par

    # Convert array types
    if isinstance(par, (SOAPpy.Types.arrayType, list)):
        return [ convertParams(el) for el in par ]

    # All SOAPpy.Types.* inhert from anyType
    # dict, array are handeld above, for the rest use _data
    if isinstance(par, SOAPpy.Types.anyType):
        return par._data

    # Its NOT a array,list or even a SOAPpy.Types.* type
    # => return the para as it is
    return par



LOG_FILE = None
LOG_PRINT=False


PY_TYPES = {bool: booleanType, int: integerType, float: floatType}
def ut(v):
    if isinstance(v, datetime.datetime):
        # convert to unix time for the dateTT:
        # FIXME: check this for timezones...
        secs = (v - EPOCH).days * 86400 + (v - EPOCH).seconds
        return dateTimeType(secs)
    try:
        return PY_TYPES.get(type(v), untypedType)(v)
    except:
        # if v is None -> i.e. parser failed, don't crash:
        return untypedType('n.a.')



def soap_array(res):
    return {"ParameterList" : arrayType(data=res,
             elemsname = "ParameterValueStruct")}


EPOCH = datetime.datetime(year=1970,month=1,day=1)


def order(params, model):
    # sorted params on the wire are nice:
    keys = params.keys()
    keys.sort()
    return keys



def get_pvs(params, model):
    """ Create soap Name Value list from map.
    Used in makeInform and GPV.
    """
    params = model.rootify(params)
    res = []
    # sorted params on the wire are nice:
    for name in order(params, model):
        val = params[name]
        pv = ParameterValueStruct()
        pv.update({'Name' : ut(name),
                   'Value': ut(val)})
        res.append(pv)
    return res



def get_pis(params, model):
    """ gpn res is parameter info structs """
    params = model.rootify(params)
    res = []
    for name in order(params, model):
        val = params[name]
        pv = ParameterInfoStruct()
        if val:
            val = ut('1')
        else:
            val = ut('0')
        pv.update({'Name'    : ut(name),
                   'Writable': val})
        res.append(pv)
    return res



class CPEClass(object):
    """
    This class is handling the RPCs:
    Wrapped by SOAPClientTR69, which is instantiated from outside.
    """
    def __init__(self, t):
        self.t             = t
        self.model         = t.model


    def GetRPCMethods(self):
        rpcs = self.model.check_model_rpc_support()
        return {'MethodList': rpcs}


    def Reboot(self, CommandKey):
        self.model.Reboot(CommandKey, self.t)
        return {}

    def X_AXIROS_COM_RunCmdFlow(self, CmdFlow):
        try:
            res = self.model.X_AXIROS_COM_RunCmdFlow(CmdFlow, self.t)
        except Exception, ex:
            return AXTR069CPEFaultType('9899',
                    'X_AXIROS_COM_RunCmdFlow Exception:%s' % ex)
        return {'CmdFlowResult': str(res)}

    def GetParameterNames(self, ParameterPath, NextLevel=False):
        if NextLevel=="1" or NextLevel=="true":
            NextLevel=True
        else:
            NextLevel=False
        # model to deliver map with params -> writable/readonly
        params = self.model.GetParameterNames(ParameterPath, NextLevel, self.t)
        res = get_pis(params, self.model)
        if len(res) == 0:
            # Parameter was not found
            res.append(AXTR069CPEFaultType('9005',
                'Invalid Parameter Name %s' % ParameterPath))

        return soap_array(res)

    def GetParameterValues(self, ParameterNames):
        # map with key to vals:
        try:
            params = self.model.GetParameterValues(ParameterNames, self.t)
        except Exception, ex:
            logger.exception('GPV Error: %s' % ex)
            # Deliver result in any case to server, whatever it is:
            return AXTR069CPEFaultType('9003',
                    'Invalid Arguments: %s' % ex)
        res = get_pvs(params, self.model)
        return soap_array(res)

    def AddObject(self, ObjectName='', ParameterKey=''):
        #FIXME: error handling for not supported ones !
        index = self.model.AddObject(ObjectName, ParameterKey, self.t)
        return {'InstanceNumber': ut(str(index)), 'Status': ut('0')}


    def DeleteObject(self, ObjectName='', ParameterKey=''):
        #FIXME: error handling for not supported ones !
        self.model.DeleteObject(ObjectName, ParameterKey, self.t)
        return {'Status': ut('0')}


    def SetParameterValues(self, ParameterList, ParameterKey=None):
        pmap = {}
        for k in ParameterList:
            pmap[k['Name']] = k['Value']
        pmap = self.model.dotify(pmap)
        if pmap.get('.IP.Diagnostics.IPPing.DiagnosticsState') == 'Requested':
            pm = {}
            pm.update(pmap)
            self.t.session_cache['diag_job_ping'] = pm
            return {"Status": ut(str(0))}

        try:
            # {'Status': 1|0}
            res = self.model.SetParameterValues(pmap, self.t)
        except Exception, ex:
            msg = str(ex)
            if msg.startswith('.'):
                msg = self.model.rootify(msg)
            return AXTR069CPEFaultType("9003",
                        "Invalid arguments %s" % msg)
        if res:
            status = 1
        else:
            status = 0
        return {"Status": ut(str(status))}

    def do_ping_test(self, pmap):
        # blocking, long lasting:
        self.model.diagnostics_ping(self.t, pmap)
        self.evs.append({"CommandKey":'',
                         "EventCode":"8 DIAGNOSTICS COMPLETE"})
        # push result in inform params:
        m = self.t.session_cache.setdefault('ext_params', {})
        for k, v in self.t.session_cache.items():
            if '.IPPing.' in k:
                m[k] = v
        self.add_inform_method()
        self.start_cwmp()


    def Download(self, **kwargs):
        stat_1 = {'Status':       ut('1'),
                  'CompleteTime': ut("0001-01-01T00:00:00Z"),
                  'StartTime':    ut("0001-01-01T00:00:00Z")}

        method = kwargs.get('method') or self.model.Download
        # are we in a file transfer or in an inform:
        kwargs['in_transfer'] = getattr(self, 'in_transfer', 0)
        try:
            res = method(kwargs, self.t)
            if res == 1:
                self.in_transfer = kwargs
                return stat_1
        except Exception, ex:
            # expecting "9011: <reason>"
            msg = str(ex)
            if ': ' in msg:
                code, msg = msg.split(': ', 1)
            else:
                code = ['9010', '9011'][method != self.model.Download]
            return AXTR069CPEFaultType(code, msg)

        #Different types may come in the reply
        if (res.get('Status') is not None)  and \
            res.get('CompleteTime')  and \
            res.get('StartTime'):
                return res

        return  stat_1




    def Upload(self, **kwargs):
        kwargs['method'] = self.model.Upload
        return self.Download(**kwargs)






class SOAPMethod:
    """
    Class for SOAPpy based SOAPMethod
    """
    def __init__(self,
            t,
            methodName,
            ID             = None,
            HoldRequest    = None,
            NoMoreRequests = None ,
            body_map       = {},
            isResponse     = 0,
            stack          = None,
            cwmp           = CWMP_VER):

        self.methodName     = methodName
        self.body_map       = body_map
        self.ID             = ID
        self.HoldRequest    = HoldRequest
        self.NoMoreRequests = NoMoreRequests
        self.body_map       = body_map
        self.isResponse     = isResponse
        self.result         = ""
        self.stack          = stack
        self.cwmp           = cwmp
        self.t              = t
        self.model          = t.model


    def convertToTR69(self, body):
        header = """<soap:Envelope
        xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
        xmlns:soap-enc="http://schemas.xmlsoap.org/soap/encoding/"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xmlns:xsd="http://www.w3.org/2001/XMLSchema"
        xmlns:cwmp="urn:dslforum-org:%s">""" % self.cwmp
        for k, v in SOAP_TO_CWMP_REPL.items():
            body = body.replace(k, v)
        body = body.replace('xsi:type="soap-enc:Array"', '')
        return header + body[38:] + "</soap:Envelope>"


    def buildSOAP(self):
        h = "cwmp:"

        header={}

        if (not self.ID is None):
            header[h + "ID"] = stringType(data=self.ID, typed=0)
            header[h + "ID"]._setMustUnderstand(1)

        if (not self.HoldRequest is None):
            header[h + "HoldRequest"] = integerType(data=self.HoldRequest,
                                                   typed=0)
            header[h + "HoldRequest"]._setMustUnderstand(1)

        if (not self.NoMoreRequests is None):
            header[h + "NoMoreRequests"] = integerType(data=self.NoMoreRequests,
                                                      typed=0)
        if len(header)!=0:
            hd = headerType(data = header, typed=1)
        else:
            hd=None
        if (self.isResponse):
            methodName = h + self.methodName + "Response"
            kw = self.result
        else:
            methodName = h + self.methodName
            kw = self.body_map

        if isinstance(self.result, faultType):
            body = buildSOAP(noroot   = 1,
                             envelope = 0,
                             args     = self.result,
                             header   = hd,
                             config   = CWMPConfig)
        else:
            # for debug - print all out one by one to see where exc occurs:
            if 0:
                for i in xrange(len(kw.values()[0])):
                    print i; kw.values()[0][i].get('Name')._data;
                    print buildSOAP(kw = kw.values()[0][i])

            body = buildSOAP(noroot   = 1,
                             envelope = 0,
                             kw       = kw,
                             header   = hd,
                             method   = methodName,
                             config   = CWMPConfig)
        tr = self.convertToTR69(body)
        return tr



    def run(self):
        """ we apply on the stack the next RPCs """
        m = self.methodName
        if not m in self.model.check_model_rpc_support():
            self.result = AXTR069CPEFaultType('9000', 'Method not supported')
        else:
            # models can supply their own out of this stack - having to care for
            # cwmp formatting then on their own:
            rm  = getattr(self.stack, m, getattr(self.t.model, m))
            res = apply(rm, (), self.body_map)
            res = convertToSOAPStruct(self.methodName + 'Response', res)
            self.result = res





class SOAPClientTR69(CPEClass):
    """ Protocol Wrapper for CPEClass """

    def __init__(self,
                 t,
                 evs,
                 proxy            = None,
                 call_history     = None,
                 cwmp             = CWMP_VER,
                 job_id           = None,
                 style            = None,
                 max_transactions = 50):

        super(SOAPClientTR69, self).__init__(t)
        if call_history != None:
            # the 0th element will contain the call log:
            call_history.insert(0, [])

        # if we have buf in style, we don't print but append to here:
        self.output_buf = ''

        self.AuthorizationTrying = 0
        self.nonce_count         = 0
        self.cookies             = []
        self.methods             = []
        self.conn                = None
        self.auth_header         = None
        self.cwmp                = cwmp
        self.call_history        = call_history
        self.max_transactions    = max_transactions
        self.evs                 = evs
        self.proxy               = proxy


        if isinstance(style, (str, unicode)):
            self.style = {}
            self.style.update(DEF_STYLE)
            if 'indent' in style:
                self.style['indent']   = 2
            if 'col' in style:
                self.style['col']      = 1
            if '-compress' in style:
                self.style['compress'] = 'full'
            if '-semicompress' in style:
                self.style['compress'] = 'semi'
            if 'html' in style:
                self.style['format']   = 'html'
            else:
                self.style['format']   = 'term'
        elif isinstance(style, dict):
            self.style = style
        else:
            self.style = None

        StateInfo = {
                'StartTime'     : s_time(),
                'EndTime'       : s_time(),
                'HTTPReqNumber' : 0,
                'CPEReqNumber'  : 0,
                'CPERespNumber' : 0,
                'HTTPRespNumber': 0,
                'ACSReqNumber'  : 0,
                'ACSRespNumber' : 0}

        if job_id is not None:
            self.job_id = job_id
        else:
            self.job_id = TR69JobsInfo.getNextJobId()

        jobslog[self.job_id] = StateInfo



    def add_inform_method(self):
        params   = self.model.make_inform(transport=self.t)
        dev_id   = self.model.get_device_id(self.t)
        evs      = self.model.get_events(self.t)
        if not evs:
            # not derived in model - take default or command line args:
            evs = self.evs

        DeviceId = {}
        for k, v in dev_id.items():
            DeviceId[k] = ut(v)

        AllEvents = []

        for ev in evs:
            Event = EventStruct()
            Event.update({'CommandKey': ut(ev.get("CommandKey", "")),
                          'EventCode' : ut(ev.get("EventCode", ""))})
            AllEvents.append(Event)

        body_map = {'DeviceId'     : DeviceId,
                    'Event'        : arrayType(AllEvents,
                                     elemsname='EventStruct'),
                    'MaxEnvelopes' : ut(str(1)),
                    'CurrentTime'  : ut(strftime('%Y-%m-%dT%H:%M:%S',
                                        localtime(s_time()))),
                    'RetryCount'   : ut(str(0)),
                    'ParameterList': arrayType(get_pvs(params, self.model),
                                         elemsname="ParameterValueStruct")}

        inform_method  = SOAPMethod(self.t,
                                     'Inform',
                                     ID='axpand_%s' % s_time(),
                                     body_map=body_map,
                                     cwmp=self.cwmp)

        self.methods.append(inform_method)


    # ---------------------------------------- Digest Authentication
    def get_cnonce(self, nonce):
        # The cnonce-value is an opaque
        # quoted string value provided by the client and used by both client
        # and server to avoid chosen plaintext attacks, to provide mutual
        # authentication, and to provide some message integrity protection.
        # This isn't a fabulous effort, but it's probably Good Enough.
        dig = sha.new("%s:%s:%s:%s" % (self.nonce_count,
                                       nonce,
                                       ctime(),
                                       randombytes(8))).hexdigest()
        return dig[:16]


    def retry_http_digest_auth(self, auth):
        token, challenge = auth.split(' ', 1)
        chal = parse_keqv_list(parse_http_list(challenge))
        auth = self.get_authorization(chal)
        if auth:
            auth_val         = 'Digest %s' % auth
            self.auth_header = auth_val


    def get_algorithm_impls(self, algorithm):
        # lambdas assume digest modules are imported at the top level
        if algorithm == 'MD5':
            H = lambda x: md5(x).hexdigest()
        elif algorithm == 'SHA':
            H = lambda x: sha1(x).hexdigest()
        # MD5-sess
        KD = lambda s, d: H("%s:%s" % (s, d))
        return H, KD


    def get_authorization(self, chal):
        try:
            realm = chal['realm']
            nonce = chal['nonce']
            qop = chal.get('qop')
            algorithm = chal.get('algorithm', 'MD5')
            # mod_digest doesn't send an opaque, even though it isn't
            # supposed to be optional
            opaque = chal.get('opaque', None)
        except KeyError:
            return None

        H, KD = self.get_algorithm_impls(algorithm)
        if H is None:
            return None

        user, passw = self.model.get_http_creds(self.t)
        entdig = None

        A1 = "%s:%s:%s" % (user, realm, passw)
        A2 = "%s:%s" % ('POST',
                        # XXX selector: what about proxies and full urls
                        self.req_path)
        if qop == 'auth':
            self.nonce_count += 1
            ncvalue = '%08x' % self.nonce_count
            cnonce = self.get_cnonce(nonce)
            noncebit = "%s:%s:%s:%s:%s" % (nonce, ncvalue, cnonce, qop, H(A2))
            respdig = KD(H(A1), noncebit)
        elif qop is None:
            respdig = KD(H(A1), "%s:%s" % (nonce, H(A2)))
        else:
            # XXX handle auth-int.
            pass

        # XXX should the partial digests be encoded too?

        base = 'username="%s", realm="%s", nonce="%s", uri="%s", ' \
               'response="%s"' % (user, realm, nonce, self.req_path,
                                  respdig)
        if opaque:
            base = base + ', opaque="%s"' % opaque
        if entdig:
            base = base + ', digest="%s"' % entdig
        if algorithm != 'MD5':
            base = base + ', algorithm="%s"' % algorithm
        if qop:
            base = base + ', qop=auth, nc=%s, cnonce="%s"' % (ncvalue, cnonce)
        return base

    # ---------------End methods for digest authentication

    def log(self, msg):
        if isinstance(msg, (list, tuple)):
            msg = ''.join(msg)
        msg = ax_xml.pretty_print(msg, self.style)
        if self.style:
            if 'buffer' in self.style:
                self.output_buf += "%s\n" % msg
            else:
                if self.style.get('format') == 'term':
                    print msg
                else:
                    logger.info(msg)


    def commandLogging (self, message, isRequest=False, http={}):
        #logger.info('\n' + message)
        if not self.call_history == None:
            self.call_history[0].append(message)
            method = args = None
            if message:
                body   =  parseSOAPRPC(message, header=1 , body=1)
                method = body[0]._name
                args   = convertParams(body[0]._asdict())
            if isRequest:
                self.call_history.append({'request_method': method,
                                          'request_args': args})
            else:
                self.call_history[-1]['response_method'] = method
                self.call_history[-1]['response_args']   = args



    def dumpHistoryCalls(self):
        i = 0
        for m  in self.call_history:
            i += 1
            print "%s.\tREQUEST: %s - %s" % (
                    i,
                    m.get('request_method'),
                    m.get('request_args'))
            print "\tRESPONSE: %s - %s" % (
                    m.get('response_method'),
                    m.get('response_args'))

    def close(self):
        self.conn.close()


    def start_cwmp(self):
        """
            Here the multistep cwmp exchange really happens
            on the wire
        """


        # Build SOAP message

        # send http1.1 -> do connection outside main loop:
        if not self.conn:
            acs, user, passw = self.model.get_ms(self.t)
            if not acs:
                raise Exception('No ACS URL in session cache')

            parsedurl         = urlparse(acs)
            server            = parsedurl[1]
            self.req_path     = parsedurl[2]
            proxy = server
            if self.proxy:
                proxy = self.proxy

            if parsedurl[0] == 'https':
                self.conn = HTTPSConnection(proxy)
            else:
                self.conn = HTTPConnection(proxy)
            self.url = '%s://%s%s' % (parsedurl[0], parsedurl[1], parsedurl[2])


        http_req = 0
        cpe_req  = 0
        cpe_resp = 0

        http_resp = 0
        acs_req   = 0
        acs_resp  = 0


        in_cwmp_session= True
        max_t = self.max_transactions
        while in_cwmp_session:
            if max_t and http_req > max_t:
                raise Exception("Excessive Recursion. max_transactions: %s"\
                                 % max_t)

            if len(self.methods) == 0:
                in_cwmp_session= False
                break

            cpe_req_list  = []
            cpe_resp_list = []
            acs_req_list  = []
            acs_rep_list = []

            postdata = ""
            req = self.methods[0]

            if type(req) == type({}):
                newob = getattr(self, req['Methodname'], None)
                if newob is None:
                # method unknown
                    self.methods = self.methods[1:]
                    continue

                else:
                    res=apply(newob, (), req['Parameters'] )
                    self.methods =  self.methods[1:]
                    continue

            elif req != "":
                if req.methodName == "Inform":
                    # FIXME! We must clean this parameters
                    #self.auth_header=None
                    #self.AuthorizationTrying=0
                    #self.nonce_count=0
                    #self.cookies=['axpand_hit']
                    pass
                postdata = postdata + req.buildSOAP()+ "\n"

                if req.isResponse:
                    cpe_resp = cpe_resp + 1
                    cpe_resp_list.append(req.methodName)
                else:
                    cpe_req = cpe_req + 1
                    cpe_req_list.append(req.methodName)

            jobslog[self.job_id]['CPEReqNumber']  += cpe_req
            jobslog[self.job_id]['CPERespNumber'] += cpe_resp
            if self.style:
                self.log(log_line1 %  'OUTGOING SOAP')
                self.log(postdata)

            # Begin HTTP request

            http_start_time = s_time()


            self.conn.putrequest("POST", self.url)
            if  postdata != "":
                self.conn.putheader("Accept"        , "text/xml; charset=utf-8")
                self.conn.putheader("User-Agent"    , "Axiros AXPAND v%s" % VER)
                self.conn.putheader("Content-Type"  , "text/xml; charset=utf-8")
                self.conn.putheader("Content-Length", str(len(postdata)))
                self.conn.putheader("Connection"    , "Keep-Alive")
                #self.conn.putheader("Connection",    "Close")
            else:
                pass
                # FIXME: When we use HTTPS there is a strange Exception
                # something on TCP level...
                # if postdata = ''. Is postdata='\n' all is ok
                #self.conn.putheader("Content-Length", str(0))
                #self.conn.putheader("Connection", "Close")
                # but with it we get 30% intermittent errors on HTTP.
                # might want to take it in for HTTPS only(?)
                #FIXME: Check this for HTTP and HTTPS at multistep scenarios:
                # GK. 2012/01
                #postdata += '\n'

            # put cookie
            if self.cookies:
                # cookies like, see below at set:
                # ['axpand_hit="2"; ', 'tr69="Tm9...4x"; ']
                cookies = ''
                for cook in self.cookies:
                    cookies += cook
                cookies = cookies.strip()
                self.conn.putheader ("Cookie", cookies)

            # This header for TR69 reqiured
            self.conn.putheader("SOAPAction", '')

            # Authentciation
            if self.auth_header:
                if self.style:
                    self.log(self.auth_header)
                self.conn.putheader("Authorization", self.auth_header)


            self.conn.endheaders()

            # Send SOAP message
            # FIXME
            self.commandLogging(postdata.strip(), True)
            self.conn.send(postdata)
            http_req = http_req + 1
            jobslog[self.job_id]['HTTPReqNumber'] += http_req

            resp = self.conn.getresponse()
            # error code:
            ec = resp.status
            em = str(resp.msg)
            hl = resp.getheaders()
            h = {}
            for k, v in hl:
                h[k] = v


            http_end_time = s_time()
            TR69JobsInfo.ThreadsInfo[get_thread_ident()] = \
                    http_end_time - http_start_time
            if self.style:
                self.log(log_line2 % 'HTTP RESPONSE')
                self.log('\n%s\n%s' % (ec, em))
                self.log(log_line3 % 'HTTP RESPONSE HEADER')
                self.log( '\n' + str(h))

            if h.has_key('set-cookie'):
                for cookie in h.get('set-cookie').split(', '):
                    key = cookie.split('=')[0]
                    # cookie overwritten?
                    for mycook in self.cookies:
                        if mycook.split('=')[0] == key:
                            self.cookies.remove(mycook)
                    cookie = cookie.split("Path")[0]
                    self.cookies.append(cookie)
                if self.style:
                    self.log(self.cookies)

            # get file-like object from HTTP response
            # and #self.log( received HTML to screen)
            if ec != 204:
                textlines = resp.read()
            else:
                textlines = ""

            # Check Response
            if ec == 401:
                #UNAUTHORIZED
                self.AuthorizationTrying += 1
                if self.AuthorizationTrying > 3:
                    raise Exception('Authorization Required: Bad creds')

                if h.has_key('www-authenticate'):
                    if 'basic' in  h.get('www-authenticate').lower():
                    # Basic Authentciation
                        self.auth_header = "Basic "+ base64.encodestring(
                                user + ":" + passw)
                        continue

                    if 'digest' in  h.get('www-authenticate').lower():
                        self.retry_http_digest_auth(h.get('www-authenticate'))
                        if self.style:
                            self.log( "---------------------------------")
                            self.log( h.get('www-authenticate'))
                            self.log( self.auth_header)
                            self.log( "---------------------------------")
                        continue
                        # raise 'Need digest'
                        # Digest Authentciation
                        pass
                raise Exception('Unknown authentciation scheme')

            self.commandLogging(textlines, False)
            if not (ec == 200 or ec == 204):
                #print textlines
                if self.style:
                    self.log(log_line1 % "INCOMING SOAP")
                    self.log( textlines)

                fp = open('error.log', 'a')
                fp.write('%s\n' % ec)
                fp.close()
                raise Exception("Error!")

            if ec == 204:
                self.model.clear_events(self.t)


            http_resp = http_resp + 1
            jobslog[self.job_id]['HTTPRespNumber'] += http_resp

            if self.style:
                self.log(log_line1 % "INCOMING SOAP")
                self.log( textlines)

            if textlines.find("</soap:Envelope>") != -1:
                splitResponse = textlines.split("</soap:Envelope>")
            else:
                splitResponse = textlines.split("</SOAP-ENV:Envelope>")

            res = []
            SendEmptyPost = 0
            for resp in splitResponse:
                if not ':Envelope' in resp:
                    break
                if '<soap:Envelope' in  textlines:
                    conv_resp = conv_env(resp + "</soap:Envelope>")
                else:
                    conv_resp = conv_env(resp + "</SOAP-ENV:Envelope>")

                meth = None
                #Exception
                try:
                    p = parseSOAPRPC(conv_resp, header=1 , body=1)
                except Exception, e:
                    self.log('Exception parsing ACS SOAP: %s' % e)
                    #self.log(log_line2 % 'ERROR')
                    #self.log(conv_resp)
                    #self.log( )
                    #self.log(e)
                    #self.log(log_line2 % '')
                    #p=parseSOAPRPC(conv_resp, header=1 , body=1)
                    # Parsing error
                    # 9002
                    # {} ???
                    meth = SOAPMethod(self.t,
                                      '' ,
                                      {},
                                      isResponse=1,
                                      stack=self,
                                      cwmp=self.cwmp)
                    meth.ID = None
                    meth.result = AXTR069CPEFaultType('9002',
                                    'Internal Error, XML not valid')
                    res.append(meth)

                if meth is None:
                    if type(p[0]) == faultType:
                        raise Exception("Server Error: %s" % conv_resp)

                    resp = p[0]._name
                    if 'Response' in resp:
                        # we have no more meths, cwmp response is there
                        # -> send empty post:
                        SendEmptyPost = 1
                        #self.log( resp[:len(resp)-len("Response")])
                        if resp[:len(resp)-len("Response")] == "Inform":
                            self.model.clear_events(self.t)
                        #self.log( "Response for method:" + \
                        #        resp[:len(p[0]._name)-len("Response")])
                        #self.log( "Result:" + str(p[0]._asdict()))
                        acs_resp = acs_resp + 1
                        acs_rep_list.append(resp[:len(resp)-len("Response")])

                    else:
                        meth = SOAPMethod(self.t,
                                          resp,
                                          body_map=p[0]._asdict(),
                                          isResponse=1,
                                          stack=self,
                                          cwmp=self.cwmp)

                        acs_req = acs_req + 1
                        acs_req_list.append(meth.methodName)

                        if (not p[1] is None):
                            header = p[1]._asdict()
                            if header.has_key('ID'):
                                meth.ID = header['ID']

                        try:
                            meth.run()
                        except Exception, ex:
                            # should NEVER end here. But we did. stacktrace:
                            logger.exception('while running %s: %s' % \
                                         (meth.methodName, ex))
                            # error 9002?
                            pass
                        res.append(meth)

            jobslog[self.job_id]['ACSReqNumber'] += acs_req
            jobslog[self.job_id]['ACSRespNumber'] += acs_resp
            jobslog[self.job_id]['EndTime'] = s_time()
            if LOG_PRINT:
                log_str = "%f\t%f\t%s\t%s\t%s\t%s\t%s\n" % (
                                    http_start_time,
                                    http_end_time,
                                    self.serial,
                                    ';'.join(cpe_req_list),
                                    ';'.join(cpe_resp_list),
                                    ';'.join(acs_req_list),
                                    ';'.join(acs_rep_list),
                            )
                fp = open(self.log_file,'a')
                fp.write(log_str)
                fp.close()

            ##self.log( len(res))
            if (len(res) > 0):
                # self.call(res)
                self.methods = res + self.methods[1:]
                continue

            elif SendEmptyPost:
                # If MaxEnvelopes=1, we must send empty post after Inform Resp.
                # Or sent CPE Method to ACS.
                #FIXME
                # If method has own methods to server, must we send empty POST?
                self.methods = self.methods[1:]
                if len(self.methods) == 0:
                    self.methods = [""] + self.methods[1:]
                continue
            else:
                self.methods = self.methods[1:]

            if len(self.methods) == 0:
                if self.model.has_events(self.t):
                    self.add_inform_method()
                else:
                    in_cwmp_session = False



if __name__ == '__main__':
    """ we are callable on the CLI as well """

    # FIXME: No config file support yet, just CLI and lib (transport via)

    def_acs  = 'http://127.0.0.1:9675/live/CPEManager/CPEs/genericTR69'
    tr_param = '.DeviceInfo.PeriodicInformInterval: 3600;'

    cwd = package_home(globals())
    def_cache_file = cwd.replace('__main__', 'cache.txt')
    MS = '.ManagementServer.'
    DI = '.DeviceInfo.'

    def do_example(option, opt_str, value, parser):
        """ Print examples for copy and paste on cli """

        sep1 = log_line3 % ''
        sep2 = log_line2 % ''
        res  = "\nCall Examples - Adapt to Your Needs" + sep1
        cmd = sys.argv[0]
        for k, v in examples().items():
            res += '\n' + k + ':\n\n'
            args = ''
            for k1, v1 in v.items():
                args += '%s: %s;' % (k1, v1)
            res += '%s --acs=%s --t_args="%s"' % (cmd, def_acs, args)
            res += sep2

        res += '\nStatic With TR-Parameters:\n\n%s --acs=%s --args="%s"' % (
                cmd, def_acs, tr_param)
        res += sep2
        res += ('\nStatic, No Format, Hitting Local ACS at Root /demo/:\n\n%s'
                ' --acs=demo -s term') % cmd
        print res
        sys.exit(0)




    use = "Usage: %prog [options]"
    parser = OptionParser(usage = use)

    parser.add_option(
            "-e",
            action   = "callback",
            callback = do_example,
            help     = "print examples")

    parser.add_option(
            "-p", "--proxy",
            action   = "store",
            help     = "use proxy, '-p ENV', '-p <IP>:<port> or '-p PH' to use worker",
            default  = "")


    parser.add_option(
            "-a", "--acs",
            action   = "store",
            help     = "ACS URL, also '-a demo',  '-a 7675/demo' or '-a 7675/'",
            default  = def_acs)

    parser.add_option(
            "--sn",
            action   = "store",
            help     = "CPE Serial Number",
            default  = "AX.ACT_TEST")


    parser.add_option(
            "-s", "--style",
            action   = "store",
            help     = ("log style. Supported: term|html, indent, "
                        "semicompress, compress, col."
                        "Default is term-col-indent"),
            default  = "term-col-indent-semicompress")

    parser.add_option(
            "--evs",
            action   = "store",
            help     = "TR-069 Event codes, comma separated numbers",
            default  = "6")

    parser.add_option(
            "--args",
            action   = "store",
            help     = "TR-069 fixed params",
            default  = tr_param)


    parser.add_option(
            "--t_args",
            action   = "store",
            help     = "transport args",
            default  = "via: cache;")

    parser.add_option(
            "-c", "--cachefile",
            action   = "store",
            help     = ("cachefile with parameters, in tr-069 parameter format "
                        "- only needed for via=cache"),
            default  = def_cache_file)

    parser.add_option(
            "-l", "--loglevel",
            action   = "store",
            help     = "loglevel (INFO, DEBUG, WARNING)",
            default  = 'DEBUG')

    options, args = parser.parse_args()

    ll = options.loglevel
    if ll == 'WARNING':
        llo = logging.WARNING
    elif ll == 'INFO':
        llo = logging.INFO
    else:
        llo = logging.DEBUG
    logging.basicConfig(level=llo)

    proxy = None
    if options.proxy == 'ENV':
        proxy = urlparse(getenv('http_proxy', ''))[1]
        if not proxy:
            raise Exception("No http_proxy is set in environment")
    elif options.proxy == 'PH':
        # parsed at communication setup time:
        # needed typically at job processing time
        proxy == options.proxy
    elif options.proxy:
        if not len(options.proxy.split(':')) == 2:
            raise Exception("proxy url not correct, must by 'IP:port'")
        proxy = options.proxy

    acs = options.acs
    if not acs.startswith('http'):
        if not '/' in acs:
            acs = '9675/' + acs
        elif acs.endswith('/'):
            acs = acs + 'live'
        # we accept just the tenant, like live, demo...:
        acs = def_acs.replace('9675/live', acs)

    ext_params = {}
    ext_params[MS + 'URL']          = acs
    ext_params[DI + 'SerialNumber'] = options.sn

    args   = {}
    t_args = {}
    for m, ov in ((args, 'args'), (t_args, 't_args')):
        val = getattr(options, ov)
        for kv in val.split(';'):
            kv = kv.strip()
            if not kv:
                continue
            k, v = kv.split(':', 1)
            v = v.strip()
            try:
                v = literal_eval(v)
            except:
                pass
            m[k.strip()] = v
    ext_params.update(args)
    # set the cache file source if we are in cache mode:
    if t_args['via'] == 'cache' and not 'source' in t_args:
       t_args['source'] = options.cachefile
       t_args['ctype']  = 'file_tr069'

    settings = {'t_settings'   : t_args,
                'proxy'        : proxy,
                'ext_params'   : ext_params,
                'events'       : options.evs.split(','),
                'call_history' : [],
                'style'        : options.style,
                'via'          : 'tr069'}

    sp = pretty_print.dict_to_txt(settings)

    logger.info('Instantiating transport using settings: \n%s' % sp)

    tr = get_transport_object('tr069', settings=settings)

    tr.get('Inform')


