from ax.utils.parsing.parse_text import get_line_val, get_in
from netaddr import IPNetwork

from ax.transport.model.misc import get_error_line
from ax.transport.model.misc import get_uptime_secs, run_many, put
from ax.transport.model.misc import safe_cli_get
from ax.transport.model.misc import handle_Upload, handle_Download

from ax.transport.model.keyval import handle_GPV, handle_SPV, handle_GPN
from ax.transport.model.keyval import SPVException, set_flow
from ax.transport.model.keyval import depends, lines, indizes

from ax.transport.model.model_support import Model, MODELS

"""
DPS for ssh like:
"linuxbox": {
         "static.via": "ssh",
         "static.allowed_cmds": None,
         "static.model": "linux.LSB_IGD",
         "static.formatters": None,
          },
"""

MODEL = 'IGD'
FOR = 'linux.pexpect|ssh|telnet'

class LSB_IGD(Model):
    root = 'I'
    model = 'IGD'
    matching = 'linux.pexpect|ssh|telnet'


    #def GPV_NSLookupDiagnostics_HostName(self, t):
    #    depends('GPV_DeviceInfo', t)


    def GPV_DeviceInfo(self, t):
        c = t.session_cache
        # we want only one transaction for all inform params:
        cmds = ('cat /proc/uptime',
                'cat /proc/cpuinfo',
                'cat /etc/issue',
                'uname -r',
                'uname -n',
                'date +"%Y-%m-%dT%H:%M:%SZ%:z"',
                '/sbin/ifconfig|grep eth0'
                )
        uptime, cpu_info, issue, kern, host, date, ifeth0 = run_many(t, cmds)
        c['.DeviceInfo.UpTime'] = int(uptime.split('.', 1)[0])
        cores = len(cpu_info.split('processor')) - 1
        hw = get_line_val(cpu_info, 'model name', sep=':')
        hw = hw.replace('(R)', '').replace('CPU', '')
        hw = '_'.join(hw.split())
        c['.DeviceInfo.HardwareVersion'] = '%s_CPU_%s' % (cores, hw)
        # like Debian GNU/Linux 6.0 \n \l:
        distri = issue.split('\\', 1)[0].strip()
        c['.DeviceInfo.Manufacturer'] = c['distri'] = distri.split(
                ' ', 1
                )[0]
        distri = distri.replace(' ', '')
        c['.DeviceInfo.SoftwareVersion'] = '%s|%s' % (kern, distri)
        c['.DeviceInfo.SerialNumber'] = ifeth0.split('HWaddr ',1)[1].strip()
        c['.NSLookupDiagnostics.HostName'] =host
        c['.Time.CurrentLocalTime'] = date



    def GPV_DeviceInfo_DeviceLog(self, t):
        c = t.session_cache
        if c.get('in_inform'):
            return
        c['.DeviceInfo.DeviceLog'] = t.get(
                'tail -n 100 /var/log/messages'
                )[-32768:]


    def GPV_Time_NTPServer1(self, t):
        c = t.session_cache
        for nr in range(1, 4):
            c['.Time.NTPServer%s' % nr] = ''
        buf = t.get('cat /etc/ntp.conf')
        if not 'server' in buf:
            return
        buf = buf.split('\nserver ')
        for nr in (1, 2, 3):
            try:
                c['.Time.NTPServer%s' % nr] = buf[nr].split()[0]
            except Exception:
                pass

    def GPV_Time_NTPServer2(self, t):
        depends('GPV_Time_NTPServer1', t)

    def GPV_Time_NTPServer3(self, t):
        depends('GPV_Time_NTPServer1', t)


    def GPV_WANDevice(self, t):
        ipbrief = depends('show_ifconfig', t)

    def GPV_LANDevice(self, t):
        ipbrief = depends('show_ifconfig', t)

    def GPV_ManagementServer(self, t):
        c = t.session_cache
        tr = '.ManagementServer.'
        if 'db_props' in c:
            am = c['db_props']
            c[tr + 'ConnectionRequestUsername'] = am['.AxirosAxess.CpeHandler.Axpand.Transport.AAA.User']
            c[tr + 'ConnectionRequestPassword'] = ''
        pie = 0
        pii = 86400
        if hasattr(t, 'cpe'):
            pie = t.cpe.get('.MS.PIE')
            if not pie:
                pie = 0
                t.cpe.set('.MS.PIE', pie)
            pii = t.cpe.get('.MS.PII')
            if not pii:
                pii = 0
                t.cpe.set('.MS.PII', pii)
        c[tr + 'PeriodicInformEnable'] = str(pie)
        c[tr + 'PeriodicInformInterval'] = str(pie)
        #import pdb; pdb.set_trace()


# -------------------------------Helpers


    def show_ifconfig(self, t):
        """
        """
        # to know the distri:
        c = t.session_cache
        depends('GPV_DeviceInfo', t)
        distri = c['distri']
        # main info base is ifconfig, not /proc.
        # we will split below, delete the space in the column:
        # show also down ifs:
        out, routes, dmesg = run_many(t, ('ifconfig -a',
                                       'route -n',
                                       'dmesg|grep NETDEV_CHANGE'))
        #c['.DeviceInfo.X_Axiros_Com.NativeOutput.Ifconfig'] = out
        ifs = {
            'eth': [],
            'lo':  []
              }
        nfos = {}

        # first parse ifconfig results into mappings:
        for line in lines(out):
            if not line.startswith(' ') and line.strip():
                # interface line, like: 
                # eth0      Link encap:Ethernet  HWaddr 00:30:48:d7:52:5c 
                if_name = line.split(' ', 1)[0]
                if_map = {'Name': if_name}
                # init optional values
                if_map['noIP6'] = '0'
                if_map['noIP4'] = '0'
                noIP4 = 0
                nfos[if_name] = if_map
                if_map['Status'] = 0
                if_map['MAC'] = get_in(line, 'HWaddr ')
                # last change - heavy parsing of dmesg output:
                try:
                    up = int(float(dmesg.rsplit(if_name, 1)[0].rsplit(
                                   '[', 1)[1].split(']')[0].strip()))
                    if_map['status_changed'] = c['.DeviceInfo.UpTime'] - up
                except Exception, ex:
                    if_map['status_changed'] = 'n.a.'


                for if_type in ifs:
                    if line.startswith(if_type):
                        ifs[if_type].append(if_name)
                        break
                continue
            line = line.strip()
            if line.startswith('UP '):
                if_map['Status'] = 1

            elif line.startswith('inet addr'):
                ip = get_in(line, 'inet addr:')
                net = get_in(line, 'Mask:')
                if_map['IP'], if_map['Netmask'] = ip, net
                noIP4 = noIP4 + 1
                if_map['noIP4'] = str(noIP4)

            elif line.startswith('inet6 addr'):
                ind = '1'
                if 'Scope:Link' in line:
                    ind = '2'
                if_map['IP6' + ind] = get_in(line, 'inet6 addr:').split('/')[0]
                if_map['noIP6'] = ind
                print if_map['noIP6']

            elif line.startswith('RX packets'):
                if_map['rx_packets'] = get_in(line, 'packets:')
                if_map['rx_errors'] =  get_in(line, 'errors:')
                if_map['rx_dropped'] = get_in(line, 'dropped:')

            elif line.startswith('TX packets'):
                if_map['tx_packets'] = get_in(line, 'packets:')
                if_map['tx_errors'] =  get_in(line, 'errors:')
                if_map['tx_dropped'] = get_in(line, 'dropped:')

            elif line.startswith('RX bytes'):
                if_map['rx_bytes'] = get_in(line, 'RX bytes:')
                if_map['tx_bytes'] = get_in(line, 'TX bytes:')

        # parse route results into mappings:
        #for route in lines(routes):
        #    if route.endswith(' ')
        #    print 'DBG >%s< ' %route

        # then apply the IGD logic:
        # Assumptions (tbd):
        #  WAN interface
        WAN_MAP = ['eth0', 'eth1', 'eth2']
        # - ethx : LAN interfaces (x != WAN_MAP)
        # - lo: not modelled
        # O.I - store index counters in cache ?
        #import pdb; pdb.set_trace()
        noIPIF = 0
        noWANDEV = 0
        noWANIPCON = 0
        noLANDEV = 0
        noLANETH = 0
        for if_type, if_names in ifs.items():
            for if_name in if_names:
                if_map = nfos[if_name]
                tr_node = None
                index = if_names.index(if_name) + 1
                m = if_map
                # test for WAN interfaces
                ifwan = False
                wm = False
                for wan in WAN_MAP:
                    if if_name.startswith(wan):
                        ifwan = True
                        wm = (if_name == wan)
                        break
                
                if ifwan:
                    # create WAN model
                    if wm:
                        noWANDEV += 1
                        c['.WANDeviceNumberOfEntries'] = noWANDEV
                        twan = '.WANDevice.%d.WANCommonInterfaceConfig.' % noWANDEV
                        c[twan + 'EnabledForInternet'] = '1'
                        if if_map['Status'] == 1:
                            c[twan + 'PhysicalLinkStatus'] = "Up"
                        else:
                            c[twan + 'PhysicalLinkStatus'] = "Down"
                        c[twan + 'TotalBytesSent'] = 0
                        c[twan + 'TotalBytesReceived'] = 0
                        c[twan + 'TotalPacketsSent'] = 0
                        c[twan + 'TotalPacketsReceived'] = 0
                    wan_device = '.WANDevice.%d.' % noWANDEV
                    noWANIPCON += 1
                    # for Ethernet (interface or link), only one WANConnectionDevice instance is supported:
                    c[wan_device + 'WANConnectionNumberOfEntries'] = 1
                    c[wan_device + 'WANConnectionDevice.1.WANIPConnectionNumberOfEntries'] = noWANIPCON
                    tr = wan_device + 'WANConnectionDevice.1.WANIPConnection.%d.' % noWANIPCON
                    c[tr + 'Enable'] = "1"
                    if if_map['Status'] == 1:
                        c[tr + 'ConnectionStatus'] = "Connected"
                    else:
                        c[tr + 'ConnectionStatus'] = "Disconnected"
                    put(c, tr, 'ExternalIPAddress', m, 'IP')
                    put(c, tr, 'SubnetMask', m, 'Netmask')
                    put(c, tr, 'MACAddress', m, 'MAC')
                    c[tr + 'PortMappingNumberOfEntries'] = "0"
                    tr += 'Stats.'
                    put(c, tr, 'EthernetBytesSent', m, 'tx_bytes')
                    put(c, tr, 'EthernetBytesReceived', m, 'rx_bytes')
                    put(c, tr, 'EthernetPacketsSent', m, 'tx_packets')
                    put(c, tr, 'EthernetPacketsReceived', m, 'rx_packets')
                    put(c, tr, 'EthernetErrorsSent', m, 'tx_errors')
                    put(c, tr, 'EthernetErrorsReceived', m, 'rx_errors')
                    put(c, tr, 'EthernetDiscardPacketsSent', m, 'tx_dropped')
                    put(c, tr, 'EthernetDiscardPacketsReceived', m, 'rx_dropped')
                    if 'tx_bytes' in m:
                        c[twan + 'TotalBytesSent'] += int(m['tx_bytes'])
                        c[twan + 'TotalBytesReceived'] += int(m['rx_bytes'])
                        c[twan + 'TotalPacketsSent'] += int(m['tx_packets'])
                        c[twan + 'TotalPacketsReceived'] += int(m['rx_packets']) 

                elif if_type == 'eth':
                    # create LAN interfaces model
                    k = if_name.split(':')
                    if not k[1:2]:
                        # create new LANDevice
                        noLANDEV += 1
                        c['.LANDeviceNumberOfEntries'] = noLANDEV
                        noLANETH = 0
                        tld = '.LANDevice.%d.' % noLANDEV
                        c[tld + 'LANWLANConfigurationNumberOfEntries'] = 0
                    # create new LANEthernetInterfaceConfig
                    noLANETH += 1
                    c[tld + 'LANEthernetInterfaceNumberOfEntries'] = noLANETH
                    tr = tld + 'LANEthernetInterfaceConfig.%d.' % noLANETH 
                    if if_map['Status'] == 1:
                        c[tr + 'Status'] = "Up"
                    else:
                        c[tr + 'Status'] = "Disabled"
                    #put(c, tr, 'LastChange', m, 'status_changed')
                    put(c, tr, 'MACAddress', m, 'MAC')
                    c[tr + 'Name'] = if_name
                    if 'tx_bytes' in m:
                        tr += 'Stats.'
                        put(c, tr, 'BytesSent', m, 'tx_bytes')
                        put(c, tr, 'BytesReceived', m, 'rx_bytes')
                        put(c, tr, 'PacketsSent', m, 'tx_packets')
                        put(c, tr, 'PacketsReceived', m, 'rx_packets')
                        put(c, tr, 'ErrorsSent', m, 'tx_errors')
                        put(c, tr, 'ErrorsReceived', m, 'rx_errors')
                        put(c, tr, 'DiscardPacketsSent', m, 'tx_dropped')
                        put(c, tr, 'DiscardPacketsReceived', m, 'rx_dropped')

                if tr_node:
                    # remember the node with indizes:
                    nfos[if_name]['tr_index'] = index


        #import pdb; pdb.set_trace()
        return [ifs, nfos]




# -----------  Setter Methods:

    setters = {'SPV_LANSetup': ['LANHostConfigManagement'], \
               'SPV_ManagementServer': ['ManagementServer'] \
              }
    error_markers = ['Bad ', 'nvalid ', ' ncomplete ']
    exit_context = ['exit', 'end']

    def SPV_ManagementServer(self, t):
        c = t.session_cache
        tm = c['spv_try_mode']
        ms_map = {'.ManagementServer.PeriodicInformEnable' : '.MS.PIE', \
                  '.ManagementServer.PeriodicInformInterval' : '.MS.PII' }
        for item in c['to_set_params']:
            if item in ms_map:
                if not tm:
                    if hasattr(t, 'cpe'):
                        t.cpe.set(ms_map[item], c['to_set_params'][item])
                c['have_set_params'].append(item)
        #import pdb; pdb.set_trace()

        
#FIXME: Below is Cisco.................

    def commit_on_close(self, c, t):
        # this takes long, do it only on close:
        t.get('copy running-config startup-config', timeout=10)



    def SPV_LANSetup(self, t):
        # all SPV params:
        c = t.session_cache
        params = c['to_set_params']
        # get state:
        ifs, nfos = depends('show_ip_int', t)

        # configure:
        t.get('conf t')

        # stringify SPV map:
        s_params = str(params)

        # check all ifs which are found (i.e. in c):
        for index in indizes(LD + 'LANEthernetInterfaceConfig.', c):
            if_node = LD + 'LANEthernetInterfaceConfig.%s.' % index
            ip_node = LD + 'LANHostConfigManagement.IPInterface.%s.' % index

            if_name = c.get(if_node + 'Name')
            if not if_name or not (if_node in s_params or ip_node in s_params):
                # iface not there or nothing to change on this one:
                continue

            t.get('interface %s' % if_name)
            # enable?
            key = if_node + 'Enable'
            v = params.get(key)
            set_map = {'c': c,
                       't': t,
                       'error_markers' : self.error_markers,
                       'ctx_exit': self.exit_context
                       }

            if v != None:
                # enable param set to a value. run the cmd:
                set_map['affects_params'] = key
                if str(v) == '1':
                    set_map['flow'] = 'no shutdown'
                else:
                    set_map['flow'] = 'shutdown'
                set_flow(set_map)

            # ip setup with ip address and netmask?
            ip_key =  ip_node + 'IPInterfaceIPAddress'
            net_key = ip_node + 'IPInterfaceSubnetMask'

            if ip_key in s_params or net_key in s_params:
                ip  = params.get(ip_key,  nfos[if_name]['IP'])
                net = params.get(net_key, nfos[if_name]['Netmask'])
                set_map['affects_params'] = (ip_key, net_key)
                set_map['flow'] = 'ip address %s %s' % (ip, net)
                set_flow(set_map)

            # next iface, or exit on error:
            t.get('exit')

        # back to show mode:
        t.get('end')

# -----------  Upload and Download Support:


    def do_http_cfg_upload(self, t, url, *args, **kwargs):
        res = t.get('copy run %s' % url, condition='?')
        res = t.get('', condition='?')
        res = t.get('', timeout=10)
        if 'Error' in res:
            err = get_error_line(str(res), 'Error')
            raise Exception(err)
    do_tftp_cfg_upload = do_http_cfg_upload


    def do_http_cfg_download(self, t, url, file_name, file_size,*args,**kwargs):
        if not file_name:
            file_name = 'running-config'
        else:
            t.get('delete flash:%s' % file_name, condition='?')
            t.get('', condition='onfirm]')
            t.get('')

        res = t.get('copy %s %s' % (url, file_name), condition='?')
        if 'Error' in res:
            raise Exception(get_error_line(str(res), 'Error'))
        if file_name == 'running-config':
            res = t.get('', timeout=10)
            if 'copied' in res:
                # apply it:
                t.get('copy running-config startup-config', condition='?')
                t.get('', timeout=30)
                return
            raise Exception(str(res), 'Error')

        res = t.get('', condition='?', timeout=10)
        if 'Error' in res:
            raise Exception(get_error_line(str(res), 'Error'))
        if 'Erase flash' in res:
            res = t.get('n', timeout=10)
        if 'copied' in res:
            return
        raise Exception(str(res), 'Error')
    do_tftp_cfg_download = do_http_cfg_download




# -----------  Supported TR-069 RPCs:  


    def GetParameterValues(self, params, t):
        # use the default handler:
        return handle_GPV(params, t)


    def SetParameterValues(self, params, t):
        # use the default handler:
        return handle_SPV(params, t)


    def GetParameterNames(self, params, t):
        # use the default handler:
        return handle_GPN(params, t)


    def Reboot(self, params, t):
        # we save the running config before reboot:
        res = t.get('reload', condition=']')
        if 'Save?' in res:
            res = t.get('yes', condition='onfirm]', timeout=20)
        if 'reload?' in res:
            res = t.get('confirm', condition=None)
        return {}


    def Download(self, params, t):
        return handle_Download(params, t)


    def Upload(self, params, t):
        return handle_Upload(params, t)



# register us:
MODELS["linux.LSB_IGD"] = LSB_IGD()


