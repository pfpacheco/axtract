"""Provides access to commands
    Programs like "ssh" will cause trouble because they insist on getting
    passwords from TTY instead of STDIN. Use PexpectTelnetter in those cases.
"""
import os
import signal
import subprocess

from ax.transport.base import ConnectionClosedException, \
         TooMuchDataException, ErrorConditionException
from ax.transport.connected_transport import ConnectedGetter
from ax.transport.condition_checking import build_condition_object, check_condition

class PopenComm(ConnectedGetter):
    """Provides Telnet-like access to a command.
        This has problems with programs like ssh, which insists on reading
        passwords from the tty instead of stdin. Use the PexcpectTelnetter
        for that.
        For programs that write to both STDOUT and STDERR at about the same
        time, it is undefined in which order this data will appear from the
        point of view of this module.
    """
    popen_args = None
    identification = "comm_process://%s"
    # single process comm call:
    condition = '/EOF'
    auto_reconnect = True


    def open_connection(self):
        if self.popen_args is None:
            raise ValueError("connect() called, but no $popen_args were set")
        try:
            # long line for debugging, sorry:
            return subprocess.Popen(self.popen_args, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        except Exception, exc:
            raise ConnectionClosedException(
                    "Could not start subprocess: %s" % str(exc))

    def close_connection(self, conn_obj = None):
        conn_obj = conn_obj or self._conn_obj
        try:
            # self._conn_obj.terminate() exists only in Python >=2.6
            os.kill(conn_obj.pid, signal.SIGTERM)
        except Exception, exc:
            raise ConnectionClosedException(
                    "Exception while closing: %s" % exc)
        finally:
            conn_obj = None


    def is_closed(self, conn_obj):
        """ for the auto_reconnect feature"""
        return conn_obj.stdin.closed


    def communicate(self, cmd, conn_obj, condition, error_condition, timeout, **kwargs):
        if conn_obj.stdin.closed and self.auto_reconnect:
            del conn_obj
            conn_obj = self.open_connection()
            self.set_connection_obj(obj = conn_obj)

        data = conn_obj.communicate(cmd)

        condition_obj, meta_terminator = build_condition_object(condition)
        error_condition_obj = None
        if error_condition:
            error_condition_obj, err_meta_terminator = \
                    build_condition_object (error_condition)

        success_data = ''

        if condition == '/EOF':
            success_data = data

        elif check_condition(data, condition_obj, **kwargs):
            success_data = data

        if error_condition_obj and check_condition(data, error_condition_obj, **kwargs):
            raise ErrorConditionException('data: %s' %  data)

        if len(data) > self.maxdata:
            raise TooMuchDataException()

        return success_data

