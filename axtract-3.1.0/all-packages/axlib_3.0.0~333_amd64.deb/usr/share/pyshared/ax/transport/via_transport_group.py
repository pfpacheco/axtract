"""Handling groups of transports """


from ax.transport.base import ErrorConditionException, \
        ConnectionClosedException, TimeoutException, TransportException
from ax.transport.connected_transport import ConnectedGetter
from time import sleep, time
from ax.transport.transport_access import get_transport_object
from threading import Thread, RLock
from collections import deque

STATE_INITED = 1
STATE_CONNECTED = 2
STATE_COMMUNICATING = 3
STATE_EXCEPTED = -1
STATE_FINISHED = 0
STATE_WAIT_ALARM = 10


MAX_KEEP_EXCEPTIONS = 1000000

def get_err_id(ex):
    try:
        return ex.err_id
    except:
        return 0

class OutOfTransportsException(TransportException):
    err_id = "18200"
    exceptions = None
    original_exception = None
    def __init__(self, exceptions = None, orig = None):
        self.exceptions = exceptions
        self.original_exception = orig

class TransportGroup(ConnectedGetter):
    """
    A meta transport for child transports, which it uses to communicate
    serialized or in parallel.

    Key is the settings map - it parametrizes all child transports
    """
    # in a threaded mode if we can't continue,
    # the exception will be here:
    global_exception = None

    group_size = None
    # transports instantiated:
    transports = {}
    # containing state and data:
    results = {}
    # connect at start:
    connect_at_start = []
    connected = []
    # list of (ts, number, exception_id, failover_nr)
    exceptions = None
    lock = None
    alarmers = []
    # how many comm proceses for each get:
    active = 1
    background = False
    wait_for_results = True
    active_threads = {}
    comm_calls = 1
    # how many entries to keep (None = keep all,
    # one for one comm call is reasonable:
    hist_size = None
    comm_call_sleep = 0.1

    # try the states in that order:
    exc_policies = 'alarm;failover 0 2 1 -1;retry'
    retry_backoff_factor = 1.5
    # retry forever
    retry_secs = -1
    # immediate retry:
    exception_recover_secs = 0
    in_use_for_failover = []

    def setup(self, settings):
        """ taking care for the parametrization of the transports in
        the group, plus instantiating them, unconnected"""

        # first parametrize myself:
        super(TransportGroup, self).setup(settings)

        # reasonable assumption: max 10 hist, except otherwise stated:
        # (hist is the number of results we keep for communication events)
        if not self.hist_size:
            self.hist_size = 10
            if self.comm_calls < 8:
                # to see the last exception as well:
                self.hist_size = self.comm_calls + 1

        # active ones more than connected ones? Refused:
        if self.active > len(self.connect_at_start):
            raise Exception(("active set to a higher number (%s) "
                             "than connect_at_start (%s)") \
                    % (self.active, self.connect_at_start))

        # here we'll log all exceptions:
        self.exceptions = deque([], MAX_KEEP_EXCEPTIONS)

        # failover is done one by one:
        self.lock = RLock()

        # how many transports we manage here:
        self.group_size = settings.get('group_size')
        if not self.group_size:
            raise Exception("No group size")

        # get the settings for the transports, by taking
        # mine plus adding the special ones ('s_host_2'
        # -> host of number 2):
        base_map = {}
        for k, v in settings.items():
            if not k.startswith('s_'):
                base_map[k] = v

        # one for conveniently setting ALL classes to this one:
        # (otherwise we would get transport_group vias:
        vias = settings.get('vias')
        if vias:
            base_map['via'] = vias

        t_settings = {}
        for i in xrange(self.group_size):
            t_settings[i] = {}
            t_settings[i].update(base_map)

        for k, v in settings.items():
            if k.startswith('s_'):
                k_real, s_index = k[2:].rsplit('_', 1)
                s_index = int(s_index)
                t_settings[s_index][k_real] = v
                if k_real == 'handle_alarms':
                    self.alarmers.append(s_index)


        # now we have the settings maps for all members of the group.
        # create the objects, connected or not, dependent on settings:

        for i in xrange(self.group_size):
            s = t_settings[i]
            if not s.get('via') or s['via'] == self.via:
                raise Exception ("transport %i has no via set" % i)
            try:
                self.transports[i] = get_transport_object(None,\
                        settings=s, do_connect=0)
            except Exception, ex:
                raise Exception("Can't get transport %s with setup %s"\
                        % (i, s))


    def setup_results_cache(self):
        """ Our memory over all transactions, containing
        also the thread state
        Done at beginning of all times (in setup) or at reconnect:
        """
        # here we store the results over all threads:
        for i in xrange(self.group_size):
            # at reconnect time the alarmers alre
            self.results[i] = {
                    'last_exc': (0, None),
                    'data': deque([], self.hist_size),
                    'state': STATE_INITED,
                    'req_close': False
                    }
        # and here the alarms:
        for i in self.alarmers:
            self.results[i]['state'] = STATE_WAIT_ALARM
            self.results[i]['data'] = deque([], MAX_KEEP_EXCEPTIONS)



    def send_alarms(self, err_id, exception, number, at_connect=None):
        """ feature: if handle_alarms key is in a transport, it is
        notified whenever something bad happens. It can choose if he
        wants to process"""
        for i in self.alarmers:
            t = self.transports[i]
            if exc_id in t.handle_alarms:
                try:
                    t.get('alarm', args={'err_id': err_id,\
                            'err_txt': '%s' % exception})
                except Exception, ex:
                    self.write_exception(number, ex)


    def get_failover_transport(self, failover, cmd, **kwargs):
        """ The hard part: failover. Done singlethreaded, within the lock.

        A suggestion for a reasonable failover policy is here.

        But you can supply your own one, don't forget you can load
        code at runtime:
        """
        # we will, if we find one, return a new transport nr:
        new = None
        # failover like 'failover <state1> <state2> ...
        # meaning to first try state1 then state2 ...
        # if state = excepted we wait after retries a configurable time:
        modes = failover[8:].strip().split(' ')

        if cmd == 'connect':
            # init time - only one mode, the others will be connected anyway
            # one by one:
            modes = [STATE_INITED]

        tstart = time()
        sleep_on_none_avail = 0.1 / self.retry_backoff_factor
        while (time() - tstart < self.retry_secs) or self.retry_secs < 0:
            for mode in modes:
                mode = int(mode)
                # find one which is not currently busy, to use as a failover:
                for i in xrange(self.group_size):
                    # not take one which is already taken, and also not an alarmer:
                    if i in self.in_use_for_failover or i in self.alarmers:
                        continue
                    try_connect = False
                    state = self.results[i]['state']
                    if not state == mode:
                        continue
                    if mode != STATE_EXCEPTED:
                        if cmd == 'connect' and i in self.connect_at_start:
                            # will be connected anyway:
                            continue
                        # use it right away:
                        try_connect = True
                    else:
                        # the last option, try an excepted one again?
                        exc_time = self.results[i]['last_exc'][0]
                        if time() - exc_time > self.exception_recover_secs:
                            try_connect = True
                    if try_connect:
                        try:
                            self.transports[i].connect()
                            self.results[i]['state'] = STATE_CONNECTED
                            if not i in self.connected:
                                self.connected.append(i)
                            # no other failing one should pick this one
                            # removed only at comm method:
                            if not i in self.in_use_for_failover:
                                self.in_use_for_failover.append(i)
                            return i
                        except Exception, ex:
                            # try another excepted one (if there)
                            self.results[i]['last_exc'] = (time(), get_err_id(ex), str(ex))
                            self.results[i]['state'] = STATE_EXCEPTED


            # looped over all, none useable found. block.
            # we still have the exception lock.
            sleep_on_none_avail = sleep_on_none_avail * self.retry_backoff_factor
            sleep(sleep_on_none_avail)


    def write_exception(self, number, ex, fatal = None):
        err_id = get_err_id(ex)

        self.exceptions.append([time(), number, err_id, str(ex)])

        self.results[number]['last_exc'] = (time(), err_id, str(ex))

        self.results[number]['data'].append((int(time()), err_id))

        self.results[number]['state'] = STATE_EXCEPTED

        self.results[number]['ts'] = time()

        if fatal:
            # we want to stop. Let mark it like this:
            # normally when we are out of transports.
            self.global_exception = True
            self.close()
            for i in xrange(self.group_size):
                self.results[i]['state'] == STATE_EXCEPTED
        return err_id


    def handle_exception(self, exception, number, cmd, **kwargs):
        """ in a connect or get transpaction of a transport an exception
        happened. transport.py already closed the subtransport.
        How to continue here in teh management?
        """
        # first avoid trouble:
        self.lock.acquire()

        if self.global_exception:
            # that is stopping everything anyway:
            return

        err_id = self.write_exception(number, exception)

        if number in self.connected:
            # as said, it's already closed:
            self.connected.remove(number)

        # a chain of policies:
        policies = self.exc_policies

        res = {}

        for p in policies.split(';'):
            p = p.strip()
            try:
                p_res = self.handle_exc_policy(res,
                                               err_id,
                                               exception,
                                               number,
                                               p,
                                               cmd,
                                               **kwargs)
            except Exception, ex:
                self.write_exception(number, ex, fatal = 1)
                self.lock.release()
                raise ex

        self.lock.release()
        return res


    def handle_exc_policy(self, res,
                                err_id,
                                exception,
                                number,
                                policy,
                                cmd,
                                **kwargs):
        if policy == 'alarm':
            self.send_alarms(err_id, exception, number, **kwargs)

        elif policy.startswith('failover'):
            new = self.get_failover_transport(policy, cmd, **kwargs)
            if new != None:
                res['new'] = new
                return
            raise OutOfTransportsException(self.exceptions, exception)

        elif policy.startswith('wait'):
            sleep(float(policy[4:].strip()))

        elif hasattr(self, policy):
            # custom policy:
            new = getattr(self, policy)(exception, err_id, cmd, **kwargs)
            if new != None:
                res['new'] = new
                return
            raise OutOfTransportsException(self.exceptions, exception)

        elif policy == 'retry':
            res['policy'] = 'retry'

        else:
            # do nothing:
            pass



    def open_connection(self):
        """
        entry point. called by connect of connected_transport.py.
        clean up an try with fresh confidence """
        self.global_exception = None
        self.setup_results_cache()
        self.connected = []
        for i in xrange(self.group_size):
            if i in self.connect_at_start:
                self.connect_single_transport(i)


    def connect_single_transport(self, number):
        """ we are in the main thread"""
        try:
            self.transports[number].connect()
            self.results[number]['state'] = STATE_CONNECTED
            self.connected.append(number)
        except Exception, ex:
            res = self.handle_exception(ex, number, 'connect')
            # the exc. handler already tried to connect the failover.


    def comm_threaded(self, number,
                            cmd,
                            condition,
                            error_condition,
                            timeout,
                            **kwargs):
        self.active_threads[number] = Thread(\
                target = self.single_transport_communicate,
                name='CommThread_%s' % number,
                kwargs = {'number': number,
                          'cmd' : cmd,
                          'condition' : condition,
                          'error_condition' : error_condition,
                          'timeout': timeout,
                         })
        self.active_threads[number].start()


    def single_transport_communicate(self,
                                     number,
                                     cmd,
                                     condition,
                                     error_condition,
                                     timeout,
                                     **kwargs):
        """
        Single threaded communication, comm_calls time, with sleeps
        according to comm_call_sleep in between
        """
        res = self.results[number]
        try:
            # from now one we can use it again for failover,
            # state communicating is for sure not in failover modes:
            if number in self.in_use_for_failover:
                self.in_use_for_failover.remove(number)

            t = self.transports[number]

            for i in xrange(self.comm_calls):
                if res.get('req_close'):
                    t.close()
                    break

                # run the communication:
                comm_res = self.transports[number].communicate(
                                                    cmd,
                                                    t.get_connection_obj(),
                                                    condition,
                                                    error_condition,
                                                    timeout,
                                                    **kwargs)

                self.results[number]['data'].append((time(), comm_res))
                self.results[number]['ts'] = time()
                if i < self.comm_calls - 1:
                    sleep(self.comm_call_sleep)

            if res.get('req_close'):
                if t.is_connected:
                    t.close()
            else:
                res['state'] = STATE_FINISHED

        except Exception, ex:

            res = self.handle_exception(ex, number, cmd, **kwargs)
            if not res:
                return

            if res.get('policy') == 'retry':
                self.results[res['new']]['state'] == STATE_COMMUNICATING
                # run again with the failover one:
                self.single_transport_communicate(
                                                res['new'],
                                                cmd,
                                                condition,
                                                error_condition,
                                                timeout,
                                                **kwargs)



    def communicate(self, cmd, conn_obj, condition,
                          error_condition, timeout, **kwargs):
        """ Called single threaded by my get function.

        Will do the comm one by one or in parallel, if background is set.
        """
        if self.background:
            comm_call = self.comm_threaded
        else:
            comm_call = self.single_transport_communicate

        # which ones to use for communication:
        # preferred finished or connected ones:
        use = []
        for i in xrange(self.group_size):
            if i in self.alarmers:
                continue

            if len(use) == self.active:
                break
            state = self.results[i]['state']
            if state == STATE_FINISHED or state == STATE_CONNECTED:
                use.append(i)
                self.results[i]['state'] = STATE_COMMUNICATING

        while len(use) < self.active:
            # that might except and we we let it go through. We are in the main thread:
            res = self.handle_exception(OutOfTransportsException(),
                                            -1,
                                            cmd,
                                            **kwargs)['new']

            self.results[res]['state'] == STATE_COMMUNICATING
            use.append(res)

        for i in use:
            comm_call(i, cmd, condition, error_condition, timeout, **kwargs)

        if self.background:
            if self.wait_for_results:
                for nr, t in self.active_threads.items():
                    t.join()
            if self.global_exception:
                raise OutOfTransportsException(self.exceptions)

        res = {}

        for i in xrange(self.group_size):
            if self.results[i].get('ts'):
                res[i] = {'state':    self.results[i].get('state'),
                          'data' :    tuple(self.results[i]['data']),
                          'last_exc': self.results[i].get('last_exc')}
        return res


    def close_connection(self, conn_obj):
        for i in xrange(self.group_size):
            # for background threads which are still looping
            self.results[i]['req_close'] = 1

        if self.background:
            if self.wait_for_results:
                for t in self.active_threads:
                    t.join()

        for i in xrange(self.group_size):
            if self.transports[i].is_connected and not\
                    self.transports[i].is_closing:
                self.transports[i].close()
                try:
                    if i in self.connected:
                        self.connected.remove(i)
                except:
                    pass





