"""
A parser for microflows for transport specifically
and in general for arbitrary nested method flows and results
if/else reactions parametrized within one string line
"""
user_in = '[R]sername: [S]%(user)s'
pw_in = '[R]assword: [S]%(password)s[R]'
pw_exc = '|Re: ername:[IF]ername[S1]/EXC:Unauthorized[/IF]'
# sometimes no space after ena password's ':' sometimes yes:
ena_ssh = '[R]>[S]enable[R]assword:[S]%(enable_pass)s[R]#|Re: > $[IF]>[S1]/EXC:Unauthorized[/IF]'
c_ena_ssh = '[S]term len 0' + ena_ssh
oa_telnet = '[R]name:[S]%(user)s[R]assword:[S]%(password)s[R]>|Re: name[IF]name[S1]/EXC:Unauthorized[/IF][S]term len 0[R]>/Z'


MF_LIB = {
'patton_telnet_user_pw': '[R]login: [S]%(user)s[R]password: [S]%(password)s[R]>[S]enable[R]',  
'cisco_telnet_user_pw':  user_in + pw_in + '>' + pw_exc + c_ena_ssh,
'cisco_telnet_pw': pw_in + '>' + pw_exc + c_ena_ssh,
'cisco_ssh': '[R]>' + c_ena_ssh,
'ac_ena_ssh': ena_ssh,
'oa_telnet': oa_telnet,
'linux_login_user_pass':
'[R]ogin: [S]%(user)s[R]ssword: [S]%(password)s[R]%(condition)s|Re: ogin: $[IF]%(condition)s[ELSE][S1]/EXC:Unauthorized[/IF]',
'linux_login_user_pass_fallback':
'[R]ogin: [S]%(user)s[R]assword: [S]%(password)s[R]%(condition)s|Re: ogin: $[IF]%(condition)s[S1]/UNSET:logged_in_def[ELSE][S1]%(def_user)s[R1]assword: [S1]%(def_password)s[R1]%(condition)s|Re: ogin: $[IF1]%(condition)s[S2]/SET:logged_in_def[ELSE1][S2]/EXC:Unauthorized[/IF1][/IF]',
'cisco_direct_ena':
'[R]Username: [S]%(user)s[R]Password: [S]%(password)s[R]#/Z|Re: sername: [IF]#[S1]term len 0[R1][ELSE][S1]/EXC:Unauthorized[/IF]',
'cisco_login_user_pass':
'[R]Username: [S]%(user)s[R]Password: [S]%(password)s[R]>[S]enable[R]assword:[S]%(enable_pass)s[R][S]term len 0[R]',
'cisco_direct_password':
'[R]assword:[S]%(password)s[R]>/Z[S]enable[R]assword:[S]%(enable_pass)s[R][S]term len 0[R]'
        }

from ax.transport.base import TransportException, EXT_CODE_ENV
from ax.transport.condition_checking import check_condition

class MicroflowNotFoundException(TransportException):
    """ Can't find microflow """
    err_id = 20010
EXT_CODE_ENV["MicroflowNotFoundException"] = MicroflowNotFoundException


def run_microflow(caller, method, microflow, hir = 0, **kwargs):
    """ sometimes it's handy to specify a flow within here,
    and not in user of the transport
    mf like '/F:[R]Login: [S]user[R]$ '
    or, more complex like:

        '[R]Login: [S]login_name[R]Welcome|Re: Login: [IF]Login: [S1]default_login_name[R1]$ |Re: Lo    gin: [IF1]Login: [S2]LoginException[ELSE1][S2]logged_in_def[/IF1][ELSE][S1]logged_in_normal[/IF][S]hooray, in[R]hooray, in'

    """
    DEBUG = 0
    if microflow.startswith('DEBUG:'):
        microflow = microflow[6:]
        DEBUG = 1
    if microflow.startswith('LIB:'):
        mf = microflow.split('LIB:', 1)[1].strip()
        # first check it at the caller:
        microflow = getattr(caller, mf, MF_LIB.get(mf))
        if not microflow:
            raise MicroflowNotFoundException("did not find flow %s" % mf)
        # DONT DO THIS - there could be variables changing during the flow:
        #if '%(' in microflow:
        #    microflow = microflow % caller

    # Send tag:
    S = '[S]'
    # Receive
    R = '[R]'
    IF = '[IF]'
    if hir != 0:
        # if we are nested we work with [S1], [S2]..:
        S = S.replace(']', '%s]' % hir)
        R = R.replace(']', '%s]' % hir)
        IF = IF.replace(']', '%s]' % hir)
    if microflow.startswith(R):
        # there should be first a read, not a send:
        microflow = '/WAIT' + microflow
    # split by the send blocks:
    cl = microflow.split(S)
    if DEBUG:
        print "parsed as %s" % cl
    res = ''
    for c in cl:
        if_cond = None
        if not c: continue
        if not R in c:
            c = c + R
        cmd, cond = c.split(R)
        if  IF in cond:
            # an if block is in the condition:
            # like [S]do[R]result[IF]result:[S1]send2[ELSE][/IF]
            else_flow = None
            # IF has the correct index, see above, so use it:
            ENDIF = IF.replace('[', '[/')
            ELSE = IF.replace('IF', 'ELSE')
            cond, rest = cond.split(IF, 1)
            rest  += '/'
            split = min(rest.find('/'), rest.find('['))
            if_cond = rest[:split]
            if_flow = rest[split:]
            if_flow = if_flow.split(ENDIF, 1)[0]
            if ELSE in if_flow:
                if_flow, else_flow = if_flow.split(ELSE, 1)
        if not cond:
            # string conditions should be None
            # to get self.condition in 'get'
            cond = None
        # all parsed, run it:
        if DEBUG:
            print 'calling get(%s,%s,%s), if_cond is: %s' %\
                    (cmd, cond, kwargs, if_cond)
        res = method(cmd, cond, **kwargs)
        if DEBUG:
            print 'received: %s'% res

        if if_cond:
            if '%(' in if_cond:
                # replace variables only NOW, not before:
                if_cond = if_cond % caller
 
            if check_condition(res, if_cond):
                if if_flow:
                    res = run_microflow(caller, method, if_flow, hir = hir +1)
            elif else_flow:
                res = run_microflow(caller, method, else_flow, hir = hir +1)
    return res

