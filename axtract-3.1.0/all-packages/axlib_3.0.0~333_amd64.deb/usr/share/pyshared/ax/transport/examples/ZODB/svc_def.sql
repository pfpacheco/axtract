mysql> select * from AXServiceDefinitionTable;
+----+-------------+--------------------+-----------+--------------------------------------+------------+---------+--------+------------+
| id | servicetype | name               | typeValue | defaultValue                         | columnName | comment | hidden | changeable |
+----+-------------+--------------------+-----------+--------------------------------------+------------+---------+--------+------------+
| 22 | tr69_proxy  | ext:refCPE         | str       | cpeid                                |            |         |        |            |
| 21 | tr69_proxy  | ext:enableActions  | str       | 1                                    |            |         |        |            |
| 20 | tr69_proxy  | ext:allowForPortal | str       | 1                                    |            |         |        |            |
| 19 | tr69_proxy  | user               | str       |                                      | value1     |         |        | 1          |
| 23 | tr69_proxy  | ext:actions        | eval      | ['activate', 'modify', 'deactivate'] |            |         |        |            |
| 24 | tr69_proxy  | ext:primaryKey     | eval      | ['cid']                              |            |         |        |            |
| 25 | tr69_proxy  | password           | str       |                                      | value2     |         | 1      | 1          |
| 26 | tr69_proxy  | host               | str       |                                      | value3     |         |        | 1          |
| 27 | tr69_proxy  | port               | str       |                                      | value4     |         |        | 1          |
| 28 | tr69_proxy  | acs                | str       |                                      | value5     |         |        | 1          |
| 29 | tr69_proxy  | enable_pass        | str       |                                      | value6     |         | 1      | 1          |
| 30 | tr69_proxy  | pii                | str       |                                      | value7     |         |        | 1          |
| 31 | tr69_proxy  | prov_code          | str       |                                      | value8     |         |        | 1          |
| 32 | tr69_proxy  | cache              | JSON      |                                      | generic    |         |        | 1          |
+----+-------------+--------------------+-----------+--------------------------------------+------------+---------+--------+------------+
26 rows in set (0.00 sec)

mysql> 

