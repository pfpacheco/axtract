from ax.utils.parsing           import parse_text
from time import time
from ax.utils.formatting.pretty_print import dict_to_txt
from ast                        import literal_eval
from ax.transport.jobs.axp_jobs import push_job
from simplejson import dumps, loads

def get_settings(r):
    f = r.form
    settings = {'via': 'telnet'}
    settings['allowed_cmds'] = ''
    settings['heartbeat_int'] = f.get('heartbeat_int', 30)
    settings['model'] = f['model']
    settings['model_code_uri'] = 'http://127.0.0.1:9672/tw/AX/models/IOS_TW/document_src'
    settings['newline'] = '\\r\\n'
    settings['prolog'] = '/F:LIB:cisco_direct_ena'
    settings['host'] = f['host']
    settings['user'] = f['user']
    settings['ena_password'] = 'no'
    settings['password'] = f['password']
    settings['timeout'] = f['timeout']
    settings['host'] = f['host']
    settings['condition'] = '#/Z'
    return settings

def pretty(s):
    if isinstance(s, dict):
        return dict_to_txt(s, fmt={'html': 1, 'styles': {'td': 'report3'}})
    return str(s)

def manage_poc(REQUEST):
    tstart = time()
    c = REQUEST.PARENTS[0]
    SS = c.CPEManager.AXServiceStorage
    exception = ''
    r = REQUEST
    q = r.get('workers', 'twt')
    hold = int(r.get('hold', 0))
    json = r.get('json', 0)
    if json:
        json = 'checked'
    f = r.form
    wait = int(r.get('wait', 30))
    if r.get('do_get'):
        settings = get_settings(r)
        res = {}
        m = {'SVC': r.get('twservice', ''),
             'ME-INTERFACE': r.get('ME-INTERFACE', ''),
             'EFP-ID': r.get('EFP-ID')}

        res = push_job(q, {'cmd': 'model.get_cfg',
                        'settings': settings,
                        'kw': m,
                        'hold': hold},
                        expiry = wait * 2,
                        wait = wait)
        r.set('result', pretty(res))
        r.set('msg', 'Done running the getter')


    if r.get('do_hold_demo'):
        settings = get_settings(r)
        res = {}
        for i in xrange(int(r.get('hold_runs'))):

            res['run %s' % (i+1)] = push_job(q,
                    {'cmd': r.get('do_hold_job'),
                            'settings': settings,
                            'hold': hold},
                            expiry = wait * 2,
                            wait = wait)
        r.set('result', pretty(res))
        r.set('msg', 'Total time: %s' % (time() - tstart))

    if r.get('do_add') or r.get('do_explore'):
        # full explore:
        settings = get_settings(r)
        res = push_job(q, {'cmd': 'model.get_cfg',
                        'settings': settings,
                        'hold': hold},
                        expiry = wait * 2,
                        wait = wait)
        if r.get('do_add'):
            m = {'AXP': settings}
            m['TR069'] = res['res']
            svc = {'cid': f['host'],
                    'servicetype': 'axpand',
                    'realStatusOfService' : 1,
                    'statusService' : 1,
                    'host': f['host'],
                    'password': f['password'],
                    'model': f['model'],
                    'via': settings['via'],
                    'port':f['port'],
                    'cache': m}

            SS.manage_writeService(svc)
            r.set('msg','Config and access written to AXPAND db')
        r.set('result', pretty(res))

    if json:
        return dumps(res)
    ret = "<title>AXPAND TWE POC</title>"
    ret += '<link rel="stylesheet" type="text/css" href="/manage_page_style.css" />'
    tit = {1: ('AXPAND',
               'TW Electronics POC Demonstrator',
               'Legacy & Scalable Communication Management with Axiros AXPAND'
               )}
    tit1, tit2, tit3 = tit.get(1)
    ret += """<div onclick="location.reload();">""" + getattr(c, 'ax_head')(
       tit1, tit2, tit3, 100) + '</div>'
    ret += '<br/>' * 6
    if exception:
        ret += '<font color="red">%s</font><br>' % exception
    if r.get('msg'):
        ret += '<font color="green">%s</font><br>' % r.get('msg')
    ret += """
<hr />
<form method="GET">
    """

    ret += """<table>
           <tr>
           <th width="200px" class="report5" nowrap>Hold <input size="3" type="text" name="hold" value="%s"/> secs<input type="checkbox" name="json" %s/>as json</th>
              <th colspan="20" class="report5">
           <b>Access Settings</b>
            <input type="submit" name="do_explore" value="explore device"/>
            <input type="submit" name="do_add" value="add device"/>
           </th></tr>
           <tr>
            """ % (hold, json)

    for k, v, d, default in (
            ('Queue', 'workers', 'Where to run the flows', 'twt'),
            ('<b>Host</b>', 'host', 'Hostname or IP', '66.162.110.43'),
            ('Port', 'port', '', 23),
            ('User', 'user', '', 'axiros'),
            ('Password', 'password', '', 'Lab@cc3ss!'),
            ('Timeout', 'timeout', 'Socket timeout [sec]', 20),
            ('Heartbeat', 'heartbeat_int', 'Heartbeat when holded [sec]', 60),
            ('Model', 'model', 'Business logic', 'cisco.IOS_TW_1'),
            ):
        note = ''
        if v == 'host':
            note = '<br><font color="grey" size="-2">If added this is enough</font>'
        ret += """
        <td class="report3">%s
            <input type="text" maxlength="20" name="%s"
            value = "%s" title="%s">%s\
                 </td>""" % (k, v, r.get(v, default), d, note)
    ret += '</tr></table>'
    #---------------------------------------------------------------------------
    ret += '<br><hr><br>'
    ret += """<table>
           <tr> 
           <th width="200px" class="report5" nowrap>Runs <input size="3" type="text" name="hold_runs" value="%s"/> times</th>
           <th colspan="20" class="report5">
                <b>Socket Holding </b>
                <input type="submit" name="do_hold_demo" value="run hold demo"/>
                <input type="text" name="do_hold_job" value="%s" size="30"/>
                </th>
            <tr><td colspan="2" class="report3">Enter a hold time in second (above) 
            and a repitition count.
            The comm. socket will remain open with periodic heartbeat running in
            the configured intervals to keep it open potentially long.
            If the communication breaks it will be reastablished at the next job.
            Note: There should be significant improvements in turnaround time when holding.
            </td></tr>
        </table>""" % (r.get('hold_runs', 3), r.get('do_hold_job', 'show clock'))
    #---------------------------------------------------------------------------
    ret += '<br><hr><br>'
    ret += """<table>
           <tr>
           <th colspan="20" class="report5">
           <b>Getters</b>
            <input type="submit" name="do_get" value="Run Getter"/>
           </th></tr>
           """
    for k, v, d, default in (
            ('Service', 'twservice', '', 'ME3600_EIS_IPVPN_Basic_SNLAN_Untagged'),
            ('ME-INTERFACE', 'ME-INTERFACE', '', 'GigabitEthernet0/2'),
            ('EFP-ID', 'EFP-ID', '', ''),
            ):
        ret += """
        <td class="report3">%s
            <input type="text" maxlength="20" name="%s"
            value = "%s" title="%s"></td>\
                    </td>""" % (k, v, r.get(v, default), d)
    ret += """<tr><td class="report3">That shall demonstrate how the filters in our
             getter methods in the model work.</td></tr>"""
    ret += "</table>"
    #---------------------------------------------------------------------------
    ret += '<br><hr><br>'
    ret += """<table>
           <tr>
           <th colspan="20" class="report5">
           <b>Getters</b>
            <input type="submit" name="do_get" value="Run Getter"/>
           </th></tr>
           """
 
    mc = ''
    ret += """</td></tr><tr><th class="report3">Arbitrary calls on the model<td>
            <td class="report5"><select name="model_call">
            %s
            </select></td><td><input=name="model_call_params" value="%s"/>
            </table>""" % (mcalls_options, r.get('model_call_params', ''))



 
    ret +='</form>'
    if r.get('result'):
        ret +='<hr>%s' % r.get('result')
    rf = dict_to_txt(r.form)
    ret += """<hr><font color="lightgrey" size="-2">Processing time: %2d ms
    <br>
    27/02/2013 Axiros GmbH</font>

    <!--
Request parameters:
%s
-->
    """\
            %(((time()-tstart)/1000), rf)


    return ret
