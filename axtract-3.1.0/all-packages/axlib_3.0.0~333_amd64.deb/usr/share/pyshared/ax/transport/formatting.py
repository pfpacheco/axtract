""" Static flow handling methods """

from condition_checking import check_condition
from ax.utils.formatting.pretty_print import obj_to_html_list
from ax.utils.formatting.pretty_print import show_unprintable
from ax.utils.formatting.pretty_print import repl_unprintable
from ax.utils.formatting.ansi2html import Ansi2HtmlWriter

import cgi
import re

class FormatterException(Exception):
    err_id = 18700

# output formatters:
def fmt_condition_strip (t,ret_as, cmd, res, spec = None):
    """ reduce the result only to the output of the box
    removing the command and the condition """
    # check if the result starts with the cmd:
    if res.startswith(cmd):
        res = res.split(cmd, 1)[1]
    # is the last line matching the condition? If so cut it:
    if not '\n' in res:
        return res
    pre, prompt = res.rsplit('\n', 1)
    if check_condition(prompt, t.condition):
        res = pre
    return res.strip()


def fmt_replace(t, ret_as, cmd, res, spec = None):
    repl_spec = getattr(t, 'fmt_replacements', '')
    if not repl_spec or not ':' in repl_spec:
        raise Exception("no fmt_replacements parameter found - supply parameter. Example: fmt_replacements foo:bar,/n:sep char  (to replace 'foo' with 'bar' and lineseperators with the string 'sep char')")
    for rspec in repl_spec.split(','):
        if not ':' in rspec: continue
        rfrom, rto = rspec.split(':')
        rfrom = repl_unprintable(rfrom.strip()).replace('/SPC', ' ')
        rto = repl_unprintable(rto.strip()).replace('/SPC', ' ')
        res = res.replace(rfrom, rto)
    return res


def fmt_ansi2html(t, ret_as, cmd, res, spec = None):
    w = Ansi2HtmlWriter()
    return w.write(res)


def fmt_html (t, ret_as, cmd, res, spec = None):
    hres = obj_to_html_list(res)
    return hres

def fmt_show_unprintable(t, ret_as, cmd, res, spec = None):
    return show_unprintable(res)

def format_result (t, ret_as, cmd, received, spec):
    """
    A formatting function that somehow modifies the results before we
    put it into $ret_map.
    We can specify formatters separated by '/;' as 'fmt' argument in the
    spec.
    Further we can supply base formatters in derivations of this class.
    The formatting functions themselves have to be defined in derivations
    of this class. We supply a number of them in the module formatters.py
    """
    # these the transporter always wants:
    formatters = getattr(t, 'formatters', '')
    if spec and spec.get('fmt'):
        formatters += '/;' + spec.get('fmt', '')

    if formatters:
        formatters = formatters.split('/;')
        for formatter in formatters:
            if not formatter:
                continue
            f_name = 'fmt_' + formatter
            in_t = getattr(t, f_name, None)
            try:
                if in_t:
                    received = in_t(ret_as, cmd, received, spec)
                else:
                    try:
                        received = globals().get('fmt_' + formatter)\
                          (t, ret_as, cmd, received, spec)
                    except:
                        pass
            except Exception, e:
                raise FormatterException ("%s: %s" % (formatter, e))
    return received


