from ax.transport.base import ConnectionClosedException, \
        TimeoutException
from ax.transport.telnetter import Telnetter

class SocketTelnetter(Telnetter):
    """A mostly abstract class for all telnetters that work directly on sockets.
        This includes socket objects as provided by Python's own "socket"
        module, as provided by "gevent" and probably also as provided by
        similar frameworks.
        What is left to be implemented is the way in which sockets are actually
        created and stored in self._socket, either in __init__() or in connect().

        Note that this implementation tempers with self._socket.settimeout()
        in many places. Make sure you set it to your liking before doing
        anything.
    """


    # The host and port to connect to. These must be something where
    # str(self.host) and int(port) would be acceptable for the
    # socket.connect() function.
    host = None
    port = None

    # If our TCP connection should originate from a certain IP, set this
    # value. It acts like the "-b" of telnet or the "-s" of netcat.
    bind_ip = None

    # Whatever module we use to implement the builtin "socket" type of
    # functions. Could be the real "socket" or "gevent.socket" or
    # something else. This must be set by the __init__ of our subclasses.
    _socket_module = None


    def open_connection(self):
        """Create the TCP connection as defined in the self.xxx variables
        We rely on the calling logic to not call this if the socket is
        still established (!= None here). Since we would not reconnect if
        the server closed the connection.
        """

        if self.host is None or self.port is None:
            raise ValueError("connect() called with host:'%s', port:'%s'" %
                    (self.host, self.port))
        if self._socket_module is None:
            raise ValueError("connect() called but not _socket_module was set")

        # Just a typing shortcut
        socket = self._socket_module
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(self.timeout)
        if self.bind_ip:
            try:
                # "0" as a port means we do not care.
                sock.bind((self.bind_ip, 0))
            except socket.error, exc:
                msg = "Could not bind socket to '%s'"
                raise ConnectionClosedException(msg % self.bind_ip)
        try:
            sock.connect((self.host, int(self.port)))
        except socket.timeout:
            raise TimeoutException("Timout connecting to host '%s' port '%s'" %
                    (self.host, self.port))
        except socket.error, exc:
            msg = "Could not connect to host '%s' port '%s'. " \
                    "Original exception: %s"
            raise ConnectionClosedException(
                    msg % (self.host, self.port, str(exc)))
        return sock


    def send_data(self, data, conn_obj):
        pass

    def read(self, timeout, maxdata, conn_obj):

        conn_obj.settimeout(timeout)

        try:
            new_data = conn_obj.recv(maxdata)
        except self._socket_module.timeout:
            raise TimeoutException()

        if new_data == "":
            # This happens if the other side has closed the connection.
            raise ConnectionClosedException()
        return new_data

