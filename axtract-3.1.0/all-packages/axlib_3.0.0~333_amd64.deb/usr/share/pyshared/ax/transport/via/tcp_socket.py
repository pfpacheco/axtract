"""Implementation of a SocketTelnetter using the builtin "socket" module."""
from ax.transport.base import ConnectionClosedException, TimeoutException
from ax.transport.generic_socket import SocketTelnetter
import socket

class PythonSocketTelnetter(SocketTelnetter):
    """Implementation of a SocketTelnetter using Python's "socket" module
    """
    def __init__(self):
        super(PythonSocketTelnetter, self).__init__()
        # Python's builtin socket module
        self._socket_module = socket

    def send_data(self, data, conn_obj):
        super(PythonSocketTelnetter, self).send_data(data, conn_obj)
        try:
            conn_obj.sendall(data)
        except socket.error, exc:
            # Maybe the other side has closed the connection
            raise ConnectionClosedException(str(exc))

