from os import urandom
from hashlib import md5
from hashlib import sha1
import time

def parse_keqv_list(l):
    """Parse list of key=value strings where keys are not duplicated."""
    parsed = {}
    for elt in l:
        k, v = elt.split('=', 1)
        if v[0] == '"' and v[-1] == '"':
            v = v[1:-1]
        parsed[k] = v
    return parsed

def parse_http_list(s):
    """Parse lists as described by RFC 2068 Section 2.

    In particular, parse comma-separated lists where the elements of
    the list may include quoted-strings.  A quoted-string could
    contain a comma.  A non-quoted string could have quotes in the
    middle.  Neither commas nor quotes count if they are escaped.
    Only double-quotes count, not single-quotes.
    """
    res = []
    part = ''

    escape = quote = False
    for cur in s:
        if escape:
            part += cur
            escape = False
            continue
        if quote:
            if cur == '\\':
                escape = True
                continue
            elif cur == '"':
                quote = False
            part += cur
            continue

        if cur == ',':
            res.append(part)
            part = ''
            continue

        if cur == '"':
            quote = True

        part += cur

    # append last part
    if part:
        res.append(part)

    return [part.strip() for part in res]


class DigestAlgorithm(object):
    def __init__(self, username, password, path):
        self.username = username
        self.password = password
        self.path = path
        self.nonce_count = 0
        # only used if algorithm="MD5-sess"
        self.last_cnonce = None

    def get_challenge(self, request_headers):
        authreg = request_headers.get('www-authenticate')
        if not authreg:
            return None

        scheme = authreg.split()[0].lower()
        if scheme == 'digest':
            return authreg.split(' ', 1)[1]
        return None

    def calc(self, challenge):
        chal = parse_keqv_list(parse_http_list(challenge))
        auth = self.get_authorization(chal)
        if auth:
            return 'Digest %s' % auth

    def get_authorization(self, chal):
        try:
            realm = chal['realm']
            nonce = chal['nonce']
            # AX-modify
            qop = [ x.strip() for x in chal.get('qop', '').split(',') ]
            # It can happen that we get an empyt string in our list
            # (filter them out)
            qop = [ x for x in qop if x]

            algorithm = chal.get('algorithm', 'MD5')
            # some CPEs send a lowerclase algorithm
            # algorithm should be case-insensitive according to RFC2617
            algorithm = algorithm.upper()
            # mod_digest doesn't send an opaque, even though it isn't
            # supposed to be optional
            opaque = chal.get('opaque', None)
        except KeyError:
            return None

        H, KD = self.get_algorithm_impls(algorithm)
        if H is None:
            return None

        user, pw = self.username, self.password
        if user is None:
            return None

        # XXX not implemented yet
        entdig = None

        cnonce = None
        if algorithm == "MD5-SESS":
            if nonce != self.last_cnonce:
                self.last_cnonce = self.get_cnonce(nonce)
            cnonce = self.last_cnonce
            A1 = "%s:%s:%s" % (H("%s:%s:%s" %  (user, realm, pw)), nonce, cnonce)
        else:
            A1 = "%s:%s:%s" % (user, realm, pw)

        # XXX selector: what about proxies and full urls
        A2 = "%s:%s" % ('GET', self.path)

        # AX-
        if 'auth' in qop:
            self.nonce_count += 1
            ncvalue = '%08x' % self.nonce_count
            if not cnonce:
                cnonce = self.get_cnonce(nonce)
            noncebit = "%s:%s:%s:%s:%s" % (nonce, ncvalue, cnonce, 'auth', H(A2))
            respdig = KD(H(A1), noncebit)
        elif not qop:
            respdig = KD(H(A1), "%s:%s" % (nonce, H(A2)))
        else:
            # XXX handle auth-int.
            pass

        # XXX should the partial digests be encoded too?

        base = 'username="%s", realm="%s", nonce="%s", uri="%s", ' \
               'response="%s"' % (user, realm, nonce, self.path, respdig)

        if opaque:
            base = base + ', opaque="%s"' % opaque
        if entdig:
            base = base + ', digest="%s"' % entdig

        # AX- always send the algorithm
        base = base + ', algorithm="%s"' % algorithm
        if qop:
            base = base + ', qop=auth, nc=%s, cnonce="%s"' % (ncvalue, cnonce)
        return base

    def get_cnonce(self, nonce):
        # The cnonce-value is an opaque
        # quoted string value provided by the client and used by both client
        # and server to avoid chosen plaintext attacks, to provide mutual
        # authentication, and to provide some message integrity protection.
        # This isn't a fabulous effort, but it's probably Good Enough.
        dig = sha1("%s:%s:%s:%s" % (self.nonce_count, nonce, time.ctime(),
                                            urandom(8))).hexdigest()
        return dig[:16]

    def get_algorithm_impls(self, algorithm):
        # lambdas assume digest modules are imported at the top level
        if algorithm in ('MD5', "MD5-SESS"):
            H = lambda x: md5(x).hexdigest()
        elif algorithm == 'SHA':
            H = lambda x: sha1(x).hexdigest()
        else:
            msg = "Unknown digest authentication algorithm: %s"
            raise ValueError(msg % algorithm)

        KD = lambda s, d: H("%s:%s" % (s, d))
        return H, KD
