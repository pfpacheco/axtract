from ax.transport.model.keyval import depends
from ax.transport.model.model_support import add_model
from ax.transport.model.protocols.snmp import SNMP

# we work only via these:
DI = '.DeviceInfo.'

class LinuxSNMP(SNMP):
    root = 'D'
    dev  = 0.1
    model = 'DEV2'
    matching = 'linux.snmp'

    def GPV_DeviceInfo(self, t):
        c = t.session_cache
        buf = depends('GET:1.3.6.1.2.1.1.1.0,1.3.6.1.2.1.25.1.4.0', t)
        try:
            sv = '-'.join(buf[0].split(' ')[2].split('-')[0:2])
        except Exception:
            sv = 'NA'
        try:
            hv = buf[0].split(' ')[-1]
        except Exception:
            hv = 'NA'
        try:
            #don't know if its a good idea to use this as a unique id
            #for a linux server
            sn = buf[1].split(' ')[1].split('UUID=')[1]
        except Exception:
            sn = 'NA'
        c[DI + 'Manufacturer'] = 'Linux'
        c[DI + 'ManufacturerOUI'] = '00067C'
        c[DI + 'ProductClass'] = 'AXPAND'
        c[DI + 'SoftwareVersion'] = sv
        c[DI + 'SpecVersion'] = str(self.rev)
        c[DI + 'SerialNumber'] = sn
        c[DI + 'HardwareVersion'] = hv

# -------------------------------Helpers
add_model(('linux.SNMP', LinuxSNMP()))

RUN = ""
