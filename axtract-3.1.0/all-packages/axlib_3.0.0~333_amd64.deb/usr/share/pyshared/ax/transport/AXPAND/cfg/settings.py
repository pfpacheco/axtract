DEBUG = True
TEMPLATE_DEBUG = True

TEMPLATE_DIRS = (
    '/opt/ax/utils/lib/web/portals',
    '/opt/AXPAND/portal/sections'
)

STATIC_URL = '/static/'
SECRET_KEY = 'foobar12^%'
TEMPLATE_LOADERS = [
        'django.template.loaders.filesystem.Loader',
        'django.template.loaders.app_directories.Loader',
]


CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'unique-snowflake'
    }
}
# for the template tags folders:
INSTALLED_APPS = (
    'ax1', 'AXPAND'
)

# sections which we have to load in any case
# to build the main page:
AX_STARTUP_LOAD = ['settings']
