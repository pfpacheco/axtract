import unittest2
import os
from ax.transport.axpand import gto
from time import time
from inspect import getsourcefile
from ax.transport.model.model_support import MODELS
from ax.utils.formatting.pretty_print import dict_to_txt
from ast import literal_eval
import logging
logging.basicConfig(level=logging.DEBUG)

TESTED = {}
class ModelTests(unittest2.TestCase):
    # overwritten:
    modelmatch = 'xxx'

    def test__all_flows(self):
        for k, v in MODELS.items():
            self.run_flows(k, v)


    def run_flows(self, model_name, mobj):
        if not self.modelmatch in model_name:
            return
        print '\nsearching test specs for %s' % model_name
        tdir = getsourcefile(mobj.__class__).rsplit('/', 1)[0]
        tdir += '/tests/'
        if not os.path.exists(tdir):
            return
        # search for flows in all <modelname>_<rev> subfolders:
        for f in os.listdir(tdir):
            spec_dir = os.path.join(tdir, f)
            if not f.startswith('flows_%s_' % model_name):
                # we will come to that by the caller's scanning all MODELS:
                continue

            specs = os.listdir(spec_dir)
            for spec in specs:
                try:
                    specfile = os.path.join(spec_dir, spec)
                    testmap = literal_eval(open(specfile).read())
                    tests = testmap.get('tests')
                except:
                    print 'Unparsable spec file %s' % specfile
                    continue

                info = {}
                for nfo in ('At', 'Model', 'ModelRev', 'job', 'jobArgs'):
                    info[nfo] = testmap.get(nfo)

                print dict_to_txt({'Test': info})
                settings = testmap['Settings']
                settings['testmap'] = testmap
                settings['testmode'] = 'run: %s' % f
                t = gto(str(time()), settings = settings)
                meth = getattr(t.model, testmap['job'])
                args = testmap['jobArgs']
                args += (t,)
                res = apply(meth, args)
                check = testmap.get('Checkmode')
                expected = testmap.get('jobResult')
                c = t.session_cache
                self.assertDictContainsSubset(expected, c)

                

