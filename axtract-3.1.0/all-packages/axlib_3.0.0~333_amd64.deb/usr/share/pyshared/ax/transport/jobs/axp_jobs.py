""" We have zmq style queing in the code,
    ready to be used as alternative to redis

    Strategy for queing is broker less, i.e.
    all clients of a certain queue connect to all servers
    in the cluster to get jobs.
"""
from time import sleep, time
import re
import os
from ax.utils.redis.client import RedisClient, ConnectionProblem
# when we don't use the failover feature:
from redis import Redis
from zlib import decompress
from cPickle import loads as unpickle
from cPickle import dumps as pickle
from threading import Thread, Lock
from ax.utils.parsing.parse_text import convert_fmt
from os import getpid
import logging
logger = logging.getLogger(__name__)


class MessageQueueSizeExceeded(Exception):
    pass

# we paginate jobs by expiry time, every minute
PAGINATION_INT = 60

# if no expiry is set this is the default:
DEF_LIFETIME = PAGINATION_INT

JOB_EXPIRED          = 0
JOB_WAIT_EXPIRED     = 1
JOB_CLEARED          = 2
JOB_QUEUED           = 3
JOB_PICKED           = 4
JOB_NOT_PUSHED       = 5
# from queue_worker:
JOB_STATUS_SUCCESS   = 10
JOB_STATUS_FAILED    = 20
# pretty status:
PS = {0: 'Job Expired', 1: 'Job Wait Expired', 2: 'Job Cleared', 3: 'Job Queued',
      4: 'Job Picked' , 5: 'Not pushed, queue db not ready',
      10: 'Job Run Success', 20: 'Job Run Error'}


def successify(res, reason):
    """ at postprocessing it was found that a result was ok. Remove all errors """
    res['status']        = JOB_STATUS_SUCCESS
    res['status_pretty'] = 'Declared OK: %s' % reason
    if 'err_id' in res:
        del res['err_id']


def format_job_res(res, tstart=0, **kw):
    if isinstance(res, int):
        # job is still on server
        res = {'status': res,
               'status_pretty': PS.get(res, 'Unknown')
               }
        if tstart:
            res['pt'] = time() - tstart
        if kw:
            res.update(kw)
        return res

    if isinstance(res, (str, unicode)):
        try:
            res = unpickle(res)
        except:
            res = unpickle(decompress(res))
    res['status_pretty'] = PS.get(res['status'], 'Unknown')
    if kw:
        res.update(kw)
    return res


REDIS_DB = 10

JOB_COUNTER = 0

Q_REMAPPINGS = {}

DEF_JOB_EXPIRY = 10

class PusherThread(Thread):
    """ needed when we call multiple workers at the same time, blocking """
    def __init__(self, res, rpusher, push_args):
        self.push_args = push_args
        self.res = res
        self.rpusher = rpusher

    def run(self):
        my_res = apply(self.rpusher.push_job, self.push_args)
        # first arg is the process queue
        self.res[self.push_args[0]] = my_res


# useful for debugging, redirecting all redis AXP connections to this one,
# process local:
ENVIRON_REDIS = os.environ.get('DEFAULT_REDIS', '127.0.0.1')
class RedisPusher(object):
    def __init__(self, hosts=ENVIRON_REDIS):
        '''
        hosts can be like "<host>, <failover>"
        "ip:port" supported for host and failover
        '''
        logger.debug('Creating a Redis client at %s' % hosts)
        hosts = hosts.replace(' ', '')
        if ',' in hosts:
            host, failover = hosts.split(',')
        else:
            host = hosts
            failover = None
        if failover:
            self._redis = RedisClient(host=host, failover=failover, db=REDIS_DB)
        else:
            if not ':' in host:
                host += ':6379'
            host, port = host.split(':', 1)
            self._redis = Redis(host=host, port=int(port), db=REDIS_DB)
        logger.info('Created Redis Client: %s' % self._redis)

    def job_queue_status(self, jobid):
        ql = self._redis.llen('job:%s' % jobid)
        if ql == 2:
            return JOB_QUEUED
        if ql == 1:
            # job is popped from the queue by a worker:
            return JOB_PICKED
        if ql == 0:
            # job is popped from the queue by a worker:
            return JOB_EXPIRED


    def push_job(self, mq, jobid, job, expiry, max_items, wait, lpush):
        """ we rpush a job's ID into the queue, the real job is an expiring key
        The workers will pop the job ids and then the real jobs if not expired.
        That way we avoid sending over expired jobs over the Network.
        """
        r = self._redis

        # now for jobs for more than one or for dedicated HOSTS:
        if mq.startswith('ALL:'):
            return self.handle_multi_worker_call(mq, jobid, job, expiry,
                                    max_items, wait, lpush)


        if max_items:
            items = r.llen(mq)
            if items > max_items:
                msg = "Queue %s at %s items, max is %s" % (mq, items, max_items)
                raise MessageQueueSizeExceeded(msg)

        expiry = expiry or wait or DEF_LIFETIME
        if not isinstance(expiry, int):
            raise ValueError("expiry and wait must be integers")
        tstart     = time()
        tint       = int(tstart)
        # our jobs paginated by time - the same for all jobs in this t interval:
        pagin_t    = tint - (tint % PAGINATION_INT)
        ref_jobid  = 'jobref:%s:%s'   % (pagin_t, jobid)
        full_jobid = 'job:%s' % jobid

        # two element queue - which is in for maximum <expiry> seconds:
        # the second one is to determine if the job is picked:
        #TODO: could be one transaction:
        p = r.pipeline()
        p.rpush(full_jobid, job)
        # to see expiries:
        p.rpush (full_jobid, 1)
        p.expire(full_jobid, expiry)

        # now let the worker find the ref to the full_jobid::
        remapped = Q_REMAPPINGS.get(mq)
        if remapped:
            to_q, match = remapped
            if re.search(match, job):
                mq = to_q

        if not lpush:
            # default:
            p.rpush(mq, ref_jobid)
        else:
            p.lpush(mq, ref_jobid)
        # if no one wants it for a day we should really remove the ref
        # Note: we only keep it very longer then the jobs themselves to
        # see overload situations where jobs are long not picked:
        p.expire(ref_jobid, 86400)
        p.execute()

        if wait:
            # we block now in this thread, waiting for result:
            # we rely here on the multithreading capabilities of the redis lib,
            wait_q = 'jobres_wait:%s' % jobid
            res = r.blpop(wait_q, wait)
            if not res:
                if self.job_queue_status(jobid) == JOB_QUEUED:
                    return format_job_res(JOB_QUEUED, tstart)
                return format_job_res(JOB_WAIT_EXPIRED, tstart)
            id, res = res
            return format_job_res(res, tstart)
        else:
            # clients can run check_job on it:
            return jobid


    def get_job(self, jobid, expire_in=None, wait=None):
        """ check the job keys if
        *) still present        -> no worker yet picked it
        *) empty                -> job, popped, in processing
        *) gone                 -> processed or expired.

        using expire_in you can prolong or shorten expiries

        """
        job_res = 'jobresult:%s' % jobid
        r = self._redis
        if expire_in == -1:
            r.expire(jobid)
        if self.job_queue_status(jobid) == JOB_QUEUED:
            return format_job_res(JOB_QUEUED)
        # job is picked. result ready?
        # is it processing or there:
        res = r.get(job_res)
        if res:
            if expire_in != None:
                r.expire(job_res, expire_in)
            return format_job_res(res)

        # no result yet, job picked:
        if not wait:
            return format_job_res(JOB_PICKED)

        # client wants to wait blocking for result:
        fin_q =  'jobfin:%s' % jobid
        # all result waiting clients get waked up now:
        fin = r.brpoplpush(fin_q, fin_q, wait)
        if not fin:
            if self.job_queue_status(jobid) == JOB_QUEUED:
                return format_job_res(JOB_QUEUED)
            return format_job_res(JOB_WAIT_EXPIRED)
        res = r.get(job_res)
        if not res:
            return format_job_res(JOB_WAIT_EXPIRED)
        id, res = res
        if expire_in != None:
            r.expire(job_res, expire_in)
        return format_job_res(res)


    def handle_multi_worker_call(self, mq, jobid, job, expiry,
                                 max_items, wait, lpush):
        """
        handling of jobs which begin with ALL:... must be pushed to many
        workers

        mq like ALL:@218.24 or ALL:SB (which we substring match)
        """
        def get_proc_q(w):
            # w form pubsub listen, like:
            # proc,unittestsqueue2,unittestsqueue:26864@paral<-127.0.0.1
            # we want the proc queue:
            pidhost = w.split(':', 1)[1].split('<-', 1)[0]
            return 'proc:' + pidhost

        mq = mq[4:]

        # expiry must be int -> we take millis for wait:
        def_exp = 0.1
        if not expiry > 0:
            raise Exception(("expiry for 'ALL:..' jobs must a reasonable "
                             "amount of milliseconds to wait for workers "
                             "informing us about their presence. Default is "
                             " %s [millisecs]" % def_exp))
        if expiry == DEF_JOB_EXPIRY:
            # reasonably safe, 100ms rount trip to the job workers:
            m_expiry = def_exp
        else:
            m_expiry = expiry / 1000.

        # get the proc queues of current workers:
        r = self._redis

        if 'send_stats' in job:
            r.publish('ALLMQs', 'send_stats')
            return 'stats collection triggered'

        r.publish('ALLMQs', 'get_workers')
        # we now get busy looping, we don't know whats out there:
        w = 0
        wold = -1
        while w != wold:
            sleep(m_expiry)
            wold = w
            w = r.scard('job_workers')
        ws = []
        for w in r.smembers('job_workers'):
            ws.append(w)

        # now filter: get the workers the client wants:
        # either host or queues:
        my_ws = []
        if mq.startswith('@'):
            # hosts:
            for w in ws:
                if mq in w:
                    my_ws.append(get_proc_q(w))

        else:
            # queues:
            for w in ws:
                if mq in w.split('<-', 1)[0]:
                    my_ws.append(get_proc_q(w))


        if 'get_workers' in job:
            # client wanted to know only:
            return my_ws


        # and now finally push the job to the targets:
        res = {}
        if not wait or wait < 2:
            # we an push one by one, no blocking:
            # wait = 1 is minimum wait -> pretty fast job.
            for w in my_ws:
                res[w] = self.push_job(w, 'ALL->%s->%s' % (w, jobid), job, expiry,
                                    max_items, wait, lpush)
        else:
            # we have to push and wait in parallel, since job could take looong:
            threads = []
            for w in my_ws:
                thread = PusherThread(res, self, (w, jobid, job, expiry,
                                max_items, wait, lpush))
                threads.append(thread)
                thread.start()
            for t in threads:
                t.join()

        return res

    def stats(self, job):
        """ return the results of send_stats cmds on pubsub """
        since = int(job.get('from', 0))
        r = self._redis
        del_pipe = r.pipeline()
        workers = r.zrange('job_stats', 0, -1)
        res = {}
        for worker in workers:
            m = {}
            res[worker.split('jobs_stats_', 1)[1]] = m
            wres = r.zrangebyscore(worker, since, '+inf', withscores=1)
            if not wres:
                del_pipe.delete(worker)
                del_pipe.delete(set)

            for stat, t in wres:
                m[t] = unpickle(stat)

        if 'timeline' in job:
            # reorder: return dict with keys = ts:
            tres = {}
            for w, tser in res.items():
                for ts, qsm in tser.items():
                    tm = tres.setdefault(ts, {})
                    for q, stats in qsm.items():
                        byq = tm.setdefault(q, {})
                        byq[w] = stats
            return tres

        return res



REDIS_BY_IP = {}
# to create only one per IP, its threadsafe:
C_LOCK = Lock()


#-------------------------------- API entry from outside - one call:

def push_job(queue, job, expiry=DEF_JOB_EXPIRY,
        max_items=0, wait=None, lpush=0, server=ENVIRON_REDIS):
    try:
        return try_push_job(queue, job, expiry, max_items, wait, lpush, server)
    except ConnectionProblem, ex:
        return format_job_res(JOB_NOT_PUSHED,
                err='Redis Connection Problem (failover client): %s' % str(ex))
    except Exception, ex:
        return format_job_res(JOB_NOT_PUSHED,
                err='Redis Connection Problem: %s' % str(ex))


from uuid import uuid4
def try_push_job(queue, job, expiry=DEF_JOB_EXPIRY,
             max_items=0, wait=None, lpush=0, server='127.0.0.1'):
    """
    Push a job onto a queue.
    Typically called by AXESS within scripts.
    The job is either dict or ax human format.
    We push jsonized format of it to a local redis queue, to wich worker connect
    Result is sent back to this redis server then.

    :param wait = max wait time in secs for the answer -
            we block waiting for that long max.
    :param: expiry: the lifetime of a job
    :param: max_items: reject job if there are this number in the queue
    :param: lpush: insert LIFO style

    job parameters:
        Typically: {'cmd': <transport get command>,
                    'settings': <transport settings map with via>,
                    '<args>: <arguments for the transport's comm calls.
                    }
        Other parameters:
        jobid: id on all logs, key in redis for the job.
               Autocreated if not given
        pool_id: Nails a transport pool key.
               If the connection_pooling is set as well then it should descr.
                the connection end point.
               Using it you can leave a transport instantiated and/or send future jobs to it
               using the process queue.
        wait_status=1: the calling client with wait set does just want to get the
                       status (success/fail), not the full result (default)
        set_result=<expiry_secs>:
                           Write the job result into redis, ready for other
                           processed to fetch via a 'get' call
        set_status=<secs>: Write the job status into redis, ready for other
                           processed to fetch via a 'get' call

    Running jobs on specific worker processes:
    If queue is a dict we check if its a result from a previous job incl.
    the worker key.
    We automatically queue this job then to the process queue
    there (setting queue to "proc:<pid>@<hostname>")

    In-process jobs: If queue is 'me' the jobs are run within this process.
    Supply a 'get_log' argument if you want to access the job's log in the
    result.


    Remapping jobs:
        if queue == 'remap':
            * job = 'flush': Remove all remappings
            * job = (<oldq>, <newq>, <mapregex>): Send all jobs for oldq,
            which, when dumped, match the regex to newq
            This is handy for debugging certain jobs at a production cluster,
            with a worker started in foreground on a host, not affecting
            other jobs on the cluster - and not having to change the
            job pushing clients.

    Getting job results from other processes:
    if queue == get, we provide access to query an existing job_result

    job:
        push_job('get', <jobid>, expiry=2, wait=1)

        will deliver the result of job with jobid as given,
        setting a result expiry time of 2 seconds and blocks for 1 second max
        to get the result.

        Special case:
            if expiry == -1:
                the job (not the result) is being removed from the job queue


    redis: clients can deliver their own instance of a redis pusher object.

    Note: This call is allowed from restricted python! Take care that the
    workers run just with the priviledges needed but not more.




    """
    # typically clients want localhost but e.g. the workers push back for proxy
    # jobs:
    redispusher = REDIS_BY_IP.get(server)
    if not redispusher:
        with C_LOCK:
            # created while waiting?
            redispusher = REDIS_BY_IP.get(server)
            if not redispusher:
                redispusher = RedisPusher(hosts=server)
                REDIS_BY_IP[server] = redispusher


    if isinstance(queue, dict):
        # client threw the result of a previous job on us -> push to that
        # same process of the result again:
        worker = queue.get('worker')
        queue = 'proc:%s' % worker.split('[', 1)[0]


    if queue.startswith('me:'):
        # local job:
        if queue == 'me:get':
            # a process wants to see the result:
            return redispusher.get_job(job, expire_in=expiry, wait=wait)

        if queue == 'me:remap':
            if job == 'flush':
                Q_REMAPPINGS.clear()
                return 'All mappings cleared'
            from_q, to_q, match = job
            Q_REMAPPINGS[from_q] = (to_q, match)
            return 'Mapping all jobs for queue %s to %s if they match %s' \
                    % (from_q, to_q, match)
        if queue == 'me:stats':
            return redispusher.stats(job)


    if isinstance(job, (str, unicode)):
        try:
            job = convert_fmt(job, force='struct')
        except:
            raise SyntaxError('Error parsing %s' % job)

    if not isinstance(job, dict):
        raise ValueError('Job is no dict: %s' % job)

    # conserve the job settings as they where: the client might need them:
    job = job.copy()

    # can axpand work with that:
    if not 'cmd' in job and not 'flow' in job and not 'inline' in job:
        raise KeyError('No cmd(s) given in %s' % job)


    jobid = job.get('jobid')
    global JOB_COUNTER
    JOB_COUNTER += 1
    if JOB_COUNTER > 9999:
        JOB_COUNTER = 0

    cmds = job.get('cmd', job.get('flow'))
    if not jobid:
        jobid = '%s' % uuid4()
        #jobid = '..%s' % cmds[-20:] # not inter node safe reg. job IDs
        #jobid = '%s.%s:%s' % (getpid(), JOB_COUNTER, jobid)
    else:
        # we will use only the new one through all calls - and modify it
        # e.g. in ALL calls -> delete it to avoid confusion what it is:
        del job['jobid']

    job['pushts'] = time()
    if wait != None:
        if not queue == 'me':
            wait = int(wait)
            # 2 hours blocking client -> major fubar normally.
            # but there was a use case in swisscom:
            if wait < 1 or wait > 7200:
                # 7200 is to recover the server *somehow* when waiting for godot.
                # FIXME: should allow 7200 only in debug mode:
                raise ValueError("wait not > 0 and < 7200, is %s" % wait)

        # the worker needs to know us waiting:
        if not 'wait' in job:
            job['wait'] = wait

    #job['q_name'] = queue
    if queue == 'me':
        from ax.transport.jobs.queue_worker import SyncWorker
        w = SyncWorker('', 'me', None)
        res = w.run_inproc(jobid, job)
        return res

    try:
        job = pickle(job)
    except:
        raise SyntaxError('Error parsing %s' % job)


    return redispusher.push_job(queue, jobid, job, expiry, max_items, wait, lpush)


