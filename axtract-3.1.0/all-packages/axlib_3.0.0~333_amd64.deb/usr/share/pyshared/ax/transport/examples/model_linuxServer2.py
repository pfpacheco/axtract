#!/opt/axess/bin/call_with_eggs
"""
Example for Device Model 2 Usage.
"""
import logging, sys
logging.basicConfig(level=logging.DEBUG)

from ax.transport import axpand
from ax.utils.tr069 import TR69Utils
from pprint import pformat
# read in all xml definition files:
TR69Utils.parse_global_properties('/etc/axess/TR69')

# root object:
R = 'Device'
IP = '89.181.200.81'
via = 'telnet'
prolog = "/F:[R]Username:[S]%(user)s[R]Password:[S]%(password)s[R]>"
settings = {
        'via': via,
        'user': 'axiros',
        'password': 'menuth63ecr89eG5',
        'prolog': prolog,
        'condition': '>/Z',
        'host': IP,
        'allowed_cmds': None
       }

def pp(s):
    print pformat(s)



t = axpand.get_transport_object('oneaccess', settings=settings)
import pdb; pdb.set_trace() 
pp(t.get('show version'))
