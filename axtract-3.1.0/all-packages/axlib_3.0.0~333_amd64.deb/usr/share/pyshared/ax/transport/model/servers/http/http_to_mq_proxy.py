""" Get handler for http servers proxying to the job queue """
from ax.utils.formatting.pretty_print import dict_to_txt

from ax.transport.jobs.axp_jobs import push_job, JOB_WAIT_EXPIRED,\
        JOB_STATUS_FAILED
from urlparse import urlparse
from ax.transport.model.model_support import Model, add_model

###############################################################
#
# The web job listener:
#
###############################################################



class HTTP_TO_MQProxy(Model):
    """ proxying http onto the mq """

    def do_GET(self, t, url, headers={}, post_data=None, **kw):
        """ t is transport with parametrization, h is the req handler """
        use_ssl = 0
        # all local jobs must be called at: with /me/:
        http_proxy = t.http_proxy
        if '/me/' in url:
            return t.local_call(url, headers, post_data)

        if not getattr(t, 'http_proxy', 0):
            raise KeyError("http_proxy attribute not present in transport")

        # we are a HTTP proxy now - we push to the redis the proxy picks
        # from:
        PQ = 'PH'
        # proxy request to the other end:
        # clients can force ssl on or off:
        use_ssl = headers.get('use_ssl')
        # the other side needs a proxy which lets us call the (SSLed) Internet
        #FIXME: let this be a header or request param:
        wait = 60

        if not 'use_ssl' in headers:
            if str(urlparse(url).port).endswith('443'):
                use_ssl = 1
        else:
            del headers['use_ssl']

        if use_ssl:
            # we relay on the urllib on the other side to
            # follow all redirects until the final result is there:
            url = url.replace('http://', 'https://')

        res = push_job(PQ, {'cmd': '',
                            'kw': {'headers': headers, 'data': post_data},
                            'settings':{
                                'via'          : 'http',
                                'get_http_errs': 1,
                                'host'         : url}},
                            wait=wait, server=http_proxy)

        if res['status'] == JOB_WAIT_EXPIRED:
            res['status']  = 500
            res['details'] =  ('Proxy job was not picked on the server. '
                                'Is a proxy job handler started there?')
            res['data']    = dict_to_txt(res)

        elif res['status'] == JOB_STATUS_FAILED:
            res['status'] = 500
            res['data']   = dict_to_txt(res)

        else:
            res['data'] = res['res']

        return res

        # no action right now:
        return 'you called %s' % url



add_model('servers.http.HTTP_TO_MQProxy', HTTP_TO_MQProxy())
