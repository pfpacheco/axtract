""" The parent for all transports which send and receive CLI style """

from connected_transport import ConnectedSenderReceiver

class Telnetter(ConnectedSenderReceiver):
    """
    This is the base class for the Axiros Telnet client.
    """

    # Buffer for incoming data. Everything that is read is appended to it
    # via the "+=" operator. Modify it as you please.
    input_buf = ""

    # The type of newline that the other side prefers. You may want "\n",
    # "\r\n", "\r" or ever stranger stuff. The newline you configure here
    # will be appended when self.user and self.password are sent during
    # login(). It will also be appended to commands sent via run_command()
    # but not to stuff sent via send_data(). Setting this to the empty
    # string will disable the feature.
    newline = "\n"

    identification = "sock://%(host)s:%(port)s/"
    formatters = 'condition_strip'

    def send_data(self, data, conn_obj):
        """Sends the given data to the other side
            Subclasses must override this method.
        """
        raise NotImplementedError()

    def run_command(self, command, conn_obj):
        """Sends the given command string to the other side.
            This is identical to self.send_data(), except that
            self.newline is appended to $command for your
            convenience.
        """
        self.send_data(command + self.newline, conn_obj)


    def read(self, timeout, maxdata, conn_obj):
        """Read and return one chunk of data.
            How this is done depends on the specific transport.
            Subclasses must override this method.
        """
        raise NotImplementedError()
