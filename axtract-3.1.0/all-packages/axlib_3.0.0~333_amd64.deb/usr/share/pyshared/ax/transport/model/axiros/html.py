from ax.transport.model.model_support import Model
from ax.transport.model.model_support import add_model
from ax.utils.formatting.html import rewrite_links, neutralize_script_tags

class HTML(Model):
    """ Good for HTML scrapers """
    #TODO beautiful soup stuff...

    root = "D"
    rev  = 1.0

add_model(('axiros.html', HTML()),)

