#!/opt/axess/bin/call_with_eggs
import unittest2
from time import sleep, time
from ax.transport import axpand
from ax.transport.base import TimeoutException, TransportException
from ax.transport.via.redis_pubsub import EVS_BY_CHANNEL
from ax.transport.via.redis_pubsub import set_max_listener_threads
from ax.transport.via.redis_pubsub import get_max_listener_threads
import ax.transport.via.redis_pubsub

# try - if not no func tests:
import redis

import logging
logging.basicConfig(level=logging.DEBUG)

class RedisUsingLayer:
    pass


class PubSubFuncTests(unittest2.TestCase):
    """"
        Autonmous tests of this via -
        requiring a running redis server at default port
    """
    layer = RedisUsingLayer


    def setUp(self):
        # device ident:
        self.di = str(time())
        EVS_BY_CHANNEL.clear()
        set_max_listener_threads(5)
        self.test_chan = 'pubsub_test_chan_%s' % self.di
        self.settings ={
                 'listen_channel' : self.test_chan,
                 'publish_channel': self.test_chan,
                 'redis_host': '127.0.0.1',
                 'device_identifier': self.di,
                 'listen_timeout': '0.2',
                 'listen_match_crit': 'device_identifier, comp_key',
                 'publish_json': '{"comp_key": "%s"}' % self.di
                 }

    def tearDown(self):
        EVS_BY_CHANNEL.clear()

    def get_t(self):
        t = str(time())
        return axpand.get_transport_object(t, 'redis_pubsub', self.settings)


    def test_match(self):
        t = self.get_t()
        # we publish and check evs, which will be filled by the listener:
        res = t.get(self.test_chan)
        assert res == {'comp_key': self.di}


    def test_no_match(self):
        # now we don't match the event:
        self.settings['listen_match_crit'] = 'no_exists, somekey'
        t = self.get_t()
        t1 = time()
        # so we get a timeout:
        self.assertRaises(TimeoutException, t.get, self.test_chan)
        assert time() - t1 > 0.2


    def test_expiry(self):
        self.settings['listen_match_crit'] = 'no_exists, somekey'
        self.settings['events_list_check_len'] = 0
        t = self.get_t()
        # blocks for min. 0.2:
        self.assertRaises(TimeoutException, t.get, self.test_chan)
        evs = EVS_BY_CHANNEL[self.test_chan]
        assert len(evs) == 1
        ev = evs[0]
        # blocks for min. 0.2:
        self.assertRaises(TimeoutException, t.get, self.test_chan)
        ev1 = evs[0]
        # first one is removed during the get with timeeout:
        assert ev1 != ev
        assert len(evs) == 1


    def test_listener_thread(self):
        r = redis.Redis('127.0.0.1', 6379)
        self.assertEquals(r.publish(self.test_chan, '{"fu": "bar1"}'), 0)
        self.assertEquals(r.publish(self.test_chan, '{"fu": "bar2"}'), 0)
        self.assertEquals(r.publish(self.test_chan, '{"fu": "bar3"}'), 0)
        self.assertEquals(r.publish(self.test_chan, '{"fu": "bar4"}'), 0)
        # only def connect creates the listener:
        self.assertNotIn(self.test_chan, EVS_BY_CHANNEL)
        self.settings['events_list_check_len'] = 0
        # this creates the thread:
        t = self.get_t()
        res = t.get(self.test_chan)
        self.assertIn('comp_key', res)
        # let time to clear:
        sleep(0.1)
        self.assertListEqual(EVS_BY_CHANNEL[self.test_chan], [])


    def test_listeners_overload(self):
        for i in range(1, get_max_listener_threads() + 10):
            # see test after the loop, this is just a security belt
            # to not create too many threads:
            assert i < 7
            chan = 'overload_test_%s' % i
            self.settings['listen_channel'] = chan
            #self.settings['publish_channel'] = chan
            try:
                t = self.get_t()
            except TransportException, ex:
                break
        # max was set to 5 in setUp, so exception comes with 6th:
        self.assertEqual(i, 6)


if __name__ == "__main__":
    unittest2.main(verbosity=2)
