from ax.transport.flow_handling import KNOWN_TAGS
from ax.transport.transport_access import  VIA_CLASS_SEARCH_FOLDERS
from ax.utils.formatting.pretty_print import dict_to_txt
from ax.transport.inventory import bases
from pprint import PrettyPrinter
import os
pp = PrettyPrinter().pprint


def get_microflow_lib(print_out = 0):
    from ax.transport.microflows import MF_LIB
    if print_out:
        return pp(MF_LIB)
    return  dict_to_txt(MF_LIB, fmt = {'block_sep_0': 1, 'em_0': 1})


def list_exceptions(print_out = 0):
    """ scan through the directory, finding exceptions """
    import ax.transport
    rpath = ax.transport.__path__[0]
    e_list = os.popen('grep -i "^class" *|grep Exception').read()
    ret = {}
    for ex in e_list.split('\n'):
        if not ':' in ex:continue
        module, exc = ex.split(':',1)
        exec ("from ax.transport.%s import %s as this_ex" % (module.split('.py')[0], exc.split(' ', 1)[1].split('(')[0]))
        mod, doc, err_id, base = this_ex.__module__, this_ex.__doc__, this_ex.err_id, this_ex.__class__.__base__
        ret[ex[:-1]] = { 'module': mod, 'doc': doc, 'err_id': err_id}
    if print_out:
        return pp(ret)
    return dict_to_txt(ret, fmt = {'block_sep_0': 1, 'em_0': 1})


def get_help(chapter = None, print_out = 0):
    res = {'base methods': ('axpand.get_transport_object', '<transport_object>.get'),
            'base_vias': bases,
            'extensions': VIA_CLASS_SEARCH_FOLDERS,
            'TAGS': KNOWN_TAGS
            }
    if print_out:
        return pp(res)
    return dict_to_txt(res, fmt = {'block_sep_0': 1, 'em_0': 1})






def examples():
    ret = {}
    ret['telnet_IOS']      = {
            'via'            : 'telnet',
            'prolog'         : '/F:LIB:cisco_telnet_user_pw',
            'user'           : 'test',
            'password'       : 'test',
            'enable_pass'    : 'cisco',
            'host'           : '1.2.3.4',
            'port'           : 23,
            'allowed_cmds'   : '',
            'condition'      : '#/Z',
            'model'         : 'cisco.IOS_IGD'
            }

    ret['ssh_IOS']         = {
            'via'            : 'ssh',
            'prolog'         : '/F:LIB:cisco_ssh',
            'user'           : 'test',
            'password'       : 'test',
            'enable_pass'    : 'cisco',
            'host'           : '1.2.3.4',
            'port'           : 22,
            'allowed_cmds'   : '',
            'condition'      : '#/Z',
            'newline'        : '\\n',
            'invoke_shell'   : 1,
            'model'         : 'cisco.IOS_IGD'
            }
    #FIXME: Add more...
    return ret

























if __name__ == '__main__':
    print get_help()
