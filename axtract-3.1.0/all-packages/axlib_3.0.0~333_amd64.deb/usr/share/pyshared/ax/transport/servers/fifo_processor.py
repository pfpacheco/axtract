"""Implementation """

from ax.transport.connected_transport import ConnectedReceiver
import os
import logging
from threading import Thread
from time import time, ctime

logger = logging.getLogger( __name__)

KILLPILL = 'AXSTOP'
class FifoProcessor(ConnectedReceiver, Thread):
    """
    Creating a fifo and processing via arbitrary handler
    """
    procs = []
    sin   = None
    fifo = '/tmp/axfifo'
    identification =  "Fifo://%(fifo)s"


    def open_connection(self):
        self.destroy()
        os.mkfifo(self.fifo)
        fd = os.open(self.fifo, os.O_RDWR)
        self.sin = os.fdopen(fd, 'r')
        return self.sin

    def close(self, conn_obj=None):
        self.stop_loop()
        if self.sin and not self.sin.closed:
            try:
                self.sin.close()
            except Exception, ex:
                pass
        self.destroy()

    def destroy(self):
        if os.path.exists(self.fifo):
            os.unlink(self.fifo)


    def stop_loop(self):
        """ dead pill """
        if self.is_alive():
            with open(self.fifo, 'w') as f:
                f.write(KILLPILL + '\n')

    def main_loop(self):
        while not self.shutdown_requested:
            line = self.sin.readline()
            if line.strip() == KILLPILL:
                logging.warn('Got main loop exit signal')
                break
            print 'procssing', line


    def communicate(self, cmd, conn_obj, condition, error_condition,\
            timeout, data, **kwargs):
        print self, self.__hash__()
        print '?' * 100
        print 'got' , cmd, data
        return self





