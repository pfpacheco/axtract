import datetime
import struct
import binascii
import gevent
from gevent.queue import Queue
import time
import signal
import simplejson
from ax.utils.lru import ExpiringLRUCache
from ax.utils.tools import chunk_iterable
from ax.transport.servers.sml.sml_crc16 import CRC16
from ax.transport.servers.sml.sml_constants import ASCII_PARAMS, \
IP_PARAMS, DATE_PARAMS, TIMESTAMP_PARAMS, SMALL_INT_PARAMS, BIG_INT_PARAMS, \
PROFILE_GENERIC, ATTENTION_OK, OBIS_PARAMS, BOOL_PARAMS, TWOS_COMPLEMENT, \
MEDIUM_INT_PARAMS, ALL_INT_PARAMS

class SMLObject(object):
    """All SML messages classes inherit from here"""
    def __init__(self, payload):
        super(SMLObject, self).__init__()
        self.payload = payload
        self.cursor = 0

    def _decode_value(self, obis, value):
        """checks if the type of an obis code
        and decodes the data accordingly"""
        if value is None:
            return None
        if obis in ASCII_PARAMS:
            value = value.decode('hex')
        elif obis in IP_PARAMS:
            value = self._decode_ip(value)
        elif obis in DATE_PARAMS:
            value = self._decode_date(value)
        elif obis in TIMESTAMP_PARAMS:
            value = self._decode_ts(value)
        elif obis in ALL_INT_PARAMS:
            value = self._decode_int(value)
        elif obis in TWOS_COMPLEMENT:
            value = self._get_int(value)
        elif obis in BOOL_PARAMS:
            value = self._decode_bool(value)
        else:
            pass
        try:
            simplejson.dumps(value)
        except UnicodeDecodeError:
            value = 'DECODE_ERROR'
        return value

    @classmethod
    def _decode_bool(cls, value):
        if value in ('00', '0', 0, False, 'False', 'false'):
            return False
        else:
            return True

    def _get_int(self, hexval):
        #formatter = "b" * (len(hex_int) / 2)
        #hex_int = binascii.unhexlify(hex_int)
        #return struct.unpack(formatter , hex_int)[0]
        #return struct.unpack("!q", struct.pack("!Q", int(hex_int, 16)))[0]
        val = int(hexval, 16)
        thelen = len(hexval)*4
        binval = bin(val)[2:]
        while ((len(binval)) < thelen):
            binval = '0' + binval
        bits = len(binval)
        if( (val&(1<<(bits-1))) != 0 ):
            val = val - (1<<bits)
        return val

    def _decode_sml_time(self, sml_time_tuple):
        """given a tuple like '655069B374', '53003C', '53003C')
        returns an epoch time integer in localtime"""
        #ts = int(self.get_value_from_byte(sml_time_tuple[0]), 16)
        ts = self._get_int(self.get_value_from_byte(sml_time_tuple[0]))
        local_offset = self._get_int(self.get_value_from_byte(sml_time_tuple[1]))
        season_offset = self._get_int(self.get_value_from_byte(sml_time_tuple[2]))
        local_ts = ts + local_offset * 60 + season_offset * 60
        return ts
        new_value = datetime.datetime.utcfromtimestamp(local_ts)
        return new_value.strftime("%d/%m/%Y %H:%M:%S")

    @classmethod
    def _decode_ts(cls, hex_ts):
        new_value = datetime.datetime.fromtimestamp(int(hex_ts, 16))
        return new_value.strftime("%d/%m/%Y %H:%M:%S")

    @classmethod
    def _decode_date(cls, hex_date):
        if len(hex_date)!=12:
            return None
        def get_value(value):
            value = str(int(value, 16))
            if len(value) < 2:
                value = '0' + value
            return value
        years = get_value(hex_date[0:2])
        months = get_value(hex_date[2:4])
        days = get_value(hex_date[4:6])
        hours = get_value(hex_date[6:8])
        minutes = get_value(hex_date[8:10])
        seconds = get_value(hex_date[10:12])
        return "%s/%s/%s %s:%s:%s" % (days, months, years,
                hours, minutes, seconds)

    @classmethod
    def _decode_int(cls, hex_int):
        return int(hex_int, 16)

    @classmethod
    def _decode_ip(cls, hex_ip):
        """gets an 8 char long hex string and returns it as
        an IP address"""
        if len(hex_ip)!=8:
            return hex_ip
        try:
            split_hex_ip = (hex_ip[0:2],
                hex_ip[2:4],
                hex_ip[4:6],
                hex_ip[6:8])
            ip_addr = '.'.join(str(int(x, 16)) for x in split_hex_ip)
        except Exception, e:
            msg = "Invalid IP hex string was given to be decoded"
            raise Exception(msg)
        return ip_addr

    @classmethod
    def _get_unit(cls, code):
        """
        accepts a byte that represents the unit
        and return the human readable unit
        """
        if code is None:
            return 'No Unit'
        alias = int(code, 16)
        if alias == 7:
            return 'sec'
        elif alias == 27:
            return 'W'
        elif alias == 35:
            return 'V'
        elif alias == 30:
            return 'Wh'
        elif alias == 44:
            return 'Hz'
        else:
            return 'Undefined Unit: %d' % alias

    def _calculate_value(self, obis, scaler, value):
        """
        applies the scaler on the value and
        returns the value.
        """
        new_value = None
        new_scaler = None
        if scaler != '00' and not scaler is None:
            new_scaler = struct.unpack("b", binascii.unhexlify(scaler))[0]
            #new_value = int(value, 16) * (10 ** scaler)
        #if new_value is None:
        new_value = self._decode_value(obis, value)
        if new_scaler:
            new_value = new_value * (10 ** new_scaler)
        return new_value

    def parse_sml(self):
        """
        parses the self.payload of the SMLObject
        and returns a list of sml messages
        """
        sml_messages = []
        while self.cursor != len(self.payload):
            value = self.get_next_bytes(1, self.cursor, self.payload)
            if value.startswith('7'):
                size_of_list = int(value[-1], 16)
                self.cursor += 2
                result = self._parse_sml_list(size_of_list,
                        self.payload[self.cursor:])
                self.cursor += result[0]
                list_of_values = result[1]
                sml_msg_type = list_of_values[3][0]
                sml_msg_type = self.get_value_from_type(sml_msg_type)
                sml_msg_type = self._get_type_of_sml(sml_msg_type)
                if sml_msg_type == 'SML_PublicOpen.Res':
                    sml_messages.append(SMLPublicOpenRes(list_of_values))
                elif sml_msg_type == 'SML_GetList.Res':
                    sml_messages.append(SMLGetListRes(list_of_values))
                elif sml_msg_type == 'SML_PublicClose.Res':
                    sml_messages.append(SMLPublicCloseRes(list_of_values))
                elif sml_msg_type == 'SML_GetProcParameter.Res':
                    sml_messages.append(SMLGetProcParamererRes(list_of_values))
                elif sml_msg_type == 'SML_Attention.Res':
                    sml_messages.append(SMLAttentionRes(list_of_values))
                elif sml_msg_type == 'SML_GetProfilePack.Res':
                    sml_messages.append(SMLGetProfilePackRes(list_of_values))
            else:
                #TODO add code for recognizing the end of sml data
                break
        return sml_messages

    def _get_procparvalue(self, num):
        """
        returns the SML_ProcParValue given
        the data including its length
        """
        num = self.get_value_from_byte(num)
        if num == '01':
            return 'SML_Value'
        elif num == '02':
            return 'SML_PeriodEntry'
        elif num == '03':
            return 'SML_TupelEntry'
        elif num == '04':
            return 'SML_Time'
        elif num == '05':
            return 'SML_ListEntry'

    @classmethod
    def _get_type_of_sml(cls, num):
        """
        returns the SML type of message as a string
        """
        if num == '0101':
            return 'SML_PublicOpen.Res'
        elif num == '0701':
            return 'SML_GetList.Res'
        elif num == '0201':
            return 'SML_PublicClose.Res'
        elif num == '0501':
            return 'SML_GetProcParameter.Res'
        elif num == 'FF01':
            return 'SML_Attention.Res'
        elif num == '0301':
            return 'SML_GetProfilePack.Res'
        else:
            raise Exception('Unknown SML message type: %s' % num)

    def get_next_bytes(self, num, cursor=None, payload=None):
        """
        returns the next 'num' bytes from the cursor
        posigion on the payload given
        """
        if cursor == None:
            cursor = self.cursor
        if payload == None:
            payload = self.payload
        return payload[cursor:cursor + 2 * num]

    @classmethod
    def _get_long_length(cls, length_in_bytes):
        """
        return an integer from a string like 8320
        representing a field's length
        """
        numbers = []
        nr_of_bytes = 0
        tmp_cursor = 0
        while length_in_bytes[tmp_cursor] == '8':
            numbers.append(int(length_in_bytes[tmp_cursor + 1], 16))
            tmp_cursor += 2
        numbers.append(int(length_in_bytes[tmp_cursor:tmp_cursor + 2], 16))
        shifter = 0
        numbers.reverse()
        for num in numbers:
            nr_of_bytes += num << shifter
            shifter += 4
        return nr_of_bytes

    def get_value_from_long_bytes(self, length_in_bytes, payload):
        """
        returns the bytes of a data value starting with 8
        """
        nr_of_bytes = self._get_long_length(length_in_bytes)
        return payload[len(length_in_bytes):nr_of_bytes * 2]

    def get_value_from_byte(self, payload):
        """
        returns the value based on the initial byte
        """
        if payload == None:
            payload = self.payload
        if payload[0:2] == '01':
            return None
        byte = self.get_next_bytes(1, 0, payload)
        if byte in ('42', '52', '53', '54', '55', '59',
                '62', '63', '64', '65', '69'):
            return self.get_value_from_type(payload)
        elif byte.startswith('8'):
            tmp_cursor = 0
            byte = ''
            while payload[tmp_cursor] == '8':
                byte += payload[tmp_cursor:tmp_cursor + 2]
                tmp_cursor += 2
            byte += payload[tmp_cursor:tmp_cursor + 2]
            return self.get_value_from_long_bytes(byte, payload)
        else:
            return self.get_value_from_length(payload)

    def get_value_from_length(self, payload=None):
        """
        returns the value interpreting the first byte
        as the length of the value
        """
        if payload == None:
            payload = self.payload
        if payload[0:2] == '01':
            return None
        length = int(self.get_next_bytes(1, 0, payload), 16) - 1
        value = self.get_next_bytes(length, 2, payload)
        return value

    def get_value_from_type(self, payload=None):
        """
        returns the value interpreting the first byte
        as the type of the value
        """
        if payload == None:
            payload = self.payload
        if payload[0:2] == '01':
            return None
        next_bytes = self.get_next_bytes(1, 0, payload)
        num_of_bytes = self._num_of_bytes_based_on_type(next_bytes)
        value = self.get_next_bytes(num_of_bytes, 2, payload)
        return value

    @classmethod
    def _num_of_bytes_based_on_type(cls, bytes_type):
        """
        returns how many bytes the different
        SML data structures are
        """
        if bytes_type == '62' or bytes_type == '52' or bytes_type == '42':
            return 1
        elif bytes_type == '63' or bytes_type == '53':
            return 2
        elif bytes_type == '64' or bytes_type == '54':
            return 3
        elif bytes_type == '65' or bytes_type == '55':
            return 4
        elif bytes_type == '69' or bytes_type == '59':
            return 8

    def _parse_sml_list(self, num, payload):
        """
        parses the payload and returns nested lists
        of bytes based on the SML message structure
        """
        cursor = 0
        list_of_values = []
        for _ in xrange(num):
            identifier = self.get_next_bytes(1, cursor, payload)
            if identifier is None:
                list_of_values.append(None)
                cursor += 2
            elif identifier == '62' or identifier == '52' \
                    or identifier == '42':
                list_of_values.append(payload[cursor:cursor + 4])
                cursor += 4
            elif identifier == '63' or identifier == '53':
                list_of_values.append(payload[cursor:cursor + 6])
                cursor += 6
            elif identifier == '64' or identifier == '54':
                list_of_values.append(payload[cursor:cursor + 8])
                cursor += 8
            elif identifier == '65' or identifier == '55':
                list_of_values.append(payload[cursor:cursor + 10])
                cursor += 10
            elif identifier == '69' or identifier == '59':
                list_of_values.append(payload[cursor:cursor + 18])
                cursor += 18
            elif identifier.startswith('7'):
                size_of_list = int(identifier[-1], 16)
                result = self._parse_sml_list(size_of_list,
                        payload[cursor + 2:])
                cursor += result[0] + 2
                list_of_values.append(result[1])
            elif identifier == '00':
                cursor += 2
                list_of_values.append('00')
            elif identifier.startswith('8'):
                tmp_cursor = cursor
                identifier = ''
                while payload[tmp_cursor] == '8':
                    identifier += payload[tmp_cursor:tmp_cursor + 2]
                    tmp_cursor += 2
                identifier += payload[tmp_cursor:tmp_cursor + 2]
                nr_of_bytes = self._get_long_length(identifier) * 2
                list_of_values.append(payload[cursor:cursor + nr_of_bytes])
                cursor += nr_of_bytes
            else:
                list_of_values.append(self.get_next_bytes(int(identifier, 16),
                    cursor, payload))
                cursor += int(identifier, 16) * 2
        return (cursor, list_of_values)


class SMLMessage(SMLObject):
    """generic SML Message. SML Messages inherit from here"""
    def __init__(self, list_of_values):
        super(SMLMessage, self).__init__(list_of_values)
        self.transaction_id = self.get_value_from_byte(list_of_values[0])
        self.group_no = self.get_value_from_byte(list_of_values[1])
        self.abort_on_error = self.get_value_from_byte(list_of_values[2])
        self.msg_body_list = list_of_values[3:]

    def get_transaction_id(self):
        return self.transaction_id


class SMLPublicOpenRes(SMLMessage):
    """SMLPublicOpenRes message implementation"""
    def __init__(self, list_of_values):
        super(SMLPublicOpenRes, self).__init__(list_of_values)
        self.codepage = self.get_value_from_byte(self.msg_body_list[0][1][0])
        self.client_id = self.get_value_from_byte(self.msg_body_list[0][1][0])
        self.req_field = self.get_value_from_byte(self.msg_body_list[0][1][2])
        self.server_id = self.get_value_from_byte(self.msg_body_list[0][1][3])
        self.ref_time = self.msg_body_list[0][1][4]
        self.checksum = self.get_value_from_byte(self.msg_body_list[1])

    def get_timezone(self):
        """returns timezone information if any"""
        choice = self.get_value_from_byte(self.ref_time[0])
        if choice == '03':
            local_offset = self.ref_time[1][1]
            season_offset = self.ref_time[1][2]
            return (local_offset, season_offset)
        else:
            return None

class SMLPublicCloseRes(SMLMessage):
    """SMLPublicCloseRes message implementation"""
    def __init__(self, list_of_values):
        super(SMLPublicCloseRes, self).__init__(list_of_values)
        self.checksum = self.get_value_from_byte(self.msg_body_list[1])


class SMLGetProcParamererRes(SMLMessage):
    """SMLGetProcParamererRes message implementation"""
    def __init__(self, list_of_values):
        super(SMLGetProcParamererRes, self).__init__(list_of_values)
        if self.msg_body_list[0][1][1] == ['070101010101FF']:
            results = self.msg_body_list[0][1][2][2]
        else:
            results = [self.msg_body_list[0][1][2]]
        self.parameters = {}

        for item in results:
            if isinstance(item[1], list):
                res = item[1][1]
                param_type = self._get_procparvalue(item[1][0])
                if param_type == 'SML_ListEntry':
                    obis = self.get_value_from_byte(res[0])
                    #unit = self._get_unit(self.get_value_from_byte(res[3]))
                    scaler = self.get_value_from_byte(res[4])
                    value = self.get_value_from_byte(res[5])
                    value = self._calculate_value(obis, scaler, value)
                elif param_type == 'SML_Value':
                    obis = self.get_value_from_byte(item[0])
                    #unit = 'No Unit'
                    value = self.get_value_from_byte(res)
                    value = self._decode_value(obis, value)
                elif param_type == 'SML_PeriodEntry':
                    obis = self.get_value_from_byte(res[0])
                    scaler = self.get_value_from_byte(res[2])
                    value = self.get_value_from_byte(res[3])
                    value = self._calculate_value(obis, scaler, value)
                elif param_type == 'SML_Time':
                    obis = self.get_value_from_byte(item[0])
                    value = self._decode_sml_time(res[1])
                else:
                    msg = 'Parameter type %s not implemented yet' % param_type
                    raise Exception(msg)
                # If we need the unit also uncomment the following
                #self.parameters[obis] = {
                        #'unit': unit,
                        #'value': value}
                self.parameters[obis] = value
            else:
                self.obis = self.get_value_from_byte(item[0])
                subparams = {}
                if isinstance(item[2], list):
                    for subitem in item[2]:
                        subparam_obis = self.get_value_from_byte(subitem[0])
                        if isinstance(subitem[1], list):
                            subparam_type = self._get_procparvalue(subitem[1][0])
                        else:
                            subparam_type = '01'
                        if subparam_type == 'SML_ListEntry':
                            list_entry = subitem[1][1]
                            #subparam_unit = \
                                    #self._get_unit(self.get_value_from_byte
                                #list_entry[3]))
                            subparam_scaler = self.get_value_from_byte(list_entry[4])
                            subparam_value = self.get_value_from_byte(list_entry[5])
                            subparam_value = self._calculate_value(subparam_obis,
                                    subparam_scaler, subparam_value)
                        elif subparam_type == 'SML_Value':
                            #subparam_unit = 'No Unit'
                            subparam_value = self.get_value_from_byte(
                                    subitem[1][1])
                            subparam_value = self._decode_value(subparam_obis,
                                    subparam_value)
                        elif subparam_type == '01':
                            #subparam_unit = 'No Unit'
                            subparam_value = None
                        else:
                            msg = 'Parameter type %s not implemented yet'\
                                    % subparam_type
                            raise Exception(msg)
                        # If we need the unit also uncomment the following
                        """
                        subparams[subparam_obis] = {'unit': subparam_unit,
                                    'value': subparam_value}
                        """
                        subparams[subparam_obis] = subparam_value
                else:
                    subparams = self.get_value_from_byte(item[2])
                self.parameters[self.obis] = subparams

    def get_result(self):
        """returns the result of an SMLGetProcParamererRes"""
        return self.parameters


class SMLAttentionRes(SMLMessage):
    """SMLAttentionRes message implementation"""
    def __init__(self, list_of_values):
        super(SMLAttentionRes, self).__init__(list_of_values)
        self.server_id = self.get_value_from_byte(self.msg_body_list[0][1][0])
        self.attention_no = self.get_value_from_byte(self.msg_body_list[0][1][1])
        self.attention_msg = self.get_value_from_byte(
                self.msg_body_list[0][1][2])
        self.attention_details = self.get_value_from_byte(
                self.msg_body_list[0][1][3])

    def get_result(self):
        """returns the result of an SMLAttentionRes"""
        result = None
        if self.attention_no == ATTENTION_OK:
            result = 'OK'
        else:
            result = 'Failure: ' + self.attention_no
        return {'result': result,
                'message': self.attention_msg\
                        if not self.attention_msg is None else '',
                'details': self.attention_details\
                        if not self.attention_details is None else ''}


class SMLGetProfilePackRes(SMLMessage):
    """SMLGetProfilePackRes message implementation"""
    def __init__(self, list_of_values):
        super(SMLGetProfilePackRes, self).__init__(list_of_values)
        self.obis_list = list_of_values[3][1][4]
        self.values_list = list_of_values[3][1][5]

    def get_result(self):
        """returns the result of an SMLGetProfilePackRes"""
        result = []
        obis_list = []
        # populate a list with items like (obis, unit, scaler)
        for obis_entry in self.obis_list:
            obis = self.get_value_from_byte(obis_entry[0])
            unit = self.get_value_from_byte(obis_entry[1])
            scaler = self.get_value_from_byte(obis_entry[2])
            obis_list.append((obis, unit, scaler))
        for i in xrange(len(self.values_list)):
            value_entry = self.values_list[i]
            ts = self._decode_sml_time(value_entry[0][1])
            values = []
            for j in xrange(len(value_entry[2])):
                val = self.get_value_from_byte(value_entry[2][j][0])
                obis = obis_list[j][0]
                unit = self._get_unit(obis_list[j][1])
                scaler = obis_list[j][2]
                values.append((obis, unit,
                    self._calculate_value(obis, scaler, val)))
            result.append((ts, values))
        return result

class SMLGetListRes(SMLMessage):
    """SMLGetListRes message implementation"""
    def __init__(self, list_of_values):
        super(SMLGetListRes, self).__init__(list_of_values)
        self.client_id = self.get_value_from_byte(self.msg_body_list[0][1][0])
        self.server_id = self.get_value_from_byte(self.msg_body_list[0][1][1])
        self.list_name = self.get_value_from_byte(self.msg_body_list[0][1][2])
        self.acs_sensor_time = self.msg_body_list[0][1][3]
        self.sml_list = self.parse_sml_list_items(self.msg_body_list[0][1][4])

    @classmethod
    def parse_sml_list_items(cls, sml_items):
        """makes a list of the sml_items"""
        temp_list = []
        for item in sml_items:
            temp_list.append(SMLListEntry(item))
        return temp_list

    def get_result(self):
        """returns the result of an SMLGetListRes"""
        values = {}
        for sml_list_entry in self.sml_list:
            values[sml_list_entry.obis] = {}
            values[sml_list_entry.obis]['value'] = sml_list_entry.value
            values[sml_list_entry.obis]['unit'] = sml_list_entry.unit
        return values


class SMLListEntry(SMLObject):
    """SMLListEntry message implementation"""
    def __init__(self, list_of_values):
        super(SMLListEntry, self).__init__(list_of_values)
        self.obis = self.get_value_from_byte(list_of_values[0])
        self.status = self.get_value_from_byte(list_of_values[1])
        self.val_time = self.get_value_from_byte(list_of_values[2])
        self.unit = self._get_unit(self.get_value_from_byte(
            list_of_values[3]))
        self.scaler = self.get_value_from_byte(list_of_values[4])
        value = list_of_values[5]
        if (isinstance(value, list)):
            indicator = self.get_value_from_byte(list_of_values[5][0])
            if indicator == '01' or indicator == '02':
                self.value = self.get_value_from_byte(list_of_values[5][0][0])
            elif indicator == '03':
                self.value = self._decode_sml_time(list_of_values[5][1])
        else:
            self.value = self.get_value_from_byte(list_of_values[5])
            self.value_signature = self.get_value_from_byte(list_of_values[6])
            self.value = self._calculate_value(self.obis, self.scaler, self.value)


class SMLParser(object):
    """object that defines the parser behavior"""
    def __init__(self, logger):
        self.logger = logger
        self.transaction_id = 0

    def parse_sml(self, payload):
        """parses the sml payload and returns a list of SMLObjects"""
        sml_obj = SMLObject(payload)
        sml_messages_list = sml_obj.parse_sml()
        self.transaction_id = int(sml_messages_list[-1].transaction_id, 16)
        return sml_messages_list


class SMLComposer(object):
    """object that defines the sml message composer behavior"""
    def __init__(self, cpeid, logger):
        super(SMLComposer, self).__init__()
        self.transaction_id = 0
        self.crc16 = CRC16()
        self.logger = logger
        self.cpeid = cpeid
        self._timezone = None

    def set_timezone(self, timezone):
        """sets the timezone"""
        self._timezone = timezone

    @classmethod
    def _encode_bool(cls, value):
        if value:
            return '01'
        else:
            return '00'

    def _encode_value_with_prefix(self, obis, value):
        """checks if the type of an obis code
        and encodes the data accordingly"""
        if obis in ASCII_PARAMS:
            return self._return_value_with_length(value.encode('hex'))
        elif obis in IP_PARAMS:
            return self._return_value_with_length(self._encode_ip(obis, value))
        elif obis in SMALL_INT_PARAMS:
            value = '00' + self._encode_int(obis, value)
            return '62' + value[-2:]
        elif obis in MEDIUM_INT_PARAMS:
            value = '0000' + self._encode_int(obis, value)
            return '63' + value[-4:]
        elif obis in BIG_INT_PARAMS:
            value = '00000000' + self._encode_int(obis, value)
            return '65' + value[-8:]
        elif obis in OBIS_PARAMS:
            return self._return_value_with_length(value)
        elif obis in BOOL_PARAMS:
            return '42' + self._encode_bool(value)
        else:
            msg = 'Don\'t know how to encode value for OBIS \'%s\'' % obis
            self.logger.debug(msg)
            return self._return_value_with_length(value.encode('hex'))

    def _encode_int(self, obis, integer):
        """encode an integer to hex"""
        try:
            hex_int = hex(integer)[2:]
        except TypeError:
            msg = 'Invalid integer value given for OBIS \'%s\'' % obis
            self.logger.debug(msg)
            return '00'
        return hex_int

    def _encode_ip(self, obis, ip_addr):
        """encode an ip to hex"""
        numbers = ip_addr.split('.')
        invalid = False
        hex_ip = ''
        if len(numbers) != 4:
            invalid = True
        else:
            try:
                for num in numbers:
                    temp = '00' + hex(int(num))[2:]
                    hex_ip += temp[-2:]
            except ValueError:
                invalid = True
        if invalid:
            msg = 'Invalid value for IP address given for OBIS \'%s\'' % obis
            self.logger.debug(msg)
            return '00'
        else:
            return hex_ip

    @classmethod
    def _get_bytes_for_sml_type(cls, sml_type):
        """returns the bytes that correspond
        to a specific sml message type"""
        if sml_type == 'SML_PublicOpen.Req':
            return '630100'
        elif sml_type == 'SML_GetProcParameter.Req':
            return '630500'
        elif sml_type == 'SML_PublicClose.Req':
            return '630200'
        elif sml_type == 'SML_SetProcParameter.Req':
            return '630600'
        elif sml_type == 'SML_GetProfilePack.Req':
            return '630300'
        else:
            raise Exception('Unsupported SML message: %s' % sml_type)

    @classmethod
    def _return_value_with_length(cls, value):
        """given a value it appends the length of it
        in the beginning and returns it. Length is in bytes"""
        if isinstance(value, int):
            value = hex(value)[2:]
        if len(value) % 2 == 1:
            value = '0' + value
        value_length = hex(len(value) / 2 + 1)[2:]
        if len(value_length) % 2 == 1:
            value_length = '0' + value_length
        return (value_length + value)

    def _generate_req_field(self):
        """calculates the reqfield"""
        #TODO calculate req field
        return '00990306060343'

    def _crc16(self, string, with_prefix=False):
        """returns the crc16 checksum of the string given.
        if with_prefix is used returns the length also"""
        checksum = self.crc16.calcString(string)
        if len(checksum) % 2 == 1:
            checksum = '0' + checksum
        if with_prefix:
            checksum = '63' + checksum
        return checksum

    def _get_username_password(self):
        """returns a tuple with username and password in bytes"""
        #TODO username and password
        #service/service
        username = 'master'
        password = 'master'
        username = username.encode('hex')
        password = password.encode('hex')
        return (username, password)

    def sml_public_open_req(self, code_page=None, client_id=None,
            req_field=None, server_id=None, username=None, password=None,
            sml_version=None):
        """composes a SMLPublicOpenReq"""
        if not username:
            username, password = self._get_username_password()
        request = '76'
        request += self._return_value_with_length(self.transaction_id)
        self.transaction_id += 1
        request += '6200620072'
        request += self._get_bytes_for_sml_type('SML_PublicOpen.Req')
        request += '77'
        if code_page:
            request += self._return_value_with_length(code_page)
        else:
            request += '01'
        if client_id:
            request += self._return_value_with_length(client_id)
        else:
            request += '01'
        if req_field:
            request += self._return_value_with_length(req_field)
        else:
            request += self._return_value_with_length(self._generate_req_field())
        if server_id:
            request += self._return_value_with_length(server_id)
        else:
            request += '01'
        if username:
            request += self._return_value_with_length(username)
        else:
            request += '01'
        if password:
            request += self._return_value_with_length(password)
        else:
            request += '01'
        if sml_version:
            request += self._return_value_with_length(sml_version)
        else:
            request += '01'
        request += self._crc16(request, True)
        request += '00'
        return request

    def sml_get_proc_parameter_req(self, obis_codes, server_id=None,
            username=None, password=None, attribute=None):
        """composes an SMLGetProcParamererReq"""
        if not username:
            username, password = self._get_username_password()
        request = '76'
        request += self._return_value_with_length(self.transaction_id)
        self.transaction_id += 1
        request += '6200620072'
        request += self._get_bytes_for_sml_type('SML_GetProcParameter.Req')
        request += '75'
        if server_id:
            request += self._return_value_with_length(server_id)
        else:
            request += '01'
        if username:
            request += self._return_value_with_length(username)
        else:
            request += '01'
        if password:
            request += self._return_value_with_length(password)
        else:
            request += '01'
        num_of_obis_codes = hex(len(obis_codes)).replace('0x', '7')
        request += num_of_obis_codes
        for obis in obis_codes:
            request += self._return_value_with_length(obis)
        if attribute:
            request += self._return_value_with_length(attribute)
        else:
            request += '01'
        request += self._crc16(request, True)
        request += '00'
        return request

    def sml_public_close_req(self):
        """composes an SMLPublicCloseReq"""
        request = '76'
        request += self._return_value_with_length(self.transaction_id)
        self.transaction_id += 1
        request += '6200620072'
        request += self._get_bytes_for_sml_type('SML_PublicClose.Req')
        request += '7101'
        request += self._crc16(request, True)
        request += '00'
        return request

    def sml_set_proc_parameter_req(self, data,
            username=None, password=None):
        """composes an SMLSetProcParameterReq"""
        request = '76'
        request += self._return_value_with_length(self.transaction_id)
        self.transaction_id += 1
        request += '6200620072'
        request += self._get_bytes_for_sml_type('SML_SetProcParameter.Req')
        request += '7501'
        if not username:
            username, password = self._get_username_password()
        if username:
            request += self._return_value_with_length(username)
        else:
            request += '01'
        if password:
            request += self._return_value_with_length(password)
        else:
            request += '01'
        request += '71'
        if len(data.keys()) > 1:
            request += '070101010101FF'
            # TODO length greater than 15 7F
            request += '73070101010101FF017' + hex(len(data.keys()))[2:]
        elif len(data.keys()) == 1:
            request += self._return_value_with_length(data.keys()[0])
        for obis, value in data.items():
            request += '73'
            request += self._return_value_with_length(obis)
            request += '726201'
            request += self._encode_value_with_prefix(obis, value)
            request += '01'
        request += self._crc16(request, True)
        request += '00'
        return request

    def _encode_sml_time(self, time_stamp):
        """given a UTC timestamp returns the SML_Time
        structure"""
        request = '7262'
        if self._timezone is None:
            request += '02'
            request += self._encode_value_with_prefix('SML_Timestamp',
                    time_stamp)
        else:
            request += '0373'
            request += self._encode_value_with_prefix('SML_Timestamp',
                    time_stamp)
            request += self._timezone[0] #local_offset
            request += self._timezone[1] #season_offset
        return request

    def sml_get_profile_pack_req(self, arguments,
            username=None, password=None):
        """composes an SMLGetProfilePackReq"""
        try:
            start = arguments['start']
            end = arguments['end']
        except KeyError:
            self.logger.warning('Start and end timestamps were passed' +\
            ' incorreclty for the profile method. Fetching only last day.')
            end = int(time.time())
            start = end - 3600 * 24
        request = '76'
        request += self._return_value_with_length(self.transaction_id)
        self.transaction_id += 1
        request += '6200620072'
        request += self._get_bytes_for_sml_type('SML_GetProfilePack.Req')
        request += '7901'
        if not username:
            username, password = self._get_username_password()
        if username:
            request += self._return_value_with_length(username)
        else:
            request += '01'
        if password:
            request += self._return_value_with_length(password)
        else:
            request += '01'
        request += '01'
        request += self._encode_sml_time(start)
        request += self._encode_sml_time(end)
        request += '71'
        request += self._return_value_with_length(PROFILE_GENERIC)
        request += '0101'
        request += self._crc16(request, True)
        request += '00'
        return request

    def sml_acknowledgement(self):
        request = "76"
        request += self._return_value_with_length(self.transaction_id)
        self.transaction_id += 1
        request += "620062007263FF017407B82ADC000001078181C7C7FD0001016362E500"
        return request

    def compose_message(self, method, arguments, transaction_id):
        """composes the message to be sent"""
        pre_header = '20' + self.cpeid + '%s'
        header = '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'
        tr_start = '1B1B1B1B01010101'
        self.transaction_id = transaction_id
        body = self.sml_public_open_req()

        if method == 'get':
            body += self.sml_get_proc_parameter_req(arguments)
        elif method == 'set':
            body += self.sml_set_proc_parameter_req(arguments)
        elif method == 'profile':
            body += self.sml_get_profile_pack_req(arguments)
        elif method == 'sml_ack':
            body += self.sml_acknowledgement()
        else:
            raise Exception('Unknown method %s' % method)

        body += self.sml_public_close_req()
        body += '0000001B1B1B1B1A03'
        body += self._crc16(tr_start + body)
        length = ('0000' + hex(len(header + tr_start + body) / 2)[2:])[-4:]
        pre_header %= length
        request = pre_header + header + tr_start + body
        self.logger.debug('About to send this to %s: %s',
                self.cpeid, request.upper())
        return binascii.unhexlify(request)


class SMLDevice(object):
    """sml device object"""
    def __init__(self, socket, cpeid, ip, logger, disconnect_me):
        self.is_fake = False
        if not socket:
            self.is_fake = True
        self.socket = socket
        self.ip = ip
        self.logger = logger
        self.composer = SMLComposer(cpeid, logger)
        self.parser = SMLParser(logger)
        self.cpeid = cpeid
        self._transaction_id = 0
        self._timezone = None
        self.pending_command = gevent.coros.Semaphore(value=1)
        self.command_list_flag = False
        self.command_sequence_complete = gevent.coros.Semaphore(value=0)
        #self.pending_transactions = ExpiringLRUCache(10, default_timeout=5000)
        self.last_job_successful = True
        self.pending_transactions = ''
        self.disconnect_me = disconnect_me
        self.queue = Queue()
        self.timeout = 10
        self.response_buffer = {}
        self.sender = gevent.spawn(self.send)


    def add_to_buffer(self, data):
        """ adds data to the buffer dict """
        if isinstance(data, list):
            if self.response_buffer == {}:
                self.response_buffer = []
            self.response_buffer += data
        elif isinstance(data, dict):
            try:
                if data['result'].startswith('Failure'):
                    if not len(self.response_buffer):
                        self.response_buffer.update(data)
                    return False
            except KeyError:
                pass
            self.response_buffer.update(data)
        return True

    def reset_buffer(self):
        self.response_buffer = {}

    def get_buffer(self):
        """ get data from the buffer """
        return self.response_buffer

    def set_timezone(self, timezone):
        """sets the timezone like (local_offet, season_offset)
        example ('53003C', '53003C')"""
        self._timezone = timezone
        self.composer.set_timezone(timezone)

    def get_ip(self):
        """returns the IP of the device"""
        return self.ip

    def get_metadata(self, tr_id):
        """ gets metadata from the givern transaction id """
        """
        tr_id = int(tr_id, 16)
        metadata = self.pending_transactions.get(tr_id)
        if metadata is None:
            self.logger.error('Transaction id not found...')
            msg = 'Looking for %d and I have %s' % (tr_id,
                    self.pending_transactions.data)
            self.logger.error(msg)
        self.pending_transactions.invalidate(tr_id)
        self.pending_command.release()
        return metadata
        """
        self.pending_command.release()
        return self.pending_transactions

    def send_data(self, data):
        """sends data through the socket"""
        self.logger.debug('CPEID %s: sent request', self.cpeid)
        self.socket.sendall(data)

    def send(self):
        """ reads from queue and send data to device """
        job_failed = [False]
        def job_status(job_failed):
            job_failed[0] = True
        gevent.signal(signal.SIGUSR1, job_status, job_failed)
        last_job = 0
        while 1:
            list_of_jobs = self.queue.get()
            self.last_job_successful = True
            self.command_list_flag = True
            job_count = 0
            for job in list_of_jobs:
                if job_failed[0]:
                    job_failed[0] = False
                    self.logger.warning("JOB FAILED: %s" % str(last_job))
                    self.command_list_flag = False
                    self.last_job_successful = False
                    break
                last_job = job
                self.pending_command.acquire()
                job_count += 1
                method, arguments, step, inline = job
                metadata = {'step': step,
                    'args': arguments,
                    'cpeid': self.cpeid,
                    'method': method,
                    'inline': inline }
                #self.pending_transactions.put(self._transaction_id, metadata)
                self.pending_transactions = metadata
                msg = self.composer.compose_message(method, arguments,
                    self._transaction_id)
                self._transaction_id = self.composer.transaction_id + 1
                if job_count == len(list_of_jobs):
                    self.command_list_flag = False
                try:
                    self.send_data(msg)
                except Exception, e:
                    self.logger.warning(e)
                    self.command_list_flag = False
                    self.pending_command.release()
                    self.disconnect_me(self.cpeid)
                    break
                gevent.sleep(0)
                start_ts = time.time()
                while self.pending_command.locked():
                    if time.time() - start_ts < self.timeout:
                        gevent.sleep(0.1)
                    else:
                        self.pending_command.release()
                        self.last_job_successful = False
                        self.command_list_flag = False
                        list_of_jobs = []
                        break
                if not self.last_job_successful:
                    break
            if self.last_job_successful:
                self.command_sequence_complete.acquire()
            else:
                self.reset_buffer()
                self.logger.warning('CPEID %s: Last Job was not successful',
                        self.cpeid)

    def add_job(self, method, arguments, step, inline):
        """composes and sends the message"""
        list_of_jobs = []
        if method == 'set' or method == 'get':
            if isinstance(arguments, list):
                for chunk in chunk_iterable(arguments, 15):
                    list_of_jobs.append((method, list(chunk), step, inline))
            elif isinstance(arguments, dict):
                for chunk in chunk_iterable(arguments.keys(), 15):
                    temp_dict = {}
                    for key in chunk:
                        temp_dict[key] = arguments[key]
                    list_of_jobs.append((method, temp_dict, step, inline))
        elif method == 'profile':
            start = arguments['start']
            end = start + 3590
            while end < arguments['end']:
                if start > time.time():
                    break
                if end > time.time():
                    end = int(time.time())
                list_of_jobs.append((method, {'start': start, 'end': end}, step, inline))
                start = end + 10
                end = start + 3590
            list_of_jobs.append((method, {'start': end - 3580, 'end': arguments['end']}, step, inline))
        elif method == 'sml_ack':
            list_of_jobs.append((method, {}, step, None))
        self.queue.put(list_of_jobs)

    def parse_data(self, payload):
        """parses the given payload"""
        parsed_data = self.parser.parse_sml(payload)
        self._transaction_id = self.parser.transaction_id + 1
        return parsed_data
