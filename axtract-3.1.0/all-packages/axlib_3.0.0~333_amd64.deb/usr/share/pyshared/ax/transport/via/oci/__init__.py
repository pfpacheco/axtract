"""Implementation of a http based interaction """
import hashlib
import logging
import re
import time
import urllib2

from suds.client import Client

from ax.transport.base import \
        ErrorConditionException, ConnectionClosedException,\
        TransportException
from ax.transport.connected_transport import ConnectedGetter

from messages import *

logger = logging.getLogger( __name__)

class OCI(ConnectedGetter):

    """
    >>> from ax.transport import axpand
    >>> import time
    >>> userId = '%s@broadsoft.com' %int(time.time() /100)
    >>> user_data = {
    ...         'userId': userId, 
    ...         'firstName':  'John',
    ...         'lastName': 'Doe',
    ...         'callingLineIdLastName': 'Doe',
    ...         'callingLineIdFirstName': 'John',
    ...         'password' : 'foobar',
    ...     }

    >>> client = axpand.get_transport_object('test', 'oci', settings={})
    >>> user = client.get(cmd='add_user', data=user_data)

    >>> user_profile = {
    ...         'userId': userId,
    ...         'language': 'English',
    ...         'title': 'Mr.',
    ...         'emailAddress': userId,
    ...         'mobilePhoneNumber': '0123456',
    ...         'pagerPhoneNumber': '7890123',
    ...         'addressLocation': 'Munich',
    ...         'addressLine1': 'St. Foo',
    ...         'city': 'Munich',
    ...         'stateOrProvince': 'Munich',
    ...         'stateOrProvinceDisplayName': 'Bayern',
    ...         'zipOrPostalCode': '85635',
    ...         'country': 'Germany',
    ...         'timeZone': 'Europe/Berlin',
    ...     }

    >>> profile = client.get(cmd='set_user_profile', data=user_profile)
    >>> # This will add all available services to user. If you want to 
    >>> # add only a set of services, add a list of service names
    >>> # with a key called "serviceName"
    >>> user_group = {
    ...     'userId': userId,
    ...     'serviceProviderId': 'demorauckenthaler',
    ...     'groupId': 'Axiros',
    ... } 
    >>> 
    >>> assigned_services = client.get(cmd='assign_services', data=user_group)

    >>> user_sip_account = client.get(cmd='set_user_sip_account', data={})Name    """

    oci_url = "https://xsp2.ihs.broadsoft.com/webservice/services/ProvisioningService?wsdl"
    oci_user = 'AxirosAdmin@broadsoft.com'
    oci_password = 'Axiros2012'
    acs_name = "acs1"

    sessionId = None
    nonce = None
    group_id = None
    service_provider = None
    phoneId = None

    def open_connection(self):
        self.sessionId = self._generate_session_id()
        self.client = Client(self.oci_url)

        self.authenticate()

        return self.client

    def close(self, conn_obj):
        self.logout()

    def communicate(self, cmd, conn_obj, condition,\
            error_condition, timeout, **kwargs):
        # entry point for communication:
        # understand the specific commands here.


        if hasattr(self, cmd):
            command = getattr(self, cmd)
            if callable(command):
                return command(**kwargs)
            else:
                raise TypeError("Command %s is not callable for <oci.OCI>" %cmd)

        else:
            raise NotImplementedError

    def _generate_session_id(self):
        if self.sessionId:
            return self.sessionId

        mapping = {
            'acs_name': self.acs_name,
            'sys_time': time.ctime(),
            'session': self.phoneId,
        }
        self.sessionId = "Host=%(acs_name)s,Production=false,SessionID=%(session)s,SystemTime=%(sys_time)s" % mapping
        return self.sessionId

    def create_password_digest(self):
        sha_pwd = hashlib.sha1(self.oci_password).hexdigest()
        md5_pwd = hashlib.md5(self.nonce + ":" + sha_pwd ).hexdigest()
        return md5_pwd


    def send_auth_request(self):
        body = AUTHENTICATION_REQUEST % {
                'sessionId': self.sessionId,
                'username': self.oci_user
                }
        response = self._sendxml(body)

        # Get the nonce of the response
        nonce = re.findall('<nonce>(.*)</nonce>', response)
        if nonce:
            self.nonce = nonce[0]
        return self.nonce

    def send_auth_challenge(self):
        body = AUTHENTICATION_CHALLENGE % {
                'sessionId': self.sessionId,
                'username': self.oci_user,
                'signed_password': self.create_password_digest()
                }
        response = self._sendxml(body)

        # We get need the goupId and the ServiceProvider
        group_id = re.findall('<groupId>(.*)</groupId>', response)
        if group_id:
            self.group_id = group_id[0]
        service_provider = re.findall('<serviceProviderId>(.*)</serviceProviderId>', response)
        if service_provider:
            self.service_provider = service_provider[0]

    def get_default_fields(self):
        default_fields = {
                    'serviceProviderId': self.service_provider,
                    'groupId': self.group_id,
        }
        return default_fields

    def send_commands(self, commands):
        result = []
        for command in commands:
            body = COMMANDS % {
                    'sessionId': self.sessionId,
                    'command': command,
                    }
            #body = body % body_params
            response = self._sendxml(body)
            success = False
            # Check for an error
            if "ErrorResponse" in response:
                # Get error message
                error = re.findall('<summary>(.*)</summary>', response)
                if error:
                    result.append("ERROR: %s" % error[0])
                else:
                    result.append("UNKNOWN ERROR")
            else:
                result.append("SUCCESS")
                success = True

            logger.debug(response)
            print response
        return (success, result, response)

    def parse_fields(self, fields, data={}):

        chunks = []

        for field in fields:
            if hasattr(field, '__iter__'):
                complex_chunks = []
                complex_field = field[0]
                chunk = self.parse_fields(field[1:], data)
                chunks.append('<%s>\n\t%s\n</%s>' %(complex_field, chunk, complex_field))

                continue

            value = data.get(field, False)
            if value:
                chunk = ""
                if hasattr(value, '__iter__'):
                    values = []
                    for v in value:
                        values.append('<%s>%s</%s>' %(field, v, field))

                    value = '\n'.join(values)
                else:
                    value = '<%s>%s</%s>' %(field, value, field)

                chunks.append(value)

        return '\n'.join(chunks)

    def generate_valid_body(self, header, fields, data={}):
        """
            The OCI standard is strict on input validation. If a field is
        provided, it should at least have some useable data 
        """

        default_fields = self.get_default_fields()
        data.update(default_fields)

        # The command header MUST always be sent
        chunks = [header,]

        chunks.append(self.parse_fields(fields, data))

        chunks.append('</command>')
        body = '\n'.join(chunks)

        return body 

    def add_user(self, data):
        body = self.generate_valid_body(ADD_USER_HEADER, ADD_USER_FIELDS, data)
        return self.send_commands([body,])

    def set_user_profile(self, data):
        body = self.generate_valid_body(SET_USER_PROFILE_HEADER, SET_USER_PROFILE_FIELDS, data)
        print(body)
        return self.send_commands([body,])

    def assign_services(self, data):

        if not data.get('serviceName', False):
            services = self.list_available_services(data)
            data['serviceName']= services

        body = self.generate_valid_body(ASSIGN_SERVICES_TO_USER_HEADER, ASSIGN_SERVICES_TO_USER_FIELDS, data)
        return self.send_commands([body,])

    def list_available_services(self, data):
        body = self.generate_valid_body(LIST_AVAILABLE_SERVICES_HEADER, LIST_AVAILABLE_SERVICES_FIELDS, data)
        success, msg, response = self.send_commands([body,])

        if not success:
            raise Exception(msg, response)

        # We are not interested in :
        #   servicePacksAuthorizationTable
        #   userServicesAuthorizationTable
        #group_services = re.findall('<groupServicesAuthorizationTable>(.*)</groupServicesAuthorizationTable>', response)
        group_services = re.findall('<userServicesAuthorizationTable>(.*)</userServicesAuthorizationTable>', response)

        if not group_services:
            raise Exception('Failed to get the list of authorized services for group %s. \nResponse: \t%s' %(data['groupId'], response))

        services = group_services[0]
        collumns = len(re.findall('<colHeading>', services))
        rows = re.findall('<col/?>([^<]*)', services)

        allowed_services = []

        while len(rows):
            try:
                service = [rows.pop(0) for i in range(collumns)]
            except IndexError:
                break

            service_name = service[0]
            service_allowed = service[1]
            user_assignable = service[8]
            group_assignable = service[9]

            if service_allowed == 'true' and \
                user_assignable == 'true': #and\
                allowed_services.append(service_name)

        return allowed_services


    def authenticate(self):
        self.send_auth_request()
        self.send_auth_challenge()

    def logout(self):
        body = LOGOUT % {
                'username': self.oci_user,
                'sessionId': self.sessionId,
                }
        response = self._sendxml(body)

    def _sendxml(self, body):
        logger.debug("BODY:\n\n %s" % body)
        print("BODY:\n\n %s" % body)
        response = self.client.service.processOCIMessage(body)
        #response = client.service.processMessage(body)
        print( "RESPONSE: \n\n %s" % response)


        return response


