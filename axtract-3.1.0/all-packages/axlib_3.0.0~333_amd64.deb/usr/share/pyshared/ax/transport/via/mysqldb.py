"""Implementation of a layer 5 Telnetter using python's telnetlib."""
from ax.transport.base import ErrorConditionException, ConnectionClosedException
from ax.transport.connected_transport import ConnectedGetter
import MySQLdb
from MySQLdb import ProgrammingError, OperationalError
import logging

logger = logging.getLogger( __name__)

class MySQLClient(ConnectedGetter):
    """
    Using python's MySQLdb driver
    """
    identification =  "MySQLdb://%(user)s@%(host)s:%(port)s/"
    allowed_cmds = """^[(,*)"'%A-z @.0-9]+$"""
    allowed_args = None
    maxdata = 1000

    database = ''
    user = None
    password = None
    host = '127.0.0.1'
    port = 3306




    def open_connection (self):
        try:
            return MySQLdb.connect(host = self.host, \
                port = self.port, \
                user = self.user, \
                passwd = self.password,\
                db = self.database
                )
        except Exception, ex:
            logging.exception(ex)
            msg = "Could not connect to %s - exception was: %s" %\
                    (self.identification % self, ex)
            raise ConnectionClosedException (msg)


    def communicate(self, cmd, conn_obj, condition, error_condition, timeout,  **kwargs):
        cursor = conn_obj.cursor()
        try:
            cursor.execute(cmd, kwargs.get('args'))
            return cursor.fetchall()
        except (ProgrammingError, OperationalError), ex:
            logging.exception(ex)
            err = 'Error: %s' % ex
            if condition and 'Error' in condition:
                return 'Ignoring ' + err
            raise ErrorConditionException(err)
        except Exception, ex:
            logging.exception(ex)
        finally:
            logging.debug('closing cursor')
            conn_obj.commit()
            cursor.close()


