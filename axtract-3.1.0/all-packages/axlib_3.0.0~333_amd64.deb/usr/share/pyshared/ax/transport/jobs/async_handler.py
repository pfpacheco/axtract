"""
Handling the starting of threads and subprocesses for blocking transports

"""
from time import time
import subprocess
from ax.transport.transport_access import get_transport_object
from sys import argv
from os import kill
import signal
from logging import getLogger
logger = getLogger(__name__)


# for now we keep a reference to all here, not only in the objectpool - since
# the pool currently keeps no ref on objects currently in use - so we could not
# shut them down at program end.
PROCS = {}
THREADS = []

START_THREAD = 'STARTTHREAD'
FINAL_CLOSE = 2
def shutdown_all():
    """ the main program ends """
    for name in PROCS:
        # we are closing
        _kill_proc(name)
    for t in THREADS:
        logger.info('Stopping thread %s' % t)
        safe_close(t, force_close=FINAL_CLOSE)


def handle_async(job, cmd, SL, **kw):
    """ queue worker got a '/ASNC' command:"""
    if not cmd.startswith('/ASNC:'):
        return None, None
    mode = cmd[6:].split(':')[0]
    id = job.get('pool_id')
    if not id:
        raise Exception("Need a pool_id to address this async job handler")

    settings = job.get('settings', {})
    # via this via block if later 2 queue workers want to send signals to it
    # parallel:
    if not 'poolsize' in settings:
        settings['poolsize'] = 1
    # we keep references in the start calls for later stop calls:
    settings['connection_pooling'] = 1

    t = get_transport_object(pool_id=id,
                             settings=settings,
                             do_connect=START_THREAD in mode)

    if mode == 'STARTPROC':
        # start it, by writing this job as startup spec, telling him he should
        # start the server as thread:
        temp = '/tmp/tmp%s' % time()
        with open(temp, 'w') as f:
            f.write(str(job).replace('STARTPROC', START_THREAD))
        start = kw.get('start_args')
        if not start:
            start = [argv[0],
                     '-q', id,
                     '-S', '"%s"' % ','.join(SL['servers']),
                     '--jobfile=%s' % temp
                     ]
        proc = subprocess.Popen(start)
        PROCS[id] = proc
        return t, 'Started process %s' % proc.pid

    elif mode == 'KILLPROC':
        _kill_proc(id)
        t.close(force_close=1)
        return None, 'Killed %s process' % id


    elif mode == START_THREAD:
        # if this command was sent to the same process, with same poolid,
        # the thread might still be alive, which we consider as ok:
        if not t.is_alive():
            t.daemon = True
            ps = ''
            t.start()
            THREADS.append(t)
        else:
            ps = ' (was alive)'
        return t, 'Started thread %s%s.' % (t, ps)

    elif mode == 'STOPTHREAD':
        t.shutdown_requested = 1
        # by the pooling mechanics the close meth was overwritten:
        safe_close(force_close=1)
        # None to prevent another close operation on it:
        THREADS.remove(t)
        return None, 'Stopped'


def _kill_proc(name):
    try:
        pid = PROCS.pop(name).pid
    except:
        return
    logger.info('killing process %s (%s)' % (name, pid))
    try:
        kill(pid, signal.SIGTERM)
    except:
        pass
    try:
        kill(pid, signal.SIGKILL)
    except:
        pass


def safe_close(t, force_close=None):
    if force_close == FINAL_CLOSE:
        # that prevents any blocking put back, see close method::
        t.poolsize = None
    try:
        t.close(force_close=force_close)
    except:
        pass


