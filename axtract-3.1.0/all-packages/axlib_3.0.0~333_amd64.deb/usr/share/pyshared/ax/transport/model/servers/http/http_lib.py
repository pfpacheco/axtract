import urlparse
import simplejson

class Redirect(Exception):
    pass


def set_mime_type(url, headers, res):
    if isinstance(headers, dict):
        headers = headers.items()
    if '.woff' in url:
        headers += (('Content-Type', 'application/font-woff'),)
    elif '.css' in url:
        headers += (('Content-Type', 'text/css'),)
    elif '.js' in url:
        headers += (('Content-Type', 'text/javascript'),)
    elif '.html' in url or '_html' in url:
        headers += (('Content-Type', 'text/html'),)

    return headers

def parse_form(data, exists={}):
    """ urlencoded or json posts or query strings into map """
    try:
        exists.update(simplejson.loads(data))
    except Exception:
        qsl = urlparse.parse_qsl(data)
        for k, v in qsl:
            if k in exists:
                # zope style:
                exists[k] = [exists[k], v]
            exists[k] = v
    return exists
