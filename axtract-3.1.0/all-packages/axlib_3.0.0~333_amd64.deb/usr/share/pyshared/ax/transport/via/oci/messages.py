
# Needs sessionId and username
AUTHENTICATION_REQUEST = """<ns2:BroadsoftDocument xmlns:ns2="C" protocol="OCI">
<sessionId>%(sessionId)s</sessionId>
<command xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="AuthenticationRequest">
<userId>%(username)s</userId>
</command>
</ns2:BroadsoftDocument>
"""

# Needs sesson_id, username and signed_password
AUTHENTICATION_CHALLENGE = """<ns2:BroadsoftDocument xmlns:ns2="C" protocol="OCI">
<sessionId>%(sessionId)s</sessionId>
<command xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="LoginRequest14sp4">
<userId>%(username)s</userId>
<signedPassword>%(signed_password)s</signedPassword>
</command>
</ns2:BroadsoftDocument>
"""

# Needs sessionId and command
COMMAND_REQUEST = """<ns2:BroadsoftDocument xmlns:ns2="C" protocol="OCI">
<sessionId>%(sessionId)s</sessionId>
%(command)s
</command>
</ns2:BroadsoftDocument>
"""

# Needs Username
LOGOUT = """<ns2:BroadsoftDocument xmlns:ns2="C" protocol="OCI">
<sessionId>%(sessionId)s</sessionId>
<command xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="LogoutRequest">
<userId>%(username)s</userId>
</command>
</ns2:BroadsoftDocument> """

COMMANDS = """<ns2:BroadsoftDocument xmlns:ns2="C" protocol="OCI">
<sessionId>%(sessionId)s</sessionId>
%(command)s
</ns2:BroadsoftDocument>"""


COM_1 = """<command xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="SystemSoftwareVersionGetRequest"/>"""
COM_2 = """<command xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="GroupAccessDeviceModifyRequest14">
<serviceProviderId>VF_366456242-1</serviceProviderId>
<groupId>VF_366456242-1_3969_2</groupId>
<deviceName>0107006286</deviceName>
<macAddress>58BFEA10FE7A</macAddress>
</command>"""
COM_3 = """<command xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="GroupAccessDeviceModifyRequest14">
<serviceProviderId>VF_366456242-1</serviceProviderId>
<groupId>VF_366456242-1_3969_2</groupId>
<deviceName>0107006286</deviceName>
<macAddress xsi:nil="true"/>
</command>"""
COM_4 = """<command xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="GroupAccessDeviceModifyRequest14">
<serviceProviderId>VF_366456242-1</serviceProviderId>
<groupId>VF_366456242-1_3969_2</groupId>
<deviceName>0107006286</deviceName>
<macAddress>58BFEA10FEB3</macAddress>
</command>"""
COM_5 = """<command xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="UserAccessDeviceTagsGetRequest">
<userId>AxirosFoo@broadsoft.com</userId>
<accessDevice>
    <deviceLevel>System</deviceLevel>
    <deviceName>axiros.aastra</deviceName>
</accessDevice>
</command>"""
COM_6 = """<command xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="GroupAccessDeviceAddRequest14">
<serviceProviderId>demoauckenthaler</serviceProviderId>
<groupId>Axiros</groupId>
<deviceName>axiros_test</deviceName>
<deviceType>axiros.aastra</deviceType>
</command>"""
COM_7 = """<command xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="UserAddRequest17sp4">
<serviceProviderId>demoauckenthaler</serviceProviderId>
<groupId>Axiros</groupId>
<userId>AxirosBar@broadsoft.com</userId>
<lastName>Bar</lastName>
<firstName>Axiros</firstName>
<callingLineIdLastName>Bar</callingLineIdLastName>
<callingLineIdFirstName>Axiros</callingLineIdFirstName>
<password>yeah!!</password>
</command>"""


ADD_USER = """<command xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="UserAddRequest17sp4">
<serviceProviderId>%(service_provider)s</serviceProviderId>
<groupId>%(group_id)s</groupId>
<userId>%(userID)s</userId>
<lastName>%(lastName)s</lastName>
<firstName>%(firstName)s</firstName>
<callingLineIdLastName>%(callingLineIdLastName)s</callingLineIdLastName>
<callingLineIdFirstName>%(callingLineIdFirstName)s</callingLineIdFirstName>
<password>%(password)s</password>
</command>"""

ADD_DEVICE = """<command xsi:type="GroupAccessDeviceAddRequest14" xmlns="" echo="My GroupAccessDeviceAddRequest14 add PC">
<serviceProviderId>%(service_provider)s</serviceProviderId>
<groupId>%(group_id)s</groupId>
<deviceName>userid_btbc_pc</deviceName>
<deviceType>Business Communicator - PC</deviceType>
<protocol>SIP 2.0</protocol>
<transportProtocol>Unspecified</transportProtocol>
</command>"""

SET_USER_PROFILE = """<command xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="UserModifyRequest17sp4">
<userId>%(userID)s</userId>
<language>%(language)s</language>
<timeZone>%(timeZone)s</timeZone>
<title>%(title)s</title>
<pagerPhoneNumber>%(pagerPhoneNumber)s</pagerPhoneNumber>
<mobilePhoneNumber>%(mobilePhoneNumber)s</mobilePhoneNumber>
<emailAddress>%(emailAddress)s</emailAddress>
<addressLocation>%(addressLocation)s</addressLocation>
<address>%(address)s</address>
</command>"""


ADD_USER_HEADER = """<command xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="UserAddRequest17sp4">"""
ADD_USER_FIELDS = ['serviceProviderId','groupId','userId','lastName','firstName','callingLineIdLastName','callingLineIdFirstName','password',]

SET_USER_PROFILE_HEADER = """<command xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="UserModifyRequest17sp4">"""
SET_USER_PROFILE_FIELDS = ['userId','language','timeZone','title','pagerPhoneNumber','mobilePhoneNumber','emailAddress',
['address', 'addressLine1', 'addressLine2', 'city', 'stateOrProvince', 'stateOrProvinceDisplayName', 'zipOrPostalCode', 'country',],
]

LIST_AVAILABLE_SERVICES_HEADER = """<command xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="GroupServiceGetAuthorizationListRequest">"""
LIST_AVAILABLE_SERVICES_FIELDS = ['serviceProviderId', 'groupId',]

ASSIGN_SERVICES_TO_USER_HEADER = """<command xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="UserServiceAssignListRequest">"""
ASSIGN_SERVICES_TO_USER_FIELDS = ['userId', 'serviceName']
