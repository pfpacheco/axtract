"""
Loading the portal via an Axpand HTTP server, i.e. NOT inside Zope.


Model registered in this same file, which is exec.ed by the config loader of
job_handler, so the model gets registered (last line).
"""

# ----------------------------------------------------------- JobHandler config
# start job_handler with -c <this file>, so that it sets startup_jobs as given.
# We use for the beginning the normal threaded http server:
worker_threads = 1
my_queues = ['-']
startup_jobs = """
cmd: /ASNC:STARTTHREAD
pool_id: Ax1PortalServer
settings:
  model: servers.http.AX1PortalServer
  zeo: 127.0.0.1:8100
  port: 8089
  host: 0.0.0.0
  via: ax.transport.servers.threaded_http_server.AxThreadedHTTPServer
"""
# ------------------------------------------------------ End Job Handler Config



# ---------------------------------------------- Model Code for the HTTP server
import sys
from os import environ
from ax.utils.lib.web.portals.ax1 import loader
from ax.transport.model.model_support import add_model
from ax.transport.model.servers.http.http_app_srv import ZeoClient

web_path = loader.__file__.split('/portals')[0]

portal_path = web_path + '/portals'
if not portal_path in sys.path:
    sys.path.append(portal_path)


# AXPAND is on /opt and /opt is in sys.path !
environ['DJANGO_SETTINGS_MODULE'] = 'AXPAND.cfg.settings'

MAIN_PAGE = '/index.html'
CTX = {'app_name': 'AXPAND',
       'main_page': MAIN_PAGE,
       'allowed': '.*',
       'sections': ['logging', 'doc', 'tom', 'settings'],
       'section_settings_sub1': ['skin', 'preferences'],
       'section_logging_from': 'AXPAND.portal',
       'section_tom_from': 'AXPAND.portal',
       }

# why not cache ALL static files:
CACHE = {}


class AX1PortalServer(ZeoClient):
    """ Serving the ax1 portal from outside of Zope
    We mimic the behaviour of the AXWorkflow based loader
    """


    def do_GET(self, t, url, headers={}, post_data=None, **kw):
        """ t is transport with parametrization, h is the req handler """

        # -------------------------------------------------------- Static pages
        # get the Zope style request, with session and params:
        if 'static' in url or 'load_static=' in url:
            url = url.split('?', 1)[0].replace(MAIN_PAGE, '')
            hit = CACHE.get(url)
            if hit and not 'ajax' in url:
                return hit
            if '/ax1/' in url:
                fpath = portal_path + '/ax1/' + url.split('/ax1/')[1]
            else:
                fpath = web_path +  url
            with open(fpath) as f:
                ret = f.read()
                CACHE[url] = ret
            return ret


        # ------------------------------------------------------- Dynamic pages
        # we are using the loader into real AXESS like is:
        env = self.get_request_env(t,
                                   called = MAIN_PAGE,
                                   url=url,
                                   headers=headers,
                                   post_data=post_data,
                                   **kw)

        kw['kw'] = CTX

        r = env['request']
        app = env['app']
        # zope style:
        app.REQUEST = r

        try:
            res = loader.axess_load(app, debug = 'deb' in r.form, **kw)
            res['headers'] = {'cookies': r.RESPONSE.cookies}
            return res
        except Exception, ex:
            return self.handle_exc(ex)


# registering the model:
add_model('servers.http.AX1PortalServer', AX1PortalServer())
