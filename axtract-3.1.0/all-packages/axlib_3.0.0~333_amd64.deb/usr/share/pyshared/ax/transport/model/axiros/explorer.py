from ax.transport.model.model_support import Model, AX_DI
from ax.transport.model.model_support import add_model

ID = '.DeviceInfo.'
class Explorer(Model):
    no_comm = None

    def Inform(self, t):
        res = {}
        res.update(AX_DI)
        if not self.no_comm:
            try:
                res = t.get('model')
                #t.write_cpe(res)
            except Exception, ex:
                res[ID + 'SerialNumber'] = 'AXPAND_ERROR'
        return res

add_model(('axiros.explorer', Explorer()))

