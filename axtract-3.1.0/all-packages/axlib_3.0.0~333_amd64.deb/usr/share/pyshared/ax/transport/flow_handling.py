""" Static flow handling methods """
import logging
from types import ListType
from ax.transport.base import TransportException
from ast import literal_eval
from ax.transport.formatting import format_result
from ax.transport.transport_access import get_transport_object
from ax.utils.sub_proc_runner import get_proc_res

import re

try:
    import simplejson as json
except ImportError:
    import json

logger = logging.getLogger( __name__)


######################################################
#
# Json Flow Handling
#
######################################################

class FlowException(TransportException):
    err_id = 19400
    pass



def run_cmd_step(t, spec, ret_map):
    """Run a single step of a command flow, specified by $spec
        The result is put in $ret_map if/how $spec says.
    """
    # parse a few standard vars and the rest pass through via get and
    # communicate to the specific transport:

    # condition handling. 'prompt' shall be synon. to 'condition'
    until, condition = spec.get('until'), spec.get('condition', spec.get('prompt'))
    # Only one of $until and $condition may have a value, the other must
    # be None. If both are None, $condition defaults to $self.condition. If
    # $condition is given, $self.condition is set to $condition.

    if condition:
        t.condition = condition

    # Handle error cases
    if until is not None and condition is not None:
        # Only one is allowed allowed.
        raise ValueError("$until and $condition were specified, but only "
                "one is allowed ('%s'/'%s'")
    condition = until or condition

    timeout = spec.get('timeout')
    if timeout:
        timeout = float(timeout)

    # the error condition given in error_condition is checked at
    # every receive (if set).
    # 'error_condition' = 'error'
    error_condition = spec.get('error_condition', spec.get('error'))

    cmd = spec.get('cmd', None)
    if cmd is None:
        # We did the magic above (setting condition, timeout...) and do not
        # want to run any command.
        return
        # cmd == '' it's allowed, it's like punching return.


    # if given, put result in ret_map under this name:
    ret_as = spec.get('as', None)

    # fmt given -> return as cmd:
    if not ret_as and spec.get('fmt'):
        ret_as = 'RESULT ' + cmd

    # we allow this shortcut for multiple commands:
    cmd_parts = cmd.split('/;')

    # Run command(s), gather result(s).
    res = []
    # we want to parse ANY kwarg into the via. put away the contol flow ones:
    kwargs = {}
    kwargs.update(spec)
    for expl in ('cmd',
                 'until',
                 'prompt',
                 'condition',
                 'as',
                 'error_condition',
                 'error',
                 'timeout',
                 'settings'):
        try: del kwargs[expl]
        except: pass

    for cmd_part in cmd_parts:
        received = t.get(cmd_part, condition,\
                    error_condition, timeout, **kwargs)
        logger.debug("%s: %s" , t, t.nice_log(received))

        # push received string through all formatters:
        if ret_as:
            received = format_result (t, ret_as, cmd, received, spec)

        res.append(received)

    if ret_as:
        # have the result finally, put into the return map:
        # ret as was if we did not have multiple commands:
        if len(res) == 1:
            res = res[0]
        ret_map[ret_as] = res



def run_flow(t, cmdlist):
    """ run a simple flow  - lightweight alternative to the
    complex run_cmd_flow """

    if isinstance(cmdlist, (str, unicode)):
        try:
            cmdlist = json.loads(cmdlist)
        except:
            try:
                cmdlist = literal_eval(cmdlist)
            except:
                # take it as a simple command:
                cmdlist = [{'cmd': cmdlist}]

    if isinstance(cmdlist, dict):
        cmdlist = [cmdlist]
    # if only one command we return it:
    if len(cmdlist) == 1 and not 'as' in cmdlist[0]:
        cmdlist[0]['as'] = 'result'

    ret_map = {}
    for spec in cmdlist:
        run_cmd_step(t, spec, ret_map)
    return ret_map







######################################
#
# Line flow parsing
#
######################################
KNOWN_TAGS = {'AS': 'as',
              'CMD': 'cmd',
              'UNTIL': 'until',
              'FMT': 'fmt',
              'ARGS': 'args',
              'ERR': 'error_condition',
              'PROMPT': 'condition',
              'TIMEOUT': 'timeout',
              'END': '-'}

def try_line_parsing(cmdlines):
    """
    Convert cmdlines to ListType :
        cmd1
        cmd2 arg2 AS foo
        cmd3 UNTIL $ /Z AS bar
        cmd4 ARGS [foo, bar]
        cmd5 ARGS {foo: bar, 1: 2}
    will result in
    [{'cmd': 'cmd1'}, {'cmd': 'cmd2 arg2', 'as': 'foo'},
     {'cmd': 'cmd3', 'until': '$ /Z', 'as': 'bar'},
     {'cmd': 'cmd4', 'args': ['foo', 'bar']},
     {'cmd': 'cmd5', 'args': {'foo': 'bar', '1':'2'}}]
    We are very cautious about whitspace as you can see.
    Order of tags does not matter, but cmd must be first.
    """
    ret = {}
    if not type(cmdlines) in (unicode, str):
        return

    cmdlines = cmdlines.strip()
    if  cmdlines[0] in ('{', '['):
        return

    cmdlines = cmdlines.replace('\r', '')

    if cmdlines.startswith('via '):
        # the line flow contains settings:
        settings, cmdlines = parse_settings(cmdlines)
        if settings:
            ret['settings'] = settings

    ret_list = []
    tags = KNOWN_TAGS.keys()

    for line in cmdlines.split('\n'):
        # we allow comments and there may be whitespace left:
        line = line.strip()
        if not line or line.startswith('#') or line.strip()=='get':
            continue
        cmd_spec = {}
        # to get the parsing all done:
        line += ' END'
        statement_list = line.split(' ')
        cur_tag = 'CMD'
        cur_val = ''
        for statement in statement_list:
            if not statement: continue
            if not statement in tags:
                cur_val += ' ' + statement
            else:
                # a new tag is comming - write the old:
                cmd_spec[KNOWN_TAGS.get(cur_tag)] = cur_val.strip()
                cur_tag = statement
                cur_val = ''
        # try to be smart if ARGS are given\
        # turn straightforward into lists and maps:
        args =cmd_spec.get('args')
        # lists:
        if args:
            if args.startswith('['):
                # like [1, foo, bar]
                arglist = []
                for a in args[1:-1].split(','):
                    arglist.append(a.strip())
                cmd_spec['args'] = arglist
            elif args.startswith('{'):
                # like {foo: bar, 1: 2}
                argmap = {}
                for kv in args[1:-1].split(','):
                    if not kv: continue
                    k,v = kv.split(':', 1)
                    argmap[k.strip()] = v.strip()
                cmd_spec['args']= argmap
        ret_list.append(cmd_spec)

    # if there is just one command add an 'AS':
    if len(ret_list) == 1 and not ret_list[0].get('as'):
        ret_list[0]['as'] = 'result'

    ret['cmdlist'] = ret_list
    return ret


def parse_settings(flow):
    """
    get like:

        via telnet
          host 127.0.0.1
           port 23
        condition $ .
        # comment
          prolog F:[S]/UNSET:dbg_cli[S]/WAIT[R]login: [S]user[R]Password: [S]pass[R]$ .
        get
         ifconfig eth0 AS ipconfig

    and return:
        {'via': 'telnet', ...}, "ifconfig eth0 AS ipconfig"
    i.e. the setup as map and the flow as is, will be parsed above.

    """
    if not flow.startswith('via '):
        # not settings here:
        return {}, flow
    settings = {}
    get_line = None

    for line in flow.split('\n'):
        line = line.strip()
        if line.startswith('get'):
            get_line = line
            break
        if not line or line.startswith('#'):
            continue
        # just a key puts a '' as val:
        if not ' ' in line:
            settings[line] = ''
            continue
        k, v = line.split(' ', 1)
        k = k.strip()
        v = v.strip()
        if v == 'None':
            v = None
        elif v.endswith('.'):
            if v.endswith('/.'):
                v = v[:-2]+'.'
            else:
                v = v[:-1]
        if k == 'timeout':
            v = float(v)
        if k == 'newline':
            # can't send directly:
            v = v.replace('/r', '\r').replace('/n', '\n')
        settings[k] = v
    if not get_line:
        return settings, ''
    flow = flow.split(get_line, 1)[1]
    return settings, flow


