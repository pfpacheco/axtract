"""
Extension of the original Send/Receive Concept to arbitrary client sided
interactions, including that (from original docu):


Module that helps with telnetting and similar stuff.

This module (or rather, its implementations) provide you with functions that
greatly help you when you need to do command->response->command->response...
chains via telnet.

Actually, the various implementations do not only support telnet but anything
that fits in the send_stuff()->receive_stuff()->send_stuff()->receive_stuff()
pattern. This includes
    - generic TCP/IP interactions similar to what netcat does. Check out
        PythonSocketTelnetter and GeventSocketTelnetter for that.
    - Abstracting STDIN/STDOUT/STDERR of arbitrary programs. This is implemented
        by PopenTelnetter and PexpectTelnetter.

Ideally you can convert
a Telnet-flow that uses PythonSocketTelnetter into an SSH-flow that uses
PexpectTelnetter simply by instantiating a different class and setting
different properties (in this case $command instead of $host and $port).
"""

import re
import time
import traceback

import logging
from os.path import join
try:
    from simul_mode import setup_simulation_mode
except:
    print 'No simulation mode support - mock framework not available'

from ax.utils.dynamic_objects.dyn_code import load_ext_uri
from ax.utils import obj_members

from testable_transport import TestableTransport
# parsing parametrizations of anything a client -> server interaction could
# run into is a tedious thing - it's done here:
from ax.transport.condition_checking  import build_condition_object
from ax.transport.condition_checking  import check_condition


logger = logging.getLogger( __name__)

class TransportException(Exception):
    """ Root of all exceptions"""
    err_id = 18000
    def __init__(self, ex_str=None, ex_obj=None):
        self.ex_obj = ex_obj
        if not ex_str:
            if ex_obj:
                ex_str = str(ex_obj)
            else:
                ex_str = 'Transport Exception'
        super(TransportException, self).__init__(ex_str)

    def get_class_name(self, c):
        # crazy, obviously strange exception objects gotten:
        return str(c.__class__).rsplit('.',1)[1].split("'", 1)[0]

    def __str__(self):
        cs = self.get_class_name(self)
        m = self.message
        if self.ex_obj:
            ecs = self.get_class_name(self.ex_obj)
            return '%s %s: %s(%s)' % (cs, self.err_id, ecs, m)
        else:
            return '%s %s: %s' % (cs, self.err_id, m)


class ConnectionClosedException(TransportException):
    """You wanted to send/receive but the other side closed the connection"""
    err_id = 18400

class UnauthorizedException(TransportException):
    """Credentials had not been accepted"""
    err_id = 18450


class TooMuchDataException(TransportException):
    """A read aborted because more data was received than allowed.
        Check the $maxdata parameter of read_until()
    """
    err_id = 18500

class TimeoutException(TransportException):
    """A read aborted because no $terminator was found before timeout"""
    err_id = 18600

class SecurityException(TransportException):
    """Cmds or args violated the allowed set"""
    err_id = 18650


class ErrorConditionException (TransportException):
    """An interaction with the other side was considered an error from the
    other side (matching the error_condition in general)"""
    err_id = 17000


def load_uri_with_env(uri, t_obj, MODELS):
    if not uri:
        return
    logger.info('loading uri %s for %s', uri, t_obj)
    exec_globals = {
            'transport': t_obj,
            'self': t_obj,
            'MODELS': MODELS
            }
    exec_globals.update(EXT_CODE_ENV)
    do_reload = False
    if uri.startswith('RELOAD:'):
        uri = uri.split('RELOAD:', 1)[1].strip()
        do_reload = True
    code = load_ext_uri(uri, exec_globals, cache_code=1, force_reload=do_reload)
    logger.debug("loaded code %s", code)



# debug level control (dbg_cli var)
START_PDB_ON_GET = '1'
STACK_TRACE_GET_EXCEPTIONS = '2'

# object() is quite
# pointless, but guaranteed not to be equal to anything except itself.
UNTIL_EOF = lambda data, **kwargs: isinstance(data, ConnectionClosedException)
UNTIL_TIMEOUT = lambda data, **kwargs: isinstance(data, TimeoutException)
NO_READ = object()

# that map might be extended by other transports:
EXT_CODE_ENV = {"re": re,
    "TransportException": TransportException,
    "TimeoutException": TimeoutException,
    "TooMuchDataException": TooMuchDataException,
    "UnauthorizedException": UnauthorizedException,
    "SecurityException": SecurityException,
    "ErrorConditionException": ErrorConditionException,
    "ConnectionClosedException": ConnectionClosedException,
    "UNTIL_EOF": UNTIL_EOF,
    "UNTIL_TIMEOUT": UNTIL_TIMEOUT,
    "NO_READ": NO_READ
            }

from ax.transport.control_stmt_parser import parse_ctrl


RE_CACHE = {}
STATS = {}
STATS_EXTENDED = {}

class Getter(TestableTransport):
    """ A *Pretty* Parametrizable Getting Object -
            Base for All Objects in the Module """
    # can be set to a queue, for real time loggers to pick from:
    comm_log            = None
    version =           2
    # overwrite when developping a new flowhandler:
    # search this class for 'dbg_cli' to see the effect:
    dbg_cli =           ''

    # are we starting threads for communication?
    # see threaded_transport.py:
    concurrency =       None

    # here we store the customized parameters in a map
    # In the connect method for creating threaded transports
    # this is absolutely needed to parametrize the
    # threads one by one:
    settings =          None

    # custom init extension code to be loaded is here:
    init_code_uri =     None

    # models extend the functionality:
    # can be downloaded from the server, see model_support module:
    model =             None
    model_code_uri =    None

    # features like models might want to use this: cleared at connect:
    session_cache =     {}

    simulation_mode =   None

    # normally the prompt:
    condition =         None

    # what triggers us to think the server sent an error:
    error_condition =   None
    timeout =           3.0
    maxdata =           1000000

    last_transf_time =  0

    # run these before and after each flow (see flow_handling):
    pre_cmd_flow =      None
    post_cmd_flow =     None

    # autorun these commands before and after each get?:
    cmd_intro =         None
    cmd_outro =         None

    # not calling close on the connection object,
    # just put back into an object pool?
    connection_pooling = None
    poolsize =          0

    # identification of a transport
    # (with e.g. an open ssh session or DB object:
    identification =    "%s"
    ident =             None

    # ssh, telnet, http....:
    via =               None

    # a specialization of the via, which is very general.
    t_type =            None

    # holding always what was exchanged up to now:
    input_buf =         ''

    # white list for commands and arguments:
    allowed_cmds =      "^[,/\-. :A-z 0-9]+$"
    allowed_args =      "^[,/\-. :A-z 0-9]+$"
    allowed_cmd_subs =  None
    allowed_arg_subs =  None

    # do we get paginated output like __MORe__ and have to press
    # page_fwd_key:
    page_fwd = None

    # when tcpflowing in a subprocess for debugging:
    flow_capt_proc_id = 0


    def __enter__(self):
        return self

    def __exit__(self, type, value, traceback):
        try:
            self.close()
        except:
            pass


    def info(self, with_values=None, fmt=None):
        """ only show our member vars, not from parents """
        return obj_members(self, direct_only=1,
                with_values=with_values, fmt=fmt)
    help = info

    def full_info(self, with_values=None, fmt=None):
        return obj_members(self, direct_only=0,
                with_values=with_values, fmt=fmt)


    def setup(self, settings, **kwargs):
        for k, v in settings.items():
            setattr(self, k, v)
        if 'timeout' in settings:
            self.timeout = float(self.timeout)
        if 'port' in settings:
            self.port = int(self.port)

        self.session_cache = {}
        #  remember the parametrization also, for example for the threaded setup
        self.settings = settings
        # run custom init code, e.g. turning this generic socket
        # transporter into a cisco talking thingy
        if self.init_code_uri:
            load_uri_with_env(self.init_code_uri, self, MODELS)

        if not self.model:
            #FIXME: this is a tr-069 style one, we are further meanhile
            # -> omit if not specified
            self.model = 'axiros.static'
        self.model_name = self.model
        from ax.transport.model.model_support import MODELS, load_model
        load_model(self)

        if 'testmode' in settings and self.testmode:
            self.set_testmode(settings)

        #  set the ident matching the settings:
        self.get_ident()
        if self.simulation_mode:
            setup_simulation_mode(self)

        logger.debug( "have set up %s with %s", self, settings)

    def communicate(self, *args, **kwargs):
        """called by 'get' - after all the extension work is done.
        overwrite ! """
        raise NotImplementedError

    def before_get(self):
        """ descendants could autoconnect here """

    def explore(self):
        """ overwrite for specific implementations"""
        raise NotImplementedError




    # ------------------------------------------------------------- Main Method

    def get(self, cmd, condition=None, error_condition=None,
            timeout=None, **kwargs):
        """
        Main entry point into axpand when having a parametrized
        transport object at hand for running an interaction.
        Autoconnects if the transport is a connecting one.

        $cmd: Transport specific command to send over.
        If starting with a '/' it's a control switch.
        See parse_ctrl method.

        $condition: What are we waiting for from the other side.
        Typically a prompt like thing.

        $error_condition: When do we assume the other side does
        not like what we sent. We raise ErrorConditionException
        then.

        $timeout: How long to wait for the other side

        $**kwargs: Transport specific arbitrary parameters to
        parametrize a communication flow.
        """
        if self.comm_log:
            msg = cmd
            if kwargs:
                msg = '%s %s' % (cmd, kwargs)
            self.comm_log.put('<%s\t%s\t%s' % (time(), self, msg))


        if logger.level:
            # DEBUG is 10:
            #FIXME: check must be per handler:
            if logger.level < 11:
                logger.debug("get: cmd: %s, condition: %s, error_condition: %s,"
                        "timeout: %s, kwargs: %s",
                        cmd, condition, error_condition, timeout, kwargs)
            else:
                logger.info("get called: %s", cmd)

        if self.cmd_intro:
            self.cmd_intro()

        self.last_transf_time = time.time()

        if cmd is None:
            cmd = '/WAIT'

        do_ret =  wait = noerr = None
        if '%(' in cmd and not cmd.startswith('/SET'):
            # see __getitem__ function in this class.
            # one could specify a whole microflow as a
            # variable as well ;-)
            # /SET is not replaced, we want to be able
            # to add 'templates', which are only replaced
            # at 'runtime', i.e. when we really send it
            # as cmd:
            try:
                cmd = cmd % self
            except Exception:
                # there might be cmd_args given, we check
                # later
                pass

        if cmd.startswith('/'):
            cmd, do_ret, wait, noerr = parse_ctrl(
                    self, cmd, condition, error_condition, timeout, **kwargs)
            if do_ret is not None:
                if self.comm_log:
                    self.comm_log.put('>%s\t%s\t%s' % (time(), self, do_ret))
                return do_ret

        if condition is None:
            condition = self.condition
        if error_condition is None:
            error_condition = self.error_condition
        if timeout is None:
            timeout = self.timeout


        # see def __getitem__ above:
        if condition and '%(' in condition:
            condition = condition % self

        if noerr:
            # we just don't check for server errors, the cmd itself has to take
            # care to get into proper until matching w/o timeouts:
            # clients can check for None or this:
            error_condition = ''
        # run after_get in any case:
        try:
            # catch exceptions and close then self:
            try:
                cmd_args = kwargs.get('cmd_args')
                if cmd_args and '%(' in cmd:
                    cmd = cmd % cmd_args
                self.check_args(cmd, **kwargs)


                if self.dbg_cli and START_PDB_ON_GET in self.dbg_cli:
                    print "-" * 70
                    print """Debug/CLI mode is on - stopping at every 'get' method,
                            just before sending the command.
                    Step trough it using n and then hit c"""
                    print "Current input buffer..............."
                    print self.input_buf
                    print "..................................."
                    print "cmd is %s" % cmd
                    print "condition is %s" % condition
                    print "error condition is %s" % error_condition
                    print "timeout is %s" % timeout
                    print "(you can change all variables now)"
                    print "-" * 70
                    # don't remove the trace - it's a feature!
                    print
                    import pdb; pdb.set_trace()

                # the conn_obj might have been specified:
                conn_obj = kwargs.get('conn_obj')
                if conn_obj:
                    del kwargs['conn_obj']
                else:
                    conn_obj = self.get_connection_obj()

                if cmd.startswith('model.'):
                    from ax.transport.model.model_support import model_call
                    ret = model_call(self, cmd, timeout, condition, error_condition, **kwargs)
                else:
                    ret = self.communicate(cmd, conn_obj, condition,
                                error_condition, timeout, **kwargs)

                    if logger.level <= logging.DEBUG:
                        ppstr = str(ret)
                        logger.debug("comm. result: %s" % \
                        (ppstr[:1000] + (ppstr[1000:] and '...(output truncated)')))
                if self.comm_log:
                    self.comm_log.put('>%s\t%s\t%s' % (time(), self, ret))
                return ret

            except UnauthorizedException, ex:
                self.handle_get_exception(ex, cmd = cmd, args = kwargs)
        finally:
            self.after_get()

    def get_connection_obj(self):
        """ overwritten by connected transports """
        return None

    def __repr__(self):
        if self.ident:
            return self.ident
        # ident comes in setup:
        return '%s.%s (not parametrized)' % (self.__module__, self.__class__)


    def __getitem__(self, key):
        # that's the key for the ability to supply cmds like:
        # get("%(enable_password)s") if we have that variable set here:
        return self.__getattribute__(key)


    def check_args(self, cmd, **kwargs):
        """ template replacement is used """
        if self.allowed_cmds:
            if not isinstance(cmd, (str, unicode)):
                raise ValueError("Need cmd type str but got: %s" % cmd)
            # if those are set additionally remove them of
            # the checked set:
            if self.allowed_cmd_subs:
                for allow in self.allowed_cmd_subs.split(','):
                    cmd = cmd.replace(allow.strip(), '')
            re_allowed = RE_CACHE.get(self.allowed_cmds) or \
                    RE_CACHE.setdefault(self.allowed_cmds,
                    re.compile(self.allowed_cmds))
            if not re_allowed.search(cmd) and not cmd == '':
                raise SecurityException("cmd %s not allowed using %s" %
                        (cmd, self.allowed_cmds))

        if not kwargs or not self.allowed_args:
            return

        re_allowed = RE_CACHE.get(self.allowed_args) or \
                RE_CACHE.setdefault(self.allowed_args,\
                re.compile(self.allowed_args))
        for k, v in kwargs.items():
            # cmd_args not checked, they are already in cmd
            if k == 'cmd_args' or k == 'fmt':
                continue
            v = str(v)
            if self.allowed_arg_subs:
                # like with cmds:
                for allow in self.allowed_arg_subs.split(','):
                    v = v.replace(allow.strip(), '')
                if not re_allowed.search(v) and not v == '':
                    raise SecurityException \
                        ("argument %s not allowed using %s"\
                        % (str(v), self.allowed_args))


    def after_get(self):
        self.last_transf_time = time.time()


    def clear (self):
        """ clear the input buffer"""
        self.input_buf = ''
        self.session_cache = {}


    def get_ident(self):
        """ Every transport pooled via this class
        has to supply its connection characteristics as a string
        like: 'ssh://admin@127.0.0.1:22' - then we can reuse the connection.
        """
        if not self.ident:
            self.ident = get_ident(self)
        return self.ident


    def handle_get_exception(self, ex, **kwargs):
        """ called also from the connected transport, where we close"""
        logger.exception(ex, kwargs)
        raise ex


    #---- tools:
    def nice_log(self, res):
        if not res: return
        res = str(res)
        if len(res) > 40:
            res = '%s...%s' % (res[:20], res[-20:])
        return '%s' % res.replace('\r', ' ').replace('\n', ' ')
   # --- end tools




class SenderReceiver(Getter):
    """ Objects where send and receive is a separated thing
    Typically anything which works with pipes and sockets directly
    """
    def communicate(self, cmd, conn_obj, condition, error_condition,
            timeout, **kwargs):

        if not cmd == '/WAIT':
            # send over:
            self.run_command(cmd, conn_obj)

        if condition == '':
            condition = '/NOREAD'

        elif condition is None:
            raise Exception, "condition neither set nor given for cmd %s" % cmd

        res = self.receive_until_condition (conn_obj, condition,
                error_condition, timeout, **kwargs)
        return res

    def receive_until_condition(self, conn_obj, condition, error_condition,
            timeout, **kwargs):
        """ The standard way of receiving something, if we are not an application
            aware (i.e. layer 5) receiver.

            First creates objects out of the conditions, then reads from the server.
            Reads until calling condition_obj() returns something that is true.
            $condition_obj() will be given all *args and **kwargs that this method
            received in addition to its own arguments. The first parameter,
            however, is the newly read data.
            Reading is aborted with an exception in the following cases:
                1. More than $timeout seconds have passed
                        -> TimeoutException
                2. More than $maxdata bytes were read
                        -> TooMuchDataException
                3. The connection was closed by the other side
                        -> ConnectionClosedException

            Regardless of potential exceptions, all data that was read is
            appended to self.input_buf. The _newly_ read data is also the return
            value if the method returns normally.

            Note that $condition_obj() gets only the newly read data. If you care
            about self.input_buf, do it yourself.

            In cases where you do not want one of the conditions to become
            effective you can
                - set $condition to None, this will never match.
                - set $timeout or $maxdata to 2**64, this value should be
                    high enough so that they never match. Use at your own risk!
            At least the first case is useful, e.g. when you just want to read
            what somebody has to say, regardless of what it is.

        """
        maxdata = kwargs.get('maxdata')
        if maxdata == None:
            # if 0 we don't check it:
            maxdata = self.maxdata

        cur_timeout = timeout
        condition_obj, meta_terminator = build_condition_object (condition)

        error_condition_obj = None
        if error_condition:
            error_condition_obj, err_meta_terminator = build_condition_object(
                    error_condition)

        start = time.time()
        data = ""
        success_data = None

        while 1:
            try:
                if condition == '/NOREAD':
                    return ''
                new_data = self.read(cur_timeout, max(self.maxdata,
                                            maxdata - len(data)), conn_obj)

                data += new_data

            except TimeoutException:
                self.input_buf += data
                # we MUST throw the timeout exception and not connection close
                # if the server takes too long to answer due to being busy (?)
                # client has to handle that:
                if meta_terminator and  "/TIMEOUT" in meta_terminator:
                    return data
                # no, we don't close the connection when there is a timeout:
                raise TimeoutException()

            except Exception, ex:
                # Don't want to handle the exception here, but the API promises
                # we append $data that was received even in case of error.
                self.input_buf += data
                if meta_terminator and  "/EOF" in meta_terminator:
                    # all expected:
                    return data
                raise ConnectionClosedException(str(ex))

            if check_condition(data, condition_obj, **kwargs):
                # success - NO! we must first check if there was maybe
                # a error reported from ther server before we hooray:
                if self.page_fwd and self.page_fwd in data:
                    # don't find it again next time:
                    data = data.replace(self.page_fwd, '')
                    self.send_data(' ', conn_obj)
                    continue
                success_data = data

            if  error_condition_obj and \
                    check_condition(data, error_condition_obj, **kwargs):
                # Even in error cases, the API promises we append
                # the data we read.
                self.input_buf += data
                raise ErrorConditionException('data: %s' %  data)

            if len(data) >= maxdata and maxdata:
                # Already received as much as allowed and still condition()
                # is not happy. The len(data)>maxdata should never
                # happen since we limit the amount when receiving, but
                # better be safe than sorry.
                self.input_buf += data
                raise TooMuchDataException()

            if success_data is not None:
                #hooray:
                self.input_buf += data
                return success_data

            # Have we spent more than $timeout seconds already?
            # Did we already get $maxdata bytes? Do these calculations
            # after self.read() because in many cases we probably never
            # get down here -> save CPU time.
            time_spent = time.time() - start
            cur_timeout = timeout - time_spent
            if cur_timeout < 0:
                self.input_buf += data
                if meta_terminator and  "/TIMEOUT" in meta_terminator:
                    # all expected:
                    return data
                # no connection close !
                raise TimeoutException()


    def sanitize_input(self):
        """Merges/converts newlines and removes non-printables in self.input_buf
            The following modifications are made in the given order:
            Remove non-printables: All characters with ASCII values <32 or
                >126 are removed, with the exception of \n. Note that this
                includes tabs.
            Newline conversion: \n, \r, \n\r and \r\n are
                converted to \n. Note that these have the ASCII values
                \n=0x0A and \r=0x0D.
            Newline merging: Consecutive "\n"s are merged to a single "\n"
        """
        # TODO: This can be done here in the main class. Just needs doing.
        raise NotImplementedError




def get_ident(transport, settings_map=None):
    if transport.ident:
        return transport.ident
    # we use the settings from the object:
    if not settings_map:
        settings_map = transport

    configuration_ident = transport.identification % settings_map
    via = settings_map['via']
    return '%s (%s)' % (configuration_ident, via)


