"""Implementation of a layer 5 Telnetter using python's telnetlib.

Using the "use_gevent" property, you can get a version that is safe for use in
greenlets.
"""
from ax.transport.base import ConnectionClosedException, TimeoutException, \
        TooMuchDataException, ErrorConditionException
from ax.transport.connected_transport import ConnectedGetter
from ax.utils.formatting.pretty_print import repl_unprintable
from ax.transport.condition_checking import parse_condition
from ax.transport.condition_checking import check_condition
from time import sleep, time
import logging
logger = logging.getLogger( __name__)
class PyTelnetLib(ConnectedGetter):
    """
    Implementation of a **LAYER 5*** Telnetter using python's telnetlib
    Layer 5 means: This can ONLY do
    RFC 854: TELNET Protocol Specification
    and not raw socket communication - use the pysock_telnetter for this
    """
    identification =  "PTL://%(host)s:%(port)s/"
    # looks like a reasonable default:
    port = 23
    host = '127.0.0.1'
    # the default for most boxes is like that:
    newline = '\r\n'
    maxdata = 1000000
    user = ''
    password = ''
    condition = '$ '
    use_gevent = False


    def open_connection (self):
        self.my_newline = self.newline
        if '\\n' in self.newline:
            self.my_newline = self.newline.replace('\\n', '\n').replace('\\r', '\r')
        try:
            if self.use_gevent:
                from ax.utils.gevent_utils.green_telnetlib import Telnet
            else:
                from telnetlib import Telnet
            t = Telnet(self.host, int(self.port), self.timeout)
        except Exception, ex:
            msg = 'Error opening Telnet socket: %s' % ex
            logger.exception(msg)
            raise ConnectionClosedException(msg)
        return t



    def read_human(self):
        """ try act 'human', i.e. read until nothin
        happens """
        t = self._conn_obj
        ret = ''
        res = 1
        while res:
            res = t.read_until(' ', self.timeout)
            ret += res
        return ret

    def explore(self):
        ret = ''

        cmds = ('try',)
        for i in xrange(100):
            cmds += ('try%s' % i,)

        self._conn_obj.close()
        sleep(0.1)
        self.connect()
        sleep(0.1)
        t = self._conn_obj
        commlog = []
        ret += '-> %s\n' % self.read_human()
        for k in cmds:
            k = getattr(self, k, '')
            if not k: continue
            k = repl_unprintable(k)
            t.write(k)
            ret += '<- %s\n' % k
            ret += '-> %s\n' % self.read_human()
        return ret


    def communicate(self, cmd, conn_obj, condition, err_con, timeout, **kwargs):
        if not cmd == '/WAIT':
            self.send_data(cmd + self.my_newline, conn_obj)

        if not condition or condition == '/NOREAD':
            return ''

        maxdata = kwargs.get('maxdata', self.maxdata)
        # this has a cache, faster than it looks:
        cmap = parse_condition(condition)
        (plain_term, plain_val, regexp_terminator, meta_terminator) = (
                cmap.get('plain'),
                cmap.get('plain_value'),
                cmap.get('regexp'),
                cmap.get('meta', '')
                )

        # handle the most common case *fast*:
        # NOTE: the libraries' read_until would match for 'in', 'starts' and
        # 'ends',
        # all return values would lead to a match!
        ok_matches = 0
        if plain_term == plain_val and not regexp_terminator and not err_con:
            # no /Z and /A (plain_term == plain_val):
            # do a library read_until:
            term = plain_term
        else:
            # will do a library.expect:
            term = []
            if plain_term:
                term.append(self.re_escape(plain_val.split('|', 1)[0]))

            if regexp_terminator:
                term.append(regexp_terminator)

            if err_con:
                cmap = parse_condition (err_con)
                plain_err_terminator, regexp_err_terminator = \
                        cmap.get('plain'), cmap.get('regexp')
                # we have to insert the error conditions *first* in order to see
                # by the index of the match if it _was_ an error:
                if plain_err_terminator:
                    term.insert(0, self.re_escape(plain_err_terminator))
                    ok_matches = 1
                if regexp_err_terminator:
                    term.insert(0, regexp_err_terminator)
                    ok_matches = 2

        #if 'servererr' in cmd and ok_matches != 0:
        res = self.read_until(term, ok_matches=ok_matches, timeout=timeout,
                meta=meta_terminator, maxdata=maxdata, conn_obj=conn_obj)
        return res



    def re_escape(self, s):
        """ escape the special strings like $ given in plain strings """
        for c in '.^$*+?{}[]|()':
            s = s.replace(c, '\\' + c)
        s = s.replace('/Z', '\Z').replace('/A', '\A')
        return s

    def send_data(self, data, conn_obj):
        try:
            conn_obj.write(data)
        except Exception, exc:
            msg = "Exception while trying to send: %s" % exc
            logger.exception(msg)
            raise ConnectionClosedException(msg)


    def read_until (self, terminator, ok_matches, timeout,
                          maxdata, meta, conn_obj):
        """
        we must find timeouts via looking at the clock, since there is no
        EOF error thrown by expect even if there is a server close when there
        was data before
        """
        index = -2
        ts = time()
        data = ''
        try:
            if type(terminator) in (str, unicode):
                data = conn_obj.read_until(terminator, timeout)
            else:
                index, match, data = conn_obj.expect(terminator, timeout)
                if index != -1 and index < ok_matches:
                    self.input_buf += data
                    raise ErrorConditionException('data: %s' %  data)

            self.input_buf += data

            if time() -ts > timeout:
                self.input_buf += data
                if '/TIMEOUT' in meta:
                    return data
                raise TimeoutException

            if len(data) >= maxdata and maxdata:
                raise TooMuchDataException

            if index == -1 or (index == -2 and not terminator in data):
                raise EOFError (
                        'terminator not found, no timeout - assuming EOF')

            return data

        except EOFError, exc:
            # analogue to the other transports in transport.py:
            self.input_buf += data
            if '/EOF' in meta or '/TIMEOUT' in meta:
                return data
            # will be done by the caller, in get:
            #self.close()
            raise ConnectionClosedException('Got EOFError: %s' % exc)

