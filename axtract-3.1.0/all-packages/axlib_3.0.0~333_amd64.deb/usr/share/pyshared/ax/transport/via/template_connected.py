""" Template for a connected transport """
import logging
from ax.transport.base import \
        ErrorConditionException, ConnectionClosedException,\
        TransportException
from ax.transport.connected_transport import ConnectedGetter
from ax.utils.formatting.html import rewrite_links, neutralize_script_tags


logger = logging.getLogger( __name__)

class YourTransport(ConnectedGetter):
    """
    A template for a transport
    """
    # variables:
    allowed_args = None
    allowed_cmds = None
    host = None
    identification =  "%(host)s"
    user = None
    password = None

    def open_connection (self):
        # this must return your connection object, i.e. 
        # the telnet object, the httpconnection, the ssh 
        # connection or whatever. The Session.
        # it usually has an open and close method.
        # open it here, using your params
        conn_obj = somelib.session(self.host, self.user)
        return conn_obj

    def communicate(self, cmd, conn_obj, condition,\
            error_condition, timeout, **kwargs):
        # entry point for communication:
        # understand the specific commands here.
        if cmd == 'walk':
            start_node = kwargs['start_node']
            return {'tree': None}

    # supply this if your connection object does NOT understand
    # a close method to close it. 
    # Example:
    def close_connection(self, conn_obj = None):
        """ this method may never except! """
        conn_obj = conn_obj or self.get_connection_obj()
        try:
            conn_obj.terminate(force=True)
        except Exception, exc:
            raise ConnectionClosedException(
                    "Exception while closing: %s" % exc)
        finally:
            del conn_obj



