from ax.utils.parsing.parse_text import get_line_val, parse_timestr
import re
from netaddr.core import AddrFormatError
from time import strftime
from binascii import hexlify
from netaddr import IPAddress as IP
from netaddr import IPNetwork, EUI
from ax.transport.model.misc import get_error_line
from ax.transport.model.misc import put
from ax.transport.model.misc import warn
from ax.transport.model.misc import safe_cli_get
from ax.transport.model.misc import handle_Upload, handle_Download

from ax.transport.model.keyval import handle_SPV, handle_GPN
from ax.transport.model.keyval import set_flow, SPVException
from ax.transport.model.keyval import depends, lines, indizes
from ax.utils.parsing.parse_text import get_indent_chars, get_line, rem


IOS_TYPE7_KEY = "dsfd;kfoA,.iyewrkldJKDHSUBsgvca69834ncxv9873254k;fg87"

class IOSParser(object):
    def init(self, t):
        c = t.session_cache
        if not 'issues' in c:
            self._init(t)
        return c, c['show run'], c['issues']

    def _init(self, t):
        """ parsing pres you don't want to run > 1 """
        c = t.session_cache
        run = depends('show run', t)
        lines = run.splitlines()
        # this sets
        c['indent_chars'] = get_indent_chars(lines)
        c['issues'] = c.get('issues', [])

    def heartbeat(self, t):
        t.get('term len 0')
        return 1

    def set_stats(self, c, tr, m, if_type=None):
        tr = tr + 'Stats.'
        put(c, tr, 'BytesSent', m, 'tx_bytes')
        put(c, tr, 'BytesReceived', m, 'rx_bytes')
        put(c, tr, 'PacketsSent', m, 'tx_packets')
        put(c, tr, 'PacketsReceived', m, 'rx_packets')
        put(c, tr, 'ErrorsSent', m, 'tx_errors')
        put(c, tr, 'ErrorsReceived', m, 'rx_errors')
        put(c, tr, 'DiscardPacketsSent', m, 'tx_dropped')
        put(c, tr, 'DiscardPacketsReceived', m, 'rx_dropped')
        put(c, tr, 'BroadcastPacketsReceived', m, 'rx_broadcasts')
        put(c, tr, 'BroadcastPacketsSent', m, 'tx_broadcasts')
        c[tr + 'MulticastPacketsReceived'] = 0
        c[tr + 'MulticastPacketsSent'] = 0
        packets = 'Packets'
        if if_type == 'Dot11Radio':
            packets = 'TotalPackets'
        try:
            c[tr + 'UnicastPacketsSent'] = \
                    c[tr + packets + 'Sent'] - \
                    c[tr + 'BroadcastPacketsSent']
        except:
            pass
        try:
            c[tr + 'UnicastPacketsReceived'] = \
                    c[tr + packets + 'Received'] - \
                    c[tr + 'BroadcastPacketsReceived']
        except:
            pass
        put(c, tr, 'UnknownProtoPacketsReceived', m, 'ignored')
        put(c, tr, 'DiscardPacketsReceived', m)
        put(c, tr, 'DiscardPacketsSent', m)



    def is_upstream(self, m, c):
        """ if the name of the IF is in def_gw_if or the gw ip is in th network
        we say this is Upstream """
        if m.get('Name', 'xx') in c['def_gw_if']:
            return True
        ip, mask = m.get('IP'), m.get('Netmask')
        if not ip or not mask:
            return False
        gw = c.get('def_gw_ip')
        if not gw or gw == 'n.a.':
            return False
        if IP(gw) in IPNetwork('%s/%s' % (ip, mask)):
            return True
        return False

    def parse_default_gw(self, c, def_route):
        c['def_gw_ip'] = get_line_val(def_route.lower(), 'default gateway is ')
        c['def_gw_if'] = get_line_val(def_route, 'directly connected, via ')




    def parse_clock(self, t):
        ret = depends('show clock', t).replace('*', '')
        if not ret:
            return ''
        ret = ret.replace('show clock', '').strip().split('\n')[0].strip().split()
        t.session_cache['.Time.LocalTimeZoneName'] = ret[1]
        # FIXME must be IEEE 1003.1:
        t.session_cache['.Time.LocalTimeZone'] = ret[1]
        # strange timezones replacement: FIXME
        if ret[0].startswith('.'):
            # mm: we saw a strange output from some devices
            # p ret
            # ['.15:57:27.456', 'Roma', 'Thu', 'Mar', '7', '2013']
            ret[0] = ret[0][1:]
        ret[1] = 'CET'
        ret = ' '.join(ret)
        if ret[8] == '.':
            ret = ret[0:8] + ret[12:]
        ret = parse_timestr(ret, '%H:%M:%S %Z %a %b %d %Y')
        return ret


    def parse_run_blocks(self, match, run, start_match=0):
        if start_match:
            fmatch = '\n%s' % match
        else:
            fmatch = match
        blocks = run.split(fmatch)[1:]
        res = []
        for b in blocks:
            res.append(self.parse_run_block(match,
                        '\n' + match + b))
        return res

    def runsplit(self, t):
        run = depends('show run', t)
        return run.splitlines()

    def parse_run_block(self, match, run):
        """
        Deliver a block from a running config.
        run is a string, then we look in it or t then we get show run,
        incl. splitting from the chache
        Note: we accept also t as 'run' argument!
        """
        ret = ''
        inblock = 0
        if isinstance(run, (str, unicode)):
            lines = run.splitlines()
        else:
            # 'run' is t then, so:
            lines = depends('runsplit', run)

        for line in lines:
            if line.startswith('!'):
                continue
            if not line.startswith(' '):
                if inblock:
                    # we are out:
                    return ret
                else:
                    if not match in line:
                        continue
                    ret += line + '\n'
                    inblock = 1
            else:
                if inblock:
                    ret += line + '\n'
        return ret


    def set_nfos_run_blocks(self, nfos, t):
        """ adds the run_cfg statements into nfos iface maps"""
        for iface, nmap in nfos.items():
            nfos[iface]['runcfg'] = self.parse_run_block('interface %s' % iface, t)

    def show_run(self, t):
        res = safe_cli_get(t, 'show run', 30)
        return res.split('!', 1)[1].strip()


    def show_startup(self, t):
        res = safe_cli_get(t, 'show startup-config')
        return res.split('!', 1)[1].strip()



    def show_ip_int(self, t):
        """
        Main interfaces parser.
        Build a map(nfos) of Iface names versus their properties.
        Then build the TR params out of it.

        """
        c = t.session_cache
        # we will split below, delete the space in the column:
        # simul:

        interfaces = depends('show interface', t)
        def_route  = depends('show ip route 0.0.0.0', t)
        ip_brief   = depends('show ip int brief', t)

        self.parse_default_gw(c, def_route)
        # ip int | inc line | Internet address')

        ifs = {
            'ATM':            [],
            'Dialer':         [],
            'Vlan':           [],
            'Tunnel':         [],
            'Dot11Radio':     [],
            'FastEthernet':   [],
            'Ethernet':       [],
            'BVI':            [],
            'GigabitEthernet':[],
            'Virtual-Access': [],
            'Serial'        : []
              }
        nfos = {}
        run = depends('show_run', t)

        # first parse results into mappings:
        #import pdb; pdb.set_trace()
        valid = False
        if_name = "";
        for line in lines(interfaces):
            #search for interface information
            if not line.startswith(' ') and line.strip():
                valid = False
                if_name = line.split(' ', 1)[0]
                # check if name is valid:
                for if_type in ifs:
                    if line.startswith(if_type):
                        valid = True
                        ifs[if_type].append(if_name)
                        if_map = {'Name': if_name,
                                  'Duplex': 'Auto',
                                  'Speed': 'Auto'}
                        nfos[if_name] = if_map
                        if_map['Status'] = 0
                        if_map['Enable'] = True
                        if 'is up' in line:
                            if_map['Status'] = 1
                        if 'down' in line:
                            if_map['LinkStatus'] = 0
                        if 'administratively down' in line:
                            if_map['Enable'] = False
                        break

                continue
            elif valid:  # interface found
                line = line.strip().lower()
                #print line, "-" * 100
                if line.startswith('internet address is '):
                    ip = IPNetwork(line.rsplit(' ', 1)[1])
                    if_map['IP'], if_map['Netmask'] = str(ip.ip), str(ip.netmask)
                elif 'uplex' in line:
                    if 'half' in line:
                        if_map['Duplex'] = 'Half'
                    else:
                        if_map['Duplex'] = 'Full'
                    # this parsing rule seems bound to break:
                    try:
                        if_map['Speed'] = get_line_val(line, ' ', sep='mb/s', get=0)
                    except:
                        if_map['Speed'] = 0
                elif 'mtu ' in line and ' bw ' in line:

                    try:
                        if_map['mtu'] = int(line.split('mtu ', 1)[1].split(' ')[0])
                        if_map['bw_kb'] = int(line.split(' kbit/sec')[0].\
                                rsplit(' ', 1)[1])
                    except:
                        if_map['bw_kb'] = 0

                elif line.startswith('hardware is'):
                    if line.find("address is "):
                        # if this is a real IF we have the mac in this line:
                        try:
                          if_map['MAC'] = str(EUI(get_line_val(line,
                            'address is ',
                            sep=' ',
                            get=0))).replace('-', ':')
                        except AddrFormatError, ex:
                            if_map['MAC'] = ''
                elif line.find('packets input,') > 0:
                    stat = line.split()
                    if_map['rx_bytes'] = int(stat[3])
                    if_map['rx_packets'] = int(stat[0])
                elif ' broadcasts,' in line and 'received ' in line:
                    stat = line.split()
                    if_map['rx_broadcasts'] = int(stat[1])
                    # no info:
                    if_map['tx_broadcasts'] = 0
                elif 'maximum active vcs,' in line:
                    stat = line.split()
                    if_map['max_vcs'] = int(stat[0])
                    if_map['cur_vcs'] = int(stat[-3])
                elif line.find('packets output,') > 0:
                    stat = line.split()
                    if_map['tx_bytes'] = int(stat[3])
                    if_map['tx_packets'] = int(stat[0])
                elif line.find('input errors') > 0:
                    stat = line.split()
                    if_map['rx_errors'] = int(stat[0])
                    if_map['ignored'] = int(stat[-2])
                elif line.find('output errors') > 0:
                    stat = line.split()
                    if_map['tx_errors'] = int(stat[0])

                elif 'input queue' in line:
                    stat = line.split()
                    # 0/75/0/0 (size/max/drops/flushes):
                    smdf = stat[2].split('/')[2]
                    if_map['DiscardPacketsReceived'] = int(smdf)
                    if_map['DiscardPacketsSent'] = int(stat[-1])
                elif 'encapsulation' in line:
                    if_map['Encapsulation'] = line.split()[1]


            else:
                pass

        self.set_nfos_run_blocks(nfos, t)
        for iface, nmap in nfos.items():
            # get secondary IP:
            i_cfg = nmap.get('runcfg')
            if not 'secondary' in i_cfg:
                continue
            for line in i_cfg.splitlines():
                try:
                    if 'ip address ' in line and 'secondary' in line:
                        nmap['IPSecondary'], nmap['NetmaskSecondary'] \
                        = line.split('ip address ')[1].split(' secondary')[0].split()
                        break
                except:
                    pass


        arp = depends('show arp', t)

        c['ifs']  = ifs
        c['nfos'] = nfos


        return [ifs, nfos, ip_brief, arp]

    def encrypt7(self, secret):
        """Cisco Type 7 password encryption.
        """
        def join_byte_values(values):
            return ''.join(chr(v) for v in values)

        if isinstance(secret, unicode):
            secret = secret.encode("utf-8")
        # looks broken but works:
        key = IOS_TYPE7_KEY.decode("unicode_escape")
        key_size = len(key)
        cipher = join_byte_values(
            value ^ ord(key[(1 + idx) % key_size])
            for idx, value in enumerate(ord(c) for c in secret)
        )
        checksum = hexlify(cipher).decode("ascii").upper()
        return "%02d%s" % (1, checksum.encode("ascii"))

    def decrypt7(self, ep):
        """Cisco Type 7 password decryption.
        """
        decrypt=lambda x:''.join([chr(int(x[i:i+2],
                16)^ord(IOS_TYPE7_KEY[(int(x[:2])+i/2-1)%53]))for i in range(2,
                                    len(x),2)])
        try:
            passp = decrypt(ep)
        except Exception:
            #password decryption failed
            passp = ''
        return passp



    def parse_vlan_blocks(self, t):
        c, run, issues = self.init(t)
        vms = {}
        vlan_blocks = self.parse_run_blocks('vlan ', run, start_match=1)
        for block in vlan_blocks:
            header = block.splitlines()[0]
            vid = header.split(' ', 1)[1]
            vms[vid] = {}
            name = get_line_val(block, ' name ')
            if not name == 'n.a.':
                vms[vid]['name'] = name
        c['vlans'] = vms
        return vms

    def parse_policy_blocks(self, t):
        c, run, issues = self.init(t)
        pms = {}
        policy_blocks = self.parse_run_blocks('policy-map ', run, start_match=1)
        for block in policy_blocks:
            pid = block.splitlines()[0].split()[1]
            pm = {}
            pms[pid] = pm
            class_blocks = self.parse_run_blocks('class ', block)
            for cblock in class_blocks:
                id = cblock.splitlines()[0].split()[-1]
                m = {}
                pm[id] = m
                if not 'police ' in cblock:
                    continue
                pl = get_line('police ', cblock)
                try:
                    pls = rem(pl, (' cir', ' bc'))
                    pls = pls.split()
                    m['bw'], m['burst'] = int(pls[-2]), int(pls[-1])
                except:
                    issues.append("Can't parse %s in class %s of %s'" % \
                                  (pl, id, pid))
        c['policy-maps'] = pms
        return pms

    def get_in_range(self, r_dict, key):
        """ are we in a vlan range like '3771,4000-4001,4005' """
        if not str(key).isdigit():
            return None, None
        ikey = int(key)
        skey = str(key)
        for k in r_dict:
            for range in k.split(','):
                range = range.strip()
                if range.isdigit():
                    if range == skey:
                        return r_dict[k], range
                if '-' in range:
                    min, max=range.split('-')
                    if int(min)<=ikey and ikey<=int(max):
                        return r_dict[k], range
        return None, None


    def parse_interface_blocks(self, t, match=''):
        c, run, issues = self.init(t)
        ims = {}
        ifs_brief = depends('show ip int brief', t)
        # there may be more than one space to indent, check only once,->store:
        # also for other methods:
        ic = c['indent_chars']
        for line in ifs_brief.splitlines():
            if not (' up ' in line or ' down ' in line) or not match in line:
                continue
            iface = line.split()[0]
            m = {}
            ims[iface] = m
            iface_cfg = self.parse_run_block('interface %s' % iface, run)
            for line in iface_cfg.splitlines():
                line_l = line.lower()
                if line_l.startswith(ic + 'description '):
                    m['descr'] = rem(line, 'description').strip()
                elif line_l.startswith(ic + 'bandwidth '):
                    try:
                        m['bw'] = int(line_l.split()[1])
                    except:
                        m['bw'] = 0
                        issues.append("Can't parse bandwidth in %s of %s" % \
                                      (line, iface))
                elif line_l.startswith(ic + 'speed '):
                    m['speed'] = line_l.split()[1]
                elif 'service instance' in line_l:
                    sis = self.parse_svc_instance_blocks(iface_cfg, iface, t)
                    m['service_instances'] = sis
                    break
        c['interfaces'] = ims
        return ims


    def parse_svc_instance_blocks(self, block, parent, t):
        """
        parse service instance blocks:

        type is 'ethernet' here, ic is the indent """
        c, run, issues = self.init(t)
        sims = {}
        # double indent here:
        ic = c['indent_chars'] * 2
        blocks = block.split('service instance ')[1:]
        for block in blocks:
            lines = block.splitlines()
            ls = lines[0].strip().split()
            try:
                id = int(ls[0])
            except:
                issues.append("%s: Can't parse service instance %s" % \
                              (parent, lines[0]))
                continue
            m = {}
            sims[id] = m
            m['descr'] = ''
            if len(ls)>1:
                m['type'] = ls[1]

            for line in lines:
                line_l = line.lower()
                if line_l.startswith(ic + 'description '):
                    descr = rem(line, 'description').strip()
                    m['descr'] = descr

                elif line_l.startswith(ic + 'service-policy input '):
                    m['input-policy'] = get_line_val(line, 'input ')
                elif line_l.startswith(ic + 'service-policy output '):
                    m['output-policy'] = get_line_val(line, 'output ')
                elif ' service-policy ' in line:
                    m['policy'] = get_line_val(line, 'policy ')

                if line_l.startswith(ic + 'bridge-domain '):
                    try:
                        m['bridge-domain'] = int(line_l.rsplit(' ', 1)[1])
                    except:
                        warn(c, "%s: Can't map vlan in %s" % (descr, line))
        return sims





# -----------  Setter Methods:

    setters = {'ip_setup': ['.IP.Interface'],
               'set_wifi'    : ['.WiFi.'],
               'set_diagnostics'    : ['.IP.Diagnostics'],
               'set_portmapping'    : ['.NAT.PortMapping.']}
    error_markers = ['Bad ', 'nvalid ', ' ncomplete ']
    exit_context = ['exit', 'end']


    def commit_on_close(self, t):
        # this takes long, do it only on close:
        t.get('copy running-config startup-config', timeout=10)

    def commit_changes(self, t):
        """ hook called after all SPVs in keyval"""
        t.get('write mem', timeout=20)
        # remove session cache
        #t.session_cache.clear()

    def extract_index_numbers(self, params, subtree):
        indexes = []
        for p in params:
            try:
                idx = int(p.replace(subtree, '').split('.')[0])
                if idx not in indexes:
                    indexes.append(idx)
            except:
                pass
        indexes.sort()
        return indexes

    def set_diagnostics(self, t):
        # we accept everything here
        # the ping command is triggered within the GPV method
        c = t.session_cache
        params = c['to_set_params']
        hsp    = c['have_set_params']
        for p in params.keys():
            hsp.append(p)

    def set_portmapping(self, t):
        show_cmd = 'show ip nat translations'
        c = t.session_cache
        params = c['to_set_params']
        hsp    = c['have_set_params']

        key0 = params.keys()[0]
        val0 = params.get(key0)
        delete_object = None
        add_object    = ''
        if val0 == 'DeleteObject':
            # ends with a '.', get index:
            delete_object = int(key0.rsplit('.', 2)[-2])

        elif val0 == 'AddObject':
            add_object = key0


        if c.get('spv_try_mode') and not add_object and not delete_object:
            # no param supported check here, we pretend superpowers ;-):
            hsp.extend(params.keys())
            return
        subtree = '.NAT.PortMapping.'

        pm_cmd = "ip nat inside source static %(proto)s %(internal_ip)s "
        pm_cmd += "%(internal_port)s %(external_ip)s %(external_port)s"
        # no caching !:
        current_config = t.get(show_cmd)
        if not '---' in current_config and not add_object:
            # we just support those...
            raise Exception('No portmappings configured')

        current_config = current_config.splitlines()
        cleaned_config = ['head']
        for cline in current_config:
            # filter out unsupported portforwards
            if cline.split()[-1] == '---':
                cleaned_config.append(cline)

        current_config = cleaned_config
        if add_object.endswith('.NAT.PortMapping.'):
            # get biggest index:
            max = 0
            for line in cleaned_config:
                try:
                    to = line.split()[1]
                    if '127.0.0.1:65' in to:
                        idx = int(to.split(':65')[1])
                        if idx > max:
                            max = idx
                except:
                    pass

            # CAUTION: we really rely on the cisco adding this pseudo forwards
            # at the end, so we always get the biggest index number pointing
            # to the new one
            max = max + 1
            t.get('conf t')
            t.get(('ip nat inside source static udp 127.0.0.1 %s '
                   '127.0.0.1 %s') % (65000 + max, 65000 + max))
            t.get('end')
            # the new one is at the end, spv will hit it:
            return len(cleaned_config)

        if delete_object:
            portmapping_indexes=[delete_object]
        else:
            portmapping_indexes = self.extract_index_numbers(params.keys(), subtree)

        for idx in portmapping_indexes:
            hsp.append('%s%s.Description' % (subtree, idx))
            hsp.append('%s%s.Interface' % (subtree, idx))
            try:
                pm_settings = current_config[idx].strip().split()
            except:
                # raise Exception here?
                continue
            # proto is an empty string for option TCP,UDP
            proto = pm_settings[0].replace('-', '')
            for i in (1, 2):
                if not ':' in pm_settings[i]:
                    pm_settings[i] += ':0'
            external_ip, external_port = pm_settings[1].split(':')
            if external_port == '0':
                external_port = ''
            internal_ip, internal_port = pm_settings[2].split(':')
            if internal_port == '0':
                internal_port  = ''
            pm_conf = {}
            pm_conf['proto'] = proto
            pm_conf['external_ip'] = external_ip
            pm_conf['external_port'] = external_port
            pm_conf['internal_ip'] = internal_ip
            pm_conf['internal_port'] = internal_port
            # remove portmapping
            if delete_object:
                # DeleteObject called, just delete entry and return
                delete_cmd = 'no %s' % pm_cmd % pm_conf
                t.get('conf t')
                t.get(delete_cmd)
                # and out:
                break

            cmd = 'no %s' % pm_cmd % pm_conf
            t.get('conf t')
            t.get(cmd)
            # recreate with values passed in SPV
            for p, v in params.items():
                if subtree + str(idx) in p:
                    if p.endswith('Protocol'):
                        if v == 'TCP,UDP': v = ''
                        pm_conf['proto'] = v
                        hsp.append(p)
                    if p.endswith('RemoteHost'):
                        pm_conf['external_ip'] = v
                        hsp.append(p)
                    if p.endswith('ExternalPort'):
                        pm_conf['external_port'] = v
                        hsp.append(p)
                    if p.endswith('InternalClient'):
                        pm_conf['internal_ip'] = v
                        hsp.append(p)
                    if p.endswith('InternalPort'):
                        pm_conf['internal_port'] = v
                        hsp.append(p)
            t.get(pm_cmd % pm_conf)
            t.get('end')




    def set_wifi(self, t):
        c = t.session_cache
        params = c['to_set_params']
        hsp    = c['have_set_params']
        for p in params:
            if p.endswith('.Channel') and p.startswith('.WiFi.Radio.'):
                if c.get('spv_try_mode'):
                    hsp.append(p)
                    continue
                iface = c[p.replace('Channel', 'Name')].split('.')[0]
                res = t.get('conf t')
                res = t.get('interface %s' % iface)
                res = t.get('channel %s' % params[p])
                res = t.get('end')
                hsp.append(p)
            elif p.endswith('.AutoChannelEnable') and \
                 p.startswith('.WiFi.Radio.'):
                if params[p] in ('True', 'true', True, 1, '1'):
                    if c.get('spv_try_mode'):
                        hsp.append(p)
                        continue
                    iface = c[p.replace('AutoChannelEnable', 'Name')]
                    iface = iface.split('.')[0]
                    res = t.get('conf t')
                    res = t.get('interface %s' % iface)
                    res = t.get('channel least-congested')
                    res = t.get('end')
                    hsp.append(p)
                elif params[p] in ('False', 'false', False, 0, '0'):
                    hsp.append(p)
            elif p.endswith('.SSID') and p.startswith('.WiFi.SSID.'):
                if c.get('spv_try_mode'):
                    hsp.append(p)
                    continue
                iface_param = p.replace('.WiFi.SSID.', '.WiFi.Radio.')
                iface = c[iface_param.replace('SSID', 'Name')]
                iface = iface.split('.')[0]
                current_ssid = c[p]
                run = depends('show_run', t)
                ret = self.parse_run_block('dot11 ssid %s' % current_ssid, run)
                lines = ret.split('\n')
                if len(current_ssid) > 0:
                    res = t.get('conf t')
                    res = t.get('no dot11 ssid %s' % current_ssid)
                    res = t.get('dot11 ssid %s' % params[p])
                    for line in lines[1:]:
                        res = t.get(line)
                    res = t.get('end')
                    res = t.get('conf t')
                    res = t.get('interface %s' % iface)
                    res = t.get('ssid %s' % params[p])
                    res = t.get('end')
                    hsp.append(p)
            elif p.endswith('.Security.WEPKey') and \
                    p.startswith('.WiFi.AccessPoint.'):
                hsp.append(p)
            elif p.endswith('.Security.KeyPassphrase') and \
                    p.startswith('.WiFi.AccessPoint.'):
                hsp.append(p)
            elif p.endswith('.Security.ModeEnabled') and \
                    p.startswith('.WiFi.AccessPoint.'):
                if c.get('spv_try_mode'):
                    hsp.append(p)
                    continue
                ssid_reference = c[p.replace('.Security.ModeEnabled', '.SSIDReference')]
                #ssid_reference is like Device.WiFi.SSID.2
                radio_ref = c[ssid_reference.replace('Device', '') + '.LowerLayers']
                #radio_ref is like Device.WiFi.Radio.2
                iface = c[radio_ref.replace('Device', '') + '.Name']
                iface = iface.split('.')[0]
                current_ssid = c[ssid_reference.replace('Device', '') + '.SSID']
                run = depends('show_run', t)
                ret = self.parse_run_block('dot11 ssid %s' % current_ssid, run)
                if len(current_ssid) == 0:
                    raise Exception("Invalid SSID found on the box")
                lines = ret.split('\n')
                mode = params[p]
                configure_vlan = ''
                for line in lines[1:]:
                    if 'vlan' in line:
                        configure_vlan = line
                        break
                commands = []
                commands.append('conf t')
                commands.append('no dot11 ssid %s' % current_ssid)
                commands.append('end')
                commands.append('conf t')
                commands.append('interface %s' % iface)
                ret = self.parse_run_block('interface %s' % iface, run)
                lines = ret.split('\n')
                for line in lines[1:]:
                    if configure_vlan in line:
                        commands.append('no %s' % line.lstrip(' '))
                commands.append('end')
                if mode == 'None':
                    commands.append('conf t')
                    commands.append('dot11 ssid %s' % current_ssid)
                    commands.append(configure_vlan)
                    commands.append('authentication open')
                    commands.append('mbssid guest-mode')
                    commands.append('end')
                elif mode in ('WEP-64', 'WEP-128',
                        'WPA-Personal', 'WPA2-Personal'):
                    commands.append('conf t')
                    commands.append('dot11 ssid %s' % current_ssid)
                    commands.append(configure_vlan)
                    commands.append('authentication open')
                    commands.append('mbssid guest-mode')
                    if mode == 'WEP-64':
                        key = params[p.replace('ModeEnabled', 'WEPKey')]
                        try:
                            int(key, 16)
                        except ValueError:
                            key = key.encode('hex')
                        key = self.encrypt7(key.decode('hex'))
                        commands.append('end')
                        commands.append('conf t')
                        commands.append('interface %s' % iface)
                        commands.append('encryption %s mode wep mandatory' % configure_vlan)
                        cmd = 'encryption %s key 1 size 40bit 7 %s transmit-key'
                        commands.append(cmd % (configure_vlan, key))
                    elif mode == 'WEP-128':
                        key = params[p.replace('ModeEnabled', 'WEPKey')]
                        try:
                            int(key, 16)
                        except ValueError:
                            key = key.encode('hex')
                        key = self.encrypt7(key.decode('hex'))
                        commands.append('end')
                        commands.append('conf t')
                        commands.append('interface %s' % iface)
                        commands.append('encryption %s mode wep mandatory' % configure_vlan)
                        cmd = 'encryption %s key 1 size 128bit 7 %s transmit-key'
                        commands.append(cmd % (configure_vlan, key))
                    elif mode == 'WPA-Personal':
                        commands.append('authentication key-management wpa')
                        key = params[p.replace('ModeEnabled', 'KeyPassphrase')]
                        commands.append('wpa-psk ascii 0 %s' % key)
                        commands.append('end')
                        commands.append('conf t')
                        commands.append('interface %s' % iface)
                        cmd = 'encryption %s mode ciphers aes-ccm tkip' % configure_vlan
                        commands.append(cmd)
                    elif mode == 'WPA2-Personal':
                        commands.append('authentication key-management wpa version 2')
                        key = params[p.replace('ModeEnabled', 'KeyPassphrase')]
                        commands.append('wpa-psk ascii 0 %s' % key)
                        commands.append('end')
                        commands.append('conf t')
                        commands.append('interface %s' % iface)
                        cmd = 'encryption %s mode ciphers aes-ccm tkip' % configure_vlan
                        commands.append(cmd)
                    commands.append('end')
                else:
                    raise Exception('Not a valid mode %s' % mode)
                commands.append('conf t')
                commands.append('interface %s' % iface)
                commands.append('ssid %s' % current_ssid)
                commands.append('end')
                for cmd in commands:
                    res = t.get(cmd)
                    if "Invalid input detected at '^' marker" in res:
                        raise SPVException('IOS command \'' + cmd + '\' failed')
                hsp.append(p)
            elif p.startswith('.WiFi.Radio.') and \
                    p.endswith('.Enable'):
                if params[p] in ('True', 'true', True, 1, '1'):
                    if c.get('spv_try_mode'):
                        hsp.append(p)
                        continue
                    iface = c[p.replace('Enable', 'Name')]
                    res = t.get('conf t')
                    res = t.get('interface %s' % iface)
                    res = t.get('no shutdown')
                    res = t.get('end')
                    c[p.replace('Enable', 'Status')] = 'Up'
                    hsp.append(p)
                elif params[p] in ('False', 'false', False, 0, '0'):
                    if c.get('spv_try_mode'):
                        hsp.append(p)
                        continue
                    iface = c[p.replace('Enable', 'Name')]
                    res = t.get('conf t')
                    res = t.get('interface %s' % iface)
                    res = t.get('shutdown')
                    res = t.get('end')
                    c[p.replace('Enable', 'Status')] = 'Down'
                    hsp.append(p)




    def ip_setup(self, t):
        # all SPV params:
        c = t.session_cache
        params = c['to_set_params']
        # get state:
        ifs, nfos, ip_brief, arp = depends('show_ip_int', t)

        # configure:
        t.get('conf t')

        # stringify SPV map:
        s_params = str(params)
        LD = 'foo'

        # check all ifs which are found (i.e. in c):
        for index in indizes(LD + 'LANEthernetInterfaceConfig.', c):
            if_node = LD + 'LANEthernetInterfaceConfig.%s.' % index
            ip_node = LD + 'LANHostConfigManagement.IPInterface.%s.' % index

            if_name = c.get(if_node + 'Name')
            if not if_name or not (if_node in s_params or ip_node in s_params):
                # iface not there or nothing to change on this one:
                continue

            t.get('interface %s' % if_name)
            # enable?
            key = if_node + 'Enable'
            v = params.get(key)
            set_map = {'c': c,
                       't': t,
                       'error_markers' : self.error_markers,
                       'ctx_exit': self.exit_context
                       }

            if v != None:
                # enable param set to a value. run the cmd:
                set_map['affects_params'] = key
                if str(v) == '1':
                    set_map['flow'] = 'no shutdown'
                else:
                    set_map['flow'] = 'shutdown'
                set_flow(set_map)

            # ip setup with ip address and netmask?
            ip_key =  ip_node + 'IPInterfaceIPAddress'
            net_key = ip_node + 'IPInterfaceSubnetMask'

            if ip_key in s_params or net_key in s_params:
                ip  = params.get(ip_key,  nfos[if_name]['IP'])
                net = params.get(net_key, nfos[if_name]['Netmask'])
                set_map['affects_params'] = (ip_key, net_key)
                set_map['flow'] = 'ip address %s %s' % (ip, net)
                set_flow(set_map)

            # next iface, or exit on error:
            t.get('exit')

        # back to show mode:
        t.get('end')

    def get_freq_from_channel(self, channel):
        channel_map = self.get_channel_map()
        for chan, freq in channel_map.iteritems():
            if chan == channel:
                return freq

        return None


    def get_channel_from_freq(self, freq):
        return self.get_channel_map().get(freq)

    def get_channel_map(self):

        channel_map = {2412:1, 2417:2, 2422:3, 2427:4, 2432:5, 2437:6, 2442:7,
                       2447:8, 2452:9, 2457:10, 2462:11, 2467:12, 2472:13,
                       2484:13,
                       5170:34, 5180:36, 5190:38, 5200:40, 5210:42,  5220:44,
                       5230:46, 5240:48, 5260:52, 5280:56, 5300:60,  5320:64,
                       5500:100, 5520:104, 5540:108, 5560:112, 5580:116,
                       5600:120, 5620:124, 5640:128, 5660:132, 5680:136,
                       5700:140, 5745:149, 5765:153, 5785:157, 5805:151}
        return channel_map

# -----------  Upload and Download Support:




    def do_http_cfg_upload(self, t, url, *args, **kw):
        #url = url.replace('/putdevice', '/data/regman/upload')
        file_name = kw.get('file_name')
        if not file_name:
            sn = t.session_cache.get('.DeviceInfo.SerialNumber')
            file_name = '%s_CiscoAGConfig_%s' % (sn, strftime("%Y-%m-%dT%H%M%S.ini"))
        if file_name and not file_name in url:
            url = url + '/' + file_name
        res = t.get('copy run %s' % url, condition='?')
        res = t.get('', condition='?')
        res = t.get('', '#|Re: \)', timeout=20)
        if 'Error' in res:
            err = get_error_line(str(res), 'Error')
            raise Exception("9011: %s" % err)
    do_tftp_cfg_upload = do_http_cfg_upload
    do_ftp_cfg_upload = do_http_cfg_upload

    def do_http_cfg_download(self, t, url, *args, **kw):
        do_reboot = 0
        file_name = kw.get('file_name')
        if not file_name:
            file_name = 'startup-config'
            do_reboot = 1
        else:
            t.get('delete flash:%s' % file_name, condition='?')
            t.get('', condition='onfirm]')
            t.get('')

        res = t.get('copy %s nvram:%s' % (url, file_name), condition='?')
        if 'Error' in res:
            raise Exception(get_error_line(str(res), 'Error'))
        if file_name == 'startup-config':
            res = t.get('', timeout=10)
            if 'copied' in res:
                # apply it:
                t.get('', timeout=30)
                self.Reboot({}, t)
                return 1
            raise Exception(str(res), 'Error')

        res = t.get('', condition='?', timeout=10)
        if 'Error' in res:
            raise Exception("9015: %s" % get_error_line(str(res), 'Error'))

        if 'Erase flash' in res:
            res = t.get('n', timeout=20)

        if 'copied' in res:
            return

        raise Exception("9015: Transfer Error")

    do_tftp_cfg_download = do_http_cfg_download
    do_ftp_cfg_download = do_http_cfg_download






# -----------  Supported TR-069 RPCs:
    def AddObject(self, object_name, parameter_key, t):
        return self.SetParameterValues({object_name: 'AddObject'}, t)


    def DeleteObject(self, object_name, parameter_key, t):
        self.SetParameterValues({object_name: 'DeleteObject'}, t)




    def SetParameterValues(self, params, t):
        # use the default handler:
        return handle_SPV(params, t)


    def GetParameterNames(self, params, t):
        # use the default handler:
        return handle_GPN(params, t)


    def Reboot(self, params, t):
        # we save the running config before reboot:
        res = t.get('reload', condition=']')
        if 'Save?' in res:
            res = t.get('yes', condition='onfirm]', timeout=20)
        if 'reload?' in res:
            res = t.get('', condition='/NOREAD', timeout=1)
        return {}


    def Download(self, params, t):
        # this one should be async, that makes sense:
        if not params.get('in_transfer'):
            return 1
        return handle_Download(params, t)


    def Upload(self, params, t):
        return handle_Upload(params, t)

