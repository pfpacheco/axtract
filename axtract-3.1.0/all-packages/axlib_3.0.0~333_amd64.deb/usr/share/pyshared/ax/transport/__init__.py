try:
    __import__('pkg_resources').declare_namespace(__name__)
except ImportError:
    from pkgutil import extend_path
    __path__ = extend_path(__path__, __name__)



import hashlib
from os import popen, stat
from os.path import exists

#FIXME:protect from peeking:
SALT_CACHE = {}
def get_oneway_pw(t, pw, leng = 0, param = 'password'):
    """ Often we will be the creator of pws.

    we do it via an external module which can be secured 
    via OS board methods - and decide for it self what to 
    return
    We don't need even read rights to it, exec rights are 
    enough.
    """
    if not leng == int(leng):
        raise Exception ("need pw length as an integer")
    if leng < 1: leng = 1000
    if pw.startswith('force:'):
        return pw.split('force:')[1].strip()
    if hasattr(t, '__class__'):
        t_id = t.__class__.__name__
    else:
        t_id = str(t)
    salt = SALT_CACHE.get(t_id + param)
    if not salt:
        s_file = getattr(t, 'pw_module', None) or\
                '/etc/default/.axess_pw_salts.py'
        if not exists(s_file):
            # see the line below to understand the sys argv -
            # it just returns the pw as is:
            open(s_file, 'w').write\
                    ('import sys\nprint sys.argv[2][5:]')
        try:
            salt = popen('python %s --tid=%s --pw=%s --param=%s' % \
                (s_file, t_id, pw, param)).read()
        except Exception, ex:
            return pw


    if salt.startswith('force:'):
        return salt.split('force:')[1].strip()
   
    SALT_CACHE[t_id + param] = salt
    rpw = hashlib.md5('axp%s%s' % (pw, salt)).hexdigest()[:leng]
    return rpw

if __name__ == "__main__":
    print get_oneway_pw('dummy', 'some pw')

