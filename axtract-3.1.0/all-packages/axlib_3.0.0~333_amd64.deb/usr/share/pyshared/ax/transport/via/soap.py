"""Implementation of a suds based soap interaction """

# Note: basic implementation only, we only return what the soap server
# sent (suds objects for complex objects) w/o further parsing into 
# python standard objects.

# but all client.service.<rpc>s can be called.

from ax.transport.base import \
        ErrorConditionException, ConnectionClosedException
from ax.transport.connected_transport import ConnectedGetter
import suds

class SOAPClient(ConnectedGetter):
    """
    Using suds

    Note: suds is using python logging, here are facilities:
    logging.getLogger('suds.client').setLevel(logging.CRITICAL)
    logging.getLogger('suds.transport').setLevel(logging.CRITICAL)
    logging.getLogger('suds.xsd.schema').setLevel(logging.CRITICAL)
    logging.getLogger('suds.wsdl').setLevel(logging.CRITICAL)
    """

    identification =  "SOAP://%(user)s@%(wsdl_url)s"
    allowed_args = None
    allowed_cmds = None
    user = 'anon'
    password = None
    wsdl_url = None


    def open_connection (self):
        try:
            return  suds.client.Client(self.wsdl_url)
        except Exception, ex:
            msg = "Could not connect to %s - exception was: %s" %\
                    (self.identification % self, ex)
            raise ConnectionClosedException (msg)


    def communicate(self, cmd, conn_obj, condition,\
            error_condition, timeout, **kwargs):
        args = ()
        try:
            res = apply(getattr(conn_obj.service, cmd), kwargs.get('args'))
            return res
        except Exception, ex:
            err = 'Error: %s' % ex
            raise ErrorConditionException(err)



