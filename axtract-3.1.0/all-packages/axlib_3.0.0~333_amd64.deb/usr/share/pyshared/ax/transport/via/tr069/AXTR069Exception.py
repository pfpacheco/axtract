"""

AXTR069Exception.py is part of the commercial products WPS and Ax.

This file is copyrighted (C) 2002 - 2006 by Axiros GmbH.
Under no circumstance any distribution, derived work, analysis
and/or decompilation of this module is allowed.

Usage is restricted to parties legally owning a license
for the whole product. German copyright laws apply!

For details please read the license.

"""
__author__ = "Axiros GmbH, Germany"
__date__ = "$Date: 2006-10-24 18:08:03 +0200 (Tue, 24 Oct 2006) $"
__version__ = "$Revision: 112 $"[11:-2]


from ax.utils.lib.SOAPpy_ax.Types import faultType
from ax.utils.lib.SOAPpy_ax.Types import arrayType
from ax.utils.lib.SOAPpy_ax.Types import structType
from ax.utils.lib.SOAPpy_ax.Types import headerType
from ax.utils.lib.SOAPpy_ax.Types import untypedType
from ax.utils.lib.SOAPpy_ax.Types import dateTimeType
from ax.utils.lib.SOAPpy_ax.SOAPBuilder import buildSOAP

class AXTR069FaultType(faultType):
	faultcode = 'Server'
	default_faultcode = "8001"
	default_faultstring = "Request denied (no reason specified)"
        def __init__(self, faultcode = None, faultstring = None, detail = 1, SetParameterValuesFault = None):
	        self.tr069 = 1
		if not faultcode:
			faultcode = self.default_faultcode
		if not faultstring:
			faultstring = self.default_faultstring
                if detail:
                        #self.faultcode = 'Server'
                        self.faultstring = 'CWMP Fault'
                        self.detail = AXTR069FaultType(faultcode,faultstring,0,SetParameterValuesFault)
			self.SetParameterValuesFault = None
                else:
                        self.faultcode = faultcode
                        self.faultstring = faultstring
			if SetParameterValuesFault:
				if type(SetParameterValuesFault) in (type([]),type((1,))):
					self.SetParameterValuesFault = SetParameterValuesFault
				else:
					self.SetParameterValuesFault = [SetParameterValuesFault]
			else:
				self.SetParameterValuesFault = None
                structType.__init__(self, None, 0)

class AXTR069CPEFaultType(AXTR069FaultType):
	faultcode = 'Client'
	default_faultcode = "9001"
	default_faultstring = "Request denied (no reason specified)"
	
class SetParameterValuesFault(AXTR069FaultType):
	def __init__(self,faultcode,faultstring,parameter):
	        self.tr069 = 1
                self.faultcode = faultcode
                self.faultstring = faultstring
		self.ParameterName = parameter
                structType.__init__(self, None, 0)
		

class AXTR069Exception(Exception):
        def __init__(self,FaultCode = 8001,Description='Request denied (no reason specified)'):
                self.FaultCode = FaultCode
                self.Description = Description
		
	def __str__(self):
		return "Fault %s %s"%(self.FaultCode,self.Description)


