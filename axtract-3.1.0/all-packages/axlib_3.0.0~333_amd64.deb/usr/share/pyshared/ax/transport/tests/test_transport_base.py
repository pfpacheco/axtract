#!/opt/axess/bin/call_with_eggs
import unittest2
from time import sleep, time
from ax.transport import base
from ax.transport.base import TimeoutException, TransportException


# try - if not no func tests:
import logging
logging.basicConfig(level=logging.DEBUG)




class SET_Tests(unittest2.TestCase):
    def setUp(self):
        self.b = base.Getter()
        self.b.repl1 = 'http://foo.bar:232?fo=1'
        self.b.testvar = 'fubar'

    def test_SET_Empty(self):
        assert self.b.get('/SET: foo') == ''
        assert self.b.foo == '1'

    def test_SET_STR(self):
        assert self.b.get('/SET: foo = 2') == ''
        self.b.get('/SET:fo=2')
        self.b.get('/SET:bar=  2  ')
        assert self.b.foo == '2'
        assert self.b.fo == '2'
        assert self.b.bar == '2'

    def test_SET_INT(self):
        assert self.b.get('/SETINT: foo2 = 2') == ''
        assert self.b.foo2 == 2

    def test_SET_FLOAT(self):
        assert self.b.get('/SETFLOAT: foo3 = 2.4') == ''
        assert self.b.foo3 == 2.4

    def test_SET_REPL(self):
        assert self.b.get('/SETREPL: foo4 = /n/t bar') == ''
        assert self.b.foo4 == '\n\t bar'

    def test_UNSET_Empty(self):
        self.test_SET_Empty()
        res = self.b.get('/UNSET: foo')
        assert getattr(self.b, 'foo', 1)  == 1

    def test_IS(self):
        assert self.b.get('/GET: testvar') == self.b.testvar

    def test_NOERR(self):
        """ testing if a the error condition is not set """
        self.b.communicate = test_fun
        self.b.error_condition = 'err'
        res = self.b.get('no_check_cmd')
        assert res[1][0] == 'no_check_cmd'
        assert res[1][3] == 'err'
        res = self.b.get('/NOERR:no_check_cmd')
        assert res[1][0] == 'no_check_cmd'
        assert res[1][3] == ''



TEST_ARGS = [0, {}]
def test_fun(*args, **kwargs):
    # called with self, as first arg:
    if args and hasattr(args[0], 'sub_test_fun') \
            or 'no_check' in str(args):
        # will check in the test itself:
        return 'processed', args, kwargs
    assert args   == TEST_ARGS[0]
    assert kwargs == TEST_ARGS[1] or 'transport' in kwargs.keys()

class TestClass(object):
    sub_test_fun = test_fun




class RUN_RUNS_Tests(unittest2.TestCase):
    """"
        Autonmous tests of the base module
    """

    def setUp(self):
        TEST_ARGS[0] = ()
        TEST_ARGS[1] = {}
        self.b = base.Getter()
        self.kw_triv = {'transport': self.b}
        # example subobject, with some real life reference;-)
        self.b.model = TestClass()
        self.b.testfun = test_fun
        self.settings ={
                 }

    # nailing down the RUNS parsing - args MUST be nice with ', ':
    def test_RUNS_NoParams(self):
        self.b.testfun = test_fun
        # here we won't parse our the function params:
        self.assertRaises(Exception, self.b.get, '/RUNS:testfun')

    def test_RUNS(self):
        # here we won't parse our the function params:
        TEST_ARGS[0] = ('1,2', 'a')
        self.b.get('/RUNS:testfun(1,2, a)')

    def test_RUNS2(self):
        # here we won't parse our the function params:
        TEST_ARGS[0] = ('1', '2 ', 'a')
        self.b.get('/RUNS:testfun(1, 2 , a)')

    def test_RUNS3(self):
        # here we won't parse our the function params:
        TEST_ARGS[0] = ('1', '2 ', 'a')
        self.b.get('/RUNS:testfun  (1, 2 , a) asdfa')



    # RUN functions can work with non string args:
    def test_RUN_1(self):
        # here we won't parse our the function params:
        self.b.get('/RUN:testfun')

    def test_RUN_2(self):
        # here we won't parse our the function params:
        TEST_ARGS[0] = (1, 2, 'a')
        self.b.get('/RUN:testfun', params = (1, 2 , 'a'))

    def test_RUN_3(self):
        # here we won't parse our the function params:
        TEST_ARGS[0] = ( 'a', {1: 2}, 'foo')
        TEST_ARGS[1] = {'foo': 'bar', 'bar': 'adf', 'params': TEST_ARGS[0]}
        TEST_ARGS[1].update(self.kw_triv)
        self.b.get('/RUN:testfun',
                         foo= 'bar',
                         bar='adf',
                         params = ('a', {1:2}, 'foo'))


    # cmds can be like a.b.c:
    def test_RUNS_SUBOBJ(self):
        res = self.b.get('/RUNS:model.sub_test_fun(1, a)')
        assert res == ('processed', (self.b.model, '1', 'a'), self.kw_triv)


    def test_RUN_SUBOBJ_2(self):
        p = (1, 'y')
        res = self.b.get('/RUN:model.sub_test_fun',
                   params = p)
        assert res[0] == 'processed'
        

    def test_obj_not_found(self):
        self.b.model = None
        self.assertRaises(TransportException,
           self.b.get, '/RUN:model.sub_test_fun', foo='bar')


    def test_more_hir(self):
        self.b.model.subobj = self.b
        # testfun is in b, will be called now w/o self, unbound:
        TEST_ARGS[1] = {'foo1': 'bar2', 'transport': self.b}
        res = self.b.get('/RUN:model.subobj.testfun', foo1='bar2')
        # circ. refs?, go sure:
        del self.b.model.subobj
        del self.b




    def test_transport_arg(self):
        res = self.b.get('/RUN:model.sub_test_fun', foo='bar', ft = 'transport')
        assert res == (
            'processed',
            (self.b.model,),
            {'foo': 'bar',
             'ft': 'transport',
             'transport': self.b})


    def test_transport_argRUNS(self):
        res = self.b.get('/RUNS:model.sub_test_fun(transport, foo)')
        assert res == ('processed', (self.b.model, self.b, 'foo'), self.kw_triv)


if __name__ == "__main__":
    unittest2.main(verbosity=2)
