from ax.utils.parsing.parse_text import get_line_val, get_in
from netaddr import IPNetwork

from ax.transport.model.misc import get_tr_rpcs, get_error_line
from ax.transport.model.misc import get_uptime_secs, run_many, put
from ax.transport.model.misc import safe_cli_get
from ax.transport.model.misc import handle_Upload, handle_Download

from ax.transport.model.keyval import handle_GPV, handle_SPV, handle_GPN
from ax.transport.model.keyval import SPVException, set_flow
from ax.transport.model.keyval import depends, lines, indizes

from ax.transport.model.model_support import Model, MODELS


# Modelling of a CISCO 1861 router:
#
# assumptions: ATM0 interfaces are WAN




class C1861(Model):

    def GPV_NSLookupDiagnostics_HostName(self, t):
        depends('GPV_DeviceInfo', t)


    def GPV_DeviceInfo(self, t):
        c = t.session_cache
        buf = t.get('show version')
        c['.DeviceInfo.Manufacturer'] = 'Cisco'
        c['.DeviceInfo.ManufacturerOUI'] = '00067C'
        c['.DeviceInfo.ProductClass'] = 'AXPAND'
        c['.DeviceInfo.Modelname'] = 'C1861'
        c['.DeviceInfo.Description'] = 'Cisco C1861 router managed by Axiros AXPAND'
        sw = buf.split(' Version', 1)[1].split(',', 1)[0].strip()
        c['.DeviceInfo.SoftwareVersion'] = buf.split(' Version',
            1)[1].split(',', 1)[0].strip()
        c['.DeviceInfo.HardwareVersion'] = buf.rsplit('cisco.com',
            1)[1].split(' processor ', 1)[0].split('Cisco ')[1].split(' ')[0]

        pre, upt = buf.split('uptime is', 1)
        c['.DeviceInfo.UpTime'] = get_uptime_secs(upt.split('\n')[0])
        sn = ''
        pvc = ''
        custkey = ''
        if hasattr(t, 'cpe'):
            sn = t.cpe.get('.DI.SN')
            if not sn:
                sn = '0.0.0'
                t.cpe.set('.DI.SN', sn)
            pvc = t.cpe.get('.DI.PrC')
            if not pvc:
                pvc = ''
                t.cpe.set('.DI.PrC', pvc)
        c['.DeviceInfo.Serialnumber'] = sn
        c['.DeviceInfo.ProvisioningCode'] = pvc
        c['.DeviceInfo.X_TELECOMITALIA_COM_Customerkey'] = custkey
        if 'db_props' in c:
            c['.DeviceInfo.X_TELECOMITALIA_COM_IPAddress'] = c['db_props']['.AxirosAxess.CpeHandler.Axpand.Transport.Socket.Host']
        else:
            c['.DeviceInfo.X_TELECOMITALIA_COM_IPAddress'] = '99.99.99.99'
        #import pdb; pdb.set_trace()


    def GPV_DeviceInfo_DeviceLog(self, t):
        c = t.session_cache
        if c.get('in_inform'):
            return
        buf = safe_cli_get(t, 'show log')
        #c['.DeviceInfo.DeviceLog'] = buf[-32768:]
        c['.DeviceInfo.DeviceLog'] = '<DEVICELOG HERE>'


    def GPV_DeviceConfig_ConfigFile(self, t):
        c = t.session_cache
        #res = depends('show_run', t)
        #c['.DeviceConfig.ConfigFile'] = res
        c['.DeviceConfig.ConfigFile'] = '<CONFIGFILE HERE>'


    def GPV_DeviceConfig_PersistentData(self, t):
        c = t.session_cache
        #res = depends('show_startup', t)
        #c['.DeviceConfig.PersistentData'] = res
        c['.DeviceConfig.PersistentData'] = '<PersistentData HERE>'


    def GPV_Time_NTPServer1(self, t):
        """
        address         ref clock       st   when   poll reach  delay  offse
        ~1.2.4.2         .INIT.          16      -     64     0  0.000   0.000 1
        *~62.38.83.25     62.38.0.204      5    801   1024   377  1.351  -5.125
        +~62.38.83.26     62.38.0.205      5     58   1024   377  1.414  -5.231
        * sys.peer, # selected, + candidate, - outlyer, x falseticker, ~ configu
        """
        c = t.session_cache
        for nr in range(1, 4):
            c['.Time.NTPServer%s' % nr] = ''
        buf = t.get('show ntp associations')
        nr = 0
        for l in buf.split('\n'):
            if len(l) > 1 and l[1] == '~':
                nr += 1
                c['.Time.NTPServer%s' % nr] = l[2:].split(' ', 1)[0]


    def GPV_Time_NTPServer2(self, t):
        depends('GPV_Time_NTPServer1', t)


    def GPV_Time_NTPServer3(self, t):
        depends('GPV_Time_NTPServer1', t)


    def GPV_LANDevice(self, t):
        ipbrief = depends('show_ip_int', t)

                
    def GPV_ManagementServer(self, t):
        #import pdb; pdb.set_trace()
        c = t.session_cache
        tr = '.ManagementServer.'
   
        pie = 0
        pii = 86400
        pk = ""
        pt = ""
        un = ""
        cru = ""
        dmchange = False
        if hasattr(t, 'cpe'):
            pie = t.cpe.get('.MS.PIE')
            if not pie:
                pie = 0
                t.cpe.set('.MS.PIE', pie)
                dmchange = True
            pii = t.cpe.get('.MS.PII')
            if not pii:
                pii = 0
                t.cpe.set('.MS.PII', pii)
                dmchange = True
            pt = t.cpe.get('.MS.PIT')
            if not pt:
                pt = "0001-01-01T00:00:00Z"
                t.cpe.set('.MS.PIT', pt)
                dmchange = True
            pk = t.cpe.get('.MS.PK')
            if not pk:
                pk = ''
                t.cpe.set('.MS.PK', pk)
                dmchange = True
            un = t.cpe.get('.MS.Us')
            if not un:
                un = ''
                t.cpe.set('.MS.Us', un)
                dmchange = True
            cru = t.cpe.get('.MS.CRUs')
            if not cru:
                cru = ''
                # Get Username from AXPAND Transport:
                t.cpe.set('.MS.CRUs', cru)
                dmchange = True
            # write changes back to DB
            if dmchange:
                setattr(t.cpe,'writeCPE',True)

        c[tr + 'PeriodicInformEnable'] = str(pie)
        c[tr + 'PeriodicInformInterval'] = str(pii)
        c[tr + 'PeriodicInformTime'] = pt
        c[tr + 'ParameterKey'] = pk
        c[tr + 'Username'] = un
        c[tr + 'Password'] = ''
        c[tr + 'ConnectionRequestUsername'] = cru
        c[tr + 'ConnectionRequestPassword'] = ''
        #import pdb; pdb.set_trace()

# -------------------------------Helpers

    def show_run(self, t):
        res = safe_cli_get(t, 'show run', 30)
        return res.split('!', 1)[1].strip()


    def show_startup(self, t):
        res = safe_cli_get(t, 'show startup-config')
        return res.split('!', 1)[1].strip()


    def show_ip_nat_translations(self, t):
        """
        test_C877_BRM#show ip nat translations
        Pro Inside global         Inside local          Outside local         \
                                                                Outside global
        tcp 5.55.224.4:889        192.168.1.10:80       ---                   \
                                                                ---
        tcp 62.38.95.90:389       192.168.1.11:389      ---
        tcp 5.55.224.4:3389       192.168.1.11:3389     10.5.80.225:4184
        tcp 5.55.224.4:3389       192.168.1.11:3389     ---
        test_C877_BRM#
        """
        c = t.session_cache
        res = []
        index = 0
        cmd = 'show ip nat translations'
        for line in lines(t.get(cmd)):
            l = line.split()
            if len(l) < 3 or cmd in line:
                continue
            index += 1
            outip, outport = l[1].split(':')
            inip,  inport  = l[2].split(':')
            res.append({
                          'outIP': outip, 'outPort': outport,
                          'inIP' : inip,  'inPort' : inport,
                          'proto': l[0].upper()
                       }
                      )
        c['show_ip_nat_translations'] = res



    def show_ip_int(self, t):
        c = t.session_cache
        # we will split below, delete the space in the column:
        out = t.get('show interface')  
        # ip int | inc line | Internet address')

        ifs = {
            'ATM':            [],
            'Dialer':         [],
            'Vlan':           [],
            'Dot11Radio':     [],
            'FastEthernet':   [],
            'Virtual-Access': []
              }
        nfos = {}

        # first parse results into mappings:
        #import pdb; pdb.set_trace()
        valid = False
        if_name = "";
        for line in lines(out):
            #search for interface information
            if not line.startswith(' ') and line.strip():
                valid = False
                if_name = line.split(' ', 1)[0]
                # check if name is valid:
                for if_type in ifs:
                    if line.startswith(if_type):
                        valid = True
                        ifs[if_type].append(if_name)
                        if_map = {'Name': if_name}
                        nfos[if_name] = if_map
                        if_map['Status'] = 1
                        if 'down' in line:
                            if_map['Status'] = 0
                        break
                continue
             
            elif valid:  # interface found
                line = line.strip()
                if line.startswith('Internet address is '):
                    ip = IPNetwork(line.rsplit(' ', 1)[1])
                    if_map['IP'], if_map['Netmask'] = str(ip.ip), str(ip.netmask)
                elif line.startswith('Hardware is'):
                    if_map['MAC'] = "00:00:00:00:00:00"
                    if line.find("(bia") > 0:
                        mac = line.split("(bia ")[1]
                        if len(mac) > 15:
                            if_map['MAC'] = "%c%c:%c%c:%c%c:%c%c:%c%c:%c%c" % (c[1],c[2],c[3],c[4],c[6],c[7],c[8],c[9],c[11],c[12],c[13],c[14])
                elif line.find('packets input,') > 0:
                    stat = line.split()
                    if_map['rx_bytes'] = int(stat[3])   
                    if_map['rx_packets'] = int(stat[0]) 
                elif line.find('packets output,') > 0:
                    stat = line.split() 
                    if_map['tx_bytes'] = int(stat[3])    
                    if_map['tx_packets'] = int(stat[0])                   
            else:
                print "DBG invalid line>%s<" % line
         
        WAN_MAP = ['ATM0/2/0']
        # - ethx : LAN interfaces (x != WAN_MAP)
        # - lo: not modelled
        # O.I - store index counters in cache ?
        #import pdb; pdb.set_trace()
        noIPIF = 0
        noWANDEV = 0
        noWANIPCON = 0
        noLANDEV = 0
        noLANETH = 0
        c['.WANDeviceNumberOfEntries'] = noWANDEV
        c['.LANDeviceNumberOfEntries'] = noLANDEV
        for if_type, if_names in ifs.items():
            for if_name in if_names:
                if_map = nfos[if_name]
                tr_node = None
                index = if_names.index(if_name) + 1
                m = if_map
                # test for WAN interfaces
                ifwan = False
                wm = False
                for wan in WAN_MAP:
                    if if_name.startswith(wan):
                        ifwan = True
                        wm = (if_name == wan)
                        break
                
                if ifwan:
                    # create WAN model
                    if wm:
                        noWANDEV += 1
                        c['.WANDeviceNumberOfEntries'] = noWANDEV
                        twan = '.WANDevice.%d.WANCommonInterfaceConfig.' % noWANDEV
                        c[twan + 'EnabledForInternet'] = '1'
                        if if_map['Status'] == 1:
                            c[twan + 'PhysicalLinkStatus'] = "Up"
                        else:
                            c[twan + 'PhysicalLinkStatus'] = "Down"
                        c[twan + 'TotalBytesSent'] = 0
                        c[twan + 'TotalBytesReceived'] = 0
                        c[twan + 'TotalPacketsSent'] = 0
                        c[twan + 'TotalPacketsReceived'] = 0
                    wan_device = '.WANDevice.%d.' % noWANDEV
                    
                    # for Ethernet (interface or link), only one WANConnectionDevice instance is supported:
                    if if_name != wan:   # only model ATM0/2/0.x as connection! 
                        noWANIPCON += 1
                        c[wan_device + 'WANConnectionNumberOfEntries'] = 1
                        c[wan_device + 'WANConnectionDevice.1.WANIPConnectionNumberOfEntries'] = noWANIPCON
                        tr = wan_device + 'WANConnectionDevice.1.WANIPConnection.%d.' % noWANIPCON
                        c[tr + 'Enable'] = "1"
                        if if_map['Status'] == 1:
                            c[tr + 'ConnectionStatus'] = "Connected"
                        else:
                            c[tr + 'ConnectionStatus'] = "Disconnected"
                        put(c, tr, 'ExternalIPAddress', m, 'IP')
                        put(c, tr, 'SubnetMask', m, 'Netmask')
                        put(c, tr, 'MACAddress', m, 'MAC')
                        c[tr + 'PortMappingNumberOfEntries'] = "0"
                        c[tr + 'PortMapping'] = ''
                        tr += 'Stats.'
                        put(c, tr, 'EthernetBytesSent', m, 'tx_bytes')
                        put(c, tr, 'EthernetBytesReceived', m, 'rx_bytes')
                        put(c, tr, 'EthernetPacketsSent', m, 'tx_packets')
                        put(c, tr, 'EthernetPacketsReceived', m, 'rx_packets')
                        put(c, tr, 'EthernetErrorsSent', m, 'tx_errors')
                        put(c, tr, 'EthernetErrorsReceived', m, 'rx_errors')
                        put(c, tr, 'EthernetDiscardPacketsSent', m, 'tx_dropped')
                        put(c, tr, 'EthernetDiscardPacketsReceived', m, 'rx_dropped')
                        if 'tx_bytes' in m:
                            c[twan + 'TotalBytesSent'] += int(m['tx_bytes'])
                            c[twan + 'TotalBytesReceived'] += int(m['rx_bytes'])
                            c[twan + 'TotalPacketsSent'] += int(m['tx_packets'])
                            c[twan + 'TotalPacketsReceived'] += int(m['rx_packets']) 

                elif if_type == 'FastEthernet':
                    #import pdb; pdb.set_trace()
                    # create LAN interfaces model
                    k = if_name.split(':')
                    if not k[1:2]:
                        # create new LANDevice
                        noLANDEV += 1
                        c['.LANDeviceNumberOfEntries'] = noLANDEV
                        noLANETH = 0
                        tld = '.LANDevice.%d.' % noLANDEV
                        c[tld + 'LANLANConfigurationNumberOfEntries'] = 0
                    # create new LANEthernetInterfaceConfig
                    noLANETH += 1
                    c[tld + 'LANEthernetInterfaceNumberOfEntries'] = noLANETH
                    tr = tld + 'LANEthernetInterfaceConfig.%d.' % noLANETH 
                    if if_map['Status'] == 1:
                        c[tr + 'Status'] = "Up"
                    else:
                        c[tr + 'Status'] = "Disabled"
                    #put(c, tr, 'LastChange', m, 'status_changed')
                    put(c, tr, 'MACAddress', m, 'MAC')
                    c[tr + 'Name'] = if_name
                    if 'tx_bytes' in m:
                        tr += 'Stats.'
                        put(c, tr, 'BytesSent', m, 'tx_bytes')
                        put(c, tr, 'BytesReceived', m, 'rx_bytes')
                        put(c, tr, 'PacketsSent', m, 'tx_packets')
                        put(c, tr, 'PacketsReceived', m, 'rx_packets')
                        put(c, tr, 'ErrorsSent', m, 'tx_errors')
                        put(c, tr, 'ErrorsReceived', m, 'rx_errors')
                        put(c, tr, 'DiscardPacketsSent', m, 'tx_dropped')
                        put(c, tr, 'DiscardPacketsReceived', m, 'rx_dropped')

                if tr_node:
                    # remember the node with indizes:
                    nfos[if_name]['tr_index'] = index
        return [ifs, nfos]




# -----------  Setter Methods:

    setters = {'SPV_LANSetup': ['LANHostConfigManagement'], \
               'SPV_ManagementServer': ['ManagementServer'], \
               'SPV_DeviceInfo': ['DeviceInfo'], \
              }
    error_markers = ['Bad ', 'nvalid ', ' ncomplete ']
    exit_context = ['exit', 'end']




    def SPV_ManagementServer(self, t):
        #import pdb; pdb.set_trace()
        c = t.session_cache
        tm = c['spv_try_mode']
        ms_map = {'.ManagementServer.PeriodicInformEnable' : '.MS.PIE', \
                  '.ManagementServer.PeriodicInformInterval' : '.MS.PII', \
                  '.ManagementServer.PeriodicInformTime' : '.MS.PIT', \
                  '.ManagementServer.ConnectionRequestUsername' : '.MS.CRUs', \
                  '.ManagementServer.ConnectionRequestPassword' : '.MS.CRP', \
                  '.ManagementServer.Username' : '.MS.Us', \
                  '.ManagementServer.Password' : '.MS.P', \
                  '.ManagementServer.URL' : '.MS.U', \
                 }
        for item in c['to_set_params']:
            if item in ms_map:
                if not tm:
                    if hasattr(t, 'cpe'):
                        t.cpe.set(ms_map[item], c['to_set_params'][item])
                c['have_set_params'].append(item)


    def SPV_DeviceInfo(self, t):
        #import pdb; pdb.set_trace()
        c = t.session_cache
        tm = c['spv_try_mode']
        ms_map = {'.DeviceInfo.ProvisioningCode' : '.DI.PrC'
                  }
        for item in c['to_set_params']:
           if item in ms_map:
               if not tm:
                   if hasattr(t, 'cpe'):
                        t.cpe.set(ms_map[item], c['to_set_params'][item])
               c['have_set_params'].append(item)


    def commit_on_close(self, t):
        # this takes long, do it only on close:
        t.get('copy running-config startup-config', timeout=10)



    def SPV_LANSetup(self, t):
        c = t.session_cache
        # all SPV params:
        params = c['to_set_params']
        # get state:
        ifs, nfos = depends('show_ip_int', t)

        # configure:
        t.get('conf t')

        # stringify SPV map:
        s_params = str(params)

        # check all ifs which are found (i.e. in c):
        LD ='DUMMY' # to be fixed
        for index in indizes(LD + 'LANEthernetInterfaceConfig.', c):
            if_node = LD + 'LANEthernetInterfaceConfig.%s.' % index
            ip_node = LD + 'LANHostConfigManagement.IPInterface.%s.' % index

            if_name = c.get(if_node + 'Name')
            if not if_name or not (if_node in s_params or ip_node in s_params):
                # iface not there or nothing to change on this one:
                continue

            t.get('interface %s' % if_name)
            # enable?
            key = if_node + 'Enable'
            v = params.get(key)
            set_map = {'c': c,
                       't': t,
                       'error_markers' : self.error_markers,
                       'ctx_exit': self.exit_context
                       }

            if v != None:
                # enable param set to a value. run the cmd:
                set_map['affects_params'] = key
                if str(v) == '1':
                    set_map['flow'] = 'no shutdown'
                else:
                    set_map['flow'] = 'shutdown'
                set_flow(set_map)

            # ip setup with ip address and netmask?
            ip_key =  ip_node + 'IPInterfaceIPAddress'
            net_key = ip_node + 'IPInterfaceSubnetMask'

            if ip_key in s_params or net_key in s_params:
                if 'IP' in nfos[if_name]:
                    ip  = params.get(ip_key,  nfos[if_name]['IP'])
                    net = params.get(net_key, nfos[if_name]['Netmask'])
                else:
                    ip = '0.0.0.0'
                    net = '0.0.0.0'
                set_map['affects_params'] = (ip_key, net_key)
                set_map['flow'] = 'ip address %s %s' % (ip, net)
                set_flow(set_map)

            # next iface, or exit on error:
            t.get('exit')

        # back to show mode:
        t.get('end')



# -----------  Upload and Download Support:


    def do_http_cfg_upload(self, t, url, *args, **kwargs):
        res = t.get('copy run %s' % url, condition='?')
        res = t.get('', condition='?')
        res = t.get('', timeout=10)
        if 'Error' in res:
            err = get_error_line(str(res), 'Error')
            raise Exception(err)
    do_tftp_cfg_upload = do_http_cfg_upload


    def do_http_cfg_download(self, t, url, file_name, file_size,*args,**kwargs):
        if not file_name:
            file_name = 'running-config'
        else:
            t.get('delete flash:%s' % file_name, condition='?')
            t.get('', condition='onfirm]')
            t.get('')

        res = t.get('copy %s %s' % (url, file_name), condition='?')
        if 'Error' in res:
            raise Exception(get_error_line(str(res), 'Error'))
        if file_name == 'running-config':
            res = t.get('', timeout=10)
            if 'copied' in res:
                # apply it:
                t.get('copy running-config startup-config', condition='?')
                t.get('', timeout=30)
                return
            raise Exception(str(res), 'Error')

        res = t.get('', condition='?', timeout=10)
        if 'Error' in res:
            raise Exception(get_error_line(str(res), 'Error'))
        if 'Erase flash' in res:
            res = t.get('n', timeout=10)
        if 'copied' in res:
            return
        raise Exception(str(res), 'Error')
    do_tftp_cfg_download = do_http_cfg_download




# -----------  Supported TR-069 RPCs:
    def GetRPCMethods(self):
        # default handling:
        return {'MethodList': get_tr_rpcs(self)}
    
    
    def GetParameterValues(self, params, t):
        # use the default handler:
        return handle_GPV(params, t)
    
    
    def SetParameterValues(self, params, t):
        # use the default handler:
        return handle_SPV(params, t)
    
    
    def GetParameterNames(self, params, t):
        # use the default handler:
        return handle_GPN(params, t)
    
    
    def Reboot(self, params, t):
        # we save the running config before reboot:
        res = t.get('reload', condition=']')
        if 'Save?' in res:
            res = t.get('yes', condition='onfirm]', timeout=20)
        if 'reload?' in res:
            res = t.get('confirm', condition=None)
        return {}

    
    def Download(self, params, t):
        return handle_Download(params, t)
    
    
    def Upload(self, params, t):
        return handle_Upload(params, t)




# register us:
from ax.transport.base import MODELS
MODELS["cisco.C1861"] = C1861()


