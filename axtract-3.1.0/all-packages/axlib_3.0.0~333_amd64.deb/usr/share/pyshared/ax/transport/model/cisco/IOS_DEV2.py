from ax.utils.parsing.parse_text import get_line_val, parse_timestr
import re
from cgi import escape
import time
from datetime import datetime
from netaddr import IPAddress as IP
from netaddr import IPNetwork, EUI
from ax.transport.model.misc import get_uptime_secs, put
from ax.transport.model.misc import get_ifmap_by_ip
from ax.transport.model.misc import safe_cli_get
from ax.transport.model.keyval import depends, lines
from ax.transport.model.model_support import add_model
from ax.transport.model.model_support import Model
from ios_parsing import IOSParser

# we work only via these:
DI = '.DeviceInfo.'

class IOS_DEV2(IOSParser, Model):
    root = 'D'
    model = 'DEV2'
    matching = 'cisco.pexpect|ssh|telnet'

    def test_portmapping_spv(self, t):
        c = t.session_cache
        c['to_set_params'] = {'.NAT.PortMapping.1.Enable' : 1,
                              '.NAT.PortMapping.1.RemoteHost' : '94.93.26.177',
                              '.NAT.PortMapping.1.ExternalPort' :9999,
                              '.NAT.PortMapping.1.InternalPort' : 1999,
                              '.NAT.PortMapping.1.InternalClient' : '10.0.4.9',
                              '.NAT.PortMapping.1.Protocol' : 'TCP',
                              '.NAT.PortMapping.3.RemoteHost' : '94.93.26.177',
                              '.NAT.PortMapping.3.ExternalPort' : 737,
                              '.NAT.PortMapping.3.InternalPort' : 731,
                              '.NAT.PortMapping.3.InternalClient' : '10.0.4.73',
                              '.NAT.PortMapping.3.Protocol' : 'TCP',
                              }
        c['have_set_params'] = {}
        IOSParser.set_portmapping(self, t)

    def heartbeat(self, t):
        """ holded transports need from time to time a heartbeat preventing
        socket close"""
        try:
            t.get('term len 0')
        except:
            return 0
        return 1

    def GPV_DeviceInfo(self, t):
        c = t.session_cache
        buf = depends('show version', t).split('show version')[-1]
        c['.RootDataModelVersion'] = '2.6'


        c[DI + 'SupportedDataModel.1.URL'] = 'http://localhost/IOS_2.6.xml'
        c[DI + 'SupportedDataModel.1.URN'] = 'urn:axiros-com:device-2-6-0'
        c[DI + 'SupportedDataModel.1.Features'] = 'CiscoIOSFeatures'

        c[DI + 'Manufacturer'] = 'Cisco'
        c[DI + 'ManufacturerOUI'] = '00067C'
        c[DI + 'ProductClass'] = 'AXPAND'
        c[DI + 'SoftwareVersion'] = get_line_val(
                buf,
                'Version',
                ',',
                get=0)
        # HW model: take the first word in the line after Processor board ID:
        pre, post = buf.split('Processor board ID', 1)
        mn = post.split('\n', 1)[1].split()[0]
        c[DI + 'ModelName'] = mn
        hwfull = pre.splitlines()[-1]
        hw = hwfull.upper().replace('CISCO ', '').split(' ')[0]
        hw = hw[0:4] + hw[4:].split('-')[0]
        c[DI + 'HardwareVersion'] = hw
        c['.X_AXIROS_COM.CpeInfos.ExtendedHWInfos'] = hwfull
        c[DI + 'Description'] = 'Cisco %s Router Managed By Axiros AXPAND' % hw
        c[DI + 'SerialNumber'] = get_line_val(buf, 'Processor board ID').split(' ')[0].split(',')[0]


        pre, upt = buf.split('uptime is', 1)
        c[DI + 'UpTime'] = get_uptime_secs(upt.split('\n')[0])
        c['.NSLookupDiagnostics.HostName'] = pre.rsplit('\n',1)[1].strip()

        # boot time - vendor specific feature:
        # System restarted at 05:10:03 MEZ Wed May 8 2002
        boot_time_ts = depends('parse_clock', t) - c[DI + 'UpTime']
        # convert:
        try:
            # client conversion problem with float:
            c['.X_AXIROS_COM.CpeInfos.BootTime'] = str(boot_time_ts)
            c['.X_AXIROS_COM.CpeInfos.BootTimePretty'] = time.ctime(boot_time_ts)
        except:
            # not statement about restart:
            pass


    def GPV_DeviceInfo_DeviceLog(self, t):
        return ''
        c = t.session_cache
        if c.get('in_inform'):
            return
        buf = safe_cli_get(t, 'show log', maxdata=0)
        c['.DeviceInfo.DeviceLog'] = escape(buf[-10000:])

    def GPV_DeviceConfig_ConfigFile(self, t):
        c = t.session_cache
        res = depends('show_run', t)
        c['.DeviceConfig.ConfigFile'] = res


    """
    def xGPV_DeviceConfig_PersistentData(self, t):
        c = t.session_cache
        res = depends('show_startup', t)
        c['.DeviceConfig.PersistentData'] = res

    """

    def GPV_Time_NTPServer1(self, t):
        """
        address         ref clock       st   when   poll reach  delay  offse
        ~1.2.4.2         .INIT.          16      -     64     0  0.000   0.000 1
        *~62.38.83.25     62.38.0.204      5    801   1024   377  1.351  -5.125
        +~62.38.83.26     62.38.0.205      5     58   1024   377  1.414  -5.231
        * sys.peer, # selected, + candidate, - outlyer, x falseticker, ~ configu
        """
        c = t.session_cache
        for nr in range(1, 5):
            c['.Time.NTPServer%s' % nr] = ''

        buf = t.get('show ntp associations')
        if 'invalid input' in buf.lower():
            # sntp?
            buf = depends('show sntp', t)
            if not 'SNTP server' in buf:
                c['no_ntp'] = 1
                return
            c['is_sntp'] = 1
            nr = 0
            for line in buf.splitlines():
                cells = line.split()
                #IPv4
                if len(cells[0].split('.')) == 4:
                    nr += 1
                    c['.Time.NTPServer%s' % nr] = cells[0]
        nr = 0
        for l in buf.split('\n'):
            if len(l) > 1 and l[1] == '~':
                nr += 1
                c['.Time.NTPServer%s' % nr] = l[2:].split(' ', 1)[0]


    def GPV_Time(self, t):
        c = t.session_cache
        depends('GPV_Time_NTPServer1', t)
        if c.get('is_sntp'):
            buf = depends('show sntp', t).lower()
        else:
            buf = depends('show ntp status', t)
        c['.Time.Enable'] = True
        if 'not enabled' in buf or 'invalid input' in buf:
            c['.Time.Status'] = 'Disabled'
        else:
            if ' unsynchronized' in buf and not 'synced' in buf:
                c['.Time.Status'] = 'Unsynchronized'
            elif ' synchronized' in buf or 'synced' in buf:
                c['.Time.Status'] = 'Synchronized'
            elif not 'clock' in buf and not 'sntp server' in buf:
                c['.Time.Status'] = 'Disabled'
                c['.Time.Enable'] = False
            else:
                c['.Time.Status'] = 'Error'
        # like: 11:44:59.302 MEZ Sun Jun 16 2002
        clockts = depends('parse_clock', t)
        c['.Time.CurrentLocalTime'] =  datetime.fromtimestamp(int(clockts))

        # additional parameters, required by REGMAN
        # TODO: Fill with valid values if available
        c['.Time.DaylightSavingsEnd'] = ""
        c['.Time.DaylightSavingsStart'] = ""
        c['.Time.DaylightSavingsUsed'] = ""
        c['.Time.LocalTimeZone'] = ""


    def GPV_Time_NTPServer2(self, t):
        depends('GPV_Time_NTPServer1', t)


    def GPV_Time_NTPServer3(self, t):
        depends('GPV_Time_NTPServer1', t)

    def diagnostics_ping(self, t, pmap):
        c = t.session_cache
        p = '.IP.Diagnostics.IPPing.'
        timeout = max(1, int(pmap.get(p + 'Timeout', 1000)/1000))
        size = pmap.get(p + 'X_AXIROS_COM_DataBlockSize', 100)
        reps = pmap.get(p + 'NumberOfRepetitions', 1)
        host = pmap.get(p + 'Host', '8.8.8.8')
        ifac = pmap.get(p + 'Interface', '')
        cmd = 'ping %s repeat %s timeout %s size %s' % (host, reps, timeout, size)
        if ifac:
            cmd += ' source %s' % ifac

        ping_res = t.get(cmd, timeout=timeout * reps + 1)

        state = None
        try:
            for line in ping_res.split('\n'):
                if 'Success rate is' in line:
                    line = line.strip()
                    res = line.rsplit('=')[1].replace('ms', '').strip()
                    res_min, avg, res_max = res.split('/')
                    sc = int(line.split(',', 1)[0].split('/')[-1].replace(')', ''))
                    fc = reps - sc
                    state = 'Completed'
        except:
            pass
        finally:
            if not state:
                res_min = avg = res_max = sc = 0
                fc = reps
                if 'Translating' in ping_res and not '[OK]' in ping_res:
                    state = 'Error_CannotResolveHostName'
                else:
                    state = 'Error_Internal'
        c['.IP.Diagnostics.IPPing.DiagnosticsState']    = state
        c['.IP.Diagnostics.IPPing.FailureCount']        = fc
        c['.IP.Diagnostics.IPPing.Host']                = host
        c['.IP.Diagnostics.IPPing.Interface']           = ifac
        c['.IP.Diagnostics.IPPing.MaximumResponseTime'] = "%s ms" % res_max
        c['.IP.Diagnostics.IPPing.MinimumResponseTime'] = "%s ms" % res_min
        c['.IP.Diagnostics.IPPing.NumberOfRepetitions'] = reps
        c['.IP.Diagnostics.IPPing.SuccessCount']        = sc
        c['.IP.Diagnostics.IPPing.AverageResponseTime'] = "%s ms" % avg
        c['.IP.Diagnostics.IPPing.Timeout']             = timeout





    def GPV_IP_Diagnostics(self, t):
        """ not yet... """
        print 'GPV'
        c = t.session_cache
        state = c.get('.IP.Diagnostics.IPPing.DiagnosticsState')
        if not state:
            # should not happen, we DONT keep ping results forever, just do
            # defaults now, sync:
            self.diagnostics_ping(t, {})



    def GPV_Ethernet(self, t):
        depends('build_dev2_ifs', t)


    def GPV_IP(self, t):
        depends('build_dev2_ifs', t)

    def GPV_DNS(self, t):
        c = t.session_cache
        depends('build_dev2_ifs', t)
        nfos = c['nfos']
        run = depends('show run', t)
        ns = []
        for part in run.split('ip name-server ')[1:]:
            ns.append(part.split('\n', 1)[0].strip())

        tr = '.DNS.'
        c[tr + 'SupportedRecordTypes'] = 'A,AAA,SRV,PTR'
        tr += 'Client.'
        c[tr + 'ServerNumberOfEntries'] = len(ns)
        if ns:
            c[tr + 'Status'] = 'Enabled'
            i = 0
            for dns in ns:
                i += 1
                c[tr+'Server.%s.DNSServer' % i] = dns
                c[tr+'Server.%s.Status' % i] = 'Enabled'
                c[tr+'Server.%s.Type' % i] = 'Static'
                self.insert_iface(tr, dns, t)
        else:
            c[tr + 'Status'] = 'Disabled'



    def GPV_DSL(self, t):
        depends('build_dev2_ifs', t)
        c = t.session_cache
        ifs, nfos, ip_brief, arp = depends('show_ip_int', t)
        stack = c['stack']
        index = 0
        for dsl in stack['DSL.Line']:
            index += 1
            tr = '.DSL.Line.%s.' % index
            l_if = dsl['l_if']
            lm = nfos[l_if]
            u_if = dsl['u_if']
            um = nfos[u_if]
            dsl_infos = depends('show dsl interface %s' % l_if, t)
            c[tr + 'Name'] = l_if
            c[tr + 'Upstream'] = True
            c[tr + 'StandardUsed'] = get_line_val(dsl_infos, 'DSL Mode:')
            c[tr + 'UpstreamMaxBitRate'] = 0
            c[tr + 'DownstreamMaxBitRate'] = 0
            try:
                encoding = lm['runcfg'].split('dsl operating-mode ',
                    1)[1].splitlines()[0]
                if '-' in encoding:
                    encoding = encoding.rsplit('-', 1)[1]
            except:
                encoding = 'n.a.'
            modem_status = get_line_val(dsl_infos, 'Modem Status:')
            if 'show' in modem_status.lower():
                c[tr + 'Status'] = 'Up'
                c[tr + 'LineEncoding'] = encoding.upper()
                # no idea:
                c[tr + 'AllowedProfiles'] = ''
                c[tr + 'CurrentProfile'] = ''
                noise =  get_line_val(dsl_infos, 'Noise Margin:').split()
                c[tr + 'UpstreamNoiseMargin'] = float(noise[2])
                c[tr + 'DownstreamNoiseMargin'] = float(noise[0])
                attn =  get_line_val(dsl_infos, 'Attenuation:').split()
                c[tr + 'UpstreamAttenuation'] = float(attn[2])
                c[tr + 'DownstreamAttenuation'] = float(attn[0])
                powe =  get_line_val(dsl_infos, 'Output Power:').split()
                c[tr + 'UpstreamPower'] = float(powe[2])
                c[tr + 'DownstreamPower'] = float(powe[0])
                self.set_stats(c, tr, lm)

            else:
                c[tr + 'Status'] = 'Down'
            c[tr + 'Stats.Total.ErroredSecs'] = 0
            c[tr + 'Stats.Total.SeverelyErroredSecs'] = 0

            tr = '.DSL.Channel.%s.' % index
            c[tr + 'Name'] = u_if
            status = ('Up', 'Down')['down' in get_line_val(dsl_infos,
                                                    'Modem Status:').lower()]
            c[tr + 'Status'] = status

            if not status == 'Down':
                speed =  get_line_val(dsl_infos, 'Speed (kbps):').split()
                if not len(speed) == 4:
                    speed = (0,0,0,0)
                c[tr + 'UpstreamCurrRate'] = speed[2]
                c[tr + 'DownstreamCurrRate'] = speed[0]
                if speed[2] == '0':
                    # data path = fast:
                    c[tr + 'UpstreamCurrRate'] = speed[3]
                    c[tr + 'DownstreamCurrRate'] = speed[1]
                self.set_stats(c, tr, um)

                tr += 'Stats.Total.'
                try:
                    fec = get_line_val(dsl_infos, 'Noise Margin:').split()
                    if len(fec) != 2:
                        fec = (fec[0], fec[2])
                    fec = (float(fec[0]), float(fec[1]))
                except:
                    fec = (0,0)
                try:
                    hec = get_line_val(dsl_infos, 'ES Errors:').split()
                    if len(hec) != 2:
                        hec = (hec[0], hec[2])
                    fec = (float(hec[0]), float(hec[1]))
                except:
                    hec = (0,0)
                try:
                    crc = get_line_val(dsl_infos, 'CRC Errors:').split()
                except:
                    crc = (0,0,0,0)
                c[tr + 'XTURFECErrors'], c[tr + 'XTURFECErrors'] = fec
                c[tr + 'XTURHECErrors'], c[tr + 'XTUCHECErrors'] = hec
                if crc[0]:
                    c[tr + 'XTURCRCErrors'], c[tr + 'XTUCCRCErrors'] = crc[0], crc[2]
                else:
                    c[tr + 'XTURCRCErrors'], c[tr + 'XTUCCRCErrors'] = crc[1], crc[3]
        c['.DSL.LineNumberOfEntries'] = index
        c['.DSL.ChannelNumberOfEntries'] = index


    def GPV_ATM(self, t):
        depends('build_dev2_ifs', t)
        c = t.session_cache
        ifs, nfos, ip_brief, arp = depends('show_ip_int', t)
        stack = c['stack']
        index = 0
        for atm in stack['ATM.Link']:
            index += 1
            tr = '.ATM.Link.%s.' % index
            l_if = atm['l_if']
            lm = nfos[l_if]
            u_if = atm['u_if']
            um = nfos[u_if]
            status = um['Status']
            c[tr + 'Status'] = ['Down', 'Up'][status]
            c[tr + 'Name'] = u_if
            c[tr + 'LowerLayers'] = 'Device.DSL.Channel.%s' % (atm['lower'] + 1)
            # wild guess:
            runcfg = um['runcfg']
            if 'ip address' in runcfg:
                c[tr + 'LinkType'] = 'IPoA'
            for line in runcfg.splitlines():
                if line.strip().startswith('pvc '):
                    c[tr + 'DestinationAddress'] = line.strip().split('pvc ')[1]
            c[tr + 'AAL'] = lm.get('Encapsulation', '')
            self.set_stats(c, tr, um)
        c['.ATM.LinkNumberOfEntries'] = index



    def GPV_PPP(self, t):
        depends('build_dev2_ifs', t)
        c = t.session_cache
        ifs, nfos, ip_brief, arp = depends('show_ip_int', t)
        stack = c['stack']
        index = 0
        for ppp in stack['PPP.Interface']:
            index += 1
            tr = '.PPP.Interface.%s.' % index
            l_if = ppp['l_if']
            lm = nfos[l_if]
            c[tr + 'Status'] = ['Down', 'Up'][lm['Status']]
            c[tr + 'Name'] = ppp['u_if']
            c[tr + 'LowerLayers'] = self.get_lower_layers(tr, c)
            self.set_stats(c, tr, lm)
        c['.PPP.InterfaceNumberOfEntries'] = index


    def GPV_WiFi(self, t):
        depends('build_dev2_ifs', t)
        c = t.session_cache
        ifs, nfos, ip_brief, arp = depends('show_ip_int', t)
        stack = c['stack']
        index = 0
        for wifi in stack['WiFi.Radio']:
            # Dot11Radio 1 does not exist
            """
            controller = depends('show controllers Dot11Radio %s | i Current' \
                                 % index, t)
            """
            controller = depends('show controllers Dot11Radio 0 | i Current', t)
            index += 1
            tr = '.WiFi.Radio.%s.' % index
            l_if = wifi['l_if']
            lm = nfos[l_if]
            if 'shutdown' in nfos[wifi['u_if']]['runcfg']:
                status = 'Down'
            else:
                status = 'Up'
            c[tr + 'Status'] = status

            if status == 'Up':
                c[tr + 'Enable'] = True
            else:
                c[tr + 'Enable'] = False
            c[tr + 'Name'] = wifi['u_if']
            c[tr + 'Upstream'] = False
            freq, mhz, channel, chr = get_line_val(controller,
                                         'Current Frequency:').split()[:4]
            if freq.startswith('2'):
                c[tr + 'OperatingFrequencyBand'] = '2.4GHz'
                c[tr + 'OperatingStandards'] = 'g,b'

            else:
                c[tr + 'OperatingFrequencyBand'] = '5GHz'
                c[tr + 'OperatingStandards'] = 'a,n'

            c[tr + 'Channel'] = chr
            c[tr + 'AutoChannelSupported'] = True
            c[tr + 'AutoChannelEnable'] = False
            self.set_stats(c, tr, lm)
        c['.WiFi.RadioNumberOfEntries'] = index
        index = 0
        for ssid in stack['WiFi.SSID']:
            index += 1
            imap = nfos[ssid['u_if']]
            status = 'Up'
            if 'shutdown' in imap['runcfg']:
                status = 'Down'
            tr = '.WiFi.SSID.%s.' % index
            c[tr + 'Enable'] = True
            c[tr + 'Status'] = status
            c[tr + 'Name'] = ssid['ssid']
            c[tr + 'LowerLayers'] = self.get_lower_layers(tr, c)
            c[tr + 'BSSID'] = imap['MAC']
            c[tr + 'MACAddress'] = imap['MAC']
            c[tr + 'SSID'] = ssid['ssid']
            stats_if = imap
            if not 'rx_packets' in stats_if:
                try:
                    stats_if = nfos[ssid['l_if']]
                except:
                    pass


            self.set_stats(c, tr, stats_if)
            wstr = tr
            tr = '.WiFi.AccessPoint.%s.' % index
            trap = tr
            umap = nfos[ssid['l_if']]
            c[tr + 'Status'] = status
            c[tr + 'Enable'] = umap['Enable']
            c[tr + 'SSIDReference'] = 'Device.' + wstr[1:-1]
            cfg = ssid['cfg']
            if 'authentication open' in cfg:
                c[tr + 'SSIDAdvertisementEnabled'] = True
            else:
                c[tr + 'SSIDAdvertisementEnabled'] = False
            tr = tr + 'Security.'
            vlannr = ssid['cfg'].split('vlan ')[1].split('\n')[0]
            c[tr + 'ModesSupported'] = 'None,WEP-64,WEP-128,WPA-Personal,WPA2-Personal'
            c[tr + 'WEPKey'] = ''
            c[tr + 'PreSharedKey'] = ''
            c[tr + 'KeyPassphrase'] = ''
            mode = 'None'
            for line in umap['runcfg'].splitlines():
                if '40bit' in line and 'vlan ' + vlannr in line:
                    mode = 'WEP-64'
                    break
                elif '128bit' in line and 'vlan ' + vlannr in line:
                    mode = 'WEP-128'
                    break
            if mode == 'None':
                key_mgmt = get_line_val(cfg, 'authentication key-management').upper()
                if 'WPA VERSION 2' in key_mgmt:
                    mode = 'WPA2-Personal'
                elif 'WPA' in key_mgmt:
                    mode = 'WPA-Personal'
                passp = get_line_val(cfg, 'wpa-psk ascii ').strip()
                if passp:
                    if passp.startswith('7 '):
                        passp = self.decrypt7(passp[2:])
                    c[tr + 'KeyPassphrase'] = passp
            else:
                passp = umap['runcfg'].split('bit ')[-1]
                passp = passp.split(' transmit-key')[0]
                if passp:
                    if passp.startswith('7 '):
                        passp = self.decrypt7(passp[2:])
                c[tr + 'WEPKey'] = passp.encode('hex')
            c[tr + 'ModeEnabled'] = mode

            tr = tr.replace('Security', 'AssociatedDevice')
            assocs = depends('get_wifi_assocs', t)
            i = 0
            if 'assocs' in ssid:
                for ip, v in ssid['assocs'].items():
                    i += 1
                    mac = v.get('MAC')
                    auth = v.get('state')
                    if auth == 'Assoc':
                        auth = True
                    else:
                        auth = False
                    c[tr + str(i) + '.MACAddress'] = mac.replace('-', ':')
                    c[tr + str(i) + '.AuthenticationState'] = auth
            c[trap + 'AssociatedDeviceNumberOfEntries'] = i
        c['.WiFi.SSIDNumberOfEntries'] = index
        c['.WiFi.AccessPointNumberOfEntries'] = index




    def GPV_DHCPv4_Server(self, t):
        c = t.session_cache
        depends('build_dev2_ifs', t)
        nfos, ifs = c['nfos'], c['ifs']
        pools = self.parse_dhcp(t)
        index = 0
        order = 0
        c['.DHCPv4.Server.Enable'] = False
        for name, pool in pools.items():
            order += 1
            m = pool
            c['.DHCPv4.Server.Enable'] = True
            index += 1
            tr = '.DHCPv4.Server.Pool.%s.' % index
            c[tr + 'Alias'] = 'cpe-%s' % name
            # FIXME - check
            c[tr + 'Enable']     = True
            put(c, tr, 'DomainName', m, 'DomainName')
            put(c, tr, 'DNSServers', m, 'DNSServers')
            put(c, tr, 'IPRouters' , m, 'IPRouters' )
            put(c, tr, 'MinAddress', m, 'MinAddress')
            put(c, tr, 'MaxAddress', m, 'MaxAddress')
            put(c, tr, 'SubnetMask', m, 'SubnetMask')
            put(c, tr, 'LeaseTime' , m, 'DHCPLeaseTime')
            c[tr + 'Order'] = order
            c[tr + 'Interface'] = ''
            # find the interface:
            for i in xrange(1, len(c['stack']['IP.Interface'])+1):
                try:
                    ip = c['.IP.Interface.%s.IPv4Address.1.IPAddress'  % i]
                    if self.ip_in_pool(IP(ip), pool):
                        c[tr + 'Interface'] = 'Device.IP.Interface.%s' % i
                        # nice to see:
                        c[tr + 'X_AXIROS_COM_InterfaceName'] = \
                        c['stack']['IP.Interface'][i-1]['u_if']
                except:
                    # no ip address set:
                    pass

        c['.DHCPv4.Server.PoolNumberOfEntries'] = index



# -------------------------------Helpers
    def ip_in_pool(self,ip, pool):
        ipmin = int(IP(pool['MinAddress']))
        ipmax = int(IP(pool['MaxAddress']))
        if ipmin <= int(ip) and int(ip) <= ipmax:
            return 1

    def parse_dhcp(self, t):
        run = depends('show_run', t)
        pools = {}
        for pool_block in self.parse_run_blocks('ip dhcp pool', run):
            try:
                new_pool = {}
                pool = pool_block.splitlines()
                pool_name = pool[0].strip().rsplit(' ',1)[1]
                for line in pool[1:]:
                    line = line.strip()
                    if line.startswith('network'):
                        new_pool['SubnetMask'] = line.split(' ')[-1].strip()
                        address = line.split(' ')[1].strip()
                        ip = IPNetwork(address + '/' + new_pool['SubnetMask'])
                        new_pool['MaxAddress'] = (IP(ip.last) - 1).__str__()
                        new_pool['MinAddress'] = (IP(ip.first) + 1).__str__()
                    elif line.startswith('default-router'):
                        new_pool['IPRouters'] = \
                            line.split('default-router ')[1].replace(' ', ',')
                    elif line.startswith('domain-name'):
                        new_pool['DomainName'] = line.split(' ')[-1]
                    elif line.startswith('dns-server'):
                        new_pool['DNSServers'] = \
                                line.split('dns-server ')[1].replace(' ', ',')
                    elif line.startswith('lease'):
                        # lease {days [hours][minutes] | infinite}
                        if 'infinite' in line:
                            new_pool['DHCPLeaseTime'] = 'infinite'
                        else:

                            lease_t = line.split()+['0', '0']
                            days  = lease_t[1]
                            hours = lease_t[2]
                            mnt   = lease_t[3]
                            new_pool['DHCPLeaseTime'] = int(days) * 86400 + \
                                int(hours) * 3600 + int(mnt) * 60
                    if not new_pool.get('DHCPLeaseTime'):
                        # cisco default is a day:
                        new_pool['DHCPLeaseTime'] = 86400


                pools[pool_name] = new_pool
            except IndexError:
                continue
        t.session_cache['pools'] = pools
        return pools
        """ the pools dict should be like this(keys are the pool names):
            {
              '1': {'SubnetMask': '255.255.0.0',
                    'IPRouters': '172.16.1.100,172.16.1.101',
                    'DomainName': 'axiros.com',
                    'DNSServers': '172.16.1.102,172.16.2.102',
                    'MinAddress': '172.16.0.1',
                    'MaxAddress': '172.16.255.254'
                    },
              '192.168.2.0/24': {'DomainName': 'ssg-test.local',
                    'IPRouters': '192.168.2.254',
                    'DHCPLeaseTime': '1800',
                    'SubnetMask': '255.255.255.0',
                    'DNSServers': '192.168.1.1',
                    'MinAddress': '192.168.2.1',
                    'MaxAddress': '192.168.2.254'
              }
            }
        """



    def GPV_NAT(self, t):
        """
        test_C877_BRM#show ip nat translations
        Pro Inside global         Inside local          Outside local         \
                                                                Outside global
        tcp 5.55.224.4:889        192.168.1.10:80       ---                   \
                                                                ---
        tcp 62.38.95.90:389       192.168.1.11:389      ---
        tcp 5.55.224.4:3389       192.168.1.11:3389     10.5.80.225:4184
        tcp 5.55.224.4:3389       192.168.1.11:3389     ---
        test_C877_BRM#
        """
        c = t.session_cache
        depends('build_dev2_ifs', t)
        nfos, ifs = c['nfos'], c['ifs']
        res = []
        index = 0
        cmd = 'show ip nat translations'
        natl = depends(cmd, t)
        outs = []
        for line in lines(natl):
            l = line.split()
            if len(l) < 4 or cmd in line:
                continue
            if 'Inside' in line:
                # header:
                continue
            if l[3].replace('-', ''):
                # no outside nat supported:
                continue
            index += 1
            for i in (1,2):
                if not ':' in l[i]:
                    l[i] += ':0'
            outip, outport = l[1].split(':')
            inip,  inport  = l[2].split(':')
            if outip not in outs:
                outs.append(outip)
                tr = '.NAT.InterfaceSetting.%s.' % index
                c[tr + 'Enable'] = True
                c[tr + 'Status'] = 'Enabled'
                self.insert_iface(tr, outip, t)
            tr = '.NAT.PortMapping.%s.' % index
            c[tr + 'Enable'] = True
            self.insert_iface_portmapping(tr, outip, t)
            c[tr + 'RemoteHost'] = outip
            # Lease duration 0 for static port forwards
            c[tr + 'LeaseDuration'] = 0
            c[tr + 'ExternalPort'] = outport
            c[tr + 'InternalPort'] = inport
            c[tr + 'InternalClient'] = inip
            c[tr + 'Description'] = ('%s:%s->%s:%s' % (outip, outport,
                                    inip, inport)).replace(':0', ':*')
            if l[0].lower() == 'tcp':
                c[tr + 'Protocol'] = 'TCP'
            elif l[0].lower() == 'udp':
                c[tr + 'Protocol'] = 'UDP'
            else:
                c[tr + 'Protocol'] = 'TCP,UDP'
        c['.NAT.InterfaceSettingNumberOfEntries'] = len(outs)
        c['.NAT.PortMappingNumberOfEntries'] = index


    def insert_iface_portmapping(self, tr, ip, t):
        c = t.session_cache
        nfos = c['nfos']
        for ifmap in nfos.values():
            if ifmap.get('IP') == ip:
                c[tr + 'X_AXIROS_COM_InterfaceName'] = ifmap['Name']
                put(c, tr, 'Interface', ifmap, 'tr181_ip_int')

    def insert_iface(self, tr, ip, t):
        c = t.session_cache
        nfos = c['nfos']
        ifmap = get_ifmap_by_ip(ip, nfos)
        if ifmap:
            c[tr + 'X_AXIROS_COM_InterfaceName'] = ifmap['Name']
            put(c, tr, 'Interface', ifmap, 'tr181_ip_int')


    def add_host(self, t, dhcp, nfos, hind, active_hosts,
                 ip, mac, adds=None, ltr=None, active=True):
        # don't relay on ls[-1], check IP:
        c = t.session_cache
        clockts = depends('parse_clock', t)
        ifmap = get_ifmap_by_ip(ip, nfos)
        if not ifmap:
            return hind
        hind += 1
        tr = '.Hosts.Host.%s.' % hind
        l3 = ifmap['Name']
        c[tr + 'X_AXIROS_COM_InterfaceName'] = l3
        put(c, tr, 'Layer3Interface', ifmap, 'tr181_ip_int')
        mac = EUI(mac)
        # loweest layer:
        l1 = None
        for imap in nfos.values():
            smac = str(mac)
            if imap.get('MAC') == smac and 'Ether' in imap.get('Name', ''):
                l1 = imap.get('Name')
                break
        if not l1:
            # get it from the stack table:
            for ipm in c['stack']['IP.Interface']:
                if ipm['u_if'] == ifmap['Name']:
                    try:
                        l1 = ipm['l_if']
                    except:
                        pass

        c[tr + 'X_AXIROS_COM_L1_InterfaceName'] = l1
        try:
            l1n = self.get_index(c['stack'], l1, 'Ethernet.Interface')
        except:
            try:
                l1n = self.get_index(c['stack'], l1, 'WiFi.Radio')
            except:
                l1n = ''

        c[tr + 'Layer1Interface'] = 'Device.' + l1n
        c[tr + 'PhysAddress'] = str(mac).replace('-', ':')
        try:
            oname = mac.info.OUI.org.replace(' ','')
        except:
            oname = 'Unkown'
        c[tr + 'HostName'] = 'Org: ' + oname
        c[tr + 'IPAddress'] = ip
        if active:
            c[tr + 'Active'] = True
        else:
            c[tr + 'Active'] = False
        if adds:
            c[tr + 'AddressSource'] = adds
        else:
            address_source = 'Static'
            lease_time_remaining = 0
            for row in dhcp.split('\n'):
                if row.startswith(ip):
                    tmp = row.split()[2:-1]
                    lease_expire = parse_timestr('%s %s %s %s' \
                            % (tmp[3], tmp[0], tmp[1], tmp[2]), '%H:%M %b %d %Y')
                    address_source = 'DHCP'
                    ltr = int(lease_expire - clockts)
                    break
            c[tr + 'AddressSource'] = address_source
        c[tr + 'LeaseTimeRemaining'] = ltr or 0
        active_hosts.append(ip)
        return hind

    def GPV_Hosts(self, t):
        #def GPV_Hosts(self, t, prefix, ifn, ip_brief, arp, layer2name):
        # ifn = 'FastEthernet0/1'
        """
        show arp
        Protocol  Address          Age (min)  Hardware Addr   Type   Interface
        Internet  10.0.0.253              4   0004.0d9b.a93f  ARPA   Vlan200
        Internet  10.0.0.254              -   8843.e184.8c82  ARPA   Vlan200
        Internet  94.93.26.177            -   8843.e184.8c82  ARPA   Vlan200
        Internet  94.93.26.178            -   8843.e184.8c82  ARPA   Vlan200
        Internet  94.93.26.179            -   8843.e184.8c82  ARPA   Vlan200
        Internet  172.16.1.1              -   8843.e184.8c82  ARPA   Vlan100
        Internet  172.16.1.2              0   8843.e184.8c9e  ARPA   Integrated-Service-En
        e0/0
        Internet  172.16.1.52            12   0021.a085.2f69  ARPA   Vlan100
        Internet  172.16.1.54            11   001e.4aa8.ff57  ARPA   Vlan100
        Internet  172.16.1.56            12   0024.9735.acce  ARPA   Vlan100
        Internet  172.16.1.58            35   001e.4aa9.2dd9  ARPA   Vlan100

        the vlan hw addr are the locals often !
        nets below to correct that.

        """
        c = t.session_cache
        ifs, nfos, ip_brief, arp = depends('show_ip_int', t)
        dhcp = depends('show ip dhcp binding', t)
        depends('build_dev2_ifs', t)
        hind = 0
        active_hosts = []
        int_by_ip = {}
        # first the arp ones:
        for line in arp.splitlines():
            active = True
            line = line.strip()
            if 'Incomplete' in line:
                continue
            ls = line.split()
            if not len(ls) == 6:
                continue
            if '-' in ls:
                active = False
            ip = ls[1]
            if ' %s ' % ip in ip_brief:
                # this is the cisco itself.
                continue
            hind = self.add_host(t, dhcp, nfos, hind, active_hosts, ip,
                    ls[3], active=active)

        # search for hosts no longer in the arp table but still in dhcp binding
        for row in dhcp.splitlines():
            # is ip, for sure there are better ways..
            cells = row.split()
            try:
                ip = IP(cells[0])
            except:
                continue
            ip = str(ip)
            if ip in active_hosts:
                continue

            hind = self.add_host(t, dhcp, nfos, hind, active_hosts,
                        ip, cells[1][-15].replace('.', ''), adds='DHCP', ltr=0)

        if c['stack']['WiFi.Radio']:
            assocs = depends('get_wifi_assocs', t)
            for host in assocs:
                if host['IP'] in active_hosts:
                    continue
                hind = self.add_host(t, dhcp, nfos, hind, active_hosts,
                   host['IP'], host.get('MAC', ''), adds='DHCP', ltr=0)
        c['.Hosts.HostNumberOfEntries'] = hind


    def get_wifi_assocs(self, t):
        wlan_hosts = depends('show dot11 associations', t)
        """
            802.11 Client Stations on Dot11Radio0:

            SSID [Cisco877] :

            IP address      Device        Name            Parent         State
            10.x.x.65      ccx-client    -               self           Assoc
            10.x.x.225     ccx-client    -               self           Assoc
            10.x.x.239     4800-radio    abc123          self           Assoc
            10.x.x.127     4800-radio    abc123          self           Assoc

            r-05513058904#
        """
        c = t.session_cache
        ssids =  c['stack']['WiFi.SSID']
        associated_hosts = []
        if not 'State' in wlan_hosts:
            return {}
        m = None
        curssid = ''
        for line in wlan_hosts.splitlines():
            if line.strip().startswith('SSID'):
                m = None
                for ssidm in ssids:
                    ssid = ssidm['ssid']
                    if '[%s]' % ssid in line:
                        m = ssidm
                        m['assocs'] = {}
                        break
            if not m:
                continue
            mac = ''
            cells = line.split()
            # someties with mac sometimes not
            try:
                ip = str(IP(cells[0]))
            except:
                try:
                    ip = str(IP(cells[1]))
                    mac = str(EUI(cells[0]))
                except:
                    continue
            im = {'MAC': mac, 'IP': ip, 'state': cells[-1]}
            m['assocs'][ip] = im
            associated_hosts.append(im)
        return associated_hosts



    def build_stack(self, t):
        """
        we work our way up from the ifs and then down from the ip ints:
        """

        c = t.session_cache
        depends('show_ip_int', t)
        nfos, ifs = c['nfos'], c['ifs']
        run = depends('show_run', t)
        eth_ifs     = []
        bridges     = []
        eth_links   = []
        atm_links   = []
        ip_ifs      = []
        dsl_lines   = []
        dsl_channels= []
        wifi_radios = []
        wifi_ssids  = []
        ppp_ifs     = []
        serial_ifs  = []

        stack = {'Ethernet.Interface'   : eth_ifs,
                 'DSL.Line'             : dsl_lines,
                 'DSL.Channel'          : dsl_channels,
                 'Bridge'               : bridges,
                 'Ethernet.Link'        : eth_links,
                 'ATM.Link'             : atm_links,
                 'IP.Interface'         : ip_ifs,
                 'WiFi.Radio'           : wifi_radios,
                 'WiFi.SSID'            : wifi_ssids,
                 'PPP.Interface'        : ppp_ifs,
                 'X_AXIROS_COM_CiscoSerialF.Interface': serial_ifs
                 }

        def extract_vlan_nfos(line, nfos):
            line = line.lower()
            id = None
            if 'spanning' in line:
                return None, None
            m = 'encapsulation dot1q (.*) .*|switchport .+ vlan (.*)|switchport mode (trunk)|bridge-group (.*)'
            group = re.search(m, line).group
            id = group(1) or group(2) or group(3) or group(4)
            if not id:
                return None, None
            for iface in nfos:
                if id == group(4):
                    if iface.lower() == 'bvi%s' % id:
                        return id, iface
                else:
                    if iface.lower() == 'vlan%s' % id:
                        return id, iface
            # create a pseudo one if not there:
            if id == group(4):
                return id, "!BVI%s" % id
            else:
                return id, '!Vlan%s' % id


        def upper(l, lower=None, lower_type=None, ifs=None):
            """ add an upper layer interface """
            # the lower gets us as upper:
            # we will have this position:
            l_if, u_if = ifs
            index = len(l)
            if lower:
                try:
                    lm = stack[lower_type][lower]
                except:
                    return None, None
                lm['up'] = index
                # get our type, for utype in the lower:
                for k, v in stack.items():
                    if v == l:
                        type = k
                lm['utype'] = type
                if not l_if:
                    l_if = lm['l_if']

            m = None
            if l is bridges:
                low = {'lower_type': lower_type, 'lower': lower,
                        'l_if': l_if, 'u_if': u_if}
                for b in bridges:
                    # how to find if the bridge is already there?
                    # we compare to u_if of bridge:
                    if b['lower'][0]['u_if'] == u_if:
                        m = b
                        # if you extend this list adapt write_row below:
                        # (when doing the bridges)
                        m['lower'].append(low)
                        m['bridge_exists'] = 1
                        break
            if m == None:
                # new one:
                m = {}
                if l is bridges:
                    m['lower'] = [low]
                else:
                    m['lower'] = lower
                    m['l_if'] = l_if
                    m['u_if'] = u_if
                l.append(m)
            m['ltype'] = lower_type
            return m, index


        def all_upper_bridge(lower, lower_type, ifs):
            """ add all up from a bridge port """
            mb, ib = upper(bridges, lower, lower_type, ifs)
            if 'bridge_exists' in mb:
                return mb, ib
            m1, i1 = upper(eth_links, ib, 'Bridge', ifs)
            m2, i2 = upper(ip_ifs, i1, 'Ethernet.Link', ifs)

        def add_upper_ip(lower, lower_type, ifs, lstat=None):
            """ all up w/o a bridge in between """
            m1, i1 = upper(eth_links, lower, lower_type, ifs)
            if lstat is not None:
                m1['link_status'] =  lstat
            m2, i2 = upper(ip_ifs, i1, 'Ethernet.Link', ifs)


        trunks = []
        ifaces = nfos.keys()
        ifaces.sort()
        for iface in ifaces:
            i_cfg = nfos[iface]['runcfg']
            # lowest and uppest:
            ifs = [iface, None]
            if 'Serial' in iface and not '.' in iface:
                u_if = (iface + '.1')
                if not u_if in nfos:
                    u_if = iface
                ifs[1] = u_if
                m, index = upper(serial_ifs, ifs=ifs)
                m1, i1 = upper(ppp_ifs, index, 'X_AXIROS_COM_CiscoSerialF.Interface',
                               ifs)
                m2, i2 = upper(ip_ifs, i1, 'PPP.Interface', ifs=ifs)


            if 'Ethernet' in iface:
                # we add the direct stack w/o bridge always since it can be
                # configured and is showing up in nfos:
                # so uppest is also iface:
                ifs[1] = iface
                m, index = upper(eth_ifs, ifs=ifs)
                lstat = nfos[iface].get('LinkStatus')
                add_upper_ip(index, 'Ethernet.Interface', ifs=ifs, lstat=lstat)

                if not i_cfg.strip():
                    # this is just configured, nothing on it:
                    # next one:
                    continue
                for line in i_cfg.splitlines():
                    if 'switchport' in line.lower() or 'bridge-group' in line.lower():
                        vlanid, vlan = extract_vlan_nfos(line, nfos)
                        if vlanid:
                            ifs[1] = vlan
                            if not vlanid == 'trunk':
                                all_upper_bridge(
                                    index,
                                    'Ethernet.Interface',
                                    ifs=ifs)
                            else:
                                trunks.append((index, ifs))

            if 'ATM' in iface:
                # ATM0.1 ?
                if not '.' in iface:
                    # currently one atm link per channel only:
                    # ATM0.1 :
                    u_if = iface + '.1'
                    if not u_if in nfos:
                        u_if = iface
                    ifs[1] = u_if
                    m, index = upper(dsl_lines, ifs=ifs)
                    # how to detect over ATM ?
                    m, index = upper(dsl_channels, index, 'DSL.Line', ifs=ifs)
                    m, index = upper(atm_links, index, 'DSL.Channel', ifs=ifs)
                    m, index = upper(ip_ifs, index, 'ATM.Link', ifs=ifs)

            if 'Dot11Radio' in iface:
                """ all ssids are on vlans:
                    r-05513058904(config)#interface Dot11Radio 0
                    r-05513058904(config-if)#ssid ax
                    r-05513058904(config-if-ssid)#exit
                    Dot11Radio0: SSID ax is not associated with a VLAN and will be disabled!
                    """
                bssids = depends('show dot11 bssid', t)

                if '.' in iface:
                    # we treat subints below:
                    continue
                # ssids on it:
                for line in bssids.splitlines():
                    cells = line.split()
                    if len(cells) == 0:
                        break
                    if not cells[0] == iface:
                        continue
                    ssid = cells[-1]
                    # for wifi we remember a few things for later:
                    block = 'dot11 ssid %s' % ssid
                    ssid_cfg = self.parse_run_block(block, t)
                    if 'vlan' in ssid_cfg:
                        vlannr = ssid_cfg.split(' vlan ')[1].split()[0]
                        # we assume the vlan in ssid cfg can be pointing to
                        # a .x radio  when native or to a real vlan:
                        for subint in xrange(10):
                            subiface = iface + '.%s' % subint
                            if not subiface in nfos:
                                continue
                            if 'encapsulation dot1Q %s' % vlannr in \
                               nfos[subiface]['runcfg']:
                                ipiface = subiface
                                break
                        """
                        if 'Vlan%s' % vlannr in nfos:
                            ipiface = 'Vlan%s' % vlannr
                        """
                        # now build stack ending in ipiface:
                        ifs = [iface, ipiface]

                        m_radio, index_radio = upper(wifi_radios, ifs=ifs)
                        m_ssid, index_ssid = upper(wifi_ssids, index_radio,
                                               'WiFi.Radio', ifs=ifs)
                        m_ssid['ssid'] = ssid
                        m_ssid['cfg'] = ssid_cfg
                        m_link, index_link = upper(eth_links, index_ssid,
                                               'WiFi.SSID', ifs=ifs)
                        m_ip, index_ip = upper(ip_ifs, index_link,
                                               'Ethernet.Link', ifs=ifs)


        for tun in c['ifs']['Tunnel']:
            ip_ifs.append({'u_if': tun})

        # do we have vlans w/o lower layers:
        for vlan in c['ifs']['Vlan']:
            covered = 0
            for ip_if in ip_ifs:
                if ip_if['u_if'] == vlan:
                    covered = 1
                    break
            if not covered:
                # are we a switch?
                vid = vlan.lower().replace('vlan', '')
                buf = depends('show vlan-switch id %s' % vid, t)
                try:
                    shortif = buf.replace('\r',
                            '').split('\n%s' % vid)[1].split('\n')[0].split()[-1]
                    ifn = shortif.upper().replace('FA',
                            'FastEthernet').replace('GI', 'GigabitEthernet')
                    pos = -1
                    for eif in eth_ifs:
                        pos += 1
                        if eif.get('l_if') == ifn:
                            lstatus = 0
                            if 'active' in buf:
                                lstatus = 1
                            eth_links.append({
                                'ltype': 'Ethernet.Interface',
                                'lower': pos,
                                'l_if': ifn,
                                'link_status': lstatus,
                                'u_if': vlan})
                            ip_ifs.append({
                                'u_if': vlan,
                                'l_if': ifn,
                                'ltype': 'Ethernet.Link',
                                'lower': len(eth_links)-1})

                except:
                    # no lower layers - make a trunk:
                    bridges.append({'no_lower_layers': 1,
                        'lower': [{'u_if': vlan}]})
                    eth_links.append({
                        'ltype': 'Bridge',
                        'lower': len(bridges)-1,
                        'u_if': vlan})
                    ip_ifs.append({
                        'u_if': vlan,
                        'ltype': 'Ethernet.Link',
                        'lower': len(eth_links)-1})
                    #ip_ifs.append({'u_if': vlan})

        # throw the trunk if into all vlans:
        for tr in trunks:
            for b in stack['Bridge']:
                if b.get('no_lower_layers'):
                    continue
                uppest = b['lower'][0]['u_if']
                lt = b['lower'][0]['lower_type']
                if lt == 'Ethernet.Interface' and \
                   'Vlan' in uppest:
                    b['lower'].append({'l_if': tr[1][0],
                                       'lower': tr[0],
                                       'u_if': uppest,
                                       'infos': 'trunk',
                                       'lower_type': lt})


        # create the interface stack:
        hl = '.InterfaceStack.%s.HigherLayer'
        ll = '.InterfaceStack.%s.LowerLayer'
        index = 0
        rowindex = 1
        def write_row(htype, hindex, rowindex, stack):
            """ write an entry in the stack table """
            grid, x, y = stack['grid'], stack['x'] + 1, stack['y']
            hobject = stack[htype][hindex]
            grid[(x, y)] = {'htype': htype, 'obj': hobject['u_if']}
            if not 'ltype' in hobject:
                # tunnel or so:
                return rowindex

            ltype, lindex = hobject['ltype'], hobject['lower']
            if ltype == None:
                # end recursion down:
                return rowindex
            c[hl % rowindex] = '%s.%s' % (htype, hindex+1)
            if ltype == 'Bridge':
                port = 1
                b = 'Bridging.Bridge.%s.Port.1' % (lindex + 1)
                c[ll % rowindex] = b
                x = x + 1
                grid[(x, y)] = {'htype': ltype, 'obj': b}
                x = x + 1
                if stack['Bridge'][lindex].get('no_lower_layers'):
                    return rowindex + 1
                for lower in stack['Bridge'][lindex]['lower']:
                    bltype, blindex = lower['lower_type'], lower['lower']
                    rowindex += 1
                    c[hl % rowindex] = 'Bridging.Bridge.%s.Port.1' % (lindex + 1)
                    port += 1
                    b = 'Bridging.Bridge.%s.Port.%s' % (lindex + 1, port)
                    grid[(x, y)] = {'htype': ltype, 'obj': b}
                    c[ll % rowindex] = b
                    rowindex += 1
                    c[hl % rowindex] = 'Bridging.Bridge.%s.Port.%s' % (lindex + 1, port)
                    c[ll % rowindex] = '%s.%s' % (bltype, blindex+1)
                    rowindex += 1
                    stack['x'] = x
                    stack['y'] = y
                    rowindex = write_row(bltype, blindex, rowindex, stack) - 1
                    y = stack['y'] + 1
                return rowindex + 1

            c[ll % rowindex] = '%s.%s' % (ltype, lindex+1)
            rowindex += 1
            stack['x'] = x
            return write_row(ltype, lindex, rowindex, stack)
        # visual stack:
        stack['x'] = 0
        stack['y'] = 0
        stack['grid'] = {}
        for i in xrange(len(ip_ifs)):
            stack['x'] = 0
            stack['y'] += 2
            rowindex = write_row('IP.Interface', i, rowindex, stack)

        c['.InterfaceStackNumberOfEntries'] = rowindex - 1
        c['stack'] = stack
        c['.X_AXIROS_COM.InterfaceStackGrid'] = self.draw_stack(t)
        self.draw_stack(t, 1)


    def draw_stack(self, t, do=None):
        if do:
            print '-' * 80
            print self.draw_stack(t)
            print '-' * 80
            return
        grid = t.session_cache['stack']['grid']
        ret = ''
        maxx = 0
        maxy = 0
        for x,y in grid:
            if x > maxx:
                maxx = x
            if y > maxy:
                maxy = y
        for y in range(maxy, 0, -1):
            for x in range(1, maxx+1):
                val = grid.get((x,y),'')
                vals = ''
                if val:
                    for v in val.values():
                        vals += str(v) + ':'
                ret += vals[:-1] + '\t'
            ret += '\n'
        return ret


    def GPV_Bridging(self, t):
        depends('build_bridge_stack', t)


    def build_bridge_stack(self, t):
        c = t.session_cache
        depends('build_stack', t)
        nfos = c['nfos']
        stack = c['stack']

        # Bridging:
        tr = '.Bridging.'
        c[tr + 'MaxBridgeEntries'] = 0
        c[tr + 'MaxDBridgeEntries'] = 0
        c[tr + 'MaxQBridgeEntries'] = 0
        bridges = len(stack['Bridge'])
        c[tr + 'BridgeNumberOfEntries'] = bridges
        rtr = '.Bridging.Bridge.%s.'
        for i in xrange(1, bridges+1):
            is_bvi = None
            no_lower_layers = 0
            if stack['Bridge'][i-1].get('no_lower_layers'):
                no_lower_layers = 1
            else:
                if 'BVI' in stack['Bridge'][i-1]['lower'][0]['u_if']:
                    is_bvi = 1
            tr = rtr % i
            m = stack['Bridge'][i-1]
            if no_lower_layers:
                ports = 1
            else:
                ports = len(m['lower']) + 1
            c[tr + 'Status'] = 'Enabled'
            c[tr + 'Standard'] = '802.1Q-2005'
            c[tr + 'PortNumberOfEntries'] = ports
            c[tr + 'VLANNumberOfEntries'] = 1
            if not is_bvi:
                c[tr + 'VLANPortNumberOfEntries'] = ports
            else:
                c[tr + 'VLANPortNumberOfEntries'] = 0
            if is_bvi and 0:
                # disabled, they need the Name and VlanID even for BVI
                for port in xrange(1, ports+1):
                    trp = tr + 'VLAN.%s.' % port
                    c[trp + 'VLAN'] = tr[1:] + 'VLAN.1'
                    c[trp + 'Port'] = tr[1:] + 'Port.%s' % (port + 1)
                    # no idea:
                    c[trp + 'Untagged'] = False
            else:
                # 1 vlan:
                name = m['lower'][0]['u_if']
                c[(tr) + 'VLAN.1.Name'] = name
                c[(tr) + 'VLAN.1.VLANID'] = name.lower().replace('vlan', '').replace('bvi', '')

            # .Port:
            for port in xrange(1, ports+1):
                trp = tr + 'Port.%s.' % port
                c[trp + 'Status'] = 'Up'
                if port == 1:
                    lname = m['lower'][0]['u_if']
                else:
                    lname = m['lower'][port-2]['l_if']
                c[trp + 'Name'] = lname
                if port == 1:
                    c[trp + 'ManagementPort'] = True
                else:
                    c[trp + 'ManagementPort'] = False
                if not no_lower_layers:
                    c[trp + 'LowerLayers'] = self.get_lower_layers(trp, c)
                # no idea
                c[trp + 'PortState'] = 'Forwarding'
                # no idea:
                c[trp + 'AcceptableFrameTypes'] = 'AdmitAll'
                # status:
                if port == 1:
                    statsif = m['lower'][0]['u_if']
                else:
                    statsif = m['lower'][port-2]['l_if']
                statsif = nfos.get(statsif, {})
                self.set_stats(c, trp, statsif)
        return stack


    def get_lower_layers(self, iface, c):
        ret = ''
        if iface.startswith('.'):
            iface = iface[1:]
        if iface.endswith('.'):
            iface = iface[:-1]
        for row in xrange(1, 1 + c['.InterfaceStackNumberOfEntries']):
            if c['.InterfaceStack.%s.HigherLayer' % row] == iface:
                ret += 'Device.' + c['.InterfaceStack.%s.LowerLayer' % row] +','
        if ret:
            ret = ret[:-1]
        return ret


    def get_index(self, stack, iface, type):
        ms = stack.get(type)
        for i in xrange(len(ms)):
            if ms[i]['l_if'] == iface:
                return '%s.%s' % (type, i + 1)
        raise Exception("interface not found %s" % iface)



    def build_dev2_ifs(self, t):
        stack = depends('build_bridge_stack', t)
        c = t.session_cache
        # don't run show run
        depends('show_ip_int', t)
        # first the FastEthernets:
        nfos, ifs = c['nfos'], c['ifs']
        links = {}
        # save in sessionmap:
        c['links'] = links
        serials = ifs['Serial']
        for iface in serials:
            if '.' in iface:
                continue
            m = nfos[iface]
            tr = '.%s.' % self.get_index(stack, iface, 'X_AXIROS_COM_CiscoSerialF.Interface')
            m['tr181'] = tr
            c[tr + 'Alias'] = 'cpe-%s' % iface
            c[tr + 'Name'] = iface
            c[tr + 'LowerLayers'] = ''
            c[tr + 'EncapsulationMethod'] = m.get('Encapsulation', 'n.a.')


        eth_ifs = ifs['FastEthernet']
        eth_ifs.extend(ifs['GigabitEthernet'])
        eth_ifs.extend(ifs['Ethernet'])
        for iface in eth_ifs:
            m = nfos[iface]
            tr = '.%s.' % self.get_index(stack, iface, 'Ethernet.Interface')
            # keep a ref to the model:
            m['tr181'] = tr
            c[tr + 'Alias']      = 'cpe-%s' % iface
            put(c, tr, 'DuplexMode',  m, 'Duplex', deflt='Auto')
            put(c, tr, 'Enable',      m,           deflt='Auto')
            put(c, tr, 'MACAddress',  m, 'MAC',    deflt='')
            status = 'Down'
            if m.get('Status', 0) == 1:
                status = 'Up'
            c[tr + 'Status'] = status
            speed = m.get('Speed', 'Auto')
            if 'auto' in str(speed).lower():
                speed = 0
            c[tr + 'MaxBitRate'] = speed
            c[tr + 'Name']       = iface
            c[tr + 'Upstream'] = self.is_upstream(m, c)
            self.set_stats(c, tr, m)
        c['.Ethernet.InterfaceNumberOfEntries'] = len(eth_ifs)

        # links. for now we build links 1:1 to ifs:
        type = 'Ethernet.Link'
        index = 0
        for i in xrange(len(stack.get(type))):
            m = stack[type][i]
            index = i + 1
            tr = '.Ethernet.Link.%s.' % index
            m['tr181'] = tr
            ll = self.get_lower_layers(tr, c)
            c[tr + 'LowerLayers'] = ll
            linkst = m.get('link_status')
            if linkst:
                c[tr + 'Status'] = ['Down', 'Up'][linkst]
            # stats we take those from the up if:
            iface = m.get('u_if')
            if iface and not iface.startswith('!'):
                self.set_stats(c, tr, nfos[iface])
                # if just one we take the stats from the lower layer:
        c['.Ethernet.LinkNumberOfEntries'] = index

        # vlans - we use for now VlanTermination table, not bridge.
        """
        # we don't do it currently:
        for iface in ifs['Vlan']:
            shvl = t.get('show vlan-switch brief')
            vlans = {}
            for vlan in ifs.get('Vlan'):
                # vlan like 'Vlan1'
                vnr = vlan.split('Vlan', 1)[1]
                ena = True
                try:
                    vnfos = shvl.split('\n%s ' % vnr)[1].split()
                except:
                    # the vlan is in show interfaces but not in here.
                    # use Enable = False
                    ena = False
                    vnfos = ['', 'Down']
                descr  = vnfos[0]
                status = vnfos[1]
                ifaces = []
                for iface in vnfos[2:]:
                    if iface.endswith(','):
                        iface = iface[:-1]
                    iface = iface.replace('Fa', 'FastEthernet')
                    if iface.isdigit() or iface.endswith('#'):
                        break # next vlan nr
                    ifaces.append(iface)
                vlans[vnr] = {'name'  : vlan,
                              'ena'   : ena,
                              'descr' : descr,
                              'status': status,
                              'ifaces': ifaces}
         (... - fill Ethernet.VLANTermination ....)
        """

        # ip interfaces:
        # we just parse ip int brief:
        ms = stack.get('IP.Interface')
        index = 0
        for i in xrange(len(ms)):
            index = i + 1
            # map from stack map:
            sm = ms[i]
            name = sm.get('u_if', sm.get('l_if'))
            m = nfos.get(name, {})
            m['tr181_ip_int'] = 'Device.IP.Interface.%s' % (i +1)
            ip = m.get('IP')
            up = False
            if ip:
                up = True
            tr = '.IP.Interface.%s.' % index
            c[tr + 'IPv4AddressNumberOfEntries'] = 0
            c[tr + 'IPv4Address.1.Enable']       = up
            if up:
                c[tr + 'IPv4Address.1.IPAddress']    = str(ip)
                c[tr + 'IPv4Address.1.Alias']        = 'cpe-%s-IP1' % name
                c[tr + 'IPv4Address.1.Status']       = m['Enable']
                c[tr + 'IPv4Address.1.SubnetMask']   = m['Netmask']
                c[tr + 'IPv4AddressNumberOfEntries'] = 1
            ip_sec = m.get('IPSecondary')
            if ip_sec:
                c[tr + 'IPv4Address.2.IPAddress']    = ip_sec
                c[tr + 'IPv4Address.2.Alias']        = 'cpe-%s-IP2' % name
                c[tr + 'IPv4Address.2.Status']       = m['Enable']
                c[tr + 'IPv4Address.2.SubnetMask']   = m['NetmaskSecondary']
                c[tr + 'IPv4AddressNumberOfEntries'] = 2
            c[tr + 'Name']                       = name
            c[tr + 'Enable']                     = m.get('Enable', False)
            c[tr + 'Alias']                      = 'cpe-%s'%  name
            c[tr + 'Loopback']                   = False
            c[tr + 'LowerLayers']                = self.get_lower_layers(tr, c)
            put(c, tr, 'MaxMTUSize', m, 'mtu')

            status = 'Down'
            if m.get('Status', 0) == 1:
                status = 'Up'
            c[tr + 'Status'] = status
            if not 'tx_bytes' in m:
                # use foo/0/1 in stead of foo/0/1.2 interface for stats:
                if 'tx_bytes' in nfos.get(name.split('.', 1)[0], {}):
                    m = nfos.get(name.split('.', 1)[0])
            self.set_stats(c, tr, m)

            if_type = 'Normal'
            c[tr + 'Type'] = if_type

        c['.IP.InterfaceNumberOfEntries'] = index
        #TODO: integrate in above code, remove copy paste..
        known_ifs = {}
        for ifname, ifdesc in c.get('nfos').items():
            if ifdesc.has_key('IP'):
                known_ifs[ifname] = ifdesc.get('IP')
        port_mappings = depends('show ip nat translations', t).split('\n')
        if len(port_mappings) <= 2:
            # no portmappings found
            return 1
        for pm in port_mappings[2:]:
            pm_conf = pm.split()
            if len(pm_conf) != 5:
                continue
            ext_ip = pm_conf[1]
            if ':' in ext_ip:
                ext_ip = ext_ip.split(':')[0]
            if ext_ip not in known_ifs.values():
                upstream = nfos.get(c.get('def_gw_if', {})).get('tr181_ip_int')
                ll =  c.get(upstream.replace('Device', '') + '.LowerLayers')
                # create new interface
                index = index + 1
                name = 'PortMapping_%s' % ext_ip
                tr = '.IP.Interface.%s.' % index
                c[tr + 'IPv4AddressNumberOfEntries'] = 0
                c[tr + 'IPv4Address.1.Enable']       = 1
                c[tr + 'IPv4Address.1.IPAddress']    = str(ext_ip)
                c[tr + 'IPv4Address.1.Alias']        = 'PortMapping__%s' % ext_ip
                c[tr + 'IPv4Address.1.Status']       = ''
                c[tr + 'IPv4Address.1.SubnetMask']   = '255.255.255.255'
                c[tr + 'IPv4AddressNumberOfEntries'] = 1
                c[tr + 'Name']                       = name
                c[tr + 'Enable']                     = 'Enable'
                c[tr + 'Alias']                      = 'cpe-%s'%  name
                c[tr + 'Loopback']                   = False
                c[tr + 'LowerLayers']                = ll
                c[tr + 'MaxMTUSize']                 = 0
                c[tr + 'Type']                       = 'Normal'
                known_ifs[name] = ext_ip
                nfos = c['nfos']
                iconf =  {'DiscardPacketsReceived': 0,
                'DiscardPacketsSent': 0,
                'Duplex': 'Auto',
                'Enable': True,
                'Encapsulation': '',
                'LinkStatus': 0,
                'MAC': '',
                'Name': name,
                'Netmask' : '255.255.255.255',
                'IP' : ext_ip,
                'Speed': 'Auto',
                'Status': 1,
                'bw_kb': 0,
                'ignored': 0,
                'mtu': 0,
                'runcfg': '',
                'rx_broadcasts': 0,
                'rx_bytes': 0,
                'rx_errors': 0,
                'rx_packets': 0,
                'tr181_ip_int': 'Device.IP.Interface.%s' % index,
                'tx_broadcasts': 0,
                'tx_bytes': 0,
                'tx_errors': 0,
                'tx_packets': 0}
                nfos[name] = iconf
                c['nfos'] = nfos
        return 1

add_model('cisco.IOS_DEV2', IOS_DEV2())

RUN = ""
