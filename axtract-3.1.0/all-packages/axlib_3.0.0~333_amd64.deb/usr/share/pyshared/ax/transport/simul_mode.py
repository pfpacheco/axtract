""""
Tools for running in simulation mode.
Used by model testers, hooked in by base.py

"""

from mock import MagicMock
import os


class MockConnObj(object):
    def __init__(self, t):
        self.t = t


def setup_simulation_mode(t):
    # the get commands received:
    t.got = []
    # t is a configured transport, not yet connected
    conn_obj = MockConnObj(t)
    t.open_connection = MagicMock(return_value=conn_obj)
    t.orig_communicate_meth = t.communicate
    t.communicate = simul_communicate
    t.check_simul_res = check_simul_res
    t.serve_flow = None
    # parsed served flows:
    flow_file = 'flows_' + getattr(t, 'flows_file', 'default')
    t.simul_flows_parsed = parse_flows(open(os.path.join(t.flows_dir, flow_file)).read())
    t.set_serve_flow = set_serve_flow
    t.close = t.close


def set_serve_flow(t, flow):
    """ a new flow is being served from the parsed ones.
    Vars are set before
    """
    t.simul_comm_step = 0
    if not flow in t.simul_flows_parsed:
        raise Exception("Flow %s not defined" % flow)
    t.flow_name = flow
    flow = t.simul_flows_parsed[flow]
    for k, v in flow[0].get('set').items():
        setattr(t, k, v)
    t.served_flow = flow




def simul_communicate(*l, **lw):
    return apply(_simul_communicate, l, lw)


def _simul_communicate(cmd, conn_obj, condition, err_con, timeout, **kwargs):
    err = ''

    # static method - we have put t here:
    t = conn_obj.t
    t.got.append((cmd, condition, kwargs))
    sf = t.served_flow[t.simul_comm_step]
    sf['run'] = 1
    rcv, send = sf['rcv'], sf['send']
    fs = 'Flow %s step %s' % (t.flow_name, t.simul_comm_step)
    t.simul_comm_step += 1
    if rcv == '':
        if not cmd == '/WAIT':
            err = "%s: Expected a /WAIT cmd" % fs

    elif rcv.startswith('t.'):
        rcv = getattr(t, rcv[2:])

        if not cmd == rcv:
            err  = "%s: Expected cmd %s, got %s" % (fs, cmd, rcv)
    if err:
        if t.enter_pdb_on_fail:
            print err
            from pprint import pformat
            print pformat(t.served_flow)
            # DONT delete pdb, this is wanted:
            import pdb; pdb.set_trace()
        raise Exception(err)
    return send




def close(t, *args, **kwargs):
    t.serve_flow = None
    t.simul_comm_step = 0
    t.got = []
    t.simul_flows_parsed = {}
    t.communicate = t.orig_communicate_meth


def check_simul_res(t, name):
    sf = t.simul_flows_parsed[name]
    for k, v in sf.items():
        if not 'run' in v or not v['run']:
            raise Exception("step %s in flow %s was not run" % (k, name))


def parse_flows(tflow):
    """
    parse a flow file into an serve_flow_map
    and reset comm steps
    tflow = total flow
    """
    clean_flow = ''
    for l in tflow.split('\n'):
        if not l.startswith('#---------'):
            clean_flow += l + '\n'

    def parse_send(send, setm):
        # line by line parsing:
        ret = []
        lines = send.strip().split('\n')
        for line in xrange(len(lines)):
            l = lines[line]
            if l.startswith('AX_SET: '):
                l = l.split('AX_SET: ', 1)[1]
                var, val = l.split(':', 1)
                while val.endswith('\\'):
                    # concat 2 lines, if \ at end:
                    val = val[:-1]
                    line += 1
                    val += lines[line]
                setm[var.strip()] = val.strip()
            else:
                ret.append(l)
        return '\n'.join(ret)

    m = {}
    cur_flow_def = None
    for flow_def in clean_flow.split('AX_FLOW_DEF'):
        if not flow_def.startswith(':'):
            # first one:
            continue
        cur_flow_def, flow = flow_def.split('\n', 1)
        cur_flow_def = cur_flow_def[1:].strip()
        fm = m
        defm = {}
        fm[cur_flow_def] = defm

        step = 0
        for lines in flow.split('AX_GET: '):
            if not lines:
                continue
            setm = {}
            if step == 0 and not flow.startswith('AX_GET'):
                rcv, send = '', lines
            else:
                rcv, send = lines.split('\n', 1)
            send = parse_send(send, setm)
            if not (send or rcv or step):
                # begin of a flow:
                continue
            defm[step] = {
                    'set': setm,
                    'send': send,
                    'rcv': rcv}
            step += 1
    return m


