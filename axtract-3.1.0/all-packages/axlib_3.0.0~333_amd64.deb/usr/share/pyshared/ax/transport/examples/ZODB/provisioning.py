def foo():
    from simplejson import dumps
    I = 'InternetGatewayDevice'
    c = container
    r = c.REQUEST
    cm = c.CPEManager
    ss = cm.AXServiceStorage
    for svc in ss.manage_getServices({'cid': r.get('cid')}): 
       ss.manage_delServiceById(svc.serviceid)
        
    f = r.form
    st = DateTime().millis()
    shost = r.get('HTTP_HOST', 'AXPAND')
    def do_return(status, msg, s={}):
        m = {}
        m['status'] = status
        m['status_des'] = msg
        ts = DateTime().millis()
        m['pt'] = ts - st
        m['ts'] = ts * 1000
        m['cnr_url'] = s['cnr_url']
        m['shost'] = shost
        #m.update(s)
        if status > 0:
            r.RESPONSE.setStatus(400, 'Error Code %s' % status)    
        return dumps(m)

    # convenience:
    if r.get('vip_reg', 0) == 'reg':
        vip_reg = 'http://77.238.10.226:10501/acs/'
    else:
        vip_reg = 'http://127.0.0.1:9675/proxy/CPEManager/CPEs/genericTR69'

    f['action'] = 'write_cpe'    
    f['vip_reg'] = vip_reg

    f['password'] = 'service'
    f['user'] = 'service'
    f['enable_pass'] = '@mprs643'
    f['port'] = 23
    f['host'] = '95.227.121.155'

    f['password'] = 'test'
    f['user'] = 'test'
    f['enable_pass'] = 'cisco'
    f['port'] = 11112
    f['host'] = 'aida.axiros.com'

    f['cid'] = r.get('cid', '1234')
    f['pii'] =  3600
    f['prov_code'] = r.get('prov_code', 'axunconfigured')
    #f['prov_code'] = 'aadf'


    missing = ''
    for i in ['action', 'vip_reg', 'cid', 'user', 'password', 'host', 'port']:
        if not i in f:
            missing += i + ', '
    if missing:
        missing = missing[:-2]
        plural = ''
        if ',' in missing:
            plural = 's'
        return do_return(10, 'Missing required parameter%s: %s' % (plural, missing)) 

    f['acs'] = f['vip_reg']
    f['cnr_url'] = 'http://46.51.174.182:7170/proxy/TI/NBI/CNR2?cid=%s' % f['cid']

    tr = {'.ManagementServer.PeriodicInformInterval': f['pii'],
          '.DeviceInfo.ProvisioningCode': 'axunconfigured',
          '.DeviceInfo.X_TELECOMITALIA_COM_Customerkey': f['cid'],
          '.DeviceInfo.X_TELECOMITALIA_COM_IPAddress': f['host'],
          '.WANDevice.1.WANConnectionDevice.1.WANIPConnection.1.ExternalIPAddress': f['host'],
          '.ManagementServer.ConnectionRequestURL': f['cnr_url']
          }
    tr = c.TR69Utils.pack_long69_to_short69(tr)      
          
          

    params = {}
    if  f['action'] == 'write_cpe':    
        f['cache'] = {}
        f['cache']['AXP'] = {}
        f['cache']['TR069'] = tr
        
        params = {'ServiceParameters': f, 'ServiceIdentifiers': {'cid': f['cid']}, 'CommandOptions': {}}
        ss.Interfaces.InterfaceMethods.activate_tr69_proxy(params, c.CPEManager, ss.log)
        return do_return(0, msg = 'added', s = f)
        
    return DateTime().millis()
