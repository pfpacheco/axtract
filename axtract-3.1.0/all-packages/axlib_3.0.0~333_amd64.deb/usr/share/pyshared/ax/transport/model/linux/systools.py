""" sys stats for linux model and jobhandler"""
try:
    import psutil
    import os
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    print "No psutil module installed - will not generate process stats"
    print "to add: apt-get install python-psutil"



def get_sys_stats():
    if not PSUTIL_AVAILABLE:
        return {}

    system_stats = {}
    process = psutil.Process(os.getpid())
    memory = process.get_memory_info()
    system_stats['memory'] = {
        'resident': memory[0],
        'virtual' : memory[1]
    }
    cpu_times = process.get_cpu_times()
    system_stats['proc_cpu'] = {
        'percent'    : process.get_cpu_percent(),
        'user_time'  : cpu_times[0],
        'system_time': cpu_times[1]
    }
    system_stats['system_cpu'] = {
        'percent': psutil.cpu_percent(),
        'times'  : psutil.get_system_cpu_times()
    }
    system_stats['system_memory'] = {
        'virtual': {
            'total'    : psutil.total_virtmem(),
            'used'     : psutil.used_virtmem(),
            'available': psutil.avail_virtmem()
        },
        'physical': {
            'total'    : psutil.TOTAL_PHYMEM,
            'used'     : psutil.used_phymem(),
            'available': psutil.avail_phymem()
        }
    }
    return system_stats

