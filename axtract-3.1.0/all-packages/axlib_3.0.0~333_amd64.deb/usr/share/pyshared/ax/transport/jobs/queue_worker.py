"""
Worker Thread for a queue based processing

"""
from thread import start_new_thread
from ast import literal_eval
from async import handle_async, safe_close
from cPickle import dumps as pickle
from cPickle import loads as unpickle
from ax.transport.flow_handling import run_flow
import threading
from ax.transport.axpand import get_transport_object
from zlib import compress
from ax.transport.jobs.axp_jobs import format_job_res, JOB_WAIT_EXPIRED
from time import time, ctime, sleep
from logging import DEBUG, INFO, WARN, getLogger
from ax.transport.model.linux.systools import get_sys_stats
from ax.utils.redis.client import RedisClient, ConnectionProblem


SYSTEM_STATS_KEY = 'SYS_STATS'

class JobFinished(Exception):
    # just to leave the flow,
    # avoiding to much nesting
    pass


# TODO: config mgmt job:
REDIS_DB = 10

# prevent recursion - max steps in a job:
MAX_STEPS = 10


JOB_STATUS_SUCCESS = 10
JOB_STATUS_FAILED  = 20

EXP_SMOOTH_FACTOR = 0.5
STATS = {'me': {}}


# this stores the process wide system layout:
# populated by the main thread:
SL = {'avpopdelay': 0}
REDIS0 = {}


SER_PICKLE = 1
SER_REPR   = 2
def serialize(obj, meth, job):
    if meth == SER_PICKLE:
        try:
            objstr = pickle(obj)
        except Exception ,ex:
            if isinstance(obj, dict) and 'res' in obj:
                # a via returned an object which can't be pickled - if so try
                # repr of it, w/o changing the obj:
                m = {}
                m.update(obj)
                m['res'] = repr(obj['res'])
                # the result contains an object which is not pickl-able:
                objstr = pickle(m)
    elif meth == SER_REPR:
        objstr = repr(obj)
    # no need to compress < MTU:
    if 'compress' in job and len(objstr) > 1000:
        objstr = compress(objstr)
    return objstr


def listen_pubsub(server, logger):
    """ there are some jobs sent pubsub style, like get stats """
    stats_expiry = SL['stats_expiry']
    stats_items  = SL['stats_items']
    stats_trunc  = int(stats_items * 0.2)
    r = RedisClient(host=server, db=REDIS_DB, cert=SL['cert'])
    for ret in r.pubsub_listen('ALLMQs'):
        ret = ret['data']
        p = r.pipeline()
        logger.log(INFO, 'received pubsub: %s' % ret)
        if ret == 'get_workers':
            # sender wants to know all processes listening:
            p.sadd('job_workers',
                ('%(qs_str)s:%(pid)s@%(hostname)s<-' % SL) + server)
            # quickly expire, jobs will follow on the proc queues:
            # and worker processes may stop meanwhile:
            p.expire('job_workers', 2)

        elif ret == 'send_stats':
            me = '%(pid)s@%(hostname)s' % SL
            my_sets = 'jobs_stats_' + me
            count = r.zcount(my_sets, '-inf', '+inf')
            if count > stats_items:
                # delete 20% entries:
                p.zremrangebyrank(my_sets, 0, stats_trunc)
            # we dump only the queue stats which have data:
            stats = {}
            for q, qm in SL['queues'].items():
                qs = qm['stats']
                if qs:
                    stats[q] = qs
            stats[SYSTEM_STATS_KEY] = get_sys_stats()
            p.zadd(my_sets, pickle(stats), int(time()))
            p.zadd('job_stats', my_sets, int(time()))
            p.expire('job_stats', stats_expiry)
            p.expire(my_sets, stats_expiry)
        p.execute()



class SyncWorker(object):
    """
    Picking packets from the queue and starting manage_packet
    on them
    """

    def __init__(self, server, mq, logger=None):
        """ mq = 'me' -> this is called from the job pusher directly,
        w.o redis. after init he calles run_inproc
        """
        self.stats_groups   = None
        self.mq             = mq
        self.get_log        = None
        self.server         = server
        if not mq == 'me':
            self.name = '%s@%s' %(mq, server)
            # we (re)connet with picks:
            self.conn           = None
        else:
            self.name = self.log_prefix = mq

        if not logger:
            self.logger = getLogger(self.name)
        else:
            self.logger = logger
        self.tstart = 0
        self.setup_stats_groups()
        # will be redis client first time we need it:
        self.conn = None
        self.http_proxy = SL.get('http_proxy')


    def setup_stats_groups(self):
        # stats groups:
        if self.mq == 'me':
            return
        sf = SL['stats_format']
        sgs = ()
        for sg in sf.split(','):
            sg = sg.strip()
            if not sg:
                continue
            if not ':' in sg:
                sg += ':'
            sg += ':' + sg
            sgs += (sg.split(':', 2),)
        # helper, for the workers::
        self.stats_groups = sgs
        self.my_stats = SL['queues'][self.mq]['stats']


    # convenience funcs:
    def log(self, level, msg):
        # millis since job start:
        ts = time()
        dt = ''
        if self.tstart:
            dt = int((ts - self.tstart) * 1000)
        if self.get_log:
            self.job_log += self.get_log % {'ts'    : ts,
                                            'ctime' : ctime(ts),
                                            'dt'    : dt,
                                            'msg'   : msg}
        if self.logger.isEnabledFor(level):
            msg = str(msg)
            self.logger.log(level, '%s\t%5s %s' % (self.log_prefix, dt, msg))

    def info(self, msg):
        return self.log(INFO, msg)

    def debug(self, msg):
        return self.log(DEBUG, msg)

    def warn(self, msg):
        return self.log(WARN, msg)


    def set_stats(self, job, job_str):
        """
        get correct stats group (under wich key we store stats in STATS map)
        and init / add that job
        """
        #naturally the server can force that group:
        sg = job.get('stats_group', 'auto')

        # this is the time it took to pop the job from the queue.
        # relies on time sync of the cluster (with redis 2.6 we will use
        # TIME in order to know the offset:

        if sg == 'auto':
            stgs = None
            for group in self.stats_groups:
                key, val, keyval = group
                if not val:
                    # plaintext match:
                    if val in job_str:
                        sg = key
                        break
                try:
                    stgs = stgs or job['settings']
                    if val == '*' and key in stgs:
                        sg = '%s:%s' % (key,  stgs[key])
                        break
                    elif val in stgs.get(key):
                        sg == keyval
                except:
                    continue
        # here we set our counters now:
        # setdefault is atomic:
        stats = self.my_stats.setdefault(sg, {'jobs'  : 0,
                                              'errors': 0,
                                              'avpt'  : 0})
        # not threadsafe - but in the end this is stats and the pt is long:
        stats['jobs'] += 1

        esf = EXP_SMOOTH_FACTOR
        popdelay = time() - job['pushts']
        SL['avpopdelay'] = esf * popdelay + (1-esf) * SL['avpopdelay']
        return stats


    def run_inproc(self, jobid, job):
        """ if job['wait' = 0 we block until done, no thread started
        wait not set: spawn thread run job, don't block
        wait > 0: spawn thread, block for max wait secs for response
        """
        wait = job.get('wait')

        if wait == None:
            # this reflects the push_job behaviour w/o wait argument:
            start_new_thread(self.run_job, (jobid, job,))
            return
        try:
            wait = float(wait)
            if wait < 0:
                raise
        except:
            raise Exception("wait not >= 0 or not a float: %s" % wait)
        ts = time()
        if wait == 0:
            # no thread and block:
            res = self.run_job(jobid, job)
        else:
            ev = threading.Event()
            start_new_thread(self.run_job, (jobid, job, ev))
            try:
                ev.wait(wait)
                res = getattr(ev, 'job_result')
            except:
                res = JOB_WAIT_EXPIRED
        res = format_job_res(res, ts)
        return res


    def run(self):
        """ just wrapping the exception, thread should never stop """
        if self.server == '-':
            self.logger.info('Not connecting to a server')
        while 1:
            try:
                if self.server == '-':
                    raise ConnectionProblem
                self.run_unsafe()
            except ConnectionProblem:
                # with the axiros client we get instant exceptions, so wait a
                # bit before the next try:
                sleep(1)
            except Exception, ex:
                self.logger.exception('%s' % ex)
            continue

    def run_unsafe(self):
        """ picking job from the queue, setting stats,
        calling run_job
        and handing where to signal the result

        'unsafe' since this one does not 100% guarantee no exception to happen.
        -> wrapped in def run, to keep the thread alive in any case.
        """
        if not self.conn:
            self.conn = RedisClient(host=self.server, db=REDIS_DB, cert=SL['cert'])
        jobid = self.conn.blpop(('CHK', self.mq))
        # the client had put in some timeing infos before:
        try:
            jobid = jobid[1].split(':', 2)[2]
        except:
            self.warn('job format error: %s' % str(jobid)[:100])
            return
        job_str = self.conn.lpop('job:%s' % jobid)

        self.debug('popped job %s' % jobid)
        if not job_str:
            self.info('job %s expired' % jobid)
            return
        try:
            job = unpickle(job_str)
            serialization = SER_PICKLE
            assert isinstance(job, dict)
        except:
            try:
                job = literal_eval(job_str)
                serialization = SER_REPR
                assert isinstance(job, dict)
            except:
                self.warn('job not well formatted %s' % job_str)
                return

        stats = self.set_stats(job, job_str)

        if self.mq == 'PH':
            # we are a proxy - insert a proxy if given:
            if self.http_proxy:
                settings = job.get('settings')
                if settings and not 'proxy' in settings:
                    settings['proxy'] = self.http_proxy

        job_res_map = self.run_job(jobid, job)

        status = job_res_map.get('status')
        if status == JOB_STATUS_FAILED:
            stats['errors'] += 1
        # average of job processing time, with exponential smoothing:
        esf = EXP_SMOOTH_FACTOR
        pt = job_res_map.get('pt')
        stats['avpt']    = esf * pt + (1-esf) * stats['avpt']

        # ---------- Sending back results?
        wait = job.get('wait')
        # typically a waiting client gets the full result, for others we
        # can say if we want status only for full result.
        # If even the waiting one wants the status only he must say:
        # 'status_only'
        push_status_only  = job.get('wait_status')
        set_result        = job.get('set_result')
        set_status        = job.get('set_status')
        set_result_basedb = job.get('set_result_basedb')

        if not (set_result_basedb or wait or set_result or set_status):
            # so this job was fire and forget
            del job_res_map
            job_res_map = None
            return

        # pipeline_actions stores all the actions on the pipeline before
        # the execute and acts like a journal and replays the actions
        # in case the connection to redis is gone and re-established
        pipeline_actions = []
        if wait and pt > int(wait):
            # wait timed out, no need to send:
            wait = None

        # when do we need full result:
        if set_result or (wait and not push_status_only) or set_result_basedb:
            job_res_full = serialize(job_res_map, serialization, job)

        if set_status or (wait and push_status_only):
            # delete the (big?) result:
            job_res_map['res'] = status
            job_res_status = serialize(job_res_map, serialization, job)

        if wait:
            wait_q = 'jobres_wait:%s' % jobid
            if push_status_only:
                pipeline_actions.append(('rpush', (wait_q, job_res_status)))
            else:
                # full res push:
                pipeline_actions.append(('rpush', (wait_q, job_res_full)))
            # client is popping on it:
            pipeline_actions.append(('expire', (wait_q, 1)))

        if set_result or set_status:
            res_key = 'jobresult:%s' % jobid
            if set_result:
                pipeline_actions.append(('set', (res_key, job_res_full)))
                pipeline_actions.append(('expire', (res_key, set_result)))
            else:
                pipeline_actions.append(('set', (res_key, job_res_status)))
                pipeline_actions.append(('expire', (res_key, set_status)))
            # wake up the already blocking clients, jobfin is ring:
            job_fin_str = 'jobfin:%s' % jobid
            pipeline_actions.append(('rpush', (job_fin_str, 1)))
            pipeline_actions.append(('expire', (job_fin_str, 1)))

        if pipeline_actions:
            p = self.conn.pipeline()
            for action, args in pipeline_actions:
                getattr(p, action)(*args)
            p.execute()

        if set_result_basedb:
            # full result into db0, with that timeout:
            res_key = 'jobresult:%s' % jobid
            REDIS0[self.server].set(res_key, job_res_full)
            REDIS0[self.server].expire(res_key, set_result_basedb)



    def run_job(self, jobid, job, ev=None):
        """ Running it here, incl. multistep handling
        called from redis popper thread or from run_sync """
        # put it in for now:
        p_jobid = jobid
        err_res = None

        t = None
        last_results = None
        if job.get('result_history'):
            last_results = []
        counter = 0
        #FIXME: self... not nice:
        self.tstart = time()
        # for inproc jobs, we log into this string:
        self.get_log = job.get('get_log')
        if self.get_log:
            self.job_log = ''

        self.log(INFO, 'Running %s' % str(job)[:500])
        res = 'n.a.'


        def treat_dynamic_args(new_job, job, res):
            """ inline jobs might refer to parent job's params and last result"""
            cmd  = new_job.get('cmd')
            is_flow = 0
            if cmd is None:
                cmd = new_job.get('flow')
                is_flow = 1
            kw = new_job.get('kw')
            if not kw:
                return cmd, {}, None, is_flow
            # if there are DYN values given, leave them dynamic, replace back
            # to this after run:
            orig_kw = None
            for arg, val in kw.items():
                if isinstance(val, (str, unicode)) and val.startswith('DYN:'):
                    # FIXME: security:
                    if not orig_kw:
                        orig_kw = {}
                        # deep?
                        orig_kw.update(kw)
                    kw[arg] = eval(val.split(':', 1)[1])
            return cmd, kw, orig_kw, is_flow


        def check_res(res):
            # does result contain a new instruction on existing t or a new job?
            if isinstance(res, dict):
                # is the endpoint wanting us to log stuff (given as tuples):
                # ((20, 'an info'), (30, 'a WARNING'))
                logs = res.get('logit')
                if logs and logs[0]:
                    if isinstance(logs[0], int):
                        logs = (logs,)
                    for line in logs:
                        self.log(line[0], line[1])


                if 'cmd' in res:
                    if res.get('settings') != None:
                        # a full new job:
                        return None, res
                    # a new command:
                    return res, None
            return None, None

        def do_run(t, job, p_job=None, res=None, is_next=None):
            # p_job: parent job
            if not p_job:
                p_job = job
            cmd, kw, orig, is_flow = treat_dynamic_args(new_job=job,
                                                        job=p_job, res=res)

            if cmd == 'get_stats':
                return t, SL, None, None

            if not is_flow and isinstance(cmd, (unicode, str)) and \
               cmd.startswith('static:'):
                # static function call, w/o transport.
                # basically just using a lib, w/o doing communication:
                from ax.transport.model.model_support import MODELS
                # just calling a function, no transport:
                try:
                    model = job['model']
                    model = MODELS[model]
                except Exception:
                    raise Exception("no model found: %s" % str(job)[:200])
                func = getattr(model, cmd.split('static:', 1)[1].strip())
                if not func:
                    raise Exception("function %s not in model %s" % (cmd, model))
                res = func(**kw)

            else:
                try:
                    if not t and cmd.startswith('/ASNC:'):
                        t, res = handle_async(job, cmd, SL, **kw)
                    else:
                        if not t:
                            t = get_transport_object(job.get('pool_id'),
                                        settings=job.get('settings', {}))
                        if is_flow:
                            res = run_flow(t, cmd)
                        else:
                            res = t.get(cmd, **kw)

                except Exception, ex:
                    # commmunication error, transport should be closed now:
                    try:
                        self.logger.exception('%s' % ex)
                    except:
                        print 'EXC!' * 100
                    safe_close(t, force_close=True)
                    raise ex


            if last_results != None:
                last_results.append(res)

            if orig:
                job['kw'] = orig
            if is_next:
                # inline transports we close immediatelly:
                safe_close(t)
            next_call, new_job = check_res(res)
            if not next_call and not new_job:
                next = job.get('next')
                # the next job can stop the inline calling by supplying
                # an empty next argument:
                if next != None:
                    next_call, new_job = check_res(next)
                else:
                    next_call, new_job = check_res(p_job.get('next'))
            return t, res, next_call, new_job


        try:
            while 1:
                counter += 1
                if counter > MAX_STEPS:
                    raise Exception("Recursion")
                t, res, next_call, new_job = do_run(t, job, res=res)

                if next_call:
                    job.update(next_call)
                    continue

                if new_job:
                    jobid= '%s-next[%s]' % (p_jobid, counter)
                    nt, res, next_call, new_job = do_run(None, new_job,
                                    p_job=job, res=res, is_next=1)
                    # if we got back a string or a status int, we consider
                    # the inline call to be completed:
                    if not isinstance(res, (str, unicode)) or \
                           isinstance(res, int):
                        if next_call:
                            job.update(next_call)
                            continue

                        if new_job:
                            counter += 1
                            safe_close(t)
                            t = None
                            jobid= '%s-next[%s]' % (p_jobid, counter)
                            job = new_job
                            continue

                # finished:
                status = JOB_STATUS_SUCCESS
                break

        except Exception, ex:
            status = JOB_STATUS_FAILED
            # transport errors have err_ids, we prepend it:
            try:
                estr = repr(ex)
                eattr = getattr(ex, 'err_id', -1)
            except:
                estr = 'unknown error'
                eattr = -1
            err_res = {'err': estr, 'err_id': eattr}

        safe_close(t)
        if getattr(t, 'test_auto_write', 0):
            try:
                t.write_testmap()
            except:
                pass

        job_res = {
            'pt'    : time() - self.tstart,
            'res'   : res,
            'count' : counter,
            'status': status,
            'jobid' : p_jobid,
            'start' : self.tstart,
            'worker': self.name}
        if err_res:
            job_res.update(err_res)
        self.tstart = 0
        if last_results != None:
            job_res['last_results'] = last_results


        if self.get_log:
            self.get_log = None
            job_res['job_log'] = self.job_log
            self.job_log = None

        if ev:
            # we have been called with a calling thread waiting:
            ev.job_result = job_res
            ev.set()
        return job_res




class Worker(SyncWorker, threading.Thread):
    def __init__(self, thread_nr, server, mq, logger=None):
        threading.Thread.__init__(self)
        super(Worker, self).__init__(server, mq, logger)
        self.log_prefix = '%s[%s]<-%s' % (mq, thread_nr, server)
        # don't touch the name - it's information is parsed in many places:
        n = '%(pid)s@%(hostname)s' % SL
        # name (from super init) = mq@server
        self.name = n + '[%s]<-%s' % (thread_nr, self.name)
        self.debug('starting job picker %s' % self.name)


