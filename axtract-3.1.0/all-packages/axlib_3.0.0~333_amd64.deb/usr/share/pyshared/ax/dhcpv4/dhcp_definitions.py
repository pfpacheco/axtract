# Numeric code of the message type. Integer from 0-255
MTYPE = "mtype"
# Short name, e.g. "ARP Cache Timeout"
NAME = "name"
# Slightly longer description, e.g. "ARP cache timeout in seconds"
DESC = "description"
# The RFC where this option is defined.
RFC = "rfc"

# RFCs list akk the names with a "DHCP..." suffix, which is omitted for brevity.
MTYPE_DATA = [


        {MTYPE: 10, NAME: "LEASEQUERY", DESC: "Any kind of leasequery", RFC: "4388"},
        {MTYPE: 11, NAME: "LEASEUNASSIGNED", DESC: "Answer to leasequery: Certainly unsassigned", RFC: "4388"},
        {MTYPE: 12, NAME: "LEASEUNKNOWN", DESC: "Answer to leasequery: No info", RFC: "4388"},
        {MTYPE: 13, NAME: "LEASEACTIVE", DESC: "Answer to leasequery: Lease is active", RFC: "4388"},
]

def get_mtypes_by_name(rfc_filter=None):
    """Returns a dict of message types, where the name is used as key

    If an rfc_filter is passed, it must be an iterable of RFC identifier
    strings, e.g. ["1234", "42"]. Only items from the given RFCs will be returned.
    """
    if rfc_filter is not None:
        rfc_filter = list(rfc_filter)
    retval = {}
    for mtype in MTYPE_DATA:
        if (rfc_filter is None) or mtype[RFC] in rfc_filter:
            retval[mtype[NAME]] = mtype

    return retval

MTYPES_BY_NAME = get_mtypes_by_name()

def get_mtypes_by_code(rfc_filter=None):
    """Returns a dict of mtypes, where the mtype's code is used as key

    If an rfc_filter is passed, it must be an iterable of RFC identifier
    strings, e.g. ["1234", "42"]. Only items from the given RFCs will be returned.
    """
    if rfc_filter is not None:
        rfc_filter = list(rfc_filter)
    retval = {}
    for mtype in MTYPE_DATA:
        if (rfc_filter is None) or mtype[RFC] in rfc_filter:
            retval[mtype[MTYPE]] = mtype

    return retval

MTYPES_BY_CODE = get_mtypes_by_code()
