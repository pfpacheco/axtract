#!/usr/bin/python -tt
""" Base functionality to proxy UDP / DHCPv4 / DHCPv6 packets.

If you want a daemon that uses this functionality, use the module
ax.dhcpv4.udp_proxy_daemon. That module also contains more documentation.

You should NOT use the UDPHub class unless you know exactly what you are doing.
Use the DHCPv4Switch whenever you are handling DHCPv4 packets.
"""
import logging
import select
import socket

from netaddr import IPAddress

from ax.utils.lru import ExpiringLRUCache

class UDPHub(object):
    """UDP packet Hub. Many clients send to server, all clients get all replies

    The above behavior results in a O(n^2) complexity: If 100 clients send a
    request, each of the 100 replies will be sent to all 100 clients, leading
    to 100^2 = 10,000 operations. The DHCPv4Switch avoids this by using
    knowledge about the DHCPv4 packet format, leading to O(n) complexity.

    Since UDP is connectionless, the Hub cannot know when a client is not
    interested in the packets any more (usually because he already got the
    reply he was looking for). For that reason, the Hub forgets about clients
    after a while (session_timeout parameter for __init__).

    The Hub can be used to proxy DHCP Leasequeries to a DHCP server if the
    server always sends responses to the same port (=only 1 process can
    receive them).
    It could also be (ab)used as an IPv4 <-> IPv6 translator for UDP.
    """
    def __init__(self, listen_address, destination_addresses,
            session_timeout=3.0, max_sessions=1000,
            logger=None, send_from_address=None):
        """

        listen_address must be an (IP, PORT) tuple.
        destination_addresses must be an iterable of (IP, PORT) tuples.
        """
        if logger is None:
            from ax.utils.logging import setup_logging_for_library
            logger = setup_logging_for_library("")
        self.logger = logger
        self.logger.debug("%s.__init__(): starting...", self.__class__.__name__)

        # self.run() will continue until you set this variable to True.
        self.shutdown_requested = False
        self.listen_address = listen_address
        self.destination_addresses = destination_addresses
        # Remember up to 1k sessions (default), each for up to
        # 3 seconds (default).
        self.clients = ExpiringLRUCache(
                max_sessions, default_timeout=session_timeout)

        # Set up self.sock_listen, the socket with which we listen for clients
        # that contact us.
        listen_ip = IPAddress(listen_address[0])
        if listen_ip.version == 4:
            sock_listen = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        else:
            sock_listen = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
        self.sock_listen = sock_listen
        self.sock_listen.bind(listen_address)

        # Set up self.sock_destination, the socket with which we communicate
        # with the servers. Since it is only one socket, we can only use IPv4
        # or IPv6, but not both at the same time.
        destination_ip = IPAddress(destination_addresses[0][0])
        if destination_ip.version == 4:
            sock_destination = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        else:
            sock_destination = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
        self.sock_destination = sock_destination
        if send_from_address is not None:
            self.sock_destination.bind(send_from_address)

        self.logger.debug("%s.__init__(): finished", self.__class__.__name__)

    def read_from_client(self):
        """To be called when sock_listen is readable

        Receives exactly one packet from a client and forwards it to
        all destinations.
        """
        data, address = self.sock_listen.recvfrom(4096)
        if self.clients.get(address) is None:
            self.logger.info("Have a new client from %s: %d bytes",
                    address, len(data))
            self.clients.put(address, True)
        else:
            self.logger.debug("Another message from client %s: %d bytes",
                    address, len(data))
            self.clients.put(address, True)

        for destination_address in self.destination_addresses:
            self.sock_destination.sendto(data, destination_address)

    def read_from_destination(self):
        """To be called when sock_destination is readable

        Receives exactly one packet from a destination and forwards it to
        all clients.
        """
        data = self.sock_destination.recv(4096)
        self.logger.debug("Received %d bytes from destination", len(data))
        # By not using the LRUCache's API, we avoid flagging items as
        # "recently used", since we have no idea which of these is still there.
        for client_address in self.clients.keys():
            self.logger.debug("Sending data to client %s", client_address)
            self.sock_listen.sendto(data, client_address)

    def run(self):
        self.logger.error("You are using the UDPHub. Are you really sure this "
                "is what you want? How about using DHCPv4Switch instead?")
        self.logger.info("%s has started running", self.__class__.__name__)
        empty_list = []
        while not self.shutdown_requested:
            try:
                self.logger.debug("%s.run() main loop continues",
                        self.__class__.__name__)
                readable = select.select(
                        [self.sock_listen, self.sock_destination],
                        empty_list, empty_list, 1.0)[0]
                for sock in readable:
                    if sock is self.sock_listen:
                        self.read_from_client()
                    elif sock is self.sock_destination:
                        self.read_from_destination()
                    else:
                        raise ValueError
            except Exception:
                if self.shutdown_requested:
                    # SIGINT/SIGTERM probably interrupted the select() syscall,
                    # which is translated into an exception -> normal
                    pass
                else:
                    self.logger.exception("Exception in %s main loop:",
                            self.__class__.__name__)

        self.logger.info("%s has stopped running", self.__class__.__name__)


class DHCPvXSwitch(UDPHub):
    """UDPHub that knows about session IDs (at static location in the packet)

    In contrast to the dumb UDPHub, this class will only forward replies to
    those clients that sent requests with the same DHCP session ID. In practice,
    that means the reply is only sent to a single client, since we generate
    DHCP session IDs in a way that they are unique over all processes on the
    host.

    The main internal change is that self.sessions does not contain address
    tuples as keys and always True as value. Instead, it contains session IDs
    that are mapped to a set of address tuples (unless strange things happen,
    each set should only contain a single address). When a reply arrives from
    a server, this allows a very fast lookup of the client(s) that should get
    this reply.

    The start/stop indexes of the session ID location are NOT hard coded but
    parameterized in our subclasses. By doing this, the same code can support
    both DHCPv4 and DHCPv6. In DHCPv4 lingo, the session ID is called "xid", in
    DHCPv6 it is called "transaction-id".

    Note that the code does not care if e.g. DHCPv4 packets are sent through
    IPv6 or DHCPv6 through IPv4.
    """
    # In which area of the packet we can find the DHCP session ID. This is
    # different for DHCPv4 and DHCPv6, so values must be set by our subclasses.
    xid_start_index = None
    xid_stop_index = None

    def read_from_client(self):
        """To be called when sock_listen is readable

        Receives exactly one packet from a client and forwards it to
        all destinations.
        """
        data, address = self.sock_listen.recvfrom(4096)
        dhcp_xid = data[self.xid_start_index:self.xid_stop_index]
        client_set = self.clients.get(dhcp_xid)
        if client_set is None:
            self.logger.info("Have a new client from %s: %d bytes",
                    address, len(data))
            self.clients.put(dhcp_xid, set((address,)))
        else:
            if address in client_set:
                self.logger.debug("Another message from client %s: %d bytes",
                        address, len(data))
            else:
                self.logger.info("Adding client %s to already existing set().",
                        address)
                client_set.add(address)
            self.clients.put(dhcp_xid, client_set)

        for destination_address in self.destination_addresses:
            self.sock_destination.sendto(data, destination_address)

    def read_from_destination(self):
        """To be called when sock_destination is readable

        Receives exactly one packet from a destination and forwards it to
        all clients with matching XIDs.
        """
        data = self.sock_destination.recv(4096)
        self.logger.debug("Received %d bytes from destination", len(data))
        dhcp_xid = data[self.xid_start_index:self.xid_stop_index]

        # Using get() will mark the item as recently used, but it will not
        # change the life time of the entry.
        client_set = self.clients.get(dhcp_xid)
        if client_set is None:
            self.logger.warn("Received reply but found no clients for it.")
            return
        self.logger.debug("Sending %d bytes to client(s) %s",
                len(data), client_set)
        for client_address in client_set:
            self.sock_listen.sendto(data, client_address)


class DHCPv4Switch(DHCPvXSwitch):
    """DHCP switch configured for DHCPv4"""
    xid_start_index = 4
    xid_stop_index = 8


class DHCPv6Switch(DHCPvXSwitch):
    """DHCP switch configured for DHCPv6"""
    xid_start_index = 1
    xid_stop_index = 4


if __name__ == "__main__":
    LOGGER = logging.getLogger()
    logging.basicConfig(level=logging.DEBUG)

    LISTEN_ADDRESS = ("127.0.0.1", 6868)
    SEND_FROM_ADDRESS = ("0.0.0.0", 6767)
    DESTINATION_ADDRESSES = [("127.0.0.1", 9999)]

    SWITCH = DHCPv4Switch(LISTEN_ADDRESS, DESTINATION_ADDRESSES, logger=LOGGER,
            send_from_address=SEND_FROM_ADDRESS)
    SWITCH.run()

