"""
Module to do en/decoding of individual options
"""

DECODERS = {
        0: dec_one_byte_option,
        255: dec_one_byte_option
}
ENCODERS = {
        0: enc_one_byte_option,
        255: enc_one_byte_option
}


def enc_one_byte_option(code, data):
    return "B", chr(code)

def dec_one_byte_option(code, data):
    pass
