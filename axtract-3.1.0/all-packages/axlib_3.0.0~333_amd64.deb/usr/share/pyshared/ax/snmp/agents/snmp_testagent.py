"""
    SNMP Testagent
"""

"""
    1. Results are represented by lists.
    2. The list contains dictionaries
    3. Each dictionary stands for a column (identified by column OID as key)
    4. Dictionary value is a list with rows
    5. Rows are dictionaries with the following form:
        => { 'row' : 1, 'value' : val, 'type' : type, 'ttl' : 5.0, 'expire' : expiration_time }
            => Row -> row index
            => value -> OID value
            => type -> OID type
            => ttl -> "time to live" (cache validity period)
            (=> expire -> timestamp the cache is valid till, used to set the 
            expire in the past: force updating cache; can be usually skipped)
        
    Generally:
       
        [
            {column_oid :
                [
                    {'ttl': 5.0, 'type': <TYPE>, 'expire': <SECONDS>, 'value': <VALUE>, 'row': <ROW_IDX>}, 
                ]
            }
        ]
"""

# MIB as python representation
import snmp_test_mib as snmp_mib
# MIB utils
from snmp_mib_utils import registerFullTable, registerColumn, \
                    registerRow, registerLeaf, gen_tree_val, \
                    generate_oid_tree

import time
import logging
import logging.handlers
import random

mib_dict = snmp_mib.MIB
OID_TREE = {}

logger = logging.getLogger('testagent')
LOG_FILENAME = '/tmp/testagent.log'
logger.setLevel(logging.DEBUG)
log_handler = logging.handlers.RotatingFileHandler(LOG_FILENAME)
formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
log_handler.setFormatter(formatter)
logger.addHandler(log_handler)

"""
    Data callbacks
"""
data_callbacks = {}

def getCallbacks():
    """
        Get callbacks set for specific OIDs
    """
    return data_callbacks

def getTimeStamp():
    """
        Get current timestamp
    """
    return time.ctime()

def getRTCache():
    """
        Get the total memory from /proc/meminfo
    """
    rt_cache = open("/proc/net/stat/rt_cache")
    first_line = True
    data = []
    
    for line in rt_cache:
        line = line.strip()
        if not first_line:
            splitted_data = line.split(" ")
            break
        else:
            first_line = False
           
    rt_cache.close()
            
    return splitted_data

def getFullTable(table_oid):
    """
        Return the full table represented as followed:
        
        EXAMPLE:
         
        [
            {'1.3.6.1.4.1.33546.1.4.1.1': 
                [
                    {'ttl': 5.0, 'type': 'INTEGER', 'expire': 1299581690.1445751, 'value': 1, 'row': 1}, 
                    {'ttl': 5.0, 'type': 'INTEGER', 'expire': 1299581690.1445839, 'value': 2, 'row': 2}, 
                    {'ttl': 5.0, 'type': 'INTEGER', 'expire': 1299581690.1445861, 'value': 4, 'row': 4}
                ]
            },
            .
            .
            .
        ]

    """
    idx = 1
    table = OID_TREE[table_oid]
     
    net_dev_file = open('/proc/net/dev')
    # result is a list with columns
    result = []
    
    for line in net_dev_file:
        line = line.strip()
        if not line.startswith('Inter-') and not line.startswith('face'):
            data = line.split(" ")     
            i = 0
            
            first_column = True
            
            for column in table:
                column_entry = { column : [] }
                
                # generate index column
                if first_column:
                    column_entry[column].append(gen_tree_val(idx, idx, 'Counter32', 5.0))
                    first_column = False
                else:
                    column_entry[column].append(gen_tree_val(idx, data[i], 'STRING', 5.0))
                    i += 1
                
                result.append(column_entry)
            
            idx += 1
    
    net_dev_file.close()
            
    return result
    

"""
    Indices the tables have
"""
table_indices = [0, 1, 2, 4]

def getColumnX(table_oid, column_idx):
    """
          Get column by its index.

          @param table_oid: Table OID
          @param column_idx: Requested OID, used for determining column OID
    """ 
    logger.debug("COLUMN IDX: %s", column_idx)
    # get data
    raw_data = getRTCache()
    # sort out the empty strings
    data = []
    for e in raw_data:
        if e != "":
            data.append(e)

    i = 0
    
    result = []
    
    for column in OID_TREE[table_oid]:
        column_entry = { column : [] }
        col_idx_pos = column.rfind(".")
        
        if column_idx == column[col_idx_pos + 1:]:
           
            for idx in table_indices:
                
                if int(column_idx) == 1:
                    column_entry[column].append(gen_tree_val(idx, idx, 'INTEGER', 5.0, True))
                else:
                    value = data[i]
                    column_entry[column].append(gen_tree_val(idx, value + " " + getTimeStamp(), 'STRING', 5.0, True))
                i += 1
            idx_column = False
        else:
            for idx in table_indices:
                # set expiration to the past
                expire = time.time() - 50.0
                column_entry[column].append(gen_tree_val(idx, None, 'INTEGER', 5.0, True))
        result.append(column_entry)
    
    return result

# Test indices
axIndices = [0, 1, 2, 4]

def getAxIndex():
    """
          Get AxIndex column.
    """ 
    mycol = []
    rows = []
    # set expire after 5 secs
    
    for idx in axIndices:
        rows.append(gen_tree_val(idx, idx, 'INTEGER', 5.0, True))
        
    mycol.append({ snmp_mib.MIB['nodes']['axIndex']['oid'] : rows })

    return mycol


def getAxDescr():
    """
          Get AxDescr column.
    """
    mycol = []
    rows = []
    # set expire after 5 secs
    
    for idx in axIndices:
        rows.append(gen_tree_val(idx, getTimeStamp(), 'STRING', 5.0, True))
        
    mycol.append({ snmp_mib.MIB['nodes']['axDescr']['oid'] : rows })
    
    rows = []
    
    for idx in axIndices:
        rows.append(gen_tree_val(idx, getTimeStamp(), 'STRING', 5.0, True))

    mycol.append({ snmp_mib.MIB['nodes']['axType']['oid'] : rows })

    return mycol
 
def getAxType():
    """
          Get AxType column.
    """ 
    mycol = []
    rows = []
    # set expire after 5 secs
    
    for idx in axIndices:
        rows.append(gen_tree_val(idx, random.randint(5, 100), 'INTEGER', 5.0, True))
        
    mycol.append({ snmp_mib.MIB['nodes']['axType']['oid'] : rows })

    return mycol

def getRowByIdx(table_oid, row_idx):
    """
        Get row by its index. Columns for the corresponding row are filled with values.
        All the other entries have to be contained in the result as well.
        Entry values are None and their cache has to be outdated. 
        @param table_oid: Table OID
        @param row_idx: Row index
    """
    logger.debug("ROW IDX: %s", row_idx)
    idx_column = True
    
    result = []
    
    for column in OID_TREE[table_oid]:
        column_entry = { column : [] }
        
        # index column entry
        if idx_column:
            column_entry[column].append(gen_tree_val(row_idx, row_idx, 'INTEGER', 5.0, True))
            idx_column = False
        # other columns
        else:
            column_entry[column].append(gen_tree_val(row_idx, column + " Value for " + str(row_idx) + " " + getTimeStamp(), 'INTEGER', 5.0, True))
            
        result.append(column_entry)
        
    return result
             

def getIndexColumn(table_oid):
    """
        Return all available indices (=> Index Column)
        All the other entries have to be contained in the result as well.
        Entry values are None and their cache has to be outdated. 
        @param table_oid: OID of the requested table 
    """
    # get columns
    columns = OID_TREE[table_oid]
    # get the index column
    idx_column_oid = columns[0]
    
    result = []
    # index column
    idx_column_entry = { idx_column_oid : [] }
            
    for idx in range(1, 4):
        expire = time.time() + 15.0    
        idx_column_entry[idx_column_oid].append(gen_tree_val(idx, idx, 'INTEGER', 5.0, True))
    result.append(idx_column_entry)
    # flag to skip the index column
    skip_first = True

    for column_oid in columns:
        # skip the index column
        if not skip_first:
            column_entry = { column_oid : [] }
            # set expiration to the past
            expire = time.time() - 50.0
            for index in range(1, 4):
                column_entry[column_oid].append(gen_tree_val(index, None, 'STRING', 5.0, True, expire))
            result.append(column_entry)
        else:
            skip_first = False
                  
    return result


def testCBSingleOID():
    """
        Callback for a leaf
    """
    return [{ 'value' : random.randint(5, 100), 'type' : 'INTEGER', 'ttl' : 5.0 }]

                
# generate OID tree
OID_TREE = generate_oid_tree(mib_dict)
    
"""
    Register callbacks
"""

# full table
registerFullTable(snmp_mib.MIB, data_callbacks, "ifTable", getFullTable)
# columns
registerColumn(snmp_mib.MIB, data_callbacks, "axIndex", getAxIndex)
registerColumn(snmp_mib.MIB, data_callbacks, "axDescr", getAxDescr)
registerColumn(snmp_mib.MIB, data_callbacks, "axType", getAxType)
# row
registerRow(snmp_mib.MIB, data_callbacks, "rowAxTable", getRowByIdx, getIndexColumn)

# register single OID
registerLeaf(snmp_mib.MIB, data_callbacks, "singleO", testCBSingleOID)

