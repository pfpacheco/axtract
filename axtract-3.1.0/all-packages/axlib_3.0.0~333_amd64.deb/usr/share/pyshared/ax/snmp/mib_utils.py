""" SNMP MIB utilities """

def generate_oid_tree(mib_dict):
    """
    Read the MIB structure and generate
    the corresponding OID tree represented
    by a dictionary.

    FORM:
        {
            table_oid : [ column_oid ],
            .
            .
        }
    """
    oid_tree = {}
    # get columns
    nodes = mib_dict['nodes']

    tables = []
    columns = []

    # proceed nodes from the MIB
    for node in nodes:
        if nodes[node]['nodetype'] == "table":
            oid_tree[nodes[node]['oid']] = []
            tables.append(nodes[node]['oid'])

        elif nodes[node]['nodetype'] == "column":
            columns.append(nodes[node]['oid'])

    # assign columns to tables
    while len(tables) > 0:
        table = tables.pop()

        for column in columns:
            if table in column:

                if not oid_tree.has_key(table):
                    oid_tree[table] = []

                oid_tree[table].append(column)
                # sort columns
                oid_tree[table].sort()

    return oid_tree

## Data callbacks registration
def register_full_table(mib, data_callbacks, node_name, callback):
    """ Register full table callback for a node """
    register_callback(mib, data_callbacks, node_name, 'table', callback)

def register_column(mib, data_callbacks, node_name, callback):
    """ Register column callback for a node """
    register_callback(mib, data_callbacks, node_name, 'column', callback)

def register_row(mib, data_callbacks, node_name, callback, idx_callback):
    """ Register raw and index column callback for a node """
    register_callback(mib, data_callbacks, node_name, 'row', callback, idx_callback)

def register_leaf(mib, data_callbacks, node_name, callback):
    """ Register callback for a leaf """
    register_callback(mib, data_callbacks, node_name, 'leaf', callback)

def register_callback(mib, data_callbacks, node_name, oid_type, cb, idx_cb=None):
    """ Register specific callback """
    nodes = mib['nodes']

    if nodes.has_key(node_name):
        node = nodes[node_name]
        node_oid = node['oid']

        if oid_type != 'row':
            data_callbacks[node_oid] = { 'callback' : cb, 'nodetype' : oid_type }
        elif oid_type == 'row':
            data_callbacks[node_oid] = { 'row_callback' : cb, 'index_callback' : idx_cb, 'nodetype' : oid_type }

def gen_tree_val(row, value, oid_type, ttl, append_expire=False, expire=None):
    """ Generate value dictionary for the tree """
    value = { 'row' : row, 'value' : value, 'type' : oid_type, 'ttl' : ttl }

    if append_expire:
        if expire:
            value['expire'] = expire
        else:
            value['expire'] = None

    return value

def get_oid(nodes, prefix, name):
    return nodes[prefix + name]['oid']

def cut_root_oid(root_oid, oid):
    # +1 cause of the '.'
    root_len = len(root_oid) +1
    return oid[root_len:]

def get_type_name(nodes, prefix, name):
    syntax_type_node = nodes[prefix + name]['syntax']['type']
    if 'name' in syntax_type_node:
        name = syntax_type_node['name']
        if name == 'DisplayString':
            return 'String'
        return name

    elif 'basetype' in syntax_type_node:
        return syntax_type_node['basetype']
    else:
        raise Exception("Cannot figure out the type:%s" % prefix + name)

def get_default_by_type_name(type_name):
    """Returns the default value according to the type"""
    if type_name in ('String', 'DisplayString'):
        return ''
    elif type_name in ('Counter32', 'Counter64', 'Gauge32',
                       "Unsigned32", "Integer", "Integer32", "UInteger32"):
        return 0
    elif type_name in ('IpAddress'):
        return '0.0.0.0'
    else:
        raise Exception("Cannot calc default value for type: %s" % type_name)

def register_table_callback(registry, key_in_registry, mib):
    def real_register(function):
        register_full_table(mib, registry, key_in_registry, function)
        return function
    return real_register

def register_column_callback(registry, key_in_registry, mib):
    def real_register(function):
        register_column(mib, registry, key_in_registry, function)
        return function
    return real_register

def register_row_callback(registry, key_in_registry, mib, idx_callback):
    def real_register(function):
        register_row(mib, registry, key_in_registry, function, idx_callback)
        return function
    return real_register

def register_leaf_callback(registry, key_in_registry, mib):
    def real_register(function):
        register_leaf(mib, registry, key_in_registry, function)
        return function
    return real_register
