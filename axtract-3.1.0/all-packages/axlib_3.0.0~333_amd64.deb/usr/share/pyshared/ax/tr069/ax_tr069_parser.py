"""
Implementation of a TR-069 property parser from XML file to an internal
representation
"""
import os
import simplejson
import itertools

from xml.etree import cElementTree as ElementTree
from ax.utils.parsing.parse_text import parse_line
from ax.tr069.ax_tr069_properties import AXTR069Node, AXTR069ListNode
from ax.utils.config_mgmt.ConfigManager import get_axess_default_config



class AXTR069PropertiesParser (object):
    """
    An XML TR-069 properties parser and mapping generator
    """
    def __init__(self, strict_short_parsing=None, short_auto_parent=None, short_tr069_index_path=None, verbose_output=False):
        """
        Initialise the parser. The strict_short_parsing parsing attribute can
        be used to influence the behaviour when the configuration tries to
        enforce a duplicate "short" name onto some property.
        short_auto_parent: append the parent automatically if not defined in
        the short.
        short_tr069_index_path: provide a path to a filename here to store an index for the
        tr069 short names. if no path is provided, no short name index will be used.
        """
        self.short_tr069_index_path = short_tr069_index_path
        self.short_tr069_index_enabled = short_tr069_index_path is not None
        if strict_short_parsing is None:
            # should we allow 2 shorts pointing to same long?
            # needed e.g. if we want the old vendor xml shorts parallel to the
            # new ones:
            self.__strict_properties_parsing = True
            AX_DEF_CFG = get_axess_default_config()
            spp = AX_DEF_CFG.get('STRICT_PROPERTIES_PARSING')
            if spp == '0' or spp == 'N':
                self.__strict_properties_parsing = False
        else:
            self.__strict_properties_parsing = strict_short_parsing
        self.short_auto_parent = short_auto_parent

        self.__TR069 = {}
        self.__SHORT_TR069 = {}
        self.__SHORT_TR069_BY_PROPS_FILE = {}
        self.__SHORT_INDEX = TwoWayDict(self.load_short_tr069_index())
        self.new_short_index_entries = False
        self.verbose_output = verbose_output

    def get_tr069_props(self):
        """
        Return the internal "long" name to property mapping.
        """
        return self.__TR069

    def load_short_tr069_index(self):
        """
        Loads the unique index of short names
        """
        if self.short_tr069_index_enabled and os.path.exists(self.short_tr069_index_path):
            with open(self.short_tr069_index_path, 'r') as fd:
                return simplejson.load(fd)
        return {}

    def set_in_short_tr069_index(self, full_name, full_shortname):
        self.__SHORT_INDEX[full_name] = full_shortname

    def get_short_from_short_tr069_index(self, full_name):
        if not self.short_tr069_index_enabled:
            return None
        return self.__SHORT_INDEX.normal_get(full_name)

    def get_long_from_short_tr069_index(self, full_shortname):
        if not self.short_tr069_index_enabled:
            return None
        return self.__SHORT_INDEX.reversed_get(full_shortname)

    def save_short_tr069_index(self):
        """
        Saves the unique index of short names
        """
        if self.short_tr069_index_enabled and self.new_short_index_entries:
            # return a json-like structure (we're not using simplejson as
            # we want a line-by-line output)
            lines = []
            lines.append('{')
            for k, v in self.__SHORT_INDEX.normal_iteritems():
               lines.append('    "%s": "%s",' % (k,v))
            if len(lines) > 1:
                lines[-1] = lines[-1][:-1]
            lines.append('}')

            with open(self.short_tr069_index_path, 'w') as fd:
                fd.write('\n'.join(lines))

    def get_short_tr069_props(self):
        """
        Return the internal "short" name to property mapping.
        """
        return self.__SHORT_TR069

    def get_short_tr069_by_file(self):
        """
        Return the internal "short" name to filename mapping.
        """
        return self.__SHORT_TR069_BY_PROPS_FILE

    def parse_xml_file(self, fn):
        """
        Parse the specified XML file containing properties definitions.
        """
        print "Parsing xml property definitions in %s " % fn
        rootNode = ElementTree.parse(fn).getroot()
        attrs = rootNode.attrib
        conv_map = self.__get_conversions(attrs)

        fn = fn.split("/")[-1].split(".xml")[0]
        self.__parse_tree(rootNode, fn, conv_map)

    def parse_xml_string(self, xml):
        """
        Parse the specified XML string containing properties definitions.
        """
        rootNode = ElementTree.fromstring(xml)
        attrs = rootNode.attrib
        conv_map = self.__get_conversions(attrs)

        self.__parse_tree(rootNode, "", conv_map)

    def __get_conversions(self, attrs):
        conv_map = {}

        conversions = attrs.get('conversions')
        if conversions:
            try:
                conv_map = parse_line(conversions)
            except Exception, ex:
                msg = "Error %ex in conversion rule %s"
                raise Exception(msg % (ex, conversions))

        return conv_map

    def __create_compat_dictionaries(self, tree, fn):
        """
        Recurse through the properties tree and create the legacy dictionaries
        mapping the properties by name to a dictionary of attribues.
        """
        for c in tree.get_childs_tree():
            full_name = c.get_full_name()
            full_shortname = c.get_full_shortname()
            c['tr69'] = full_name
            c['short69'] = full_shortname

            longnode = self.__TR069.get(full_name, c)
            shortnode = self.__SHORT_TR069.get(full_shortname, c)

            longnode.update(c)
            shortnode.update(c)

            newfile = longnode['file']
            if fn and newfile and not fn in newfile:
                # If it's a leaf we'll add all filenames where it appears
                if not c.get_direct_childs():
                    newfile = newfile + ", " + fn
                # Otherwise we'll set it to multi
                else:
                    newfile = "multi"

            # If there's no filename use the current filename
            if not newfile:
                newfile = fn

            longnode['file'] = newfile
            shortnode['file'] = newfile

            if 'unit' in c:
                unit = 'Unit: %s' % c['unit']
                shortnode['unit'] = unit
                longnode['unit'] = unit

            self.__SHORT_TR069[full_shortname] = shortnode
            self.__TR069[full_name] = longnode

    def __parse_tree(self, node, fn, conv_map):
        """
        Recurse through the property description nodes, assign appropriate
        short names and create the fancy legacy dictionaries for backwards
        compatibility.
        """
        t = self.__parse_nodes(node)
        self.__assign_short_names(t, conv_map)
        self.__create_compat_dictionaries(t, fn)

        return t

    @staticmethod
    def buildId(name, simpl=0, conv_map=None):
        """ This builds a descriptive short key by taking
        just the capitals.
        Like:
        InternetGatewayDevice.Services.VoiceService.x.VoiceProfile.x.SIP.ProxyServer
        -> I.S.VS.x.VP.x.S.PS

        Problem:
        'SabcIabcPabc' -> SIP
        'SfghIP' -> SIP (-> uniqueness problem)
        so we call it below with a raising simpl param until we get a
        unique one.
        examples: see unittests.
        """
        # force special cases - for downward compatiblity to versions
        # before the TR69.xml was copmleted
        # by marat in different order:
        if name == "InternetGatewayDevice":
            return "I"
        if name == "WANIPConnection":
            return "WIC"
        if name == "ConnectionRequestUsername":
            # this breaks a bit the autostyle (CoRU) but Us is clearer for the User:
            return "CRUs"

        if conv_map:
            # fix those long to short conversions:
            for k, v in conv_map.items():
                if k in name:
                    name = name.replace(k, '|%s|' % v)

        ret = ""

        # just an 'out of range avoider':
        name = name + "123456789"

        if name == name.lower():
            # Prevent returning an empty string in case of all-lowercase
            # parameter names
            name = name[0].upper() + name[1:]

        lastTaken = -10
        i = -1
        while i < len(name) - 10:
            i += 1
            # was this a forced short, by conv_map?:
            if name[i] == '|':
                # find next one:
                j = name.find('|', i + 1)
                # force the short:
                ret += name[i + 1:j]
                i = j
                continue

            # is this a capital letter?
            # IF we have a conflict then we take the next <simpl> small letter(s)
            # IF conv_map is given (i.e. Vendor file, we parse new style,
            # i.e. with out '_' and using also lower case chars):
            is_capital = name[i] == name[i].upper()
            is_not_underscore = name[i] != '_'
            prev_is_underscore = (i > 0 and name[i - 1] == '_')

            no_conv_and_capital = not conv_map and is_capital
            conv_given = conv_map and ((is_capital and is_not_underscore) or prev_is_underscore)

            if conv_given or no_conv_and_capital:
                lastTaken += 1
                nn = name[i + 1]
                if lastTaken < i - 1 or nn != nn.upper():
                    if nn == '|':
                        j = i + 1
                    else:
                        j = i + simpl + 1
                        simpl = 0
                    ret += name[i:j]
                    lastTaken = j - 1
                    i = lastTaken

        return ret

    def __parse_nodes(self, node):
        """
        Recurse through the described tree starting with the specified node and
        create appropriate node entries depending on the type.
        """
        attrs = node.attrib

        # Check whether this node is supposed to be a list
        islist = False
        value = attrs.get('islist', "").lower()
        if value:
            if value == 'true':
                islist = True
            elif value == 'false':
                pass
            else:
                msg = "Unknown value ('%s') specified to 'islist' attribute"
                raise ValueError(msg % value)

            del attrs["islist"]

        if islist:
            n = AXTR069ListNode(node.tag)
        else:
            n = AXTR069Node(node.tag)

        n.update(attrs)

        for child in node:
            n.add_child(self.__parse_nodes(child))

        return n

    def __assign_short_names(self, nodes, conv_map):
        """
        Recurse through the nodes assigning them them proper non-conflicting
        "short" names.
        """
        for c in nodes.get_childs_tree():
            name = c.get_native_name()
            parent = c.get_parent()

            if not c.get_full_name().startswith('InternetGatewayDevice'):
                raise Exception('Any parameter has to start with InternetGatewayDevice')

            # If a short name was specified we will check whether it is unique
            specified_short = c.get("short", "")
            if specified_short:
                del c["short"]

                if self.__strict_properties_parsing and parent:
                    for sibling in parent.get_direct_childs():
                        if sibling.get_full_shortname() == specified_short:
                            msg = "Strict parsing engaged but forced short " \
                                  "name '%s' clashes for '%s'"
                            raise Exception(msg % (specified_short, name))

                c.set_full_shortname(specified_short, self.short_auto_parent)

                if self.short_tr069_index_enabled:
                    new_full_short = c.get_full_shortname()
                    full_name = c.get_full_name()
                    name_in_index = self.get_long_from_short_tr069_index(new_full_short)

                    if self.__strict_properties_parsing:
                        if name_in_index is not None and name_in_index != full_name:
                            raise Exception('Forced short parameter "%s" for "%s" is already in use'\
                                            ' by a different parameter: %s' % (new_full_short, full_name, name_in_index))
                    if name_in_index:
                        continue

            if not specified_short:
                if self.short_tr069_index_enabled:
                    indexed_short = self.get_short_from_short_tr069_index(c.get_full_name())
                    if indexed_short:
                        c.set_full_shortname(indexed_short)
                        continue

                full_name = c.get_full_name()
                if self.verbose_output:
                    print 'Found new Parameter:', full_name

                # Tests if the same long name was defined in a previous parsed
                # xml file before. If so use this shortname.
                # Another check below ensures that a shortname in
                # self.__SHORT_TR069 is *never* used twice
                if full_name in self.__TR069:
                    c.set_shortname(self.__TR069[full_name].get_native_shortname())
                else:
                    # Parameter is new => search for a shortname
                    for i in range(10):
                        short = self.buildId(name, i, conv_map)
                        # Check if this 'short' conflicts with another one in
                        # this subtree
                        conflict = False
                        if parent is not None:
                            for sibling in parent.get_direct_childs():
                                if sibling.get_native_shortname() == short:
                                    conflict = True
                                    break

                        if conflict:
                            continue

                        # There is no conflict within the current xml file.
                        # This checks for conflicts with previous parsed xml
                        # files
                        c.set_shortname(short)
                        new_full_short = c.get_full_shortname()
                        if new_full_short in self.__SHORT_TR069:
                            # this short name was already assigned to a
                            # different parameter during the current run
                            continue

                        if self.short_tr069_index_enabled:
                            long_name_in_index = self.get_long_from_short_tr069_index(new_full_short)
                            if long_name_in_index and long_name_in_index != full_name:
                                # this short name was already assigned to a
                                # different parameter in our short name index
                                continue

                        break
                    else:
                        # run if there was not break:
                        raise Exception("Keying problem at node %s " % name)

            if self.short_tr069_index_enabled:
                self.set_in_short_tr069_index(
                    c.get_full_name(),
                    c.get_full_shortname())

                self.new_short_index_entries = True
                if self.verbose_output:
                    print 'assigned new permanent short name', c.get_full_shortname()

        return nodes


class TwoWayDict(object):
    __slots__ = ('_normal', '_reverse')

    def __init__(self, init_dict):
        self._normal = init_dict
        stream = itertools.izip(init_dict.itervalues(), init_dict.iterkeys())
        self._reverse = dict(stream)

    def __setitem__(self, key, value):
        if key in self._normal:
            del self._reverse[self._normal[key]]

        self._normal[key] = value
        self._reverse[value] = key

    def normal_iteritems(self):
        return self._normal.iteritems()

    def normal_get(self, key):
        return self._normal.get(key)

    def reversed_get(self, key):
        return self._reverse.get(key)
