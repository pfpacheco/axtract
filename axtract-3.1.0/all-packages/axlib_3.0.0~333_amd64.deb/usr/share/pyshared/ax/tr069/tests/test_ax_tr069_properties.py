from ax.tr069.ax_tr069_properties import AXTR069Node, AXTR069ListNode
import unittest2


class AXTR069NodeTest(unittest2.TestCase):
    def test_construction(self):
        name = "Test"
        shortname = "T"
        n = AXTR069Node(name)
        self.assertEqual(n.get_shortname(), "")
        n.set_shortname(shortname)
        self.assertEqual(n.get_shortname(), shortname)
        self.assertEqual(n.get_name(), name)
        self.assertEqual(n.get_direct_childs(), [])
        self.assertEqual(n.get_parent(), None)

    def test_compat_attributes(self):
        name = "Test"
        shortname = "T"
        n = AXTR069Node(name)
        n.set_shortname(shortname)

        self.assertEqual(n['short69'], shortname)
        self.assertEqual(n['tr69'], name)
        self.assertEqual(n['typeLength'], None)
        self.assertEqual(n['default'], None)
        self.assertEqual(n['readOnly'], False)
        self.assertEqual(n['TR_description'], None)
        self.assertEqual(n['write'], None)
        self.assertEqual(n['emptyfromcpe'], None)
        self.assertEqual(n['islist'], False)
        self.assertEqual(n['type'], 'string')
        self.assertEqual(n['id'], '1')
        self.assertEqual(n['unit'], None)
        self.assertEqual(n['size'], 20)
        self.assertEqual(n['isNode'], False)
        self.assertEqual(n['file'], "")

    def test_add_child(self):
        name = "Test"
        n1 = AXTR069Node(name)

        with self.assertRaises(ValueError):
            n1.add_child("")

        n2 = AXTR069Node("Foo")
        n1.add_child(n2)

        n3 = AXTR069ListNode("Bar")
        n1.add_child(n3)

    def test_get_direct_childs(self):
        name = "Test"
        n1 = AXTR069Node(name)

        n2 = AXTR069Node("Foo")
        n1.add_child(n2)

        n3 = AXTR069ListNode("Bar")
        n1.add_child(n3)

        n4 = AXTR069ListNode("Baz")
        n2.add_child(n4)

        cn = [n.get_full_name() for n in n1.get_direct_childs()]
        self.assertEqual(cn, ['Test.Foo', 'Test.Bar.x'])

    def test_get_name(self):
        name = "Test"
        n = AXTR069Node(name)
        self.assertEqual(n.get_name(), name)
        self.assertEqual(n.get_native_name(), name)

        n = AXTR069ListNode(name)
        self.assertEqual(n.get_name(), name + ".x")
        self.assertEqual(n.get_native_name(), name)

    def test_get_short_name(self):
        name = "Test"
        shortname = "T"
        n = AXTR069Node(name)
        n.set_shortname(shortname)
        self.assertEqual(n.get_shortname(), shortname)
        self.assertEqual(n.get_native_shortname(), shortname)

        n = AXTR069ListNode(name)
        n.set_shortname(shortname)
        self.assertEqual(n.get_shortname(), shortname + ".x")
        self.assertEqual(n.get_native_shortname(), shortname)

    def test_set_full_short_name(self):
        name = "Test"
        shortname = "T"
        n = AXTR069Node(name)
        n.set_full_shortname(shortname)
        self.assertEqual(n.get_shortname(), shortname)
        self.assertEqual(n.get_native_shortname(), shortname)

        name = "Test"
        shortname = "T.T"
        n2 = AXTR069Node(name)
        n.add_child(n2)
        n2.set_full_shortname(shortname)
        self.assertEqual(n2.get_shortname(), "T")
        self.assertEqual(n2.get_native_shortname(), "T")

        name = "Test"
        shortname = "I.T"
        n3 = AXTR069Node(name)
        n.add_child(n3)
        with self.assertRaises(ValueError):
            n3.set_full_shortname(shortname)

        name = "NewTest"
        shortname = "T.T"
        n4 = AXTR069Node(name)
        with self.assertRaises(ValueError):
            n4.set_full_shortname(shortname)

    def test_get_full_name(self):
        name = "Test"
        shortname = "T"
        n1 = AXTR069Node(name)
        n1.set_shortname(shortname)

        self.assertEqual(n1.get_full_name(), n1.get_name())
        self.assertEqual(n1.get_full_shortname(), n1.get_shortname())

        name = "Foo"
        shortname = "F"
        n2 = AXTR069Node(name)
        n2.set_shortname(shortname)
        n1.add_child(n2)

        self.assertEqual(n2.get_full_name(), "Test." + n2.get_name())
        self.assertEqual(n2.get_full_shortname(), "T." + n2.get_shortname())

        n3 = AXTR069ListNode("Bar")
        n3.set_shortname("B")
        n1.add_child(n3)

        self.assertEqual(n3.get_full_name(), "Test." + n3.get_name())
        self.assertEqual(n3.get_full_shortname(), "T." + n3.get_shortname())

        n4 = AXTR069ListNode("Baz")
        n4.set_shortname("B")
        n2.add_child(n4)

        self.assertEqual(n4.get_full_name(), "Test.Foo." + n4.get_name())
        self.assertEqual(n4.get_full_shortname(), "T.F." + n4.get_shortname())

    def test_get_parent(self):
        name = "Test"
        n1 = AXTR069Node(name)

        self.assertEqual(n1.get_parent(), None)

        name = "Foo"
        n2 = AXTR069Node(name)
        n1.add_child(n2)

        self.assertNotEqual(n2.get_parent(), None)
        self.assertEqual(n2.get_parent(), n1)

        n3 = AXTR069ListNode("Bar")
        n1.add_child(n3)

        self.assertNotEqual(n3.get_parent(), None)
        self.assertNotEqual(n3.get_parent(), n2)
        self.assertEqual(n3.get_parent(), n1)

        n4 = AXTR069ListNode("Baz")
        n2.add_child(n4)

        self.assertNotEqual(n4.get_parent(), None)
        self.assertNotEqual(n4.get_parent(), n1)
        self.assertEqual(n4.get_parent(), n2)

    def test_get_childs_tree(self):
        name = "Test"
        n1 = AXTR069Node(name)

        name = "Foo"
        n2 = AXTR069Node(name)
        n1.add_child(n2)

        n3 = AXTR069ListNode("Bar")
        n1.add_child(n3)

        n4 = AXTR069ListNode("Baz")
        n2.add_child(n4)

        self.assertEqual(n1.get_childs_tree(), [n1, n2, n4, n3])

    def test_truthness(self):
        name = "Test"
        n1 = AXTR069Node(name)

        self.assertEqual(bool(n1), True)
        self.assertEqual(bool(n1.get_parent()), False)

        name = "Foo"
        n2 = AXTR069Node(name)
        n1.add_child(n2)

        self.assertEqual(bool(n2), True)
        self.assertEqual(bool(n2.get_parent()), True)

        n3 = AXTR069ListNode("Bar")
        n1.add_child(n3)

        self.assertEqual(bool(n3), True)
        self.assertEqual(bool(n3.get_parent()), True)

    def test_comparison(self):
        name = "Test"
        n1 = AXTR069Node(name)
        eqn1 = AXTR069Node(name)

        self.assertEqual(n1, eqn1)

        name = "Foo"
        n2 = AXTR069Node(name)
        n1.add_child(n2)
        eqn2 = AXTR069Node(name)

        # Without add_child this will stay a new single root node
        self.assertNotEqual(n2, eqn2)
        self.assertNotEqual(n2, n1)
        self.assertEqual(n2.get_parent(), n1)

        n3 = AXTR069ListNode("Bar")
        n1.add_child(n3)
        eqn3 = AXTR069ListNode("Bar")

        # Without add_child this will stay a new single root node
        self.assertNotEqual(n3, eqn3)
        self.assertNotEqual(n3, n2)
        self.assertNotEqual(n3, n1)
        self.assertEqual(n3.get_parent(), n1)
