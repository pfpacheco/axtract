from time import strftime, localtime, time
from ax.utils.lib.SOAPpy_ax import untypedType

_tr_methods = [
    'GetRPCMethods',
    'GetParameterValues',
    'SetParameterValues',
    'GetParameterNames',
    'GetParameterAttributes',
    'SetParameterAttributes',
    'Reboot',
    'AddObject',
    'DeleteObject',
    'DeleteObject',
    'Download',
    'Upload',
    'ScheduleInform',
    'ScheduleDownload',
    'GetQueuedTransfers',
    'FactoryReset',
    'ChangeDUState',
    'CancelTransfer',
    'X_AXPAND_RunCmdFlow'
]


def get_tr_methods(get_cloned=None, *args, **kwargs):
    """ this is the place to implement version specific method definition
    right now we just return this list
    """
    if not get_cloned:
        return _tr_methods
    else:
        clone = []
        clone.extend(_tr_methods)
        return clone


def get_tr_time():
    return untypedType(strftime('%Y-%m-%dT%H:%M:%S', localtime(time())))
