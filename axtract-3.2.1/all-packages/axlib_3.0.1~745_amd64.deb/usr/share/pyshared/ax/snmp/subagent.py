import sys
import time
import logging
import logging.handlers
import select
import warnings

from ax.utils.ax_tree.ax_tree import AXOrderedTree
from ax.utils.logging.handlers import WatchedRotatingFileHandler

class SubAgent(object):
    def __init__(self, logfile, get_callbacks, get_setter_callbacks,
            logLevel=logging.DEBUG):
        warnings.simplefilter('ignore', DeprecationWarning)
        self.logLevel = logLevel
        self.logger = self._create_logger(logfile)
        self.oid_callbacks = self._create_oid_callbacks(get_callbacks)
        self.main_tree = AXOrderedTree(self.oid_callbacks)
        self.get_setter_callbacks = get_setter_callbacks

        self.target = None
        self.set_request = False

    def _create_logger(self, logfile):
        logger = logging.getLogger('subagent')
        logger.setLevel(self.logLevel)

        log_format = "%(asctime)s - %(name)s (line %(lineno)d) " \
                     "- %(levelname)s: %(message)s"
        formatter = logging.Formatter(log_format)

        log_handler = WatchedRotatingFileHandler(logfile)
        log_handler.setFormatter(formatter)

        logger.addHandler(log_handler)
        return logger

    def _callback_cmp(self, a, b):
        _a_parts = a[0].split('.')[1:]
        _b_parts = b[0].split('.')[1:]
        v = 0
        for i in range(0, len(_a_parts)):
            try:
                a_val = int(_a_parts[i])
                b_val = int(_b_parts[i])
            except IndexError:
                break
            if a_val == b_val:
                continue
            elif a_val < b_val:
                v = -1
                break
            else:
                v = 1
        return v


    def _create_oid_callbacks(self, get_callbacks):
        oid_callbacks = []
        try:

            callbacks = get_callbacks()
            for oid in callbacks:
                key = oid
                # append a point to the beginning
                if key[1:] != ".":
                    key = "." + oid

                oid_callbacks.append((key, [callbacks[oid]]))

            # this is super important to be sorted properly. The rest of 
            # the code relies on sorted oids
            oid_callbacks.sort(self._callback_cmp)
            return oid_callbacks

        except Exception, error:
            msg = "Error initializing OID callbacks: " \
                  "check your callbacks agent! Details: %s"
            self.logger.error(msg % error)

    def refresh_cache(self, element):
        """Refresh the cache by the given result"""
        try:
            if isinstance(element, list) and len(element) > 0:
                element = element[0]

            # set cache validity
            if element:
                update_interval = element.get('ttl')
                element['expire'] = time.time() + update_interval

        except Exception, ex:
            self.logger.exception("Cache refresh failed: %s", ex)

        return element

    def print_result(self, result):
        """
            Print result type and value
            @param result: Dictionary containing type and value of the result
        """
        if isinstance(result, list) and len(result) > 0:
            result = result[0]

        try:
            if result:
                # print OID type
                oid_type = result['type']
                self.logger.debug("PRINTING element type: %s", oid_type)
                self.output(oid_type)

                # print callback result
                self.logger.debug("PRINTING element value: %s", result['value'])
                self.output(result['value'])
            else:
                self.logger.debug("Printing NONE...")
                self.output("NONE")

        except Exception, ex:
            self.logger.exception("Printing result failed: %s", ex)
            self.output("NONE")

    def do_set(self, target, value):
        """Process the "set" request"""

        self.logger.debug("Performing SET request...")
        key = target.strip()

        try:
            callbacks = self.get_setter_callbacks()
            # remove the point in the beginning
            if target[:1] == '.':
                target = target[1:]
            # determine the column and index
            pos = target.rfind('.')
            idx = target[pos + 1:]
            column = target[:pos]

            if callbacks.has_key(column):
                cb = callbacks[column]['callback']
                if cb:
                    # excecute callback
                    cb(idx, value)

        except Exception, ex:
            msg = "Error setting value %s for OID %s: %s"
            self.logger.exception(msg, value, key, ex)

        self.output("DONE")

    def do_get(self, target):
        """
        Process a "get" request
        -> If any unexpected error occurs, send "NONE" back to SNMP
        -> update cache with refreshCache()
        -> send value back via printResult()
        @param target: Requested OID 
        """
        key = target.strip()
        found = True
        result = None

        self.logger.debug("Performing GET request...")
        self.logger.debug("Requested OID: %s", repr(key))
        if self.main_tree.has_key(key):
            # get subtree
            element = self.main_tree.get(key)

            if not isinstance(element, AXOrderedTree) and element[0].has_key("nodetype") and element[0]['nodetype'] != 'leaf':
                # root nodes don't have any value
                self.print_none_response()
            else:
                got_result = False
                # check cache for validity
                if isinstance(element, list) and element[0].get('expire') > time.time():
                    self.logger.debug("Cache is still valid.")
                    # cache is still valid
                    # get value from cache
                    result = element[0]
                    got_result = True
                else:
                    self.logger.debug("Cache needs updating!")
                    nodetype, table_oid = self.get_node_type(key)

                    if nodetype:
                        self.logger.debug("Current node type: %s", nodetype)

                        get_first = key == table_oid
                        result = self.collect_data(table_oid, key, False, get_first, nodetype, True)

                        # renew cache
                        self.refresh_cache(result)
                        got_result = True

                if got_result and result:
                    # print OID
                    self.logger.debug("PRINTING OUT TARGET: %s", target)
                    self.output(target)
                    self.logger.debug("Callback result: %s", result)
                    # print type and value
                    self.print_result(result)
                else:
                    self.print_none_response()
        else:
            self.logger.debug("No OID found!")
            # no OID found
            found = False

        # try to find a parent
        if not found:
            loop_alive = True
            parent_key = key

            # check if parent is in the MAIN_TREE
            while loop_alive:
                # find the last appearance of the point
                point_idx = parent_key.rfind(".")
                # go one level higher
                parent_key = parent_key[:point_idx]

                if self.main_tree.has_key(parent_key):
                    self.logger.debug("Parent exists.")
                    self.logger.debug("key => %s", key)
                    self.logger.debug("parent key => %s", parent_key)

                    nodetype, table_oid = self.get_node_type(key)

                    if nodetype:
                        result = self.collect_data(parent_key, key, True, False, nodetype, True)
                        requested_element = self.main_tree.get(key)
                        self.refresh_cache(requested_element)

                        # print type and value
                        self.print_result(result)

                        loop_alive = False

                if parent_key == "":
                    loop_alive = False
                    self.print_none_response()

        return result

    def do_get_next(self, target):
        """
        Process a "getnext" request
        -> If any unexpected error occurs, send "NONE" back to SNMP
        -> update cache with refreshCache()
        -> send value back via printResult()
        @param target: Requested OID
        """
        key = target.strip()

        self.logger.debug("Performing GETNEXT request...")
        self.logger.debug("Requested OID: %s", repr(key))

        node = None
        exist = False
        result = None
        it_key = None

        # check if there is such key
        if self.main_tree.has_key(key):
            self.logger.debug("HAS KEY: %s", self.main_tree.has_key(key))
            # get the node
            node = self.main_tree[key]
            exist = True

        # if the given OID doesn't exist in the tree (yet),
        # try to get the value for it via its parent
        if not exist:
            exist = self.find_childs_parent_oid(key)

        # ->  if there is a result: collectData() got data and
        #     already stored it into tree. The needed OID is found by
        #     iterating over tree leaves.
        # ->  if collect data didn't get any data, a "NONE" will be
        #     printed
        if not exist:
            self.print_none_response()
        else:
            node_found = False
            node = self.main_tree.get(key)
            self.logger.debug(node)

            # if the node is a list, check if it has a nodetype key
            # -> original callback node
            if isinstance(node, list) and len(node) > 0 and node[0].has_key('nodetype') and node[0].get('nodetype') != 'leaf':
                it_key = key
                node_found = True
            # check if the node is not a leaf. If so, take
            # its first child
            elif isinstance(node, AXOrderedTree):
                keys_iterator = node.iter_leaf_keys()
                # get the first child from iterator
                first_key = keys_iterator.next()
                it_key = key + "." + first_key
                node_found = True
            else:
                self.logger.debug("Iterating over elements...")
                # get keys iterator
                it = self.main_tree.iter_leaf_keys()
                # search for the specified OID
                for it_key in it:
                    # requested key is found
                    if it_key == key:
                        self.logger.debug("Leaf found: %s", it_key)
                        nodetype, table_oid = self.get_node_type(it_key)
                        # if a row or a leaf requested, proceed to the next element
                        if len(self.main_tree[it_key]) > 0 and self.main_tree[it_key][0].has_key('row') or nodetype == 'leaf':
                            # is there a next element?
                            # check if iterator has more elements. If iterator is empty,
                            # there is no more leaves in the tree
                            if len(it.nodes) > 0:
                                it_key = it.next()
                                node_found = True
                            else:
                                # no more elements left in the iterator: end of the tree!
                                self.print_none_response()
                                return
                        break

            if node_found:
                # if getting any None result, ignore the empty elements
                # and try to get the data for the next OIDs
                while result == None:
                    result = self.get_data(it_key)
                    if result != None:
                        # print type and value
                        self.print_result(result)
                    # having got an empty result try to take the next element
                    elif len(it.nodes) > 0:
                        it_key = it.next()
                    else:
                        self.print_none_response()
                        break
            else:
                self.print_none_response()

        return (it_key, result)
    
    def find_childs_parent_oid(self, key):
        """
            If any OID is requested that doesn't exist
            in the current tree, try to determine its 
            parent OID
            @param parent_key: Initial key a parent has to be found for
        """
        exist = False
        parent_key = key
        result = None

        while parent_key != "":
            # Search for parent key that
            # could contain the given OID

            # find the parent key by cutting off the last part
            # of the OID (after last point)
            # last appearance of point
            p_idx = parent_key.rfind(".")
            parent_key = parent_key[:p_idx]

            if self.main_tree.has_key(parent_key):
                self.logger.debug("PARENT NODE %s exists", parent_key)

                nodetype, table_oid = self.get_node_type(parent_key)

                if nodetype:
                    result = self.collect_data(parent_key, key, False, True, nodetype)

                if result:
                    # if got any result, update cache expire
                    # (next routine will just read the values from cache)
                    self.refresh_cache(result)
                    # make loop quit
                    parent_key = ""
                    exist = True

        return exist

    def print_none_response(self):
        """
            Print None message to notify SNMPD that
            element tree is ended
        """
        self.logger.debug("No element found, sending NONE to SNMPD...")
        self.output("NONE")

    def get_data(self, it_key):
        """
            Get new data for the element or get 
            the values from its cache
            @param it_key: OID the data is obtained for
        """
        result = None

        if it_key:
            self.logger.debug("ITERATOR KEY IS: %s", it_key)
            element = self.main_tree.get(it_key)

        if not element:
            self.print_none_response()
        else:
            # check cache validity
            if element[0].get('expire') > time.time():
                # print target (not to forget the \n)
                self.logger.debug("Printing TARGET...")
                self.output(it_key)
                self.logger.debug("Cache is still valid: getting value from cache...")
                # cache is still valid
                # get value from cache
                result = element[0]
            else:
                self.logger.debug("Cache needs to be updated.")
                # get nodetype / table oid
                nodetype, table_oid = self.get_node_type(it_key)
                # take the first one, if root requested
                get_first = table_oid == it_key
                # ROW: next index is determined by separate routine
                get_request = nodetype != 'row'
                # collect data
                result = self.collect_data(table_oid, it_key, True, get_first, nodetype, get_request)
                # refresh cache
                self.refresh_cache(result)

        return result

    def get_node_type(self, it_key):
        """
        Get node type
        Node type is determined by callbacks
        @param it_key: OID a callback should be registered for
        """
        _it_key = it_key.split('.')
        for callback in self.oid_callbacks:
            _callback_nodes = callback[0].split('.')
            matches = True
            for i in range(0, len(_callback_nodes)):
                if _callback_nodes[i] != _it_key[i]:
                    matches = False
                    break
            if matches:
                nodetype = callback[1][0].get('nodetype')
                table_oid = callback[0]
                self.logger.debug("Table OID -> %s, Nodetype -> %s", nodetype, table_oid)

                return (nodetype, table_oid)

        return (None, None)


    def collect_data_by_row(self, key, it_key, table_oid, get_request, cb):
        """
        Proceed row:
        get all indices via getIndexColumn()
        pass the needed row index to getRowByIndex()
        """
        self.logger.debug("Processing row...")
        idx = self.main_tree.get(key)

        # check for OID for being an index
        idx_callback = cb['index_callback']

        updated = False

        if isinstance(idx, list) and 'index_callback' in idx[0]:
            idx_callback_result = idx_callback(table_oid)
            # index column was not stored yet
            self.logger.debug("Storing the index column for the first time...")
            # indicating to the function (idx_column = True) that this is an index column, so the result
            # wont' be stored within the appendDataToMainTree() function: the function
            # returns the obtained columns that are directly appended to the 'key' node
            idx_result = self.append_data_to_main_tree(idx_callback_result, key, True)
            self.main_tree[key] = idx_result
            # tell the following block to skip as there's no need to
            # check cache validity because the indices are to be up-to-date
            updated = True

        if not updated:
            idx_callback_result = idx_callback(table_oid)
            # Check if the current OID is the index:
            # if so, check its validity. If the cache is invalid,
            # get the index column and overwrite the node data
            if it_key in idx_callback_result[0]:
                cache_expire = None
                # check if it's leaf
                if isinstance(idx, list):
                    cache_expire = idx[0]['expire']
                    self.logger.debug("CACHE EXPIRES: %s; NOW: %s", cache_expire, time.time())
                # check cache for validity:
                # if no cache or it's expired, overwrite the node data
                if not cache_expire or cache_expire < time.time():
                    self.logger.debug("Idx column cache expired! Getting index column...")
                    idx_result = self.append_data_to_main_tree(idx_callback_result, key, True)
                    self.main_tree[key] = idx_result

        # get index
        temp = it_key[len(table_oid) + 1:]

        # Table's root node requested => take the first
        if temp == "":
            index = 1
        else:
            # determine OID index
            # get the last appearance of point in requested oid
            last_point_idx_req = it_key.rfind(".")
            index = it_key[last_point_idx_req + 1:]

        next_index = None
        # get the index column (have to be the first in list)
        rows = idx_callback_result[0].values()[0]
        # get next index:
        # -> if index is 1, take the first row
        # -> otherwise: search for the current index and take the next one
        if int(index) == 1:
            next_index = rows[0]['row']
        else:
            i = 0
            # go through indices to find the current/next one
            while i < len(rows):
                # if current index matches the found one:
                # -> take it for a get request
                # -> take the next available index for getnext requests
                if rows[i]['row'] == int(index):
                    if get_request:
                        # for get requests take current index
                        next_index = index
                    elif i <= len(rows):
                        # for getnext request try to get the next index
                        next_index = rows[i]['row']
                i += 1

        self.logger.debug("INDEX: %s", next_index)
        # get the callback
        row_callback = cb['row_callback']

        callback_result = None

        # get row by the 'next_index'
        if next_index:
            callback_result = row_callback(table_oid, next_index)

        return callback_result

    def collect_data_by_column(self, cb):
        """ Get data by column """

        self.logger.debug("Processing column...")
        collection_method = cb.get('callback')
        callback_result = collection_method()

        return callback_result

    def collect_data_by_table(self, table_oid, cb):
        """ Get data by full table """
        self.logger.debug("Obtaining full table... %s", cb)

        collection_method = cb.get('callback')
        callback_result = collection_method(table_oid)
        self.logger.debug("Result from callback:%s", callback_result)

        return callback_result

    def collect_data_by_leaf(self, cb):
        """ Get data by leaf """
        self.logger.debug("Obtaining leaf...")

        collection_method = cb.get('callback')
        callback_result = collection_method()

        return callback_result

    def get_data_callback(self, oid):
        """
        Get the callback for data
        @param oid: OID a callback is registered for
        """
        cb = None

        _oid_nodes = oid.split('.')
        # get corresponding callback
        for callback in self.oid_callbacks:
            _callback_nodes = callback[0].split('.')
            matches = True
            for i in range(0, len(_callback_nodes)):
                if _callback_nodes[i] != _oid_nodes[i]:
                    matches = False
                    break
            if matches:
                cb = callback[1][0]
                break

        return cb

    def collect_data(self, key, it_key, print_oid=True, get_first=False, nodetype='table', get_request=False):
        """
        Get Non-Leaf values
        @param print_oid: if True, print the requested OID in this function
                        (if there is a need to skip the print action, if the OID has already been printed)
        @param get_first: if True, get the first element appeared in list
        """
        result = None
        # get callback
        cb = self.get_data_callback(it_key)

        # cut off the point in the beginning (i.e the
        # agent doesn't use the OIDs with prepending point)
        if it_key[:1] == '.':
            table_oid = key[1:]
        else:
            table_oid = key

        # prevent subroutines from affecting the subagent communication with SNMPD
        # by printing some stuff to stdout!
        original_stdout = sys.stdout
        sys.stdout = open("/dev/null", "w")
        try:
            # collect data by one of the following routines
            if nodetype == 'row':
                callback_result = self.collect_data_by_row(key, it_key, table_oid, get_request, cb)
            elif nodetype == 'column':
                callback_result = self.collect_data_by_column(cb)
            elif nodetype == 'table':
                callback_result = self.collect_data_by_table(table_oid, cb)
            elif nodetype == 'leaf':
                callback_result = self.collect_data_by_leaf(cb)
        finally:
            # restore original stdout
            fake_stdout = sys.stdout
            sys.stdout = original_stdout
            fake_stdout.close()
        
        self.logger.debug("Result got from callback is: %s", callback_result)
        
        if callback_result:
            if nodetype == 'leaf':
                # store result for leaf directly into node
                self.main_tree[key] = callback_result
            else:
                # don't set the table values within routine, but return a list for subtree
                callback_result = self.append_data_to_main_tree(callback_result, key, nodetype == 'table')
                # set table values by the returned subtree here and update values cache
                if nodetype == 'table':
                    self.main_tree[key] = callback_result
                    values_iterator = self.main_tree[key].iter_leaf_values()
                    # update cache expiration
                    for element in values_iterator:
                        self.refresh_cache(element)

            iterator = None
            # don't overwrite the root node data for row and column collection methods
            if nodetype != 'leaf' and isinstance(self.main_tree[key], AXOrderedTree):
                # get keys iterator
                iterator = self.main_tree[key].iter_leaf_keys()

            element_found = False
            index = ""
            if nodetype == 'leaf':
                element_found = True
            elif iterator != None:
                # iterate over elements
                for next_element in iterator:
                    if get_first and next_element != '':
                        self.logger.debug("ELEMENT FOUND: %s", next_element)
                        element_found = True
                    elif key + "." + next_element == it_key:
                        self.logger.debug("ELEMENT FOUND: %s", next_element)
                        element_found = True
                        # for getnext requests get the next element
                        # for "get-by-row" routines base on the separate routine
                        if not get_request and nodetype != 'row':
                            if len(iterator.nodes) > 0:
                                next_element = iterator.next()
                                element_found = True

                    if element_found:
                        index = "." + next_element
                        break

            if element_found:
                # print only if printing is allowed (default)
                if print_oid:
                    self.logger.debug("PRINTING TARGET WITHIN COLLECT_DATA(): %s", key + index)
                    self.output(key + index)

                result = self.main_tree.get(key + index)

        return result

    def append_data_to_main_tree(self, callback_result, it_key=None, idx_column=False):
        """
            Appends callback data to main tree. If proceeding the index column
            a list with rows is generated and returned to the row process routine:
            the data is just overwritten.
        """

        subtree = []
        
        for list_elem in callback_result:
            # get key
            column_oid = list_elem.keys()[0]

            # generate subtree
            for row in list_elem[column_oid]:
                index = "." + str(row['row'])
                # generate entry
                entry = column_oid + index

                # if not the index column, skip this and overwrite nodes
                if not idx_column:
                    # if entry oid with no prepending point received
                    if entry[:1] != ".":
                        entry = "." + entry

                    # check validity
                    entry_check = self.main_tree.get(entry)
                    # overwrite the values only if the cache is outdated
                    if not entry_check or entry_check[0]['expire'] < time.time():
                        try:
                            # try to set the row value for entry-key
                            self.main_tree[entry] = [row]
                        except:
                            # there a was a attempt to set a value for entry that
                            # already has a value
                            if column_oid[:1] != ".":
                                column_oid = "." + column_oid
                            # reset the value
                            self.main_tree[column_oid] = AXOrderedTree()
                            # store new value for entry
                            self.main_tree[entry] = [row]

                    self.refresh_cache(self.main_tree[entry])
                else:
                    # append to list
                    subtree.append((entry[len(it_key):], [row]))

        return AXOrderedTree(subtree)

    ## Communicate with SNMPD

    def output(self, line):
        sys.stdout.write("%s\n" % line)
        sys.stdout.flush()

    def confirm_receipt(self):
        """Perform the SNMPD handshake"""
        self.logger.debug("Confirming receipt with PONG...")

        try:
            self.output("PONG")
            self.logger.debug("Printing PONG done!")
        except Exception, ex:
            self.logger.exception("Sending PONG failed: %s", ex)

    def process_input(self, line) :
        '''
            Process SNMPD input, call subroutines
        '''
        if line.strip() == '':
            sys.exit(0)

        try:
            if 'PING' == line.strip():
                self.logger.debug("PING received.")
                self.confirm_receipt()

            elif 'getnext' == line.strip():
                self.target = sys.stdin.readline()
                self.logger.debug("GETNEXT request for %s", self.target)
                self.do_get_next(self.target)

            elif 'get' == line.strip():
                self.target = sys.stdin.readline()
                self.logger.debug("GET request for %s", self.target)
                self.do_get(self.target)

            elif 'set' == line.strip():
                # mark as SET-Request to get the value in the next read
                self.set_request = True
                self.target = sys.stdin.readline()
            elif self.set_request:
                value = line.strip()
                self.logger.debug("SET request for %s", self.target)
                # excecute set request
                self.do_set(self.target, value)
                self.set_request = False

        except Exception, ex:
            # if any error occurs, print NONE
            self.logger.exception(ex)
            self.print_none_response()

        self.logger.debug("Finishing processing line...")

    def read_stdin(self) :
        """
        Read from standard input.
        Use "select" to wait for new data.
        """

        try:
            (rr, wr, er) = select.select([sys.stdin], [], [])

            for fd in rr:
                line = fd.readline()
                self.process_input(line)
        except Exception, ex:
            self.logger.exception("ERROR while reading STDIN: %s", ex)


    def start_listening(self):
        """Listen to STDIN"""
        # Read StdIn
        while 1:
            # read input
            self.read_stdin()

        self.logger.debug("Process finished!")
