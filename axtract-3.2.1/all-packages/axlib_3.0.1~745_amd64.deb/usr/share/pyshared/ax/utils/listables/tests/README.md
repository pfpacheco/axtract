# Getting to a Test Setup for `test_listables.py`

> This is normally done when functionally testing axess, the zope server.
> i.e. there is the test data.


If you want to test outside of that, i.e. in PY3 then get yourself to a mysql
server or mariadb server, then:


1. Get the SQL dump from here:

    development_chroot root@ip-10-34-2-19:/opt/axess# cat src/axlib/bamboo_scripts/mysql_test_setup.sql

and

2. source it into your test db.


Then adapt a copy of `custom_db_env.sh` and source it before runnint the test.



## Problems and Fixes

### Duplicate data after test crashes

The tests do often not clean up at start, so you might have to source the test
data, which erases then refills all tables.


### underlying table doesn't have a default value


If you have an empty sql server, maria or mysql, make sure to disable strict
mode:

https://www.farbeyondcode.com/Solution-for-MariaDB-Field--xxx--doesn-t-have-a-default-value-5-2720.html

=> in mariadb, my.cnf: `sql_mode = NO_ENGINE_SUBSTITUTION` has to be set

guess in mysql strict mode off is doing the same.
