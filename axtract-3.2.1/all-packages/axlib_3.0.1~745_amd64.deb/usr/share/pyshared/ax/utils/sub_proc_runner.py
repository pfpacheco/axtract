
import warnings
from ax.utils.formatting.msgs import DeprecationMessage as DW

msg = DW( 'module moved away'
        , ticket       ='AXOS-589'
        , alternatives =('ax.daemon.processes',)
        )

# To see: python -W '' sub_proc_runner.py or $PYTHONWARNINGS
warnings.warn(msg, DeprecationWarning, stacklevel=1)

# let this crash if a later ax.daemon pip is not installed.
# (the user must change his imports when this happens, since
# ax.utils should NOT depend on anything else in axlib outside ax.utils:
#
from ax.daemon.processes.sub_proc import *


