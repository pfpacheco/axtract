import os
import pprint
import subprocess


def source_file(bash_file):
    """
    Doing a bash 'source' command within python, resulting in change of
    process environ.
    We use bash to do the parsing, i.e. the file can have bash specific cmds,
    like refs to other env vars or if else.

    Tradeoff: slow, involves a subprocess.
    """
    command = ['env', '-i', '/bin/bash', '-c', 'source %s && env' % bash_file]

    proc = subprocess.Popen(command, stdout = subprocess.PIPE)

    for line in proc.stdout:
        (key, _, value) = line.partition("=")
        os.environ[key] = value.strip()
    proc.communicate()


