# Template for custom test environ.
# This file is for manual testing only, never used in automated scenarios

# Source a copy of this adapted to your DB before running python test_listable.py

set -a
DB_NAME="live"
DB_USER="root"
DB_USER="ax"
DB_HOST="127.0.0.1"
DB_PORT=3306

# DB Driver is mysql.so if present, else PyMySQL if present. Else tests are
# skipped.

# Alternatively (preferred if set) you can set the whole URL in one go, i.e. dicatate
# also driver:
MYSQL_URL="mysql+pymysql://ax:ax@127.0.0.1:3307/live?charset=utf8mb4"
set +a

