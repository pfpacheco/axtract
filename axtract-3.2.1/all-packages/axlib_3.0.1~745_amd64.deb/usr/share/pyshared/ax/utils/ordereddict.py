"""Provide an OrderedDict that is usable in Zope"""
from collections import OrderedDict as Orig

# In python3 OrderedDict is a C-Extension => No assignments allowed
class OrderedDict(Orig):
   pass

# Zope RestrictedPython assumess structures (that are not dict or list) to
# have __guarded_setitem__, __guarded_delitem__, __guarded_setattr__, and
# __guarded_delattr__ attributes. For instance, classes not having these
# attributes are not allowed to do assignments or del operations.
# These statements will fail if the attributes are not included:
#     x['5'] = 1
#     del x['7']
# Some background can be found in the RestrictedPython/Guards.py:103
# Safe types don't need these attributes and skip the check for
# guarded attributes (Guards.py:118 => {dict: True, list: True}).
OrderedDict.__guarded_setitem__ = OrderedDict.__setitem__
OrderedDict.__guarded_delitem__ = OrderedDict.__delitem__


# attaching a pretty printer, mainly for debug sessions
def to_yaml(od):
    """Converts ordered dict to yaml which is convertable back to O.D. """
    from .convert import odict_to_yml
    return odict_to_yml(od)

# we should not change the __repr__ (which is ugly at pp)
OrderedDict.yml  = to_yaml
