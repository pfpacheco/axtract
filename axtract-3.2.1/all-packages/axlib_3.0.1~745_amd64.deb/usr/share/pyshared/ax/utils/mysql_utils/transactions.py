import contextlib

"""
This method allows to execute SQL queries as part of the same transaction
Usage like:
with mysql_transaction as connection:
    connection.execute(sql1)
    connection.execute(sql2)
sql1 and sql2 will be part of the same transaction

WARNING: Keep in mind that because all the connections in the typical AXESS
engine pool use autocommit by default we will need to disable the autocommit
and enable it again for every transaction. So this is function is intented to
be used for administrative actions rather than business logic related queries
"""
@contextlib.contextmanager
def mysql_transaction(engine):
    connection = engine.connect()
    try:
        # all are connections are using autocomit so first we need to
        # disable this
        connection.execute('SET autocommit=0')
        # start the transaction
        transaction = connection.begin()
    except Exception as e:
        # if something goes wrong the discard the connection while
        # telling the engine pool to lazily spawn another one so
        # that the pool is not distrurbed
        connection.invalidate(e)
        raise
    try:
        yield connection
    except Exception:
        # In case something is wrong in the context code, rollback and notify
        transaction.rollback()
        raise
    else:
        # all went well, COMMIT the transaction
        transaction.commit()
    finally:
        try:
            # restore the autocommit function before we put the 
            # connection back in the pool
            connection.execute('SET autocommit=1')
            connection.close()
        except Exception as e:
            # if something is wrong we don't want the connection to be left
            # with autocommit false so discard it
            connection.invalidate(e)

