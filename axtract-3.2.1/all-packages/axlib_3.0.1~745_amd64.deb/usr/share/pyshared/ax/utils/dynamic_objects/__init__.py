

import inspect, sys, operator, types, imp, os, stat

PY2 = sys.version_info[0] < 3

# in 3 only methods of real instances are "methods"
#is_func = inspect.ismethod if PY2 else inspect.isfunction

def to_func(m):
    try:
        return m.__func__ if PY2 else m
    except Exception as ex:
        # in py2 there are a few complications for the various callables,
        # this seems to be the most universal way.
        # If not for you then use a custom converter below:
        return m

to_staticm = lambda m: staticmethod(to_func(m))
to_classm  = lambda m: classmethod (to_func(m))

_no_filter = lambda *a, **kw: True
def methods(cls, filter=None):
    '''the filter we always is use is the pretty wide callable'''
    filter = _no_filter if filter is None else filter
    meths = [(k, getattr(cls, k)) for k in dir(cls)]
    meths = [(k, meth) for k, meth in meths \
            if k[:2] != '__' and callable(meth) and filter(k, meth)]
    return meths


def convert_methods(cls, filter=None, converter=None, into=None):
    into = cls if into is None else into
    converter = converter or (lambda m: m)
    adder = operator.setitem if isinstance(into, dict) else setattr
    [adder(into, fn, converter(meth)) for fn, meth in methods(cls, filter)]


def make_staticmethods(cls, filter=None):
    '''
    Sometimes its useful to just make a **namespace** for otherwise static
    functions within a module.

    Then classes come handy to give them that.

    This avoids having to add the deocorators which clutter the code.
    '''
    convert_methods(cls, filter, converter=lambda m: to_staticm(m))



def make_classmethods(cls, filter=None):
    '''
    When namespaces for sets of functions can be cloned into new ones we
    use classmethods.

    This avoids having to add the deocorators which clutter the code.
    '''
    convert_methods(cls, filter, converter=lambda m: to_classm(m))



# --------------------------------------------------------------------- modules
def mod_changed(have, osstat):
    mt, s = stat.ST_MTIME,  stat.ST_SIZE
    return (have.get(mt), have.get(s)) != (osstat[mt], osstat[s])

def mod_reload_on_change(mod_path, name=None, _last_stats={}):
    '''
    Reloads a module only if there are changes of file AND size.
    mod_path: slashed
    _last_stats: internal
    '''
    mt, sz = stat.ST_MTIME,  stat.ST_SIZE
    # we index by import path:
    last = _last_stats.get(mod_path)
    if last:
        fn = last['fn_abs']
        try:
            s = os.stat(fn)
            if not mod_changed(last, s):
                return last
        except:
            pass

    if name == None:
        name = mod_path
    (fd, pathname, description) = imp.find_module(mod_path)
    #fn = os.path.abspath(mod_path)
    try:
        mod = imp.load_module(name, fd, pathname, description)
    finally:
        fd.close()

    fn = mod_path
    s = os.stat(pathname)
    st = (s[mt], s[sz])

    m = {mt: s[mt],
         sz: s[sz],
         'mod': mod,
         'fn': fn,
         'fn_abs': os.path.abspath(pathname)
        }
    _last_stats[mod_path] = m
    return m

def get_mod(mod_path):
    return (sys.modules.get(mod_path) if mod_path in sys.modules else
            mod_reload_on_change(mod_path)['mod'])
