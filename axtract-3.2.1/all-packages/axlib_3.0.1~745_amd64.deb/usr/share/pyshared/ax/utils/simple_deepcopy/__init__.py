try:
    from ._simple_deepcopy import deepcopy
except:
    pass
