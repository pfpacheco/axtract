#!/usr/bin/python -tt
"""
agnad: Axiros Global Numbers ADministrator

Provides a command line interface to most functionality in
ax.utils.globalnumbers. That includes:
    - List current variables
    - Adding to / Subtractring from variables
    - Setting variables to certain values
    - Resetting an entire registry to zero
    - Creating  new variables to ensure a certain type.
"""
from __future__ import print_function

import re
import simplejson
import sys

from optparse import OptionParser

from ax.utils.globalnumbers import GlobalNumbers


class GlobalNumbersAdministrator(object):
    """Class to perform various actions on GlobalNumbers

    See below how it is used.
    """
    def __init__(self, operation, varname, value, registries):
        self.operation = operation
        self.varname = varname
        self.value = value
        self.registries = registries

        # The return code to use once the program finishes normally. A
        # non-zero return code indicates that at least one (not neccessarily
        # every) operation failed. When no operations are performed because
        # no matching name was found, the return code is still 0.
        self.return_code = 0

    def run(self):
        func = getattr(self, "operation_" + self.operation, None)
        if func is None:
            raise NotImplementedError
        func()

    def name_matches(self, name):
        """Return True if $name matches the --name or --variables, else False

        This is a helper function for the self.operation_xxx() methods.
        """
        if self.varname is None:
            return True
        elif isinstance(self.varname, basestring):
            return name == self.varname
        else:
            return re.search(self.varname, name) is not None

    def operation_add(self):
        """Implement the --add operation"""
        for filename in self.registries:
            globnum = GlobalNumbers(filename)
            registry_data = globnum.get_registry_data()
            if not registry_data:
                print("No variables at all in the registry %s" % filename)
                continue

            matches = 0
            for name, data in registry_data.items():
                if self.name_matches(name):
                    matches += 1
                    increment = float(self.value)
                    globnum.increment(name, increment)
                    print("Added %s to %s in registry %s" % (
                            self.value, name, filename))
            if matches == 0:
                print("None of the variables in registry %s matched." % filename)

    def operation_sub(self):
        """Implement the --sub operation"""
        for filename in self.registries:
            globnum = GlobalNumbers(filename)
            registry_data = globnum.get_registry_data()
            if not registry_data:
                print("No variables at all in the registry %s" % filename)
                continue

            matches = 0
            decrement = float(self.value)
            for name, data in registry_data.items():
                if not self.name_matches(name):
                    continue

                matches += 1
                try:
                    globnum.decrement(name, decrement)
                except Exception as exc:
                    print(("Error: Could not subtract from %s "
                            "in registry %s: %s") % (name, filename, exc), file=sys.stderr)
                    self.return_code = 1
                else:
                    print("Subtracted %s from %s in registry %s" % (
                            self.value, name, filename))
            if matches == 0:
                print("None of the variables in registry %s matched." % filename)

    def operation_print_human(self):
        """Print human-readable variables & values"""
        # Figure out the longest name and value we have. With that knowledge,
        # formatting can be adapted.
        longest_name = 15
        longest_value = 4
        for filename in self.registries:
            globnum = GlobalNumbers(filename)
            registry_data = globnum.get_registry_data()
            for name, data in registry_data.items():
                longest_name = max(longest_name, len(name))
                longest_value = max(longest_value, len(str(int(data[3]))))
        longest_float = str(longest_value + 7)
        longest_int = str(longest_value)

        for filename in self.registries:
            globnum = GlobalNumbers(filename)
            registry_data = globnum.get_registry_data()
            if not registry_data:
                print("No variables at all in the registry %s" % filename)
                continue

            lines = []
            for name, data in registry_data.items():
                if self.name_matches(name):
                    current_value = data[3]
                    to_fill = longest_name - len(name)
                    dots = " " * (to_fill % 5) + "  .  " * (to_fill / 5)
                    if isinstance(current_value, float):
                        format_string = "    %s%s = %" + longest_float + ".6f"
                    else:
                        format_string = "    %s%s = %" + longest_int + "d"
                    lines.append(format_string % (name, dots, current_value))

            if lines:
                lines.sort()
                print("Variables in registry %s:" % filename)
                print("\n".join(lines))
            else:
                print("None of the variables in registry %s matched." % filename)

    def operation_print_machine(self):
        """Print machine-readable variables & values

        Less chatty than print_human to be easier to parse. Names and values
        are separated by a single space.
        """
        for filename in self.registries:
            globnum = GlobalNumbers(filename)
            registry_data = globnum.get_registry_data()
            if not registry_data:
                continue

            for name, data in registry_data.items():
                if self.name_matches(name):
                    current_value = data[3]
                    print("%s %s" % (name, current_value))

    def operation_print_json(self):
        """Print machine-readable variables & values in JSON format

        JSON has this format
            {"registry1": {"foo": 42, "bar": 3.141}, "registry2": {...}, ...}
        """
        result = {}
        for filename in self.registries:
            result[filename] = {}
            globnum = GlobalNumbers(filename)
            registry_data = globnum.get_registry_data()
            if not registry_data:
                continue

            for name, data in registry_data.items():
                if self.name_matches(name):
                    current_value = data[3]
                    result[filename][name] = current_value
        print(simplejson.dumps(result))

    def operation_ensure_int(self):
        if not isinstance(self.varname, basestring):
            print("You did not provide a --name", file=sys.stderr)
            sys.exit(1)
        for filename in self.registries:
            globnum = GlobalNumbers(filename)
            try:
                globnum.ensure_int_type(self.varname)
            except TypeError as exc:
                self.return_code = 1
                print("Error working with store %s: %s" % (
                        filename, exc), file=sys.stderr)

    def operation_ensure_uint(self):
        if not isinstance(self.varname, basestring):
            print("You did not provide a --name", file=sys.stderr)
            sys.exit(1)
        for filename in self.registries:
            globnum = GlobalNumbers(filename)
            try:
                globnum.ensure_uint_type(self.varname)
            except TypeError as exc:
                self.return_code = 1
                print("Error working with store %s: %s" % (
                        filename, exc), file=sys.stderr)

    def operation_ensure_long(self):
        if not isinstance(self.varname, basestring):
            print("You did not provide a --name", file=sys.stderr)
            sys.exit(1)
        for filename in self.registries:
            globnum = GlobalNumbers(filename)
            try:
                globnum.ensure_long_type(self.varname)
            except TypeError as exc:
                self.return_code = 1
                print("Error working with store %s: %s" % (
                        filename, exc), file=sys.stderr)

    def operation_ensure_ulong(self):
        if not isinstance(self.varname, basestring):
            print("You did not provide a --name")
            sys.exit(1)
        for filename in self.registries:
            globnum = GlobalNumbers(filename)
            try:
                globnum.ensure_ulong_type(self.varname)
            except TypeError as exc:
                self.return_code = 1
                print("Error working with store %s: %s" % (
                        filename, exc), file=sys.stderr)

    def operation_ensure_fp(self):
        if not isinstance(self.varname, basestring):
            print("You did not provide a --name", file=sys.stderr)
            sys.exit(1)
        for filename in self.registries:
            globnum = GlobalNumbers(filename)
            try:
                globnum.ensure_float_type(self.varname)
            except TypeError as exc:
                self.return_code = 1
                print("Error working with store %s: %s" % (
                        filename, exc), file=sys.stderr)

    def operation_reset(self):
        """Implement the --reset operation"""
        if self.varname is not None:
            print(("--reset will reset ALL values. You cannot "
                    "use it with --name or --values"), file=sys.stderr)
            sys.exit(1)
        for filename in self.registries:
            print("Resetting all values in registry %s to zero." % filename)
            globnum = GlobalNumbers(filename)
            globnum.reset_values()

    def operation_set(self):
        """Implement the --set operation"""
        for filename in self.registries:
            globnum = GlobalNumbers(filename)
            registry_data = globnum.get_registry_data()
            for name in registry_data:
                if not self.name_matches(name):
                    continue

                new_value = float(self.value)
                try:
                    type_info = globnum.get_registry_data()[name][1]
                except Exception:
                    type_info = ""
                if new_value < 0 and type_info.startswith("U"):
                    print(("Error: Cannot assign a negative "
                            "value to variable %s, since it is an unsigned "
                            "int/long.") % name, file=sys.stderr)
                    self.return_code = 1
                    continue
                try:
                    globnum.set_value(name, new_value)
                except Exception as exc:
                    self.return_code = 1
                    print(("Error: Cannot assign variable '%s' "
                            "to %s: %s") % (name, new_value, exc), file=sys.stderr)
                else:
                    print("Value %s in registry %s was set to %s" % (
                            name, filename, new_value))

    def operation_remove(self):
        print(("Removing variables is not supported at the moment. You will "
                "have to remove the registry and restart any daemons using it."), file=sys.stderr)
        sys.exit(1)


def parse_options(options, args):
    config = {}
    config['value'] = None

    valid_operations = ["print_human", "print_machine", "print_json",
            "reset", "remove", "set", "add", "sub", "ensure_int",
            "ensure_uint", "ensure_long", "ensure_ulong", "ensure_fp"]
    chosen_operation = ""
    for operation in valid_operations:
        if getattr(options, operation) is not None:
            # This operation is set. It must be the only operation.
            if chosen_operation:
                print("Conflicting operations: %s and %s" % (
                        chosen_operation, operation), file=sys.stderr)
                sys.exit(1)
            else:
                chosen_operation = operation
                config['value'] = getattr(options, operation)

    if chosen_operation:
        config['operation'] = chosen_operation
    else:
        config['operation'] = "print_human"

    if options.name and options.variables:
        print("You cannot combine --name and --variables", file=sys.stderr)
        sys.exit(1)

    if not options.name and not options.variables:
        if config['operation'] in (
                "print_human", "print_machine", "print_json", "reset"):
            # OK to not specify a name, just match all.
            config['varname'] = None
        else:
            print(("You must specify the variable(s) to work "
                    "with. Either via --name or --variables"), file=sys.stderr)
            sys.exit(1)
    elif options.name:
        config['varname'] = options.name
    else:
        config['varname'] = re.compile(options.variables)

    if not args:
        print("You did not provide any registry file(s)", file=sys.stderr)
        sys.exit(1)
    config['registries'] = args

    return config


def get_options():
    usage = """agnad.py [options] registry_1 (registry_2 ...)
    For example,
        agnad.py --set=42 --name=answer /var/lib/axtract/my_registry.globnum
    will set the item named "answer" in the registry
    /var/lib/axtract/my_registry.globnum to the value 42 and
        agnad.py --print-json /var/lib/axtract/my_registry.globnum
    will print all items in this registry in JSON format."""
    parser = OptionParser(usage=usage)
    parser.add_option("--print", dest="print_human", action="store_true",
            help="Print variables&values in human readable format")
    parser.add_option("--print-machine", dest="print_machine",
            action="store_true", help=("Print variables&values in machine "
            "readable format (separated by a single space)."))
    parser.add_option("--print-json", dest="print_json",
            action="store_true", help=("Print variables&values in JSON "
            "format (each registry in its own object)"))
    parser.add_option("--reset", dest="reset", action="store_true",
            help="Set ALL variables to zero")
    parser.add_option("--remove", dest="remove", action="store_true",
            help="Remove variables from the registry")

    parser.add_option("--set", dest="set",
            help="Set variables to given value")
    parser.add_option("--add", dest="add",
            help="Add given value to the variables.")
    parser.add_option("--sub", dest="sub",
            help="Subtract given value from the variables")

    parser.add_option("--ensure_int", dest="ensure_int", action="store_true",
            help="Ensure that given value is of type 32 or 64 bit integer")
    parser.add_option("--ensure_uint", dest="ensure_uint", action="store_true",
            help=("Ensure that given value is of type unsigned 32 or "
            "64 bit integer"))
    parser.add_option("--ensure_long", dest="ensure_long", action="store_true",
            help="Ensure that given value is of type 64 bit integer")
    parser.add_option("--ensure_ulong", dest="ensure_ulong",
            action="store_true",
            help="Ensure that given value is of type unsigned 64 bit integer")
    parser.add_option("--ensure_fp", dest="ensure_fp", action="store_true",
            help="Ensure that given value is of type 64 bit fixed point.")

    parser.add_option("--name", dest="name",
            help="Name of variable to use for the operation")
    parser.add_option("--variables", dest="variables",
            help=("Regular expression for the names of variables to use "
                "during the operation. This uses re.search(), so e.g. "
                "--variables=yy will match a variable called 'xxyyzz'"))

    return parser.parse_args()

def run():
    options, args = get_options()
    config = parse_options(options, args)
    agnad = GlobalNumbersAdministrator(config['operation'], config['varname'],
            config['value'], config['registries'])
    agnad.run()
    sys.exit(agnad.return_code)


if __name__ == "__main__":
    run()
