import unittest


class ParameterValueStruct(dict):
    def __init__(self, *args, **kwargs):
        dict.__init__(self, *args, **kwargs)
        self._ax_soap_dic = 1


class TestSoapPyAx(unittest.TestCase):
    def _gen_message(self, body):
        return '''<?xml version="1.0" encoding="UTF-8"?>
            <SOAP-ENV:Envelope
                SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"
                xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/"
                xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
                xmlns:xsd="http://www.w3.org/1999/XMLSchema"
                xmlns:xsi="http://www.w3.org/1999/XMLSchema-instance"
                xmlns:xsd3="http://www.w3.org/2001/XMLSchema">
                    <SOAP-ENV:Body>%s</SOAP-ENV:Body>
            </SOAP-ENV:Envelope>''' % body

    def _gen_tr069_message(self, body):
        return """<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
    xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/"
    xmlns:xsd="http://www.w3.org/2001/XMLSchema"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xmlns:cwmp="urn:dslforum-org:cwmp-1-1">
    <SOAP-ENV:Header>
    <cwmp:ID SOAP-ENV:mustUnderstand="1">1566993092.37</cwmp:ID>
    </SOAP-ENV:Header>
    <SOAP-ENV:Body>
    %s
    </SOAP-ENV:Body>
    </SOAP-ENV:Envelope>""" % body

    def _get_test_message(self):
        return b'<?xml version="1.0" encoding="UTF-8"?>\n<SOAP-ENV:Envelope SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/" xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/1999/XMLSchema" xmlns:xsi="http://www.w3.org/1999/XMLSchema-instance" xmlns:xsd3="http://www.w3.org/2001/XMLSchema">\n<SOAP-ENV:Body>\n<v1 SOAP-ENC:root="1">\n<pv_list SOAP-ENC:arrayType="xsd:ParameterValueStruct[18]" xsi:type="SOAP-ENC:Array">\n<EventStruct>\n<Name>x01</Name>\n<Value xsi:type="xsd:string">abc</Value>\n</EventStruct>\n<EventStruct>\n<Name>x02</Name>\n<Value xsi:type="xsd:boolean">true</Value>\n</EventStruct>\n<EventStruct>\n<Name>x03</Name>\n<Value xsi:type="xsd:boolean">false</Value>\n</EventStruct>\n<EventStruct>\n<Name>x04</Name>\n<Value xsi:type="xsd:decimal">10</Value>\n</EventStruct>\n<EventStruct>\n<Name>x05</Name>\n<Value xsi:type="xsd:float">1</Value>\n</EventStruct>\n<EventStruct>\n<Name>x06</Name>\n<Value xsi:type="xsd:dateTime">2020-06-10T14:00:00Z</Value>\n</EventStruct>\n<EventStruct>\n<Name>x07</Name>\n<Value xsi:type="xsd3:hexBinary">616263</Value>\n</EventStruct>\n<EventStruct>\n<Name>x08</Name>\n<Value xsi:type="xsd3:base64Binary">YWJj</Value>\n</EventStruct>\n<EventStruct>\n<Name>x09</Name>\n<Value xsi:type="xsd:binary" encoding="base64">YWJj</Value>\n</EventStruct>\n<EventStruct>\n<Name>x10</Name>\n<Value xsi:type="xsd:integer">103</Value>\n</EventStruct>\n<EventStruct>\n<Name>x11</Name>\n<Value xsi:type="xsd:integer">1</Value>\n</EventStruct>\n<EventStruct>\n<Name>x12</Name>\n<Value xsi:type="xsd:double">1.0</Value>\n</EventStruct>\n<EventStruct>\n<Name>x13</Name>\n<Value xsi:type="xsd:string">abc</Value>\n</EventStruct>\n<EventStruct>\n<Name>x14</Name>\n<Value xsi:null="1"/>\n</EventStruct>\n<EventStruct>\n<Name>x15</Name>\n<Value xsi:type="xsd:integer">False</Value>\n</EventStruct>\n<EventStruct>\n<Name>x16</Name>\n<Value xsi:type="xsd:string">abc</Value>\n</EventStruct>\n<EventStruct>\n<Name>x17</Name>\n<Value>un</Value>\n</EventStruct>\n<EventStruct>\n<Name>x18</Name>\n<Value xsi:type="xsd:string">&lt;&gt;</Value>\n</EventStruct>\n</pv_list>\n<other>test</other>\n</v1>\n</SOAP-ENV:Body>\n</SOAP-ENV:Envelope>\n'

    def test_imports(self):
        # This tests that all the imports are working under python3
        from ax.utils.lib.SOAPpy_ax import (
            Client,
            Config,
            Errors,
            fpconst,
            NS,
            Parser,
            Server,
            SOAPBuilder,
            Types,
            URLopener,
            Utilities,
            version,
            WSDL
        )

    def test_soap_builder(self):
        from ax.utils.lib.SOAPpy_ax.Types import (
            arrayType,
            untypedType,
            structType,
            stringType,
            booleanType,
            decimalType,
            floatType,
            dateTimeType,
            hexBinaryType,
            base64BinaryType,
            binaryType,
            integerType
        )

        from ax.utils.lib.SOAPpy_ax.SOAPBuilder import buildSOAP

        def gen_pv(name, value):
            return ParameterValueStruct(Name=untypedType(name), Value=value)

        items = []
        items.append(gen_pv('x01', stringType('abc')))
        items.append(gen_pv('x02', booleanType(True)))
        items.append(gen_pv('x03', booleanType(0)))
        items.append(gen_pv('x04', decimalType(10)))
        items.append(gen_pv('x05', floatType(1.0)))
        items.append(gen_pv('x06', dateTimeType((2020, 6, 10, 14, 0, 0))))
        items.append(gen_pv('x07', hexBinaryType('abc')))
        items.append(gen_pv('x08', base64BinaryType('abc')))
        items.append(gen_pv('x09', binaryType('abc')))
        items.append(gen_pv('x10', integerType(103)))
        items.append(gen_pv('x11', 1))
        items.append(gen_pv('x12', 1.0))
        items.append(gen_pv('x13', "abc"))
        items.append(gen_pv('x14', None))
        items.append(gen_pv('x15', False))
        items.append(gen_pv('x16', u'abc'))
        items.append(gen_pv('x17', untypedType('un')))
        items.append(gen_pv('x18', stringType('<>')))

        message = {
            'pv_list': arrayType(items, elemsname="EventStruct"),
            'other': untypedType('test')
        }

        result = buildSOAP(message)
        self.assertEqual(self._get_test_message(), result)

    def test_parse_soap(self):
        from ax.utils.lib.SOAPpy_ax import parseSOAPRPC
        result = parseSOAPRPC(self._get_test_message().decode('ascii'))
        result = result._asdict()
        result['pv_list'] = [ob._asdict() for ob in result['pv_list']]

        ref = {
            'pv_list': [
                {'Name': 'x01', 'Value': 'abc'},
                {'Name': 'x02', 'Value': 1},
                {'Name': 'x03', 'Value': 0},
                {'Name': 'x04', 'Value': 10.0},
                {'Name': 'x05', 'Value': 1.0},
                {'Name': 'x06', 'Value': (2020, 6, 10, 14, 0, 0.0)},
                {'Name': 'x07', 'Value': 'abc'},
                {'Name': 'x08', 'Value': b'abc'},
                {'Name': 'x09', 'Value': b'abc'},
                {'Name': 'x10', 'Value': 103},
                {'Name': 'x11', 'Value': 1},
                {'Name': 'x12', 'Value': 1.0},
                {'Name': 'x13', 'Value': 'abc'},
                {'Name': 'x14', 'Value': None},
                {'Name': 'x15', 'Value': 'False'},
                {'Name': 'x16', 'Value': 'abc'},
                {'Name': 'x17', 'Value': 'un'},
                {'Name': 'x18', 'Value': '<>'}
            ],
            'other': 'test'
        }

        self.assertEqual(ref, result)

    def test_parse_datetime_from_string(self):
        from ax.utils.lib.SOAPpy_ax import parseSOAPRPC
        from ax.utils.lib.SOAPpy_ax.Types import dateTimeType

        body = """<Value xsi:type="xsd3:dateTime">2020-06-10T14:00:00</Value>"""
        result = parseSOAPRPC(self._gen_message(body))
        self.assertEqual((2020, 6, 10, 14, 0, 0.0), result)

        ob = dateTimeType('2020-06-10T14:00:00')
        self.assertEqual((2020, 6, 10, 14, 0, 0.0), ob._data)

    def test_add_header(self):
        from ax.utils.lib.SOAPpy_ax.Types import headerType
        from ax.utils.lib.SOAPpy_ax.Types import stringType
        from ax.utils.lib.SOAPpy_ax import buildSOAP

        data = {"ID": stringType("envid", typed=0)}
        data ["ID"]._setMustUnderstand(1)

        header = headerType(data=data, typed=1)

        result = buildSOAP(
            noroot=1,
            envelope=0,
            kw={'a': 'b'},
            header=header,
            method='test_add_header')

        ref = b'<?xml version="1.0" encoding="UTF-8"?>\n<SOAP-ENV:Header>\n<ID SOAP-ENV:mustUnderstand="1">envid</ID>\n</SOAP-ENV:Header>\n<SOAP-ENV:Body>\n<test_add_header>\n<a xsi:type="xsd:string">b</a>\n</test_add_header>\n</SOAP-ENV:Body>\n'

        self.assertEqual(ref, result)

    def test_boolean_type(self):
        from ax.utils.lib.SOAPpy_ax.Types import booleanType
        self.assertTrue(booleanType(1))
        self.assertFalse(booleanType('0'))

    def test_parse_transfer_complete(self):
        from ax.utils.lib.SOAPpy_ax import parseSOAPRPC
        from ax.utils.lib.SOAPpy_ax.Types import structType
        body = """
                <cwmp:TransferComplete>
                   <CommandKey>AXConfigStorage</CommandKey>
                   <FaultStruct>
                   <FaultCode>0</FaultCode>
                   <FaultString></FaultString>
                   </FaultStruct>
                   <StartTime>2019-08-28T13:51:32</StartTime>
                   <CompleteTime>2019-08-28T13:51:32</CompleteTime>
                </cwmp:TransferComplete>
        """
        result = parseSOAPRPC(self._gen_tr069_message(body))
        result = result._asdict()
        self.assertEqual(result["CommandKey"], "AXConfigStorage")
        self.assertEqual(result["CompleteTime"], "2019-08-28T13:51:32")
        self.assertEqual(result["StartTime"], "2019-08-28T13:51:32")
        self.assertTrue(isinstance(result["FaultStruct"], structType))
        self.assertEqual(result["FaultStruct"]._asdict()["FaultCode"], "0")
        self.assertEqual(result["FaultStruct"]._asdict()["FaultString"], "")

if __name__ == "__main__":
    unittest.main()
