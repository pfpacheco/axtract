import os
import threading
import time

# After fork the WatcherThread is stopped *but* if if you call watcher.start
# the following error is raised.
# File "/usr/lib/python2.6/threading.py", line 467, in start
# raise RuntimeError("thread already started")
# => associate the watchers with the process pid
_watchers = {}


def _create_watcher(filename, reload_func):
    watcher = ConfigWatcher(reload_func)
    watcher.daemon = True
    watcher.last_mtime = os.stat(filename).st_mtime
    watcher.filename = filename
    return watcher


def start_watcher(filename, reload_func):
    """Starts a watcher for logging config

    @param filename: File to watch for changes
    @param reload_func: Called when the file changed.
                        It is called like this reload_func(filename)

    Hint: This method is *NOT* thread safe.
    => Don't call it from separate threads. Only on startup from the main one.
    """

    pid = os.getpid()
    if pid not in _watchers:
        watcher = _watchers[pid] = _create_watcher(filename, reload_func)
    else:
        watcher = _watchers[pid]

    if not watcher.is_alive():
        if watcher.run_called:
            watcher = _watchers[pid] = _create_watcher(filename, reload_func)
        watcher.start()
    return watcher


def stop_watcher():
    pid = os.getpid()
    if pid not in _watchers:
        return

    _watchers[os.getpid()].stop_me = True
    _watchers[os.getpid()].join(0.5)


class ConfigWatcher(threading.Thread):
    def __init__(self, reload_func):
        self.filename = None
        self.last_mtime = None
        self.stop_me = False

        # Threads cannot be started twice, there is no official API
        # to check if a Thread was already started :(
        self.run_called = False

        # Called when it is time to reload
        self.reload_func = reload_func

        threading.Thread.__init__(self)

    def run(self):
        # This flag makes it possible to check if the Thread was already started
        self.run_called = True

        while not self.stop_me:
            if self.stop_me:
                return

            try:
                self._do_single_run()
            except Exception as error:
                print ('Error while single run', error)

            time.sleep(1.0)

    def _do_single_run(self):
        if self.last_mtime != os.stat(self.filename).st_mtime:
            # In case of slow and buffered writing, wait before reading
            if os.stat(self.filename).st_mtime > (time.time() - 5):
                time.sleep(5)

            try:
                self.reload_func(self.filename)
            except Exception as error:
                # Hmm where to log if an error occurs while parsing the file
                print ('Error while processing config file', error)
            else:
                self.last_mtime = os.stat(self.filename).st_mtime
