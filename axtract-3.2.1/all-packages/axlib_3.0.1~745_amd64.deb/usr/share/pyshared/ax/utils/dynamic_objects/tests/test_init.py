import unittest
import inspect
from ax.utils.dynamic_objects import make_staticmethods, make_classmethods
from ax.utils.dynamic_objects import convert_methods, methods, to_func

class AG:
    def bar():
        'bar'
        return 23
    def foo(a):
        'doc'
        return [a, AG.foo, AG.bar()]

    def leave(self, b):
        return b

AG.anon = lambda x, y: x * y


class TestInit(unittest.TestCase):

    def test_extract_functions(self):
        m = {}
        convert_methods(AG, into=m, converter=to_func)
        assert m['anon'] and m['bar'] and m['foo'] and m['leave']
        assert m['bar']() == 23
        assert m['anon'](3,4) == 12


    def test_to_static(self):

        class A(AG):
            def foo(a):
                'foodoc'
                return [a+a, A.foo, A.bar()]

        make_staticmethods(A, filter=lambda n, meth: n!='leave')

        def test(A):
            l = A.foo(1)
            eq = self.assertEqual
            eq ( A.foo.__doc__, 'foodoc')
            eq ( A.bar.__doc__, 'bar')
            eq ( l[0], 2)
            eq ( l[2], 23)
            eq ( inspect.isfunction    ( l[1])    , True)
            eq ( A().leave(2), 2)
            eq ( A.anon(2, 3), 6)

        test(A)
        make_staticmethods(A, filter=lambda n, meth: n!='leave')
        test(A)



    def test_to_classmethod(self):
        class A:
            i = 'a'
            def bar(cls):
                'bar'
                return cls.i

            def foo(cls, a):
                'doc'
                return [a, cls.foo, cls.bar()]

            def leave(self, b):
                return b

        class B(A): i='b'

        A.anon = lambda cls, x, y: x * y
        inspect.ismethod(B.foo)

        make_classmethods(B, filter=lambda n, meth: n!='leave')

        def test(B):
            l = B.foo(11)
            eq = self.assertEqual
            eq ( B.foo.__doc__, 'doc')
            eq ( B.bar.__doc__, 'bar')
            eq ( l[0], 11)
            eq ( l[2], 'b')
            eq ( B().leave(2), 2)
            eq ( B.anon(2, 3), 6)
            # A unchanged:
            eq ( A().anon(2, 3), 6)
            eq ( A().bar(), 'a')


        test(B)




if __name__ == "__main__":
    unittest.main()

