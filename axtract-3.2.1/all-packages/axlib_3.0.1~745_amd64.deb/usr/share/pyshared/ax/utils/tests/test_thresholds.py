#!/usr/bin/python -tt

import os
import unittest2
import inspect
from ax.utils.thresholds import ThresholdEngineByConfig
from ax.utils.thresholds import ThresholdEngine


class TestThresholdEngineByConfig(unittest2.TestCase):
    def setUp(self):
        self.filepath = '/tmp/my_cfg.json'

    def tearDown(self):
        if os.path.isfile(self.filepath):
            os.remove(self.filepath)

    def test_invalid_cfg(self):
        self.assertRaises(Exception, ThresholdEngineByConfig, None)
        self.assertRaises(Exception, ThresholdEngineByConfig, [])
        self.assertRaises(Exception, ThresholdEngineByConfig, ())
        self.assertRaises(Exception, ThresholdEngineByConfig, object())
        self.assertRaises(Exception, ThresholdEngineByConfig, 0)
        self.assertRaises(Exception, ThresholdEngineByConfig, 'bogus')

    def test_with_cfg_as_dict(self):
        engine = ThresholdEngineByConfig({})
        self.assertTrue(
            isinstance(engine.get_engine_by_param('param'), ThresholdEngine),
            "%s is not a ThresholdEngine instance" % engine
        )

    def test_with_cfg_as_json_file(self):
        JSON_CFG = '{"thresholds": {}}'

        with open(self.filepath, 'w') as json_file:
            json_file.write(JSON_CFG)

        engine = ThresholdEngineByConfig(self.filepath)
        self.assertTrue(
            isinstance(engine.get_engine_by_param('param'), ThresholdEngine),
            "%s is not a ThresholdEngine instance" % engine
        )


class TestThresholdEngine(unittest2.TestCase):
    def setUp(self):
        self.LOWER = "LOWER_IS_BETTER"
        self.HIGHER = "HIGHER_IS_BETTER"
        self.INNER = "INNER_IS_BETTER"
        self.OUTER = "OUTER_IS_BETTER"

    def tearDown(self):
        pass

    def _run_engine(self, cfg, value, expected):
        engine = ThresholdEngine(cfg)
        self.assertEqual(engine(value), expected,
            "cfg=%s + value=%s should give '%s'" % (cfg, value, expected))

    def test_no_cfg(self):
        self._run_engine([], 'whatever', 'unknown')
        self._run_engine((), 'whatever', 'unknown')

    def test_invalid_cfg(self):
        self.assertRaises(Exception, ThresholdEngine, 1)
        self.assertRaises(Exception, ThresholdEngine, 1.3)
        self.assertRaises(Exception, ThresholdEngine, 'BOGUS')
        self.assertRaises(Exception, ThresholdEngine, {})
        self.assertRaises(Exception, ThresholdEngine, None)
        self.assertRaises(Exception, ThresholdEngine, object())

        self.assertRaises(Exception, ThresholdEngine, ([1.0],))
        self.assertRaises(Exception, ThresholdEngine,
            ([1.0], 'LOWER_IS_BETTER', 'bogus'))
        self.assertRaises(Exception, ThresholdEngine,
            ('bogus', [1.0], 'LOWER_IS_BETTER'))
        self.assertRaises(Exception, ThresholdEngine,
            ([1.0], 'bogus', 'LOWER_IS_BETTER'))

    def test_invalid_order(self):
        self.assertRaises(Exception, ThresholdEngine,
            ([1.0], 'BOGUS_ORDER'))
        self.assertRaises(Exception, ThresholdEngine,
            ([1.0, 2.0], 'BOGUS_ORDER'))
        self.assertRaises(Exception, ThresholdEngine,
            ([[1.0, 2,0]], 'BOGUS_ORDER'))
        self.assertRaises(Exception, ThresholdEngine,
            ([[1.0, 2,0], [0.6, 2.4]], 'BOGUS_ORDER'))

    def test_invalid_thresholds(self):
        self.assertRaises(Exception, ThresholdEngine, ([2.0, 1.0], self.LOWER))
        self.assertRaises(Exception, ThresholdEngine, ([2.0, 1.0], self.HIGHER))

        self.assertRaises(Exception, ThresholdEngine, ([2.0, 1.0], self.INNER))
        self.assertRaises(Exception, ThresholdEngine, ([2.0, 1.0], self.OUTER))

        self.assertRaises(Exception, ThresholdEngine,
            ([['', 2.0], [0.5, 2.5]], self.INNER))
        self.assertRaises(Exception, ThresholdEngine,
            ([[1.0, ''], [0.5, 2.5]], self.INNER))
        self.assertRaises(Exception, ThresholdEngine,
            ([[1.0, 2.0], ['', 2.5]], self.INNER))
        self.assertRaises(Exception, ThresholdEngine,
            ([[1.0, 2.0], [0.5, '']], self.INNER))

        self.assertRaises(Exception, ThresholdEngine,
            ([[1.0, 2.0], [2.5, 0.5]], self.INNER))
        self.assertRaises(Exception, ThresholdEngine,
            ([[2.0, 1.0], [0.5, 2.5]], self.INNER))
        self.assertRaises(Exception, ThresholdEngine,
            ([[2.0, 1.0], [2.5, 0.5]], self.INNER))

        self.assertRaises(Exception, ThresholdEngine,
            ([['', 2.0], [0.5, 2.5]], self.OUTER))
        self.assertRaises(Exception, ThresholdEngine,
            ([[1.0, ''], [0.5, 2.5]], self.OUTER))
        self.assertRaises(Exception, ThresholdEngine,
            ([[1.0, 2.0], ['', 2.5]], self.OUTER))
        self.assertRaises(Exception, ThresholdEngine,
            ([[1.0, 2.0], [0.5, '']], self.OUTER))

        self.assertRaises(Exception, ThresholdEngine,
            ([[1.0, 2.0], [2.5, 0.5]], self.OUTER))
        self.assertRaises(Exception, ThresholdEngine,
            ([[2.0, 1.0], [0.5, 2.5]], self.OUTER))
        self.assertRaises(Exception, ThresholdEngine,
            ([[2.0, 1.0], [2.5, 0.5]], self.OUTER))

    def test_inner_outer_no_interval(self):
        self.assertRaises(Exception, ThresholdEngine,
            ([[1.0, 2.0], 3.0], self.INNER))
        self.assertRaises(Exception, ThresholdEngine,
            ([0.5, [1.0, 2.0]], self.INNER))
        self.assertRaises(Exception, ThresholdEngine,
            ([0.5, 3.0], self.INNER))

        self.assertRaises(Exception, ThresholdEngine,
            ([[1.0, 2.0], 3.0], self.OUTER))
        self.assertRaises(Exception, ThresholdEngine,
            ([0.5, [1.0, 2.0]], self.OUTER))
        self.assertRaises(Exception, ThresholdEngine,
            ([0.5, 3.0], self.OUTER))

    def test_inner_outer_intervals_relation(self):
        self.assertRaises(Exception, ThresholdEngine,
            ([[1.0, 2.0], [1.5, 2.5]], self.INNER))
        self.assertRaises(Exception, ThresholdEngine,
            ([[1.5, 2.5], [1.0, 2.0]], self.INNER))
        self.assertRaises(Exception, ThresholdEngine,
            ([[0.5, 2.5], [1.0, 2.0]], self.INNER))

        self.assertRaises(Exception, ThresholdEngine,
            ([[1.0, 2.0], [1.5, 2.5]], self.OUTER))
        self.assertRaises(Exception, ThresholdEngine,
            ([[1.5, 2.5], [1.0, 2.0]], self.OUTER))
        self.assertRaises(Exception, ThresholdEngine,
            ([[0.5, 2.5], [1.0, 2.0]], self.OUTER))

    def test_lower_one_threshold(self):
        ths = [1.0]

        self._run_engine((ths, self.LOWER), 0.3, 'good')
        self._run_engine((ths, self.LOWER), 1.0, 'good')
        self._run_engine((ths, self.LOWER), 1.2, 'bad')

    def test_lower_two_thresholds(self):
        ths = [1.0, 2.0]

        self._run_engine((ths, self.LOWER), 0.3, 'good')
        self._run_engine((ths, self.LOWER), 1.0, 'good')
        self._run_engine((ths, self.LOWER), 1.2, 'marginal')
        self._run_engine((ths, self.LOWER), 2.0, 'marginal')
        self._run_engine((ths, self.LOWER), 2.1, 'bad')

    def test_higher_one_threshold(self):
        ths = [1.0]

        self._run_engine((ths, self.HIGHER), 0.3, 'bad')
        self._run_engine((ths, self.HIGHER), 1.0, 'good')
        self._run_engine((ths, self.HIGHER), 1.2, 'good')

    def test_higher_two_thresholds(self):
        ths = [1.0, 2.0]

        self._run_engine((ths, self.HIGHER), 0.3, 'bad')
        self._run_engine((ths, self.HIGHER), 1.0, 'marginal')
        self._run_engine((ths, self.HIGHER), 1.2, 'marginal')
        self._run_engine((ths, self.HIGHER), 2.0, 'good')
        self._run_engine((ths, self.HIGHER), 2.1, 'good')

    def test_inner_one_interval(self):
        ths = [[1.0, 2.0]]

        self._run_engine((ths, self.INNER), 0.3, 'bad')
        self._run_engine((ths, self.INNER), 1.0, 'good')
        self._run_engine((ths, self.INNER), 1.2, 'good')
        self._run_engine((ths, self.INNER), 2.0, 'good')
        self._run_engine((ths, self.INNER), 2.1, 'bad')

    def test_inner_two_intervals(self):
        ths = [[1.0, 2.0], [0.6, 2.4]]

        self._run_engine((ths, self.INNER), 0.3, 'bad')
        self._run_engine((ths, self.INNER), 0.6, 'marginal')
        self._run_engine((ths, self.INNER), 0.8, 'marginal')
        self._run_engine((ths, self.INNER), 1.0, 'good')
        self._run_engine((ths, self.INNER), 1.7, 'good')
        self._run_engine((ths, self.INNER), 2.0, 'good')
        self._run_engine((ths, self.INNER), 2.1, 'marginal')
        self._run_engine((ths, self.INNER), 2.4, 'marginal')
        self._run_engine((ths, self.INNER), 2.7, 'bad')

    def test_outer_one_interval(self):
        ths = [[1.0, 2.0]]

        self._run_engine((ths, self.OUTER), 0.3, 'good')
        self._run_engine((ths, self.OUTER), 1.0, 'good')
        self._run_engine((ths, self.OUTER), 1.2, 'bad')
        self._run_engine((ths, self.OUTER), 2.0, 'good')
        self._run_engine((ths, self.OUTER), 2.1, 'good')

    def test_outer_two_intervals(self):
        ths = [[1.0, 2.0], [0.6, 2.4]]

        self._run_engine((ths, self.OUTER), 0.3, 'good')
        self._run_engine((ths, self.OUTER), 0.6, 'good')
        self._run_engine((ths, self.OUTER), 0.8, 'marginal')
        self._run_engine((ths, self.OUTER), 1.0, 'marginal')
        self._run_engine((ths, self.OUTER), 1.7, 'bad')
        self._run_engine((ths, self.OUTER), 2.0, 'marginal')
        self._run_engine((ths, self.OUTER), 2.1, 'marginal')
        self._run_engine((ths, self.OUTER), 2.4, 'good')
        self._run_engine((ths, self.OUTER), 2.7, 'good')

    def test_get_intervals_no_cfg(self):
        engine = ThresholdEngine(())
        self.assertEqual(engine.get_intervals(), {},
            'Intervals, no cfg')

    def test_get_intervals_jsonisable(self):
        engine = ThresholdEngine(([1.0], self.LOWER))
        self.assertEqual(engine.get_intervals(True), (
                (('minus_inf', 1.0), 'good'),
                ((1.0, 'plus_inf'), 'bad')
            ), 'Intervals, LOWER_IS_BETTER, one threshold')

    def test_get_intervals_lower(self):
        engine = ThresholdEngine(([1.0], self.LOWER))
        self.assertEqual(engine.get_intervals(), {
                (-float('inf'), 1.0): 'good',
                (1.0, float('inf')): 'bad'
            }, 'Intervals, LOWER_IS_BETTER, one threshold')

        engine = ThresholdEngine(([1.0, 2.0], self.LOWER))
        self.assertEqual(engine.get_intervals(), {
                (-float('inf'), 1.0): 'good',
                (1.0, 2.0): 'marginal',
                (2.0, float('inf')): 'bad'
            }, 'Intervals, LOWER_IS_BETTER, two thresholds')

    def test_get_intervals_higher(self):
        engine = ThresholdEngine(([1.0], self.HIGHER))
        self.assertEqual(engine.get_intervals(), {
                (-float('inf'), 1.0): 'bad',
                (1.0, float('inf')): 'good'
            }, 'Intervals, HIGHER_IS_BETTER, one threshold')

        engine = ThresholdEngine(([1.0, 2.0], self.HIGHER))
        self.assertEqual(engine.get_intervals(), {
                (-float('inf'), 1.0): 'bad',
                (1.0, 2.0): 'marginal',
                (2.0, float('inf')): 'good'
            }, 'Intervals, HIGHER_IS_BETTER, two thresholds')

    def test_get_intervals_inner(self):
        engine = ThresholdEngine(([[1.0, 2.0]], self.INNER))
        self.assertEqual(engine.get_intervals(), {
                (-float('inf'), 1.0): 'bad',
                (1.0, 2.0): 'good',
                (2.0, float('inf')): 'bad'
            }, 'Intervals, INNER_IS_BETTER, one interval')

        engine = ThresholdEngine((
            [[1.0, 2.0], [0.5, 2.5]], self.INNER))

        self.assertEqual(engine.get_intervals(), {
                (-float('inf'), 0.5): 'bad',
                (0.5, 1.0): 'marginal',
                (1.0, 2.0): 'good',
                (2.0, 2.5): 'marginal',
                (2.5, float('inf')): 'bad'
            }, 'Intervals, INNER_IS_BETTER, two intervals')

    def test_get_intervals_outer(self):
        engine = ThresholdEngine(([[1.0, 2.0]], self.OUTER))
        self.assertEqual(engine.get_intervals(), {
                (-float('inf'), 1.0): 'good',
                (1.0, 2.0): 'bad',
                (2.0, float('inf')): 'good'
            }, 'Intervals, OUTER_IS_BETTER, one interval')

        engine = ThresholdEngine((
            [[1.0, 2.0], [0.5, 2.5]], self.OUTER))

        self.assertEqual(engine.get_intervals(), {
                (-float('inf'), 0.5): 'good',
                (0.5, 1.0): 'marginal',
                (1.0, 2.0): 'bad',
                (2.0, 2.5): 'marginal',
                (2.5, float('inf')): 'good'
            }, 'Intervals, OUTER_IS_BETTER, two intervals')


if __name__ == '__main__':
    unittest2.main()
