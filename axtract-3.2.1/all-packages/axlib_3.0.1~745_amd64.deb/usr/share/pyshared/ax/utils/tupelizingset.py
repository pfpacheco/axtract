class TupelizingSet(set):
    """
    Defines a class which behaves like a regular set but allows construction
    from iterables which contain lists in the first level. Those will be
    automatically converted to tuples.
    """
    def __init__(self, data=[]):
        data = (tuple(d) if isinstance(d, list) else d for d in data)
        super(TupelizingSet, self).__init__(data)
