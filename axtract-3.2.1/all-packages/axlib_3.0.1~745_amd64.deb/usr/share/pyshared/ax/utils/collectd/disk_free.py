import os
import argparse
import ax.utils.collectd


class DFPlugin(ax.utils.collectd.BasePlugin):
    plugin_type = 'df'

    def __init__(self, args):
        super(DFPlugin, self).__init__()

        self.args = args

    def print_stats(self):
        for path in self.args.paths:
            try:
                self.stats_for_path(path)
            except Exception as error:
                msg = "Cannot generate disk free stats for path (%s): %s"
                self.log_error(msg % (path, error))

    def stats_for_path(self, path):
        st = os.statvfs(path)
        blocksize = self.get_block_size(st)
        if not blocksize > 0:
            raise Exception("Invalid blocksize(%s): %s" % (blocksize, st))

        # Size of the entire filesystem
        total = self.get_and_validate(st, 'f_blocks')

        # Total blocks free
        free = self.get_and_validate(st, 'f_bfree')

        # Number of free blocks for unprivileged users
        avail = self.get_and_validate(st, 'f_bavail')

        # Ensure that total >= free => avail
        if free < avail:
            free = avail

        if total < free:
            total = free

        used = total - free
        reserved = free - avail

        if path == '/':
            path_name = 'root'
        else:
            path_name = path.strip('/').replace('/', '-')

        self.submit(path_name, 'df_complex', 'free', free * blocksize)
        self.submit(path_name, 'df_complex', 'reserved', reserved * blocksize)
        self.submit(path_name, 'df_complex', 'used', used * blocksize)

    @staticmethod
    def get_block_size(st):
        return st.f_frsize if st.f_frsize else st.f_bsize

    def get_and_validate(self, st, fieldname):
        # There are some filesystems which report negative numbers.
        # We don't support them.
        val = getattr(st, fieldname)
        if not val >= 0:
            raise Exception("Field (%s) is less than 0: %s" % (fieldname, st))
        return val


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('paths', nargs='+')
    return parser.parse_args()


def main():
    DFPlugin(parse_args()).main()
