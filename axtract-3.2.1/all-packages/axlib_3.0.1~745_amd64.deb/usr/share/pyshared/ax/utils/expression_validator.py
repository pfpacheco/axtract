from itertools import product
from pyparsing import Word
from pyparsing import alphanums
from pyparsing import Or
from pyparsing import Literal
from pyparsing import QuotedString
from pyparsing import printables
from pyparsing import Optional


class ExpressionValidator(object):
    """Check if a object fits to a list of expressions

    This should be used if the list of expressions is *FIXED* and the object you
    want to check is pretty dynamic.
    For example in Axtract it is used to calc the monitoring mode of a CPE.
    A list of expression (called match_list) can look like this
    ["DI.SN =~ thomson", "DI.PRC =! AXConfigured"]

    For such a match_list this class generates efficient python code,
    so match_list has not to be parsed all the time

    A match_list is a list of strings where each string looks like this
    "[&|]fieldname_to_check <OPERATOR> REF_VALUE"

    * Each string can be prefixes with '&' or "|" and says how this string
      should be concatenated with a previous one. '&' means AND '|' means OR.
      If the sting has no such prefix AND is implicitly used

    * 'fieldname_to_check' can be a arbitrary string.
      This value is given to the operator function

    * 'OPERATOR' All possible operators are defined in the
      operator_registry given at __init__ time.
      => this class does *NOT* enforce the operators to use

    * 'REF_VALUE' can be a arbitrary string.
      This value is given to the operator function

    Look at the examples folder of AXOS to see how this class can be used
    """
    __slots__ = ('_parser', '_evaluator', '__call__')

    def __init__(self, operator_registry, match_list):
        if len(match_list) == 0:
            raise Exception("Cannot build a validator with a match_list")

        self._parser = self._build_match_parser(operator_registry)

        match_functions = []
        operators = []

        clause, cpe_attr, op, expression = self._parse(match_list[0])
        match_func = operator_registry[op](cpe_attr, expression)
        match_functions.append(match_func)

        for match in match_list[1:]:
            clause, cpe_attr, op, expression = self._parse(match)
            match_func = operator_registry[op](cpe_attr, expression)
            match_functions.append(match_func)
            operators.append(clause)

        self._evaluator = LazyAndOrEvaluator(operators, match_functions)
        # add shortcut, to avoid attribute lookup
        self.__call__ = self._evaluator.__call__

    @staticmethod
    def _build_match_parser(operator_registry):
        # In the beginning of a match &,| can be used to define a boolean
        # operation between the previous match
        def rename_and_or(s, l, t):
            if t[0] == '&': return 'and'
            if t[0] == '|': return 'or'
        parser = Optional(Word('&|'), default='&').setParseAction(rename_and_or)

        # CPE-Attribute match
        parser += Word(alphanums + "$", alphanums + '.' + '_' + '-')

        # Operators
        parser += Or([Literal(op) for op in operator_registry])

        # there are two types of <expression>
        # 1) without double quotes => strip leading/trailing whitespaces
        # 2) with double quotes => allow whitespaces in beginning/end
        #  example for 2) 'cpe.foo =~ " be "'
        # IMPORANT: double quotes inside the expression need to be escaped

        # strip leading/trailing whitespaces
        strip = lambda s,l,t: t[0].strip()
        exp_without_db_quotes = Word(printables + ' ').setParseAction(strip)

        exp_with_db_quotes = QuotedString('"', '\\')
        or_exp = Or([exp_with_db_quotes, exp_without_db_quotes])
        # make the expression optional, which means empty string is set.
        parser += Optional(or_exp, default='')

        return parser

    def _parse(self, match):
        # leading whitespaces lead to a wrong expression if qoutes are used
        match = match.strip()
        try:
            return self._parser.parseString(match)
        except Exception as e:
            raise Exception("Error parsing %s: %s" % (match, e))

def name_gen():
    repeat = 1
    while True:
        for name in product('abcdefghijklmnop', repeat=repeat):
            yield ''.join(name)
        repeat  += 1

class AndOrEvaluator(object):
    """
    If you want lazy execution of the incoming args, look at the file
    tests/test_tools.py.
    The class TestAndOrEvaluator has a case called test_lazy_class_call,
    which shows how to do this, by having a class overriding the __nonzero__
    method
    """

    _static_arg_tpl = """def _function(%s): return %s\nret = _function"""

    def __init__(self, operators):
        """ operators is a list of and, or """

        if len(operators) == 0:
            raise Exception("No operators make this code senseless")
        for op in operators:
            if op not in ['and', 'or']:
                raise Exception("Wrong operator given: %s" % op)

        self._static_arg_fun = self._build_eval_function(operators)

    def _build_eval_function(self, operators):
        _name_gen = name_gen()
        arg_list = [next(_name_gen)]
        expr = ['bool(%s)' % arg_list[0]]

        for operator in operators:
            expr.append(operator)
            arg_name = next(_name_gen)

            expr.append('bool(%s)' % arg_name)
            arg_list.append(arg_name)

        function_str = self._static_arg_tpl % (','.join(arg_list), ' '.join(expr))

        variable_scope = {'ret' : None}
        exec(function_str, variable_scope)
        return variable_scope['ret']

    def __call__(self, args):
        return self._static_arg_fun(*args)

class LazyAndOrEvaluator(object):
    """
    The AndOrEvaluator is pretty generic, but in some circumstances the user of
    AndOrEvaluator-class has to write too much code.

    The current class is for lazy programmers, which have the specific use case
    * set of functions which should be executed lazily
    * each function is called with one single argument
    * this argument is the same for all functions
    If you need a more complex case look at the class above
    """
    __slots__ = ('__call__')

    _tpl = """
class ret(object):
    __slots__ = (%(slots)s)

    def __init__(self, %(initargs)s):
        %(initbody)s

    def __call__(self, arg):
        return %(callbody)s
"""
    def __init__(self, operators, functions):
        for op in operators:
            if op not in ['and', 'or']:
                raise Exception("Wrong operator given: %s" % op)

        if (len(operators)+1) != len(functions):
            msg = "Number of operators does not match to number of functions"
            raise Exception(msg)

        created_class = self._build_class(operators, functions)
        _instance = created_class(*functions)
        self.__call__ = _instance.__call__

    def _build_class(self, operators, functions):
        _name_gen = name_gen()
        fun_names = [next(_name_gen) for _ in functions]
        format_str = {
            'slots' : self._gen_slots(fun_names),
            'initargs' : self._gen_initargs(fun_names),
            'initbody' : self._gen_init_body(fun_names),
            'callbody' : self._gen_call_body(operators, fun_names)
        }

        class_str = self._tpl % format_str

        variable_scope = {'ret' : None}
        exec(class_str, variable_scope)
        return variable_scope['ret']

    def _gen_slots(self, fun_names):
        return ','.join([ ('"%s"' % x) for x in fun_names])

    def _gen_initargs(self, fun_names):
        return ','.join(fun_names)

    def _gen_init_body(self, fun_names):
        init_body = []
        for name in fun_names:
            init_body.append('self.%s = %s' % (name, name))
        return ';'.join(init_body)

    def _gen_call_body(self, operators, fun_names):
        operators = list(operators)
        call_body = []
        for name in fun_names[:-1]:
            call_body.append("self.%s(arg) %s" % (name, operators.pop(0)))
        call_body.append("self.%s(arg)" % fun_names[-1])
        return ' '.join(call_body)
