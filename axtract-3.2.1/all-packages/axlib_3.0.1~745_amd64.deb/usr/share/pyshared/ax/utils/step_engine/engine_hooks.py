import abc
import time

from . import constants

_now = time.time


class EngineHooksInterface(object):
    __metaclass__ = abc.ABCMeta

    """Hooks for a protocol handler.

    This class describes the hooks a protocol handler must implement.
    A instance of such a class is given to the StepEngine and the step engine
    uses this class to perform callbacks to the protocol handler if needed.
    """

    @abc.abstractmethod
    def lookup_method(self, methodname):
        """Return a callable for a scenario with name 'methodname'"""
        pass

    @abc.abstractmethod
    def is_atomic(self, methodname):
        """Returns true/false if a method is atomic or not"""
        pass

    @abc.abstractmethod
    def gen_scenario_id(self, methodname, initargs, parent_id):
        """Generate a new unique ID for a new scenario"""
        pass

    @abc.abstractproperty
    def logger(self):
        """Return a logger object or None."""
        pass

    def handle_scenario_error(self, sc, error):
        """Called when a scenario raised an exception.

        @param sc: dic having the current scenario state like step, methodname
        @param error: exception instace which was thrown by the scenario

        The default implementation here just logs it.
        Feel free to override it if you need specific things
        to happen on errors inside a scenario.
        """

        msg = "Error in step(%s) of scenario (%s)."
        if self.logger:
            self.logger.exception(
                msg,
                sc[constants.KEY_STEP],
                sc[constants.KEY_METHOD_NAME]
            )


class ExampleHooks(EngineHooksInterface):
    """Example implementation.

    Main use is from unittests.
    """

    def __init__(self, methods_registry, atomics):
        self.methods_registry = methods_registry
        self.atomics = set(atomics)

    def lookup_method(self, methodname):
        return self.methods_registry[methodname]

    def is_atomic(self, methodname):
        return methodname in self.atomics

    def gen_scenario_id(self, methodname, initargs, parent_id):
        return repr(_now())

    @property
    def logger(self):
        return None
