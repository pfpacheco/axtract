#!/usr/bin/python -tt
"""Tests for udp_echo_plus_client and udp_echo_plus_server"""

import subprocess
import unittest2

try:
    f = open ("/etc/init.d/ax_udp_echo_plus")
except:
    integration_test = True
else:
    integration_test = False

@unittest2.skipIf(integration_test, "Cannot run integration test")
class SpecScheduleTester(unittest2.TestCase):
    """Unit tests for RepeatSpec and RepeatSchedule"""

    def tearDown(self):
        # Ensure the daemon is stopped when we quit.
        subprocess.call(["/etc/init.d/ax_udp_echo_plus", "stop"])

    def gather_debug_information(self):
        try:
            ifconfig = subprocess.check_output(["/sbin/ifconfig"])
        except Exception as exc:
            ifconfig = "/sbin/ifconfig excepted: %s" % exc

        try:
            log_data = subprocess.check_output(["cat",
                "/var/log/ax.utils/udp_echo_plus_server.log"])
        except Exception as exc:
            log_data = "Getting log data excepted: %s" % exc

        try:
            config_file = subprocess.check_output(["cat",
                "/etc/default/ax_udp_echo_plus"])
        except Exception as exc:
            config_file = "Reading config file excepted: %s" % exc

        return ("ifconfig information:\n" +  ifconfig +
                "\nlog data\n" + log_data +
                "\nconfig file\n" + config_file)

    def client_server_communication(self):
        """Have our own client communicate with our own server"""

        # Write config that uses UDP port 0 -> Kernel will assign any free port
        with open("/etc/default/ax_udp_echo_plus", "w") as stream:
            stream.write("SERVICE_ENABLED=true\n")
            stream.write('EXTRA_ARGS="$EXTRA_ARGS --port=7"')
        return_code = subprocess.call(["/etc/init.d/ax_udp_echo_plus", "start"])
        self.assertEqual(return_code, 0)

        # Have our client contact the server, check the output.
        output = subprocess.check_output([
            "udp_echo_plus_client",
            "--port=7",
            "--count=3",
            "--interval=0.1",
            "127.0.0.1"
        ])

        """ Output should look like this:

    Round trip time:  0.66 msec
    Server processing time:  0.26 msec
    Round trip time:  1.07 msec
    Server processing time:  0.48 msec
    Round trip time:  0.95 msec
    Server processing time:  0.44 msec

Average round trip time: 0.892 msec
Average server processing time: 0.393 msec
Packets sent: 3  Packets lost: 0
        """
        self.assertNotIn("Timeout", output)
        self.assertNotIn("Traceback", output)

        self.assertIn("Average round trip time", output)
        self.assertIn("Average server processing time", output)
        self.assertIn("Packets sent: 3  Packets lost: 0", output)

        self.assertEqual(output.count("msec"), 8)
        self.assertEqual(output.count("Round trip time:"), 3)
        self.assertEqual(output.count("Server processing time:"), 3)

        # Shut down the server again.
        return_code = subprocess.call(["/etc/init.d/ax_udp_echo_plus", "status"])
        self.assertEqual(return_code, 0)
        return_code = subprocess.call(["/etc/init.d/ax_udp_echo_plus", "stop"])
        self.assertEqual(return_code, 0)
        return_code = subprocess.call(["/etc/init.d/ax_udp_echo_plus", "status"])
        self.assertNotEqual(return_code, 0)

    def test_client_server_communication(self):
        try:
            self.client_server_communication()
        except Exception:
            print (self.gather_debug_information())
            raise


if __name__ == "__main__":
    unittest2.main()

