#!/usr/bin/python -tt
import unittest2

from ax.utils.ax_queue import AXQueue as Queue
import sys, os

import ax.utils.workerpool as workerpool


class Counter(object):
    'Counter resource used for testing EquippedWorker.'

    def __init__(self):
        self.count = 0


class CountJob(workerpool.Job):
    'Job that just increments the count in its resource and append it to the'
    'results queue.'

    def __init__(self, results):
        self.results = results

    def run(self, toolbox):
        'Append the current count to results and increment.'
        self.results.put(toolbox.count)
        toolbox.count += 1


in_gevent = os.environ.get('ENFORCE_GEVENT_DURING_BUILD_TESTS')


@unittest2.skipIf(in_gevent, 'gevent, we cannot block on queue')
class TestEquippedWorkers(unittest2.TestCase):
    def test_equipped(self):
        '''
        Created equipped worker that will use an internal Counter resource to
        keep track of the job count.
        '''
        results = Queue()

        def toolbox_factory():
            return Counter()

        def worker_factory(job_queue):
            return workerpool.EquippedWorker(job_queue, toolbox_factory)

        pool = workerpool.WorkerPool(1, worker_factory=worker_factory)

        # Run 10 jobs
        for i in range(10):
            j = CountJob(results)
            pool.put(j)

        # Get 10 results
        for i in range(10):
            r = results.get()
            # Each result should be an incremented value
            self.assertEqual(r, i)

        pool.shutdown()
        pool.join()


if __name__ == '__main__':
    unittest.main()
