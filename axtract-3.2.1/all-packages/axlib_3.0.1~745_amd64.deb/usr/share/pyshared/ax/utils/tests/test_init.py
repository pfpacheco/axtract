#!/usr/bin/python -tt
"""Tests for functionality in __init__.py"""
import shutil
import sys
import tempfile
import unittest2

from ax.utils import get_object_from_module

class TestInit(unittest2.TestCase):
    def test_get_object(self):
        """get_object_from_module must load the specified item"""

        module_code = """
class Foo(object):
    this_must_exist = True
"""
        temp_dir_name = tempfile.mkdtemp()
        try:
            with open(temp_dir_name + "/foo_module.py", "w") as module_file:
                module_file.write(module_code)

            imported_object = get_object_from_module("foo_module.Foo",
                    temp_dir_name)
            self.assertEqual(imported_object.this_must_exist, True)
        finally:
            shutil.rmtree(temp_dir_name)

    def test_get_object_has_stable_syspath(self):
        """get_object_from_module must not modify sys.path

        Check if AXOS-105 is fixed.
        """
        old_syspath = list(sys.path)
        try:
            sys.path.append("/foo")
            sys.path.append("/bar")
            path_initial = list(sys.path)

            try:
                get_object_from_module("does.not.exist", "/foo")
            except ImportError:
                # This is expected to happen.
                pass

            self.assertEqual(path_initial, list(sys.path))
        finally:
            sys.path = old_syspath

    def test_path_modifications(self):
        """correct part of sys.path must be removed

        The imported module might have modified sys.path itself, so
        get_object_from_module() cannot assume that the first/last item
        in sys.path is the one it added.
        """
        old_sys_path = list(sys.path)
        module_code = """
import sys
sys.path.insert(0, "/inserted_at_beginning")
sys.path.append("/what_was_appended")
class Foo2(object):
    this_must_exist2 = True
    is_in_cache = False
"""
        old_max_diff = self.maxDiff
        temp_dir_name = tempfile.mkdtemp()
        try:
            with open(temp_dir_name + "/foo_module2.py", "w") as module_file:
                module_file.write(module_code)

            imported_object = get_object_from_module("foo_module2.Foo2",
                    temp_dir_name)
            self.assertEqual(imported_object.this_must_exist2, True)


            # NOTE: When you call
            #           get_object_from_module("foo_module.Foo", first_path)
            #           get_object_from_module("foo_module.Foo", second_path)
            # The second call will give you the item that was loaded with the
            # first call, even if second_path has different code.
            # Since this test case may be run twice in the same Python instance,
            # we need to check if this object comes from the cache (= the
            # sys.path.append() from module_code was not run) or was really
            # freshly imported.
            if imported_object.is_in_cache:
                return
            imported_object.is_in_cache = True


            sys_path_should_be = ["/inserted_at_beginning"] + old_sys_path + \
                    ["/what_was_appended"]
            # To see full diff if lists are not equal.
            self.maxDiff = None
            self.assertListEqual(sys_path_should_be, sys.path)
        finally:
            sys.path = old_sys_path
            self.maxDiff = old_max_diff
            shutil.rmtree(temp_dir_name)

    def test_enforce_search_path(self):
        """get_object...() must ensure it is really loading from search path

        A module of identical name may exist somewhere in the sys.path, but
        this module is not what we want to import.
        This checks if AXOS-127 is fixed.
        """
        old_sys_path = list(sys.path)
        temp_dir_name = tempfile.mkdtemp()
        temp_dir_name2 = tempfile.mkdtemp()
        module_code_template = """
class Foo3(object):
    module_choice = "%s"
"""
        try:
            with open(temp_dir_name + "/foo_module3.py", "w") as module_file:
                module_file.write(module_code_template % "correct module")
            with open(temp_dir_name2 + "/foo_module3.py", "w") as module_file:
                module_file.write(module_code_template % "wrong module")

            # Add the path with the wrong module as first item in sys.path.
            sys.path.insert(0, temp_dir_name2)

            imported_object = get_object_from_module("foo_module3.Foo3",
                    temp_dir_name)
            self.assertEqual(imported_object.module_choice, "correct module")
        finally:
            sys.path = old_sys_path
            shutil.rmtree(temp_dir_name)
            shutil.rmtree(temp_dir_name2)


if __name__ == "__main__":
    unittest2.main()

