class Framework:
    """ adapting the param configs to various client frameworks """

    class Kendo:
        model_types = {'str': 'string', 'int': 'number',
                       'datetime': 'date', 'bool': 'boolean'}
        @classmethod
        def adapt(Kendo, lt_config, **kw):
            ''' build columns and model for master params, adapt formats to
            Kendo '''
            sd, p, km = lt_config, lt_config['params'], Kendo.model_types
            cols, model = [], {}
            for k in sd.get('master_params') or p.keys():
                v = p.get(k)
                if not v:
                    if not k.startswith('count_'):
                        raise Exception((k, 'no definition', lt_config))
                    h = k.split('_')
                    w, tit, typ = '5em', h[0].capitalize() + h[1], 'number'
                else:
                    t = v['type']
                    w, tit, typ = ('%sem' % (min(v.get('width') or 0, 40)),
                                   v['title'], km.get(t, 'string'))
                cols.append({'field': k, 'title': tit, 'width': w})
                if v:
                    col = cols[-1]
                    if v.get('hidden'):
                        col['hidden'] = True
                    if v.get('template'):
                        col['template'] = v.get('template')
                    # our datetime format is this:
                    if v.get('type') == 'datetime':
                        col['format'] = "{0: yyyy-MM-dd HH:mm:ss}"
                        col['filterable'] = {'ui': 'datetimepicker'}


                model[k] = {'type': typ}
            m = {'columns': cols, 'model': {'fields': model}}
            if 'ico' in lt_config:
                m['ico'] = lt_config['ico']
            return m




