# These are the keys for the scenario dict.
# Still using envid and camel case for CPEManager compatibility.

# Unique ID for a scenario.
KEY_SC_ID = 'envid'

# Current step a scenario is in.
KEY_STEP = 'step'

# Current status of a scenario.
KEY_STATUS = 'status'

# Name of the scenario to execute.
KEY_METHOD_NAME = 'id'

KEY_INITARGS = 'initargs'

# Result of
# - a previous step
# - a parent scenario
# - atomic call from the protocol handler
KEY_LAST_RESULT = 'lastResult'

# ID of the parent scenario
KEY_PARENT_ID = 'callerEnvId'

# Keeps local state for the current scenario
KEY_LOCAL_STATE = 'local_state'

# Seconds since epoch when this scenrio was created
KEY_CREATION_TIME = 'ts'

# Keeps global state for the current step engine.
KEY_GLOBAL_STATE = 'global_state'

# These are the possible values for the scenario status

# The next step of this scenario is ready to be called.
STATUS_READY = 'ready'

# This scenario is waiting for a result
STATUS_WAITING_FOR_RESULT = 'wait_for_result'

# This scenario is successfuly finished
STATUS_SUCCESS = 'success'

# This scenario is failed + finished
STATUS_FAILED = 'failed'
