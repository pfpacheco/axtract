from struct import pack, unpack, unpack_from
from netaddr import IPAddress
import socket

import time
import decoder
from constants import *

import traceback

import logging

class IPDRCollector(object):

    vendor_id = "Python IPDR Collector"
    collector_socket = None
    timeout = 2
    keep_alive = 60
    capabilities = 0x01

    last_received_data_raw = None
    last_ipdr_exporter_msg = ()

    dsn_config_id = None
    dsn_sequence = None

    connected = None
    session_id = 1

    decoded_data = {}

    session_info = {}

    data_processing = False
    data_capture_running_time = 0
    data_capture_running = 0
    data_capture_keep_alive = 0
    data_capture_data_count = 0
    received_data = ""
    data_ack = 0
    ack_sequence = 0
    ack_time = 0

    templates = {}

    _decoders = {
        "string" : decoder.decode_utf8_string,
        "long" : decoder.decode_long,
        "int" : decoder.decode_int,
        "u_int" : decoder.decode_uint,
        "byte" : decoder.decode_char,
        "u_byte" : decoder.decode_unsigned_char,
        "double" : decoder.decode_double,
        "float" : decoder.decode_float,
        "boolean" : decoder.decode_boolean,
        "short" : decoder.decode_short,
        "u_short" : decoder.decode_unsigned_short,
        "ip_addr" : decoder.decode_ip_address,
        "ipv6addr" : decoder.decode_ipv6addr,
        "ipv4addr" : decoder.decode_ipv4addr,
        "uuid" : decoder.decode_uuid,
        "u_long" : decoder.decode_unsigned_long,
        "date_time" : decoder.decode_date_time,
        "date_time_msec" : decoder.decode_date_time_msec,
        "date_time_usec" : decoder.decode_date_time_usec,
        "mac_addr" : decoder.decode_mac,
        "hex_binary" : decoder.decode_hex_binary
    }

    def __init__(self, host, port, **kwargs):
        self.host = host
        self.port = port

        if "KeepAlive" in kwargs:
            self.keep_alive = kwargs.get("KeepAlive")
        if "Capabilities" in kwargs:
            self.capabilities = kwargs.get("Capabilities")
        if "Timeout" in kwargs:
            self.timeout = kwargs.get("Timeout")
        if "VendorID" in kwargs:
            self.vendor_id = kwargs.get("VendorID")

        self.logger = logging.getLogger("IPDR Collector")
        FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        logging.basicConfig(format=FORMAT, level=logging.ERROR, filename="ipdr_collector.log")

    def connect(self):
        self.logger.debug("Connecting to the IPDR exporter...")
        self.collector_socket = socket.socket(socket.AF_INET,
                                              socket.SOCK_STREAM)
        socket_info = self.collector_socket.getsockname()
        self.local_ip = socket_info[0]
        self.local_port = socket_info[1]
        self.collector_socket.connect((self.host, self.port))
        self.connected = True

    def disconnect(self):
        self.logger.debug("Disconnecting...")
        self.connected = False
        self.collector_socket.close()

    def check_data_available(self):
        # send connect message
        self.send_connect_message()

        while self.connected:
            # check received data
            self._receive_data()
            while self.data_processing:
                msg_type = self.decode_received_message()
                self.logger.debug("Message received: %s", msg_type)
                if msg_type is None:
                    self.data_processing = False

                if msg_type == "CONNECT_RESPONSE":
                    # get sessions
                    self.send_get_sessions_message()
                    continue
                elif  msg_type == "GET_SESSIONS_RESPONSE":
                    # send flow start
                    self.send_flow_start_message()
                    continue
                elif msg_type == "TEMPLATE_DATA":
                    # send final template data ack
                    self.send_final_template_data_ack_message()
                    continue
                elif  msg_type == "SESSION_START":
                    # ask keep alive status
                    self.send_keep_alive_message()
                    continue
                elif  msg_type == "KEEP_ALIVE":
                    self.send_keep_alive_message()
                    continue
                elif "DATA" in msg_type:
                    self.decode_data()
                    if self.dsn_sequence:
                        self.data_capture_running_time = time.time()
                        self.data_capture_data_count = 0
                        self.send_data_ack_message(self.dsn_config_id,
                                                   self.dsn_sequence)

                    if self.data_capture_data_count >= self.ack_sequence:
                        if self.dsn_sequence:
                            self.data_capture_data_count = 0
                            self.send_data_ack_message(self.dsn_config_id,
                                                       self.dsn_sequence)

                elif msg_type == "SESSION_STOP":
                    self.send_keep_alive_message()
                    continue

                if time.time() - self.data_capture_keep_alive > self.keep_alive:
                    self.logger.debug("Last keep alive exceeded: send KEEP ALIVE message")
                    self.send_keep_alive_message()
                    self.data_capture_keep_alive = time.time()

    def send_connect_message(self):
        """Send the connect message to the IPDR exporter"""
        self.logger.debug("Sending CONNECT message to IPDR exporter...")
        message = pack("!LHLL",
                       self.create_initiator_id(),
                       self.local_port,
                       self.capabilities,
                       self.keep_alive);
        message += self.vendor_id;

        header = self._generate_ipdr_message_header(2, "CONNECT", len(message));
        ipdr_message = header + message

        self._send_message(ipdr_message)

    def send_flow_start_message(self):
        self.logger.debug("Sending FLOW START message to IPDR exporter...")
        msg = self._generate_ipdr_message_header(2, "FLOW_START", 0)
        self._send_message(msg)

    def send_flow_stop_message(self, code, reason):
        self.logger.debug("Sending FLOW STOP message to IPDR exporter...")
        message = pack("H", code)
        message += reason
        msg = self._generate_ipdr_message_header(2, "FLOW_STOP", len(message))
        self._send_message(msg)

    def send_data_ack_message(self, config_id, sequence):
        self.logger.debug("Sending DATA ACK message to IPDR exporter (DSN config: %s | DSN sequence: %s) ...", config_id, sequence)
        message = pack("H", config_id)
        # encode encode_64bit_number
        sequence_encoded = decoder.encode_64bit_number(sequence)
        message += sequence_encoded
        header = self._generate_ipdr_message_header(2, "DATA_ACK", len(message))
        header += message
        self._send_message(header)

    def send_final_template_data_ack_message(self):
        self.logger.debug("Sending FINAL TEMPLATE DATA ACK message to IPDR exporter...")
        msg = self._generate_ipdr_message_header(2, "FINAL_TEMPLATE_DATA_ACK", 0)
        self._send_message(msg)

    def send_keep_alive_message(self):
        self.logger.debug("Sending KEEP ALIVE message to IPDR exporter...")
        self.logger.debug("DATA ACK flag is: %s", self.data_ack)
        if self.data_ack:
            self.send_data_ack_message(self.dsn_config_id, self.dsn_sequence)
            self.data_ack = 0

        self.data_capture_running_time = 0
        self.data_capture_data_count = 0
        self.data_capture_running = 0

        msg = self._generate_ipdr_message_header(2, "KEEP_ALIVE", 0)
        self._send_message(msg)

    def send_get_sessions_message(self):
        self.logger.debug("Sending GET SESSIONS message to IPDR exporter...")
        message = pack("H", 4096)
        header = self._generate_ipdr_message_header(2, "GET_SESSIONS",
                                                    len(message))
        header += message
        self._send_message(header)

    def send_disconnect_message(self, code, reason):
        self.logger.debug("Sending DISCONNECT message to IPDR exporter...")
        message = pack("H", code)
        message += reason
        header = self._generate_ipdr_message_header(2, "DISCONNECT",
                                                    len(message))
        header += message
        self._send_message(header)

    def _send_message(self, message):
        if self.connected:
            self.collector_socket.sendall(message)

    def _generate_ipdr_message_header(self, version, message, msg_length):
        message_id = IPDR_MESSAGE_TYPES[message]
        header = pack("!BBBBL", version, message_id, self.session_id, 0, msg_length + 8)

        return header

    def _receive_data(self):
        data = ""
        try:
            data = self.collector_socket.recv(2048)
        except socket.timeout:
            print ("TIMEOUT")
        except socket.error as err:
            print (err)
        self.last_received_data_raw = data

        self.data_processing = True

    def create_initiator_id(self):
        if self.local_ip:
            return IPAddress(self.local_ip).value
        return ""

    def get_exporter_message_type(self):
        msg_code = self.last_ipdr_exporter_msg[1]
        for msg_type_str, code in IPDR_MESSAGE_TYPES.items():
            if msg_code == code:
                return msg_type_str
        return None

    def decode_exporter_msg(self):
        message = self.last_received_data_raw
        if message:
            self.last_ipdr_exporter_msg = unpack_from("!BBBBL", message, offset=0)
            return True
        return False

    def decode_received_message(self):
        if not self.decode_exporter_msg():
            return ""

        self.data_processing = False

        response_length = len(self.last_received_data_raw)

        msg_type = self.get_exporter_message_type()
        msg_length = self.last_ipdr_exporter_msg[4]

        msg = self.last_received_data_raw[8:]

        self.received_data = self.last_received_data_raw[msg_length:]
        if len(self.last_received_data_raw) > msg_length:
            self.logger.debug("Setting data processing as active...")
            self.data_processing = True

        if msg_type == "CONNECT_RESPONSE":
            capabilities, keep_alive = unpack("!HL", msg[:6])
            vendor = msg[6:]
            self.decoded_data['capabilities'] = capabilities
            self.decoded_data['keep_alive'] = keep_alive
            self.decoded_data['vendor'] = vendor

        elif msg_type == "GET_SESSIONS_RESPONSE":
            request, = unpack_from("H", msg, offset=0)
            self._extract_session_data(msg[2:])
            self._update_session_parameters()

            self.decoded_data['sessions_request_id'] = request

        elif msg_type == "TEMPLATE_DATA":
            tmpl_config, tmpl_flags, tmpl_predata = unpack_from("!HBL", msg, offset=0)

            self.decoded_data['template_config'] = tmpl_config
            self.decoded_data['template_flags'] = tmpl_flags
            self.decoded_data['template_predata'] = tmpl_predata

            self._extract_template_data(msg[7:])

        elif msg_type == "SESSION_START":
            uptime, = unpack("!L", msg[:4])
            msg = msg[4:]
            records, msg = decoder.decode_64bit_number(msg)
            # msg = msg[8:]
            gap_records, msg = decoder.decode_64bit_number(msg)
            # msg = msg[8:]
            primary, ack_time, ack_sequence, doc_id = unpack("!BLLH", msg[:11])

            self.decoded_data['uptime'] = uptime
            self.decoded_data['records'] = records
            self.decoded_data['gap_records'] = gap_records
            self.decoded_data['primary'] = primary
            self.decoded_data['ack_time'] = ack_time
            self.decoded_data['ack_sequence'] = ack_sequence
            self.decoded_data['doc_id'] = doc_id

            margin_time = ack_time * 0.05
            if margin_time > 15:
                margin_time = 15
            ack_time = ack_time - margin_time
            if not self.ack_time or ack_time < self.ack_time:
                self.ack_time = ack_time
            if not self.ack_sequence or ack_sequence < self.ack_sequence:
                self.ack_sequence = ack_sequence

        elif msg_type == "DATA":

            if not self.data_capture_running:
                self.data_capture_running_time = time.time()
                self.data_capture_running = False
            if not self.data_capture_keep_alive:
                self.data_capture_keep_alive = time.time()

            self.data_capture_running += 1
            self.data_capture_data_count += 1


            tmpl_id, config_id, flags = unpack("HHB", msg[:5])
            msg = msg[5:]
            sequence_num, message = decoder.decode_64bit_number(msg)
            # message = msg[8:]

            self.decoded_data['data_template_id'] = tmpl_id
            self.decoded_data['data_config_id'] = config_id
            self.decoded_data['data_flags'] = flags
            self.decoded_data['data_sequence'] = sequence_num
            self.decoded_data['data_data'] = message

            self.dsn_sequence = self.decoded_data['data_sequence']
            self.dsn_config_id = self.decoded_data['data_config_id']

        elif msg_type == "SESSION_STOP":
            reason_code, = unpack("H", msg[:2])
            msg = msg[2:]
            reason, msg = decoder.decode_utf8_string(msg)
            self.decoded_data['reason_code'] = reason_code
            self.decoded_data['reason'] = reason

        elif msg_type == "ERROR":
            self.logger.error("IPDR exporter sent an ERROR message")
            ts, error_code = unpack("!LH", msg[:6])
            msg = msg[6:]
            reason, msg = decoder.decode_utf8_string(msg)
            self.decoded_data['ts'] = ts
            self.decoded_data['error_code'] = error_code
            self.decoded_data['reason'] = reason

            self.logger.error("Timestamp: %s, code: %s, reason: %s", ts, error_code, reason)
            self.disconnect()

        # self.logger.debug("Decoded data: %s", self.decoded_data)
        self.logger.debug("\n<======>\n%s\n<======>", self.decoded_data)
        return msg_type

    def _extract_session_data(self, data):
        self.logger.debug("Extracting session data...")
        session_count, = unpack("!L", data[:4])
        data = data[4:]
        for session_decode in range(0, session_count):
            sess_id, reserved = unpack("BB", data[:2])
            data = data[2:]
            sess_name, data = decoder.decode_utf8_string(data)
            sess_descr, data = decoder.decode_utf8_string(data)

            ack_time, ack_sequence = unpack("!LL", data)
            self.ack_sequence = ack_sequence
            current_session = {
                'session_id' : sess_id,
                'session_name' : sess_name,
                'session_description' : sess_descr,
                'ack_time' : ack_time,
                'ack_sequence' : ack_sequence
            }
            self.session_info.setdefault(session_decode, current_session)

    def _update_session_parameters(self):
        session = self.session_info.values()[0]
        self.ack_sequence = session['ack_sequence']
        margin_time = session['ack_time'] * 0.05
        if margin_time > 15:
            margin_time = 15
        if not self.ack_time:
            self.ack_time = session['ack_time'] - margin_time
        if not self.session_id:
            self.session_id = session['session_id']

    def decode_data(self):
        """Decode data"""
        self.logger.debug("Decoding data...")
        exported_data = {}
        template_id = self.decoded_data['data_template_id']
        data = self.decoded_data['data_data']

        # self.dsn_sequence = self.decoded_data['data_sequence']
        # self.dsn_config_id = self.decoded_data['data_config_id']

        if not self.data_ack:
            self.data_ack = 1
            self.send_keep_alive_message()

        int_or_dir = unpack("!L", data[:4])
        data = data[4:]

        for field in self.templates[template_id]['fields']:
            field_type_hex = field['type_id']
            field_type_string = get_template_field_string_type_by_id(field_type_hex)
            field_name = field['name']
            # decode data
            try:
                decoder = self._decoders[field_type_string]
                # self.logger.debug("Getting value for %s...", field_name)
                decoded_value, data = decoder(data)
                exported_data[field_name] = decoded_value
            except KeyError as ex:
                print("No decoder for the given type defined: %s" % str(ex))
            except Exception as ex:
                print(ex)

        for key, value in exported_data.items():
            self.logger.debug("%s: %s", key, value)

    def _extract_template_data(self, msg):
        #import pdb; pdb.set_trace()
        while(len(msg) > 10):
            tmpl_id, = unpack("H", msg[:2])
            msg = msg[2:]

            record_type, msg = decoder.decode_utf8_string(msg)
            record_config, msg = decoder.decode_utf8_string(msg)

            # unpack fields
            fields_count, = unpack("!L", msg[:4])

            self.templates[tmpl_id] = {
                    'fields_count' : fields_count,
                    'fields' : [],
                    'schema_name' : record_type,
                    'type_name' : record_config
            }

            msg = msg[4:]
            counter = 0
            fields = []
            while counter < fields_count:
                type_id, field_id = unpack("!LL", msg[:8])
                msg = msg[8:]
                field_name, msg = decoder.decode_utf8_string(msg)
                field_enabled, = unpack("B", msg[:1])
                msg = msg[1:]
                field = {
                        'name' : field_name,
                        'type_id' : type_id,
                        'field_id' : field_id,
                        'enabled' : field_enabled
                        }
                fields.append(field)
                counter += 1

        self.templates[tmpl_id]['fields'] = fields
        for field in self.templates[tmpl_id]['fields']:
            self.logger.debug("Template data field: %s (id %s)", field['name'], field['type_id'])
