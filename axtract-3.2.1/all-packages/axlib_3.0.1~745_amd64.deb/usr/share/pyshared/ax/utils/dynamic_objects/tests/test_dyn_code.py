import unittest
from ax.utils.dynamic_objects.dyn_code import run_exec_command, load_ext_uri, \
        CodeLoadingException, CodeExecutionException, set_global_code_cache_size, \
        MaxCodeObjectsExceededException
from tempfile import NamedTemporaryFile
from time import time
import os

GLOB_COUNTER = 0

class TestDynCode(unittest.TestCase):

    def setUp(self):
        global GLOB_COUNTER
        GLOB_COUNTER = 0
        set_global_code_cache_size(10)
        self.code = b"""
# environ checks (imports):
import os
import ax.utils.dynamic_objects.dyn_code
for i in range(100):
    me.incr_counter()
"""



    def incr_counter(self):
        global GLOB_COUNTER
        GLOB_COUNTER += 1


    def test_run_exec_command(self):
        cmd = """me.incr_counter()"""
        env = {'me': self}
        for i in range(100):
            run_exec_command(cmd, env)
        assert GLOB_COUNTER == 100


    def test_cache(self):
        f = NamedTemporaryFile(delete=False)
        env = {'me': self}
        f.write(self.code)
        f.close()

        set_global_code_cache_size(1)
        load_ext_uri('file:////%s' % f.name, env)
        self.assertRaises(MaxCodeObjectsExceededException,\
                load_ext_uri, 'file:///%s' % f.name, env)

        set_global_code_cache_size(10)
        os.unlink(f.name)


    def test_load_ext_uri(self):
        env = {'me': self}
        f = NamedTemporaryFile(delete=False)
        f.write(self.code)
        f.close()

        t1 = time()
        load_ext_uri('file://%s' % f.name, env)
        t1 = time() - t1

        t2 = time()
        load_ext_uri('file://%s' % f.name, env)
        t2 = time() - t2

        assert t1 > t2

        t3 = time()
        load_ext_uri('file://%s' % f.name, env, force_reload = 1)
        t3 = time() - t3
        assert t3 > t2

        t4 = time()
        load_ext_uri('file://%s' % f.name, env, cache_code = 0)
        t4 = time() - t4
        assert t4 > t2

        os.unlink(f.name)

        # cache works (file is gone):
        load_ext_uri('file://%s' % f.name, env)

        self.assertRaises(CodeLoadingException, load_ext_uri, 'file://%s' % \
                f.name, env, force_reload = 1)


        assert GLOB_COUNTER == 500

    def test_exec_error(self):
        env = {'me': self}
        f = NamedTemporaryFile(delete=False)
        f.write(self.code + b'\ni = 9/0')
        f.close()
        self.assertRaises(CodeExecutionException, load_ext_uri, 'file://%s' % \
                f.name, env, force_reload = 1)

        os.unlink(f.name)


if __name__ == "__main__":
    unittest.main()

