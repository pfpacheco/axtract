import time
import socket
import os
from ax.utils.six.moves import _thread as thread
import pymongo
import pymongo.errors
import datetime
import inspect

from ax.utils.mongo_utils import build_call_op_with_reconnect

utcnow = datetime.datetime.utcnow
_hostname = socket.gethostname()
call_op_with_reconnect = build_call_op_with_reconnect(45, 1)


class LockManager(object):
    def __init__(
            self,
            host,
            port,
            db_name,
            coll_name,
            default_lifetime=None):

        self.coll_name = coll_name

        self.db = pymongo.MongoClient(host, port)[db_name]
        self.default_lifetime = default_lifetime
        self._lock_factory = MongoLockWithStatus

    def __call__(self, lock_name, lifetime=None, info=''):
        """
            Returns a Object wich can take part in a with-'statement'

            lock_name : "Resource name we want to lock"
            lifetime : MAXIMUM duration in seconds how long the lock is allowed
                       to be active. Is the lifetime reached other parties can
                       aquiere the lock
            info : Abitrary object which will be stored in the database.
                   It has NO influence on the locking-behaviour. Its only for
                   information purpose when someone needs to understand whats
                   wrong with the LOCKS

        """
        lifetime = lifetime or self.default_lifetime
        return self._lock_factory(
            self.db[self.coll_name],
            lock_name,
            lifetime,
            info)

    @staticmethod
    def from_connection(mongo_conn, db_name, coll_name, default_lifetime=None):
        inst = LockManager.__new__(LockManager)
        inst.coll_name = coll_name

        # This writes are critical, so a loss hurts very hard
        # => Ensure this on a db-object-level
        # Wait for the in-memory representation beeing updated
        wc = pymongo.WriteConcern(w=1)
        inst.db = mongo_conn.get_database(db_name, write_concern=wc)

        inst.default_lifetime = default_lifetime
        inst._lock_factory = MongoLockWithStatus
        return inst

    def enable_lock_status(self):
        self._lock_factory = MongoLockWithStatus

    def disable_lock_status(self):
        self._lock_factory = MongoLock

    # ONLY use this from management software from the outside
    # So you can get rid of old locks after a 'kill -9'
    def erase_lock(self, lock_name):
        coll = self.db[self.coll_name]
        coll.delete_one({"_id": lock_name})
        coll.delete_many({"status_of_lock": lock_name})


class MongoLock(object):
    def __init__(self, coll, lock_name, lifetime, info=''):
        if lifetime is not None:
            self.lifetime = datetime.timedelta(seconds=lifetime)
        else:
            self.lifetime = None

        self.coll = coll
        self.lock_name = lock_name

    def __enter__(self):
        if not self._try_get_lock():
            self._wait_for_lock()

    def __exit__(self, exc_type, exc_value, traceback):
        self._release_lock()

    def _try_get_lock(self):
        insert = {'_id': self.lock_name}

        if self.lifetime:
            insert['lifetime'] = utcnow() + self.lifetime

        try:
            call_op_with_reconnect(self.coll.insert_one, insert)
        except pymongo.errors.DuplicateKeyError:
            return False
        return True

    def _wait_for_lock(self):
        got_it = False
        while not got_it:
            self._remove_old_locks()
            time.sleep(0.3)
            got_it = self._try_get_lock()

    def _remove_old_locks(self):
        now = datetime.datetime.utcnow()

        call_op_with_reconnect(
            self.coll.delete_many,
            {'_id': self.lock_name, 'lifetime': {"$lt": now}})

    def _release_lock(self):
        call_op_with_reconnect(
            self.coll.delete_one,
            {'_id': self.lock_name})


class MongoLockWithStatus(MongoLock):
    def __init__(self, coll, lock_name, lifetime, info=''):
        super(MongoLockWithStatus, self).__init__(
            coll,
            lock_name,
            lifetime,
            info)

        # This lock info will be stored in a seperate document. This seperate
        # document contains the following information about the lock
        # * List of waiters
        # * Who is currently helding the lock
        # * Who was helding it the last time
        # this second document has NO influence of the locking itself its only
        # for debugging purpose !
        self.lock_info = {
            'host': _hostname,
            'process': os.getpid(),
            'thread_id': thread.get_ident(),
            'caller_info': info,
            'caller_frame': self._build_caller_info(inspect.currentframe()),
            'acquire_try_start': datetime.datetime.utcnow(),
            'acquired': None,
            'released': None,
        }

    def _build_caller_info(self, current_frame):
        # current_frame is from __init__,
        # __init__ is called by LockManager.__call__ => go back two frames to
        # have the 'real caller' frame
        caller_frame = inspect.getouterframes(current_frame)[2]
        try:
            return {
                'module_name': caller_frame[1],
                'line': caller_frame[2],
                'method_name': caller_frame[3],
                'code_context': caller_frame[4][0].strip()
            }
        finally:
            # this delete is recommended by the python docu
            del caller_frame

    def __enter__(self):
        if not self._try_get_lock():
            self._add_me_to_waiter_list()
            self._wait_for_lock()
            self._remove_me_from_waiter_list()
        self._me_acquired_lock()

    def __exit__(self, exc_type, exc_value, traceback):
        self._release_lock()
        self._me_released_lock()

    ## here are all the functions which manipulate the 'lock-status' document
    def _add_me_to_waiter_list(self):
        call_op_with_reconnect(
            self.coll.update_one,
            {'status_of_lock': self.lock_name},
            {"$push": {"waiters": self.lock_info}},
            upsert=True)

    def _remove_me_from_waiter_list(self):
        call_op_with_reconnect(
            self.coll.update_one,
            {'status_of_lock': self.lock_name},
            {"$pull": {"waiters": self.lock_info}}
        )

    def _me_acquired_lock(self):
        self.lock_info['acquired'] = datetime.datetime.utcnow()
        call_op_with_reconnect(
            self.coll.update_one,
            {"status_of_lock": self.lock_name},
            {"$set": {'current_lock_helder': self.lock_info}},
            upsert=True)

    def _me_released_lock(self):
        self.lock_info['released'] = datetime.datetime.utcnow()
        call_op_with_reconnect(
            self.coll.update_one,
            {"status_of_lock": self.lock_name},
            {
                "$set": {'last_lock_helder': self.lock_info},
                "$unset": {'current_lock_helder': 1},
            })
