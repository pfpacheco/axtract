"""Context locals

Use them like this

from xlocal import xlocal
xcurrent = xlocal()
with xcurrent(x=1):
    output()

def output():
    print xcurrent.x
"""
from ax.utils.six.moves import _thread as thread


class xlocal(object):
    """ Implementation of an execution local object.

    get_ident could be
    thread.get_ident (default)
    greenlet.getcurrent
    """
    def __init__(self, getident=None):
        # Do it this way otherwise __getattr__ is called
        d = self.__dict__
        d['_getident'] = getident or thread.get_ident
        d['_storage'] = {}

    def _getlocals(self, autocreate=False):
        ident = self._getident()
        try:
            return self._storage[ident]
        except KeyError:
            if not autocreate:
                raise
            self._storage[ident] = loc = {}
            return loc

    def _checkremove(self):
        ident = self._getident()
        val = self._storage.get(ident)
        if val is not None:
            if not val:
                del self._storage[ident]

    def __call__(self, **kwargs):
        """ return context manager which will set execution locals
        for all code within the with-body.
        """
        return WithXLocals(self, kwargs)

    def __getattr__(self, name):
        try:
            return self._getlocals()[name]
        except KeyError:
            raise AttributeError(name)

    def __setattr__(self, name, val):
        raise AttributeError("cannot setattr, use 'with scoping'")

    def __delattr__(self, name):
        raise AttributeError("cannot delattr xlocal local attr")

class WithXLocals:
    def __init__(self, xlocal, kwargs):
        self._xlocal = xlocal
        self._kwargs = kwargs

    def __enter__(self):
        loc = self._xlocal._getlocals(autocreate=True)
        self._undostack = undostack = []
        for name, val in self._kwargs.items():
            assert name[0] != "_", "names with underscore reserved for future use"
            try:
                undostack.append(lambda n=name,v=loc[name]: loc.__setitem__(n, v))
            except KeyError:
                undostack.append(lambda n=name: loc.__delitem__(n))
            loc[name] = val
        return self

    def __exit__(self, *args):
        for action in self.__dict__.pop("_undostack"):
            action()
        self._xlocal._checkremove()
