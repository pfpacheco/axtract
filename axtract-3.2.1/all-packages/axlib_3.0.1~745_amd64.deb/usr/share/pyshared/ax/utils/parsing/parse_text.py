##############################################
#
# Text Parsing utilities
#
##############################################

import sys, time
from ast import literal_eval
import datetime

from ax.utils.ordereddict import OrderedDict

try:
    from ax.utils.formatting.pretty_print import dict_to_txt
except:
    print('no format conversion')


def parse_timestr(st, tformat):
    st = st.replace('MEZ', 'CET')
    try:
        t = time.mktime(time.strptime(st, tformat))
    except Exception as ex:
        msg = "Could not convert timestring %s: %s" % (st, ex)
        if ' %Z ' in tformat:
            msg += '. Timezone not known on this system?'
        raise Exception(msg)
    return t


def get_in(line, prefix, sep=' '):
    """ screenscraping; show version... """
    # line = 'foo: bar foo2: bar2' ->
    # get_in(line, 'foo: ') = 'bar'
    try:
        return line.split(prefix, 1)[1].lstrip().split(sep)[0].rstrip()
    except Exception:
        return 'n.a.'

def get_indent_chars(lines, indent_char=' '):
    """ deliver the chars which are used in a block to indent one level
    like in cisco configs with one space, but have seen '.' as well """
    # get to the indent number of spaces
    for line in lines:
        if not line.startswith(indent_char):
            continue
        for i in xrange(10, -1, -1):
            if line.startswith(i * indent_char):
                return i * indent_char
    return ""


def get_line(match, block, after='', start_match=None,
                   indent=None, indent_chars=None, indent_char=' '):
    lines = block.splitlines()
    if indent is not None:
        # we need to check if this is not given:
        if indent_chars == None:
            indent_chars = get_indent_chars(lines, indent_char)
    after_found = ''
    if not after:
        after_found = 1
    for line in lines:
        line_l = line.lower()
        if not after_found and after.lower() in line_l:
            after_found = 1
            continue
        if match.lower() in line_l:
            if indent is not None:
                if isinstance(indent, int):
                    str_indent = indent_chars * indent
                else:
                    str_indent = indent
                if not line.startswith(str_indent):
                    continue
            if start_match is not None:
                if not line.strip().startswith(match):
                    continue
            return line.strip()

def rem(s, what):
    if not isinstance(what, (list, tuple)):
        what = (what,)
    for w in what:
        s = s.replace(w, '')
    return s

def sort(d):
    if isinstance(d, dict):
        l = d.keys()
    elif isinstance(d, (tuple, list)):
        l = list(d)
    l.sort()
    return l

def get_line_val(total, prefix, sep=None, get=1, after='', start_match=None,
                 indent=None, indent_chars=None, indent_char=' '):
    # get infos from a line in total, precedented by prefix.
    # with sep: split that one away (typically sep is a ':')
    line = get_line(prefix, total, after, start_match, indent, indent_chars,
                    indent_char)
    if not line:
        return 'n.a.'
    splitval = prefix.lstrip(indent_char) or prefix
    splitted = line.split(splitval, 1)
    if len(splitted) == 1:
        return 'n.a.'
    splitted = splitted[1]
    if sep:
        try:
            splitted = splitted.split(sep)[get]
        except:
            return 'n.a.'
    return splitted.strip()



def convert_fmt(raw, struct_as_str = 0, force = None):
    """ convert structs to text and back - with autodetection
    of the initial format
    optional force in ('pretty', 'struct') to force a certain format.
    """
    ret = raw
    try:
        if struct_as_str:
            if ret.startswith('[') or ret.startswith('{'):
                ret = literal_eval(ret)
                if force == 'struct':
                    return ret
        if type(ret) in (str, unicode):
            if force == 'pretty':
                return ret
            return parse(ret)
        else:
            return dict_to_txt(ret, fmt={'ax': 1})
    except:
        pass
    return raw



def parse_line(line):
    """ 'foo: bar, bar: foo" into a map """
    #FIXME: need to cope with any number of space after the comma.
    return parse(line.replace(', ', ',').replace(',', '\n'))

def parse_with(raw, env='self', *args, **kw):
    """ this allows to replace constants in raw
    given in pymap syntax
    """
    if isinstance(env, basestring):
        env = [env]

    menv = {}
    for e in env:
        if e == 'self':
            e = parse(raw, *args, **kw)
        menv.update(e)
    raw = raw % menv
    return parse(raw, *args, **kw)

def parse(raw, comment_sep = '#',
          clean_empty_cols = 1,
          check_space_sep = 1,
          check_colon_sep = 1,
          leave_trivial_text = 1,
          comment_in_line_sep = '#'):
    """
    Parse text into a python map.

    This is handy for imports from Excel or Wiki
    remember that copy and paste from/to Excel or Wiki Tables
    into text fields within the AXESS GUI
    directly support tab / line separated inserts in both directions

    Special features:
    - Ignoring of columns with only one space (i.e. empty cells
      within Wiki tables)

    - [key1, key2].sub1\tval  result in a parsed structure like:
        ...{"key1.sub1": val, "key2.sub1": val ...}

    - Comments: Anything (right) after a '#' sign is ignored.

    - Values like "int:23", "float:1.2", "True", "False" will be
      casted into the respective types.

    Note: this is for parsing human readible configuration files
          and not for mass data (would be pretty slow)

    - switch comment_in_line_sep to '\n' if you want to not split off comments
      in lines

    """
    # remove comments and do "\t   \t" -> "\t\t"
    if raw.strip() == raw.split('\n')[0].strip() and \
            leave_trivial_text:
            if not ':' in raw and not ':\t' in raw:
                return raw


    # remove empty begin and end lines
    # we can't just strip() since the whole thing could be
    # globally indented, which is corrected below:
    empty_count = 0
    lines = raw.split('\n')
    for l in lines:
        if l.strip():
            # first line with content, stop:
            break
        empty_count += 1
    raw = '\n'.join(lines[empty_count:])
    raw = raw.rstrip()


    # move to the left globally indented stuff, like:
    """
    foo: bar
       baz: 1
    """
    # this happens e.g. when there is an empty first col in excel paste
    raw = "\n" + raw
    line_count = len(raw.split('\n'))
    for sep in ('\t', ' '):
        while True:
            if len(raw.split('\n%s' % sep)) != line_count:
                break
            raw = raw.replace("\n%s" % sep, "\n")
    raw = raw[1:]

    # raw is now beginning at the upper left corner.



    # find what spaced are used for a tab (if there are spaces)
    # we check whats the minimum amount of spaces until content
    # at all lines:
    if check_space_sep:
        nraw = ''
        min_spaces = 0

        for line in raw.split('\n'):
            if '\t' in line:
                continue
            lls = len(line.lstrip())
            ll = len(line)
            pre = line[:ll -lls]
            if ' ' in pre:
                spaces = len(pre)
                if spaces < min_spaces or min_spaces == 0:
                    min_spaces = spaces
        # do the tab - space replacement:
        if min_spaces > 0:
            raw = raw.replace(' ' * min_spaces, '\t')

    r = ''
    for line in raw.split('\n'):
        line = line.split(comment_in_line_sep)[0]
        if not line.strip():
            continue
        if not clean_empty_cols:
            r += line+'\n'
            continue
        for rcol in line.split('\t'):
            r += rcol.strip() + '\t'
        r += '\n'
    raw = r

    if check_colon_sep:
        # now replace key: value into key\tvalue:
        nraw = ''
        for line in raw.split('\n'):
            # key:val in line? Ignore if a colon is at the end:
            if ':' in line and not line.strip().endswith(':'):
                key = line.strip().split(':', 1)[0].strip()
                # no spaces in key:
                if not ' ' in key and not '\t' in key:
                    # replace:
                    pre, post = line.split(key, 1)
                    kval = post.split(':', 1)[1].strip()
                    nraw += pre + key +':' + '\t' + \
                        kval + '\n'
                    continue
            nraw += line + '\n'
        raw = nraw

    # now we are going to number the subblock tags, so that we can split
    # later:
    """
    count = 0
    nraw = ''
    for line in raw.split('\n'):
        if line.startswith('-\t'):
            nraw += '-%s' % count + '\n'
            count += 1
        else:
            nraw += line + '\n'
    raw = nraw
    """


    # now we have clean tab separated txt:
    return parse_cleaned_tab_sep_txt(raw)


def parse_tab_sep(raw):
    return parse(raw, check_space_sep = 0, check_colon_sep = 0)


def parse_cleaned_tab_sep_txt(raw, col = 0):
    """
    Parses structured text into a big map

    Here we parse only line and tab separated text
    """
    def leval(s):
        if '|' in s:
            # 123|float  format:
            val, typ = s.rsplit('|', 1)
            if typ == "float":
                return float(val)
            elif typ == "int":
                return int(val)
            elif typ == "str":
                return str(val)
            elif typ == "datetime":
                # object back here:
                return datetime.datetime.fromtimestamp(float(val))


        if s.endswith(':'):
            s = s[:-1]
        if s.startswith('0'):
            # literal_eval('0xA') is 10, from '08' we get an error (octal)
            return s
        try:
            return literal_eval(s)
        except:
            return s


    # col is the current column, we work from left to right
    # recursively:
    # which blocks in this col:
    blocks = []
    for line in raw.split('\n'):
        key = line.split('\t')
        if len(key) > col:
            if key[col].strip():
                blocks.append(key[col].strip())
    # go through the blocks:
    # is this a list?
    list_blocks = raw.split(('\n' + '\t' * col + '-'))
    if len(list_blocks) > 1:
        # this is a list, return it:
        ret = []
        if list_blocks[-1].strip() == '':
            list_blocks = list_blocks[:-1]
        for lb in list_blocks:
            lval = parse_cleaned_tab_sep_txt(lb, col)
            ret.append(lval)
        if len(list_blocks) == 1 and type(ret[0]) == list:
            ret = ret[0]
        return ret

    ret = OrderedDict()
    i = -1
    force_map = 0
    while i < len(blocks)-1:
        i += 1
        block = blocks[i]
        block_raw = ('\n' + raw).split(('\n' + '\t'*col + block + '\t'),1)[1]
        val = block_raw.split('\n')[0].strip()
        if val:
            #print 'val is %s %s' % (val, type(val))
            val = leval(val)
            #print 'val is %s %s' % (val, type(val))

            # this is like Version: 1.1
            # check for multvals ([foo,bar].baz = 2):
            if block.startswith('['):
                keys, sub = block.split(']',1)
                for k in keys[1:].split(','):
                    ret[k+sub] = val
            else:
                ret[leval(block)] = val
            continue
        if i < len(blocks)-1:
            # split until the next block...
            block_raw = ('\n' + block_raw).split(('\n'+ '\t'*col + \
                    blocks[i+1]),1)[0]
        # ... and treat it recursively the same:
        subval = parse_cleaned_tab_sep_txt(block_raw, col + 1)
        if block.endswith(':'):
            force_map = 1
        ret[leval(block)] = subval
    if force_map:
        return ret
    for v in ret.values():
        # if there is any non trivial mapping the whole thing is a map:
        if v:
            return ret

    if not blocks:
        # empty str on no vals:
        return ''
    # this is a list:
    ret = []
    for b in blocks:
        ret.append(leval(b))
    return ret

if __name__ == '__main__':
    m = """
foo: bar
barasdfa: foo
"""
    print(parse(m))
    m = "foo: bar,bar: f oo"
    p = parse_line(m)
    print(get_line_val('adsf', ' ', sep='mb/s', get=0))
    assert p == {'foo': 'bar', 'bar': 'f oo'}
    # for further tests check the unittests folder!
    print(parse_timestr('05:10:03 MEZ Wed May 8 2002', '%H:%M:%S %Z %a %b %d %Y'))
