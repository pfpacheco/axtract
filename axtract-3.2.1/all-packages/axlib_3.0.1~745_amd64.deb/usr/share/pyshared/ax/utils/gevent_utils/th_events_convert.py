import ctypes
import errno
import gevent
import os

EFD_SEMAPHORE = 1
EFD_CLOEXEC = 0o2000000
EFD_NONBLOCK = 0o4000

libc = ctypes.cdll.LoadLibrary('libc.so.6')


class ThreadedEventsConverter(object):
    """This one receives events from threads and converts them to events
    runnable in a gevent loop
    """

    def __init__(self):
        self.fd = self._create()
        self._pending = []
        self._runner = None

    def _create(self):
        return libc.eventfd(0, EFD_NONBLOCK)

    def start(self):
        if self._runner is None:
            self._runner = gevent.spawn(self._converter)

    def _converter(self):
        loop = gevent.get_hub().loop

        while True:
            self._wait_for_notification()
            while self._pending:
                func, args, kwargs = self._pending.pop()
                loop.run_callback(lambda: func(*args, **kwargs))

    def _wait_for_notification(self):
        while True:
            try:
                os.read(self.fd, 8)
                # struct.unpack("Q", num)[0]
            except OSError as error:
                if error.errno == errno.EAGAIN:
                    gevent.socket.wait_read(self.fd)
                else:
                    raise
            else:
                break

    def _notify(self):
        os.write(self.fd, ctypes.c_ulonglong(1))

    def active_event(self, func, *args, **kwargs):
        self._pending.append((func, args, kwargs))
        self._notify()
