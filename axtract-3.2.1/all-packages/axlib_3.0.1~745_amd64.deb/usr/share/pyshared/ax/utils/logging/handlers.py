import codecs
import json
import logging
import logging.handlers
import os
import socket
import sys
import time
from stat import ST_DEV, ST_INO, ST_SIZE
from ax.utils.locking.file_lock import FileLock

def _process_in_foreground():
    try:
        if os.getpgrp() == os.tcgetpgrp(sys.stdout.fileno()):
            return True
    except:
        pass

    return False

class WatchedFile(object):
    """A 'file' like object.

    * It detects when the inode has changed and reopens the file.
    * __init__ is different from the original 'file'.
    * Not all methods are implemented, just the ones needed for logging.
    * This code heavily relies on the logging framework acquiring a lock.
      => Only one thread at a time uses  an instance of this object.
    """
    def __init__(self, filename, mode='a', encoding=None):
        self.name = filename
        self.mode = mode
        self.encoding = encoding
        self.fd = self._gen_fd(filename, mode, encoding)
        self.dev, self.ino = self._stat_from_fd(self.fd)

    def _gen_fd(self, filename, mode, encoding):
        if encoding is None:
            return open(filename, mode)
        else:
            return codecs.open(filename, mode, encoding)

    def _stat_from_fd(self, fd):
        stat = os.fstat(fd.fileno())
        return stat.st_dev, stat.st_ino

    def _ensure_fd(self):
        if self.fd is None:
            raise ValueError("I/O operation on closed file")

        try:
            stat = os.stat(self.fd.name)
        except OSError:
            changed = True
        else:
            changed = (stat.st_dev != self.dev) or (stat.st_ino != self.ino)

        if not changed:
            return

        self.fd.flush()
        # Do _not_ perform a self.stream.close(). This would leave us
        # (for a short time) with self.stream!=None, but self.stream
        # being closed. If SIGTERM/SIGINT hits us at that point, the
        # atexit handler will call self.close(), which will attempt to
        # work with a closed file descriptor, which produces this
        # exception:
        #   ValueError: I/O operation on closed file
        old_fd = self.fd
        try:
            self.fd = self._gen_fd(self.name, self.mode, self.encoding)
        except IOError as error:
            # I know for a 'generic file' this is a NO GO.
            # However this entire class is only be ment to be used inside
            # logging.
            old_fd.write("Error opening log file: %s\n" % error)

            # This can happen when
            #   - We hit a race condition in logrotate, see AXOS-273
            #   - We do not have write permission for the directory.
            # Keep the old self.fd as it is, we have nothing better.
            # Keep current self.dev / self.ino. Next time this method is
            # called we must again try opening the new file.
            return

        try:
            old_fd.close()
        except Exception:
            # The above once produced this exception:
            #       IOError: close() called during concurrent operation
            #       on the same file object.
            # The reason is unknown, see AXOS-372 for details. It is
            # better to leak a file descriptor than to crash the
            # program, so we ignore the exception.
            pass

        # self.fd itself might have been rotated by now, even though
        # it was opened on the lines above. Use fstat() instead of stat()
        # to avoid inconsistent data in that case: With stat() we might
        # keep logging to the old file, but use stat() data of the new
        # file. By using fstat(), next time write() is called, we will
        # realize that the file was rotated.
        self.dev, self.ino = self._stat_from_fd(self.fd)

    # Here are the API methods needed for logging.
    @property
    def closed(self):
        return self.fd is None

    def close(self):
        if not self.closed:
            self.fd.close()
            self.fd = None

    def write(self, data):
        self._ensure_fd()
        self.fd.write(data)

    def flush(self):
        self._ensure_fd()
        self.fd.flush()


class WatchedFileConsole(WatchedFile):
    """A WatchedFile with a possibility of logging to stdout
    If the process has the tty:
        * It sends logs to stdout
        * tries json highlight if possible - edit: Nope. Must be done
          by formatters!
    else:
        * Just streams the log plain to stdout, e.g. into a "| jq ." pipe
        * Behaves like a WatchedFile

    Note: Logs sent to the tty will not be written to the file if clone=False

    """

    try:
        have_stdout = sys.stdout.isatty()
    except Exception:
        have_stdout = False

    def __init__(self, filename, mode='a', encoding=None, clone=True):
        super(WatchedFileConsole, self).__init__(filename, mode, encoding)

        # Write to file even if process is running in foreground?
        self.clone = clone

    def write(self, data, out=sys.stdout.write):
        if not data:
            return

        out(data)

        if not self.have_stdout or self.clone:
            super(WatchedFileConsole, self).write(data)

    def flush(self):
        if self.have_stdout:
            sys.stdout.flush()

        if not self.have_stdout or self.clone:
            super(WatchedFileConsole, self).flush()


class WatchedFileHandler(logging.FileHandler):
    """A drop-in replacement for logging.handlers.WatchedFileHandler"""

    def _open(self):
        """Return a file object which watches for lograte.

        In contrast to logging.handlers.WatchedFileHandler, this method
            - Performs only a single stat() syscall instead of two during
                ordinary logging.
            - Avoids the race condition between the two syscalls (file may
                have been moved by logrotate, which leads to exceptions).
            - Avoids a second race condition when SIGINT/SIGTERM hits the
                process while we re-open self.stream.
            - Avoids a third (very unlikely) race condition, when we just
                realized the file was rotated and exactly at that time, the
                file is rotated again.
        """
        return WatchedFile(self.baseFilename, self.mode, self.encoding)


class WatchedMultiFileHandler(logging.StreamHandler):
    def __init__(self, folder, mode='a', encoding=None):
        if not os.path.isdir(folder):
            raise Exception("%s is not a folder" % folder)

        self.folder = folder
        self.mode = mode
        self.encoding = encoding

        logging.Handler.__init__(self)
        self.stream = None
        self._streams = {}

    def flush(self):
        self.acquire()
        try:
            for fd in self._streams.values():
                fd.flush()
        finally:
            self.release()

    def emit(self, record):
        # The self.lock is already acquired.
        fn = os.path.join(self.folder, record.name.replace('.', '_') + '.log')
        if fn not in self._streams:
            self._streams[fn] = WatchedFile(fn, self.mode, self.encoding)

        # Stream handler accesses this member.
        self.stream = self._streams[fn]
        try:
            logging.StreamHandler.emit(self, record)
        finally:
            self.stream = None

    def close(self):
        self.acquire()
        try:
            for fd in self._streams.values():
                fd.close()
            logging.StreamHandler.close(self)
        finally:
            self.release()


class WatchedRotatingFileHandler(logging.handlers.RotatingFileHandler):
    """A combination of WatchedFileHandler and RotatingFileHandler.
        The code is based on copy&paste from the WatchedFileHandler, modified
        to extend the logging.handlers.RotatingFileHandler.

        Keep in mind that this is an old style class, so super() does
        not work.
    """
    def __init__(self, filename, mode="a", maxBytes=100*1000*1000,
            backupCount=3, encoding=None, delay=0):
        """Initializer, limiting disk usage to 400MB by default
            100MB max per file, 3 backup files, 1 active log file = 400MB
        """
        logging.handlers.RotatingFileHandler.__init__(self,
                filename, mode=mode, maxBytes=maxBytes, backupCount=backupCount,
                encoding=encoding, delay=delay)

        # Need to have this for watching log file rotations. Careful: Others
        # might be rotating right now.
        try:
            stat = os.stat(self.baseFilename)
        except OSError:
            self.dev, self.ino = -1, -1
        else:
            self.dev, self.ino = stat[ST_DEV], stat[ST_INO]

    def emit(self, record):
        """Write record to log file.

        If log file was rotated since last call, the old file is closed and
        the new one is opened before writing.
        """
        try:
            stat = os.stat(self.baseFilename)
        except OSError:
            changed = 1
        else:
            changed = (stat[ST_DEV] != self.dev) or (stat[ST_INO] != self.ino)

        if changed:
            # It is OK for this to run while another process performs
            # doRollover(): The worst we can do here is create a new log file
            # if none exists.
            if self.stream is None:
                self.stream = self._open()
            else:
                self.stream.flush()
                # Do _not_ perform a self.stream.close(). This would leave us
                # (for a short time) with self.stream!=None, but self.stream
                # being closed. If SIGTERM/SIGINT hits us at that point, the
                # atexit handler will call self.close(), which will attempt to
                # work with a closed file descriptor, which produces this
                # exception:
                #   ValueError: I/O operation on closed file
                old_stream = self.stream
                try:
                    self.stream = self._open()
                except IOError:
                    # This can happen when
                    #   - We hit a race condition in logrotate, see AXOS-273
                    #   - We do not have write permission for the directory.
                    error_report = logging.LogRecord(record.name,
                            record.levelno, record.pathname, 0,
                            "Error opening log file '%s':",
                            (self.baseFilename,), sys.exc_info())
                    logging.FileHandler.emit(self, error_report)

                    # self.stream is still the old one, we have nothing better.
                    logging.FileHandler.emit(self, record)
                    # Keep current self.dev / self.ino. Next time this method is
                    # called we must again try opening the new file.
                    return

                try:
                    old_stream.close()
                except Exception:
                    # The above once produced this exception:
                    #       IOError: close() called during concurrent operation
                    #       on the same file object.
                    # The reason is unknown, see AXOS-372 for details. It is
                    # better to leak a file descriptor than to crash the
                    # program, so we ignore the exception.
                    pass

            # self.stream itself might have been rotated by now, even though
            # it was opened on the lines above. Use fstat() instead of stat()
            # to avoid inconsistent data in that case: With stat() we might
            # keep logging to the old file, but use stat() data of the new
            # file. By using fstat(), next time emit() is called, we will
            # realize that the file was rotated.
            stat = os.fstat(self.stream.fileno())

            self.dev, self.ino = stat[ST_DEV], stat[ST_INO]

        # Now call our parent, which will check if the logfile needs
        # rotating and which will also do the actual writing.
        logging.handlers.RotatingFileHandler.emit(self, record)

    def shouldRollover(self, record):
        """Return 1 if log file needs rotation, else 0

        In contrast to Python's version, we directly look at self.baseFilename
        instead of self.stream: If another process has rotated the file
        already, we will notice it.
        This method also allows the log file to become slightly larger than
        the configured maxBytes (in multi process setups, staying below
        maxBytes cannot be guaranteed, anyway). It also does not open
        self.stream if it was not open before.
        """
        try:
            stat_info = os.stat(self.baseFilename)
        except OSError:
            # File does not exist -> no rotation needed
            return 0

        if stat_info[ST_SIZE] >= self.maxBytes:
            return 1
        else:
            return 0

    def doRollover(self):
        """Perform logroation

        In contrast to Python's version, this method is safe for
        multi-processing, i.e. multiple processes accessing the same log file.
        With multiple processes, the lock we are holding does not eliminate
        concurrency.
        Thus the processes need to agree on who should rotate the log files.
        Otherwise, multiple rotations may occur in parallel, which would
        delete more log files than should be deleted and/or cause exceptions
        because files do not exist any more.
        To figure out which process performs the log rotation, the following
        is done:
            - All processes attempt to create self.baseFilename + ".lock".
                This is an atomic action, only one process can successfully
                perform it. Only this process continues.
            - The continuing process checks again if the log file needs
                rotation: It could be that another process has successfully
                rotated the file before we even attempted to create the
                lock file.
            - The logfiles are rotated according to our settings.
            - self.baseFilename + ".lock" is removed
        """
        ipc_lock = FileLock(self.baseFilename + ".lock")
        if ipc_lock.lock(maxwait=0) == -1:
            # Somebody else already rotating, nothing to do for us. Since we
            # are a "Watched...Handler", we will notice and handle this later.
            return

        try:
            if not self.shouldRollover(None):
                # Somebody completed the Rollover before us.
                return
            # We have the lock and still need the Rollover. Call parent
            # class to perform the actual work.
            logging.handlers.RotatingFileHandler.doRollover(self)
        finally:
            ipc_lock.unlock()

class AxploreHandler(logging.handlers.SysLogHandler):
    """A SysLogHandler that sends messages in Axplore format

    This allows to send syslog messages to Axplore from any program that uses
    Python's logging framework: Just add this handler to the loggers you are
    interested in.
    """
    def __init__(self, *args, **kwargs):
        """Original API with added my_name parameter"""
        # This will be reported in the "from" field when sending to Axplore.
        self.my_name = str(kwargs.pop("my_name", "localhost"))
        # Convert name->code mapping to a code->name mapping:
        self.facility_codes = dict(zip(
                self.facility_names.values(), self.facility_names.keys()))
        self.message_count = 0

        logging.handlers.SysLogHandler.__init__(self, *args, **kwargs)

    def emit(self, record):
        msg = self.format(record)
        prio_mapped = self.mapPriority(record.levelname)

        # Axplore formatting:
        self.message_count += 1
        msg = b"JSON:" + json.dumps({
            'from': self.my_name,
            'msg_id': self.message_count,
            'ts': str(time.time()),
            'priority': prio_mapped,
            'priority_code': self.priority_names[prio_mapped],
            'facility': self.facility_codes[self.facility],
            'facility_code': self.facility,
            'message': msg,
            'message_type': "syslog"
            }, ensure_ascii=False).encode('utf8')

        # Copy & paste from SysLogHandler.
        try:
            if self.unixsocket:
                try:
                    self.socket.send(msg)
                except socket.error:
                    self._connect_unixsocket(self.address)
                    self.socket.send(msg)
            elif self.socktype == socket.SOCK_DGRAM:
                self.socket.sendto(msg, self.address)
            else:
                self.socket.sendall(msg)
        except (KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            self.handleError(record)

class WatchedFileConsoleHandler(logging.FileHandler):
    """A drop-in replacement for logging.handlers.WatchedFileConsoleHandler"""

    def __init__(self, *args, **kwargs):
        self.clone = kwargs.pop('clone', True)
        super(WatchedFileConsoleHandler, self).__init__(*args, **kwargs)

    def _open(self):
        """Return a file object which watches for lograte.

        In contrast to logging.handlers.WatchedFileHandler, this method
            - Performs only a single stat() syscall instead of two during
                ordinary logging.
            - Avoids the race condition between the two syscalls (file may
                have been moved by logrotate, which leads to exceptions).
            - Avoids a second race condition when SIGINT/SIGTERM hits the
                process while we re-open self.stream.
            - Avoids a third (very unlikely) race condition, when we just
                realized the file was rotated and exactly at that time, the
                file is rotated again.
        """
        return WatchedFileConsole(self.baseFilename, self.mode, self.encoding, self.clone)

