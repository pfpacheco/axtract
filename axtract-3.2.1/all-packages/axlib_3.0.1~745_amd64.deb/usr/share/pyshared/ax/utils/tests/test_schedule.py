#!/usr/bin/python -tt

import unittest2
import datetime
from ax.utils.schedule import RepeatSpec, RepeatSchedule
from ax.utils.cron_time import CronTime


class SpecScheduleTester(unittest2.TestCase):
    """Unit tests for RepeatSpec and RepeatSchedule"""
    def test_simple(self):
        spec = RepeatSpec(days_of_month=[24], months=[12])
        sched = RepeatSchedule(repeat_specs=[spec])

        # Christmas 2014, 6:01:02pm.
        christmas = datetime.datetime(2014, 12, 24, 18, 1, 2)

        self.assertTrue(spec.matches(at_date=christmas))
        self.assertTrue(sched.matches(at_date=christmas))

        # New year's day, midnight
        newyear = datetime.datetime(2014, 1, 1)
        self.assertFalse(spec.matches(at_date=newyear))
        self.assertFalse(sched.matches(at_date=newyear))

    def test_start_stop(self):
        # Christmas 2014, 6:01:02pm.
        christmas = datetime.datetime(2014, 12, 24, 18, 1, 2)

        # start year == 2005 -> must match
        spec = RepeatSpec(days_of_month=[24], months=[12],
                start=datetime.datetime(2005, 1, 1))
        sched = RepeatSchedule(repeat_specs=[spec])
        self.assertTrue(spec.matches(at_date=christmas))
        self.assertTrue(sched.matches(at_date=christmas))

        # start year == 2050 -> must not match
        spec = RepeatSpec(days_of_month=[24], months=[12],
                start=datetime.datetime(2050, 1, 1))
        sched = RepeatSchedule(repeat_specs=[spec])
        self.assertFalse(spec.matches(at_date=christmas))
        self.assertFalse(sched.matches(at_date=christmas))

        # stop year == 2005 -> must not match
        spec = RepeatSpec(days_of_month=[24], months=[12],
                stop=datetime.datetime(2005, 1, 1))
        sched = RepeatSchedule(repeat_specs=[spec])
        self.assertFalse(spec.matches(at_date=christmas))
        self.assertFalse(sched.matches(at_date=christmas))

        # stop year == 2050 -> must match
        spec = RepeatSpec(days_of_month=[24], months=[12],
                stop=datetime.datetime(2050, 1, 1))
        sched = RepeatSchedule(repeat_specs=[spec])
        self.assertTrue(spec.matches(at_date=christmas))
        self.assertTrue(sched.matches(at_date=christmas))

    def test_restrictions(self):
        """Check various ways in which a Spec can have restrictions"""
        # Saturday, August 30st 2014, 10:00am
        saturday = datetime.datetime(2014, 8, 30, 10, 0, 0)
        # Monday, September 1st 2014, 00:10am
        monday = datetime.datetime(2014, 9, 1, 0, 10, 0)

        # Restrict by day of week.
        spec = RepeatSpec(days_of_week=[6])
        self.assertTrue(spec.matches(at_date=saturday))
        self.assertFalse(spec.matches(at_date=monday))

        # Restrict by day of month.
        spec = RepeatSpec(days_of_month=[30])
        self.assertTrue(spec.matches(at_date=saturday))
        self.assertFalse(spec.matches(at_date=monday))

        # Restrict by month.
        spec = RepeatSpec(months=[8])
        self.assertTrue(spec.matches(at_date=saturday))
        self.assertFalse(spec.matches(at_date=monday))

        # Restrict by interval (9:00 to 11:00).
        spec = RepeatSpec(intervals=[(9 * 3600, 11 * 3600)])
        self.assertTrue(spec.matches(at_date=saturday))
        self.assertFalse(spec.matches(at_date=monday))

        # Restrict by multiple intervals
        spec = RepeatSpec(intervals=[(42, 43), (9 * 3600, 11 * 3600)])
        self.assertTrue(spec.matches(at_date=saturday))
        self.assertFalse(spec.matches(at_date=monday))

    def test_multiple_specs(self):
        spec1 = RepeatSpec(days_of_month=[24], months=[12])
        spec2 = RepeatSpec(days_of_month=[31], months=[1])
        sched = RepeatSchedule(repeat_specs=[spec1, spec2])

        self.assertTrue(sched.matches(
                at_date=datetime.datetime(2022, 12, 24, 1)))
        self.assertTrue(sched.matches(
                at_date=datetime.datetime(1956, 1, 31, 12)))
        self.assertFalse(sched.matches(
                at_date=datetime.datetime(2014, 6, 6, 6)))

    def test_spec_to_json_to_spec(self):
        # start / stop are null
        old_spec = RepeatSpec(days_of_month=[24], months=[12])
        jsonified = old_spec.to_json()
        new_spec = RepeatSpec.from_json(jsonified)

        self.assertEqual(old_spec, new_spec)

        # start / stop are not null
        old_spec = RepeatSpec(days_of_month=[24], months=[12],
                start=datetime.datetime(1950, 1, 1),
                stop=datetime.datetime(2050, 1, 1))
        jsonified = old_spec.to_json()
        new_spec = RepeatSpec.from_json(jsonified)

        self.assertEqual(old_spec, new_spec)

    def test_sched_to_json_to_sched(self):
        # no specs
        old_sched = RepeatSchedule(repeat_specs=[])
        jsonified = old_sched.to_json()
        new_sched = RepeatSchedule.from_json(jsonified)
        self.assertEqual(old_sched, new_sched)

        # a single spec
        spec1 = RepeatSpec(days_of_month=[24], months=[12],
                stop=datetime.datetime(2050, 1, 1))
        old_sched = RepeatSchedule(repeat_specs=[spec1])
        jsonified = old_sched.to_json()
        new_sched = RepeatSchedule.from_json(jsonified)
        self.assertEqual(old_sched, new_sched)

        # multiple specs
        spec2 = RepeatSpec(days_of_month=[6], months=[6],
                stop=datetime.datetime(2050, 1, 1))
        old_sched = RepeatSchedule(repeat_specs=[spec1, spec2])
        jsonified = old_sched.to_json()
        new_sched = RepeatSchedule.from_json(jsonified)
        self.assertEqual(old_sched, new_sched)

    def test_collapse_ranges(self):
        old_spec = RepeatSpec()
        jsonified = old_spec.to_json()

        # range(1, 13) for months and range(1, 32) for days should have been
        # collapsed to ["1-12"] and ["1-31"] instead of [1, 2, 3, 4....], which
        # would be pretty long.
        # The length should be 116 bytes, but let's not be too strict.
        self.assertLess(len(jsonified), 125)

        # Of course, ranges should get expanded again, too.
        new_spec = RepeatSpec.from_json(jsonified)
        self.assertEqual(old_spec, new_spec)


    def test_collapse_multiple_ranges(self):
        # More complicated setup with multiple ranges and gaps.
        days = [2, 12, 22]
        for extra_day in days:
            old_spec = RepeatSpec(days_of_month=
                    list(range(4, 8)) + list(range (14, 18)) + [extra_day]
                    )
            jsonified = old_spec.to_json()
            new_spec = RepeatSpec.from_json(jsonified)
            self.assertEqual(old_spec, new_spec)

    def test_no_collapse(self):
        # At the user's choice, ranges are not collapsed but stored verbatim.
        old_spec = RepeatSpec()
        json_collapsed = old_spec.to_json()
        json_uncollapsed = old_spec.to_json(collapse_ranges=False)

        # The uncollapsed version must be much longer than the collapsed
        # version, otherwise something is fishy.
        self.assertGreater(len(json_uncollapsed), len(json_collapsed))
        # Uncollapsed JSON must be loadable, too.
        new_spec = RepeatSpec.from_json(json_uncollapsed)
        self.assertEqual(new_spec, old_spec)

    def test_monday_is_day_1(self):
        """Monday must be day 1, not day 0"""
        spec = RepeatSpec(days_of_week=[1])
        # May 26th, 2014, was a Monday.
        monday = datetime.datetime(2014, 5, 26)
        sunday = datetime.datetime(2014, 5, 25)

        self.assertTrue(spec.matches(at_date=monday))
        self.assertFalse(spec.matches(at_date=sunday))

    def test_default_always(self):
        """By default, RepeatSpecs must always match"""
        spec = RepeatSpec()

        # August 31st 2014 is a Sunday (last day of month, last day of week)
        sunday = datetime.datetime(2014, 8, 31, 23, 59, 59)
        self.assertTrue(spec.matches(at_date=sunday))

        # September 1st 2014 is a Monday (first day of month, first day of week)
        monday = datetime.datetime(2014, 9, 1, 23, 59, 59)
        self.assertTrue(spec.matches(at_date=monday))

        # The module should not suddenly fail in the year 2036 (which happens
        # to have a February 29th).
        far_future = datetime.datetime(2036, 2, 29, 0, 0, 0)
        self.assertTrue(spec.matches(at_date=far_future))

    def check_equal(self, cron_syntax):
        """Brute-force check if CronTime and RepeatSchedule do the same thing"""
        cron_time = CronTime(cron_syntax=cron_syntax)
        schedule = RepeatSchedule.from_cron_syntax(cron_syntax)

        # Simulate December 31st, 2016 (a Saturday), 0.5 seconds after midnight.
        now = datetime.datetime(2016, 12, 31, 0, 0, 0, 500 * 1000)
        # Simulate the following 48 hours, in steps of 11 seconds. This will
        # give us a change of day, month, year, and also check if Sunday works.
        eleven_seconds = datetime.timedelta(seconds=11)
        two_days_in_seconds = 2 * 24 * 60 * 60

        for count in range(two_days_in_seconds // 11):
            self.assertEqual(
                    cron_time.runs_at(now),
                    schedule.matches(at_date=now),
                    msg="Failed for '%s' on date %s" % (cron_syntax, now))

            now += eleven_seconds

    def test_from_cron_syntax(self):
        """Conversion of Cron syntax to RepeatSchedule"""
        always = RepeatSchedule.from_cron_syntax("* * * * *")
        self.assertTrue(always.matches)
        # That cron schedule can be merged into one big interval.
        self.assertEqual(len(always.repeat_specs), 1)

        for cron_syntax in ("1-10 */3 * * *", "* * 1 * mon", "* * 1 * *",
                "* * * * wed", "*/10,42 * * jan-mar *", "* * * dec tue",
                "* * * * *"):
            self.check_equal(cron_syntax)

    def test_repr_eval(self):
        """eval(repr(foobar)) should return an object that is equal to foobar"""
        spec1 = RepeatSpec(days_of_week=[1, 2, 3, 4, 5], months=[3, 4, 12],
                intervals=[(10, 100), (444, 555)])
        rep = repr(spec1)
        new_spec1 = eval(rep)
        self.assertEqual(spec1, new_spec1)

        spec2 = RepeatSpec(days_of_week=[1, 2, 3, 4, 5], months=[3, 4, 12],
                start=datetime.datetime(2014, 8, 31, 23, 59, 58),
                stop=datetime.datetime(2014, 9, 1, 11, 12, 13))
        rep = repr(spec2)
        new_spec2 = eval(rep)
        self.assertEqual(spec2, new_spec2)

        sched = RepeatSchedule(repeat_specs=[spec1, spec2])
        rep = repr(sched)
        new_sched = eval(rep)
        self.assertEqual(sched, new_sched)

    def test_fractional_seconds(self):
        """Check if scheduling is precise with sub-second precision"""
        # match from 0.9 seconds after midnight to 2.9 seconds after midnight.
        spec = RepeatSpec(intervals=[(0.9, 2.9)])

        # 0.85 seconds after midnight -> 0.05 seconds too early
        now = datetime.datetime(2016, 12, 31, 0, 0, 0, 850 * 1000)
        self.assertFalse(spec.matches(at_date=now))

        # 0.95 seconds after midnight -> spec should match
        now += datetime.timedelta(milliseconds=100)
        self.assertTrue(spec.matches(at_date=now))

        # 2.95 seconds after midnight -> 0.05 seconds too late
        now += datetime.timedelta(seconds=2)
        self.assertFalse(spec.matches(at_date=now))

    def test_human_readable(self):
        # Should be smart about weekdays/weekends.
        spec1 = RepeatSpec(days_of_week=[1, 2, 3, 4, 5])
        expected1 = "on weekdays between 00:00:00 and 24:00:00"
        self.assertEqual(spec1.human_readable, expected1)
        spec2 = RepeatSpec(days_of_week=[6, 7])
        expected2 = "on weekends between 00:00:00 and 24:00:00"
        self.assertEqual(spec2.human_readable, expected2)

        # Should use the names for the weekdays, not the numbers
        spec = RepeatSpec(days_of_week=[1, 2, 3])
        self.assertEqual(spec.human_readable,
                "on Monday, Tuesday, Wednesday between 00:00:00 and 24:00:00")

        # Day of month should be collapsed as far as possible.
        spec = RepeatSpec(days_of_month=list(range(1, 5)) + list(range(10, 12)) + [8])
        self.assertEqual(spec.human_readable,
                "on day of month 1-4, 8, 10-11 between 00:00:00 and 24:00:00")

        # "Every day" to make things look nicer
        spec = RepeatSpec(months=[8, 9])
        self.assertEqual(spec.human_readable,
                "every day in August, September between 00:00:00 and 24:00:00")

        # Start and stop date must be in there.
        # August 31st 2014 is a Sunday (last d
        sunday = datetime.datetime(2014, 8, 31, 23, 59, 58)
        # September 1st 2014 is a Monday (first day of month, first day of week)
        monday = datetime.datetime(2014, 9, 1, 11, 12, 13)
        spec = RepeatSpec(start=sunday, stop=monday, intervals=[(0, 600)])
        self.assertEqual(spec.human_readable,
                "from 2014-08-31 23:59:58 until 2014-09-01 11:12:13 every day "
                "between 00:00:00 and 00:10:00")

        # RepeatSchedules must combine the information of their Specs
        schedule = RepeatSchedule(repeat_specs=[spec1, spec2])
        expected = "will run " + expected1 + ", " + expected2
        self.assertEqual(schedule.human_readable, expected)

if __name__ == "__main__":
    unittest2.main()

