import unittest
from ax.utils.tupelizingset import TupelizingSet

class TestTupelizingSet(unittest.TestCase):
    def test_empty(self):
        ns = TupelizingSet ()
        self.assertEqual (ns, set ())


    def test_from_dict(self):
        ns = TupelizingSet ({"1" : "2"})
        self.assertEqual (ns, set ({"1" : "2"}))


    def test_simple_int(self):
        ns = TupelizingSet ((1, ))
        self.assertEqual (ns, set ((1, )))


    def test_simple_strings(self):
        ns = TupelizingSet (("1", "2"))
        self.assertEqual (ns, set (("1", "2")))


    def test_strings_in_list(self):
        ns = TupelizingSet ([["1", "2"]])
        self.assertEqual (ns, set ((("1", "2"),)))


    def test_multiple_lists(self):
        ns = TupelizingSet ([["1", "2"], ["2", "2"]])
        self.assertEqual (ns, set ((('1', '2'), ('2', '2'))))


    def test_simple_error(self):
        self.assertRaises (TypeError, TupelizingSet, 1)

if __name__ == "__main__":
    unittest.main()

