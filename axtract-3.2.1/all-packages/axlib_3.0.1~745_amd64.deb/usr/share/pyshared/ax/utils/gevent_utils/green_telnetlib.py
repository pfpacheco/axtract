"""Provide a version of telnetlib.Telnet that is compatible with gevent

If you don't want to globally patch the builtin modules with the
gevent.monkey.patch_all() call but still want to use the features of the
telnetlib, import your "Telnet" class from this module.
"""

import imp
import gevent.select
import gevent.socket

# Loads a 'deepcopy' of telnetlib under the name '_green_telnetlib'. Any
# changes to _green_telnetlib will not affect the telnetlib that others
# may import.
imp.load_module('_green_telnetlib', *imp.find_module("telnetlib"))
import _green_telnetlib

# Replace modules that telnetlib imports with green equivalents.
_green_telnetlib.select = gevent.select
_green_telnetlib.socket= gevent.socket

# Remove methods that use threads to prevent their accidental use.
_green_telnetlib.Telnet.mt_interact = None
_green_telnetlib.Telnet.listener = None


Telnet = _green_telnetlib.Telnet
__all__ = ["Telnet"]
