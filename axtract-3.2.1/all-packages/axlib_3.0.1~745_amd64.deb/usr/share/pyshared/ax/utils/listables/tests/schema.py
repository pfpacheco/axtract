"""
Schema for listables unit tests
"""
from ax.utils.listables import SqlListable

class ListablesTestSchema(object):

    class Enterprise(SqlListable):
        table = 'vss_ENTERPRISE'
        primary_id = 'account_name'
        master_params = ['account_name', 'account_parent', 'account_role']
        parent_types = []


    class Operator(SqlListable):
        table = 'vss_OPERATOR'
        primary_id = 'account_name'
        master_params = ['account_name', 'account_parent', 'account_role']
        parent_types = [{'type': 'Enterprise', 'on': ('account_parent', 'account_name')}]


    class User(SqlListable):
        table = 'vss_USER'
        primary_id = 'account_name'
        master_params = ['account_name', 'account_parent', 'account_role']
        parent_types = [{'type': 'Operator', 'on': ('account_parent', 'account_name')}]


    class cpe(SqlListable):
        """ Soutbound CPE """
        table          = 'CPEManager_CPEs'
        primary_id     = 'cpeid'
        master_params  = ['cpeid', 'version', 'cid', 'cid2']
        parent_types = [{'type': 'Operator', 'on': ('cid2', 'account_name')}]


    class UserCPERelation(SqlListable):
        table = 'vss_USER_CPE_RELATION'
        primary_id = 'serviceid'
        parent_types = [
                {'type': 'User', 'on': ('userid', 'account_name')},
                {'type': 'cpe', 'on': 'cpeid'}]


    class Ticket(SqlListable):
        table          = 'AXTickets'
        primary_id     = 'ticketid'
        parent_types   = [{'type': 'cpe', 'on': ('cpeid')}]
        master_params  = ['status' , 'title' , 'ticketid' , 'step' , 'cpeid']
