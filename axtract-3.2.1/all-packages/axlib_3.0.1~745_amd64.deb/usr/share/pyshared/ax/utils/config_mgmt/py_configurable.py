""" gk2:Option parsing and presentment to the user *directly* from the source code
    of the python class.
    You can use it by defining a CFG class in your code and refer to it in your
    main object or by directly inheriting from PyConfigurable in your main method
    The first option might allow easier reload of new config during runtime.
    Usage Example: see __main__
"""
# TBD: Currently introspection only for attributes, on demand also basic
# conditions setting executable methods based on command line.

import os
import sys
import time
import inspect
import optparse
from ast import literal_eval


def py(s):
    # config files are functional python, force the name:
    if not s.endswith('.py'):
        s = s + '.py'
    return s

def _liteval(s):
    """ cli parsing can fail fatal:"""
    try:
        return literal_eval(s)
    except Exception:
        import traceback
        print('!!Error in parsing CLI entry %s' % s)
        traceback.print_exc()
        sys.exit(1)


class PyConfigurable(object):
    config_file = None
    defs_by_var = None
    _usage = None

    def __init__(self, optparse=None):
        self.use_optparse = optparse
        self.initialize_cfg()
        if optparse:
            self.optparse()



    def initialize_cfg(self):
        """
        introspect our source, typcially called in __init__.
        Merge all up the mro, for hirarchies of config holding classes.
        """

        # short options, for later cli checks:
        self._short_opts = {}

        # remember all configurables per class in the mro:
        self.cfg_vars_by_class = {}

        self.docu_by_var = {}
        self.defs_by_var = {}
        # to get values back after value resetting objects:
        self.inst_vals_by_var = {}
        # will force always the correct type:
        self.deftypes_by_var = {}
        self.imports = []

        # set the src_by_class variable containing _all_ vars with comments:
        for c in self.__class__.mro():
            if c == PyConfigurable:
                break
            # source lines:
            sl = inspect.getsourcelines(c)[0][1:]
            c = c.__name__

            cfg_vars = self.cfg_vars_by_class.setdefault(c, [])
            docu = []
            for line in sl:
                ll = line.strip()
                if not line:
                    docu = []
                    continue
                if ll.startswith('def ') or ll.startswith('_'):
                    # end of cfg vars:
                    break
                elif ll.startswith('#'):
                    docu.append(ll)
                elif ll.startswith('import ') or ll.startswith('from ') and \
                        ' import ' in ll:
                        # we support python code in the config.
                        # but it must evaluate w/o external environ, so:
                    self.imports.append(ll)
                    docu = []
                elif '=' in  ll:
                    var, dfl = ll.split('=', 1)
                    var = var.strip()
                    # var is really an attribute and not already set?
                    if not var in dir(self) or var in self.defs_by_var:
                        docu = []
                        continue
                    cfg_vars.append(var)
                    self.docu_by_var[var] = docu
                    instval = getattr(self, var)
                    self.inst_vals_by_var[var] = instval
                    dfl = dfl.strip()
                    deftype = type(instval)
                    self.defs_by_var[var] = dfl
                    self.deftypes_by_var[var] = deftype
                    docu = []

        self.pyopt_parser = self.setup_optparse()


    def reinit(self):
        """
        Some people in axiros believe that variable definition incl.
        value resets have to be done in __init__.
        So when we need to call __init__ we can get our values back by
        calling this
        """
        for k, v in self.inst_vals_by_var.items():
            if not getattr(self, k):
                setattr(self, k, v)

    def __repr__(self):
        return self.__class__.__name__


    def create_config_file(self, dest_file=None):
        """ dump our key values into a file, with docu """
        if not self.defs_by_var:
            self.initialize_cfg()
        if not dest_file:
            dest_file = self.config_file
        if not dest_file:
            raise IOError('Cannot dump config - no filename')

        with open(py(dest_file), 'w') as file:
            w = file.write
            w('# %s\n' % time.ctime())
            for imp in self.imports:
                w(imp + '\n')
            for c in self.__class__.mro():
                vars = self._getvars(c)
                if not vars:
                    continue
                h = '%s Options' % c.__name__
                w('\n# %s %s\n' % ('-'* (77 - len(h)), h))
                for var in vars:
                    docu = self.docu_by_var[var]
                    w('\n%s\n%s = %s\n' % ('\n'.join(docu), var,
                                           self.defs_by_var[var]))
                w('\n')
        print('Have written %s' % dest_file)


    def reconfigure(self, source_file=None):
        """ load the values of the config file into self """
        if not source_file:
            source_file = self.config_file
        source_file = py(source_file)
        if not source_file or not os.path.exists(source_file):
            raise IOError(("Config file %s not found. "
                   "Continuing using command line options.") % source_file)

        with open(py(source_file), 'r') as file:
            exec(file.read(), locals())

        for k, v in locals().items():
            if hasattr(self, k):
                setattr(self, k, v)

    def _getvars(self, c):
        return self.cfg_vars_by_class.get(c.__name__)


    def get_state_map(self, main_only=0):
        """ just a service for clients who want to forward their config state """
        ret = {}
        for c, vars in self.cfg_vars_by_class.items():
            if main_only and not c == self.__class__.__name__:
                continue
            for k in vars:
                ret[k] = getattr(self, k)
        return ret

    def setup_optparse(self):
        """ Client wants to work with an option_parser instance.
        Create its options, to be able to configure me via command line as well
        """
        me = sys.argv[0]
        use = self._usage or """Usage:
        %s cfg_dump [filename]
        %s [options]
        """ % (me, me)

        o = optparse.OptionParser(usage=use)
        pa = o.add_option
        for c in self.__class__.mro():
            vars = self._getvars(c)
            if not vars:
                continue
            for var in vars:
                # do we have a short option in the doc?:
                doc = ''
                for l in self.docu_by_var[var]:
                    doc += l[1:].strip()

                if doc and not doc.endswith('.'):
                    doc += '.'
                doc = doc + '\nDefault: %s\n' % self.defs_by_var[var]
                doc = doc.replace('.. Default', '. Default')

                if len(doc) > 4 and doc[0] == '[' and doc[2:4] == '] ':
                    short = "-%s" % doc[1]
                    self._short_opts[var] = short
                    doc = doc[4:]
                else:
                    short = ''
                pa(short, "--%s" % var, dest=var, help=doc,
                   default=getattr(self, var))
        return o

    def getopt(self, k):
        """ o is the option parser, k is the config option """
        return getattr(self.pyopt_parser.parse_args()[0], k)


    def optparse(self, opt_config_file=None):
        """
        after the entry of command line options set the values into us
        cli rules over config file
        """
        o = self.pyopt_parser
        (options, args) = o.parse_args()

        fn = opt_config_file or 'config_file'
        try:
            self.reconfigure(self.getopt(fn))
        except IOError as ex:
            print(ex)


        #TODO: Can insert here all sorts of string to python magic.
        # Currently rather trivial, not needing more.
        if len(sys.argv) > 1 and sys.argv[1] == 'cfg_dump':
            fn = None
            if len(sys.argv) > 2:
                fn = sys.argv[2]
            self.create_config_file(fn)
            sys.exit(0)

        cli =  ' '.join(sys.argv)
        for k in self.docu_by_var:
            # we nail all cli entries right into the correct types, according
            # to class definition, no matter the value of the config file:

            # Current Value of config file:
            v = getattr(self, k)

            cv = getattr(options, k, None)
            # was it really entered on cli? there is no 'var-seen'
            # API in optparse, so have to check for ourself :-/
            if not ' --%s=' % k in cli and \
            not ' %s '  % self._short_opts.get(k, ' -xx ') in cli:
                continue

            # cli value was given and different from config(?):
            if cv is not None and cv != v:
                # type according to class def:
                vtype = self.deftypes_by_var[k]
                if vtype == type(None):
                    # None in class def -> take type from config file:
                    if type(v) != type(None):
                        gv = type(v)(cv)
                    else:
                        gv = cv
                else:
                    # list, dict or plain type:
                    # user can enter pythonic, like "{... or like "foo:bar, ...
                    if vtype == type([]):
                        if cv.startswith('['):
                            gv = _liteval(cv)
                        else:
                            # only list of strings:
                            gv = cv.replace(', ', ',').split(',')
                    elif vtype == type({}):
                        if cv.startswith('{'):
                            gv = _liteval(cv)
                        else:
                            # cheap dict handling like --myd="foo:bar, foo2:bar2"
                            gd = {}
                            for kv in gv.split(','):
                                if not ':' in kv:
                                    raise Exception("need a dict format for %s" % k)
                                dk, dv = kv.split(':', 1)
                                gd[dk.strip()] = dv.strip()
                            gv = gd
                    else:
                        gv = vtype(cv)
                #print 'taking %s=%s from commandline' % (k, gv)
                setattr(self, k, gv)


# AXDaemons can inherit their config objects from here:
class AXDaemonCfg(PyConfigurable):
    """ Standard AXDaemon Options """
    # User/group ID that the daemon process will switch to.
    # Can be numeric (e.g. 0 for root) or names when you set them. After
    # setup(), they are converted to _numeric_ values.
    user_id = None
    group_id = None

    # pid_file is where the daemon stores its Process ID.
    pid_file = None

    # Either True or False
    daemonize = None

    # [l] May be "-" for STDERR or "syslog..." for syslogging. See _setup_syslog
    # for details on about setting up syslog via this parameter.
    log_file = None

    # How big a logfile may be before it is rotated and how many old
    # files to keep before deleting. Only becomes effective if you log
    # to a file, of course.
    log_max_filesize = 100 * 1000 * 1000
    log_backup_count = 3

    # log_level is either "CRITICAL", "ERROR", "WARNING", "INFO" or "DEBUG"
    log_level = None

    # The daemon name that will be shown in the log file
    daemon_name = None




# --------------  just a usability example:
class ConfigurableDemo(AXDaemonCfg):
    """
    Just a demo config. Attribute values define the defaults,
    comments define the helpstrings
    This demos *direct* inheritance from a PyConfigurable, not using a CFG object
    """
    from os import getpid

    #[f] A configurable property, as shortopt we choose 'f'
    foo = 'bar'

    # Another one
    #   notice that we keep the linewraps - formatting in the config file
    bar = True

    # And a more complex one:
    fancy_stuff = {'mypid': '%s' % getpid()}
    # this is a private var, startint with '_', not for config:
    _private_var = 23

    # another one but after the first _ one, so ignored:
    baz = 'Not configurable'

    # some method, ignored in config:
    def demo_method(self):
        print("in method")

if __name__ == '__main__':
    # check also job_handler.py for an usage example of this module
    cfg = ConfigurableDemo()
    print("command line help would look like:")
    cfg.pyopt_parser.print_help()
    print()
    print("config file would look like:")
    print()
    cfg.create_config_file('/tmp/pyconfdemo')
    with open('/tmp/pyconfdemo.py') as f:
        print(f.read())
    cfg.optparse()


