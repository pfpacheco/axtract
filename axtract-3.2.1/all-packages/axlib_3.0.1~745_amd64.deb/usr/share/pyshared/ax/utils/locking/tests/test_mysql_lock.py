'''
Testing the lock for sqlalchemy and std. connector
'''

import os, sys

# sys.path.insert(0, '/usr/lib64/python2.7/site-packages')
import time
from ax.utils.six.moves import _thread as thread
import unittest2
from ax.utils.locking.tools import p
from contextlib import closing
from threading import Event
from ax.utils.locking.mysql_lock import mysql_get_lock, mysql_lock, run_once
import pdb


# ---------------------------------------------------------check server running
breakpoint = pdb.set_trace
envget = os.environ.get

# set to true when debuggin w/o env:
skip_slow_tests = envget('fast_mode') or False

dflts = '127.0.0.1', 'root', 'ax', 3306
# dflts = '192.168.178.40', 'root', 'ax', 3306

cfg = [
    (k, envget(k, dflts[i]))
    for k, i in zip(('host', 'user', 'passwd', 'port'), range(0, 5))
]


# Checking for Available Libs and Server Presence:
def run__mysql(conn, sql, params=None):
    conn.query(sql % params if params != None else sql)
    res = conn.store_result()
    fetch = lambda res: [res.fetch_row()[0] for i in range(res.num_rows())]
    return res if res is None else tuple(fetch(res))


def engine():
    from sqlalchemy import create_engine

    url = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s' % dict(cfg)
    eng = create_engine(url, echo=False)
    # no-op, makes factoring a bit easier for tests of MySQL and Alch.:
    eng.close = lambda *a, **kw: None
    return eng


def run_sqlalchemy(sql, params=None):
    with closing(engine().raw_connection()) as conn:
        with closing(conn.cursor()) as cursor:
            cursor.execute(sql, params)
            return cursor.fetchall()


def run_mysqldb(conn, sql, params=None):
    with closing(conn.cursor()) as cursor:
        cursor.execute(sql, params)
        return cursor.fetchall()


try:
    import _mysql

    with closing(_mysql.connect(**dict(cfg))) as conn:
        dbs1 = run__mysql(conn, 'show databases')
    have_conn = True
except:
    have_conn = False

try:
    import MySQLdb

    with closing(MySQLdb.connect(**dict(cfg))) as conn:
        dbs2 = run_mysqldb(conn, 'show databases')
    have_mysqldb = True
except:
    have_mysqldb = False

try:
    if not have_mysqldb:
        raise
    dbs3 = run_sqlalchemy('show databases')
    have_sqlalch_conn = True
except:
    have_sqlalch_conn = False


# ---------------------------------------------------------check available libs


def wait(dt):
    t1 = time.time()
    while time.time() - t1 < dt:
        time.sleep(dt / 10.0)


eq = lambda self, a, b: self.assertEqual(a, b)
paral = thread.start_new_thread
test_lock_nr = 0


class Tools:
    def wait_fin(self, nr):
        'threads.join like function'
        while True:
            wait(0.01)
            if len(self.fin_threads) == nr:
                return

    def work(self, i, dt, timeout=10, no_lock=False):
        '''do will only be run if no other do is running -> tests if the lock
        serializes runs

        dt: time the job blocks while having the lock
        '''
        try:

            def do_work(dt):
                # a buggyinternal busy checker (no lock, ok for testing):
                if self.state['busy']:
                    return
                self.state['busy'] = True
                p('working', i)
                self.state[i] = time.time() - self.ts
                wait(dt)
                self.state['busy'] = False

            if self.no_lock:
                return do_work(dt)

            # .close is a no-op if get_conn is an engine:
            with closing(self.get_conn()) as conn:
                with mysql_lock(conn, self.lock_name, timeout):
                    do_work(dt)
        finally:
            self.fin_threads.append(i)

    def work_once(self, ev, nr, dt):
        '''
        workload for the run_once testing - preparing all conns for concurrent
        start
        '''
        conn = self.get_conn()
        self.have_conns.append(conn)
        ev.wait(5)
        with run_once(conn, 'once_test') as do:
            if do:
                self.state[nr] = time.time() - self.ts
                wait(dt)
        self.fin_threads.append(1)


in_gevent = os.environ.get('ENFORCE_GEVENT_DURING_BUILD_TESTS')


class DoTestLock(Tools):
    'common base class for all tests'

    def setUp(self):
        global test_lock_nr
        test_lock_nr += 1
        self.ts = time.time()
        self.state = {'busy': False}
        self.no_lock = False
        self.lock_name = 'test_lock_%s' % test_lock_nr
        self.fin_threads = []

    def test_attr(self):
        'sending timeout < 1'
        try:
            with mysql_lock('x', 'x', 0.9):
                raise Exception('expected AttributeError')
        except AttributeError as ex:
            pass

    # TODO: why skipped?
    @unittest2.skipIf(in_gevent, 'Blocks in gevent')
    def test_concurrent_access(self):

        self.no_lock = True
        for i in 1, 2, 3:
            paral(self.work, (i, 0.01))
        self.wait_fin(3)
        # only one ran, due to work internal busy checking:
        eq(self, len(self.state), 2)

        # now with the lock, reset stuff:
        self.state, self.no_lock, self.fin_threads = {'busy': False}, False, []

        for i in 1, 2, 3:
            paral(self.work, (i, 0.1))

        # wait until at least one of them is started:
        while len(self.state) == 1:
            wait(0.01)

        t1 = time.time()
        with closing(self.get_conn()) as conn:
            with mysql_lock(conn, self.lock_name):
                pass

        # all have been run, but one after the other, with dt = 0.1 per run
        self.assertGreater(time.time() - t1, 3 * 0.01)
        # all ran:
        eq(self, sorted(self.state.keys()), [1, 2, 3, 'busy'])
        self.wait_fin(3)

    def test_once(self):
        ev = Event()
        self.have_conns = []
        for i in range(0, 10):
            paral(self.work_once, (ev, i, 0.5))
        # have all connections ready, to have 'real' concurrency:
        while True:
            wait(0.01)
            if len(self.have_conns) == 10:
                break
        # go:
        ev.set()
        self.wait_fin(10)

        # keys: only 'busy' and the one which ran:
        eq(self, len(self.state), 2)
        [c.close() for c in self.have_conns]
        # TODO: find out why this is not working in gevent:
        if in_gevent:
            return
        with closing(self.get_conn()) as conn:
            with run_once(conn, self.lock_name) as do:
                if do:
                    self.state['x'] = 1
        self.assertIn('x', self.state)
        eq(self, self.state['x'], 1)

    @unittest2.skipIf(skip_slow_tests, 'Fastmode is set')
    def test_timeout(self):
        '''
        Main thread gets the lock before first thread is finished

        Problem: Testtime (timeout must be > 1 sec)
        but see no way to reduce it :-(
        '''
        paral(self.work, (1, 2))
        wait(0.1)  # have the thread started and own the lock
        t1 = time.time()
        with mysql_lock(self.get_conn(), self.lock_name, timeout=1):
            pass
        dt = time.time() - t1
        self.assertGreater(dt, 1)
        self.assertLess(dt, 1.5)
        self.wait_fin(1)


@unittest2.skipIf(not have_sqlalch_conn, 'No sqlalchemy')
class TestSqlAlchemyLock(DoTestLock, unittest2.TestCase):
    # only one needed:
    if have_sqlalch_conn:
        _engine = engine()

    get_conn = lambda self: self._engine

    def tearDown(self):
        self._engine.close()


@unittest2.skipIf(not have_mysqldb, 'No MySQLdb')
class TestMySQLDBLock(DoTestLock, unittest2.TestCase):
    'using the standard driver'

    get_conn = lambda self: MySQLdb.connect(**dict(cfg))


if __name__ == '__main__':
    unittest2.main()
