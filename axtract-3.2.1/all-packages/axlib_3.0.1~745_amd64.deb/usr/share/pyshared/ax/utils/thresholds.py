import os
from itertools import chain
import simplejson as json

"""
The library supports a global thresholds config such as the one below
defined as the value of the key "thresholds" inside a JSON file
or directly as a Python dict.

    {
        "param_1": [[5.2], "LOWER_IS_BETTER"],
        "param_2": [[5.2], "HIGHER_IS_BETTER"],
        "param_3": [[25.1, 37.5], "LOWER_IS_BETTER"],
        "param_4": [[25.1, 37.5], "HIGHER_IS_BETTER"],
        "param_5": [[[1.5, 3]], "INNER_IS_BETTER"],
        "param_6": [[[1.5, 3]], "OUTER_IS_BETTER"],
        "param_7": [[[35, 49], [30, 52]], "INNER_IS_BETTER"]
        "param_8": [[[35, 49], [30, 52]], "OUTER_IS_BETTER"]
    }

Alternatively, the library can be used with the thresholds config for a single
parameter without the context of a global thresholds config, like this:

    [[5.2], "LOWER_IS_BETTER"]

"""


class ThresholdEngineByConfig(object):
    """
        Helper class to produce Threshold Engines from a config

        This class has one input parameter, which may be:
        - a string indicating the path to a valid JSON file
          with the key `thresholds` in it
        - a dict comprising the global thresholds config

        Behaviour:
        - if the argument is a file path to a JSON config file,
          then the thresholds config is extracted from the file
        - if the argument is a dict, then that dict is assumed to be
          the global thresholds config

        - The method `get_engine_by_param` returns the Threshold Engine class
          for the parameter passed as an argument
    """

    def __init__(self, cfg):
        if isinstance(cfg, str) and os.path.isfile(cfg):
             with open(cfg, 'r') as cfg_json:
                thresholds = json.load(cfg_json).get('thresholds')
                if thresholds is None:
                    raise Exception("Thresholds not defined in %s" % cfg)

                cfg = thresholds

        if not isinstance(cfg, dict):
            if not isinstance(cfg, str) or not os.path.isfile(cfg):
                raise Exception("The global thresholds config must be a python dict")

        self.cfg = cfg

    def get_engine_by_param(self, param):
        return ThresholdEngine(self.cfg.get(param, []))


class ThresholdEngine(object):
    """
    Helper class to calc thresholds based on config.

    This class has one input parameter,
    which must be a two-element list or tuple:

    - 1st element = `thresholds`: a list of size 1 or 2.
    - 2nd element = `order`: string defining how to interpret the values:
        - 'HIGHER_IS_BETTER'
        - 'LOWER_IS_BETTER'
        - 'OUTER_IS_BETTER'
        - 'INNER_IS_BETTER'

    Behaviour:
    - if the input parameter is either the empty list or the empty tuple,
      then return 'unknown'

    - if `order` is *simple* (i.e. either HIGHER_IS_BETTER or LOWER_IS_BETTER),
      then `thresholds` may contain one or two numbers (int or float)
      If two thresholds are given, then the first threshold
      must not be bigger than the second.

      One threshold => good/bad
      Two thresholds => good/marginal/bad

    - if `order` is *complex* (i.e. either INNER_IS_BETTER or HIGHER_IS_BETTER),
      then `thresholds` may contain one or two intervals (list or tuple).
      For each interval the first threshold must not be bigger than the second.
      If two intervals are given, then the first interval must be the inner one
      and the second the outher one.

      One interval => good/bad
      Two intervals => good/marginal/bad

    - with respect to the extremes, the behaviour is deliberately tolerant, i.e.
      extremes are always counted as belonging to the better interval.
    """

    HIGHER_IS_BETTER = 'HIGHER_IS_BETTER'
    LOWER_IS_BETTER = 'LOWER_IS_BETTER'
    OUTER_IS_BETTER = 'OUTER_IS_BETTER'
    INNER_IS_BETTER = 'INNER_IS_BETTER'

    def __init__(self, cfg):
        if not isinstance(cfg, (list, tuple)):
            msg = "The thresholds engine's cfg must be a list or tuple: %s"
            raise Exception(msg % cfg)

        if cfg and len(cfg) != 2:
            msg = "The thresholds engine's cfg must include 2 elements: %s"
            raise Exception(msg % cfg)

        self.cfg = cfg
        if not cfg:
            return

        thresholds, order = cfg[0], cfg[1]
        self._single_sanity_check(thresholds, order)

        if order in (self.HIGHER_IS_BETTER, self.LOWER_IS_BETTER):
            self._sanity_check_simple_order(thresholds, order)

        if order in (self.OUTER_IS_BETTER, self.INNER_IS_BETTER):
            self._sanity_check_complex_order(thresholds, order)

        self.thresholds = thresholds
        self.order = order

    def _single_sanity_check(self, thresholds, order):
        if not isinstance(thresholds, (list, tuple)) or len(thresholds) > 2:
            msg = "Thresholds must be a list of size 1 or 2: %s"
            raise Exception(msg % thresholds)

        if order not in (
            self.HIGHER_IS_BETTER,
            self.LOWER_IS_BETTER,
            self.OUTER_IS_BETTER,
            self.INNER_IS_BETTER):
                raise Exception("order is not valid: %s" % order)

    def _sanity_check_simple_order(self, thresholds, order):
        if any(filter(lambda th: not isinstance(th, (int, float)), thresholds)):
            msg = "With %s thresholds may only include numbers: %s"
            raise Exception(msg % (order, thresholds))

        if len(thresholds) == 2 and thresholds[0] >= thresholds[1]:
            msg = "First threshold must be lower than the second: %s"
            raise Exception(msg % thresholds)

    def _sanity_check_complex_order(self, thresholds, order):
        if any(filter(lambda th: not isinstance(th, (list, tuple)), thresholds)):
            msg = "With %s thresholds may only include intervals: %s"
            raise Exception(msg % (order, thresholds))

        if any(filter(lambda th: len(th) != 2, thresholds)):
            msg = "Each interval must comprise 2 thresholds: %s"
            raise Exception(msg % thresholds)

        if not all(isinstance(th, (int, float)) for th in chain(*thresholds)):
            msg = "Thresholds may only include numbers in each interval: %s"
            raise Exception(msg % thresholds)

        if any(filter(lambda th: th[0] >= th[1], thresholds)):
            msg = "First threshold must be lower than the second in each interval: %s"
            raise Exception(msg % thresholds)

        if len(thresholds) == 2:
            left_ths, right_ths = zip(*thresholds)
            if left_ths[0] < left_ths[1]:
                msg = "First left threshold must not be lower than the second left : %s"
                raise Exception(msg % thresholds)

            if right_ths[0] > right_ths[1]:
                msg = "First right threshold must not be higher than the second right : %s"
                raise Exception(msg % thresholds)

    def __call__(self, val):
        if not self.cfg:
            return 'unknown'

        if self.order == self.LOWER_IS_BETTER:
            if len(self.thresholds) == 1:
                return 'good' if val <= self.thresholds[0] else 'bad'

            if len(self.thresholds) == 2:
                if val <= self.thresholds[0]:
                    return 'good'
                if val <= self.thresholds[1]:
                    return 'marginal'
                return 'bad'

        if self.order == self.HIGHER_IS_BETTER:
            if len(self.thresholds) == 1:
                return 'bad' if val < self.thresholds[0] else 'good'

            if len(self.thresholds) == 2:
                if val < self.thresholds[0]:
                    return 'bad'
                if val < self.thresholds[1]:
                    return 'marginal'
                return 'good'

        if self.order == self.INNER_IS_BETTER:
            if len(self.thresholds) == 1:
                thresholds = self.thresholds[0]
                return 'good' if thresholds[0] <= val <= thresholds[1] else 'bad'

            if len(self.thresholds) == 2:
                inner_thresholds = self.thresholds[0]
                outer_thresholds = self.thresholds[1]
                if inner_thresholds[0] <= val <= inner_thresholds[1]:
                    return 'good'
                if outer_thresholds[0] <= val <= outer_thresholds[1]:
                    return 'marginal'
                return 'bad'

        if self.order == self.OUTER_IS_BETTER:
            if len(self.thresholds) == 1:
                thresholds = self.thresholds[0]
                return 'bad' if thresholds[0] < val < thresholds[1] else 'good'

            if len(self.thresholds) == 2:
                inner_thresholds = self.thresholds[0]
                outer_thresholds = self.thresholds[1]
                if inner_thresholds[0] < val < inner_thresholds[1]:
                    return 'bad'
                if outer_thresholds[0] < val < outer_thresholds[1]:
                    return 'marginal'
                return 'good'

    def get_intervals(self, jsonisable=False):
        """
        If jsonisable = True:
            return a tuple of two-element tuples.
            The first element in each tuple is itself a two-element tuple
            indicating the interval. -inf and +inf are expressed as
            'minus_inf' and 'plus_inf', respectively.
            The second element is the quality associated with the interval.

            This format can be jasonised without further ado.

        If jsonisable = False:
            return a dict. Each key in the dict is a two-element tuple
            indicating the interval. -inf and +inf are unchanged as
            -float('inf') and float('inf'), respectively.
            The value is the quality associated with the interval.

            This format CANNOT be directly jasonised.
        """

        if not self.cfg:
            return () if jsonisable else {}

        if jsonisable:
            minus_inf = 'minus_inf'
            plus_inf = 'plus_inf'
        else:
            minus_inf = -float('inf')
            plus_inf = float('inf')

        thresholds = self.thresholds

        if self.order == self.LOWER_IS_BETTER:
            if len(thresholds) == 1:
                intervals = (
                    ((minus_inf, thresholds[0]), 'good'),
                    ((thresholds[0], plus_inf), 'bad')
                )

                return intervals if jsonisable else dict(intervals)

            if len(thresholds) == 2:
                intervals = (
                    ((minus_inf, thresholds[0]), 'good'),
                    ((thresholds[0], thresholds[1]), 'marginal'),
                    ((thresholds[1], plus_inf), 'bad')
                )

                return intervals if jsonisable else dict(intervals)

        if self.order == self.HIGHER_IS_BETTER:
            if len(thresholds) == 1:
                intervals = (
                    ((minus_inf, thresholds[0]), 'bad'),
                    ((thresholds[0], plus_inf), 'good')
                )

                return intervals if jsonisable else dict(intervals)

            if len(thresholds) == 2:
                intervals = (
                    ((minus_inf, thresholds[0]), 'bad'),
                    ((thresholds[0], thresholds[1]), 'marginal'),
                    ((thresholds[1], plus_inf), 'good')
                )

                return intervals if jsonisable else dict(intervals)

        if self.order == self.INNER_IS_BETTER:
            if len(thresholds) == 1:
                thresholds = thresholds[0]
                intervals = (
                    ((minus_inf, thresholds[0]), 'bad'),
                    ((thresholds[0], thresholds[1]), 'good'),
                    ((thresholds[1], plus_inf), 'bad')
                )

                return intervals if jsonisable else dict(intervals)

            if len(thresholds) == 2:
                thresholds = (
                    thresholds[1][0], thresholds[0][0],
                    thresholds[0][1], thresholds[1][1]
                )

                intervals = (
                    ((minus_inf, thresholds[0]), 'bad'),
                    ((thresholds[0], thresholds[1]), 'marginal'),
                    ((thresholds[1], thresholds[2]), 'good'),
                    ((thresholds[2], thresholds[3]), 'marginal'),
                    ((thresholds[3], plus_inf), 'bad')
                )

                return intervals if jsonisable else dict(intervals)

        if self.order == self.OUTER_IS_BETTER:
            if len(thresholds) == 1:
                thresholds = thresholds[0]
                intervals = (
                    ((minus_inf, thresholds[0]), 'good'),
                    ((thresholds[0], thresholds[1]), 'bad'),
                    ((thresholds[1], plus_inf), 'good')
                )

                return intervals if jsonisable else dict(intervals)

            if len(thresholds) == 2:
                thresholds = (
                    thresholds[1][0], thresholds[0][0],
                    thresholds[0][1], thresholds[1][1]
                )

                intervals = (
                    ((minus_inf, thresholds[0]), 'good'),
                    ((thresholds[0], thresholds[1]), 'marginal'),
                    ((thresholds[1], thresholds[2]), 'bad'),
                    ((thresholds[2], thresholds[3]), 'marginal'),
                    ((thresholds[3], plus_inf), 'good')
                )

                return intervals if jsonisable else dict(intervals)

