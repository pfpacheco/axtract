import time
import unittest
import pickle
import string
import itertools

from ax.utils.simple_deepcopy import deepcopy

from ax.utils.props_to_tree import py_props_to_tree
from ax.utils.props_to_tree import py_tree_to_props

from ax.utils.props_to_tree import c_props_to_tree
from ax.utils.props_to_tree import c_tree_to_props


class TestPropsToTree(unittest.TestCase):
    NB = 1
    example = {
            "I.MS.FOO": 1,
            "I.FS.XXX": 2,
            "I.MS.XXX": 3,
            "I.SH.IR.FR.SN.GK.KP": "MB",
            "X": 4,
            "XXX.FFFF": 4
        }

    def _check(self, tree):
        self.assertEqual(tree['I']['MS']['FOO'], 1)
        self.assertEqual(tree['I']['FS']['XXX'], 2)
        self.assertEqual(tree['I']['MS']['XXX'], 3)
        self.assertEqual(tree['I']['SH']['IR']['FR']['SN']['GK']['KP'], 'MB')
        self.assertEqual(tree['X'], 4)
        self.assertEqual(tree["XXX"]['FFFF'], 4)

    def test_simple_py(self):
        # start = time.time()
        for _ in range(self.NB):
            self._check(py_props_to_tree(self.example))
        # print ('simple', time.time() - start)

    def test_c_version(self):
        # start = time.time()
        for _ in range(self.NB):
            self._check(c_props_to_tree(self.example))
        # print ('real c', time.time() - start)

    def test_simple_py_complex_tree(self):
        start = {
            "I.MS.FOO": {
                "WAN.LAN": {
                    "NUM.FAB": 1}
                }
        }
        # IMPORTANT: Props to tree is not capable to convert the values also
        # the problem is the convert backwards ! we dont know the orgiginal
        # structure
        ref = {"I": {"MS": {"FOO": {"WAN.LAN": {"NUM.FAB": 1}}}}}
        self.assertEqual(ref, py_props_to_tree(start))

    def test_pickle_result(self):
        doc = {'I.MS.FOO': 1, "I.MS.BAR": 2}
        ref = {'I': {'MS': {'FOO': 1, 'BAR': 2}}}

        ret = pickle.loads(pickle.dumps(py_props_to_tree(doc)))
        self.assertEqual(ref, ret)

        ret = pickle.loads(pickle.dumps(c_props_to_tree(doc)))
        self.assertEqual(ref, ret)

    def test_memory_leak(self):
        # This test is a manual thing.
        # Let it run 1 million times and if the memory is not blown up
        # until that time you are good.
        return

        data = [i * 60 for i in string.ascii_lowercase[:10]]
        doc = {}
        for x in itertools.islice(itertools.permutations(data), 1000):
            doc['.'.join(x)] = True

        print()
        for i in itertools.count():
            if (i % 10000) == 0:
                print (time.ctime(), i)

            assert doc == c_tree_to_props(c_props_to_tree(deepcopy(doc)))


class TestTreeToProps(unittest.TestCase):
    NB = 1
    tree = {
        "I": {
            "F": {
                "X": 1
            },
            "XXXX": {
                "FFF": 3,
                "FD": 7
            }
        },
        "Foo": 1,
        "aaa": {
            "b": {
                "c": {
                    "d": 1
                }
            }
        }
    }

    def _check(self, props):
        self.assertEqual(props['I.F.X'], 1)
        self.assertEqual(props["I.XXXX.FFF"], 3)
        self.assertEqual(props["I.XXXX.FD"], 7)
        self.assertEqual(props["Foo"], 1)
        self.assertEqual(props["aaa.b.c.d"], 1)

    def test_simple(self):
        # start = time.time()
        for _ in range(self.NB):
            self._check(py_tree_to_props(self.tree))
        # print ('simple tree to props', time.time() - start)

    def test_fast(self):
        # start = time.time()
        for _ in range(self.NB):
            self._check(c_tree_to_props(self.tree))
        # print ('fast tree to props', time.time() - start)
