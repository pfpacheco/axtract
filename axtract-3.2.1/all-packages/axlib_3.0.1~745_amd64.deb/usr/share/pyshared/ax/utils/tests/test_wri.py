#!/usr/bin/python -tt

import unittest

from ax.utils import wri

class TokenbucketWRI(unittest.TestCase):
    def ratio_helper(self, wri_object, count):
        """Return item:amount mapping of the first $count items in wri_object"""
        res = {}
        for item in wri_object:
            current = res.get(item, 0)
            res[item] = current +1
            count -= 1
            if not count:
                break
        return res

    def testRatio(self):
        """Check if weights are applied correctly"""
        # Keep in mind that the sum of the weights must be a divisor of 210
        # in order for things to works out. Having only have a single item
        # will also work.
        cases = {
            ( ("foo", 42), ) : {"foo": 210},
            ( ("foo", 1), ("bar", 1) ): {"foo":105, "bar":105},
            ( ("foo", 5), ("bar", 5) ): {"foo":105, "bar":105},
            ( ("foo", 1), ("bar", 2) ): {"foo":70, "bar":140},
            ( ("foo", 10), ("bar", 20) ): {"foo":70, "bar":140},
            ( ("foo", 1), ("bar", 1), ("batz", 1) ): {"foo":70, "bar":70, "batz":70},
            ( ("foo", 2), ("bar", 2), ("batz", 2) ): {"foo":70, "bar":70, "batz":70},
        }
        for wri_class in (wri.WRI, wri.WRI2):
            for case in cases:
                wri_object = wri_class(case)
                res = self.ratio_helper(wri_object, 210)
                self.assertEqual(res, cases[case])

            # Tests that don't add up to 210

            # Large numbers, will use D'Hondt algorithm since weights cannot
            # be reduced.
            wri_object = wri_class((("foo", 10000), ("bar", 1)))
            res = self.ratio_helper(wri_object, 10001)
            self.assertEqual(res, {"foo": 10000, "bar": 1})

    def testBrokenness(self):
        """WRI2 must handle brokenness correctly"""
        wri_object = wri.WRI2([("foo", 1), ("bar", 1)], forget_after=42)
        wri_object.report_broken("foo")

        # First 42 iterations must not yield "foo".
        for count in range(0, 42):
            item = next(wri_object)
            self.assertEqual(item, "bar")
        # Next 2 iterations must yield "foo".
        items = set()
        for count in range(0, 2):
            items.add(next(wri_object))
        self.assertEqual(items, set(["foo", "bar"]))

    def testFullyBroken(self):
        """WRI2 must recover even if all items are broken.
            If the implementation uses recursion here, we may blow the stack.
            If the implementation does not count correctly, this may give us
            an eternal loop.
        """
        # With two broken items
        wri_object = wri.WRI2([("foo", 1), ("bar", 1)], forget_after=1000)
        wri_object.report_broken("foo")
        wri_object.report_broken("bar")
        items = set()
        for count in range(0, 10):
            items.add(next(wri_object))
        self.assertEqual(items, set(["foo", "bar"]))

        # With one broken item
        wri_object = wri.WRI2([("foo", 1)], forget_after=1000)
        wri_object.report_broken("foo")
        items = set()
        for count in range(0, 10):
            items.add(next(wri_object))
        self.assertEqual(items, set(["foo"]))

    def testFullyBrokenSmartness(self):
        """WRI2 must not waste CPU when all items are broken"""
        wri_object = wri.WRI2([("foo", 1), ("bar", 1)], forget_after=2**64)
        wri_object.report_broken("foo")
        wri_object.report_broken("bar")
        # If WRI2 does not recognize that all items are broken, it will perform
        # 2**64 operations. You will notice when it happens.
        items = set([next(wri_object), next(wri_object)])
        self.assertEqual(items, set(["foo", "bar"]))

        # List of item contains a duplicate now. Detection that all items are
        # broken must still work.
        wri_object = wri.WRI2([("foo", 1), ("foo", 1)], forget_after=2**64)
        wri_object.report_broken("foo")
        self.assertEqual(next(wri_object), "foo")

    def testNonRepeating(self):
        """Items that make up <= 50% of total amount must not repeat"""
        total = 20
        for count_1 in range(1, 11):
            for count_2 in range(count_1, total):
                # There will be at least as many "bar" as "foo", so "foo"
                # should not repeat at all.
                self.assertTrue(count_1 <= count_2)
                wri_object = wri.WRI( (("foo", count_1), ("bar", count_2)) )
                previous = "none"
                for index in range(total + 1):
                    current = next(wri_object)
                    if previous == "foo":
                        self.assertNotEqual(current, "foo",
                                "count_1: %d  count_2: %d" % (count_1, count_2))
                    previous = current

class TestDynamicWRI(unittest.TestCase):
    def setUp(self):
        self.wrr_scheduler = wri.DynamicWRI()

    def tearDown(self):
        pass

    def test_wri(self):
        self.wrr_scheduler.add(("job1", 2))
        self.wrr_scheduler.add(("job2", 1))
        self.wrr_scheduler.add(("job3", 3))
        self.assertEqual(3, self.wrr_scheduler.size())

        self.assertEqual("job1", next(self.wrr_scheduler))
        self.assertEqual("job1", next(self.wrr_scheduler))
        self.assertEqual("job2", next(self.wrr_scheduler))
        self.assertEqual("job3", next(self.wrr_scheduler))
        self.assertEqual("job3", next(self.wrr_scheduler))
        self.assertEqual("job3", next(self.wrr_scheduler))
        self.assertEqual("job1", next(self.wrr_scheduler))
        self.assertEqual("job1", next(self.wrr_scheduler))
        self.assertEqual("job2", next(self.wrr_scheduler))
        self.assertEqual("job3", next(self.wrr_scheduler))
        self.assertEqual("job3", next(self.wrr_scheduler))
        self.assertEqual("job3", next(self.wrr_scheduler))

    def test_wri_add(self):
        self.wrr_scheduler.add(("job1", 2))
        self.wrr_scheduler.add(("job2", 1))
        self.assertEqual(2, self.wrr_scheduler.size())

        self.assertEqual("job1", next(self.wrr_scheduler))

        self.wrr_scheduler.add(("job3", 1))
        self.assertEqual(3, self.wrr_scheduler.size())

        self.assertEqual("job1", next(self.wrr_scheduler))
        self.assertEqual("job2", next(self.wrr_scheduler))
        self.assertEqual("job3", next(self.wrr_scheduler))
        self.assertEqual("job1", next(self.wrr_scheduler))
        self.assertEqual("job1", next(self.wrr_scheduler))
        self.assertEqual("job2", next(self.wrr_scheduler))
        self.assertEqual("job3", next(self.wrr_scheduler))

        """
        The new job has to wait for its turn in the next round,
        as the round is already completed
        """
        self.wrr_scheduler.add(("job4", 2))
        self.assertEqual(4, self.wrr_scheduler.size())

        self.assertEqual("job1", next(self.wrr_scheduler))
        self.assertEqual("job1", next(self.wrr_scheduler))
        self.assertEqual("job2", next(self.wrr_scheduler))
        self.assertEqual("job3", next(self.wrr_scheduler))
        self.assertEqual("job4", next(self.wrr_scheduler))
        self.assertEqual("job4", next(self.wrr_scheduler))

    def test_wri_remove(self):
        self.wrr_scheduler.add(("job1", 1))
        self.wrr_scheduler.add(("job2", 2))
        self.wrr_scheduler.add(("job3", 1))
        self.wrr_scheduler.add(("job4", 3))
        self.assertEqual(4, self.wrr_scheduler.size())

        self.assertEqual("job1", next(self.wrr_scheduler))
        self.assertEqual("job2", next(self.wrr_scheduler))
        self.assertEqual("job2", next(self.wrr_scheduler))
        self.assertEqual("job3", next(self.wrr_scheduler))
        self.assertEqual("job4", next(self.wrr_scheduler))

        self.wrr_scheduler.remove("job4")
        self.assertEqual(3, self.wrr_scheduler.size())

        self.assertEqual("job1", next(self.wrr_scheduler))
        self.assertEqual("job2", next(self.wrr_scheduler))
        self.assertEqual("job2", next(self.wrr_scheduler))

        self.wrr_scheduler.remove("job2")
        self.assertEqual(2, self.wrr_scheduler.size())

        self.assertEqual("job3", next(self.wrr_scheduler))
        self.assertEqual("job1", next(self.wrr_scheduler))

        self.wrr_scheduler.remove("job3")
        self.assertEqual(1, self.wrr_scheduler.size())

        self.assertEqual("job1", next(self.wrr_scheduler))

        self.wrr_scheduler.remove("job1")
        self.assertEqual(0, self.wrr_scheduler.size())

        exception_occurred = 0
        try:
            self.assertEqual("job1", next(self.wrr_scheduler))
        except StopIteration:
            exception_occurred = 1

        self.assertEqual(1, exception_occurred)

    def test_wri_add_remove(self):
        self.wrr_scheduler.add(("job1", 1))
        self.wrr_scheduler.add(("job2", 2))
        self.assertEqual(2, self.wrr_scheduler.size())

        self.assertEqual("job1", next(self.wrr_scheduler))

        self.wrr_scheduler.remove("job2")
        self.wrr_scheduler.remove("job2")
        self.assertEqual(1, self.wrr_scheduler.size())

        """
        The new job has to wait for its turn in the next round,
        as the round is already completed
        """
        self.wrr_scheduler.add(("job3", 1))
        self.assertEqual(2, self.wrr_scheduler.size())

        self.assertEqual("job1", next(self.wrr_scheduler))

        self.wrr_scheduler.add(("job4", 2))
        self.assertEqual(3, self.wrr_scheduler.size())
        self.assertEqual("job3", next(self.wrr_scheduler))
        self.assertEqual("job4", next(self.wrr_scheduler))
        self.assertEqual("job4", next(self.wrr_scheduler))

        self.wrr_scheduler.remove("job1")
        self.assertEqual(2, self.wrr_scheduler.size())
        self.wrr_scheduler.remove("job4")
        self.assertEqual(1, self.wrr_scheduler.size())

        self.assertEqual("job3", next(self.wrr_scheduler))

        self.wrr_scheduler.remove("job3")
        self.assertEqual(0, self.wrr_scheduler.size())

        self.wrr_scheduler.add(("job1", 2))
        self.wrr_scheduler.add(("job2", 2))
        self.assertEqual(2, self.wrr_scheduler.size())

        self.assertEqual("job1", next(self.wrr_scheduler))
        self.assertEqual("job1", next(self.wrr_scheduler))
        self.assertEqual("job2", next(self.wrr_scheduler))
        self.assertEqual("job2", next(self.wrr_scheduler))

    def test_wri_duplicate(self):
        self.wrr_scheduler.add(("job1", 1))
        self.wrr_scheduler.add(("job2", 2))
        self.wrr_scheduler.add(("job3", 5))
        self.wrr_scheduler.add(("job2", 1))
        self.wrr_scheduler.add(("job2", 2))
        self.assertEqual(3, self.wrr_scheduler.size())

    def test_wri_iterator(self):
        self.wrr_scheduler.add(("job1", 1))
        self.wrr_scheduler.add(("job2", 2))
        self.wrr_scheduler.add(("job3", 1))

        items = ["job1", "job2", "job3"]
        scheduled_items = []

        for item in self.wrr_scheduler:
            scheduled_items.append(item)
            self.wrr_scheduler.remove(item)

        self.assertEqual(3, len(scheduled_items))
        self.assertEqual(items, scheduled_items)

if __name__ == "__main__":
    unittest.main()
