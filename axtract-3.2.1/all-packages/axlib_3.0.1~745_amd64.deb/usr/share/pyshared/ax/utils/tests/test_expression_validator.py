import unittest2
from ax.utils.expression_validator import AndOrEvaluator
from ax.utils.expression_validator import LazyAndOrEvaluator

import itertools
import time

class TestAndOrEvaluator(unittest2.TestCase):
    def test_no_operators(self):
        self.assertRaisesRegexp(
                Exception, "code senseless",
                AndOrEvaluator, [])

    def test_single_and(self):
        evaluator = AndOrEvaluator(['and'])
        self.assertEqual(True, evaluator([True, True]))

    def test_lazy_class_call(self):
        evaluator = AndOrEvaluator(['and'])
        class Foo(object):
            def __nonzero__(self):
                return True

        self.assertEqual(True, evaluator([Foo(), Foo()]))

    def test_lot_of_combinations(self):
        for repeat in range(1, 5):
            for operators in itertools.product(('and', 'or'), repeat=repeat):
                evaluator = AndOrEvaluator(operators)

                for values in itertools.product((True, False), repeat=repeat+1):
                    ref_str = self._build_ref(operators, values)
                    ret = evaluator(values)
                    self.assertEqual(eval(ref_str), ret, ref_str)

    def _build_ref(self, operators, values):
        operators = ('',) + operators + ('',)
        return ' %s '.join(operators) % values

    def test_benchit(self):
        # this class shoudl be faster then doing eval all the time
        eval_string = "%s and %s or %s "
        start = time.time()
        for _ in range(10**5):
            eval(eval_string % (True, False, True))
        eval_time = time.time() - start

        evaluator = AndOrEvaluator(['and', 'or'])
        start = time.time()
        for _ in range(10**5):
            evaluator((True, False, True))
        function_time = time.time() - start

        self.assertGreater(eval_time, function_time)

class _LazyTestFun(object):
    def __init__(self, to_return):
        self.to_return = to_return
    def __call__(self, arg):
        return self.to_return

class TestLazyAndOrEvaluator(unittest2.TestCase):
    def test_no_operator(self):
        to_call = lambda args: 'slayer'
        evaluator = LazyAndOrEvaluator([], [to_call])
        evaluator(None)

    def test_single_and(self):
        to_call = lambda args: True
        evaluator = LazyAndOrEvaluator(['and'], [to_call, to_call])
        self.assertEqual(True, evaluator(None))

    def test_lot_of_combinations(self):
        for repeat in range(1, 8):
            for operators in itertools.product(('and', 'or'), repeat=repeat):
                for values in itertools.product((True, False), repeat=repeat+1):
                    functions = [_LazyTestFun(ret) for ret in values]
                    evaluator = LazyAndOrEvaluator(operators, functions)
                    ref_str = self._build_ref(operators, values)
                    ret = evaluator(None)
                    self.assertEqual(eval(ref_str), ret, ref_str)

    def _build_ref(self, operators, values):
        operators = ('',) + operators + ('',)
        return ' %s '.join(operators) % values

    def test_benchit(self):
        # this class shoudl be faster then doing eval all the time
        eval_string = "%s and %s or %s "
        start = time.time()
        for _ in range(10**5):
            eval(eval_string % (True, False, True))
        eval_time = time.time() - start

        functions = [
            _LazyTestFun(True),
            _LazyTestFun(False),
            _LazyTestFun(True)
        ]

        evaluator = LazyAndOrEvaluator(['and', 'or'], functions)
        start = time.time()
        for _ in range(10**5):
            evaluator(None)
        function_time = time.time() - start

        self.assertGreater(eval_time, function_time)
