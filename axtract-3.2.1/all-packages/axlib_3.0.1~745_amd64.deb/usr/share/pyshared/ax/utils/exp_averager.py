#!/usr/bin/python -tt
""" Calculate Exponential Moving Averages of Load and Performance.

The basic algorithm used here is the same as used by the Linux kernel to
calculate the system's load average. It was extended, though, to allow for
different time-intervals between gathering the samples.
The smoothing_intervals that Linux uses for its load averages are 1 minute,
5 minutes, and 15 minutes, just to give you a feel for the numbers.

Read
http://en.wikipedia.org/wiki/Exponential_Moving_Average#Exponential_moving_average
for the mathematical background. For code examples, check "Linux Load Average
REVEALED" at
http://www.perfdynamics.com/CMG/CMGslides4up.pdf
"""
from time import time, sleep
from math import exp

class Averager(object):
    """Base class for LoadAverager/PerformanceAverager. Not usable alone"""
    def __init__(self, smoothing_interval=10.0):
        self.smoothing_interval = float(smoothing_interval)
        self.average = 0.0
        self._last_time = time()

    def get_average(self):
        """Return the current average"""
        # In order to get self.average recalculated, we add a sample of 0.
        # This does not affect the average that is calculated overall!
        self.add_sample(0)
        return self.average

class LoadAverager(Averager):
    """Calculate the average load.

    'Load' in a Python context could be the length of a job-queue, similar to
    the Linux kernel which defines the load as number of runnable processes that
    are waiting to be executed.
    """
    def add_sample(self, load):
        """Inform this object about the current load."""
        now = time()
        delta_t = now - self._last_time
        self._last_time = now
        # If time jumped backwards, we better ignore this sample
        if delta_t <= 0:
            return

        try:
            tmp = 1.0 / exp(delta_t / self.smoothing_interval)
        except OverflowError:
            # This happens if delta_t is large or interval is short, so that
            # e**(large /small) is to big for a float.
            tmp = 0.0 


        self.average *= tmp
        self.average += load * (1 - tmp)


class PerformanceAverager(Averager):
    """Calculate average performance

    This is very similar to the LoadAverager. But additionally, this class
    converts the jobs that were executed (=easy to measure for you) into
    a jobs-per-second number (=requires extra state and computations).
    """
    def add_sample(self, num_items_done):
        """Inform the object about work performed since last call.

        num_items_done is the amount of 'items' (whatever that is) that were
        processed since the last time you called this method. This is
        internally converted into items/second, so you don't have to bother
        with time-keeping.
        """
        now = time()
        delta_t = now - self._last_time
        self._last_time = now
        # If time jumped backwards, we better ignore this sample
        if delta_t <= 0:
            return
        performance = num_items_done / delta_t

        try:
            tmp = 1.0 / exp(delta_t / self.smoothing_interval)
        except OverflowError:
            # This happens if delta_t is large or interval is short, so that
            # e**(large /small) is to big for a float.
            tmp = 0.0

        self.average *= tmp
        self.average += performance * (1 - tmp)


def demonstrate_load_averager():
    print("\nLoad averager example")
    print("smooth-interval: 1.0\treporting load=10 every 0.1 seconds")
    # Very short smoothing interval, makes the averager very sensitive to
    # quick changes.
    averager = LoadAverager(smoothing_interval=1.0)

    for i in range(20):
        averager.add_sample(10)
        print("\taverage:", averager.get_average())
        sleep(0.1)

    print("Waiting for five(!!) times the smoothing interval. Old data is ")
    print("basically worthless.")
    sleep(5)
    print("\n\tAfter a long wait, we have average:", averager.get_average())

def demonstrate_performance_averager():
    print("\nPerformance averager example")
    print("smooth-interval: 1.0\tadding 10 items every 0.1 seconds")
    # Very short smoothing interval, makes the averager very sensitive to
    # quick changes.
    averager = PerformanceAverager(smoothing_interval=1.0)

    for i in range(20):
        # 10 items done every 0.1 seconds -> performance is 100 per second
        averager.add_sample(10)
        print("\taverage:", averager.get_average())
        sleep(0.1)

    print("Waiting for five(!!) times the smoothing interval. Old data is ")
    print("basically worthless. Performance is now 0 item in the last 5 ")
    print("seconds -> overall it is close to zero.")
    sleep(5)
    print("\n\tAfter a long wait, we have average:", averager.get_average())

def compare_intervals():
    print("\nComparing behavior when different measurement intervals are used")

    averager = LoadAverager(smoothing_interval=1)
    for i in range(10):
        sleep(0.1)
        averager.add_sample(5)
    print("\tAverage after adding 10 samples every 0.1 seconds:", averager.get_average())

    averager = LoadAverager(smoothing_interval=1)
    for i in range(5):
        sleep(0.2)
        averager.add_sample(5)
    print("\tAverage after adding 5 samples every 0.2 seconds: ", averager.get_average())

    print("\nThe above numbers should be almost identical. Some jitter always")
    print("exists due to OS scheduler, Python interpreter taking some time etc.")

if __name__ == "__main__":
    demonstrate_load_averager()
    demonstrate_performance_averager()
    compare_intervals()


