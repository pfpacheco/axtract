import pymongo
import pymongo.errors


def build_call_op_with_reconnect(*args, **kwargs):
    """This function creates a new function to wrap calls to pymongo.

    It detects the different exceptions an does a single retry for the ones
    where it makes sense.

    Since pymongo-3.0 they following this specififiction:
    https://github.com/mongodb/specifications/blob/master/source/server-selection/server-selection.rst

    The important bit here is: The 'wait 30 seconds for a new primary' happens
    inside pymongo.
    """

    def call_op_with_reconnect(op, *args, **kwargs):
        try:
            return op(*args, **kwargs)
        except pymongo.errors.NotMasterError:
            # The server we had the socket to is not primary anymore.
            # Do the operation again and let pymongo search for a new primary.
            pass

        except pymongo.errors.NetworkTimeout:
            # Timeout means that the connection blocked already for a some time.
            # Not sure what a retry should help.
            raise

        except pymongo.errors.ServerSelectionTimeoutError:
            # pymongo was not able to find a fitting server within
            # serverSelectionTimeoutMS (usually 30 seconds).
            # Retry would not help.
            raise

        except pymongo.errors.AutoReconnect:
            # This is a generic, 'error on the current socket'.
            # Retry is very likely to help.
            # Keep in mind all the other erros also inhert from AutoReconnect.
            # => the 'except AutoReconnect' must come at the end.
            pass

        # Let's do the retry. This works nicely, because the 'server-selection'
        # algorithm starts again AND considers the previous error.
        return op(*args, **kwargs)

    return call_op_with_reconnect


def build_yield_docs_with_reconnect(*args, **kwargs):
    """This function creates a new one which wraps 'find' calls to pymongo.

    The new function returns a *generator* of mongo-documents.

    This is needed, because pymongo returns a *Cursor* on a find, not connecting
    to mongodb at all. => On a find the traditional 'call_op_with_reconnect'
    does not work. This first hit to mongo is done, as soon as the first element
    is requested from the cursor.

    This function 'peeks' now into the cursors for the first document.
    This 'peek' triggers now a AutoReconnect exception, if the primary has
    changed. In such case the find is rexecuted until the new primary is found
    or the timeout has happened.

    IMPORTANT: It is impossible handle a 'failover to new primary' if the cursor
    is already exhausted a bit. It is impossible to connect to the new primary
    and continue the stream of documents exactly at the same point as on the
    old primary.
    """
    def yield_docs_with_reconnect(op, *args, **kwargs):
        # This operation does not raise a AutoReconnect.
        # It just creates a cursor object with no mongo interaction at all.
        cursor = op(*args, **kwargs)

        # See 'call_op_with_reconnect'for explanation of
        # the different error cases.
        try:
            # Get the first document from the cursor. This connects to mongo.
            yield next(cursor)
        except pymongo.errors.NetworkTimeout:
            raise
        except pymongo.errors.ServerSelectionTimeoutError:
            raise
        except (pymongo.errors.NotMasterError, pymongo.errors.AutoReconnect):
            cursor = op(*args, **kwargs)

        # Iterate over the remaining cursor.
        for doc in cursor:
            yield doc

    return yield_docs_with_reconnect
