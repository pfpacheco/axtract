"""Module to provide ObjectPool classes with varying degrees of sophistication

"""
import ax.utils.six.moves.queue as Queue

def object_pool_factory(
        obj_factory=None, obj_class=None,
        obj_args=[], obj_kwargs={},
        obj_create_rate=None, obj_create_burst=1,
        obj_giveout_rate=None, obj_giveout_burst=1,
        poolsize=None, threadsafe=True,
        obj_giveout_policy='fifo',
        with_stats=False,
        *args, **kwargs
        ):
    """Return an ObjectPool instance for the given requirements

    Define how the pool should produce its instances:
    obj_factory: A callable that produces the desired instances.
    obj_class: A class to instantiate.
    Obviously, only one may be provided.
    obj_args/obj_kwargs: The *args and **kwargs that are passed to the
        provided factory or the class when a new object is needed.
    obj_create_rate/burst: Rate limits for creating objects, used as
        parameters for a TokenBucket. rate="None" specifies no limit.
    obj_giveout_rate/burst: Rate limits for giving out objects, used as
        parameters for a TokenBucket. rate="None" specifies no limit. Note
        that a newly created object is subject to both obj_create_* limits
        AND obj_giveout_* limits.
    poolsize: How many objects the pool may contain. "None" means no limit.
    threadsafe: True if the pool must be threadsafe, False if you don't care.
    obj_giveout_policy: fifo and lifo supported.
    with_stats: If True, the pool will provide stats about total objects
        created and total objects currently given out.
    """
    if args or kwargs:
        raise ValueError("args/kwargs")
    if with_stats:
        # The only one that provides stats
        pool_class = BoundedStatsObjectPool
        if poolsize is None:
            raise ValueError("If you want ObjectPool statistics, you need to "
                    "provide a poolsize")
    else:
        if poolsize is None:
            pool_class = ObjectPool
        else:
            pool_class = BoundedObjectPool
    pool = pool_class(
            obj_factory=obj_factory, obj_class=obj_class,
            obj_args=obj_args, obj_kwargs=obj_kwargs,
            poolsize=poolsize, obj_giveout_policy = obj_giveout_policy)

    # If neither ratelimits nor threadsafety are wanted, we are done.
    if obj_create_rate is None and obj_giveout_rate is None and not threadsafe:
        return pool

    if threadsafe and with_stats:
        # Doing statistics needs to be protected by a lock
        from ax.utils.thread_proxy import ThreadSafeProx
        ThreadSafeProx(pool)

    # Ratelimits are implemented by manually applying the @ratelimit decorator.
    from ax.utils import tokenbucket
    # If $with_stats is True, then everything is already wrapped safely.
    if threadsafe and not with_stats:
        tb_class = tokenbucket.ThreadsafeTokenbucket
    else:
        tb_class = tokenbucket.Tokenbucket

    if obj_create_rate is not None:
        pool._create_object = tokenbucket.ratelimit(
                obj_create_rate, burst=obj_create_burst,
                policy="wait", bucket_class=tb_class, prefill=1)(
                        pool._create_object)
    if obj_giveout_rate is not None:
        pool.get_object = tokenbucket.ratelimit(
                obj_giveout_rate, burst=obj_giveout_burst,
                policy="wait", bucket_class=tb_class, prefill=1)(
                        pool.get_object)
    return pool

class ObjectPool(object):
    """Most simple object pool"""
    def __init__(self, obj_factory=None, obj_class=None, obj_args=[],
            obj_kwargs={}, obj_giveout_policy='fifo', *args, **kwargs):
        """Tell the ObjectPool what it should contain.

        How to get new object is defined by
        obj_factory: A callable that produces the desired instances.
        obj_class: A class to instantiate.
        Obviously, only one may be provided

        obj_args/obj_kwargs: The *args and **kwargs that are passed to the
            provided factory or the class when a new object is needed.
        """
        if obj_factory is None and obj_class is None:
            raise ValueError("You have not provided a obj_factory or obj_class")
        if obj_factory is not None and obj_class is not None:
            raise ValueError("You have provided both obj_factory AND obj_class")
        if obj_giveout_policy not in ('lifo', 'fifo'):
            raise NotImplemented("obj_giveout_policy %s not implemented" %
                    obj_giveout_policy)

        self.obj_factory = obj_factory
        self.obj_class = obj_class
        self.args = obj_args
        self.kwargs = obj_kwargs
        self.obj_giveout_policy = obj_giveout_policy
        self._pool = None
        self._create_pool()

    def _create_pool(self):
        if self.obj_giveout_policy == 'fifo':
            self._pool = Queue.Queue()
        elif self.obj_giveout_policy == 'lifo':
            try:
                self._pool = Queue.LifoQueue()
            except Exception:
                raise Exception("obj_giveout_policy 'lifo' not "
                        "supported in this python version")

    def _create_object(self):
        if self.obj_factory:
            obj = self.obj_factory(*self.args, **self.kwargs)
        elif self.obj_class:
            obj = self.obj_class(*self.args, **self.kwargs)
        return obj

    def get_object(self):
        """Get object from pool, newly created if needed."""
        try:
            return self._pool.get(False)
        except Queue.Empty:
            return self._create_object()

    def put_object(self, obj):
        """Put object back into the pool."""
        self._pool.put(obj)


class BoundedObjectPool(ObjectPool):
    """An ObjectPool which limits the number of objects it contains"""
    def __init__(self, obj_factory=None, obj_class=None, obj_args=[],
            obj_kwargs={}, obj_giveout_policy='fifo', poolsize=1,
            *args, **kwargs):
        poolsize = int(poolsize)
        if poolsize < 1:
            raise ValueError(
                    "Poolsize must be > 0, but '%s' was given" % poolsize)
        self.poolsize = poolsize

        super(BoundedObjectPool, self).__init__(
                obj_factory=obj_factory, obj_class=obj_class,
                obj_args=obj_args, obj_kwargs=obj_kwargs,
                obj_giveout_policy=obj_giveout_policy,
                *args, **kwargs)

    def _create_pool(self):
        """Create pool, fill it with placeholders for real objects"""
        if self.obj_giveout_policy == 'fifo':
            self._pool = Queue.Queue(self.poolsize)
        elif self.obj_giveout_policy == 'lifo':
            try:
                self._pool = Queue.LifoQueue(self.poolsize)
            except Exception:
                raise Exception("obj_giveout_policy 'lifo' not "
                        "supported in this python version")

        for count in range(self.poolsize):
            self._pool.put(None)

    # _create_object() needs no limitations, because we only call it after
    # taking a dummy "None" from self._pool.

    def get_object(self):
        """Get object from pool, newly created if needed (and allowed).

        Will block until an object is available
        """
        # blocking if empty:
        obj = self._pool.get()
        if obj is None:
            try:
                obj = self._create_object()
            except Exception:
                # Put the dummy back into the pool. Otherwise, less objects
                # than configured will be created.
                self._pool.put(None)
                raise
        return obj



class BoundedStatsObjectPool(BoundedObjectPool):
    """An BoundedPool with statistics about its contents"""
    def __init__(self, obj_factory=None, obj_class=None, obj_args=[],
            obj_kwargs={}, obj_giveout_policy='fifo', poolsize=1,
            *args, **kwargs):

        # How many objects were created in total. Read only!
        self.create_count = 0
        # How many objects are currently given out. Read only!
        self.given_out_count = 0

        super(BoundedStatsObjectPool, self).__init__(
                obj_factory=obj_factory, obj_class=obj_class,
                obj_args=obj_args, obj_kwargs=obj_kwargs,
                obj_giveout_policy=obj_giveout_policy,
                poolsize=poolsize,
                *args, **kwargs)

    def _create_object(self):
        obj = super(BoundedStatsObjectPool, self)._create_object()
        self.create_count += 1
        return obj

    def get_object(self):
        """Get object from pool, newly created if needed (and allowed).

        Will block until an object is available
        """
        obj = super(BoundedStatsObjectPool, self).get_object()
        self.given_out_count += 1
        return obj

    def put_object(self, obj):
        """Put object back into the pool."""
        super(BoundedStatsObjectPool, self).put_object(obj)
        self.given_out_count -= 1



