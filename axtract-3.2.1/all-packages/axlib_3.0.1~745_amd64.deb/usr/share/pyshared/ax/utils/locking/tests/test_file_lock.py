#!/usr/bin/python -tt
import os
import os.path
import shutil
import tempfile
import unittest2

from ax.utils.locking.file_lock import MachineWideFileLock

class MachineWideFileLockTests(unittest2.TestCase):
    def setUp(self):
        """Set up temporary directory for each testcase (=can run parallel)"""
        self.lock_dir = tempfile.mkdtemp()
        self.lock_file = os.path.join(self.lock_dir, "lockfile")

    def tearDown(self):
        shutil.rmtree(self.lock_dir)

    def test_single_process(self):
        """Most basic tests, running single process"""
        locker = MachineWideFileLock(self.lock_file, file_txt=b"42")

        retval = locker.lock()
        # operation must succeed.
        self.assertEqual(retval, None)
        # file must exist
        self.assertTrue(os.path.exists(self.lock_file))
        # file must contain "42"
        with open(self.lock_file) as lock_file_obj:
            self.assertEqual("42", lock_file_obj.read())

        locker.unlock()
        # File must be gone
        self.assertFalse(os.path.exists(self.lock_file))

    def test_with_syntax(self):
        """The "with" syntax must work"""
        locker = MachineWideFileLock(self.lock_file, file_txt=b"42")
        with locker:
            # file must exist
            self.assertTrue(os.path.exists(self.lock_file))
            # file must contain "42"
            with open(self.lock_file) as lock_file_obj:
                self.assertEqual("42", lock_file_obj.read())

        # File must be gone
        self.assertFalse(os.path.exists(self.lock_file))

    def test_relative_path_chdir(self):
        """Check unlock after a chdir(), when lockfile has relative path"""
        old_cwd = os.getcwd()
        os.chdir(self.lock_dir)

        try:
            locker = MachineWideFileLock("lockfile_with_relative_path")
            locker.lock()
            self.assertTrue(os.path.exists("lockfile_with_relative_path"))

            os.chdir("/")
            locker.unlock()
            # lockfile must be gone
            self.assertFalse(os.path.exists(
                os.path.join(self.lock_dir, "lockfile_with_relative_path")))

        finally:
            #restore previous CWD
            os.chdir(old_cwd)

    def test_maxwait_with_already_taken_lock(self):
        fn = os.path.join(self.lock_dir, 'l1')

        lock1 = MachineWideFileLock(fn)
        lock2 = MachineWideFileLock(fn, maxwait=1)

        with lock1 as l1:
            self.assertEqual(None,  l1)
            with lock2 as l2:
                self.assertEqual(-1, l2)
            self.assertTrue(os.path.exists(fn))



if __name__ == "__main__":
    unittest2.main()

