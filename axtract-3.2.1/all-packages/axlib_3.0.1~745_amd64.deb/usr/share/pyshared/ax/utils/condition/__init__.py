import re
from textwrap              import dedent
from sqlalchemy            import and_, or_, not_
from ax.utils.lru          import ExpiringLRUCache
from ax.utils.locking      import proc_lock
from ax.utils.func.filters import is_str, is_list, is_dict
from ax.utils.func.filters import is_starting_with, is_ending_with
from ax.utils.ax_tree      import AXTree
from ax.utils.six          import string_types
import operator as op


# ------------------------------------------------------------------- Operators

OPERATOR = {
     '='         : op.eq
   , '<'         : op.lt
   , '>'         : op.gt
   , '<='        : op.le
   , '>='        : op.ge
   , '!='        : op.ne
   , 'or'        : op.ior
   , 'and'       : op.iand
   , 'contains'  : op.contains
   , 'is'        : op.is_
   , 'is_not'    : op.is_not
   , 'starts'    : is_starting_with
   , 'ends'      : is_ending_with
   # a=context[key], b=value in evaluate_leaf:
   , 'in'        : lambda a, b: op.contains(b, a)
   , 'intersects': lambda a, b: bool(set(b).intersection(set(a)))
     # like means that there will be a re.match.
     # Only use with sanitized input using the method below
   , 'like'      : lambda a, b: bool(re.compile(sanitize_input(b)).match(a))
}

CONCAT_OPS = 'and', 'or', 'and not', 'or not'
NEGATEABLE = 'contains', 'in', 'starts', 'ends', 'like', 'intersects'


MONGO_OPERATORS = {
     '='         : '$eq'
   , '<'         : '$lt'
   , '>'         : '$gt'
   , '<='        : '$lte'
   , '>='        : '$gte'
   , '!='        : '$ne'
   , 'or'        : '$or'
   , 'and'       : '$and'
}

AXSEARCH_OPERATORS = {
     '='         : 'eq'
   , '<'         : 'lt'
   , '>'         : 'gt'
   , '<='        : 'lte'
   , '>='        : 'gte'
   , '!='        : 'eq'
   , 'or'        : 'or'
   , 'and'       : 'and'
}

# ------------------------------------------------------------------- Negations

# expression *concat* ops we negate by *adding* 'not':
for cop in 'and', 'or':
    opf = OPERATOR[cop] # opf: operator function
    OPERATOR['%s not' % cop] = lambda a, b, opf=opf: opf(a, not b)

# expression ops we negate by *prefixing* with 'not':
for nop in NEGATEABLE:
    opf = OPERATOR[nop]
    OPERATOR['not %s' % nop] = lambda a, b, opf=opf: not opf(a, b)


# ------------------------------------------------------------------- Reversion

# all negatables are also reversable, e.g. "rev starts", "rev not starts"
# e.g. contains = rev in
for nop in NEGATEABLE:
    for pre in 'not ', '':
        n = pre + nop
        opf = OPERATOR[n]
        OPERATOR['rev %s' % n] = lambda a, b, opf=opf: opf(b, a)


# ---------------------------------------------------------- Expression Parsing

def _remove_extra_brackets(item):
    if len(item) == 1:
        return _remove_extra_brackets(item[0])
    else:
        return item

def _is_leaf(item):
    if len(item) == 1:
        return _is_leaf(item[0])
    if is_str(item[1]) and not item[1] in CONCAT_OPS:
        return True
    else:
        return False
#def _is_leaf(e):
#    return x_is_leaf(e)


def sanitize_input(uinput, format_="re"):
    """
    This method is intented to be used by everyone who is generating
    conditions that have the like operator.

    It converts the value given to a restricted regexp value. It can easily
    be extended with more supported characters. To extend, modify the chars and
    subs dictionaries in below. If you don't want to use the like operaton in
    your conditions, just ignore this method. If you do then make sure that the
    value given to the like operator is passed through this method """
    # the chars dictionary stores some magic strings that are helpers to replace
    # the characters given as input
    chars = {
        '\\': '##MAGICREPLACEMENT#BS##',
        '*': '##MAGICREPLACEMENT#ST##',
        '%': '##MAGICREPLACEMENT#PERC##',
        '_': '##MAGICREPLACEMENT#US##'
        # ? and * are commented out even if they would work because axgroups
        # do not support them
        #'?': '##MAGICREPLACEMENT#QM##',
        #'+': '##MAGICREPLACEMENT#PL##',
    }
    # this is a mapping with how the various escaped characters should be
    # replaced
    if format_ == 're':
        star = ".*"
    elif format_ == 'mysql':
        star = "%"
    elif format_ == 'engine':
        star = "%"
    elif format_ == 'reverse_engine':
        star = "%%"
    subs = {
        r"([^\\]|^)\*": r"\1%s" % star,
        #r"([^\\]|^)\?": r"\1.?",
        #r"([^\\]|^)\+": r"\1.+",
    }

    # first replace all the regexp characters we want to support with their
    # magic counterparts
    for char, repl in chars.items():
        uinput = uinput.replace(char, repl)

    # then we escape the input
    if format_ == 're':
        uinput = re.escape(uinput)

    # on the escaped input we replace back the magic string with the
    # original characters
    for char, repl in chars.items():
        uinput = uinput.replace(re.escape(repl), char)

    # then we need to replace the escaped characters with the real regexp
    # characters
    for pattern, sub in subs.items():
        uinput = r"%s" % re.sub(pattern, sub, uinput)

    # add the start and end of string ctharacters
    if format_ == "re":
        uinput = r"^%s$" % uinput

    if format_ == "mysql":
        pat = '%s%s' % (chars['\\'], chars['*'])
        uinput = uinput.replace(pat, '*')
        uinput = uinput.replace(chars['*'], '%')
        uinput = uinput.replace(chars['\\'], '\\')
        uinput = uinput.replace(chars['_'], '\\_')
        uinput = uinput.replace(chars['%'], '\%')

    if format_ == "engine":
        pat = '%s%s' % (chars['\\'], chars['*'])
        uinput = uinput.replace(pat, '*')
        uinput = uinput.replace(chars['*'], '%%')
        uinput = uinput.replace(chars['\\'], '\\')
        uinput = uinput.replace(chars['%'], '\%')
        uinput = uinput.replace(chars['_'], '\\_')

    if format_ == 'reverse_engine':
        pat_us = '%s%s' % (chars['\\'], chars['_'])
        pat_perc = '%s%s' % (chars['\\'], chars['%'])
        pat = '%s%s' % (chars['%'], chars['%'])
        uinput = uinput.replace(pat_perc, '%')
        uinput = uinput.replace(pat_us, '_')
        uinput = uinput.replace(pat, '*')
        uinput = uinput.replace(chars['*'], '\\*')
        uinput = uinput.replace(chars['\\'], '\\')
        uinput = uinput.replace(chars['%'], '%')


    return uinput


def supported_operators():
    return OPERATOR.keys()


def _evaluate_leaf(leaf, context, cond_vars):
    left, op, right = leaf
    if cond_vars is not None and is_str(right) and '%(' in right:
        right = right % cond_vars

    OP = OPERATOR.get(op, None)
    if OP is None:
        raise Exception("Operator '%s' not supported" % op)

    if isinstance(left, bool):
        res = OP(left, right)
    else:
        key, value = left, right
        # This is a special case.
        # if the context is a list, and the context has an equal to a value then
        # we look for the value being in the list
        # Example: context {'a': ['1', 2']} and conditions ['a', '=', '1']
        # the above will be evaluated to True can '1' is in the list
        try:
            context_value = context[key]
        except KeyError:
            return False
        if isinstance(context_value, list) and not isinstance(value, list):
            if op == "=":
                OP = OPERATOR.get('contains')
            elif op == "!=":
                OP = OPERATOR.get('not contains')
        res = OP(context_value, value)
    return res

def _evaluate_existence(leaf, params_found):
    left, _, _ = leaf
    if not isinstance(left, str):
        return leaf
    if left not in params_found:
        params_found.append(left)

def traverse_and_apply(partial, condition, method, *args):
    """
    a partial traverse_and_apply does not care if the concat ops
    are and or or. It treats all as or
    """
    if len(condition) == 0:
        # an empty condition always matches
        return True
    if len(condition) == 1 and isinstance(condition[0], list):
        return traverse_and_apply(partial, condition[0], method, *args)
    if _is_leaf(condition):
        condition = _remove_extra_brackets(condition)
        return method(condition, *args)

    if len(condition) > 3:
        left = traverse_and_apply(partial, condition[0], method, *args)
        op = condition[1]
        right = condition[2:]
    else:
        left = condition[0]
        op = condition[1]
        right = condition[2]
    if not is_list(left):
        left_result = left
    elif _is_leaf(left):
        left = _remove_extra_brackets(left)
        left_result = method(left, *args)
    else:
        left_result = traverse_and_apply(partial, left, method, *args)

    if op in CONCAT_OPS:
        if not is_list(right):
            right_result = right
        elif _is_leaf(right):
            right = _remove_extra_brackets(right)
            right_result = method(right, *args)
        else:
            right_result = traverse_and_apply(partial, right, method, *args)
    else:
        right_result = method(right, *args)

    if partial:
        is_true = True in (left_result, right_result)
        if 'not' in op:
            return not is_true
        else:
            return is_true
    else:
        # if the method returns None, it means that the condition should be
        # removed from the processing this is used when we need to get rid of
        # specific subconditions eg transient parameters
        if left_result is None and right_result is None:
            return None
        elif left_result is None:
            return method([right_result], *args)
        elif right_result is None:
            return method([left_result], *args)
        else:
            return method([left_result, op, right_result], *args)

def evaluate(condition, context, cond_vars=None):
    '''
    # The Main Function

    Evaluation of a set of facts (context) against a condition tree, returning
    a boolean

    # Params
    - condition(list): concatenated, nested 'leaf' conditions, i.e. functions
                       which evaluate to a bool
    - context(dict)  :
    '''
    res = traverse_and_apply(False, condition, _evaluate_leaf, context, cond_vars)
    return res

def evaluate_partial(condition, context, cond_vars=None):
    """
    evaluates to True if all properties inside the context match the
    corresponding conditions.

    ATTENTION: Not all the leafs in the condition need to match. It is enough
    if only the leafs for the parameters, that exist in the context, match

    example1:
        condition [['a', '=', 1], 'and', ['b', '=', 2]]
        context { "a": 1 }
        returns True
    example2:
        condition [['a', '=', 1], 'and', ['b', '=', 2]]
        context { "c": 4 }
        returns False
    example3:
        condition [[['a', '=', 1], 'and', ['b', '=', 2]], 'or', ['a', '=', 5]]
        context { "a", "=", 4 }
        returns False
    """
    res = traverse_and_apply(True, condition, _evaluate_leaf, context,
            cond_vars)
    return res


def parameters_exist(condition, params):
    """
    This method checks if all parameters in the given list are part of of the
    condition given
    """
    params_found = []
    traverse_and_apply(False, condition, _evaluate_existence, params_found)
    return len(params) == len(frozenset(params).intersection(params_found))



# ----------------------------------------------------------- Listable Adaption
def _to_sqlalchemy(leaf, object_):
    left, op, right = leaf
    OP = OPERATOR.get(op, None)
    if OP is None:
        raise Exception("Operator '%s' not supported" % op)

    if op == 'like':
        right = sanitize_input(right, "engine")
        res = getattr(object_[left], 'like')(right)
    elif op == 'not like':
        right = sanitize_input(right, "engine")
        res = not_(getattr(object_[left], 'like')(right))
    elif op == 'intersects':
        raise NotImplementedError("MySQL does not support intersects")
    elif op == 'in':
        res = getattr(object_[left], 'in_')(right)
    elif op == 'not in':
        res = not_(getattr(object_[left], 'in_')(right))
    elif op == '=':
        res = object_[left] == right
    elif op == 'or':
        res = or_(left, right)
    elif op == 'and':
        res = and_(left, right)
    else:
        res = OP(object_[left], right)
    return res


def to_sqlalchemy_filter(condition, object_):
    return traverse_and_apply(False, condition, _to_sqlalchemy, object_)

def _to_where(leaf, values, column_name_check):
    left, op, right = leaf
    OP = OPERATOR.get(op, None)
    if OP is None:
        raise Exception("Operator '%s' not supported" % op)

    if op in ('like', 'not like'):
        right = sanitize_input(right, "engine")
    elif op == 'starts':
        op = "like"
        right = "%s%%" % right
    elif op == 'ends':
        op = "like"
        right = "%%%s" % right
    elif op in ('contains', 'intersects', 'is', 'is_not'):
        raise NotImplementedError("MySQL does not support %s" % op)
    if op in CONCAT_OPS:
        expression = "(%s %s %s) " % (left, op, right)
    else:
        if not column_name_check.match(left):
            raise Exception("Invalid column name '%s'" % left)

        expression = "(%s %s %%s) " % (left, op)
        values.append(right)
    return expression

def to_where_clause(condition, tuple_=True):
    """
    the restriction using this method is that the condition names should be
    alphanumeric or _
    This way we can avoid sql injections by assuming that no column names
    exist with non alphanumeric or _ characters
    """
    where = ""
    values = []
    # need to check if the column name is alphanumeric or _ to avoid
    # sql injection
    column_name_check = re.compile(r"^[a-zA-Z0-9_]*$")
    if condition is not None and condition != []:
        where = traverse_and_apply(False, condition,
                _to_where, values, column_name_check)
    if where != "":
        where = "WHERE %s" % where
    if tuple_:
        return where, tuple(values)
    else:
        return where % tuple(values)

def _unknown_parameters(leaf, context, unknown_params):
    left, op, right = leaf
    if op in CONCAT_OPS:
        return

    if left not in context and left not in unknown_params:
        unknown_params.append(left)

def get_all_unknown_parameters(condition, context):
    unknown_params = []
    if not len(condition):
        return []
    traverse_and_apply(False, condition, _unknown_parameters,
            context, unknown_params)
    return unknown_params

def _to_mongo_aggregation(leaf):
    left, op, right = leaf
    OP = MONGO_OPERATORS.get(op, None)
    if OP is None:
        raise Exception("Operator '%s' not supported" % op)
    if op not in ('and', 'or'):
        left = "$%s" % left
    return {
        OP: [left, right]
    }

def _to_mongo_filter(leaf):
    left, op, right = leaf
    OP = MONGO_OPERATORS.get(op, None)
    if OP is None:
        raise Exception("Operator '%s' not supported" % op)
    if op in ('and', 'or'):
        return {
            OP: [left, right]
        }
    else:
        return {
            left: { OP: right }
        }

def to_mongo_aggregation(condition):
    """
    This is meant to be used directly in the pymongo aggregate
    function as $cond conditions
    It adds the $ needed in the properties name
    """
    return traverse_and_apply(False, condition, _to_mongo_aggregation)

def to_mongo_filter(condition):
    """
    This is meant to be used directly in the pymongo filters on
    find, count queries
    """
    return traverse_and_apply(False, condition, _to_mongo_filter)

def _axgroup_to_python_filter(leaf):
    left, op, right = leaf
    if op == 'like':
        right = sanitize_input(right, 'reverse_engine')
    return [left, op, right]

def axgroup_filter_to_python_filter(condition):
    """
    This method converts a condition from axgroup to python.
    Namely it changes the "like %%" expressions to "like *"
    """
    res = traverse_and_apply(False, condition, _axgroup_to_python_filter)
    return [] if res == True else res

def _to_axsearch_leaf(leaf, count, in_op):
    left, op, right = leaf
    OP = AXSEARCH_OPERATORS.get(op, None)
    if OP in ('and', 'or'):
        raise Exception("Nested conditions are not supported on this converter")
    if OP is None:
        raise Exception("Operator '%s' not supported" % op)

    is_numeric = True
    if isinstance(right, string_types):
        is_numeric = False
    res = (('crits[%s][field]' % count, left),)
    if is_numeric:
        res += (
            ('crits[%s][value][operator]' % count, OP),
            ('crits[%s][value][value]' % count, right)
        )
    else:
        res += (('crits[%s][value]' % count, right),)

    res += (
        ('crits[%s][precondition]' % count, 'is not' if op == '!=' else 'is'),
        ('crits[%s][and_or_or]' % count, in_op)
    )

    return res

def to_axsearch_filter(condition):
    """
    This is meant to be passed in the urlencode function of urllib
    in order to generate the URL for an dynamic AXSearch
    """
    # here we cannot use the traverse_and_apply method because
    # nesting is not supported
    # The given condition needs to be a flat list (the same way
    # that the AXSearch supports it
    count = 0
    res = ()
    if len(condition) == 0:
        # an empty condition always matches
        return ()
    if _is_leaf(condition):
        condition = _remove_extra_brackets(condition)
        return _to_axsearch_leaf(condition, count, 'and')
    i = 1
    for item in condition:
        if item not in ('and', 'or'):
            try:
                next_op = condition[i]
            except IndexError:
                next_op = 'and'
            res += _to_axsearch_leaf(item, count, next_op)
            count += 1
        i += 1


    res += (('search_type', 'crits'),)
    return res

def _remove_leaf(leaf, should_remove):
    if should_remove(leaf):
        return None
    else:
        return _remove_extra_brackets(leaf)

def remove_subcondition(condition, should_remove):
    """
    Provided a condition and a method to check if a leaf should
    be removed from the whole condition, this function returns
    the new condition
    Example (remove all "a"):
    cond = [
        [
            ["b", "=", 1],
            "and",
            ["b", "=", 2]
        ],
        "or",
        [
            ["b", "=", 1],
            "and",
            ["a", "=", 2]
        ],
        "or",
        [
            ["a", "=", 2],
            "and",
            ["b", "=", 2]
        ],
        "or",
        ["a", ">", 6]
    ]

    def is_A(cond):
        if cond[0] == "a":
            return True
        return False

    condition = remove_subcondition(cond, is_A)
    condition becomes
    [
        [
            ['b', '=', 1],
            'and',
            ['b', '=', 2]
        ],
        'or',
        [
            ['b', '=', 1],
            'or',
            ['b', '=', 2]
        ]
    ]
    """
    condition = _remove_extra_brackets(condition)
    if len(condition) == 0:
        return []
    res = traverse_and_apply(False, condition, _remove_leaf, should_remove)
    if res is None:
        return []
    return _remove_extra_brackets(res)


# ----------------------------------------------------------- Convenience funcs

def parse(s, sep='\n', default_op='and'):
    '''
    Multiline string to nested condition array.

    When conditions are to be written manually it is tedious otherwise.
    See tests for usage examples.

    Caution: Currently this handles string only leafs [str, op, str]
    '''
    if sep != '\n':
        s = s.replace(sep, '\n') # we require dedent -> no '\n' values
    #res = _parse_str(s)
    return set_default_operator(_parse_str(s), default_op)

def _parse_str(s):
    sep = '\n'
    while 1: # removing whitespace lines at the beginning. No lstrip possible!
        f, rest = s.split(sep, 1)
        if f.strip():
            break
        s = rest

    s, l = dedent(s).rstrip(), []
    lines = s + sep
    while lines:
        line, lines = lines.split(sep, 1)
        sub = ()
        while line.startswith(' '): # new nesting level
            sub += (line,)
            if not lines:
                break
            line, lines = lines.split(sep, 1)
        if sub:
            l.append(_parse_str(sep.join(sub)))
        if line.startswith(' '):
            continue
        line = line.strip()
        if line in OPERATOR:
            # operator:
            l.append(line)
        else:
            # string only leafs
            l.append(line.split(' ', 2))
    return l


def set_default_operator(cond, op='and'):
    '''
    Filling in a default operator when missing.
    see tests

    Caution: This mutates the condition structure. Wanted normally.
    '''
    if not cond or is_str(cond[0]):
        return
    need, i, needs = False, 0, []
    for i in range(len(cond)):
        el = cond[i]

        if el in CONCAT_OPS:
            need = False
            continue

        if not _is_leaf(el):
            el = _remove_extra_brackets(el)
            set_default_operator(el, op)

        if not need:
            need = True
            continue
        needs.insert(0, i)

    [cond.insert(i, op) for i in needs]
    return cond




# ------------------------------------------------------------ Cached Execution
_cond_caches = {}
_from_d = lambda m, keys: [m[k] for k in keys]

def evaluate_cached( c_name, c_params, condition, context, cond_vars=None,
                     no_cache=False ):
    '''
    # Caching eval result for a set of values.

    Caution:
    This is an expert only function with a lot of risks - memory and
    unexpected results when not handled correctly.

    In the tests it was seen that uncached execution is very fast and not a
    bottleneck in most use cases.

    # Params
    - c_name(str): Name of the cache, should correspond to the cond. structure
    - c_params(array|tuple|True):
        Options:
        * tuple: Directly the values to cache the eval result for (recommended)
        * list:  The keys in context and cond_vars to get values for, then cache
        * True:  Take all vals from both maps. Not recommended - varying vals
                 like timestamps will fill the cache instantly.

    Again: Uncached execution is pretty fast!
    '''
    # client decides to cache only selected item sets, e.g. hotspot API Queries
    if no_cache:
        return evaluate(condition, context, cond_vars)


    for i in 1, 2:
        cache = _cond_caches.get(c_name)
        if cache:
            break
        def make(size, timeout):
            _cond_caches[c_name] = ExpiringLRUCache(size, timeout)
        proc_lock.run_once(make, (10000, 3600), _cond_caches, c_name)

    if c_params == True:
        # use all vals given. Risky (e.g. timestamps will explode the cache)
        c_params = sorted(context.keys())
        vals = _from_d(context, sorted(context.keys()))
        if is_dict(cond_vars):
            vals.extend(_from_d(cond_vars, sorted(cond_vars.keys())))
        vals = tuple(vals)

    elif is_list(c_params):
        # then we interpret them as keys in our context:
        vals = [context[p] if p in context else cond_vars[p] for p in c_params]
        vals = tuple(vals)

    else:
        # the to be cached params directly given, decided by the client:
        vals = c_params

    res = cache.get(vals, '\x01')
    if res != '\x01':
        return res
    res = evaluate(condition, context, cond_vars)
    cache.put(vals, res)
    return res

