import datetime
import unittest
import mock
import calendar

from ax.utils.timespec_parser import convert

posix_now_patch = 'ax.utils.timespec_parser.posix_now'
local_now_patch = 'ax.utils.timespec_parser.local_now'
tuple_as_seconds_patch = 'ax.utils.timespec_parser.tuple_as_seconds'

class TestTimeSpecParser(unittest.TestCase):
    def _check(self, string, ref):
        posix_now = 1400147722.963905
        local_now = datetime.datetime(2014, 5, 15, 11, 55, 41, 954817)
        with mock.patch(tuple_as_seconds_patch, calendar.timegm):
            with mock.patch(posix_now_patch, lambda: posix_now):
                with mock.patch(local_now_patch, lambda: local_now):
                    ret = convert(string)
                    self.assertEqual(ref, ret)

    def test_simple(self):
        self._check("0000000000", 0)
        self._check("12:12 Friday -2w", 1399032720)
        self._check("12:12 Friday", 1400242320)
        self._check("teatime 3/3/2013 + 10d", 1363190400)
        self._check("-30d", 1397555722)
        self._check("+1hour", 1400151322)
        self._check("feb 21 2012", 1329825300)
        self._check("13:40", 1400161200)
        self._check("teatime 3/3/2013 - 10d", 1361462400)
        self._check("now", 1400147722)
        self._check("now-1y+1y", 1400147722)
        self._check("14:40 3/3/2012", 1330785600)
        self._check("17:39 12.12.1986", 534793140)
        self._check("23:12 19730218", 98925120)
