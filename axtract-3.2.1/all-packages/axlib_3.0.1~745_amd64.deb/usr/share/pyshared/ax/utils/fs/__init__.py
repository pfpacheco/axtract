#!/usr/bin/env python
"""
Filesystem Tools
"""
from __future__ import absolute_import, division, print_function

import sys, time, os, io
from ax.utils.formatting.unicode_chars import read_uni_chars

exists = os.path.exists

PY2 = sys.version_info[0] < 3
PY3 = not PY2

if PY2:

    def fd_seek(fd, amount, whence):
        """mapped to the same, but returning the fd, for 2/3 compatible code"""
        fd.seek(amount, whence)
        return fd

    def make_dirs(d):
        dd, d = "", d.split("/")[1:]
        while d:
            dd += "/" + d.pop(0)
            if not os.path.exists(dd):
                os.mkdir(dd)


else:

    def fd_seek(fd, amount, whence=0):
        """fdseek is not so simple anymore when python tries
        to decode everything"""
        fd.buffer.seek(amount, whence)
        return io.TextIOWrapper(
            fd.buffer,
            encoding=fd.encoding,
            errors=fd.errors,
            newline=fd.newlines,
        )

    make_dirs = os.makedirs


def write_file(fn, s, mkdir=False, mkdirs=False):
    """Creates a file with content and directory/ies containing it in one go"""

    try:

        with open(fn, "w") as fd:
            fd.write(s)

    except IOError as ex:
        if not (mkdir or mkdirs):
            raise
        d = os.path.dirname(fn)
        if exists(d):
            raise
        make_dirs(d) if mkdirs else os.mkdir(d)
        write_file(fn, s, mkdir=False, mkdirs=False)


# read stuff from files in one liners, w/o context mgr:


def read_bytes(fn, dflt=None, bytes=-1):
    """
    Returns, if fn is present, bytes in 3 and str in 2
    Else the system exception if dflt is None

    fn the filename.
    """
    return _read(fn, dflt=dflt, how_many=bytes, mode="rb")


def read_file(fn, dflt=None, chars=-1, strip_last_linesep=True):
    """
    Normally you want, when reading just the beginning, text.
    If the file did contain text you'll get uni in 3 and str in 2 but
    that str will decode into text of len chars.

    fn the filename.
    """

    strip = strip_last_linesep
    if not PY2:
        return _strip_ls(_read(fn, dflt, how_many=chars, mode="r"), strip)

    # we are in 2 and the user wants back a str with some max characters -
    # not bytes (i.e. to render into templates.
    try:
        with open(fn) as fd:
            return read_uni_chars(fd, chars)
    except Exception as ex:
        if dflt is not None:
            return dflt
        raise


def _read(fn, dflt=None, how_many=-1, mode="rb"):
    """internal helper"""
    # exception changed from 2 to 3 so we do this instead checking for exists
    # to raise the same exception:
    fd = None
    try:
        try:

            fd = open(fn, mode)
            if mode == "rb":
                return fd.read(how_many)  # bytes in 3
            return read_uni_chars(fd, how_many)

        except Exception as ex:
            if dflt is not None:
                return dflt
            raise
    finally:
        fd.close() if fd else 0


def _strip_ls(s, strip=True):
    # helper: open(<fn>).read() adds a linesep which is not wanted normally
    return s if not strip or not s or not s[-1] == "\n" else s[:-1]
