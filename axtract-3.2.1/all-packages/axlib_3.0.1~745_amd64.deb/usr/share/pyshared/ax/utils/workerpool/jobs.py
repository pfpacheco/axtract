# jobs.py - Generic jobs used with the worker pool
# Copyright (c) 2008 Andrey Petrov
#
# This module is part of workerpool and is released under
# the MIT license: http://www.opensource.org/licenses/mit-license.php

import threading
from .exceptions import TerminationNotice

__all__ = ['Job', 'SuicideJob', 'SimpleJob']


class Job(object):
    "Interface for a Job object."
    def __init__(self):
        pass

    def run(self):
        "The actual task for the job should be implemented here."
        pass


class SuicideJob(Job):
    "A worker receiving this job will commit suicide."
    def run(self, **kw):
        raise TerminationNotice()


class SimpleJob(Job):
    """
    Given a `result` queue, a `method` pointer, and an `args` dictionary or
    list, the method will execute r = method(*args) or r = method(**args),
    depending on args' type, and perform result.put(r).
    """
    def __init__(self, result, method, args=[]):
        self.result = result
        self.method = method
        self.args = args

    def run(self):
        if isinstance(self.args, list) or isinstance(self.args, tuple):
            r = self.method(*self.args)
        elif isinstance(self.args, dict):
            r = self.method(**self.args)
        self._return(r)

    def _return(self, r):
        "Handle return value by appending to the ``self.result`` queue."
        self.result.put(r)

class RendezvousJob(Job):
    def __init__(self, pool, job_to_run, timeout=60):
        ## These variables are needed for the 'Rendevous'
        self._nb_threads = pool.size()

        # _current_count += 1 is not ThreadSafe => Lock
        self._current_count = 0
        self._lock = threading.Lock()

        # As soon as _current_count == _nb_threads the even is set
        self._event = threading.Event()
        self._timeout = timeout

        self._job_to_run = job_to_run
        self.logger = pool.logger

    def run(self):
        with self._lock:
            self._current_count += 1
            if self._current_count == self._nb_threads:
                self._event.set()

        # I know there is a race condition between the next following lines
        # (However it is very very small)
        # TODO: In python2.7 event.wait() returns if the flag is set or not
        self._event.wait(self._timeout)
        if not self._event.is_set():
            msg = "RendezvousJob runs into a timeout. " \
                  "So it seems the other threads of the pool got stuck. " \
                  "Execute the RendezvousJob anyway." \
                  "Current Count(%i) - Expected Count(%i)"
            self.logger.warning(msg, self._current_count, self._nb_threads)

        self._job_to_run.run()
