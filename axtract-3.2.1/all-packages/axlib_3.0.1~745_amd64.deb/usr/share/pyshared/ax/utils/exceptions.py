"""
ax.utils.exceptions
~~~~~~~~~~~~~~~~~~~

This module defines a set of frequently used exceptions.

"""
import simplejson


try:
    from rest_framework.exceptions import APIException
except:
    class APIException(Exception):
        """
        A stub class in case django is absent
        """
        status_code = 500
        default_detail = 'A server error occurred.'
        default_code = 'error'

        def __init__(self, detail=None, code=None):
            super(APIException, self).__init__(detail)
            self.detail = detail if detail else self.default_detail
            self.code = code if code else self.default_code


class AXException(APIException):
    def __init__(self, detail=None, code=None):
        super(AXException, self).__init__(detail)

        def __str__(self):
            return simplejson.dumps({'code': self.code,
                                     'status_code': self.status_code,
                                     'detail': self.detail},
                                    sort_keys=True,
                                    indent=4)


class DataNotFoundError(AXException):
    status_code = 404
    default_detail = 'Data not found'
    default_code = 'data_not_found'


class TargetNotFoundError(AXException):
    status_code = 404
    default_detail = 'Target not found'
    default_code = 'target_not_found'


class InvalidInputError(AXException):
    status_code = 400
    default_detail = 'The data input by the caller is not valid'
    default_code = 'invalid_input'


class InternalError(AXException):
    status_code = 500
    default_detail = 'Unknown Internal Server Error'
    default_code = 'internal_error'


class SecurityError(AXException):
    status_code = 403
    default_detail = 'Insufficient privileges'
    default_code = 'security_error'
