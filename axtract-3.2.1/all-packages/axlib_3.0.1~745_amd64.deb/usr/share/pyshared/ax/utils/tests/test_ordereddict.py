import unittest2
from ax.utils.ordereddict import OrderedDict


class TestOrderedDict(unittest2.TestCase):
    def test_yml(self):
        d = OrderedDict([("main",
                  OrderedDict([("window",
                                OrderedDict([("size", [500, 500]),
                                             ("position", [100, 900])])),
                               ("splash_enabled", True),
                               ("theme", "Dark")])),
                 ("updates",
                  OrderedDict([("automatic", True),
                               ("servers",
                                [OrderedDict([("url", "http://server1.com"),
                                              ("name", "Stable")]),
                                 OrderedDict([("url", "http://server2.com"),
                                              ("name", "Beta")]),
                                 OrderedDict([("url", "http://server3.com"),
                                              ("name", "Dev")])]),
                               ("prompt_restart", True)])),
                 ("logging",
                  OrderedDict([("enabled", True),
                               ("rotate", True)]))])

        self.assertEqual(d.yml().strip(), """
main:
  window:
    size:
    - 500
    - 500
    position:
    - 100
    - 900
  splash_enabled: true
  theme: Dark
updates:
  automatic: true
  servers:
  - url: http://server1.com
    name: Stable
  - url: http://server2.com
    name: Beta
  - url: http://server3.com
    name: Dev
  prompt_restart: true
logging:
  enabled: true
  rotate: true
""".strip())
