from ax.globalnumbers import GlobalNumbers
from ax.globalnumbers import destroy_resources
from ax.globalnumbers import FakeGlobalNumbers
from ax.globalnumbers import setup_global_numbers
