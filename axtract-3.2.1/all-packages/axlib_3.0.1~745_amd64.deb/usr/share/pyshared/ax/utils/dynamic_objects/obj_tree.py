"""
Builing (serializable) nested trees of objects which relate to each other -
like AXServices - but also e.g. AXPAND results from another system.

Useful mainly for json serializable state representations.
"""
from ax.utils.formatting.pretty_print import dict_to_txt
import time
nothing = '\x01'
from logging import WARN, ERROR, INFO, DEBUG
# this caches the cls vars of TreeObjects
#tree_class_vars = {}

simple_types = (basestring, int, float, bool, type(None))
complex_types = (dict, tuple, list)


def cls_vars(cls):
    """returns the variables defined on class level
    if cls is an object, i.e. __class__ is not type class,
    we scan its class
    """
    if not isinstance(cls, type):
        pc = getattr(cls, '__class__', 0)
        # object. take its class:
        if pc:
            cls = pc
    return obj_vars(cls)

def obj_vars(obj):
    """ serializable members of an object
    WE don't add the @properties - this is quite early in the initting,
    and there is a reason they are calced.
    """
    #class_ident = self.__class__.__module__ + self.__class__.__name__
    vs = []
    for k in dir(obj):
        if k.startswith('_'):
            continue
        v = getattr(obj, k)
        if isinstance(v, simple_types) or isinstance(v, complex_types):
            vs.append(k)
    return vs

# ----------------------------------------------------------------------------
class TreeObject(object):
    """"
    When we have hirarchies not delivered by a mapper (like ORM) we must do
    on our own and its no big deal to do.


    hir 5 example:
             {'children': {'C': [{'id': 'C 1437224434.11',
                                'items': {'id': 'C 1437224434.11',
                                        'related_types': ['Rel'],
                                        'short': 'C'},
                                'parent': Id Top 1437224434.11,
                                'related': {'Rel': [{'id': 'Rel 1437224434.11',
                                                    'items': {},
                                                    'parent': Id C 1437224434.11}]}}]},
            'id': 'Top 1437224434.11',
            'items': {'child_types': ['C'],
                    'id': 'Top 1437224434.11',
                    'related_types': ['Rel'],
                    'short': 'Top'},
            'parent': None,
            'related': {'Rel': [{'children': {'C': [{'id': 'C 1437224434.11',
                                                    'items': {},
                                                    'parent': Id Rel 1437224434.11}]},
                                'id': 'Rel 1437224434.11',
                                'items': {'child_types': ['C'],
                                            'id': 'Rel 1437224434.11',
                                            'short': 'Rel'},
                                'parent': Id Top 1437224434.11}]}}


    """
    # We are a helper class and make that clear for every dir operation:
    # protection, not recursing into the whole db:
    _max_count = 1000
    # per sub (child, relation we deliver max this):
    _max_subs = 100
    _max_hir = 5


    _id_func = None
    # first parent the main one:
    _parent = None
    _item_filter = _items_formatter = None
    child_types = None
    _child_filter = _children_formatter = _children = _add_children = None
    related_types = None
    _rel_filter = _rels_formatter = _related = _add_rels = None

    # how they are labelled in the tree:
    _key_items    = 'items'
    _key_children = 'children'
    _key_related  = 'related'
    _key_meta     = '_meta'
    _key_id       = '_id'
    # allowed @properties: foo.i. Would lead to recursion:
    _no_scan_members = ['i', 'show']

    def _init_tree_obj(self, max_count=None, max_subs=None,
                            max_hir=None  , id_func=None):
        """ shall be called by the __init__ of a tree object """
        cls = self.__class__
        if not hasattr(cls, '__class_vars__'):
            cls.__class_vars__ = cls_vars(cls)

        # convention: we want a type, see repr:
        if not hasattr(self, 'type'):
            self.type = self.__class__.__name__

        # can be set per child type:
        self._max_count = max_count or self._max_count
        self._max_subs  = max_subs  or self._max_subs
        self._max_hir   = max_hir   or self._max_hir
        self._id_func   = id_func   or self._id_func
        # must have, except if not. not calling the func yet, its return value
        # might not yet be available (prob. the reason for the child to want a
        # func):
        id_func or self.id
        # first parent the main one:
        self._parent = nothing
        self._related = self._children = nothing

    @property
    def _members(self):
        """ just a potentially useful thing for descendants """
        return self.tree(hir=1)

    def _init_tree(self, tree, items, meta, hir, parent, crit=None, ptree=None):
        """ adjustments in place """
        if self._id_func:
            id = self._id_func()
        else:
            id = self.id
        if parent:
            tree['parent'] = parent.id
        tree[self._key_id] = id
        return id

    def _params(self, into={}, **kw):
        """ our params. no methods
        into: client can have a given map filled in place to avoid double

        """
        keys = self._get_items(**kw)
        ret = []
        for key in keys:
            v = getattr(self, key, nothing)
            if v == nothing:
                continue
            if isinstance(v, simple_types) or isinstance(v, complex_types):
                ret.append(key)
                into[key] = v
        return ret

    def _param_map(self, **kw):
        m = {}
        self._params(into=m)
        return m


    def _get_items(self, **kw):
        """ could be overwritten """
        if kw.get('crit', {}).get('nosub'):
            return self.__class__.__class_vars__
        return [k for k in dir(self) if not k.startswith('_') and not \
                k in self._no_scan_members]


    def ftree(self, hir=0, parent=None, crit=None, ptree=None, meta=None, **crits):
        """
        Filtered tree. Setting crits more conveniently
        e.g. domain.ftree(hir=4, nones=1, nosub=1, ServiceProviderId='100050')
        """
        # ServiceProviderId -> {ServiceProvider: {id: 100050}}, then see
        # get_children:
        crit = crit or {}
        filters = crit.setdefault('filters', {})
        for k, v in crits.items():
            if isinstance(v, simple_types):
                if k[-2:].lower() == 'id':
                    filters[k[:-2]] = {'id': v}
                    continue
                else:
                    filters[k] = {'match': v}
            else:
                filters[k] = v
        # pass through the rest:
        crit.update(crits)
        return self.tree(hir, parent, crit, ptree, meta)

    def tree(self, hir=0, parent=None, crit=None, ptree=None, meta=None):
        """"
        Using the tree.

        builds a nested tree
        hir dictates how deep we recurse in
        crit=crit is passed through and allowed to be used by filterers and
        formatters, subclassing this base class.
        ptree the parent tree, maybe interesting e.g. for tree formatters

        Note: The tree does not *deliver* generators but criteria defined populated
        chunks of children and related objects which can be instantly serialized,
        e.g. for the web, in a multiproc setup..

        Our get_child or get_related funcs can cope with generators though,
        which the TreeObjects implementations have to deliver.
        We are just the chunk assembler (batcher) in such a scenario.
        """
        tree = {}
        items = {}
        crit = crit or {}
        id = self._init_tree(tree, items, meta, hir, parent, crit, ptree)

        # if hir = 0 we return id only (e.g. for a flat list of subs)
        hir = hir - 1
        if hir < 0:
            return id

        # on root level we return meta infos:
        return_meta = 0
        if not meta or not 'total' in meta:
            # we are root:
            return_meta = 1
            meta = {'total': 0}
            meta['path'] = ()

        built_tree = self._tree(tree, items, hir, parent, crit, ptree, meta)
        if return_meta:
            # the way to switch that off:
            if self._key_meta:
                built_tree[self._key_meta] = meta
        return built_tree

    def _tree(self, tree, items, hir=0, parent=None, crit=None,
                    ptree=None, meta=None):

        base_path = meta['path']
        filters = crit.get('filters')
        max_count = crit.get('max_count', self._max_count)
        max_subs  = crit.get('max_subs' , self._max_subs )
        if 'objs' in crit:
            tree['obj'] = self
        else:
            # items:
            m = {}
            self._params(into=m, hir=hir, parent=parent, crit=crit, items=items)
            for item, v in m.items():
                # None values wanted?
                if v == None and not crit.get('nones'):
                    continue
                if not self._item_filter or \
                        self._item_filter(hir, crit, item, v, tree):
                    items[item] = v
                continue

            add = 1
            if self._items_formatter:
                # in place:
                add = self._items_formatter(hir, crit, items, tree)
            if items and add:
                tree[self._key_items] = items

        meta['total'] += 1
        if meta['total'] > max_count:
            return nothing

        hir = hir - 1
        if hir < 0:
            return tree

        cur_path = base_path + (tree[self._key_id],)

        # children
        for sub in (self._key_children, self._key_related):

            # do we wnat 'children', 'related' occur in path?
            # guess no:
            #sub_path = cur_path + (sub, )
            sub_path = cur_path

            # the caller may supply UC specific getters, formatters, ...
            if sub == self._key_children:
                # child
                sub_types     = crit.get('child_types'     , self.child_types)
                get_children  = crit.get('get_children'    , self._get_children)
                sub_filter    = crit.get('child_filter'    , self._child_filter)
                sub_formatter = crit.get('children_formatter', \
                                          self._children_formatter)
            else:
                sub_types     = crit.get('related_types' , self.related_types)
                get_children  = crit.get('get_related'   , self._get_related)
                sub_filter    = crit.get('rel_filter'    , self._rel_filter)
                sub_formatter = crit.get('rels_formatter', self._rels_formatter)
            if sub_types == nothing:
                continue
            if not sub_types:
                continue
            subs = {}
            # ct = childtype, e.g. servicetype in AXSS:
            for ct in sub_types:
                meta['path'] = sub_path + (ct, )
                # search kws, for get_children method:
                skw = {}
                # making the signature params for the get_children calls matching
                # the filters set, i.e. a convenience feature:
                if filters:
                    ct_filter = filters.get(ct)
                    if ct_filter:
                        idf = ct_filter.get('id')
                        if idf:
                            skw = {'id': idf}
                        else:
                            skw = {'filters': ct_filter}

                # the object specific get_child but also a subsequent filter
                # can be subject to adjustments:
                child_cnt = 0
                # if the get_children do 'total', they may just set it
                # inplace into the meta:
                try:
                    sub_objs = get_children(ct, crit=crit, subs=subs,
                                          tree=tree, meta=meta, **skw)
                except Exception as ex:
                    # for now, log mgmt not clear:
                    print (ex, '!' * 10)
                    if crit.get('ign_err'):
                        continue
                    raise

                for sub_obj in sub_objs:
                    child_cnt += 1
                    meta['path'] = sub_path + (ct, )
                    if child_cnt > max_subs:
                        break
                    # filter could also restrict on len, so deliver the subs:
                    if not sub_filter or \
                            sub_filter(hir, crit, ct,  sub_obj, subs, tree):

                        sub_tree = sub_obj.tree(
                            crit=crit, parent=self, hir=hir, ptree=tree,
                            meta=meta)
                        if sub_tree == nothing:
                            break

                        # recurse:
                        subs.setdefault(ct, []).append(sub_tree)
            add = 1
            if sub_formatter:
                # the formatter could hook in elsewhere, e.g. flat - and then
                # return empty:
                add = sub_formatter(hir, crit, ct, subs, tree)

            if subs and add:
                if crit.get('flat'):
                    t = ptree or tree
                    for ct in subs:
                        for s in subs[ct]:
                            p = cur_path + (ct, s[self._key_id])
                            try:
                                t['.'.join([str(ip) for ip in p])] = s
                            except Exception as ex:
                                import pdb;pdb.set_trace()
                else:
                    tree[sub] = subs
        # reset:
        meta['path'] = cur_path
        return tree

    def _get_children(self, child_type, **kw):
        return []
    def _get_related(self, related_type, **kw):
        return []


    # API:
    def info(self, hir=2, **kw):
        return self.ftree(hir=hir, **kw)

    def show(self, hir=2, **kw):
        print(dict_to_txt(self.info(hir, **kw)))

    def childs_all(self):
        childs  = self.ftree(hir=100, ign_err=1, nosub=1,
                             nones=1, flat=1   , objs=1)
        return childs

    def _run_deep(self, func, **kw):
        """ func = delete to wipe all """
        for ct in self.child_types:
            try:
                childs = self._get_children(ct)
            except Exception as ex:
                self.log(WARN, 'Could not get children %s' % ex)
                continue
            for child in self._get_children(ct):
                try:
                    getattr(child, func)(**kw)
                except Exception as ex:
                    self.log(WARN, 'Calling error %s' % ex)

        try:
            return getattr(self, func)(**kw)
        except Exception as ex:
            self.log(WARN, 'Calling error %s' % ex)

    def __repr__(self):
        return '%s %s' % (self.type, self.id)
        # must be string:
        return self.info(verbose=0, yml=1)



class FilteringTreeObject(TreeObject):
    """ Example of how to use the filters, which are here doing nothing """
    def _child_filter(self, hir, crit, ct, child, children):
        return 1
    def _children_formatter(self, hir, crit, ct, children):
        return 1
    def _rel_filter(self, hir, crit, ct, rel, rels):
        return 1
    def _rels_formatter(self, hir, crit, rel, rels):
        return 1
    def _item_filter(self, hir, crit, item, v):
        return 1
    def _items_formatter(self, hir, crit, items):
        return 1

    def __getitem__(self, k, default=''):
        return getattr(self, k, default)



class RestTree(TreeObject):
    """ Bringing the Tree to the Web """
    def Get(self):
        pass
    def Mod(self):
        raise NotImplemented
    Put = Post = Delete = Mod

    def __init__(self, id):
        pass

if __name__ == '__main__':
    from pprint import pformat
    from ax.utils.formatting.pretty_print import dict_to_txt
    def p(m):
        return dict_to_txt(m)

    class CP(TreeClass):
        child_types = ['CC']
    class CC(TreeClass):
        child_types = []


    c = CP
    #c.Get()

    # ----------------------------------------------------------------------------
    class P(TreeObject):
        def __init__(self):
            self.short = self.__class__.__name__
            self.id = '%s %s' % (self.short, time.time())
            self._init_tree_obj()

        def __repr__(self):
            return 'Id %s' % self.id

        # producing count 1 children and relateds whenever asked:
        def _get_children(self, child_type='', **kw):
            ket = []
            for ct in self.child_types:
                if child_type in ct:
                    ret.append(globals()[ct]())
            return ret

        def _get_related(self, related_type='', **kw):
            ret = []
            for ct in self.related_types:
                if related_type in ct:
                    ret.append(globals()[ct]())
            return ret


    class C(P):
        id = 'C'
        related_types = ['Rel']

    class Rel(P):
        id = 'rel id'
        child_types = ['C']

    class Top(P):
        id = 'top'
        child_types = ['C']
        related_types = ['Rel']

    t = Top()
    print(p(t.tree(hir=10)))

