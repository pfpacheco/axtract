import os
import sys
sys.path.insert(0, '/usr/lib64/python2.7/site-packages')
from sqlalchemy import *

import logging
import unittest2

from time                                import time

logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)

def l(*p):
    print (' '.join([str(s).strip() for s in p if s is not None]))

envget = os.environ.get
dflts = '127.0.0.1'  , 'root', 'ax', 3306, 'live'
# configure your testsetting here or via the environ:
dflts = '10.37.129.2', 'root', 'ax', 3306, 'live'

cfg = [(k, envget(k, dflts[i])) for k, i in zip(
           ('host', 'user', 'passwd', 'port', 'db'), range(0, 5))]


class Test1(unittest2.TestCase):
    def setUp(self):
        self.eng = create_engine('mysql://admin:ax@127.0.0.1:3308/live', echo=True)
        self.meta = MetaData(bind=self.eng)

    def test_reflect(self):
        import pdb; pdb.set_trace()



if __name__ == '__main__':
    unittest2.main()
