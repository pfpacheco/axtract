
import ax.utils.six.moves.queue as Queue
import threading
import time

import ax.utils.async_db_writer.db_worker

DEFAULT_NUM_WORKERS = 10
DEFAULT_QUEUE_LENGTH = 1000


class AsyncWriter(object):
    def __init__(self, db_config, config=None):
        """
        db_config: Configuration data for database connectivity. The format
                depends on the db_type you specify in $config.
        Following items from $config are evaluated:
            'queue_length': how long the queue will be
            'num_workers': How many threads (=concurrent connection) to start
            'db_type': What kind of database to connect to. Check
                db_worker.create_worker() for the list of currently supported
                ones.
        """
        self._workers = []
        self._worker_threads = []

        my_config = {}
        if config is not None:
            my_config.update(config)
        my_config['queue_length'] = my_config.get(
                "queue_length", DEFAULT_QUEUE_LENGTH)
        my_config['num_workers'] = my_config.get(
                "num_workers", DEFAULT_NUM_WORKERS)

        self._query_queue = Queue.Queue(my_config['queue_length'])
        self._setup_workers(db_config, my_config)

    def _setup_workers(self, db_config, config):
        self._workers = db_worker.create_workers(self._query_queue,
                db_config, config=config)

        for worker in self._workers:
            thread = threading.Thread(target=worker.run)
            thread.daemon = True
            thread.start()
            self._worker_threads.append(thread)

    def put(self, query):
        try:
            self._query_queue.put_nowait(query)
        except Exception:
            # TODO: log+count
            pass

    def shutdown(self):
        if not self._workers:
            return
        for worker in self._workers:
            worker.should_stop = True

        # Give all threads some time to terminate. This time must be higher
        # than the threads' blocking interval on the queue to have a realistic
        # chance of working as intended.
        start_ts = time.time()
        max_join_time = self._workers[0].max_block_time + 0.3

        for worker_thread in self._worker_threads:
            time_taken = time.time() - start_ts
            worker_thread.join(max_join_time - time_taken)
            if time.time() - start_ts > max_join_time:
                break

