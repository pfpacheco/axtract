from ax.utils.listables.listable import logger
from ax.utils.locking.proc_lock import *
log  = lambda level, *msg: getattr(logger, level)(' '.join(msg))
info = lambda *msg: log('info', *msg)

ga = lambda o, k, dflt=None: getattr(o, k, dflt)

def _add_cls(base, name):
    info('adding', name, 'to', base.__name__)
    cc = type(name, (object,), {})
    setattr(base, name, cc)
    return cc

is_parent = lambda pn, lt: (any([pt for pt in ga(lt, 'parent_types', ())
                            if pt['type'] == pn]))

def _add_childs(pn, pltc, all):
    for n, lt in all:
        if n == pn:
            continue
        if is_parent(pn, lt):
            _add_childs(n, _add_cls(pltc, n), all)

def auto_tree(listables, name='API'):
    '''
    listables like
    [('Ticket', Ticket[sql]), ('TicketLog', TicketLog[sql]), ('cpe', cpe[sql])]

    normal form of api tree like:
    class MyApi:
        _schemas = [listables1, ...]
        class Ticket:

    and Ticket infos from listable will be merged into class Ticket.

    -> thats what we generate here, not more.
    '''
    lts = listables
    t = ga(lts, 'auto_tree')
    if t:
        return t
    #with proc_lock(hasattr, (lts, 'auto_tree'))):
    if 1:
        api = type(name, (object,), {'_schemas': [lts]})
        parents = []
        all = lts.items()
        for n, lt in all:
            if ga(lt, 'is_root') or not ga(lt, 'parent_types'):
                parents.append((n, _add_cls(api, n)))
        [_add_childs(n, ltc, all) for n, ltc in parents]
        lts.auto_tree = api
    return lts.auto_tree





