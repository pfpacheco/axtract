""" Helper module to write CollectdPlugins


* Inherit from it
* Ensure that BasePlugin.__init__ is called
* Implement a 'def print_stats(self):' method and use 'self.submit(..)'
   there to print the stats.

* Start it like this:
    if __name__ == '__main__':
        KafkaPlugin(parse_args()).main()
"""

import time
import os
import socket
import sys
import traceback


FMT = "PUTVAL %(hostname)s/%(plugin_type)s%(plugin_instance)s/%(type_name)s%(type_instance)s N:%(values)s\n"


class BasePlugin(object):
    def __init__(self):
        self.interval = float(os.getenv("COLLECTD_INTERVAL", 10))
        self.hostname = os.getenv("COLLECTD_HOSTNAME", socket.gethostname())

    def main(self):
        while True:
            start = time.time()
            try:
                self.print_stats()
            except Exception:
                traceback.print_exc(file=sys.stderr)

            sleep_time = self.interval - (time.time() - start)
            time.sleep(max(0, sleep_time))

    def submit(
            self,
            plugin_instance,
            type_name,
            type_instance,
            *values):

        fmt_args = {
            'hostname': self.hostname,
            'plugin_type': self.plugin_type
        }

        if plugin_instance:
            fmt_args['plugin_instance'] = '-%s' % plugin_instance
        else:
            fmt_args['plugin_instance'] = ''

        fmt_args['type_name'] = type_name

        if type_instance:
            fmt_args['type_instance'] = '-%s' % type_instance
        else:
            fmt_args['type_instance'] = ''

        values = ':'.join('U' if v is None else str(v) for v in values)
        fmt_args['values'] = values

        sys.stdout.write(FMT % fmt_args)
        sys.stdout.flush()

    def log_error(self, msg):
        print >> sys.stdout, msg

    def print_stats(self):
        raise NotImplementedError("This method must be overloaded")
