# GK: For dumping, json is well faster than simplejson.
# For loading, simplejson is faster.
# tried with big request dumps, and even we have
# bool(getattr(simplejson, '_speedups', False))
import sys


from json import loads, dumps
from yaml import safe_dump, dump

from pygments import highlight
from pygments.lexers import JsonLexer
from pygments.lexers import YamlLexer

PY3 = sys.version_info[0] > 2
basestring = str if PY3 else basestring

try:
    from pygments.formatters import HtmlFormatter, Terminal256Formatter
except:
    from pygments.formatters.terminal import TerminalFormatter

    Terminal256Formatter = TerminalFormatter


# from pygments.styles import get_style_by_name

ysl = ytermf = jsl = ''
# formatters by style:
_fmts = {}


def get_fmt(style):
    termf = _fmts.get(style)
    if not termf:
        termf = _fmts[style] = Terminal256Formatter(style=style)
    return termf


# ready to make partials for changing the defaults:
def coljhighlight(
    s,
    style='tango',
    indent=4,
    sort_keys=True,
    add_line_seps=True,
    # logger might be set to colors off, e.g. at no tty dest:
    colorize=True,
    # automatic indent only for long stuff?
    no_indent_len=0,
):

    global jsl
    if not jsl:
        jsl = JsonLexer()
    if not isinstance(s, basestring):
        if indent and no_indent_len:
            if len(str(s)) < no_indent_len:
                indent = None
        s = dumps(s, indent=indent, sort_keys=sort_keys, default=str)

    if colorize:
        res = highlight(s, jsl, get_fmt(style))
    else:
        res = s

    if add_line_seps:
        res = res.replace('\\n', '\n')

    return res


def colyhighlight(s, style='colorful'):
    global ysl, ytermf
    if not ysl:
        ysl = YamlLexer()

    ytermf = get_fmt(style)
    io = cStringIO.StringIO()
    if not isinstance(s, basestring):
        try:
            s = safe_dump(s)
        except:
            s = dump(s, default_flow_style=False)
    highlight(s, ysl, ytermf, io)
    res = io.getvalue()
    io.close()
    return res
