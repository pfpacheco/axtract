#!/usr/bin/env python
"""
This module contains a minimal client for the Atlassian Confluence REST API.
When called from the command line it will upload a list of files
to a given Confluence page.

If the option -m is passed, the script will assume the files are MongoDB
benchmarks results charts and will also add a 7x2 table to the given page,
each cell containing a paritucular chart.
"""

import os
import argparse

import requests
from requests.auth import HTTPBasicAuth
import simplejson as json

WIKI_URL = 'https://wiki.axiros.com'
USERNAME = 'kayakorep'
PASSWORD = '#Axiros2015'

ATTACHMENT_EXISTS_MSG = 'Cannot add a new attachment with same file name as an existing attachment'

def print_error_and_exit(value):
    print("Invalid option value (%s)" % value)
    parser.print_help()
    import sys; sys.exit()

def parse_args():
    parser.add_argument("-w", "--wiki-url")
    parser.add_argument("-u", "--username")
    parser.add_argument("-p", "--password")
    parser.add_argument("-i", "--page-id", required=True)
    parser.add_argument("-f", "--files", nargs='*')
    parser.add_argument("-m", "--mongodb", action='store_true')
    return parser.parse_args()


class ConfluenceRESTClient(object):
    def __init__(self, wiki_url, username, password):
        self.wiki_url = wiki_url
        self.session = requests.Session()
        self.session.auth = HTTPBasicAuth(username, password)
        self.attachments = []

    def post_file(self, container_id, filename):
        r = self.session.post(
            self.wiki_url + '/rest/api/content/%s/child/attachment' % container_id,
            headers={'X-Atlassian-Token': 'nocheck'},
            files={'file': open(filename, 'rb')}
        )

        r.encoding = 'UTF-8'
        response = r.json()
        if r.status_code == 200:
            result = response['results'][0]
            if result['title'] in filename:
                size = int(round(result['extensions']['fileSize']/1024.0))
                print("--- SUCCESS --- %s (%d KB)" % (filename, size))
                return True

        err_message = response['message']
        print("--- FAILED --- %s" % err_message)
        return ATTACHMENT_EXISTS_MSG in err_message

    def upload_attachments(self, container_id, files):
        """ Recursively find files in given paths
        and call the method 'post_file' on each of them
        """

        for o in files:
            if os.path.isfile(o):
                if self.post_file(container_id, o):
                    self.attachments.append(os.path.basename(o))
            elif os.path.isdir(o):
                self.upload_attachments(container_id, [os.path.join(o, i) for i in os.listdir(o)])
            else:
                print("(%s) is neither a regular file nor a directory. Skipping this" % o)

    def get_content_by_id(self, content_id):
        r = self.session.get(
            self.wiki_url + '/rest/api/content/%s?expand=body.storage,version' % content_id
        )

        r.encoding = 'UTF-8'
        response = r.json()
        if r.status_code == 200:
            return response['body']['storage']['value'], response['version']['number']

        raise Exception("%s - %s" % (r.status_code, response['message']))

    def update_content_by_id(self, content_id, version, html_data):
        data = {
            "version": {
                "number": version
            },
            "type": "page",
            "body": {
                "storage": {
                    "value": html_data,
                    "representation": "storage"
                }
            }
        }
        r = self.session.put(
            self.wiki_url + '/rest/api/content/%s' % content_id,
            headers={'Content-Type': 'application/json'},
            data=json.dumps(data)
        )

        r.encoding = 'UTF-8'
        return r.status_code, r.json()

    def close(self):
        pass


def create_mongodb_bm_results_wiki_table(attachments):
    # Generic Table Contents for MongoDB Benchmarks
    IMAGE_MARKUP = '<ac:image ac:height="250"><ri:attachment ri:filename="%s" /></ac:image>'
    MONGODB_DM_CHARTS = [
        ['beanstalk_commands-by-host_axtract', 'host-overview_cpu_axtract'],
        ['host-overview_cpu_mongo1', 'host-overview_cpu_mongo2'],
        ['host-overview_ram_mongo1', 'host-overview_ram_mongo2'],
        ['mongodb-overview_total-operations_mongo1', 'mongodb-overview_total-operations_mongo2'],
        ['host-overview_disk-ops_mongo1', 'host-overview_disk-ops_mongo2'],
        ['host-overview_disk-octets_mongo1', 'host-overview_disk-octets_mongo2'],
        ['host-overview_disk-time_mongo1', 'host-overview_disk-time_mongo2']
    ]

    charts_pngs = [[] for i in range(7)]
    failed_charts = {}
    for i in range(7):
        for j in range(2):
            chart_type = MONGODB_DM_CHARTS[i][j]
            att = filter(lambda name: chart_type in name, attachments)
            attachments_found = len(att)
            if attachments_found != 1:
                failed_charts[chart_type] = attachments_found
                continue
            charts_pngs[i].append(att[0])

    if failed_charts:
        err_message = "There should be one attachment for the following chart types:\n"
        for ch, n in failed_charts.items():
            err_message += "%s - Attachments found: %d\n" % (ch, n)
        raise Exception(err_message)

    return '<table><tbody><tr><td>' + '</td></tr><tr><td>'.join(
        '</td><td>'.join(
            IMAGE_MARKUP % charts_pngs[i][j] for j in range(2)
        ) for i in range(7)
    ) + '</td></tr></tbody></table>'


if __name__ == '__main__':
    parser = argparse.ArgumentParser("Atlassian Confluence REST API Client")
    args = parse_args()
    page_id = args.page_id

    client = ConfluenceRESTClient(
        args.wiki_url or WIKI_URL,
        args.username or USERNAME,
        args.password or PASSWORD,
    )

    content, version = client.get_content_by_id(page_id)
    client.upload_attachments(page_id, args.files or ['.'])
    if args.mongodb:
        table = create_mongodb_bm_results_wiki_table(client.attachments)
        status, response  = client.update_content_by_id(
            page_id,
            version + 1,
            content + '<hr/><h1>TEST</h1>' + table
        )
        if status != 200:
            print(response)
