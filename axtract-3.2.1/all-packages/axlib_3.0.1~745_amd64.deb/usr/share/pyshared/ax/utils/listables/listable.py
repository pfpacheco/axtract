"""
Support for Listables, e.g. a Table Data from SQL, realizing a Data API Backend
on them.

- Project independent
- Zope API Decoupled (e.g. SQL access callables replaceable)
- Ctx only data (e.g. verified claims of a user)
- Stateless

This module already contains the SQL Listable Adapter.
"""

import time
import types
import re
import sys
import simplejson
import warnings

try:
    import sqlalchemy
except ImportError:
    sqlalchemy = None
from ast import literal_eval
from json import loads, dumps
from pprint import pformat
from fnmatch import fnmatch
from collections import OrderedDict
from ax.utils.logging import setup_logging_for_library
from ax.utils.condition import sanitize_input
from ax.utils.locking.proc_lock import cached
from ax.utils.exceptions import InvalidInputError
from ax.utils.exceptions import DataNotFoundError
from ax.utils.exceptions import InternalError
from ax.utils.exceptions import TargetNotFoundError
if sys.version >= '3':
    from copy import deepcopy
else:
    from ax.utils.simple_deepcopy import deepcopy

PY3 = sys.version_info[0] > 2
if PY3:
    basestring = str
    xrange = range

logger = setup_logging_for_library("ax.utils.listable")

try:
    from ax.utils.formatting.inflect import titleize
except ImportError:
    print("have no ax.utils.formatting.inflect for titleize. Using capitalize.")
    titleize = lambda s: s.capitalize()


def get_listables(schema_class, db_api, invalidate=False):
    sc = schema_class
    return cached(
        key=".".join((sc.__module__, sc.__name__)),
        builder=Listables,
        facts=(schema_class, db_api),
        invalidate=invalidate,
    )


# ------------------------------------------------------------ Store API Access
get_api = lambda handle: getattr(handle, "execute", None)

# -------------------------------------------------------------- Child Counting
# done via show: [count.User, City]...-> counts Users via 'on' relation:
# {'Enterprise': {'User': {'999950': [23, 1467411893]}}
# TODO: tools is not reloaded, delete this later, when done:

child_count_cache = {}


def get(data, keys):
    keys = [k.strip() for k in keys.split(",")]
    r = {}
    for k in keys:
        r[k] = data[k]
    if len(keys) == 1:
        return r.values()[0]
    return r


from datetime import datetime

unix_millis = 10 ** 10


def iso8601_str(data, fmt="%Y-%m-%d %H:%M:%S.%f %Z"):
    if isinstance(data, (int, long)):
        if data > unix_millis:
            data = data / 1000.0
        data = datetime.utcfromtimestamp(data)
    return data.strftime(fmt)


# data column postprocessing:
post_processors = {
    "eval": literal_eval,
    "loads": loads,
    "dumps": dumps,
    "int": int,
    "float": float,
    "iso8601": iso8601_str,
    "get": [get],
}

# --------------------------------------------------------------- Internal Tools
class OD(OrderedDict):
    """ e.g. for params """

    __repr__ = lambda self: pformat(dict(self.items()))


def lit_eval(s, key=None, into=None):
    """
    literal eval with meaningful exceptions to user
    The implementation may look a bit ugly to some but it has a purpose;
    to support the following:
    Filters:
        1. ["cpe.cpeid", "=", null]
        2. ['cpe.cpeid', '=', 'Munich']
    Show parameters like:
        1. ["cpe.cpeid", "cpe.cid"]
        2. ['cpe.cpeid', 'cpe.cid']
        3. cpe.cpeid,cpe.cid
    """
    try:
        res = simplejson.loads(s)
    except simplejson.decoder.JSONDecodeError:
        try:
            res = literal_eval(s)
            if into and not isinstance(res, into):
                raise
        except Exception:
            if into in (list, tuple) and isinstance(s, basestring):
                return into([token.strip() for token in s.split(",")])

            msg = 'Could not parse "%s"' % s
            if key:
                msg = 'Key "%s": ' % key + msg
            if into:
                msg += " as a %s" % into.__name__
            raise InvalidInputError(msg)
    return res


# In order to understand stringyfied filter statements like
# "cpeid = '2323' and (foo=23 or ..)"
# we use an SQL query parser based on pyparsing, written by its author:
from pyparsing import (
    Literal,
    CaselessLiteral,
    upcaseTokens,
    delimitedList,
    Optional,
    Combine,
    Group,
    alphas,
    nums,
    alphanums,
    Forward,
    oneOf,
    quotedString,
    ZeroOrMore,
    restOfLine,
    Keyword,
    ParseException,
    ParseResults,
    Word,
)

SelectStmt = None


def build_select_parser():
    global SelectStmt
    # define SQL tokens
    SelectStmt = Forward()
    selectToken = Keyword("select", caseless=True)
    fromToken = Keyword("from", caseless=True)

    ident = Word(alphas, alphanums + "_$.").setName("identifier")
    columnName = delimitedList(
        ident, ".", combine=True
    )  # .setParseAction(upcaseTokens)
    columnNameList = Group(delimitedList(columnName))
    tableName = delimitedList(ident, ".", combine=True).setParseAction(upcaseTokens)
    tableNameList = Group(delimitedList(tableName))

    whereExpression = Forward()
    and_ = Keyword("and", caseless=True)
    or_ = Keyword("or", caseless=True)
    in_ = Keyword("in", caseless=True)

    E = CaselessLiteral("E")
    binop = oneOf(Listable._ops.values(), caseless=True)
    arithSign = Word("+-", exact=1)
    realNum = Combine(
        Optional(arithSign)
        + (Word(nums) + "." + Optional(Word(nums)) | ("." + Word(nums)))
        + Optional(E + Optional(arithSign) + Word(nums))
    )
    intNum = Combine(
        Optional(arithSign) + Word(nums) + Optional(E + Optional("+") + Word(nums))
    )
    # need to add support for alg expressions
    columnRval = realNum | intNum | quotedString | columnName
    whereCondition = Group(
        (columnName + binop + columnRval)
        | (columnName + in_ + "(" + delimitedList(columnRval) + ")")
        | (columnName + in_ + "(" + SelectStmt + ")")
        | ("(" + whereExpression + ")")
    )
    whereExpression << whereCondition + ZeroOrMore((and_ | or_) + whereExpression)

    # define the grammar
    SelectStmt << (
        selectToken
        + ("*" | columnNameList).setResultsName("columns")
        + fromToken
        + tableNameList.setResultsName("tables")
        + Optional(
            Group(CaselessLiteral("where") + whereExpression), ""
        ).setResultsName("where")
    )

    # define comment format, and ignore them
    SelectStmt.ignore("--" + restOfLine)


def parse_select_str(s):
    if not SelectStmt:
        build_select_parser()
    return SelectStmt.parseString(s)


def _p(l):
    if isinstance(l, basestring):
        return l
    r = []
    is_like_op = False  # is the operator a 'like' ?
    pos = -1
    while l:
        el = l.pop(0)
        if el in par:
            continue
        if isinstance(el, list):
            r.append(_p(el))
        elif isinstance(el, ParseResults):
            r.append(_p([i for i in el if not i in par]))
        elif isinstance(el, basestring):
            pos += 1
            if pos == 2:
                # we allow to wrap values into apos, optionally.
                # this is a value - check if it starts & ends
                # with apos and if so: remove them - otherwise we get
                # double apos in q_map filters:
                if (el[0], el[-1]) in (('"',) * 2, ("'",) * 2):
                    el = el[1:-1]
            r.append(el)
    return r


def parse_filter_str(s):
    """ creating a nested filter condition from a string entered filter """
    try:
        if not s.startswith("("):
            sl = s.lower()
            if " and " in sl or " or " in sl:
                s = "(%s)" % s

        # like [(['CID', '=', '23'], {}), 'and', (['FOO', '=', '23'], {})]:
        res = parse_select_str("select * from table where %s" % s)
        # remove the {} and the ()
        par = ("(", ")")

        res = res.where[0][1]
        r = _p(res)
        return r
    except:
        raise InvalidInputError("Unable to interpret filters: %s" % s)


# Registry for all native parameter funcs, for fast lookup:
# filled at params inspection:
native_funcs = {}

# -------------------------------------------------------- Generic Base Classes
class Listables(OD):
    is_setup = path_count = 0

    def dict(self, st=None, claims=None):
        """
        Full serialization.
        We don't(!) overwrite the std python __dict__ method,
        to not confuse normal usages of that
        """
        if st:
            if st in self:
                return self[st].attrs(claims)
            else:
                raise InvalidInputError("Unknown type: %s" % st)
        return {v.typ: v.attrs(claims) for v in self.values()}

    def __init__(self, schema_class, API=None):
        # Registers all paths between listables:
        super(Listables, self).__init__()
        self.paths = {}
        self.select_cache = {}

        # Iterate over all inner classes and register listables
        for name in dir(schema_class):
            value = getattr(schema_class, name, None)
            # issubclass does not work after reloading, so check for attrs:
            # if isinstance(value, type) and issubclass(value, Listable):
            if (
                isinstance(value, type)
                and hasattr(value, "native_group")
                and hasattr(value, "master_params")
            ):
                instance = value(self)
                self[value.__name__] = instance
        self.setup(API) if API else None

    def setup(self, API=None):
        """ base setup from py.defs.
        if sql is involved we need the API, but it restricts to one method,
        so can easily be created outside zope as well.
        Don't know yet which other listables we might have NOT on SQL but
        requiring zope?
        """
        if self.is_setup:
            return

        # we only know after the setup method that there are parent_types and
        # that can be overwritten. This modifies the list of user space types
        # accordingly:
        for key in tuple(self.keys()):
            # will remove when no parent_type.
            self[key].setup()

        # now kick all framework classes:
        for key, s in self.items():
            if API is not None:
                try:
                    s.explore(API)
                except Exception as ex:
                    ex.args += ("error exploring", key)
                    raise InternalError(str(ex))
                s.after_setup()
        self.build_paths()
        self.is_setyp = 1 if API is not None else 0

    def build_paths(self):
        """
        Building the `paths` map.

        Contains any(!) possible relation between listables (with a cost)
        Currently only within same native type.

        We stop when we can't derive any more relations.

        this is a process start only action
        """

        def build_native_group_paths(lts):
            def build_native_paths(lt, joins, lts, d=0):
                def via(l, m):
                    r = list(m["via"])  # clone
                    r.append(l)
                    return r

                before = len(joins)  # to know: are we finished?
                if d == 1:
                    frm = [[lt, [lt]]]
                else:
                    # get the vias for the previous run:
                    frm = [
                        [l, via(l, m)] for l, m in joins.items() if m["cost"] == d - 1
                    ]

                for l, via in frm:
                    for rels in l.child_types, l.parent_types:
                        for rel in rels:
                            jlt = self[rel["type"]]
                            if jlt in joins or jlt == lt:
                                continue
                            self.path_count += 1
                            # it comes handy in the path calc to add
                            # ourselves in the end of via chain:
                            vv = list(via)
                            # vv.insert(0, lt)
                            joins[jlt] = {"cost": d, "via": vv}
                if len(joins) == before:
                    lt._paths_finished = 1

            for d in xrange(100):
                cont = 0
                for lt, joins in lts.items():
                    if not lt._paths_finished:
                        cont = 1
                        build_native_paths(lt, joins, lts, d + 1)
                if not cont:
                    return
            raise InternalError("Config problem (endless loop building join paths)")

        # we do this for each native group, seperated:
        t1 = time.time()
        for ng, lts in self.paths.items():
            build_native_group_paths(lts)
        self.pt_path_calc = time.time() - t1  # store processing time.
        _ = "%s paths calculated [%.2fs]"
        logger.info(_ % (self.path_count, self.pt_path_calc))

    def insert_counts(self, data, q_map, API):
        """ count child types. join keys are in """
        lt, ccc = q_map["list_type"], child_count_cache
        ts = time.time()
        # not accept older than:
        expiry = getattr(self[lt], "count_childs_every", 60)
        not_older_than = ts - expiry
        for pos, ct in q_map.get("counts", []):
            cc = child_count_cache.setdefault(lt, {}).setdefault(ct[0], {})
            # same format as normal show param, before the kv mapping:
            q_map["show"][pos] = "%s.count_%s" % (lt, ct[0])
            # now replace the join values with the counts:
            for row in data:
                v = row[pos]
                cache = cc.get(v)
                if cache and cache[1] > not_older_than:
                    row[pos] = cache[0]
                    continue
                # ok cache too old or not present. have to count native:
                child = self[ct[0]]
                vn = child.count_val(lt, key=ct[1], val=row[pos], API=API)
                row[pos] = vn
                cc[v] = [vn, time.time()]
        # prevent misconfig:
        dt = round(time.time() - ts, 2)
        if dt > expiry:
            raise InternalError(
                ("Time to build counts (%s) > expiry(%s)." "Increase cache time")
                % (dt, expiry)
            )
        q_map["count_time"] = round(time.time() - ts, 2)
        return data

    def create_query_map(self):
        # CAUTION: If you're adding new keys to the query map, make sure that the
        # implementation does not rely on these keys to be always present.
        # Old AXGroup query map definitions must still work.
        query_map = {
            "filters": [],
            "show": [],
            "group_by": [],
            "sort": [],
            "tables": [],
            "list_type": None,
            "full_query": ["SELECT", "FROM", "WHERE", "1 = 1"],
            "filter_params": [],
            "filter_placeholders": [],
            "cost": 5,
        }
        return query_map

    # ----------------------------------- value rows to (sparse) key value maps
    def to_kv(self, data, q_map):
        """
        in first show param may define the return key value mapping
        (default is no mapping)
        kv: Show kvs, not falsey values, kva: show all values

        Also we support ts, tn switches to strip table names or reduce to first
        Letter
        """
        kvm = ":" + q_map.get("to_kv", "") + ":"
        if not ":kv" in kvm:
            q_map["kv"] = None
            return data
        q_map["kv"] = True
        q_map["kv_all"] = sh_falsy = ":kva:" in kvm
        table_names = True
        if ":tn:" in kvm:
            table_names = False
        elif ":ts:" in kvm:
            table_names = -1

        names = list(q_map.get("realized_show", []))  # headers
        # turning [[0, 'a'], [2, '']] into [{key1: 0, key2: 'a'}, {key1: 2}]
        res = []
        for val_row in data:
            row = {}
            for i in xrange(len(val_row)):
                h, v = names[i], val_row[i]
                if not table_names == True:
                    h, k = h.split(".", 1)
                    if table_names == -1:
                        h = h[0].upper() + "." + k
                    elif table_names == False:
                        h = k
                if sh_falsy or (v or v in (False, 0)):
                    row[h] = v
            # maybe all falsey
            if row:
                res.append(row)
        return res

    def post_process_val(self, f, d):
        r = d
        for f in [k.strip() for k in f.split(":")]:
            if "_" in f:
                # postprocessor with params:
                f, params = f.split("_", 1)
                r = post_processors[f](r, params)
            else:
                r = post_processors[f](r)
        return r

    def process_values(self, data, q_map):
        """
        difficulty here: show could have equal props at different locations but
        we have the post processors listed as they occur
        """
        sp = q_map.get("show_procs", [])
        if not sp:
            return data
        sh = q_map.get("realized_show", [])
        # e.g. {3: evalfunc}
        proc_by_pos = {}
        eqp = {}
        for p in sp:
            sh_idx = eqp.get(p[0], 0)
            # next equal show param must be searched from here:
            eqp[p[0]] = sh_idx + 1
            proc_by_pos[sh_idx + sh[sh_idx:].index(p[0])] = p[1]
        proc_by_pos = sorted(proc_by_pos.items())
        for row in data:
            for i, f in proc_by_pos:
                row[i] = self.post_process_val(f, row[i])
        return data

    # ----------------------------------------------------- Data Postprocessors
    def post_process(self, data, q_map, API):
        """
        run postprocessing functions over data columns.
        """
        data = self.insert_counts(data, q_map, API)
        data = self.process_values(data, q_map)
        data = self.to_kv(data, q_map)
        return data

    def get_primary_id(self, obj_name):
        return self[obj_name].primary_id

    def _validate_and_convert_input(
            self,
            results=None,
            values=None,
            filters=None,
            tenancy_filters=None,
            group_by=None,
            sort=None,
            limit=None,
            offset=None,
            cost=None):

        if results:
            if isinstance(results, str):
                results = simplejson.loads(results)

            if not isinstance(results, list):
                raise InvalidInputError("result show argument must be a list")

        if values:
            if isinstance(values, str):
                values = simplejson.loads(values)

            if not isinstance(values, dict):
                raise InvalidInputError("values argument must be a dict")

        if filters:
            if isinstance(filters, str):
                filters = simplejson.loads(filters)

            if not isinstance(filters, list):
                raise InvalidInputError("filters must be a list")

        if tenancy_filters:
            if isinstance(tenancy_filters, str):
                tenancy_filters = simplejson.loads(tenancy_filters)

            if not isinstance(tenancy_filters, list):
                raise InvalidInputError("tenancy filters must be a list")

        if group_by:
            if isinstance(group_by, str):
                group_by = simplejson.loads(group_by)

            if not isinstance(group_by, list):
                raise InvalidInputError("group by argument must be a list")

        if sort:
            if isinstance(sort, str):
                sort = simplejson.loads(sort)

            if not isinstance(sort, list):
                raise InvalidInputError("sort argument must be a list")

        if limit:
            if isinstance(limit, str):
                limit = int(limit)

            if not isinstance(limit, int):
                raise InvalidInputError("limit must be an integer")

        if offset:
            if isinstance(offset, str):
                offset = int(offset)

            if not isinstance(offset, int):
                raise InvalidInputError("offset must be an integer")

        if cost:
            if isinstance(cost, str):
                cost = int(cost)

            if not isinstance(cost, int):
                raise InvalidInputError("cost must be an integer")

    def select(
        self,
        db_engine,
        results,
        filters=None,
        tenancy_filters=None,
        group_by=None,
        sort=None,
        limit=100,
        offset=0,
        return_as="dict",
        root=None,
        cost=None
    ):
        """
        Returns the data by executing the query

        @param db_engine: Database handle
        @param results: Result parameters as list
        @param filters: Filters as nested list
        @param tenancy_filters: Tenancy filters as nested list
        @param: group_by: Group by attributes as list
        @param sort: List of tuples specifying sort attribute with asc/desc
        @param limit: Limit on the data to be fetched(None means fetch all)
        @param offset: Offset from which the next records to be fetched
        @param: return_as: Outputs 'dict' or 'list'
        @param root: Root type to be used as a starting point for building joins
        @param cost: No. of hops connecting a related resource
        """
        if not results:
            raise InvalidInputError("Cannot select without result parameters")

        self._validate_and_convert_input(
            results=results,
            filters=filters,
            tenancy_filters=tenancy_filters,
            group_by=group_by,
            sort=sort,
            limit=limit,
            offset=offset,
            cost=cost)

        if not root:
            root = results[0].split(".")[0]

        if root not in self:
            raise TargetNotFoundError(
                "Operation not supported on target or target not found: %s"
                % root)

        lt = self[root]
        query_map = self.create_query_map()

        if cost is not None:
            query_map["cost"] = cost

        if filters:
            lt.set_filters(query_map, filters, tenancy_filters)
        if results:
            lt.set_resultset(query_map, results)
        if group_by or sort:
            lt.set_query_options(query_map, group_by, sort)

        data = lt.get_data(query_map, db_engine, limit, offset)
        if return_as == "dict":
            query_map["to_kv"] = "kva"
            data = self.post_process(data, query_map, db_engine)

        return data

    def _first_element_in_lol(self, lol):
        if not lol:
            return None

        if isinstance(lol, basestring):
            return lol

        return self._first_element_in_lol(lol[0])

    def count(
        self,
        db_engine,
        filters=None,
        tenancy_filters=None,
        group_by=None,
        return_as="dict",
        root=None,
    ):
        """
        Counts rows matching filter and returns # of rows
        deleted

        @param db_engine: Database handle
        @param filters: Filters as nested list
        @param tenancy_filters: Tenancy filters as nested list
        @param: group_by: Group by attributes as list
        @param: return_as: Outputs 'dict' or 'list'
        @param root: Root type to be used as a starting point for building joins
        """
        if not filters and not group_by and not root:
            raise InvalidInputError("Not enough information for counting")

        self._validate_and_convert_input(
            filters=filters,
            tenancy_filters=tenancy_filters,
            group_by=group_by)

        if not root:
            root_filter = (
                self._first_element_in_lol(filters).split(".")[0] if filters else ""
            )
            root_group_by = group_by[0].split(".")[0] if group_by else ""
            root = root_filter if root_filter in self else root_group_by

        if root not in self:
            raise TargetNotFoundError(
                "Operation not supported on target or target not found: %s"
                % root)

        lt = self[root]
        query_map = self.create_query_map()

        if filters:
            lt.set_filters(query_map, filters, tenancy_filters)
        if group_by:
            lt.set_query_options(query_map, group_by)

        data = lt.get_count(query_map, db_engine, group_by)
        if return_as == "dict":
            data = self.post_process(data, query_map, db_engine)

        return data

    def delete(self, db_engine, filters=None, root=None):
        """
        Deletes rows matching filters and returns # of rows
        deleted

        @param db_engine: Database handle
        @param filters: Filters as nested list
        @param root: Root type to be used as a starting point for building joins
        """
        if not filters:
            raise InvalidInputError("Cannot delete without filters")

        self._validate_and_convert_input(filters=filters)

        if not root:
            root = self._first_element_in_lol(filters).split(".")[0]

        if root not in self:
            raise TargetNotFoundError(
                "Operation not supported on target or target not found: %s"
                % root)

        lt = self[root]
        query_map = self.create_query_map()
        lt.set_filters(query_map, filters)
        return lt.delete_data(query_map, db_engine)

    def update(self, db_engine, new_values, filters=None, root=None):
        """
        Updates rows matching filter and returns # of rows updated

        @param db_engine: Database handle
        @param new_values: New values for attributes to be updated
        @param filters: Filters as nested list
        @param root: Root type to be used as a starting point for building joins
        """
        if not new_values:
            raise InvalidInputError("Cannot update without new values")

        self._validate_and_convert_input(values=new_values, filters=filters)

        if not root:
            root = next(iter(new_values)).split(".")[0]

        if root not in self:
            raise TargetNotFoundError(
                "Operation not supported on target or target not found: %s"
                % root)

        lt = self[root]
        query_map = self.create_query_map()
        lt.set_filters(query_map, filters)
        lt.set_updates(query_map, new_values)
        return lt.update_data(query_map, db_engine)

    def insert(self, db_engine, values, root=None):
        """
        Inserts new record and returns # of rows inserted

        @param db_engine: Database handle
        @param values: Values for attributes to be inserted
        """
        if not values:
            raise InvalidInputError("Cannot insert record without values")

        self._validate_and_convert_input(values=values)

        if not root:
            root = next(iter(values)).split(".")[0]

        if root not in self:
            raise TargetNotFoundError(
                "Operation not supported on target or target not found: %s"
                % root)

        lt = self[root]
        query_map = self.create_query_map()
        return lt.insert_data(query_map, values, db_engine)

    def invalidate_select_cache(self):
        self.select_cache.clear()


class Listable(object):
    """
    A listable object, data of it will fill a table later.

    All descendants are instantiated and registered by order of module
    occurance, if parent_types is set (to prevent base class registration).

    This is a config only base class, instantiated only once each type.

    """

    primary_id = "id"  # the default for any master -> details filter
    master_params = []  # important params, e.g. ones to show by default
    parent_types = child_types = params = None
    # feature to specify props of params, like width, title:
    param_config = {}
    # default records per hit
    _limit = 100
    native_group = "generic"
    _paths_finished = False
    _format_specifier = "%s"

    # container(in which the listable is held) is set by Listables.register
    _container = None

    # Supported operators
    _ops = {
        "=": "=",
        "!=": "!=",
        "<": "<",
        "<=": "<=",
        ">=": ">=",
        ">": ">",
        "like": "like",
        "not like": "not like",
        "in": "in",
        "not in": "not in",
        "is": "is",
        "is not": "is not",
        "contains": "contains",
        "not contains": "not contains",
    }

    def __init__(self, container):
        self.typ = self.__class__.__name__
        self._container = container
        if self.parent_types is not None:
            container.paths.setdefault(self.native_group, {})[self] = OD()

    __repr__ = lambda self: "%s[%s]" % (self.typ, self.native_group)
    # res = '.'.join([k.__name__ for k in self.__class__.mro()[:-1]])

    @property
    def nfo(self):
        print("%s.attrs():" % self)
        res = pformat(self.attrs())
        print(res)

    def after_setup(self):
        pass  # customization hook

    def attrs(self, claims=None):
        """dict repr of the config.
        All non underscore attrs are returned - and become part of the config.
        claims contain e.g. roles or other security relevant infos.
        -> enforce restrictions here.
        """
        m = {}
        for k in dir(self):
            if not k.startswith("_") and not k == "nfo":
                v = getattr(self, k)
                if not hasattr(v, "func_name"):
                    m[k] = v
        return m

    # overwrite:
    def setup(self):
        if self.parent_types == None:
            # this is a base class and setup method was not overloaded.
            # any listable must define parent_types even like []
            self._container.pop(self.typ)

    def validate(self):
        """ custom hook"""
        pass

    def explore(self, API):
        """process start only action """
        self.params = OD()
        self.validate()  # potentially already preventing native exploration.
        self.explore_native(API)
        self.validate()
        for k, config in self.param_config.items():
            # for now only hammer over. later functions..:
            if k.startswith("count_"):
                config["type"] = "int"
            self.params.setdefault(k, {}).update(config)
            nf = config.get("native_func")
            if nf:
                native_funcs["%s.%s" % (self.typ, k)] = nf

        for p in self.master_params or ():
            if not p in self.params and not p.startswith("count_"):
                raise InternalError(
                    '%s (primary_id: %s): Master param "%s" not present in datasource'
                    % (self.typ, self.primary_id, p)
                )

    # ................................................................. filters
    def _update_filter_placeholders(self, query_map):
        regex = re.compile("%\((.+?)\)s")

        for param in query_map.get("filter_params", []):
            if not isinstance(param, basestring):
                continue

            match = regex.search(param)
            if match:
                query_map["filter_placeholders"].append(match.group(1))

    def _build_realized_filter(self, q_map, filters, tables):
        if not tables:
            tables.append(self.typ)

        if len(filters) == 1 and isinstance(filters[0], list):
            filters = filters[0]

        cond = ""
        pivot = None
        op = None
        for i, f in enumerate(filters):
            if f in self.logical_operators:
                pivot = i
                op = f
                break
        if pivot:
            left = self._build_realized_filter(q_map, filters[:pivot], tables)
            right = self._build_realized_filter(q_map, filters[pivot + 1 :], tables)
            cond = "(%s)" % " ".join([left, op, right])
        elif filters:
            # Handle nested single conditions(e.g. [[[["x", "=", 3]]]])
            if len(filters) == 1:
                return self._build_realized_filter(q_map, filters[0], tables)

            self.parse_condition(filters, tables)
            try:
                key, op, value = filters
                cond = self.build_condition(q_map, key, op, value)
            except ValueError:
                raise InvalidInputError(
                    "Condition is expected to be a 3-tuple of the form"
                    "(attribute, operand, value): %s" % str(filters)
                )

        return cond

    def realize_filters(self, filters, path_filters):
        q_map = self.prepare_filters(filters, path_filters)
        if not q_map:
            return None
        self.drop_filters_without_relation(q_map)
        q_map["list_type"] = self.typ
        filter_tables = []
        q_map["realized_filters"] = self._build_realized_filter(
            q_map, q_map["filters"], filter_tables
        )
        q_map["filter_tables"] = filter_tables
        q_map["tables"].extend(filter_tables)
        self._update_filter_placeholders(q_map)

        return q_map

    def get_realized_filters(self, query_map):
        return (
            query_map.get("realized_filters", None),
            tuple(query_map.get("filter_params", None)),
        )

    def has_lazy_filter(self, query_map):
        return True if query_map["filter_placeholders"] else False

    def set_filters(self, query_map, filters=None, path_filters=None):
        """
        Sets the filters in the query map
        @param query_map: Query map to work on
        @param filters: Filters as nested list
        @param path_filters: Additional filters to be ANDed to filters
        """
        if not query_map:
            raise InvalidInputError("Cannot set filters: No query map provided")

        filters = deepcopy(filters)
        path_filters = deepcopy(path_filters)

        if not filters:
            filters = []

        try:
            combined_filters = list(filters)
            if path_filters:
                combined_filters = [combined_filters]
                combined_filters.extend(path_filters)

            # if filters didn't change, do nothing
            if "filters" in query_map and query_map["filters"] == combined_filters:
                return

            # Clear filter params before adding new filters
            query_map["filter_params"] = []

            q_map = self.prepare_filters(filters, path_filters)
            if not q_map:
                return

            self.drop_filters_without_relation(q_map)

            query_map["list_type"] = self.typ
            query_map["filters"] = q_map["filters"]

            filter_tables = []
            query_map["realized_filters"] = self._build_realized_filter(
                query_map, query_map["filters"], filter_tables
            )
            query_map["filter_tables"] = filter_tables
            query_map["tables"].extend(filter_tables)

            self.build_query_filters_native(query_map)

            query_map["list_type"] = self.typ
            self._update_filter_placeholders(query_map)
        except (InvalidInputError, DataNotFoundError) as ex:
            raise ex
        except Exception as ex:
            raise InternalError("Cannot set filters: %s" % str(ex))

    def set_resultset(self, query_map, resultset):
        """
        Sets the result set in the query map
        @param query_map: Query map to work on
        @param resultset: Resultset as list
        """
        if not query_map:
            raise InvalidInputError("Cannot set resultset: No query map provided")

        if not resultset:
            raise InvalidInputError("Cannot set resultset: No resultset provided")

        try:
            # if resultset didn't change, do nothing
            if "show" in query_map:
                if resultset == query_map["show"]:
                    return

            query_map["resultset_tables"] = []
            if isinstance(resultset, basestring):
                resultset = lit_eval(resultset, key="show", into=list)
            elif isinstance(resultset, (tuple, list)):
                # 'kv' flag at the beginning?
                if resultset[0].startswith("kv"):
                    query_map["to_kv"] = resultset.pop(0)
                else:
                    query_map["to_kv"] = "kva"

            # replace c* with ['cid', 'cid2'..]:
            resultset = self.expand_wildcards(resultset)

            # post processors (like eval)
            sp = query_map["show_procs"] = []
            query_map["show"] = [
                self.parse_key(s, query_map["resultset_tables"], show_processors=sp)
                for s in resultset
            ]

            self.build_query_resultset_native(query_map)
            query_map["realized_show"] = query_map["show"]
            query_map["list_type"] = self.typ
        except InvalidInputError as ex:
            raise ex
        except Exception as ex:
            raise InternalError("Cannot set resultset: %s" % str(ex))

    def set_updates(self, query_map, new_values):
        """
        Sets updates in the query map
        @param query_map: Query map to work on
        @param new_values: New values for attributes to be updated
        """
        if not query_map:
            raise InvalidInputError("Cannot set updates: No query map provided")

        if not new_values:
            raise InvalidInputError("Cannot set updates: No updates provided")

        try:
            update_attributes = []
            update_params = []

            for key in iter(new_values):
                value = new_values[key]
                type_, attr = self.resolve_key(key)
                column = type_ + "." + attr
                self.validate_attribute(column)
                update_attributes.append(column + " = " + self._format_specifier)
                update_params.append(value)
            query_map["update_attributes"] = update_attributes
            query_map["update_params"] = update_params
        except InvalidInputError as ex:
            raise ex
        except Exception as ex:
            raise InternalError("Cannot set updates: %s" % str(ex))

    def _defs(self, s):
        if isinstance(s, basestring):
            s = (s, "asc")
        assert (
            isinstance(s, (list, tuple)) and len(s) == 2 and s[1] in ("asc", "desc")
        ), ("sort declaration failure: %s" % s)
        return s

    def _set_sort_order(self, query_map, sort):
        try:
            # Parse sort parameter
            if isinstance(sort, basestring):
                sort = lit_eval(sort, key="sort", into=list)

            try:
                sort = [self._defs(s) for s in sort]
            except AssertionError as err:
                raise InvalidInputError("Cannot set sort order: %s" % str(err))

            query_map["sort_tables"] = []
            attrs = []
            for key, sdir in sort:
                key = self.parse_key(key, query_map["sort_tables"])
                attrs.append((key, sdir))
            query_map["sort"] = attrs
        except InvalidInputError as ex:
            raise ex
        except Exception as ex:
            raise InternalError("Cannot set sort order: %s" % str(ex))

    def _set_group_by(self, query_map, group_by):
        try:
            query_map["group_by_tables"] = []
            attrs = []
            for key in group_by:
                key = self.parse_key(key, query_map["group_by_tables"])
                attrs.append(key)
            query_map["group_by"] = attrs

            group_by_attrs_not_in_show = set(attrs).difference(
                query_map.get("show", [])
            )
            if group_by_attrs_not_in_show:
                self.set_resultset(query_map, list(group_by_attrs_not_in_show))

        except InvalidInputError as ex:
            raise ex
        except Exception as ex:
            raise InternalError("Cannot set group by: %s" % str(ex))

    def set_query_options(self, query_map, group_by=None, sort=None):
        """
        Sets the query options
        @param query_map: Query map to work on
        @param sort: List of tuples specifying sort attribute with asc/desc
        @param group_by: List of attributes to group by
        """
        if not query_map:
            raise InvalidInputError("Cannot set query options: No query map provided")

        if not group_by:
            group_by = []

        group_by_changed = query_map.get("group_by", []) != group_by
        if group_by_changed:
            self._set_group_by(query_map, group_by)

        if not sort:
            sort = []

        sort_changed = query_map["sort"] != sort
        if sort_changed:
            self._set_sort_order(query_map, sort)

        if group_by_changed or sort_changed:
            self.build_query_options_native(query_map, sort_changed, group_by_changed)

        query_map["list_type"] = self.typ

    def build_query_tables(self, query_map):
        """
        Combine filter(first in the order as it has the root table),
        resultset and sort tables into query tables
        """
        new_tables = []
        new_tables.extend(query_map.get("filter_tables", []))
        new_tables.extend(query_map.get("resultset_tables", []))
        new_tables.extend(query_map.get("sort_tables", []))
        new_tables.extend(query_map.get("group_by_tables", []))

        # If no change in the tables, do nothing
        if (
            len(query_map["tables"]) == len(new_tables)
            and set(query_map["tables"]).symmetric_difference(new_tables) is None
        ):
            return

        seen = set()
        seen_add = seen.add
        query_map["tables"] = [x for x in new_tables if not (x in seen or seen_add(x))]
        self.build_query_tables_native(query_map)

    def drop_filters_without_relation(self, q_map):
        """
        now we remove(!) all filters for which we don't have a relation.
        e.g. Grand/<id>/Parent/<id>/Child, we can remove the Grandparent
        filter, if we anyway have the Parent filter (and we should not fail
        if there is not Child -> Grand Relation)
        """
        # TBD. think about nested stuff
        return

    def prepare_filters(self, filters, path_filters):
        """ convenience funcs
        parse a nested filters string into a structure
        we modify filters and return found meta data, like sql tables
        """
        f = filters or []
        if not isinstance(f, (list, tuple)):
            try:
                fe = lit_eval(f)
                if f[0] in ("[", "("):
                    # correct format, just was stringyfied:
                    f = fe
            except:
                f = parse_filter_str(f)
        if len(f) == 1:
            f = f[0]
        if path_filters:
            if f:
                f = [f]
            else:
                path_filters.pop(0)  # forget the 'and' then
            f.extend(path_filters)

        return {
            "filters": f,
            "show": [],
            "group_by": [],
            "sort": [],
            "tables": [],
            "filter_params": [],
            "filter_placeholders": [],
        }

    def scan_filters(self, filters, operation, tables=None):
        """ in place modifiction of filters for table types and ops """

        if not tables:
            tables = [self.typ]

        if len(filters) == 1 and isinstance(filters[0], list):
            filters = filters[0]

        pivot = None
        for i, f in enumerate(filters):
            if f in self.logical_operators:
                pivot = i
                break
        if pivot:
            self.scan_filters(filters[:pivot], operation, tables)
            self.scan_filters(filters[pivot + 1 :], operation, tables)
        elif filters:
            # Handle nested single conditions(e.g. [[[["x", "=", 3]]]])
            if len(filters) == 1:
                self.scan_filters(filters[0], operation, tables)
            else:
                operation(filters, tables)

        return {
            "tables": tables,
            "filters": filters,
            "filter_params": [],
            "filter_placeholders": [],
        }

    def parse_condition(self, cond, tables):
        """ inserting table names, replacing * with % and op then like
        table names not .table indirections but listable typ.
        """
        try:
            key, op, val = cond
        except ValueError:
            raise InvalidInputError(
                "Condition is expected to be a 3-tuple of the form"
                "(attribute, operand, value): %s" % str(cond)
            )
        if not isinstance(key, basestring):
            raise InvalidInputError("Invalid filter clause: %s" % str(cond))

        cond[0] = self.parse_key(key, tables)
        self.parse_condition_native(cond)

    def get_format_specifier(self, q_map, value):
        if isinstance(value, (list, tuple)):
            format_specifier = ",".join([self._format_specifier] * len(value))
            format_specifier = "(" + format_specifier + ")"
            q_map["filter_params"].extend(value)
        else:
            format_specifier = self._format_specifier
            q_map["filter_params"].append(value)

        return format_specifier

    def build_condition(self, q_map, key, op, value):
        cond = "%s %s %s" % (key, op, self.get_format_specifier(q_map, value))
        return cond

    def parse_key(self, key, tables, show_processors=None):
        """ altering the tables list based on keys in use
            returns (typ, key)
        """
        # Resolve key and add the type to tables if not already in
        typ, key = self.resolve_key(key)
        if not typ in tables:
            tables.append(typ)

        l = key.split(":", 1)
        if show_processors is not None:
            # we are parsing the show params. There can be configured ones
            # and ones in the current query, the latter have precedence:
            if len(l) == 1:
                pp = self._container[typ].params[key].get("post_process")
                if pp:
                    l.append(pp)
        else:
            if len(l) > 1:
                # he added a postprocessor in a filter or sort..:
                raise InvalidInputError(
                    "%s: Post processors only allowed for show params" % key
                )
        key = l[0]
        ret = ".".join((typ, key))

        # Validate attribute
        self.validate_attribute(ret)

        if len(l) > 1:
            # like ['cpe.props', 'eval']:
            l[0] = ret
            show_processors.append(l)

        return ret

    def resolve_key(self, key):
        """
        Resolves key
        For example:
        1. cpe resolves to its primary key i.e. cpe.cpeid
        2. cpeid resolves based on the type of current listable instance i.e. cpe.cpeid
        """
        tk = key.split(".")
        if len(tk) == 1:
            if tk[0] in self._container:
                tk = (tk[0], self._container[tk[0]].primary_id)
            else:
                tk = (self.typ, key)

        return tk

    def validate_attribute(self, attr):
        type_, attr_name_ = attr.split(".")

        if type_ not in self._container:
            raise InvalidInputError("Unknown attribute %s found" % (attr))

        if attr_name_ in self._container[type_].params:
            return True

        raise InvalidInputError("Unknown attribute %s found" % (attr))

    def parse_condition_operator(self, op):
        """ we just demand ops to be defined per list type, e.g. sql"""
        try:
            op = self._ops[op]
            return op
        except KeyError:
            raise InvalidInputError("Unsupported operator: %s" % op)

    def expand_wildcards(self, show):
        """ CPE.c*, User.U* into CPE.cid, CPE...."""
        ns = []
        for key in show:
            # Resolve key and validate attribute
            tk = self.resolve_key(key)

            if "*" in key:
                for kt in self._container[tk[0]].params:
                    if fnmatch(kt, tk[1]):
                        ns.append(".".join((tk[0], kt)))
            else:
                attr = ".".join((tk[0], tk[1]))

                # Validate attribute
                if not self.validate_attribute(attr):
                    raise InvalidInputError("Unknown attribute %s found" % attr)

                ns.append(attr)

        return ns

    def count_join_key(self, lt, ct):
        pt = [k for k in self._container[ct].parent_typss if k["type"] == lt]
        if not pt:
            raise InternalError("Cannot count %s, must have %s as parent" % (count, lt))
        return pt[0]["on"]

    def realize_meta(self, q_map, meta):
        if "cost" not in q_map:
            q_map["cost"] = 5
        show, tables, sort = meta["show"], q_map["tables"], meta["sort"]
        if show and isinstance(show, basestring):
            show = lit_eval(show, key="show", into=list)
        if show:
            # any to key value mapping switches at the beginning?
            if show[0].startswith("kv"):
                q_map["to_kv"] = show.pop(0)
        if not show:
            # ordered:
            show = self.params.keys()
        # replace c* with ['cid', 'cid2'..]:
        show = self.expand_wildcards(show)

        # any count.User ?
        i, counts, sh = 0, [], []
        while show:
            p = show.pop(0)
            if p.startswith("count_"):
                # we replace count.User with EID if EID is the parent join key
                # for self with User, so that we have the value for the later
                # counting:
                # child type:
                ct = p.split("_", 1)[1]
                on = self.count_join_key(self.typ, ct)
                p, ctk = on[1], on[0]
                counts.append((i, [ct, ctk]))
            sh.append(p)
            i += 1
        show = sh
        q_map["counts"] = counts

        # post processors (like eval)
        sp = q_map["show_procs"] = []
        q_map["show"] = [self.parse_key(s, tables, show_processors=sp) for s in show]
        q_map["realized_show"] = q_map["show"]
        # sorts:
        if sort and isinstance(sort, basestring):
            sort = lit_eval(sort, key="sort", into=list)
        if not sort:
            sort = []
        sort = [self._defs(s) for s in sort]
        # configured sorts?
        sort.extend([self._defs(s) for s in getattr(self, "sort", ())])
        r = []
        for key, sdir in sort:
            key = self.parse_key(key, tables)
            r.append((key, sdir))
        q_map["sort"] = r
        self.build_native_groups(q_map)
        q_map["native_joins"] = {}
        for ng, lts in q_map["native_groups"].items():
            # all same native group by definition, so we take the first:
            self._container[self.typ].build_joins_native(q_map)
            self.realize_meta_native(q_map, meta)
        # now join non native groups:
        # TODO

    def build_native_groups(self, q_map):
        """ find those listables within the same native type """
        ngs = {}
        for t in q_map["tables"]:
            ng = self._container[t].native_group
            # no objects into q_map:
            ngs.setdefault(ng, []).append(t)
            if len(ngs) == 1:
                q_map["root_group"] = ng
        q_map["native_groups"] = ngs

    def add_master_params(self, query_map, overwrite=False):
        """
        Traverses through all tables in the query_map and
        add their master params to show parameters
        Assumption: tables/joins already exists in query_map
        """
        show_params = []

        if not overwrite:
            show_params = list(query_map.get("show", []))

        for table in query_map["tables"]:
            for x in self._container[table].master_params:
                param = table + "." + x
                if param not in show_params:
                    show_params.append(param)

        self.set_resultset(query_map, show_params)

    # inheritance hooks
    def prepare_filters_native(self, filters):
        return {"filters": f}

    def realize_meta_native(self, q_map, meta):
        return q_map

    def build_joins_native(self, q_map):
        return

    def build_query_resultset_native(self, q_map):
        return


# --------------------------------------------------------------------------- #
# -------------------------- SQL Listable Adapter --------------------------- #
# --------------------------------------------------------------------------- #
class BaseSqlListable(Listable):
    table = None
    native_group = "sql"
    _excl_params = ()  # underscore, since not relevant for clients
    logical_operators = ("and", "or")
    sql_to_generic_types = {
        "BIGINT": "int",
        "BINARY": "str",
        "BIT": "bit",
        "BLOB": "str",
        "BOOLEAN": "bool",
        "CHAR": "str",
        "DATE": "date",
        "DATETIME": "datetime",
        "DECIMAL": "float",
        "DOUBLE": "float",
        "ENUM": "str",
        "FLOAT": "float",
        "INTEGER": "int",
        "LONGBLOB": "str",
        "LONGTEXT": "str",
        "MEDIUMBLOB": "str",
        "MEDIUMINT": "int",
        "MEDIUMTEXT": "str",
        "NCHAR": "str",
        "NUMERIC": "float",
        "NVARCHAR": "str",
        "REAL": "float",
        "SET": "set",
        "SMALLINT": "int",
        "TEXT": "str",
        "TIME": "time",
        "TIMESTAMP": "ts",
        "TINYBLOB": "str",
        "TINYINT": "int",
        "TINYTEXT": "str",
        "VARBINARY": "str",
        "VARCHAR": "str",
        "YEAR": "int",
    }

    @staticmethod
    def generic_type(sql_type):
        sql_type = sql_type.upper()
        return BaseSqlListable.sql_to_generic_types.get(sql_type, "unknown")

    def __init__(self, container):
        Listable.__init__(self, container)
        self.child_types = []
        if isinstance(self.parent_types, dict):
            self.parent_types = [self.parent_types]

    def set_child_types(self, svc):
        for pd in svc.parent_types:
            typ, on = pd["type"], pd["on"]
            if isinstance(on, basestring):
                # shared keyname:
                pd["on"] = on = (on, on)

            try:
                p = self._container[pd["type"]]
            except KeyError as err:
                raise InvalidInputError(
                    "Cannot mark %s as child of %s: %s not found"
                    % (self.typ, str(err), str(err))
                )

            # reverse for parent to child
            p.child_types.append({"type": svc.typ, "on": (on[1], on[0])})

    def setup(self):
        if self.parent_types == None:
            # this is a base class and setup method was not overloaded.
            self._container.pop(self.typ)
            return
        self.set_child_types(self)
        # this id is always needed. if not in master_params we append it.
        # if not master params we assume its in the columsn (all params)
        if self.primary_id not in self.master_params:
            self.master_params.append(self.primary_id)

    def set_format_specifier(self, API):
        self._format_specifier = "%s"

    def explore_native(self, API):
        self.set_format_specifier(API)
        self.set_params(API)

    def build_query_tables_native(self, query_map):
        query_map["native_joins"] = {}
        self.build_native_groups(query_map)
        for ng, lts in query_map["native_groups"].items():
            # all same native group by definition, so we take the first:
            self._container[self.typ].build_joins_native(query_map)

        # Get table/join boundaries
        fq = query_map["full_query"]
        from_index = fq.index("FROM")
        where_index = fq.index("WHERE")

        # Delete old tables/joins
        del fq[from_index + 1 : where_index]

        # Insert new tables/joins
        root_type = self.typ
        root = self._container[root_type]
        ts = ()
        ts += ("%s AS `%s`" % (root.table, root_type),)
        native_joins = query_map["native_joins"][self.native_group]
        for i, joins in enumerate(native_joins):
            t1, t2 = joins
            l1, l2 = self._container[t1], self._container[t2]

            # LEFT JOIN the root table(the one on the left to the first
            # one is always the root)
            ts += ("%s JOIN %s AS `%s`" % (
                'LEFT' if i==0 else 'INNER', l2.table, t2),)

            # on ?
            ts += (self.get_join_on(l1, l2),)
        fq[from_index + 1 : from_index + 1] = ts

    def build_query_filters_native(self, query_map):
        # Get filter boundaries
        fq = query_map["full_query"]
        where_index = fq.index("WHERE")

        # Delete old filters
        if "ORDER BY" in fq:
            end_index = fq.index("ORDER BY")
            del fq[where_index + 1 : end_index]
        else:
            del fq[where_index + 1 :]

        # Insert new filters
        fq.insert(
            where_index + 1,
            query_map["realized_filters"] if query_map["realized_filters"] else "1 = 1",
        )

        # (Re)Build tables
        self.build_query_tables(query_map)

    def build_query_resultset_native(self, query_map):
        # Get resultset boundaries
        fq = query_map["full_query"]
        select_index = fq.index("SELECT")
        from_index = fq.index("FROM")

        # Delete old resultset
        del fq[select_index + 1 : from_index]

        # Insert new filters
        c = ()
        for s in query_map["show"]:
            c += (self.native_func(s),)
        c = (", ".join(c),)
        fq[select_index + 1 : select_index + 1] = c

        # (Re)Build tables
        self.build_query_tables(query_map)

    def build_query_options_native(
        self, query_map, sort_changed=False, group_by_changed=False
    ):

        fq = query_map["full_query"]

        # Build GROUP BY clause
        if group_by_changed:
            # If 'GROUP BY' clause already exists, knock it off
            if "GROUP BY" in fq:
                group_by_index = fq.index("GROUP BY")
                if "ORDER BY" in fq:
                    order_by_index = fq.index("ORDER BY")
                    del fq[group_by_index:order_by_index]
                else:
                    del fq[group_by_index:]

            # Insert 'GROUP BY' clause
            ts = ", ".join(query_map.get("group_by", []))
            if ts:
                fq.extend(("GROUP BY", ts))

        # Build ORDER BY clause
        if sort_changed:
            # If 'ORDER BY' clause already exists, knock it off
            if "ORDER BY" in fq:
                order_by_index = fq.index("ORDER BY")
                del fq[order_by_index:]

            # Insert 'ORDER BY' clause
            ts = ", ".join(
                ["%s %s" % (self.native_func(k), d) for k, d in query_map["sort"]]
            )
            if ts:
                fq.extend(("ORDER BY", self.native_func(ts)))

        # (Re)Build tables if sort parameters changed
        self.build_query_tables(query_map)

    def validate(self):
        assert isinstance(
            self.table, basestring
        ), "table parameter must be string, is %s" % type(self.table)

    def run(self, runner, sql, params=None):
        return runner(sql, params) if params else runner(sql)

    def set_params(self, API):
        raise NotImplementedError(
            "BaseSqlListable is an abstract SQL-style Listable,"
            "use one of the concrete implementation"
        )

    def parse_condition_native(self, cond):
        # Replace wildcard * with %
        if cond[1] in ["like", "not like"]:
            # Don't sanitize lazy filter placeholders
            if cond[2] and not re.match('\%\([a-zA-Z0-9_]+\)s', cond[2]):
                cond[2] = sanitize_input(cond[2], "engine")

        # Handle None value(RHS)
        if cond[2] is None:
            # Fix operators
            if cond[1] == "=":
                cond[1] = "is"
            elif cond[1] == "!=":
                cond[1] = "is not"

        # Validate operator
        cond[1] = self.parse_condition_operator(cond[1])

    def build_condition(self, q_map, key, op, value):
        cond = "%s %s %s" % (
            self.native_func(key),
            op,
            self.get_format_specifier(q_map, value),
        )
        return cond

    def native_func(self, s):
        """ supporting 'native_func':
            'CAST(Left(Ticket.serviceid, 6) AS UNSIGNED)'"""
        return native_funcs.get(s, s)

    def build_joins_native(self, q_map):
        """ we build now the join pairs
        we have all paths between typs in `paths` dict
        Complication is though that we must avoid double joins

        Strategy: for each table get the vias to root and build join pairs
        remember though what is already joined.
        """
        # all possible paths (any cost):
        npaths = self._container.paths[self.native_group]
        # all tables involved in filters & shows:
        tables = q_map["native_groups"][self.native_group]
        pairs = []
        root_type = self.typ
        root = self._container[self.typ]
        # helper to see what is already joined:
        have = [root.typ]
        for i, t in enumerate(tables):
            if t == root_type:
                continue
            if i > q_map["cost"]:
                raise DataNotFoundError("Cost exception!")
            lt = self._container[t]
            via = npaths[self._container[t]].get(root, {}).get("via")
            if via == None:
                raise DataNotFoundError(
                    "No Relation buildable between %s and %s" % (lt, root)
                )
            p = root_type
            for vt in reversed(via):
                v = vt.typ
                if v in have:
                    p = v
                    continue
                pairs.append([p, v])
                have.append(v)
                p = v
        q_map["native_joins"][self.native_group] = pairs

    def realize_meta_native(self, q_map, meta):
        func = self.native_func
        limit = q_map["limit"] = meta.get("limit") or self._limit
        offset = q_map["offset"] = meta.get("offset", 0)
        native_joins = q_map["native_joins"][self.native_group]
        # build the query:
        q = ("SELECT",)
        c = ()
        for s in q_map["show"]:
            c += (func(s),)
        q += (", ".join(c),)
        q += ("FROM",)
        tables = q_map["tables"]
        root_type = self.typ
        root = self._container[root_type]
        ts = ()
        ts += ("%s AS `%s`" % (root.table, root_type),)
        for i, joins in enumerate(native_joins):
            t1, t2 = joins
            l1, l2 = self._container[t1], self._container[t2]

            # LEFT JOIN the root table(the one on the left to the first
            # one is always the root)
            ts += ("%s JOIN %s AS `%s`" % (
                'LEFT' if i==0 else 'INNER', l2.table, t2),)

            # on ?
            ts += (self.get_join_on(l1, l2),)
        q += ts
        rf = q_map.get("realized_filters")
        if rf:
            q += ("WHERE", rf)
        ts = ", ".join(["%s %s" % (func(k), d) for k, d in q_map["sort"]])
        if ts:
            q += ("ORDER BY", func(ts))
        q += ("LIMIT %s" % limit,)
        if offset:
            q += ("OFFSET %s" % offset,)
        q_map["full_query"] = q

    def get_join_on(self, l1, l2):
        """ l1, l2 listables """
        t1, t2 = l1.typ, l2.typ

        on = None
        for rels in l1.child_types, l1.parent_types:
            for rel in rels:
                if t2 == rel["type"]:
                    on = rel["on"]
        if on is None:
            raise InternalError("No Relation found between %s and %s" % (t1, t2))
        func = self.native_func
        return "ON %s = %s" % (func("%s.%s" % (t1, on[0])), func("%s.%s" % (t2, on[1])))

    def _resolve_params(self, query_params, lazy_filter):
        if query_params is None:
            query_params = []
        if lazy_filter is None:
            lazy_filter = {}

        # Iterate over filter params and resolve placeholders
        resolved_params = []
        for param in query_params:
            try:
                resolved_params.append(
                    param % lazy_filter if isinstance(param, basestring) else param
                )
            except (TypeError, ValueError) as err:
                # There's just an unescaped % in the filter param
                resolved_params.append(param)
            except KeyError as err:
                msg = "Cannot resolve lazy filter: Key %s not found" % str(err)
                raise InvalidInputError(msg)

        return resolved_params

    def _resolve_filter_params(self, query_map, lazy_filters):
        """
        Resolve filter parameters with lazy filter values
        Hint: %% should be used as SQL wildcard in the filters
        """
        return self._resolve_params(query_map["filter_params"], lazy_filters)

    def _resolve_update_params(self, query_map, lazy_filters):
        """
        Resolve update parameters with lazy filter(the name's an old relic)
        values
        """
        return self._resolve_params(query_map["update_params"], lazy_filters)

    def _execute(self, query_map, API):
        """
        Executes query from the query map and returns resultset

        @param query_map: Query map to be used
        @param API: Database handle
        """
        runner = get_api(API)
        res = self.run(runner, query_map["raw_sql"], tuple(query_map["raw_sql_params"]))
        return res

    def get_data(self, query_map, API):
        """
        Returns the data in the form of a list by executing the query from the
        query map

        @param query_map: Query map to be used
        @param API: Database handle
        """
        res = self._execute(query_map, API)
        # simply way faster for any mutating op on the data,
        # e.g. kv, e.g. counts:
        res = [list(row) for row in res]
        return res

    def delete_data(self, query_map, API):
        """
        Deletes rows matching filter in the query map and returns # of rows
        deleted

        @param query_map: Query map to be used
        @param API: Database handle
        """
        res = self._execute(query_map, API)
        return res.rowcount

    def update_data(self, query_map, API):
        """
        Updates rows matching filter in the query map and returns # of rows
        updated

        @param query_map: Query map to be used
        @param API: Database handle
        """
        res = self._execute(query_map, API)
        return res.rowcount

    def insert_data(self, query_map, API):
        """
        Inserts rows and returns # of rows

        @param query_map: Query map to be used
        @param API: Database handle
        """
        res = self._execute(query_map, API)
        return res.rowcount

    def count_val(self, pt, key, val, API):
        """ count occurrance of ourselves when key=val """
        if isinstance(val, basestring):
            val = '"%s"' % val

        l = (self.table, self.typ, self.native_func("%s.%s" % (self.typ, key)), val)

        res = self.run(get_api(API), "SELECT COUNT(*) FROM %s as %s WHERE %s=%s" % l)

        return res[0][0]

    def get_count(self, query_map, API):
        """
        Returns the count of rows matching filters in the query map
        SELECT COUNT(*) FROM (<query>) x
        @param query_map: Query map to be used
        @param API: Database handle
        """
        res = self._execute(query_map, API)
        res = [list(row) for row in res]

        return res[0][0] if len(res) == 1 and len(res[0]) == 1 else res


class SqlListable(BaseSqlListable):
    def __init__(self, container):
        super(SqlListable, self).__init__(container)
        self._format_specifiers = {"qmark": "?", "format": "%s"}
        self._sqlalchemy_tables = {}
        try:
            self._meta = sqlalchemy.MetaData()
        except AttributeError as err:
            raise InternalError(
                "sqlalchemy not found, " "its a dependency for SqlListable"
            )

    def set_format_specifier(self, API):
        try:
            self._format_specifier = "%s"
            self._format_specifier = self._format_specifiers.get(
                API.dialect.paramstyle, "%s"
            )
        except AttributeError as err:
            raise InternalError(
                "Cannot determine paramstyle for sqlalchemy"
                "engine. SqlListable needs sqlalchemy engine"
            )

    def set_params(self, API):
        try:
            warnings.filterwarnings('ignore', 'Unknown schema content:.*PARTITION.*')
            self._sqlalchemy_tables[self.table] = sqlalchemy.Table(
                self.table, self._meta, autoload=True, autoload_with=API
            )

            for col in self._sqlalchemy_tables[self.table].columns:
                self.params[col.name] = {
                    "type": SqlListable.generic_type(col.type.__class__.__name__),
                    "idx": col.index is not None,
                    "title": titleize(col.name).strip(),
                    "max_width": getattr(col.type, "length", 0)
                    or getattr(col.type, "display_width", 0)
                    or 0,
                }

                # max_width = bytes allowed for fixed size columns, it'll vary
                # in case of multi-byte characters
                # For example, TEXT with utf8mb4 character set can accommodate
                # from 16383 upto 65535 characters
                # Hence, max_width is only indicative of the width in case of
                # "one byte per character" characters(e.g. latin1)
                if col.type.__class__.__name__ == "ENUM":
                    self.params[col.name]["values"] = col.type.enums
                elif col.type.__class__.__name__ == "SET":
                    self.params[col.name]["values"] = col.type.values
                    self.params[col.name]["max_width"] = (
                        sum(len(val) for val in col.type.values)
                        + len(col.type.values)
                        - 1
                    )
                elif col.type.__class__.__name__ in ["TINYTEXT", "TINYBLOB"]:
                    self.params[col.name]["max_width"] = 255
                elif col.type.__class__.__name__ in ["TEXT", "BLOB"]:
                    self.params[col.name]["max_width"] = 65535
                elif col.type.__class__.__name__ in ["MEDIUMTEXT", "MEDIUMBLOB"]:
                    self.params[col.name]["max_width"] = 16777215
                elif col.type.__class__.__name__ in ["LONGTEXT", "LONGBLOB"]:
                    self.params[col.name]["max_width"] = 4294967295

        except AttributeError as err:
            raise InternalError("Error exploring data source: %s" % str(err))

    def build_condition(self, q_map, key, op, value):
        if op == "contains":
            cond = "FIND_IN_SET(%s, %s)" % (
                self.get_format_specifier(q_map, value),
                self.native_func(key),
            )
        elif op == "not contains":
            cond = "NOT FIND_IN_SET(%s, %s)" % (
                self.get_format_specifier(q_map, value),
                self.native_func(key),
            )
        else:
            cond = "%s %s %s" % (
                self.native_func(key),
                op,
                self.get_format_specifier(q_map, value),
            )

        return cond

    def get_data(self, query_map, API, limit=100, offset=0, lazy_filter=None):
        """
        Returns the data in the form of a list by executing the query from the
        query map

        @param query_map: Query map to be used
        @param API: Database handle
        @param limit: Limit on the data to be fetched(None means fetch all)
        @param offset: Offset from which the next records to be fetched
        @param lazy_filter: Values to resolve lazy filters
        """

        if not (query_map["filters"] or query_map["show"]):
            query_map["list_type"] = self.typ
            query_map.setdefault("tables", []).append(self.typ)

        # If no show parameters in the query map, use master params
        if "show" not in query_map or not query_map["show"]:
            self.add_master_params(query_map)

        sql = list(query_map["full_query"])
        additional_params = []

        sql = " ".join(sql)
        sql = sql.strip()
        if "LIMIT" in sql:
            sql = sql[0 : sql.index("LIMIT")]

        if limit is not None:
            try:
                sql += " LIMIT %d OFFSET %d" % tuple(
                    [int(limit), int(offset) if offset is not None else 0]
                )
            except TypeError as err:
                raise InvalidInputError("limit and offset need to be integers")

        # Assemble query params
        query_params = self._resolve_filter_params(query_map, lazy_filter)

        query_map["raw_sql"] = sql
        query_map["raw_sql_params"] = query_params
        return super(SqlListable, self).get_data(query_map, API)

    def delete_data(self, query_map, API, lazy_filter=None):
        """
        Deletes rows matching filter in the query map and returns # of rows
        deleted

        @param query_map: Query map to be used
        @param API: Database handle
        @param lazy_filter: Values to resolve lazy filters
        """

        # If 'ORDER BY' clause already exists, knock it off
        fq = query_map["full_query"]
        sql = " ".join(fq[0 : fq.index("ORDER BY")] if "ORDER BY" in fq else fq)

        # Replace SELECT with DELETE
        sql = sql[sql.index("FROM") :]
        sql = "DELETE " + query_map["list_type"] + " " + sql

        # Assemble query params
        query_params = self._resolve_filter_params(query_map, lazy_filter)

        query_map["raw_sql"] = sql
        query_map["raw_sql_params"] = query_params
        return super(SqlListable, self).delete_data(query_map, API)

    def update_data(self, query_map, API, lazy_filter=None):
        """
        Updates rows matching filter in the query map and returns # of rows
        updated

        @param query_map: Query map to be used
        @param API: Database handle
        @param lazy_filter: Values to resolve lazy filters
        """
        # If 'ORDER BY' clause already exists, knock it off
        try:
            fq = query_map["full_query"]
            if "ORDER BY" in fq:
                del fq[fq.index("ORDER BY") :]

            # Replace SELECT with UPDATE
            sql_tables = " ".join(fq[fq.index("FROM") + 1 : fq.index("WHERE")])
            sql_filters = " ".join(fq[fq.index("WHERE") :])
            sql = (
                "UPDATE "
                + sql_tables
                + " SET "
                + ",".join(query_map["update_attributes"])
                + " "
                + sql_filters
            )
        except KeyError as err:
            raise InternalError(
                "Expected set_filters and set_updates before update_data"
            )

        # Assemble query params
        query_params = self._resolve_update_params(
            query_map, lazy_filter
        ) + self._resolve_filter_params(query_map, lazy_filter)

        query_map["raw_sql"] = sql
        query_map["raw_sql_params"] = query_params
        return super(SqlListable, self).update_data(query_map, API)

    def get_count(self, query_map, API, lazy_filter=None, wrap=False):
        """
        Returns the count of rows matching filters in the query map
        @param query_map: Query map to be used
        @param API: Database handle
        @param wrap: If True, the query will be wrapped as follows
            SELECT COUNT(*) FROM (<query>) x
            Use case: Queries combined with set operators like UNION
        """

        # If 'ORDER BY' clause already exists, knock it off as it doesn't
        # work with the subquery
        fq = query_map["full_query"]
        sql = " ".join(fq[0 : fq.index("ORDER BY")] if "ORDER BY" in fq else fq)

        query = sql.split(" ")

        # Drop LIMIT
        if "LIMIT" in query:
            del query[query.index("LIMIT") :]

        # If no filters and no show then set the table in the query
        if not query_map.get("tables", None):
            del query[query.index("FROM") + 1 : query.index("WHERE")]
            query.insert(query.index("FROM") + 1, str(self.table + " AS " + self.typ))
            query_map["list_type"] = self.typ
            query_map["tables"] = [self.table]

        if wrap:
            count_query = "SELECT COUNT(*) FROM (%s) x" % " ".join(query)
        else:
            if query_map.get("group_by", None):
                query[query.index("SELECT") + 1] += ",COUNT(*)"
            else:
                del query[query.index("SELECT") + 1 : query.index("FROM")]
                query.insert(query.index("SELECT") + 1, "COUNT(*)")

            count_query = " ".join(query)
            query_map.setdefault("realized_show", []).append("count")

        # Assemble query params
        query_params = self._resolve_filter_params(query_map, lazy_filter)

        query_map["raw_sql"] = count_query
        query_map["raw_sql_params"] = query_params
        return super(SqlListable, self).get_count(query_map, API)

    def insert_data(self, query_map, values, API):
        """
        Inserts data and returns # of rows inserted

        @param query_map: Query map to be used
        @params values: row to be inserted
        @param API: Database handle
        """
        if not values:
            raise InvalidInputError("Cannot insert: No values provided")

        sql_query = "INSERT INTO %s(%s) VALUES(%s)" % (
            self.table,
            ",".join(self.resolve_key(k)[1] for k in values.keys()),
            ",".join(self._format_specifier for v in range(len(values))),
        )

        query_map["raw_sql"] = sql_query
        query_map["raw_sql_params"] = values.values()
        return super(SqlListable, self).insert_data(query_map, API)


class MySqlListable(SqlListable):
    def set_format_specifier(self, API):
        self._format_specifier = "%s"

    def set_field_widths(self, runner, cols):
        """
        now find max widths for views, dep. on content:
        (wrong if after this (process start) the longest content is inserted)
        but this is kinda expensiv. maybe do at counts building,
        periodically?
        """
        len_func = {"str": "CHAR_LENGTH", "int": "LENGTH", "datetime": "LENGTH"}
        sh = ", ".join(
            ["Max(%s(%s))" % (len_func[v["type"]], k) for k, v in self.params.items()]
        )
        sql = " ".join(
            ("SELECT", sh, "FROM", "(SELECT * FROM", self.table, "LIMIT 1000) as X")
        )
        res = next(iter(self.run(runner, sql)))
        for i in xrange(len(res)):
            w = res[i]
            if w:
                w = res[i] + 2
            self.params[cols[i][0]]["width"] = w

    def set_params(self, API):
        """ explore the table """
        runner = get_api(API)
        res = self.run(runner, "show columns from %s" % self.table)
        # tupleize: [('servicetype', ('servicetype', 'char', 'NO', 'PRI'...)),
        cols = sorted(
            [
                (c[0], c)
                for c in res
                if not c[0] in self._excl_params and MySqlListable.generic_type(c[1])
            ]
        )
        for key, defs in cols:
            typ = MySqlListable.generic_type(defs[1])
            self.params[key] = {
                "type": typ,
                "idx": defs[3] != "",
                "title": titleize(key).strip(),
            }
        self.set_field_widths(runner, cols)


class SqliteListable(BaseSqlListable):
    def set_format_specifier(self, API):
        self._format_specifier = "?"

    def set_params(self, API):
        """ explore the table """
        runner = get_api(API)
        print(self.table, "!")
        res = self.run(runner, "pragma table_info(%s)" % str(self.table))
        cols = sorted(
            [
                (c[1], c)
                for c in res
                if not c[1] in self._excl_params and SqliteListable.generic_type(c[2])
            ]
        )

        for key, defs in cols:
            typ = SqliteListable.generic_type(
                defs[2][: defs[2].index("(")] if "(" in defs[2] else defs[2]
            )
            self.params[key] = {
                "type": typ,
                "idx": defs[5] == 1,
                "title": titleize(key).strip(),
                "width": int(defs[2][defs[2].index("(") + 1 : defs[2].index(")")])
                if "(" in defs[2]
                else 0,
            }


# ----------------------------------------------------------- Simulation Tools
class SimulListable:
    """ mixin for headless simulations"""

    def run(self, *a, **kw):
        return []

    def set_params(self, *a, **kw):
        if not self.master_params:
            self.master_params.append(self.primary_id)
        t = "title"
        for p in self.master_params:
            self.params[p] = {"type": "str", "width": 10, t: p, "idx": True}


class SqlListableSimul(SimulListable, SqlListable):
    """ simulate presence of tables w/o having a DB.
        Good to check query building from arbitrary complex config

    This one will deliver SQL exeptions at live results fetching, since others
    will run 'real' sql and our table is not present.
    BUT you see the generated queries.
    """

    pass
