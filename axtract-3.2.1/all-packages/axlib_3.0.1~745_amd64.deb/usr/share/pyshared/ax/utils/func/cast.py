from ax.utils.func.filters import is_str, is_simple

def tpl(s, sep=None, conv_iterables=False):
    '''
    # Simple Param to Iterable Tuple

    Often we want to iterate over user provided facts but allow the user to enter
    a single fact only:

        for verb in tpl(user_entry.get('allowed_verbs')): ...

    # Params
    - sep(str): Seperator to cut strings
    - conv_iterables(bool): If set we also convert types which are already
      iterable to tuples


    '''
    if is_simple(s):
        if is_str(s) and sep:
            return tuple([p.strip() for p in s.split(sep)])
        return (s,)
    if conv_iterables:
        # TODO, needed?
        raise NotImplemented
    return () if s is None else s

