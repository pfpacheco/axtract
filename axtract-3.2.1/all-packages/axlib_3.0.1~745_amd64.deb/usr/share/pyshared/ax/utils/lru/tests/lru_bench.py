#!/usr/bin/python -OttO
from __future__ import print_function

import sys
import timeit

def run():
    intensity = 1
    amount = 10**6 * intensity
    print ("\tbenchmarking random number generation (just for comparison)", end='')
    sys.stdout.flush()
    setup_nop = "import random"
    code_nop = """
item = random.randint(0, %s - 1)
if random.getrandbits(1):
    pass
else:
    pass
""" % 4242
    taken = timeit.Timer(code_nop, setup=setup_nop).timeit(number=amount)
    print (" %3.5f seconds. This time will be subtracted from following tests" % (taken))
    subtractor = taken


    for classname in ("LRUCache", "ExpiringLRUCache"):
        print ("benchmarking %s" % classname)

        """
        amount = 10**6 * intensity
        print ("\tGetting non-existant entry...", end='')
        taken = timeit.Timer("cache.get('foo')", setup="from ax.utils.lru import %s; cache=%s(10)" % (classname, classname)).timeit(number=amount)
        print (" %3.5f seconds (%i per second)" % (taken, int(amount/taken)))

        amount = 10**7 * intensity
        print ("\tGetting existing entry...", end='')
        taken = timeit.Timer("cache.get('foo')", setup="from ax.utils.lru import %s; cache=%s(10); cache.put('foo', 'bar')" % (classname, classname)).timeit(number=amount)
        print (" %3.5f seconds (%i per second)" % (taken, int(amount/taken)))

        print ("\tReputting existing item...", end='')
        amount = 10**6 * intensity
        taken = timeit.Timer("cache.put('foo', 'bar')", setup="from ax.utils.lru import %s; cache=%s(10)" % (classname, classname)).timeit(number=amount)
        print (" %3.5f seconds (%i per second)" % (taken, int(amount/taken)))
        """


        for cachesize, itemamount in [
                (10**4, 5 * 10**3), (10**4, 10**4), (10**4, 2 * 10**4), (10**4, 10 * 10**4),
                (10**6, 5 * 10**5), (10**6, 10**6), (10**6, 2 * 10**6), (10**6, 10 * 10**6)]:

            print ("\tRandomly putting/getting %s items into cache of size %s..." % (itemamount, cachesize), end='')
            setup = """
import random
from ax.utils.lru import %s
cache=%s(%s)
# fill the cache
for item in xrange(%s):
    cache.put(item, item)
""" % (classname, classname, cachesize, itemamount)
            code = """
item = random.randint(0, %s)
if random.getrandbits(1):
    cache.get(item)
else:
    cache.put(item, item)
""" % (itemamount,)
            # adjust by $subtractor since random number generator uses considerable CPU
            taken = timeit.Timer(code, setup=setup).timeit(number=amount) - subtractor
            print (" %3.5f seconds (%i per second)" % (taken, int(amount/taken)))



if __name__ == "__main__":
    run()
