#!/usr/bin/python -tt
import ax.utils.six.moves.queue as Queue
import threading
import time
import unittest2

import ax.utils.async_db_writer as async_db_writer
from ax.utils.async_db_writer import AsyncWriter

try:
    import MySQLdb
except ImportError:
    mysql_available = False
else:
    mysql_available = True


class TestAsyncWriter(unittest2.TestCase):
    @unittest2.skipIf(not mysql_available, "Cannot run without MySQLdb")
    def test_instantiate_with_defaults(self):
        db_config = {}
        num_thread_before = threading.active_count()

        writer = AsyncWriter(db_config)

        # Threads must be started on instantiation.
        num_thread_after = threading.active_count()
        expected = num_thread_before + async_db_writer.DEFAULT_NUM_WORKERS
        self.assertEqual(num_thread_after, expected)

        # Threads must terminate on shutdown.
        writer.shutdown()
        self.assertEqual(num_thread_before, threading.active_count())

    def test_instantiate_with_config(self):
        db_config = {}
        num_workers = async_db_writer.DEFAULT_NUM_WORKERS + 1
        queue_length = async_db_writer.DEFAULT_QUEUE_LENGTH + 1
        config = {'num_workers': num_workers,
                'queue_length': queue_length,
                'db_type': "lazy"}
        num_thread_before = threading.active_count()

        writer = AsyncWriter(db_config, config=config)
        try:
            # Threads must be started on instantiation.
            num_thread_after = threading.active_count()
            expected = num_thread_before + num_workers
            self.assertEqual(num_thread_after, expected)

            # The queue must be as long as desired.
            for count in range(queue_length):
                writer._query_queue.put_nowait("foo")
            # Queue should be able to contain all given items.
            self.assertEqual(writer._query_queue.qsize(), queue_length)

            # Queue should be full, no new entry should be added.
            self.assertRaises(Queue.Full, writer._query_queue.put_nowait, "foo")
        finally:
            writer.shutdown()
            self.assertEqual(num_thread_before, threading.active_count())

    def test_queue(self):
        """Workers should be taking items from the queue"""
        queue_length = 10
        config = {'queue_length': queue_length, 'db_type': "eager"}
        num_thread_before = threading.active_count()
        writer = AsyncWriter({}, config=config)

        try:
            for count in range(3 * queue_length):
                time.sleep(0.01)
                # If workers do not take items off the queue, this will eventually
                # throw an exception.
                writer._query_queue.put_nowait("foo")
        finally:
            writer.shutdown()
            self.assertEqual(num_thread_before, threading.active_count())

    def test_put(self):
        """put() on AsyncWriter must really put, but never except or block"""
        queue_length = 1
        config = {'queue_length': queue_length, 'db_type': "lazy"}
        num_thread_before = threading.active_count()
        writer = AsyncWriter({}, config=config)

        try:
            for count in range(3 * queue_length):
                # Queue will get full, but put() must not except
                writer.put("foo")

            # The "foo" must really be in the queue
            self.assertEqual(writer._query_queue.get_nowait(), "foo")
        finally:
            writer.shutdown()
            self.assertEqual(num_thread_before, threading.active_count())

if __name__ == "__main__":
    unittest2.main()

