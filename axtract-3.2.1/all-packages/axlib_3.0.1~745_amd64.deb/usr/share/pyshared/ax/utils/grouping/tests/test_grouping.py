import unittest2
import time
import os
import sys

PY3 = sys.version_info[0] > 2

try:
    import MySQLdb
except ImportError:
    mysql_available = False
else:
    mysql_available = True

import sqlalchemy
from sqlalchemy import create_engine
import simplejson as json

from ax.utils.listables import listable
from ax.utils.grouping import Grouping
from .schema import GroupTestSchema

"""
Test data:

    enterprise1
        |
        +-- operator1
                |
                +-- user1
                |     |
                |     +-- Z1
                |     |
                |     +-- Z4
                |         |
                +-- user2 +
                      |
                      + --Z3
"""

engine = None
def _create_engine():
    global engine
    if not engine:
        # MySQL engine
        DB_NAME = os.getenv('DB_NAME', 'test')
        DB_USER = os.getenv('DB_USER','ax')
        DB_PWD = os.getenv('DB_PWD', 'ax')
        DB_HOST = os.getenv('DB_HOST', '127.0.0.1')
        DB_PORT = os.getenv('DB_PORT', 3306)
        url = 'mysql://%s:%s@%s:%s/%s' %  (
                DB_USER,
                DB_PWD,
                DB_HOST,
                DB_PORT,
                DB_NAME)

        engine = create_engine(url, echo=False)


def build_query(query_map):
    query_params = query_map.get('filter_params', [])
    sql_query = ' '.join(query_map['full_query'])
    sql_query = sql_query.replace("?", "%s")

    return sql_query % tuple(query_params)


def prepare_data():
    # Add CPEs
    engine.execute("INSERT INTO CPEManager_CPEs("
                   "cid, cid2, cpeid, cpetype, path, version, IP, "
                   "unmanagedProps, pendingProps, props, scProps, "
                   "events, methods, comments, roles) "
                   "VALUES('', 'operator1', 'ZZ0000000001', 'genericTR69', '',"
                   "'version1__HardwareVersion1__1.011', '10.0.0.135', '[]',"
                   "'{}','{}','{}','[]','','','unsupportedFW')")
    engine.execute("INSERT INTO CPEManager_CPEs("
                   "cid, cid2, cpeid, cpetype, path, version, IP, "
                   "unmanagedProps, pendingProps, props, scProps, "
                   "events, methods, comments, roles) "
                   "VALUES('', '', 'ZZ0000000002', 'genericTR69', '',"
                   "'version2__HardwareVersion2__2.022', '10.0.0.137', '[]',"
                   "'{}','{}','{}','[]','','','unsupportedFW')")
    engine.execute("INSERT INTO CPEManager_CPEs("
                   "cid, cid2, cpeid, cpetype, path, version, IP, "
                   "unmanagedProps, pendingProps, props, scProps, "
                   "events, methods, comments, roles) "
                   "VALUES('', 'operator1', 'ZZ0000000003', 'genericTR69', '',"
                   "'version1__HardwareVersion1__1.011', '10.0.0.136', '[]',"
                   "'{}','{}','{}','[]','','','unsupportedFW')")
    engine.execute("INSERT INTO CPEManager_CPEs("
                   "cid, cid2, cpeid, cpetype, path, version, IP, "
                   "unmanagedProps, pendingProps, props, scProps, "
                   "events, methods, comments, roles) "
                   "VALUES('', 'operator1', 'ZZ0000000004', 'genericTR69', '',"
                   "'version1__HardwareVersion1__1.011', '10.0.0.138', '[]',"
                   "'{}','{}','{}','[]','','','unsupportedFW')")

    # Add enterprise
    engine.execute("INSERT INTO vss_ENTERPRISE("
                   "servicetype, comments, props, account_name, account_role, "
                   "account_parent) "
                   "VALUES('ENTERPRISE', '', '{}', 'enterprise1', "
                   "'enterprise', '')")

    # Add operators
    engine.execute("INSERT INTO vss_OPERATOR("
                   "servicetype, comments, props, account_name, account_role, "
                   "account_parent) "
                   "VALUES('OPERATOR', '', '{}', 'operator1', "
                   "'operator', 'enterprise1')")

    # Add users
    engine.execute("INSERT INTO vss_USER("
                   "servicetype, comments, props, account_name, account_role, "
                   "account_parent) "
                   "VALUES('USER', '', '{}', 'user1', "
                   "'user', 'operator1')")
    engine.execute("INSERT INTO vss_USER("
                   "servicetype, comments, props, account_name, account_role, "
                   "account_parent) "
                   "VALUES('USER', '', '{}', 'user2', "
                   "'user', 'operator1')")

    # Add user-cpe relations
    engine.execute("INSERT INTO vss_USER_CPE_RELATION("
                   "servicetype, comments, props, cpeid, sip_url, userid) "
                   "VALUES('USER_CPE_RELATION', '', '{}', 'ZZ0000000001', "
                   "'sip:user1@ZZ0000000001', 'user1')")
    engine.execute("INSERT INTO vss_USER_CPE_RELATION("
                   "servicetype, comments, props, cpeid, sip_url, userid) "
                   "VALUES('USER_CPE_RELATION', '', '{}', 'ZZ0000000004', "
                   "'sip:user1@ZZ0000000004', 'user1')")
    engine.execute("INSERT INTO vss_USER_CPE_RELATION("
                   "servicetype, comments, props, cpeid, sip_url, userid) "
                   "VALUES('USER_CPE_RELATION', '', '{}', 'ZZ0000000003', "
                   "'sip:user2@ZZ0000000003', 'user2')")
    engine.execute("INSERT INTO vss_USER_CPE_RELATION("
                   "servicetype, comments, props, cpeid, sip_url, userid) "
                   "VALUES('USER_CPE_RELATION', '', '{}', 'ZZ0000000004', "
                   "'sip:user2@ZZ0000000004', 'user2')")


def cleanup_data():
    # Delete CPEs
    engine.execute("DELETE FROM CPEManager_CPEs WHERE cpeid IN "
                   "('ZZ0000000001', "
                   "'ZZ0000000002', "
                   "'ZZ0000000003', "
                   "'ZZ0000000004', "
                   "'ZZ0000000005')")

    # Delete enterprise
    engine.execute("DELETE FROM vss_ENTERPRISE WHERE account_name IN "
                   "('enterprise1')")

    # Delete operator
    engine.execute("DELETE FROM vss_OPERATOR WHERE account_name IN "
                   "('operator1')")

    # Delete user
    engine.execute("DELETE FROM vss_USER WHERE account_name IN "
                   "('user1', 'user2')")

   # Delete user-cpe relation
    engine.execute("DELETE FROM vss_USER_CPE_RELATION WHERE cpeid IN "
                   "('ZZ0000000001', "
                   "'ZZ0000000002', "
                   "'ZZ0000000003', "
                   "'ZZ0000000004', "
                   "'ZZ0000000005')")

    # Truncate AXTickets
    engine.execute("TRUNCATE TABLE AXTickets")

    # Drop group tables, they'll be created on grouping.__init__
    engine.execute("DROP TABLE IF EXISTS AXGroup")
    engine.execute("DROP TABLE IF EXISTS AXGroupStaticRelation")
    engine.execute("DROP TABLE IF EXISTS AXGroupSuperRelation")
    engine.execute("DROP TABLE IF EXISTS AXGroupConsumedMembers")


@unittest2.skipIf(PY3, "Cannot run under python3")
@unittest2.skipIf(not mysql_available, "Cannot run without MySQLdb")
class TestAXGroupingDynamic(unittest2.TestCase):
    def setUp(self):
        _create_engine()
        self.grouping = Grouping(GroupTestSchema, engine)
        prepare_data()

    def tearDown(self):
        cleanup_data()

    def test_grouping_init_idempotency(self):
        self.grouping = Grouping(GroupTestSchema, engine)
        self.grouping = Grouping(GroupTestSchema, engine)
        self.grouping = Grouping(GroupTestSchema, engine)

    def test_create_group_exceptions(self):
        group_test1_id = 0
        with self.assertRaises(ValueError) as context:
            group_test1_id = self.grouping.create_group(
                'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
                ['=', 'operator1'])
        self.assertTrue("Cannot create group %d:"
                        " Cannot set filters: string index out of range" %
                        group_test1_id, str(context.exception))

        with self.assertRaises(ValueError) as context:
            group_test1_id = self.grouping.create_group(
                'test1', 'test group', 'test_user', 'dynamic', [],
                ['Operator.account_name', '=', 'operator1'])
        self.assertTrue("Cannot create group %d: No resultset provided" %
                        group_test1_id, str(context.exception))

    def test_create_group_empty_filter(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe'])
        group_definition = self.grouping.get_group_by_id(group_test1_id)
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'], [])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE', '1 = 1'
            ]))

    def test_create_group(self):
        id_ = self.grouping.create_group(
            'test1', 'CPEs of operator1', 'test_user', 'dynamic',
            ['cpe.cpeid'], ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.get_group_by_id(id_)
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['Operator.account_name', '=', 'operator1'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'LEFT JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                'Operator.account_name = operator1'
            ]))

    def test_create_and_update_input_change(self):
        filters = ['Operator.account_name', 'like', 'op*']
        show = ['cpe.cpei*']
        id_ = self.grouping.create_group(
            'test1', 'CPEs of op*', 'test_user', 'dynamic',
            show, filters)
        group_definition = self.grouping.get_group_by_id(id_)
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['Operator.account_name', 'like', 'op%%'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(query_map['show'], ['cpe.cpeid'])

        self.assertEqual(filters, ['Operator.account_name', 'like', 'op*'])
        self.assertEqual(show, ['cpe.cpei*'])

        filters = ['Enterprise.account_name', 'like', 'ent*']
        show = ['cpe.cpetyp*']
        self.grouping.update_group(
            id_, 'test_user', 'test1', 'CPEs of op*', 'dynamic', show, filters)
        group_definition = self.grouping.get_group_by_id(id_)
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['Enterprise.account_name', 'like', 'ent%%'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(query_map['show'], ['cpe.cpetype'])

        self.assertEqual(filters, ['Enterprise.account_name', 'like', 'ent*'])
        self.assertEqual(show, ['cpe.cpetyp*'])

    def test_key_expansion(self):
        id_ = self.grouping.create_group('test2', 'CPEs of operator1',
                                         'test_user', 'dynamic', ['cpe'],
                                         ['Operator', '=', 'operator1'])
        group_definition = self.grouping.get_group_by_id(id_)
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['Operator.account_name', '=', 'operator1'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'LEFT JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                'Operator.account_name = operator1'
            ]))

    def test_extend_group(self):
        # Create group
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']

        with self.assertRaises(ValueError) as context:
            self.grouping.create_group(
                'test2',
                'test group',
                'test_user',
                'static', ['Operator.account_name'],
                ['User.account_name', '=', 'user1'],
                base_group=group_test1_id)
        self.assertEqual(
            "Cannot create group test2: Cannot extend from or to static group",
            str(context.exception))

        self.grouping.create_group(
            'test2',
            'test group',
            'test_user',
            'dynamic', ['Operator.account_name'], ['User', '=', 'user1'],
            base_group=group_test1_id)
        group_definition = self.grouping.search_groups_by_name('test2')[0]
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'Operator')
        self.assertEqual(group_definition['filter'],
                         ['Operator.account_name', '=', 'operator1',
                          'and', ['User.account_name', '=', 'user1']])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid, Operator.account_name', 'FROM',
                'vss_OPERATOR AS `Operator`', 'LEFT JOIN vss_USER AS `User`',
                'ON Operator.account_name = User.account_parent',
                'INNER JOIN CPEManager_CPEs AS `cpe`',
                'ON Operator.account_name = cpe.cid2', 'WHERE',
                '(Operator.account_name = operator1 and User.account_name = user1)'
            ]))

    def test_create_group_in_operator(self):
        group_test3_id = self.grouping.create_group(
            'test3', 'test group', 'test_user', 'dynamic',
            ['cpe.cpeid', 'User.account_name'], [
                'cpe.cpeid', 'in', ['ZZ0000000001', 'ZZ0000000002',
                                    'ZZ0000000003', 'ZZ0000000004']
            ])
        group_definition = self.grouping.get_group_by_id(group_test3_id)
        self.assertEqual(group_definition['name'], 'test3')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['cpe.cpeid', 'in', [
                             'ZZ0000000001',
                             'ZZ0000000002',
                             'ZZ0000000003',
                             'ZZ0000000004']
            ])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid, User.account_name', 'FROM',
                'CPEManager_CPEs AS `cpe`',
                'LEFT JOIN vss_USER_CPE_RELATION AS `UserCPERelation`',
                'ON cpe.cpeid = UserCPERelation.cpeid',
                'INNER JOIN vss_USER AS `User`',
                'ON UserCPERelation.userid = User.account_name', 'WHERE',
                'cpe.cpeid in (ZZ0000000001,ZZ0000000002,ZZ0000000003,ZZ0000000004)'
            ]))

    def test_create_group_wrong_filter(self):
        group_test1_id = 0
        with self.assertRaises(ValueError) as context:
            group_test1_id = self.grouping.create_group(
                'test1', 'test group', 'test_user', 'dynamic',
                ['Operator.account_name'], ['User.account_name', '=', '%s'])
        self.assertTrue("Cannot create group %d: "
                        "Filter doesn't comply with group type dynamic" %
                        group_test1_id, str(context.exception))

    def test_delete_group(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.get_group_by_id(group_test1_id)
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['Operator.account_name', '=', 'operator1'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'LEFT JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                'Operator.account_name = operator1'
            ]))

        self.grouping.delete_group(group_test1_id, 'test_user')
        with self.assertRaises(ValueError) as context:
            group_definition = self.grouping.get_group_by_id(group_test1_id)
        self.assertTrue("Group test1 does not exist", str(context.exception))

    def test_update_group(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['Operator.account_name', '=', 'operator1'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'LEFT JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                'Operator.account_name = operator1'
            ]))

        self.grouping.update_group(
            group_test1_id, 'test_user', 'test1', 'test group', 'dynamic',
            ['Operator.account_name'], ['cpe.cpeid', '=', 'ZZ0000000001'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'Operator')
        self.assertEqual(group_definition['filter'],
                         ['cpe.cpeid', '=', 'ZZ0000000001'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'Operator.account_name', 'FROM',
                'vss_OPERATOR AS `Operator`',
                'LEFT JOIN CPEManager_CPEs AS `cpe`',
                'ON Operator.account_name = cpe.cid2', 'WHERE',
                'cpe.cpeid = ZZ0000000001'
            ]))

        with self.assertRaises(ValueError) as context:
            self.grouping.update_group(group_test1_id, 'test_user', 'test1',
                                       'test group', 'dynamic', ['cpe.cpeid'],
                                       ['=', 'operator1'])
        self.assertTrue("Cannot update group %d: Cannot set filters: " \
                "string index out of range" % group_test1_id, str(context.exception))

        self.grouping.update_group(group_test1_id, 'test_user', 'test1',
                                   'test group', 'dynamic', ['cpe.cpeid'], [])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'], [])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE', '1 = 1'
            ]))

        self.grouping.update_group(
            group_test1_id, 'test_user', filter_list=['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['Operator.account_name', '=', 'operator1'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'LEFT JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name',
                'WHERE Operator.account_name = operator1'
            ]))

    def test_get_members(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.get_group_by_id(group_test1_id)
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['Operator.account_name', '=', 'operator1'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'LEFT JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                'Operator.account_name = operator1'
            ]))

        with self.assertRaises(ValueError) as context:
            self.grouping.get_group_members(
                None, limit=2, offset=0, return_as='dict')
        self.assertEqual("Cannot fetch members of group None: " \
                "Group None does not exist", str(context.exception))

        all_results = []
        result = self.grouping.get_group_members(
            group_test1_id, limit=2, offset=0)
        all_results.extend(result)
        self.assertEqual(len(result), 2)

        result = self.grouping.get_group_members(
            group_test1_id, limit=2, offset=2)
        all_results.extend(result)
        self.assertEqual(len(result), 1)

        all_results = sorted(all_results)
        self.assertEqual(all_results[0][0], 'ZZ0000000001')
        self.assertEqual(all_results[1][0], 'ZZ0000000003')
        self.assertEqual(all_results[2][0], 'ZZ0000000004')
        self.assertEqual(
            self.grouping.get_group_member_count(group_test1_id), 3)

    def test_get_extended_members(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.get_group_by_id(group_test1_id)
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['Operator.account_name', '=', 'operator1'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'LEFT JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                'Operator.account_name = operator1'
            ]))

        with self.assertRaises(ValueError) as context:
            self.grouping.get_group_extended_members(
                None, [], limit=2, offset=0, return_as='dict')
        self.assertTrue("Group None does not exist" in str(
            context.exception))

        all_results = []
        result = self.grouping.get_group_extended_members(
            group_test1_id,
            ['cpe.cpeid', 'cpe.IP', 'Enterprise.account_name'],
            limit=2,
            offset=0)
        all_results.extend(result)
        self.assertEqual(len(result), 2)

        result = self.grouping.get_group_extended_members(
            group_test1_id,
            ['cpe.cpeid', 'cpe.IP', 'Enterprise.account_name'],
            limit=2,
            offset=2)
        self.assertEqual(len(result), 1)

        all_results.extend(result)
        self.assertEqual(
            len(all_results),
            self.grouping.get_group_extended_members_count(
                group_test1_id,
                ['cpe.cpeid', 'cpe.IP', 'Enterprise.account_name']))
        all_results = sorted(all_results)
        self.assertEqual(all_results[0][0], 'ZZ0000000001')
        self.assertEqual(all_results[0][1], '10.0.0.135')
        self.assertEqual(all_results[0][2], 'enterprise1')
        self.assertEqual(all_results[1][0], 'ZZ0000000003')
        self.assertEqual(all_results[1][1], '10.0.0.136')
        self.assertEqual(all_results[1][2], 'enterprise1')
        self.assertEqual(all_results[2][0], 'ZZ0000000004')
        self.assertEqual(all_results[2][1], '10.0.0.138')
        self.assertEqual(all_results[2][2], 'enterprise1')
        self.assertEqual(
            self.grouping.get_group_member_count(group_test1_id), 3)

        self.assertEqual(
            self.grouping.get_group_members(group_test1_id),
            self.grouping.get_group_extended_members(group_test1_id, []))

        self.assertEqual(
            self.grouping.get_group_member_count(group_test1_id),
            self.grouping.get_group_extended_members_count(group_test1_id, []))

        self.assertEqual(
            self.grouping.get_group_member_count(group_test1_id),
            self.grouping.get_group_extended_members_count(group_test1_id, None))

        result = self.grouping.get_group_extended_members(
            group_test1_id,
            ['cpe.cpeid', 'cpe.IP', 'Enterprise.account_name'],
            ['User.account_name', '=', 'user1'],
            sort=[('cpe.cpeid', 'desc')],
            return_as='dict')
        self.assertEqual(
            len(result),
            self.grouping.get_group_extended_members_count(
                group_test1_id,
                ['cpe.cpeid', 'cpe.IP', 'Enterprise.account_name'],
                ['User.account_name', '=', 'user1']))
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000004')
        self.assertEqual(result[0]['cpe.IP'], '10.0.0.138')
        self.assertEqual(result[0]['Enterprise.account_name'], 'enterprise1')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.IP'], '10.0.0.135')
        self.assertEqual(result[1]['Enterprise.account_name'], 'enterprise1')

        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['Operator.account_name', 'like', 'operat*'])
        group_definition = self.grouping.get_group_by_id(group_test2_id)
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['Operator.account_name', 'like', 'operat%%'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'LEFT JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                'Operator.account_name like operat%%'
            ]))

        result = self.grouping.get_group_extended_members(
            group_test2_id,
            ['cpe.cpeid', 'cpe.IP', 'Enterprise.account_name'],
            ['cpe.cpeid', '=', 'ZZ0000000001'],
            sort=[('cpe.cpeid', 'desc')],
            return_as='dict')
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[0]['cpe.IP'], '10.0.0.135')
        self.assertEqual(result[0]['Enterprise.account_name'], 'enterprise1')

    def test_get_group_unconsumed_members(self):
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id)
        self.assertEqual(unconsumed_count, 3)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 0)

        result = self.grouping.get_group_unconsumed_members(
            group_test1_id, sort=[['cpe.cpeid', 'asc']],
            limit=3, offset=0, return_as='dict')
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')

        self.grouping.consume_member(group_test1_id, 'ZZ0000000001')
        self.grouping.consume_member(group_test1_id, 'ZZ0000000003')

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id)
        self.assertEqual(unconsumed_count, 1)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 2)

        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000001'))
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000003'))
        self.assertFalse(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000004'))

        self.grouping.consume_member(group_test1_id, 'ZZ0000000004')
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000004'))

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id)
        self.assertEqual(unconsumed_count, 0)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 3)

        result = self.grouping.get_group_unconsumed_members(
            group_test1_id, limit=3, offset=0, return_as='dict')
        self.assertEqual(len(result), 0)

        self.grouping.unconsume_all_members(group_test1_id)

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id)
        self.assertEqual(unconsumed_count, 3)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 0)

        result = self.grouping.get_group_unconsumed_members(
            group_test1_id, sort=[['cpe.cpeid', 'asc']],
            limit=3, offset=0, return_as='dict')
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')

        self.grouping.consume_members(group_test1_id, ['ZZ0000000001', 'ZZ0000000003', 'ZZ0000000004'])
        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id)
        self.assertEqual(unconsumed_count, 0)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 3)

    def test_members_with_condition(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cpeid', '=', 'ZZ0000000001'])
        group_definition = self.grouping.get_group_by_id(group_test1_id)
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['cpe.cpeid', '=', 'ZZ0000000001'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE cpe.cpeid = ZZ0000000001'
            ]))

        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cpeid', '=', 'ZZ0000000002'])
        group_definition = self.grouping.get_group_by_id(group_test2_id)
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['cpe.cpeid', '=', 'ZZ0000000002'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE cpe.cpeid = ZZ0000000002'
            ]))

        # Get members with conditions
        result = self.grouping.get_group_members_with_condition(
            [group_test1_id, group_test2_id],
            ['cpe.cpeid', 'in', ('ZZ0000000002', 'Z0000000003')],
            ['cpe.version', 'cpe.cpetype'])
        count = self.grouping.get_group_members_with_condition_count(
            [group_test1_id, group_test2_id],
            ['cpe.cpeid', 'in', ('ZZ0000000002', 'Z0000000003')])
        self.assertEqual(len(result), 1)
        self.assertEqual(len(result), count)
        self.assertEqual(result[0][0], 'version2__HardwareVersion2__2.022')
        self.assertEqual(result[0][1], 'genericTR69')

        result = self.grouping.get_group_members_with_condition(
            [group_test1_id, group_test2_id],
            result_list=['cpe.version', 'cpe.cpetype'])
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0][0], 'version1__HardwareVersion1__1.011')
        self.assertEqual(result[0][1], 'genericTR69')
        self.assertEqual(result[1][0], 'version2__HardwareVersion2__2.022')
        self.assertEqual(result[1][1], 'genericTR69')

        result = self.grouping.get_group_members_with_condition(
            [group_test1_id, group_test2_id], [], [])
        count = self.grouping.get_group_members_with_condition_count(
            [group_test1_id, group_test2_id], [])
        self.assertEqual(len(result), 2)
        self.assertEqual(len(result), count)
        self.assertEqual(result[0][0], 'ZZ0000000001')
        self.assertEqual(result[1][0], 'ZZ0000000002')

        result = self.grouping.get_group_members_with_condition(
            [group_test1_id, group_test2_id])
        count = self.grouping.get_group_members_with_condition_count(
            [group_test1_id, group_test2_id])
        self.assertEqual(len(result), 2)
        self.assertEqual(len(result), count)
        self.assertEqual(result[0][0], 'ZZ0000000001')
        self.assertEqual(result[1][0], 'ZZ0000000002')

        # Get members with conditions on disjoint resultsets
        group_test3_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid', 'cpe.cid'],
            ['cpe.cpeid', '=', 'ZZ0000000003'])
        group_definition = self.grouping.get_group_by_id(group_test3_id)
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['cpe.cpeid', '=', 'ZZ0000000003'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cid, cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE cpe.cpeid = ZZ0000000003'
            ]))

        with self.assertRaises(ValueError) as context:
            result = self.grouping.get_group_members_with_condition(
                [group_test1_id, group_test3_id],
                ['cpe.cpeid', '=', 'ZZ0000000004'])
        self.assertTrue(str(context.exception).endswith('Sub-groups have disjoint resultsets'))

        with self.assertRaises(ValueError) as context:
            result = self.grouping.get_group_members_with_condition_count(
                [group_test1_id, group_test3_id],
                ['cpe.cpeid', '=', 'ZZ0000000004'])
        self.assertTrue(str(context.exception).endswith('Sub-groups have disjoint resultsets'))

    def test_consumption_errors(self):
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id)
        self.assertEqual(unconsumed_count, 3)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 0)

        result = self.grouping.get_group_unconsumed_members(
            group_test1_id, sort=[['cpe.cpeid', 'asc']],
            limit=3, offset=0, return_as='dict')
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')

        # Group does not exist
        with self.assertRaises(ValueError) as context:
            self.grouping.consume_member(999, 'ZZ0000000001')
        self.assertEqual(str(context.exception),
                         "Cannot consume members: Group %s does not exist" %
                         str(999))

        # Group does not exist
        with self.assertRaises(ValueError) as context:
            self.grouping.consume_members(999, ['ZZ0000000001', 'ZZ0000000003'])
        self.assertEqual(str(context.exception),
                         "Cannot consume members: Group %s does not exist" %
                         str(999))

        # Group does not exist and member not consumed
        with self.assertRaises(ValueError) as context:
            self.grouping.is_member_consumed(999, 'yada_yada')
        self.assertEqual(str(context.exception),
                         "Cannot check if member consumed: Group %s does not "
                         "exist" % str(999))
        with self.assertRaises(ValueError) as context:
            self.grouping.get_group_consumed_member_count(999)
        self.assertEqual(str(context.exception),
                         "Cannot count consumed members: Group %s does not exist" %
                         str(999))
        with self.assertRaises(ValueError) as context:
            self.grouping.get_group_unconsumed_member_count(999)
        self.assertEqual(str(context.exception),
                         "Cannot fetch unconsumed member count for group %s: "
                         "Group %s does not exist" %
                         (str(999), str(999)))

        # Group exists but member not consumed
        self.assertFalse(self.grouping.is_member_consumed(
            group_test1_id, 'ZZ0000000001'))
        self.assertEqual(self.grouping.get_group_consumed_member_count(
            group_test1_id), 0)
        self.assertEqual(self.grouping.get_group_unconsumed_member_count(
            group_test1_id), 3)

        # Group exists and member consumed
        self.grouping.consume_member(group_test1_id, 'ZZ0000000001')
        self.assertTrue(self.grouping.is_member_consumed(
            group_test1_id, 'ZZ0000000001'))
        self.assertEqual(self.grouping.get_group_consumed_member_count(
            group_test1_id), 1)
        self.assertEqual(self.grouping.get_group_unconsumed_member_count(
            group_test1_id), 2)
        self.grouping.consume_members(
            group_test1_id, ['ZZ0000000001', 'ZZ0000000003', 'ZZ0000000004'])
        self.assertTrue(self.grouping.is_member_consumed(
            group_test1_id, 'ZZ0000000001'))
        self.assertTrue(self.grouping.is_member_consumed(
            group_test1_id, 'ZZ0000000003'))
        self.assertTrue(self.grouping.is_member_consumed(
            group_test1_id, 'ZZ0000000004'))
        self.assertEqual(self.grouping.get_group_consumed_member_count(
            group_test1_id), 3)
        self.assertEqual(self.grouping.get_group_unconsumed_member_count(
            group_test1_id), 0)


    def test_get_membership(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cid2', '=', 'operator1'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['cpe.cid2', '=', 'operator1'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE', 'cpe.cid2 = operator1'
            ]))

        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cpeid', '=', 'ZZ0000000001'])
        group_definition = self.grouping.search_groups_by_name('test2')[0]
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['cpe.cpeid', '=', 'ZZ0000000001'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE', 'cpe.cpeid = ZZ0000000001'
            ]))

        group_test3_id = self.grouping.create_group(
            'test3', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['User.account_name', '=', 'user2'])
        group_definition = self.grouping.search_groups_by_name('test3')[0]
        self.assertEqual(group_definition['name'], 'test3')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['User.account_name', '=', 'user2'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'LEFT JOIN vss_USER_CPE_RELATION AS `UserCPERelation`',
                'ON cpe.cpeid = UserCPERelation.cpeid',
                'INNER JOIN vss_USER AS `User`',
                'ON UserCPERelation.userid = User.account_name', 'WHERE',
                'User.account_name = user2'
            ]))

        group_test4_id = self.grouping.create_group(
            'test4', 'test group', 'test_user', 'dynamic',
            ['Operator.account_name'], ['cpe.cpeid', '=', 'ZZ0000000004'])
        group_definition = self.grouping.search_groups_by_name('test4')[0]
        self.assertEqual(group_definition['name'], 'test4')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'Operator')
        self.assertEqual(group_definition['filter'],
                         ['cpe.cpeid', '=', 'ZZ0000000004'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'Operator.account_name', 'FROM',
                'vss_OPERATOR AS `Operator`',
                'LEFT JOIN CPEManager_CPEs AS `cpe`',
                'ON Operator.account_name = cpe.cid2', 'WHERE',
                'cpe.cpeid = ZZ0000000004'
            ]))

        self.assertFalse(
            self.grouping.get_group_membership(None, 'ZZ0000000004'))

        membership = self.grouping.get_group_membership('cpe', 'ZZ0000000004')
        self.assertEqual(len(membership), 2)
        self.assertTrue(group_test1_id in membership)
        self.assertTrue(group_test3_id in membership)

        membership = self.grouping.get_group_membership(
            'Enterprise.account_name', 'enterprise1')
        self.assertEqual(len(membership), 0)

        membership = self.grouping.get_group_membership('Operator',
                                                        'operator1')
        self.assertEqual(len(membership), 1)
        self.assertTrue(group_test4_id in membership)

    def test_is_member(self):
        group_test0_id = self.grouping.create_group(
            'test0', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            [['cpe.cid2', '=', 'operator1'], 'or',
             [['cpe.cpetype', 'like', 'gen\*ric*'], 'and',
              ['cpe.version', 'like', '1.*']]])
        group_definition = self.grouping.search_groups_by_name('test0')[0]
        self.assertEqual(group_definition['name'], 'test0')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE',
                '(cpe.cid2 = operator1 or (cpe.cpetype like gen*ric%% and cpe.version like 1.%%))'
            ]))

        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            [['cpe.cid2', '=', 'operator1'], 'or',
             [['cpe.state', '<', 5], 'and', ['cpe.version', 'like', '1.*']]])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE',
                '(cpe.cid2 = operator1 or (cpe.state < 5 and cpe.version like 1.%%))'
            ]))

        with self.assertRaises(ValueError) as context:
            self.grouping.is_member('cpe.cpeid', 'ZZ0000000004', None)
        self.assertEqual("Cannot verify membership for " \
                "cpe.cpeid=ZZ0000000004 against group None: " \
                "Group None does not exist", str(context.exception))

        self.assertFalse(
            self.grouping.is_member(None, 'ZZ0000000004', group_test1_id))

        self.assertTrue(
            self.grouping.is_member('cpe.cpeid', 'ZZ0000000001',
                                    group_test1_id))
        self.assertFalse(
            self.grouping.is_member('cpe.cpeid', 'ZZ0000000002',
                                    group_test1_id))
        self.assertTrue(
            self.grouping.is_member('cpe.cpeid', 'ZZ0000000003',
                                    group_test1_id))
        self.assertTrue(
            self.grouping.is_member('cpe.cpeid', 'ZZ0000000004',
                                    group_test1_id))

    def test_stateful_consumption(self):
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id)
        self.assertEqual(unconsumed_count, 3)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 0)

        result = self.grouping.get_group_unconsumed_members(
            group_test1_id, sort=[['cpe.cpeid', 'asc']],
            limit=3, offset=0, return_as='dict')
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')

        self.grouping.consume_member(group_test1_id, 'ZZ0000000001', state=1)
        self.grouping.consume_member(group_test1_id, 'ZZ0000000001', state=10)
        self.grouping.consume_member(group_test1_id, 'ZZ0000000003', state=2)
        self.grouping.consume_member(group_test1_id, 'ZZ0000000004')

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id)
        self.assertEqual(unconsumed_count, 0)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 3)

        self.assertFalse(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000001'))
        self.assertFalse(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000001', state=1))
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000001', state=10))
        self.assertFalse(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000003'))
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000003', state=2))
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000004'))
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000004', state=255))
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000001', state=None))
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000003', state=None))
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000004', state=None))

        self.grouping.unconsume_members_by_states(group_test1_id, states=[1, 2])

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id)
        self.assertEqual(unconsumed_count, 1)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 2)

        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000001', state=10))
        self.assertFalse(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000003', state=2))
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000004'))

        self.grouping.unconsume_members_by_states(group_test1_id, states=[10])

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id)
        self.assertEqual(unconsumed_count, 2)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 1)

        self.assertFalse(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000001', state=10))
        self.assertFalse(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000003', state=2))
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000004'))

        result = self.grouping.get_group_unconsumed_members(
            group_test1_id, limit=3, offset=0, return_as='dict')
        self.assertEqual(len(result), 2)

        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')

        self.grouping.unconsume_all_members(group_test1_id)

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id)
        self.assertEqual(unconsumed_count, 3)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 0)

        result = self.grouping.get_group_unconsumed_members(
            group_test1_id, sort=[['cpe.cpeid', 'asc']],
            limit=3, offset=0, return_as='dict')
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')

        self.grouping.consume_members(group_test1_id,
                                      ['ZZ0000000003', 'ZZ0000000004'],
                                      state=42)

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id)
        self.assertEqual(unconsumed_count, 1)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 2)

        self.assertFalse(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000001'))
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000003', state=42))
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000004', state=42))

        self.grouping.unconsume_member(group_test1_id, 'ZZ0000000004')

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id)
        self.assertEqual(unconsumed_count, 2)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 1)

        self.assertFalse(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000001'))
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000003', state=42))
        self.assertFalse(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000004', state=42))

        self.grouping.unconsume_members_by_states(group_test1_id)

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id)
        self.assertEqual(unconsumed_count, 2)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 1)

        self.assertFalse(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000001'))
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000003', state=42))
        self.assertFalse(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000004', state=42))

@unittest2.skipIf(PY3, "Cannot run under python3")
@unittest2.skipIf(not mysql_available, "Cannot run without MySQLdb")
class TestAXGroupingLazy(unittest2.TestCase):
    def setUp(self):
        _create_engine()
        self.grouping = Grouping(GroupTestSchema, engine)
        prepare_data()

    def tearDown(self):
        cleanup_data()

    def test_create_group(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'lazy', ['cpe.cpeid'],
            ['Operator.account_name', '=', '%(operator_name)s'])
        group_definition = self.grouping.get_group_by_id(group_test1_id)
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'lazy')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['Operator.account_name', '=', '%(operator_name)s'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'LEFT JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                'Operator.account_name = %(operator_name)s'
            ]))

    def test_extend_group(self):
        # Create group
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']

        with self.assertRaises(ValueError) as context:
            self.grouping.create_group(
                'test2',
                'test group',
                'test_user',
                'dynamic', ['cpe.cpeid'],
                ['Operator.account_name', '=', 'operator1'],
                base_group=group_test1_id)
        self.assertEqual(
            "Cannot create group test2: Filter doesn't comply with group type dynamic",
            str(context.exception))

        self.grouping.create_group(
            'test2',
            'test group',
            'test_user',
            'lazy', ['cpe.cpeid'], ['Operator.account_name', '=', 'operator1'],
            base_group=group_test1_id)
        group_definition = self.grouping.search_groups_by_name('test2')[0]
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'lazy')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['Operator.account_name', '=', '%(operator_name)s',
                          'and', ['Operator.account_name', '=', 'operator1']])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'LEFT JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                '(Operator.account_name = %(operator_name)s and '
                'Operator.account_name = operator1)'
            ]))

    def test_create_group_wrong_filter(self):
        group_test1_id = 0
        with self.assertRaises(ValueError) as context:
            group_test1_id = self.grouping.create_group(
                'test1', 'test group', 'test_user', 'lazy',
                ['Operator.account_name'], ['User.account_name', '=', 'user1'])
        self.assertTrue("Cannot create group %d: "
                        "Filter doesn't comply with group type lazy" %
                        group_test1_id, str(context.exception))

    def test_update_group(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['Operator.account_name', '=', 'operator1'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'LEFT JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                'Operator.account_name = operator1'
            ]))

        self.grouping.update_group(
            group_test1_id, 'test_user', 'test1', 'test group', 'lazy',
            ['Operator.account_name'], ['cpe.cpeid', '=', '%(cpeid)s'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'lazy')
        self.assertEqual(group_definition['domain'], 'Operator')
        self.assertEqual(group_definition['filter'],
                         ['cpe.cpeid', '=', '%(cpeid)s'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'Operator.account_name', 'FROM',
                'vss_OPERATOR AS `Operator`',
                'LEFT JOIN CPEManager_CPEs AS `cpe`',
                'ON Operator.account_name = cpe.cid2', 'WHERE',
                'cpe.cpeid = %(cpeid)s'
            ]))

        self.grouping.update_group(group_test1_id, 'test_user', 'test1',
                                   'test group', 'dynamic', ['cpe.cpeid'],
                                   ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['Operator.account_name', '=', 'operator1'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'LEFT JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                'Operator.account_name = operator1'
            ]))

    def test_get_members(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'lazy', ['cpe.cpeid'],
            [['Operator.account_name', '=', '%(operator_name)s'], 'or',
             ['Enterprise.account_name', '=', '%(enterprise_name)s']])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'lazy')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         [['Operator.account_name', '=', '%(operator_name)s'],
                          'or',
                          ['Enterprise.account_name', '=', '%(enterprise_name)s']])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
                build_query(query_map),
                ' '.join(['SELECT', 'cpe.cpeid', 'FROM',
                    'CPEManager_CPEs AS `cpe`',
                    'LEFT JOIN vss_OPERATOR AS `Operator`',
                    'ON cpe.cid2 = Operator.account_name',
                    'INNER JOIN vss_ENTERPRISE AS `Enterprise`',
                    'ON Operator.account_parent = Enterprise.account_name',
                    'WHERE',
                    '(Operator.account_name = %(operator_name)s or ' \
                            'Enterprise.account_name = %(enterprise_name)s)']))

        with self.assertRaises(ValueError) as context:
            self.grouping.get_group_members(
                group_test1_id, limit=2, offset=0, return_as='dict')
        self.assertTrue("Cannot fetch members of group test1: " \
                "lazy filters cannot be resolved", str(context.exception))

        with self.assertRaises(ValueError) as context:
            self.grouping.get_group_members(
                group_test1_id,
                lazy_filter={'enterprise_name': 'enterprise1'},
                limit=2,
                offset=0,
                return_as='dict')
        self.assertEqual("Cannot fetch members of group %d: " \
                "Cannot resolve lazy filter: Key 'operator_name' not found" % group_test1_id,
                str(context.exception))

        all_results = []
        result = self.grouping.get_group_members(
            group_test1_id,
            lazy_filter={
                'enterprise_name': 'enterprise1',
                'operator_name': 'operator1'
            },
            limit=2,
            offset=0,
            return_as='dict')
        all_results.extend(result)
        self.assertEqual(len(result), 2)
        result = self.grouping.get_group_members(
            group_test1_id,
            lazy_filter={
                'enterprise_name': 'enterprise1',
                'operator_name': 'operator1'
            },
            limit=2,
            offset=2,
            return_as='dict')
        all_results.extend(result)
        self.assertEqual(len(result), 1)

        all_results = sorted(all_results, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(all_results[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(all_results[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(all_results[2]['cpe.cpeid'], 'ZZ0000000004')
        self.assertEqual(
            self.grouping.get_group_member_count(
                group_test1_id,
                lazy_filter={
                    'enterprise_name': 'enterprise1',
                    'operator_name': 'operator1'
                }), 3)

        # Get members with conditions
        all_results = []
        result = self.grouping.get_group_members_with_condition(
            [group_test1_id],
            ['cpe.version', '=', 'version1__HardwareVersion1__1.011'],
            ['cpe.cpeid'],
            lazy_filter={
                'enterprise_name': 'enterprise1',
                'operator_name': 'operator1'
            },
            limit=2,
            return_as='dict')
        self.assertEqual(len(result), 2)
        all_results.extend(result)
        result = self.grouping.get_group_members_with_condition(
            [group_test1_id],
            ['cpe.version', '=', 'version1__HardwareVersion1__1.011'],
            lazy_filter={
                'enterprise_name': 'enterprise1',
                'operator_name': 'operator1'
            },
            limit=2,
            offset=2,
            return_as='dict')
        self.assertEqual(len(result), 1)
        all_results.extend(result)

        count = self.grouping.get_group_members_with_condition_count(
            [group_test1_id],
            ['cpe.version', '=', 'version1__HardwareVersion1__1.011'],
            lazy_filter={
                'enterprise_name': 'enterprise1',
                'operator_name': 'operator1'
            })

        self.assertEqual(len(all_results), 3)
        self.assertEqual(len(all_results), count)
        all_results = sorted(all_results, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(all_results[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(all_results[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(all_results[2]['cpe.cpeid'], 'ZZ0000000004')


    def test_get_extended_members(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'lazy', ['cpe.cpeid'],
            [['Operator.account_name', 'like', '%(operator_name)s'], 'or',
             ['Enterprise.account_name', '=', '%(enterprise_name)s']])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'lazy')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         [['Operator.account_name', 'like', '%(operator_name)s'],
                          'or',
                          ['Enterprise.account_name', '=', '%(enterprise_name)s']])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
                build_query(query_map),
                ' '.join(['SELECT', 'cpe.cpeid', 'FROM',
                    'CPEManager_CPEs AS `cpe`',
                    'LEFT JOIN vss_OPERATOR AS `Operator`',
                    'ON cpe.cid2 = Operator.account_name',
                    'INNER JOIN vss_ENTERPRISE AS `Enterprise`',
                    'ON Operator.account_parent = Enterprise.account_name',
                    'WHERE',
                    '(Operator.account_name like %(operator_name)s or ' \
                            'Enterprise.account_name = %(enterprise_name)s)']))

        with self.assertRaises(ValueError) as context:
            self.grouping.get_group_members(
                group_test1_id, limit=2, offset=0, return_as='dict')
        self.assertTrue("Cannot fetch members of group test1: " \
                "lazy filters cannot be resolved", str(context.exception))

        with self.assertRaises(ValueError) as context:
            self.grouping.get_group_members(
                group_test1_id,
                lazy_filter={'enterprise_name': 'enterprise1'},
                limit=2,
                offset=0,
                return_as='dict')
        self.assertEqual("Cannot fetch members of group %d: " \
                "Cannot resolve lazy filter: Key 'operator_name' not found" % group_test1_id,
                str(context.exception))

        result = self.grouping.get_group_extended_members(
            group_test1_id,
            ['User.account_name'],
            lazy_filter={
                'enterprise_name': 'enterprise1',
                'operator_name': 'operator1'
            },
            sort=[['User.account_name', 'desc']],
            return_as='dict')
        self.assertEqual(
            len(result),
            self.grouping.get_group_extended_members_count(
                group_test1_id,
                ['User.account_name'],
                lazy_filter={
                    'enterprise_name': 'enterprise1',
                    'operator_name': 'operator1'
                }))

        self.assertEqual(result[0]['User.account_name'], 'user2')
        self.assertEqual(result[1]['User.account_name'], 'user2')
        self.assertEqual(result[2]['User.account_name'], 'user1')
        self.assertEqual(result[3]['User.account_name'], 'user1')

        result = self.grouping.get_group_extended_members(
            group_test1_id,
            filter_list=['User.account_name', '=', 'user1'],
            lazy_filter={
                'enterprise_name': 'enterprise1',
                'operator_name': 'operator1'
            },
            sort=[['cpe.cpeid', 'asc']],
            return_as='dict')
        self.assertEqual(
            len(result),
            self.grouping.get_group_extended_members_count(
                group_test1_id,
                filter_list=['User.account_name', '=', 'user1'],
                lazy_filter={
                    'enterprise_name': 'enterprise1',
                    'operator_name': 'operator1'
                }))

        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000004')

    def test_get_group_unconsumed_members(self):
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id,
            lazy_filter={'operator_name': 'operator1'})
        self.assertEqual(unconsumed_count, 3)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 0)

        result = self.grouping.get_group_unconsumed_members(
            group_test1_id,
            sort=[['cpe.cpeid', 'asc']],
            lazy_filter={'operator_name': 'operator1'},
            limit=3,
            offset=0,
            return_as='dict')
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')

        self.grouping.consume_members(group_test1_id, ['ZZ0000000001', 'ZZ0000000003'])

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id,
            lazy_filter={'operator_name': 'operator1'})
        self.assertEqual(unconsumed_count, 1)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 2)

        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000001'))
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000003'))
        self.assertFalse(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000004'))

        self.grouping.consume_member(group_test1_id, 'ZZ0000000004')
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000004'))

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id,
            lazy_filter={'operator_name': 'operator1'})
        self.assertEqual(unconsumed_count, 0)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 3)

        result = self.grouping.get_group_unconsumed_members(
            group_test1_id,
            lazy_filter={'operator_name': 'operator1'},
            limit=3,
            offset=0,
            return_as='dict')
        self.assertEqual(len(result), 0)

        self.grouping.unconsume_all_members(group_test1_id)

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id,
            lazy_filter={'operator_name': 'operator1'})
        self.assertEqual(unconsumed_count, 3)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 0)

        result = self.grouping.get_group_unconsumed_members(
            group_test1_id,
            sort=[['cpe.cpeid', 'asc']],
            lazy_filter={'operator_name': 'operator1'},
            limit=3,
            offset=0,
            return_as='dict')
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')

    def test_get_membership(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'lazy', ['cpe.cpeid'],
            [['Operator.account_name', '=', '%(operator_name)s'], 'or',
             ['Enterprise.account_name', '=', '%(enterprise_name)s']])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'lazy')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         [['Operator.account_name', '=', '%(operator_name)s'],
                          'or',
                          ['Enterprise.account_name', '=', '%(enterprise_name)s']])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
                build_query(query_map),
                ' '.join(['SELECT', 'cpe.cpeid', 'FROM',
                    'CPEManager_CPEs AS `cpe`',
                    'LEFT JOIN vss_OPERATOR AS `Operator`',
                    'ON cpe.cid2 = Operator.account_name',
                    'INNER JOIN vss_ENTERPRISE AS `Enterprise`',
                    'ON Operator.account_parent = Enterprise.account_name',
                    'WHERE',
                    '(Operator.account_name = %(operator_name)s or ' \
                            'Enterprise.account_name = %(enterprise_name)s)']))

        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cid2', '=', 'operator1'])
        group_definition = self.grouping.search_groups_by_name('test2')[0]
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['cpe.cid2', '=', 'operator1'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE', 'cpe.cid2 = operator1'
            ]))

        membership = self.grouping.get_group_membership('cpe.cpeid',
                                                        'ZZ0000000001')
        self.assertEqual(len(membership), 1)
        self.assertTrue(group_test2_id in membership)

        membership = self.grouping.get_group_membership('cpe.cpeid',
                                                        'ZZ0000000002')
        self.assertEqual(len(membership), 0)

        membership = self.grouping.get_group_membership('cpe.cpeid',
                                                        'ZZ0000000001')
        self.assertEqual(len(membership), 1)
        self.assertTrue(group_test2_id in membership)

        membership = self.grouping.get_group_membership('cpe.cpeid',
                                                        'ZZ0000000001')
        self.assertEqual(len(membership), 1)
        self.assertTrue(group_test2_id in membership)

    def test_is_member(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'lazy', ['cpe.cpeid'],
            [['Operator.account_name', '=', 'operator1'], 'or',
             ['Enterprise.account_name', '=', '%(enterprise_name)s']])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'lazy')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         [['Operator.account_name', '=', 'operator1'],
                          'or',
                          ['Enterprise.account_name', '=', '%(enterprise_name)s']])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
                build_query(query_map),
                ' '.join(['SELECT', 'cpe.cpeid', 'FROM',
                    'CPEManager_CPEs AS `cpe`',
                    'LEFT JOIN vss_OPERATOR AS `Operator`',
                    'ON cpe.cid2 = Operator.account_name',
                    'INNER JOIN vss_ENTERPRISE AS `Enterprise`',
                    'ON Operator.account_parent = Enterprise.account_name',
                    'WHERE',
                    '(Operator.account_name = operator1 or ' \
                            'Enterprise.account_name = %(enterprise_name)s)']))

        with self.assertRaises(ValueError) as context:
            self.grouping.is_member('cpe.cpeid', 'ZZ0000000001',
                                    group_test1_id)
        self.assertEqual("Cannot verify membership for " \
                "cpe.cpeid=ZZ0000000001 against group %d: " \
                "Cannot resolve lazy filter: Key 'enterprise_name' not found" % group_test1_id,
                str(context.exception))

        with self.assertRaises(ValueError) as context:
            self.grouping.is_member(
                'cpe.cpeid',
                'ZZ0000000001',
                group_test1_id,
                lazy_filter={'operator_name': 'operator1'})
        self.assertTrue("Cannot verify membership for " \
                "cpe.cpeid=ZZ0000000001 against group %d: " \
                "lazy filters cannot be resolved" % group_test1_id,
                str(context.exception))

        self.assertTrue(
            self.grouping.is_member(
                'cpe.cpeid',
                'ZZ0000000001',
                group_test1_id,
                lazy_filter={
                    'enterprise_name': 'enterprise1',
                    'operator_name': 'operator1'
                }))
        self.assertFalse(
            self.grouping.is_member(
                'cpe.cpeid',
                'ZZ0000000002',
                group_test1_id,
                lazy_filter={'enterprise_name': 'enterprise1'}))
        self.assertTrue(
            self.grouping.is_member(
                'cpe.cpeid',
                'ZZ0000000003',
                group_test1_id,
                lazy_filter={'enterprise_name': 'enterprise1'}))
        self.assertTrue(
            self.grouping.is_member(
                'cpe.cpeid',
                'ZZ0000000004',
                group_test1_id,
                lazy_filter={'enterprise_name': 'enterprise1'}))

@unittest2.skipIf(PY3, "Cannot run under python3")
@unittest2.skipIf(not mysql_available, "Cannot run without MySQLdb")
class TestAXGroupingStatic(unittest2.TestCase):
    def setUp(self):
        _create_engine()
        self.grouping = Grouping(GroupTestSchema, engine)
        prepare_data()

    def tearDown(self):
        cleanup_data()

    def test_create_group(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'static',
            ['cpe.cpeid'], [
                'cpe.cpeid', 'in', ('ZZ0000000001', 'ZZ0000000002',
                                    'ZZ0000000003', 'ZZ0000000004')
            ])
        group_definition = self.grouping.get_group_by_id(group_test1_id)
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'static')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'], None)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'GroupStaticRelation.member_id', 'FROM',
                'AXGroupStaticRelation AS `GroupStaticRelation`',
                'WHERE',
                'GroupStaticRelation.group_id = %s' % group_test1_id
            ]))

        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'static', ['cpe.cpeid'], [
                'Enterprise.account_name', '=', 'enterprise1'
            ])
        group_definition = self.grouping.get_group_by_id(group_test2_id)
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'static')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'], None)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'GroupStaticRelation.member_id', 'FROM',
                'AXGroupStaticRelation AS `GroupStaticRelation`',
                'WHERE',
                'GroupStaticRelation.group_id = %s' % group_test2_id
            ]))

    def test_create_group_wrong_filter(self):
        with self.assertRaises(ValueError) as context:
            self.grouping.create_group(
                'test1', 'test group', 'test_user', 'static',
                ['cpe.cpeid', 'cpe.version'],
                [['Operator.account_name', '=', 'operator1'], 'or',
                 ['Operator.account_name', '=', 'operator2']])
        self.assertTrue("Cannot create group test1: Static group must have only "
                        "one parameter in the result list ", str(context.exception))

    def test_create_group_of_110(self):
        # This will be cleaned up in teardown
        for i in range(1010):
            engine.execute("INSERT INTO AXTickets(extTicketid) VALUES('test')")

        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'static',
            ['Ticket.ticketid'],
            ['Ticket.extTicketid', '=', 'test'])
        group_definition = self.grouping.get_group_by_id(group_test1_id)
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'static')
        self.assertEqual(group_definition['domain'], 'Ticket')
        self.assertEqual(group_definition['filter'], None)

        result = self.grouping.get_group_members(
            group_definition['id'], limit=None, return_as='list')
        self.assertEqual(len(result), 1010)

    def test_update_group(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['Operator.account_name', '=', 'operator1'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'LEFT JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                'Operator.account_name = operator1'
            ]))

        self.grouping.update_group(
            group_test1_id, 'test_user', 'test1', 'test group', 'lazy',
            ['Operator.account_name'], ['cpe.cpeid', '=', '%(cpeid)s'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'lazy')
        self.assertEqual(group_definition['domain'], 'Operator')
        self.assertEqual(group_definition['filter'],
                         ['cpe.cpeid', '=', '%(cpeid)s'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'Operator.account_name', 'FROM',
                'vss_OPERATOR AS `Operator`',
                'LEFT JOIN CPEManager_CPEs AS `cpe`',
                'ON Operator.account_name = cpe.cid2', 'WHERE',
                'cpe.cpeid = %(cpeid)s'
            ]))

        self.grouping.update_group(group_test1_id, 'test_user', 'test1',
                                   'test group', 'static',
                                   ['cpe.cpeid'],
                                   ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'static')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'], None)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'GroupStaticRelation.member_id', 'FROM',
                'AXGroupStaticRelation AS `GroupStaticRelation`',
                'WHERE', 'GroupStaticRelation.group_id = %s' % group_test1_id
            ]))

        result = self.grouping.get_group_members(
            group_test1_id, sort=[['cpe.cpeid', 'asc']], return_as='dict')
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')

        self.grouping.update_group(group_test1_id, 'test_user', 'test1',
                                   'test group', 'dynamic', ['cpe.cpeid'],
                                   ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['Operator.account_name', '=', 'operator1'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'LEFT JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name', 'WHERE',
                'Operator.account_name = operator1'
            ]))

        self.grouping.update_group(group_test1_id, 'test_user', 'test1',
                                   'test group', 'static',
                                   ['cpe.cpeid'],
                                   ['User.account_name', '=', 'user2'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'static')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'], None)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'GroupStaticRelation.member_id', 'FROM',
                'AXGroupStaticRelation AS `GroupStaticRelation`',
                'WHERE', 'GroupStaticRelation.group_id = %s' % group_test1_id
            ]))

        result = self.grouping.get_group_members(
            group_test1_id, sort=[['cpe.cpeid', 'asc']], return_as='dict')
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000004')


    def test_get_members(self):
        self.test_create_group()
        group_test1 = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_test1['name'], 'test1')
        self.assertEqual(group_test1['type'], 'static')
        self.assertEqual(group_test1['filter'], None)
        query_map = json.loads(group_test1['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'GroupStaticRelation.member_id', 'FROM',
                'AXGroupStaticRelation AS `GroupStaticRelation`',
                'WHERE',
                'GroupStaticRelation.group_id = %s' % group_test1['id']
            ]))

        all_results = []
        result = self.grouping.get_group_members(
            group_test1['id'], limit=3, offset=0, return_as='dict')
        all_results.extend(result)
        self.assertEqual(len(result), 3)

        result = self.grouping.get_group_members(
            group_test1['id'], limit=3, offset=3, return_as='dict')
        all_results.extend(result)
        self.assertEqual(len(result), 1)

        all_results = sorted(all_results, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(all_results[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(all_results[1]['cpe.cpeid'], 'ZZ0000000002')
        self.assertEqual(all_results[2]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(all_results[3]['cpe.cpeid'], 'ZZ0000000004')
        self.assertEqual(
            self.grouping.get_group_member_count(group_test1['id']), len(all_results))

        # Get members with conditions
        result = self.grouping.get_group_members_with_condition(
            [group_test1['id']],
            ['User.account_name', '=', 'user1'],
            ['Enterprise.account_name', 'cpe.cpeid'])
        count = self.grouping.get_group_members_with_condition_count(
            [group_test1['id']],
            ['User.account_name', '=', 'user1'])
        self.assertEqual(len(result), 2)
        self.assertEqual(len(result), count)
        result = sorted(result, key=lambda k: k[0])
        self.assertEqual(result[0][0], 'enterprise1')
        self.assertEqual(result[0][1], 'ZZ0000000001')
        self.assertEqual(result[1][0], 'enterprise1')
        self.assertEqual(result[1][1], 'ZZ0000000004')

    def test_get_extended_members(self):
        self.test_create_group()
        group_test1 = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_test1['name'], 'test1')
        self.assertEqual(group_test1['type'], 'static')
        query_map = json.loads(group_test1['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'GroupStaticRelation.member_id', 'FROM',
                'AXGroupStaticRelation AS `GroupStaticRelation`',
                'WHERE',
                'GroupStaticRelation.group_id = %s' % group_test1['id']
            ]))

        result = self.grouping.get_group_extended_members(
            group_test1['id'], ['cpe.IP'], sort=[['cpe.IP', 'asc']])
        self.assertEqual(
            len(result),
            self.grouping.get_group_extended_members_count(
                group_test1['id'], ['cpe.IP']))

        self.assertEqual(result[0][0], '10.0.0.135')
        self.assertEqual(result[1][0], '10.0.0.136')
        self.assertEqual(result[2][0], '10.0.0.137')
        self.assertEqual(result[3][0], '10.0.0.138')

        # Insert new cpe for operator1 which should not be returned by the
        # extended members call
        engine.execute("INSERT INTO CPEManager_CPEs("
                    "cid, cid2, cpeid, cpetype, path, version, IP, "
                    "unmanagedProps, pendingProps, props, scProps, "
                    "events, methods, comments, roles) "
                    "VALUES('', 'operator1', 'ZZ0000000005', 'genericTR69', '',"
                    "'version1__HardwareVersion1__1.011', '10.0.0.140', '[]',"
                    "'{}','{}','{}','[]','','','unsupportedFW')")

        result = self.grouping.get_group_extended_members(
            group_test1['id'],
            ['cpe.IP'],
            ['Operator.account_name', '=', 'operator1'],
            sort=[['cpe.IP', 'asc']])
        self.assertEqual(
            len(result),
            self.grouping.get_group_extended_members_count(
                group_test1['id'],
                ['cpe.IP'],
                ['Operator.account_name', '=', 'operator1']))
        self.assertEqual(result[0][0], '10.0.0.135')
        self.assertEqual(result[1][0], '10.0.0.136')
        self.assertEqual(result[2][0], '10.0.0.138')

        result = self.grouping.get_group_extended_members(
            group_test1['id'],
            filter_list=['Operator.account_name', '=', 'operator1'],
            sort=[['cpe.IP', 'asc']],
            return_as='dict')
        self.assertEqual(
            len(result),
            self.grouping.get_group_extended_members_count(
                group_test1['id'],
                filter_list=['Operator.account_name', '=', 'operator1']))
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')

        group_test2 = self.grouping.search_groups_by_name('test2')[0]
        self.assertEqual(group_test2['name'], 'test2')
        self.assertEqual(group_test2['type'], 'static')

        result = self.grouping.get_group_extended_members(
            group_test2['id'],
            filter_list=['User.account_name', '=', 'user2'],
            sort=[['cpe.cpeid', 'asc']])
        self.assertEqual(
            len(result),
            self.grouping.get_group_extended_members_count(
                group_test2['id'],
                filter_list=['User.account_name', '=', 'user2']))

        self.assertEqual(result[0][0], 'ZZ0000000003')
        self.assertEqual(result[1][0], 'ZZ0000000004')

        # Add a cpe(already done above), create group, delete cpe,
        # but it should still show up in extended members
        group_id = self.grouping.create_group(
            'static_test1', 'test group', 'test_user', 'static', ['cpe.cpeid'],
            ['Operator.account_name', '=', 'operator1'])

        result = self.grouping.get_group_extended_members(
            group_id, ['IP', 'cpeid'], sort=[['cpe.IP', 'asc']],
            return_as='dict')
        self.assertEqual(
            len(result),
            self.grouping.get_group_extended_members_count(
                group_test1['id'], ['cpe.IP', 'cpe.cpeid']))

        self.assertEqual(result[0]['cpe.IP'], '10.0.0.135')
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.IP'], '10.0.0.136')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.IP'], '10.0.0.138')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')
        self.assertEqual(result[3]['cpe.IP'], '10.0.0.140')
        self.assertEqual(result[3]['cpe.cpeid'], 'ZZ0000000005')

        engine.execute("DELETE FROM CPEManager_CPEs WHERE cpeid = "
                       "'ZZ0000000005'")

        result = self.grouping.get_group_extended_members(
            group_id, ['IP', 'cpeid'], sort=[['cpe.cpeid', 'asc']],
            return_as='dict')

        self.assertEqual(result[0]['cpe.IP'], '10.0.0.135')
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.IP'], '10.0.0.136')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.IP'], '10.0.0.138')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')
        self.assertEqual(result[3]['cpe.IP'], None)
        self.assertEqual(result[3]['cpe.cpeid'], 'ZZ0000000005')

    def test_get_members_static_vs_dynamic(self):
        static_group_id = self.grouping.create_group(
            'static_operator1_cpes', 'test group', 'test_user', 'static', ['cpe.cpeid'], [
                'Operator.account_name', '=', 'operator1'
            ])
        static_group_def = self.grouping.get_group_by_id(static_group_id)
        self.assertEqual(static_group_def['name'], 'static_operator1_cpes')
        self.assertEqual(static_group_def['type'], 'static')
        self.assertEqual(static_group_def['domain'], 'cpe')
        self.assertEqual(static_group_def['filter'], None)
        query_map = json.loads(static_group_def['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'GroupStaticRelation.member_id', 'FROM',
                'AXGroupStaticRelation AS `GroupStaticRelation`',
                'WHERE',
                'GroupStaticRelation.group_id = %s' % static_group_id
            ]))

        dynamic_group_id = self.grouping.create_group(
            'dynamic_operator1_cpes', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'], [
                'Operator.account_name', '=', 'operator1'
            ])
        dynamic_group_def = self.grouping.get_group_by_id(dynamic_group_id)
        self.assertEqual(dynamic_group_def['name'], 'dynamic_operator1_cpes')
        self.assertEqual(dynamic_group_def['type'], 'dynamic')
        self.assertEqual(dynamic_group_def['domain'], 'cpe')
        self.assertEqual(dynamic_group_def['filter'],
                         ['Operator.account_name', '=', 'operator1'])
        query_map = json.loads(dynamic_group_def['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM',
                'CPEManager_CPEs AS `cpe`',
                'LEFT JOIN vss_OPERATOR AS `Operator`',
                'ON cpe.cid2 = Operator.account_name',
                'WHERE',
                'Operator.account_name = operator1'
            ]))

        result = self.grouping.get_group_members(
            static_group_def['id'], sort=[['cpe.cpeid', 'asc']], return_as='dict')
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')
        self.assertEqual(
            self.grouping.get_group_member_count(
                static_group_def['id']), len(result))

        result = self.grouping.get_group_members(
            dynamic_group_def['id'], sort=[['cpe.cpeid', 'asc']], return_as='dict')
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')
        self.assertEqual(
            self.grouping.get_group_member_count(
                dynamic_group_def['id']), len(result))

        engine.execute("INSERT INTO CPEManager_CPEs("
                   "cid, cid2, cpeid, cpetype, path, version, IP, "
                   "unmanagedProps, pendingProps, props, scProps, "
                   "events, methods, comments, roles) "
                   "VALUES('', 'operator1', 'ZZ0000000005', 'genericTR69', '',"
                   "'version1__HardwareVersion1__1.011', '10.0.0.139', '[]',"
                   "'{}','{}','{}','[]','','','unsupportedFW')")

        result = self.grouping.get_group_members(
            static_group_def['id'],
            sort=[['cpe.cpeid', 'desc']],
            return_as='dict')
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000004')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(
            self.grouping.get_group_member_count(static_group_def['id']), len(result))

        result = self.grouping.get_group_members(
            dynamic_group_def['id'], sort=[['cpe.cpeid', 'desc']], return_as='dict')
        self.assertEqual(len(result), 4)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000005')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000004')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[3]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(
            self.grouping.get_group_member_count(
                dynamic_group_def['id']), len(result))

    def test_get_group_unconsumed_members(self):
        self.test_create_group()
        group_test1 = self.grouping.search_groups_by_name('test1')[0]
        group_test1_id = group_test1['id']

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id)
        self.assertEqual(unconsumed_count, 4)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 0)

        result = self.grouping.get_group_unconsumed_members(
            group_test1_id, sort=[['cpe.cpeid', 'asc']],
            limit=4, offset=0, return_as='dict')

        self.assertEqual(len(result), 4)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000002')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[3]['cpe.cpeid'], 'ZZ0000000004')

        self.grouping.consume_member(group_test1_id, 'ZZ0000000001')
        self.grouping.consume_member(group_test1_id, 'ZZ0000000003')

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id)
        self.assertEqual(unconsumed_count, 2)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 2)

        result = self.grouping.get_group_unconsumed_members(
            group_test1_id, sort=[['cpe.cpeid', 'asc']],
            limit=2, offset=0, return_as='dict')
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000002')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000004')

        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000001'))
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000003'))
        self.assertFalse(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000004'))
        self.assertFalse(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000002'))

        self.grouping.consume_member(group_test1_id, 'ZZ0000000002')
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000002'))
        self.grouping.consume_member(group_test1_id, 'ZZ0000000004')
        self.assertTrue(
            self.grouping.is_member_consumed(group_test1_id, 'ZZ0000000004'))

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id)
        self.assertEqual(unconsumed_count, 0)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 4)

        result = self.grouping.get_group_unconsumed_members(
            group_test1_id, limit=4, offset=0, return_as='list')
        self.assertEqual(len(result), 0)

        self.grouping.unconsume_all_members(group_test1_id)

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id)
        self.assertEqual(unconsumed_count, 4)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 0)

        result = self.grouping.get_group_unconsumed_members(
            group_test1_id, sort=[['cpe.cpeid', 'asc']],
            limit=4, offset=0, return_as='list')
        self.assertEqual(len(result), 4)
        self.assertEqual(result[0][0], 'ZZ0000000001')
        self.assertEqual(result[1][0], 'ZZ0000000002')
        self.assertEqual(result[2][0], 'ZZ0000000003')
        self.assertEqual(result[3][0], 'ZZ0000000004')

        self.grouping.consume_members(group_test1_id, ['ZZ0000000001', 'ZZ0000000002', 'ZZ0000000003', 'ZZ0000000004'])
        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test1_id)
        self.assertEqual(unconsumed_count, 0)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test1_id)
        self.assertEqual(consumed_count, 4)

    def test_get_group_unconsumed_members2(self):
        self.test_create_group()
        group_test2 = self.grouping.search_groups_by_name('test2')[0]
        group_test2_id = group_test2['id']

        result = self.grouping.get_group_members(
            group_test2_id, sort=[['cpe.cpeid', 'asc']], return_as='dict')
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')
        self.assertEqual(
            self.grouping.get_group_member_count(
                group_test2_id), len(result))

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test2_id)
        self.assertEqual(unconsumed_count, 3)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test2_id)
        self.assertEqual(consumed_count, 0)

        result = self.grouping.get_group_unconsumed_members(
            group_test2_id, sort=[['cpe.cpeid', 'asc']],
            limit=4, offset=0, return_as='dict')

        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')

        self.grouping.consume_member(group_test2_id, 'ZZ0000000001')
        self.grouping.consume_member(group_test2_id, 'ZZ0000000003')

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test2_id)
        self.assertEqual(unconsumed_count, 1)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test2_id)
        self.assertEqual(consumed_count, 2)

        result = self.grouping.get_group_unconsumed_members(
            group_test2_id, sort=[['cpe.cpeid', 'asc']],
            limit=2, offset=0, return_as='dict')
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000004')

        self.assertTrue(
            self.grouping.is_member_consumed(group_test2_id, 'ZZ0000000001'))
        self.assertTrue(
            self.grouping.is_member_consumed(group_test2_id, 'ZZ0000000003'))
        self.assertFalse(
            self.grouping.is_member_consumed(group_test2_id, 'ZZ0000000004'))

        self.grouping.consume_member(group_test2_id, 'ZZ0000000004')
        self.assertTrue(
            self.grouping.is_member_consumed(group_test2_id, 'ZZ0000000004'))

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test2_id)
        self.assertEqual(unconsumed_count, 0)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test2_id)
        self.assertEqual(consumed_count, 3)

        result = self.grouping.get_group_unconsumed_members(
            group_test2_id, limit=4, offset=0, return_as='list')
        self.assertEqual(len(result), 0)

        self.grouping.unconsume_all_members(group_test2_id)

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test2_id)
        self.assertEqual(unconsumed_count, 3)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test2_id)
        self.assertEqual(consumed_count, 0)

        result = self.grouping.get_group_unconsumed_members(
            group_test2_id, sort=[['cpe.cpeid', 'asc']],
            limit=4, offset=0, return_as='list')
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0][0], 'ZZ0000000001')
        self.assertEqual(result[1][0], 'ZZ0000000003')
        self.assertEqual(result[2][0], 'ZZ0000000004')

        self.grouping.consume_members(
            group_test2_id,
            ['ZZ0000000001', 'ZZ0000000003', 'ZZ0000000004'])
        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_test2_id)
        self.assertEqual(unconsumed_count, 0)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_test2_id)
        self.assertEqual(consumed_count, 3)

    def test_get_membership(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'static',
            ['cpe.cpeid'], [
                'cpe.cpeid', 'in', ('ZZ0000000001', 'ZZ0000000002',
                                    'ZZ0000000003', 'ZZ0000000004')
            ])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'static')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'], None)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'GroupStaticRelation.member_id', 'FROM',
                'AXGroupStaticRelation AS `GroupStaticRelation`',
                'WHERE',
                'GroupStaticRelation.group_id = %s' % group_test1_id
            ]))

        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'static',
            ['cpe.cpeid'],
            ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.search_groups_by_name('test2')[0]
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'static')
        self.assertEqual(group_definition['domain'], 'cpe')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'GroupStaticRelation.member_id', 'FROM',
                'AXGroupStaticRelation AS `GroupStaticRelation`',
                'WHERE',
                'GroupStaticRelation.group_id = %s' % group_test2_id
            ]))

        group_test3_id = self.grouping.create_group(
            'test3', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cpeid', '=', 'ZZ0000000001'])
        group_definition = self.grouping.search_groups_by_name('test3')[0]
        self.assertEqual(group_definition['name'], 'test3')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE', 'cpe.cpeid = ZZ0000000001'
            ]))

        membership = self.grouping.get_group_membership('cpe.cpeid',
                                                        'ZZ0000000004')
        self.assertEqual(len(membership), 2)
        self.assertTrue(group_test1_id in membership)
        self.assertTrue(group_test2_id in membership)

        membership = self.grouping.get_group_membership('cpe',
                                                        'ZZ0000000001')
        self.assertEqual(len(membership), 3)
        self.assertTrue(group_test1_id in membership)
        self.assertTrue(group_test2_id in membership)
        self.assertTrue(group_test3_id in membership)

        membership = self.grouping.get_group_membership('Operator.account_name',
                                                        'operator1')
        self.assertEqual(len(membership), 0)

    def test_is_member(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'static',
            ['cpe.cpeid'], [
                'cpe.cpeid', 'in', ('ZZ0000000001', 'ZZ0000000002',
                                    'ZZ0000000003', 'ZZ0000000004')
            ])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'static')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'], None)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'GroupStaticRelation.member_id', 'FROM',
                'AXGroupStaticRelation AS `GroupStaticRelation`',
                'WHERE',
                'GroupStaticRelation.group_id = %s' % group_test1_id
            ]))

        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'static',
            ['cpe.cpeid'],
            ['Operator.account_name', '=', 'operator1'])
        group_definition = self.grouping.search_groups_by_name('test2')[0]
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'static')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'], None)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'GroupStaticRelation.member_id', 'FROM',
                'AXGroupStaticRelation AS `GroupStaticRelation`',
                'WHERE', 'GroupStaticRelation.group_id = %s' % group_test2_id
            ]))

        group_test3_id = self.grouping.create_group(
            'test3', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cpeid', '=', 'ZZ0000000001'])
        group_definition = self.grouping.search_groups_by_name('test3')[0]
        self.assertEqual(group_definition['name'], 'test3')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['cpe.cpeid', '=', 'ZZ0000000001'])
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                'SELECT', 'cpe.cpeid', 'FROM', 'CPEManager_CPEs AS `cpe`',
                'WHERE', 'cpe.cpeid = ZZ0000000001'
            ]))

        self.assertTrue(
            self.grouping.is_member('cpe.cpeid', 'ZZ0000000001',
                                    group_test1_id))
        self.assertTrue(
            self.grouping.is_member('cpe.cpeid', 'ZZ0000000001',
                                    group_test2_id))
        self.assertTrue(
            self.grouping.is_member('cpe', 'ZZ0000000001', group_test3_id))

        self.assertTrue(
            self.grouping.is_member('cpe', 'ZZ0000000002', group_test1_id))

        self.assertFalse(
            self.grouping.is_member('cpe.cpeid', 'ZZ0000000002', group_test2_id))

        self.assertFalse(
            self.grouping.is_member('cpe', 'ZZ0000000002', group_test3_id))

        self.assertTrue(
            self.grouping.is_member('cpe', 'ZZ0000000003', group_test1_id))

        self.assertTrue(
            self.grouping.is_member('cpe', 'ZZ0000000003', group_test2_id))

        self.assertFalse(
            self.grouping.is_member('cpe.cpeid', 'ZZ0000000003', group_test3_id))

        self.assertFalse(
            self.grouping.is_member('User.account_name', 'user1',
                                    group_test2_id))
        self.assertFalse(
            self.grouping.is_member('User', 'user1',
                                    group_test1_id))
        self.assertFalse(
            self.grouping.is_member('Operator.account_name', 'operator1',
                                    group_test2_id))

@unittest2.skipIf(PY3, "Cannot run under python3")
@unittest2.skipIf(not mysql_available, "Cannot run without MySQLdb")
class TestAXGroupingSuper(unittest2.TestCase):
    def setUp(self):
        _create_engine()
        self.grouping = Grouping(GroupTestSchema, engine)
        prepare_data()

    def tearDown(self):
        cleanup_data()

    def test_create_group_on_lazy_groups_with_overlapping_placeholders(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'lazy', ['cpe.cpeid'],
            ['cpe.cpeid', '=', '%(cpeid)s'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'lazy')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['cpe.cpeid', '=', '%(cpeid)s'])

        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'lazy', ['cpe.cpeid'],
            [['cpe.cpetype', '=', '%(cpetype)s'], 'and',
             ['cpe.cpeid', '=', '%(cpeid)s']])
        group_definition = self.grouping.search_groups_by_name('test2')[0]
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'lazy')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         [['cpe.cpetype', '=', '%(cpetype)s'], 'and',
                          ['cpe.cpeid', '=', '%(cpeid)s']])

        group_super_test1_id = 0
        with self.assertRaises(Exception) as context:
            group_super_test1_id = self.grouping.create_super_group(
                'super_test1', 'test group', 'test_user',
                [group_test2_id, group_test1_id])
        self.assertTrue("Failed to create super group: "
                        "Sub-groups have overlapping placeholders",
                        str(context.exception))

    def test_create_group_disjoint_resultsets(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic',
            ['cpe.cpeid', 'cpe.cid'], ['cpe.cpeid', '=', 'ZZ0000000002'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['cpe.cpeid', '=', 'ZZ0000000002'])

        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'dynamic',
            ['cpe.cpeid', 'cpe.cpetype'], ['User.account_name', '=', 'user2'])
        group_definition = self.grouping.search_groups_by_name('test2')[0]
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['User.account_name', '=', 'user2'])

        with self.assertRaises(Exception) as context:
            group_test1_id = 0
            group_test1_id = self.grouping.create_super_group(
                'super_test1', 'test group', 'test_user',
                [group_test2_id, group_test1_id])
        self.assertEqual("Failed to create super group: "
                        "Group %d does not exist" % group_test1_id,
                        str(context.exception))

    def test_create_group(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cpeid', '=', 'ZZ0000000002'])
        group_definition = self.grouping.get_group_by_id(group_test1_id)
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['cpe.cpeid', '=', 'ZZ0000000002'])

        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'static', ['cpe.cpeid'],
            ['User.account_name', '=', 'user2'])
        group_definition = self.grouping.get_group_by_id(group_test2_id)
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'static')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'], None)

        group_super_test1_id = self.grouping.create_super_group(
            'super_test1', 'test super group', 'test_user',
            [group_test1_id, group_test2_id])
        group_definition = self.grouping.get_group_by_id(group_super_test1_id)
        self.assertEqual(group_definition['name'], 'super_test1')
        self.assertEqual(group_definition['type'], 'super')
        self.assertEqual(group_definition['domain'], None)
        self.assertEqual(group_definition['filter'], None)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = ZZ0000000002",
                "UNION",
                "SELECT", "GroupStaticRelation.member_id",
                "FROM", "AXGroupStaticRelation AS `GroupStaticRelation`",
                "WHERE",
                "GroupStaticRelation.group_id = %s" % group_test2_id
            ]))
        children = self.grouping.get_children(group_super_test1_id)
        self.assertEqual([group_test1_id, group_test2_id], sorted(children))

        group_test3_id = self.grouping.create_group(
            'test3', 'test group', 'test_user', 'lazy', ['cpe.cpeid'],
            ['cpe.cpeid', '=', '%(cpeid)s'])
        group_definition = self.grouping.get_group_by_id(group_test3_id)
        self.assertEqual(group_definition['name'], 'test3')
        self.assertEqual(group_definition['type'], 'lazy')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'],
                         ['cpe.cpeid', '=', '%(cpeid)s'])

        group_super_test2_id = self.grouping.create_super_group(
            'super_test2', 'test super group', 'test_user',
            [group_test3_id, group_super_test1_id])
        group_definition = self.grouping.get_group_by_id(group_super_test2_id)
        self.assertEqual(group_definition['name'], 'super_test2')
        self.assertEqual(group_definition['type'], 'super')
        self.assertEqual(group_definition['domain'], None)
        self.assertEqual(group_definition['filter'], None)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = ZZ0000000002",
                "UNION",
                "SELECT", "GroupStaticRelation.member_id",
                "FROM", "AXGroupStaticRelation AS `GroupStaticRelation`",
                "WHERE",
                "GroupStaticRelation.group_id = %s" % group_test2_id,
                "UNION",
                "SELECT", "cpe.cpeid",
                "FROM", "CPEManager_CPEs AS `cpe`", "WHERE",
                "cpe.cpeid = %(cpeid)s"
            ]))
        children = self.grouping.get_children(group_super_test2_id)
        self.assertEqual([group_super_test1_id, group_test3_id], sorted(children))

        group_super_test3_id = self.grouping.create_super_group(
            'super_test3',
            'test super group',
            'test_user',
            [group_super_test1_id, group_test3_id],
            internal=False,
            cond=['Enterprise.account_name', '=', 'enterprise1'])
        group_definition = self.grouping.get_group_by_id(group_super_test3_id)
        self.assertEqual(group_definition['name'], 'super_test3')
        self.assertEqual(group_definition['type'], 'super')
        self.assertEqual(group_definition['domain'], None)
        self.assertEqual(group_definition['filter'], None)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            query_map['_axgroup_metadata']['super_cond'],
            ['Enterprise.account_name', '=', 'enterprise1'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "LEFT JOIN vss_OPERATOR AS `Operator`",
                "ON cpe.cid2 = Operator.account_name",
                "INNER JOIN vss_ENTERPRISE AS `Enterprise`",
                "ON Operator.account_parent = Enterprise.account_name",
                "WHERE", "(cpe.cpeid = ZZ0000000002",
                "and", "Enterprise.account_name = enterprise1)",
                "UNION",
                "SELECT", "AXGroupStaticRelation.member_id",
                "FROM", "CPEManager_CPEs AS `cpe`",
                "LEFT JOIN vss_OPERATOR AS `Operator`",
                "ON cpe.cid2 = Operator.account_name",
                "INNER JOIN vss_ENTERPRISE AS `Enterprise`",
                "ON Operator.account_parent = Enterprise.account_name",
                "RIGHT JOIN AXGroupStaticRelation",
                "ON cpe.cpeid = AXGroupStaticRelation.member_id",
                "WHERE",
                "Enterprise.account_name = enterprise1",
                "AND",
                "AXGroupStaticRelation.group_id = %s" % group_test2_id,
                "UNION",
                "SELECT", "cpe.cpeid",
                "FROM", "CPEManager_CPEs AS `cpe`",
                "LEFT JOIN vss_OPERATOR AS `Operator`",
                "ON cpe.cid2 = Operator.account_name",
                "INNER JOIN vss_ENTERPRISE AS `Enterprise`",
                "ON Operator.account_parent = Enterprise.account_name",
                "WHERE", "(cpe.cpeid = %(cpeid)s",
                "and", "Enterprise.account_name = enterprise1)"
            ]))
        children = self.grouping.get_children(group_super_test3_id)
        self.assertEqual(2, len(children))
        self.assertEqual([group_super_test1_id, group_test3_id], sorted(children))

        group_super_test4_id = self.grouping.create_super_group(
            'super_test4',
            'test super group',
            'test_user',
            [group_super_test1_id, group_test3_id],
            internal=False,
            cond=[])
        group_definition = self.grouping.get_group_by_id(group_super_test4_id)
        self.assertEqual(group_definition['name'], 'super_test4')
        self.assertEqual(group_definition['type'], 'super')
        self.assertEqual(group_definition['domain'], None)
        self.assertEqual(group_definition['filter'], None)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = ZZ0000000002",
                "UNION",
                "SELECT", "GroupStaticRelation.member_id",
                "FROM",
                "AXGroupStaticRelation AS `GroupStaticRelation`",
                "WHERE",
                "GroupStaticRelation.group_id = %s" % group_test2_id,
                "UNION",
                "SELECT", "cpe.cpeid",
                "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = %(cpeid)s",
            ]))
        children = self.grouping.get_children(group_super_test3_id)
        self.assertEqual(2, len(children))
        self.assertEqual([group_super_test1_id, group_test3_id], sorted(children))

        with self.assertRaises(Exception) as context:
            self.grouping.create_super_group(
                'super_test5',
                'test super group',
                'test_user',
                [group_super_test3_id, group_test3_id],
                internal=False,
                cond=['cpe.cpeid', '=', 'x'])
        self.assertEqual("Failed to create super group: "
                        "Cannot build a super group referencing another "
                        "super group with condition(%s)" %
                        group_super_test3_id, str(context.exception))

        group_test5_id = self.grouping.create_group(
            'test5', 'test group', 'test_user', 'static', ['cpe.cpeid'],
            ['cpe.cpeid', '=', 'ZZ0000000002'])
        group_definition = self.grouping.get_group_by_id(group_test5_id)
        self.assertEqual(group_definition['name'], 'test5')
        self.assertEqual(group_definition['type'], 'static')
        self.assertEqual(group_definition['domain'], 'cpe')
        self.assertEqual(group_definition['filter'], None)

        group_super_test5_id = self.grouping.create_super_group(
            'super_test5', 'test super group', 'test_user',
            [group_test1_id])
        group_definition = self.grouping.get_group_by_id(group_super_test5_id)
        self.assertEqual(group_definition['name'], 'super_test5')
        self.assertEqual(group_definition['type'], 'super')
        self.assertEqual(group_definition['domain'], None)
        self.assertEqual(group_definition['filter'], None)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = ZZ0000000002",
            ]))
        children = self.grouping.get_children(group_super_test5_id)
        self.assertEqual([group_test1_id], sorted(children))

        group_super_test6_id = self.grouping.create_super_group(
            'super_test6', 'test super group', 'test_user',
            [group_test2_id, group_test5_id])
        group_definition = self.grouping.get_group_by_id(group_super_test6_id)
        self.assertEqual(group_definition['name'], 'super_test6')
        self.assertEqual(group_definition['type'], 'super')
        self.assertEqual(group_definition['domain'], None)
        self.assertEqual(group_definition['filter'], None)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "GroupStaticRelation.member_id",
                "FROM", "AXGroupStaticRelation AS `GroupStaticRelation`",
                "WHERE",
                "GroupStaticRelation.group_id = %s" % group_test5_id,
                "UNION",
                "SELECT", "GroupStaticRelation.member_id",
                "FROM", "AXGroupStaticRelation AS `GroupStaticRelation`",
                "WHERE",
                "GroupStaticRelation.group_id = %s" % group_test2_id,
            ]))
        children = self.grouping.get_children(group_super_test6_id)
        self.assertEqual([group_test2_id, group_test5_id], sorted(children))

    def test_group_search(self):
        # Create groups
        self.test_create_group()

        super_groups = self.grouping.get_groups_by_type('super')
        self.assertEqual(6, len(super_groups))
        self.assertEqual('super', super_groups[0]['type'])
        self.assertEqual('super', super_groups[1]['type'])
        self.assertEqual('super', super_groups[2]['type'])
        self.assertEqual('super', super_groups[3]['type'])
        self.assertEqual('super', super_groups[4]['type'])

        super_groups = self.grouping.search_groups_by_description('*super*')
        self.assertEqual(6, len(super_groups))
        self.assertEqual('super', super_groups[0]['type'])
        self.assertEqual('super', super_groups[1]['type'])
        self.assertEqual('super', super_groups[2]['type'])
        self.assertEqual('super', super_groups[3]['type'])
        self.assertEqual('super', super_groups[4]['type'])

        dynamic_groups = self.grouping.get_groups_by_type('dynamic')
        self.assertEqual(1, len(dynamic_groups))
        self.assertEqual('dynamic', dynamic_groups[0]['type'])

        static_groups = self.grouping.get_groups_by_type('statiC')
        self.assertEqual(2, len(static_groups))
        self.assertEqual('static', static_groups[0]['type'])
        self.assertEqual('static', static_groups[1]['type'])

        lazy_groups = self.grouping.get_groups_by_type('lazy')
        self.assertEqual(1, len(lazy_groups))
        self.assertEqual('lazy', lazy_groups[0]['type'])

        groups = self.grouping.search_groups(
            filter_list=[['Group.type', '=', 'super'], 'and',
                         [['Group.name', 'like', '*test2'], 'or',
                          ['Group.name', 'like', '*test3']]],
            result_list=['Group.id', 'Group.name'],
            sort=[('Group.name', 'desc'), ('Group.id', 'asc')],
            return_as='dict')
        self.assertEqual(2, len(groups))
        self.assertEqual('super_test3', groups[0]['Group.name'])
        self.assertEqual('super_test2', groups[1]['Group.name'])

    def test_delete_group(self):
        # Create groups
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']
        group_test2_id = self.grouping.search_groups_by_name('test2')[0]['id']
        group_test3_id = self.grouping.search_groups_by_name('test3')[0]['id']
        group_test5_id = self.grouping.search_groups_by_name('test3')[0]['id']
        group_super_test1_id = self.grouping.search_groups_by_name(
            'super_test1')[0]['id']
        group_super_test2_id = self.grouping.search_groups_by_name(
            'super_test2')[0]['id']
        group_super_test3_id = self.grouping.search_groups_by_name(
            'super_test3')[0]['id']
        group_super_test4_id = self.grouping.search_groups_by_name(
            'super_test4')[0]['id']
        group_super_test5_id = self.grouping.search_groups_by_name(
            'super_test5')[0]['id']
        group_super_test6_id = self.grouping.search_groups_by_name(
            'super_test6')[0]['id']

        # Group for extra condition is an internal group
        internal_groups = self.grouping.get_all_groups(internal=True)
        for group in internal_groups:
            if group['name'] == 'super_test3_extra_condition':
                group_super_test3_extra_cond_id = group['id']

        with self.assertRaises(ValueError) as context:
            self.grouping.delete_group(group_test1_id, 'test_user')
        self.assertTrue("Cannot delete group %d: "
                        "Group is referenced by another group" %
                        group_test1_id, str(context.exception))

        with self.assertRaises(ValueError) as context:
            self.grouping.delete_group(group_test2_id, 'test_user')
        self.assertTrue("Cannot delete group %d: "
                        "Group is referenced by another group" %
                        group_test2_id, str(context.exception))

        with self.assertRaises(ValueError) as context:
            self.grouping.delete_group(group_test3_id, 'test_user')
        self.assertTrue("Cannot delete group %d: "
                        "Group is referenced by another group" %
                        group_test3_id, str(context.exception))

        with self.assertRaises(ValueError) as context:
            self.grouping.delete_group(group_super_test1_id, 'test_user')
        self.assertTrue("Cannot delete group %d: "
                        "Group is referenced by another group" %
                        group_super_test1_id, str(context.exception))

        self.grouping.delete_group(group_super_test2_id, 'test_user')
        group_definition = self.grouping.search_groups_by_name('super_test2')
        self.assertEqual(0, len(group_definition))

        self.grouping.delete_group(group_super_test3_id, 'test_user')
        group_definition = self.grouping.search_groups_by_name('super_test3')
        self.assertEqual(0, len(group_definition))

        self.grouping.delete_group(group_super_test4_id, 'test_user')
        group_definition = self.grouping.search_groups_by_name('super_test4')
        self.assertEqual(0, len(group_definition))

        self.grouping.delete_group(group_super_test5_id, 'test_user')
        group_definition = self.grouping.search_groups_by_name('super_test5')
        self.assertEqual(0, len(group_definition))

        self.grouping.delete_group(group_super_test6_id, 'test_user')
        group_definition = self.grouping.search_groups_by_name('super_test6')
        self.assertEqual(0, len(group_definition))

        with self.assertRaises(ValueError) as context:
            self.grouping.delete_group(group_test1_id, 'test_user')
        self.assertTrue("Cannot delete group %d: "
                        "Group is referenced by another group" %
                        group_test1_id, str(context.exception))

        with self.assertRaises(ValueError) as context:
            self.grouping.delete_group(group_test2_id, 'test_user')
        self.assertTrue("Cannot delete group %d: "
                        "Group is referenced by another group" %
                        group_test2_id, str(context.exception))

        self.grouping.delete_group(group_super_test1_id, 'test_user')
        group_definition = self.grouping.search_groups_by_name('super_test1')
        self.assertEqual(0, len(group_definition))
        group_definition = self.grouping.search_groups_by_name(
            'super_test3_extra_condition')
        self.assertEqual(0, len(group_definition))

        self.grouping.delete_group(group_test1_id, 'test_user')
        group_definition = self.grouping.search_groups_by_name('test1')
        self.assertEqual(0, len(group_definition))

        self.grouping.delete_group(group_test2_id, 'test_user')
        group_definition = self.grouping.search_groups_by_name('test2')
        self.assertEqual(0, len(group_definition))

        self.grouping.delete_group(group_test3_id, 'test_user')
        group_definition = self.grouping.search_groups_by_name('test3')
        self.assertEqual(0, len(group_definition))

    def test_force_delete_group(self):
        # Create groups
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']
        group_test2_id = self.grouping.search_groups_by_name('test2')[0]['id']
        group_test3_id = self.grouping.search_groups_by_name('test3')[0]['id']
        group_super_test1_id = self.grouping.search_groups_by_name(
            'super_test1')[0]['id']
        group_super_test2_id = self.grouping.search_groups_by_name(
            'super_test2')[0]['id']
        group_super_test3_id = self.grouping.search_groups_by_name(
            'super_test3')[0]['id']
        group_super_test4_id = self.grouping.search_groups_by_name(
            'super_test4')[0]['id']
        group_super_test5_id = self.grouping.search_groups_by_name(
            'super_test5')[0]['id']

        self.grouping.delete_group(group_super_test1_id, 'test_user', force=True)
        group_definition = self.grouping.search_groups_by_name('super_test1')
        self.assertEqual(0, len(group_definition))
        self.assertEqual(1, len(self.grouping.get_parents(group_test1_id)))
        self.assertEqual(1, len(self.grouping.get_parents(group_test2_id)))
        self.assertEqual(1, len(self.grouping.get_children(group_super_test2_id)))
        self.assertEqual(group_test3_id, self.grouping.get_children(group_super_test2_id)[0])

        super_test2_def = self.grouping.get_group_by_id(group_super_test2_id)
        query_map1 = json.loads(super_test2_def['query_map'])
        test3_def = self.grouping.get_group_by_id(group_test3_id)
        query_map2 = json.loads(test3_def['query_map'])
        self.assertEqual(build_query(query_map1), build_query(query_map2))

        super_test3_def = self.grouping.get_group_by_id(group_super_test3_id)
        query_map1 = json.loads(super_test3_def['query_map'])
        self.assertEqual(build_query(query_map1), ' '.join([
            "SELECT", "cpe.cpeid",
            "FROM", "CPEManager_CPEs AS `cpe`",
            "LEFT JOIN vss_OPERATOR AS `Operator`",
            "ON cpe.cid2 = Operator.account_name",
            "INNER JOIN vss_ENTERPRISE AS `Enterprise`",
            "ON Operator.account_parent = Enterprise.account_name",
            "WHERE", "(cpe.cpeid = %(cpeid)s",
            "and", "Enterprise.account_name = enterprise1)"
        ]))

        self.grouping.delete_group(group_super_test3_id, 'test_user', force=True)
        group_definition = self.grouping.search_groups_by_name('super_test3')
        self.assertEqual(0, len(group_definition))
        self.assertEqual(1, len(self.grouping.get_parents(group_test1_id)))

        self.grouping.delete_group(group_super_test5_id, 'test_user', force=True)
        group_definition = self.grouping.search_groups_by_name('super_test5')
        self.assertEqual(0, len(group_definition))
        self.assertEqual(0, len(self.grouping.get_parents(group_test1_id)))

        self.grouping.delete_group(group_test1_id, 'test_user')
        group_definition = self.grouping.search_groups_by_name('test1')
        self.assertEqual(0, len(group_definition))

        self.grouping.delete_group(group_test2_id, 'test_user', force=True)
        group_definition = self.grouping.search_groups_by_name('test2')
        self.assertEqual(0, len(group_definition))

        with self.assertRaises(ValueError) as context:
            self.grouping.delete_group(group_test3_id, 'test_user')
        self.assertTrue("Cannot delete group %d: "
                        "Group is referenced by another group" %
                        group_test3_id, str(context.exception))

        self.grouping.delete_group(group_test3_id, 'test_user', force=True)
        with self.assertRaises(ValueError) as context:
            self.grouping.get_group_by_id(group_super_test2_id)
        self.assertTrue("Group %s does not exist" % group_super_test2_id,
                        str(context.exception))

    def test_update_group(self):
        # Create groups
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']
        group_test2_id = self.grouping.search_groups_by_name('test2')[0]['id']
        group_super_test2_id = self.grouping.search_groups_by_name(
            'super_test2')[0]['id']
        group_super_test1_id = self.grouping.search_groups_by_name('super_test1')[0]['id']
        group_super_test3_id = self.grouping.search_groups_by_name('super_test3')[0]['id']

        with self.assertRaises(ValueError) as context:
            self.grouping.update_group(
                group_test1_id, 'test_user', 'test1', 'test group', 'dynamic',
                ['cpe.cpeid', '=', 'ZZ0000000001'], ['cpe.cpetype'])
        self.assertTrue("Cannot update group %d: "
                        "Group is referenced by another group" %
                        group_test1_id, str(context.exception))

        self.grouping.update_group(group_test1_id,
                                   'test_user',
                                   filter_list=['cpe.cpeid', '=', 'ZZ0000000001'],
                                   result_list=['cpe.cpeid'],
                                   force=True)
        group_definition = self.grouping.get_group_by_id(group_super_test1_id)
        self.assertEqual(group_definition['domain'], None)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = ZZ0000000001",
                "UNION",
                "SELECT", "GroupStaticRelation.member_id",
                "FROM", "AXGroupStaticRelation AS `GroupStaticRelation`",
                "WHERE",
                "GroupStaticRelation.group_id = %s" % group_test2_id
            ]))

        group_definition = self.grouping.get_group_by_id(group_super_test2_id)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = ZZ0000000001",
                "UNION",
                "SELECT", "GroupStaticRelation.member_id",
                "FROM", "AXGroupStaticRelation AS `GroupStaticRelation`",
                "WHERE",
                "GroupStaticRelation.group_id = %s" % group_test2_id,
                "UNION",
                "SELECT", "cpe.cpeid",
                "FROM", "CPEManager_CPEs AS `cpe`", "WHERE",
                "cpe.cpeid = %(cpeid)s"
            ]))

        group_definition = self.grouping.get_group_by_id(group_super_test3_id)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "LEFT JOIN vss_OPERATOR AS `Operator`",
                "ON cpe.cid2 = Operator.account_name",
                "INNER JOIN vss_ENTERPRISE AS `Enterprise`",
                "ON Operator.account_parent = Enterprise.account_name",
                "WHERE", "(cpe.cpeid = ZZ0000000001",
                "and", "Enterprise.account_name = enterprise1)",
                "UNION",
                "SELECT", "AXGroupStaticRelation.member_id",
                "FROM", "CPEManager_CPEs AS `cpe`",
                "LEFT JOIN vss_OPERATOR AS `Operator`",
                "ON cpe.cid2 = Operator.account_name",
                "INNER JOIN vss_ENTERPRISE AS `Enterprise`",
                "ON Operator.account_parent = Enterprise.account_name",
                "RIGHT JOIN AXGroupStaticRelation",
                "ON cpe.cpeid = AXGroupStaticRelation.member_id",
                "WHERE",
                "Enterprise.account_name = enterprise1",
                "AND",
                "AXGroupStaticRelation.group_id = %s" % group_test2_id,
                "UNION",
                "SELECT", "cpe.cpeid",
                "FROM", "CPEManager_CPEs AS `cpe`",
                "LEFT JOIN vss_OPERATOR AS `Operator`",
                "ON cpe.cid2 = Operator.account_name",
                "INNER JOIN vss_ENTERPRISE AS `Enterprise`",
                "ON Operator.account_parent = Enterprise.account_name",
                "WHERE", "(cpe.cpeid = %(cpeid)s",
                "and", "Enterprise.account_name = enterprise1)"
            ]))

        with self.assertRaises(ValueError) as context:
            self.grouping.update_group(
                group_super_test2_id, 'test_user', 'super_test2', 'test_user',
                'dynamic', ['cpe.cpeid'], ['cpe.cpeid', '=', 'ZZ0000000002'])
        self.assertTrue("Cannot update group %d: "
                        "Update operation is not supported on super groups" %
                        group_super_test2_id, str(context.exception))

    def test_update_super_group(self):
        # Create groups
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']
        group_test2_id = self.grouping.search_groups_by_name('test2')[0]['id']
        group_test3_id = self.grouping.search_groups_by_name('test3')[0]['id']
        group_super_test1_id = self.grouping.search_groups_by_name(
            'super_test1')[0]['id']
        group_super_test2_id = self.grouping.search_groups_by_name(
            'super_test2')[0]['id']
        group_super_test3_id = self.grouping.search_groups_by_name(
            'super_test3')[0]['id']
        group_super_test4_id = self.grouping.search_groups_by_name(
            'super_test4')[0]['id']

        # Update super group
        with self.assertRaises(Exception) as context:
            self.grouping.update_super_group(
                group_super_test1_id,
                'test_user',
                'test_super1',
                'test super 1',
                [group_test1_id, group_test2_id, group_test3_id])
        self.assertEqual("Failed to update super group: Group is referenced "
                         "by another super group", str(context.exception))

        self.grouping.update_super_group(
            group_super_test1_id,
            'test_user',
            'test_super1',
            'test super 1',
            [group_test1_id, group_test2_id, group_test3_id],
            force=True)

        group_definition = self.grouping.get_group_by_id(group_super_test1_id)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = ZZ0000000002",
                "UNION",
                "SELECT", "GroupStaticRelation.member_id",
                "FROM", "AXGroupStaticRelation AS `GroupStaticRelation`",
                "WHERE",
                "GroupStaticRelation.group_id = %s" % group_test2_id,
                "UNION",
                "SELECT", "cpe.cpeid",
                "FROM", "CPEManager_CPEs AS `cpe`", "WHERE",
                "cpe.cpeid = %(cpeid)s"
            ]))
        children = self.grouping.get_children(group_super_test1_id)
        self.assertEqual(3, len(children))
        self.assertEqual(
            [group_test1_id, group_test2_id, group_test3_id], sorted(children))

        # Update super group with condition based on an updated super group(new child)
        self.grouping.update_super_group(
            group_super_test4_id,
            'test_user',
            internal=1,
            sub_groups=[group_super_test1_id, group_test3_id],
            cond=['Enterprise.account_name', '=', 'enterprise1'])

        group_definition = self.grouping.get_group_by_id(group_super_test4_id)
        self.assertEqual(group_definition['name'], 'super_test4')
        self.assertEqual(group_definition['type'], 'super')
        self.assertEqual(group_definition['internal'], 1)
        self.assertEqual(group_definition['domain'], None)
        self.assertEqual(group_definition['filter'], None)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            query_map['_axgroup_metadata']['super_cond'],
            ['Enterprise.account_name', '=', 'enterprise1'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "LEFT JOIN vss_OPERATOR AS `Operator`",
                "ON cpe.cid2 = Operator.account_name",
                "INNER JOIN vss_ENTERPRISE AS `Enterprise`",
                "ON Operator.account_parent = Enterprise.account_name",
                "WHERE", "(cpe.cpeid = ZZ0000000002",
                "and", "Enterprise.account_name = enterprise1)",
                "UNION",
                "SELECT", "AXGroupStaticRelation.member_id",
                "FROM", "CPEManager_CPEs AS `cpe`",
                "LEFT JOIN vss_OPERATOR AS `Operator`",
                "ON cpe.cid2 = Operator.account_name",
                "INNER JOIN vss_ENTERPRISE AS `Enterprise`",
                "ON Operator.account_parent = Enterprise.account_name",
                "RIGHT JOIN AXGroupStaticRelation",
                "ON cpe.cpeid = AXGroupStaticRelation.member_id",
                "WHERE",
                "Enterprise.account_name = enterprise1",
                "AND",
                "AXGroupStaticRelation.group_id = %s" % group_test2_id,
                "UNION",
                "SELECT", "cpe.cpeid",
                "FROM", "CPEManager_CPEs AS `cpe`",
                "LEFT JOIN vss_OPERATOR AS `Operator`",
                "ON cpe.cid2 = Operator.account_name",
                "INNER JOIN vss_ENTERPRISE AS `Enterprise`",
                "ON Operator.account_parent = Enterprise.account_name",
                "WHERE", "(cpe.cpeid = %(cpeid)s",
                "and", "Enterprise.account_name = enterprise1)"
            ]))
        children = self.grouping.get_children(group_super_test4_id)
        self.assertEqual(2, len(children))
        self.assertEqual(
            [group_super_test1_id, group_test3_id], sorted(children))

        self.grouping.update_super_group(
            group_super_test1_id,
            'test_user',
            'test_super1',
            'test super 1',
            [group_test1_id, group_test3_id],
            force=True)

        group_definition = self.grouping.get_group_by_id(group_super_test1_id)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = ZZ0000000002",
                "UNION",
                "SELECT", "cpe.cpeid",
                "FROM", "CPEManager_CPEs AS `cpe`", "WHERE",
                "cpe.cpeid = %(cpeid)s"
            ]))
        children = self.grouping.get_children(group_super_test1_id)
        self.assertEqual(2, len(children))
        self.assertEqual(
            [group_test1_id, group_test3_id], sorted(children))

        # Update super group with condition
        self.grouping.update_super_group(
            group_super_test3_id,
            'test_user',
            'test_super3',
            'test super 3',
            [group_test2_id, group_test3_id],
            ['Operator.account_name', '=', 'operator1'])

        group_definition = self.grouping.get_group_by_id(group_super_test3_id)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            query_map['_axgroup_metadata']['super_cond'],
            ['Operator.account_name', '=', 'operator1'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "AXGroupStaticRelation.member_id",
                "FROM", "CPEManager_CPEs AS `cpe`",
                "LEFT JOIN vss_OPERATOR AS `Operator`",
                "ON cpe.cid2 = Operator.account_name",
                "RIGHT JOIN AXGroupStaticRelation",
                "ON cpe.cpeid = AXGroupStaticRelation.member_id",
                "WHERE",
                "Operator.account_name = operator1",
                "AND",
                "AXGroupStaticRelation.group_id = %s" % group_test2_id,
                "UNION",
                "SELECT", "cpe.cpeid",
                "FROM", "CPEManager_CPEs AS `cpe`",
                "LEFT JOIN vss_OPERATOR AS `Operator`",
                "ON cpe.cid2 = Operator.account_name",
                "WHERE", "(cpe.cpeid = %(cpeid)s",
                "and", "Operator.account_name = operator1)"
            ]))
        children = self.grouping.get_children(group_super_test3_id)
        self.assertEqual(2, len(children))
        self.assertEqual(
            [group_test2_id, group_test3_id], sorted(children))

        # Super group with condition to super group
        self.grouping.update_super_group(
            group_super_test3_id,
            'test_user',
            'test_super3',
            'test super 3',
            [group_test2_id, group_test3_id],
            cond=[])

        group_definition = self.grouping.get_group_by_id(group_super_test3_id)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            query_map.get('_axgroup_metadata', {}).get('super_cond', None),
            None)
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "GroupStaticRelation.member_id",
                "FROM AXGroupStaticRelation AS `GroupStaticRelation`",
                "WHERE",
                "GroupStaticRelation.group_id = %s" % group_test2_id,
                "UNION",
                "SELECT", "cpe.cpeid",
                "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = %(cpeid)s"
            ]))
        children = self.grouping.get_children(group_super_test3_id)
        self.assertEqual(2, len(children))
        self.assertEqual(
            [group_test2_id, group_test3_id], sorted(children))

        # Super group to super group with condition(
        # based on super group whose child was removed)
        self.grouping.update_super_group(
            group_super_test3_id,
            'test_user',
            'test_super3',
            'test super 3',
            [group_super_test1_id, group_test3_id],
            cond=['Enterprise.account_name', '=', 'enterprise1'])

        group_definition = self.grouping.get_group_by_id(group_super_test3_id)
        self.assertEqual(group_definition['name'], 'test_super3')
        self.assertEqual(group_definition['type'], 'super')
        self.assertEqual(group_definition['domain'], None)
        self.assertEqual(group_definition['filter'], None)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            query_map['_axgroup_metadata']['super_cond'],
            ['Enterprise.account_name', '=', 'enterprise1'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "LEFT JOIN vss_OPERATOR AS `Operator`",
                "ON cpe.cid2 = Operator.account_name",
                "INNER JOIN vss_ENTERPRISE AS `Enterprise`",
                "ON Operator.account_parent = Enterprise.account_name",
                "WHERE", "(cpe.cpeid = ZZ0000000002",
                "and", "Enterprise.account_name = enterprise1)",
                "UNION",
                "SELECT", "cpe.cpeid",
                "FROM", "CPEManager_CPEs AS `cpe`",
                "LEFT JOIN vss_OPERATOR AS `Operator`",
                "ON cpe.cid2 = Operator.account_name",
                "INNER JOIN vss_ENTERPRISE AS `Enterprise`",
                "ON Operator.account_parent = Enterprise.account_name",
                "WHERE", "(cpe.cpeid = %(cpeid)s",
                "and", "Enterprise.account_name = enterprise1)"
            ]))
        children = self.grouping.get_children(group_super_test3_id)
        self.assertEqual(2, len(children))
        self.assertEqual(
            [group_super_test1_id, group_test3_id], sorted(children))

        with self.assertRaises(Exception) as context:
            self.grouping.update_super_group(
                group_super_test4_id,
                'super_test4',
                'test super group',
                'test_user',
                [group_super_test3_id, group_test3_id],
                cond=['cpe.cpeid', '=', 'x'])
        self.assertEqual("Failed to update super group: "
                        "Cannot build a super group referencing another "
                        "super group with condition(%s)" %
                        group_super_test3_id, str(context.exception))

        with self.assertRaises(Exception) as context:
            self.grouping.update_super_group(
                group_super_test1_id,
                'super_test1',
                'test super group',
                'test_user',
                [group_test1_id, group_test3_id],
                cond=['cpe.cpeid', '=', 'x'],
                force=True)
        self.assertEqual("Failed to update super group: "
                         "Cannot add condition to super group that is "
                         "already referenced by another super group",
                         str(context.exception))

    def test_get_members(self):
        # Create groups
        self.test_create_group()
        group_super_test1_id = self.grouping.search_groups_by_name(
            'super_test1')[0]['id']
        group_super_test2_id = self.grouping.search_groups_by_name(
            'super_test2')[0]['id']
        group_super_test5_id = self.grouping.search_groups_by_name(
            'super_test5')[0]['id']

        result = self.grouping.get_group_members(
            group_super_test1_id,
            return_as='dict')
        result = sorted(result, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000002')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')
        self.assertEqual(
            self.grouping.get_group_member_count(group_super_test1_id), 3)

        with self.assertRaises(ValueError) as context:
            result = self.grouping.get_group_members(
                group_super_test2_id, return_as='dict')
        self.assertTrue("Cannot fetch members of group %d: "
                        "lazy filters cannot be resolved" %
                        group_super_test2_id, str(context.exception))

        result = self.grouping.get_group_members(
            group_super_test2_id,
            lazy_filter={'cpeid': 'ZZ0000000001'},
            return_as='dict')
        result = sorted(result, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(len(result), 4)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000002')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[3]['cpe.cpeid'], 'ZZ0000000004')
        self.assertEqual(
            self.grouping.get_group_member_count(
                group_super_test2_id, lazy_filter={'cpeid': 'ZZ0000000001'}),
            4)

        result = self.grouping.get_group_members(
            group_super_test2_id,
            lazy_filter={'cpeid': 'ZZ0000000002'},
            return_as='dict')
        result = sorted(result, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000002')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')
        self.assertEqual(
            self.grouping.get_group_member_count(
                group_super_test2_id, lazy_filter={'cpeid': 'ZZ0000000002'}),
            3)

        result = self.grouping.get_group_members(
            group_super_test5_id,
            return_as='dict')
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000002')

        # Get members with conditions
        result = self.grouping.get_group_members_with_condition(
            [group_super_test1_id, group_super_test2_id],
            ['Operator.account_name', '=', 'operator1'],
            ['cpe.cpeid', 'User.account_name'],
            lazy_filter={'cpeid': 'ZZ0000000002'})
        self.assertEqual(len(result), 3)
        result = sorted(result, key=lambda k: k[0])
        self.assertEqual(result[0][0], 'ZZ0000000003')
        self.assertEqual(result[0][1], 'user2')
        self.assertEqual(result[1][0], 'ZZ0000000004')
        self.assertEqual(result[1][1], 'user1')
        self.assertEqual(result[2][0], 'ZZ0000000004')
        self.assertEqual(result[2][1], 'user2')

        result = self.grouping.get_group_members_with_condition(
            [group_super_test1_id, group_super_test2_id],
            ['User.account_name', 'like', 'user2*'],
            ['cpe.cpeid', 'User.account_name'],
            lazy_filter={'cpeid': 'ZZ0000000002'})
        self.assertEqual(len(result), 2)
        result = sorted(result, key=lambda k: k[0])
        self.assertEqual(result[0][0], 'ZZ0000000003')
        self.assertEqual(result[0][1], 'user2')
        self.assertEqual(result[1][0], 'ZZ0000000004')
        self.assertEqual(result[1][1], 'user2')

        result = self.grouping.get_group_members_with_condition(
            [group_super_test1_id, group_super_test2_id],
            ['cpe.cpeid', '=', 'ZZ0000000001'],
            lazy_filter={'cpeid': 'ZZ0000000001'})
        count = self.grouping.get_group_members_with_condition_count(
            [group_super_test1_id, group_super_test2_id],
            ['cpe.cpeid', '=', 'ZZ0000000001'],
            lazy_filter={'cpeid': 'ZZ0000000001'})
        self.assertEqual(len(result), 1)
        self.assertEqual(len(result), count)
        self.assertEqual(result[0][0], 'ZZ0000000001')

        result = self.grouping.get_group_members_with_condition(
            [group_super_test5_id],
            ['cpe.cpetype', '=', 'genericTR69'])
        count = self.grouping.get_group_members_with_condition_count(
            [group_super_test5_id],
            ['cpe.cpetype', '=', 'genericTR69'])
        self.assertEqual(len(result), 1)
        self.assertEqual(len(result), count)

    def test_get_extended_members(self):
        # Create groups
        self.test_create_group()
        group_super_test1_id = self.grouping.search_groups_by_name(
            'super_test1')[0]['id']
        group_super_test2_id = self.grouping.search_groups_by_name(
            'super_test2')[0]['id']
        group_super_test5_id = self.grouping.search_groups_by_name(
            'super_test5')[0]['id']

        result = self.grouping.get_group_extended_members(
            group_super_test1_id,
            ['cpe.cpeid', 'cpe.IP'],
            return_as='dict')
        result = sorted(result, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(
            len(result),
            self.grouping.get_group_extended_members_count(
                group_super_test1_id,
                ['cpe.cpeid', 'cpe.IP']))
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000002')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')
        self.assertEqual(
            self.grouping.get_group_member_count(group_super_test1_id), 3)

        result = self.grouping.get_group_extended_members(
            group_super_test1_id,
            ['cpe.cpeid', 'cpe.IP'],
            ['Operator.account_name', '=', 'operator1'],
            return_as='dict')
        result = sorted(result, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(
            len(result),
            self.grouping.get_group_extended_members_count(
                group_super_test1_id,
                ['cpe.cpeid', 'cpe.IP'],
                ['Operator.account_name', '=', 'operator1']))
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000004')

        with self.assertRaises(ValueError) as context:
            result = self.grouping.get_group_extended_members(
                group_super_test2_id, ['cpe.cpeid'], return_as='dict')
        self.assertTrue("Cannot fetch members of group %d: "
                        "lazy filters cannot be resolved" %
                        group_super_test2_id, str(context.exception))

        with self.assertRaises(ValueError) as context:
            result = self.grouping.get_group_extended_members_count(
                group_super_test2_id, ['cpe.cpeid'])
        self.assertTrue("Cannot fetch members count of group %d: "
                        "lazy filters cannot be resolved" %
                        group_super_test2_id, str(context.exception))

        result = self.grouping.get_group_extended_members(
            group_super_test2_id,
            ['cpe.cpeid', 'cpe.IP'],
            lazy_filter={'cpeid': 'ZZ0000000001'},
            return_as='dict')
        result = sorted(result, key=lambda k: k['cpe.IP'])
        self.assertEqual(
            len(result),
            self.grouping.get_group_extended_members_count(
                group_super_test2_id,
                ['cpe.cpeid', 'cpe.IP'],
                lazy_filter={'cpeid': 'ZZ0000000001'}))
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000001')
        self.assertEqual(result[0]['cpe.IP'], '10.0.0.135')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[1]['cpe.IP'], '10.0.0.136')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000002')
        self.assertEqual(result[2]['cpe.IP'], '10.0.0.137')
        self.assertEqual(result[3]['cpe.cpeid'], 'ZZ0000000004')
        self.assertEqual(result[3]['cpe.IP'], '10.0.0.138')

        result = self.grouping.get_group_extended_members(
            group_super_test2_id,
            filter_list=['User.account_name', '=', 'user2'],
            lazy_filter={'cpeid': 'ZZ0000000001'},
            sort=[['cpe.IP', 'asc']],
            return_as='dict')
        self.assertEqual(
            len(result),
            self.grouping.get_group_extended_members_count(
                group_super_test2_id,
                filter_list=['User.account_name', '=', 'user2'],
                lazy_filter={'cpeid': 'ZZ0000000001'}))
        result = sorted(result, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000004')

        result = self.grouping.get_group_extended_members(
            group_super_test2_id,
            ['cpe.IP'],
            lazy_filter={'cpeid': 'ZZ0000000002'},
            return_as='dict')
        self.assertEqual(
            len(result),
            self.grouping.get_group_extended_members_count(
                group_super_test2_id,
                ['cpe.IP'],
                lazy_filter={'cpeid': 'ZZ0000000002'}))
        result = sorted(result, key=lambda k: k['cpe.IP'])
        self.assertEqual(result[0]['cpe.IP'], '10.0.0.136')
        self.assertEqual(result[1]['cpe.IP'], '10.0.0.137')
        self.assertEqual(result[2]['cpe.IP'], '10.0.0.138')

        result = self.grouping.get_group_members(
            group_super_test2_id,
            lazy_filter={'cpeid': 'ZZ0000000002'},
            return_as='dict')
        result2 = self.grouping.get_group_extended_members(
            group_super_test2_id,
            lazy_filter={'cpeid': 'ZZ0000000002'},
            return_as='dict')
        self.assertEqual(result, result2)
        self.assertEqual(
            self.grouping.get_group_member_count(
                group_super_test2_id,
                lazy_filter={'cpeid': 'ZZ0000000002'}),
            self.grouping.get_group_extended_members_count(
                group_super_test2_id,
                lazy_filter={'cpeid': 'ZZ0000000002'}))

        result = self.grouping.get_group_extended_members(
            group_super_test5_id,
            ['cpe.cpeid', 'cpe.cpetype'],
            return_as='dict')
        self.assertEqual(
            len(result),
            self.grouping.get_group_extended_members_count(
                group_super_test5_id,
                ['cpe.cpeid', 'cpe.cpetype']))
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000002')
        self.assertEqual(result[0]['cpe.cpetype'], 'genericTR69')

    def test_get_group_unconsumed_members(self):
        # Create groups
        self.test_create_group()
        group_super_test1_id = self.grouping.search_groups_by_name(
            'super_test1')[0]['id']
        group_super_test5_id = self.grouping.search_groups_by_name(
            'super_test5')[0]['id']
        group_super_test6_id = self.grouping.search_groups_by_name(
            'super_test6')[0]['id']

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_super_test1_id)
        self.assertEqual(unconsumed_count, 3)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_super_test1_id)
        self.assertEqual(consumed_count, 0)

        result = self.grouping.get_group_unconsumed_members(
            group_super_test1_id,
            limit=3, offset=0)
        result = sorted(result, key=lambda k: k[0])
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0][0], 'ZZ0000000002')
        self.assertEqual(result[1][0], 'ZZ0000000003')
        self.assertEqual(result[2][0], 'ZZ0000000004')

        self.grouping.consume_member(group_super_test1_id, 'ZZ0000000002')
        self.grouping.consume_member(group_super_test1_id, 'ZZ0000000003')

        self.assertTrue(
            self.grouping.is_member_consumed(group_super_test1_id,
                                             'ZZ0000000002'))
        self.assertTrue(
            self.grouping.is_member_consumed(group_super_test1_id,
                                             'ZZ0000000003'))
        self.assertFalse(
            self.grouping.is_member_consumed(group_super_test1_id,
                                             'ZZ0000000004'))

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_super_test1_id)
        self.assertEqual(unconsumed_count, 1)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_super_test1_id)
        self.assertEqual(consumed_count, 2)

        self.grouping.consume_member(group_super_test1_id, 'ZZ0000000004')
        self.assertTrue(
            self.grouping.is_member_consumed(group_super_test1_id,
                                             'ZZ0000000004'))

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_super_test1_id)
        self.assertEqual(unconsumed_count, 0)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_super_test1_id)
        self.assertEqual(consumed_count, 3)

        result = self.grouping.get_group_unconsumed_members(
            group_super_test1_id, limit=3, offset=0, return_as='dict')
        self.assertEqual(len(result), 0)

        self.grouping.unconsume_all_members(group_super_test1_id)

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_super_test1_id)
        self.assertEqual(unconsumed_count, 3)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_super_test1_id)
        self.assertEqual(consumed_count, 0)

        result = self.grouping.get_group_unconsumed_members(
            group_super_test1_id,
            limit=3, offset=0, return_as='dict')
        result = sorted(result, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000002')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[2]['cpe.cpeid'], 'ZZ0000000004')

        self.grouping.consume_members(
            group_super_test1_id,
            ['ZZ0000000002', 'ZZ0000000003', 'ZZ0000000004'])
        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_super_test1_id)
        self.assertEqual(unconsumed_count, 0)
        consumed_count = self.grouping.get_group_consumed_member_count(
            group_super_test1_id)
        self.assertEqual(consumed_count, 3)

        result = self.grouping.get_group_unconsumed_members(group_super_test6_id)
        self.assertEqual(3, len(result))
        self.assertEqual(
            ['ZZ0000000002', 'ZZ0000000003', 'ZZ0000000004'],
            sorted([cpe[0] for cpe in result]))
        self.grouping.consume_members(
            group_super_test6_id, ['ZZ0000000002', 'ZZ0000000003', 'ZZ0000000004'])
        result = self.grouping.get_group_unconsumed_members(group_super_test6_id)
        self.assertEqual(0, len(result))

        dyn_group1_id = self.grouping.create_group(
            'dyn_test1', 'test group', 'test_user', 'dynamic', ['cpe.version', 'cpe.cpeid'],
            ['cpe.cpeid', '=', 'ZZ0000000002'])
        dyn_group2_id = self.grouping.create_group(
            'dyn_test2', 'test group', 'test_user', 'dynamic', ['cpe.version', 'cpe.cpeid'],
            ['cpe.cpeid', '=', 'ZZ0000000003'])
        super_group_id = self.grouping.create_super_group(
            'super_group', 'test super group', 'test_user',
            [dyn_group1_id, dyn_group2_id])
        result = self.grouping.get_group_unconsumed_members(super_group_id, return_as='dict')
        self.assertEqual(2, len(result))
        result = sorted(result, key=lambda k: k['cpe.cpeid'])
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000002')
        self.assertEqual(result[0]['cpe.version'], 'version2__HardwareVersion2__2.022')
        self.assertEqual(result[1]['cpe.cpeid'], 'ZZ0000000003')
        self.assertEqual(result[1]['cpe.version'], 'version1__HardwareVersion1__1.011')

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_super_test5_id)
        self.assertEqual(unconsumed_count, 1)
        result = self.grouping.get_group_unconsumed_members(group_super_test5_id, return_as='dict')
        self.assertEqual(result[0]['cpe.cpeid'], 'ZZ0000000002')

        self.grouping.consume_member(group_super_test5_id, 'ZZ0000000002')
        self.assertTrue(
            self.grouping.is_member_consumed(group_super_test5_id,
                                             'ZZ0000000002'))

        unconsumed_count = self.grouping.get_group_unconsumed_member_count(
            group_super_test5_id)
        self.assertEqual(unconsumed_count, 0)

        result = self.grouping.get_group_unconsumed_members(group_super_test5_id, return_as='dict')
        self.assertEqual(len(result), 0)

    def test_get_membership(self):
        # Create groups
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']
        group_test2_id = self.grouping.search_groups_by_name('test2')[0]['id']
        group_super_test1_id = self.grouping.search_groups_by_name(
            'super_test1')[0]['id']
        group_super_test3_id = self.grouping.search_groups_by_name(
            'super_test3')[0]['id']
        group_super_test5_id = self.grouping.search_groups_by_name(
            'super_test5')[0]['id']
        group_super_test6_id = self.grouping.search_groups_by_name(
            'super_test6')[0]['id']

        # Group for extra condition is an internal group
        internal_groups = self.grouping.get_all_groups(internal=True)
        for group in internal_groups:
            if group['name'] == 'super_test3_extra_condition':
                group_super_test3_extra_cond_id = group['id']

        membership = self.grouping.get_group_membership('cpe.cpeid',
                                                        'ZZ0000000003')
        # membership method ignores lazy groups and super groups with lazy filters
        self.assertEqual(len(membership), 3)
        self.assertTrue(group_test2_id in membership)
        self.assertTrue(group_super_test1_id in membership)
        self.assertTrue(group_super_test6_id in membership)

        membership = self.grouping.get_group_membership('cpe.cpeid',
                                                        'ZZ0000000002')
        self.assertTrue(group_super_test5_id in membership)

    def test_is_member(self):
        # Create groups
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']
        group_test2_id = self.grouping.search_groups_by_name('test2')[0]['id']
        group_super_test1_id = self.grouping.search_groups_by_name(
            'super_test1')[0]['id']
        group_super_test2_id = self.grouping.search_groups_by_name(
            'super_test2')[0]['id']
        group_super_test5_id = self.grouping.search_groups_by_name(
            'super_test5')[0]['id']

        result = self.grouping.is_member('cpe.cpetype', 'genericTR69',
                                         group_super_test1_id)
        self.assertFalse(result)

        result = self.grouping.is_member('cpe.cpeid', 'XYZ',
                                         group_super_test1_id)
        self.assertFalse(result)

        result = self.grouping.is_member('cpe.cpeid', 'ZZ0000000003',
                                         group_super_test1_id)
        self.assertTrue(result)

        with self.assertRaises(ValueError) as context:
            self.grouping.is_member('cpe.cpeid', 'ZZ0000000004',
                                    group_super_test2_id)
        self.assertTrue("Cannot verify membership for " \
                "cpe.cpeid=ZZ0000000004 against group %d: " \
                "lazy filters cannot be resolved" %
                group_super_test2_id,
                str(context.exception))

        result = self.grouping.is_member(
            'cpe',
            'ZZ0000000004',
            group_super_test2_id,
            lazy_filter={'cpeid': 'ZZ0000000002'})
        self.assertTrue(result)

        result = self.grouping.is_member(
            'cpe.cpeid',
            'ZZ0000000001',
            group_super_test2_id,
            lazy_filter={'cpeid': 'ZZ0000000001'})
        self.assertTrue(result)

        result = self.grouping.is_member(
            'cpe.cpeid',
            'ZZ0000000002',
            group_super_test5_id)
        self.assertTrue(result)

    def test_add_children(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cpeid', '=', 'ZZ0000000002'])
        group_definition = self.grouping.search_groups_by_name('test1')[0]
        self.assertEqual(group_definition['name'], 'test1')
        self.assertEqual(group_definition['type'], 'dynamic')

        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['User.account_name', '=', 'user2'])
        group_definition = self.grouping.search_groups_by_name('test2')[0]
        self.assertEqual(group_definition['name'], 'test2')
        self.assertEqual(group_definition['type'], 'dynamic')

        group_test3_id = self.grouping.create_group(
            'test3', 'test group', 'test_user', 'lazy', ['cpe.cpeid'],
            ['cpe.cpeid', '=', '%(cpeid)s'])
        group_definition = self.grouping.search_groups_by_name('test3')[0]
        self.assertEqual(group_definition['name'], 'test3')
        self.assertEqual(group_definition['type'], 'lazy')

        group_test4_id = self.grouping.create_group(
            'test4', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cpeid', '=', 'blah'])
        group_definition = self.grouping.search_groups_by_name('test4')[0]
        self.assertEqual(group_definition['name'], 'test4')
        self.assertEqual(group_definition['type'], 'dynamic')

        group_test5_id = self.grouping.create_group(
            'test5', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cpeid', '=', 'ping'])
        group_definition = self.grouping.search_groups_by_name('test5')[0]
        self.assertEqual(group_definition['name'], 'test5')
        self.assertEqual(group_definition['type'], 'dynamic')

        group_super_test1_id = self.grouping.create_super_group(
            'super_test1', 'test group', 'test_user',
            [group_test1_id, group_test4_id])
        group_definition = self.grouping.search_groups_by_name('super_test1')[
            0]
        self.assertEqual(group_definition['name'], 'super_test1')
        self.assertEqual(group_definition['type'], 'super')
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = ZZ0000000002", "UNION", "SELECT",
                "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`", "WHERE",
                "cpe.cpeid = blah"
            ]))
        children = self.grouping.get_children(group_super_test1_id)
        self.assertEqual(2, len(children))
        self.assertTrue(group_test1_id in children)
        self.assertTrue(group_test4_id in children)
        parents = self.grouping.get_parents(group_test1_id)
        self.assertEqual(1, len(parents))
        self.assertTrue(group_super_test1_id in parents)

        self.grouping.add_children(group_super_test1_id, 'test_user',
                                   [group_test2_id])
        group_definition = self.grouping.search_groups_by_name('super_test1')[
            0]
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = ZZ0000000002", "UNION", "SELECT",
                "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`", "WHERE",
                "cpe.cpeid = blah", "UNION", "SELECT", "cpe.cpeid", "FROM",
                "CPEManager_CPEs AS `cpe`",
                "LEFT JOIN vss_USER_CPE_RELATION AS `UserCPERelation`",
                "ON cpe.cpeid = UserCPERelation.cpeid",
                "INNER JOIN vss_USER AS `User`",
                "ON UserCPERelation.userid = User.account_name", "WHERE",
                "User.account_name = user2"
            ]))
        children = self.grouping.get_children(group_super_test1_id)
        self.assertEqual(3, len(children))
        self.assertTrue(group_test1_id in children)
        self.assertTrue(group_test4_id in children)
        self.assertTrue(group_test2_id in children)
        parents = self.grouping.get_parents(group_test1_id)
        self.assertEqual(1, len(parents))
        self.assertTrue(group_super_test1_id in parents)
        parents = self.grouping.get_parents(group_test2_id)
        self.assertEqual(1, len(parents))
        self.assertTrue(group_super_test1_id in parents)

        group_super_test2_id = self.grouping.create_super_group(
            'super_test2', 'test group', 'test_user',
            [group_super_test1_id, group_test3_id])
        group_definition = self.grouping.search_groups_by_name('super_test2')[
            0]
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = %(cpeid)s", "UNION", "SELECT",
                "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`", "WHERE",
                "cpe.cpeid = ZZ0000000002", "UNION", "SELECT", "cpe.cpeid",
                "FROM", "CPEManager_CPEs AS `cpe`", "WHERE", "cpe.cpeid = blah",
                "UNION", "SELECT", "cpe.cpeid", "FROM",
                "CPEManager_CPEs AS `cpe`",
                "LEFT JOIN vss_USER_CPE_RELATION AS `UserCPERelation`",
                "ON cpe.cpeid = UserCPERelation.cpeid",
                "INNER JOIN vss_USER AS `User`",
                "ON UserCPERelation.userid = User.account_name", "WHERE",
                "User.account_name = user2"
            ]))
        children = self.grouping.get_children(group_super_test2_id)
        self.assertEqual(2, len(children))
        self.assertTrue(group_super_test1_id in children)
        self.assertTrue(group_test3_id in children)
        parents = self.grouping.get_parents(group_super_test1_id)
        self.assertEqual(1, len(parents))
        self.assertTrue(group_super_test2_id in parents)
        parents = self.grouping.get_parents(group_test3_id)
        self.assertEqual(1, len(parents))
        self.assertTrue(group_super_test2_id in parents)

        self.grouping.add_children(group_super_test1_id, 'test_user',
                                   [group_test5_id], force=True)
        group_definition = self.grouping.search_groups_by_name('super_test1')[
            0]
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = ZZ0000000002", "UNION", "SELECT",
                "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`", "WHERE",
                "cpe.cpeid = blah", "UNION", "SELECT", "cpe.cpeid", "FROM",
                "CPEManager_CPEs AS `cpe`",
                "LEFT JOIN vss_USER_CPE_RELATION AS `UserCPERelation`",
                "ON cpe.cpeid = UserCPERelation.cpeid",
                "INNER JOIN vss_USER AS `User`",
                "ON UserCPERelation.userid = User.account_name", "WHERE",
                "User.account_name = user2", "UNION", "SELECT",
                "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`", "WHERE",
                "cpe.cpeid = ping"
            ]))
        children = self.grouping.get_children(group_super_test1_id)
        self.assertEqual(4, len(children))
        group_definition = self.grouping.search_groups_by_name('super_test2')[
            0]
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = %(cpeid)s", "UNION", "SELECT",
                "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`", "WHERE",
                "cpe.cpeid = ZZ0000000002", "UNION", "SELECT", "cpe.cpeid",
                "FROM", "CPEManager_CPEs AS `cpe`", "WHERE", "cpe.cpeid = blah",
                "UNION", "SELECT", "cpe.cpeid", "FROM",
                "CPEManager_CPEs AS `cpe`",
                "LEFT JOIN vss_USER_CPE_RELATION AS `UserCPERelation`",
                "ON cpe.cpeid = UserCPERelation.cpeid",
                "INNER JOIN vss_USER AS `User`",
                "ON UserCPERelation.userid = User.account_name", "WHERE",
                "User.account_name = user2", "UNION", "SELECT",
                "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`", "WHERE",
                "cpe.cpeid = ping"
            ]))

    def test_delete_children(self):
        # Create groups
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']
        group_test2_id = self.grouping.search_groups_by_name('test2')[0]['id']
        group_test3_id = self.grouping.search_groups_by_name('test3')[0]['id']
        group_super_test1_id = self.grouping.search_groups_by_name(
            'super_test1')[0]['id']
        group_super_test2_id = self.grouping.search_groups_by_name(
            'super_test2')[0]['id']

        with self.assertRaises(ValueError) as context:
            self.grouping.delete_children(group_test1_id, 'test_user',
                                          [group_test3_id])
        self.assertTrue("Cannot delete children from group %d: " \
                "Cannot delete children for non-super group %d" %
                (group_test1_id, group_test1_id),
                str(context.exception))

        with self.assertRaises(ValueError) as context:
            self.grouping.delete_children(group_super_test1_id, 'test_user',
                                          [group_test3_id])
        self.assertTrue("Cannot delete children from group %d: " \
                "Group is referenced by another group" % group_super_test1_id,
                str(context.exception))

        self.grouping.delete_children(
            group_super_test1_id, 'test_user', [group_test3_id], force=True)
        group_definition = self.grouping.search_groups_by_name('super_test1')[
            0]
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = ZZ0000000002",
                "UNION",
                "SELECT", "GroupStaticRelation.member_id",
                "FROM", "AXGroupStaticRelation AS `GroupStaticRelation`",
                "WHERE",
                "GroupStaticRelation.group_id = %s" % group_test2_id
            ]))
        children = self.grouping.get_children(group_super_test1_id)
        self.assertEqual(2, len(children))
        self.assertTrue(group_test1_id in children)
        self.assertTrue(group_test2_id in children)
        parents = self.grouping.get_parents(group_test3_id)
        self.assertEqual(3, len(parents))
        self.assertTrue(group_super_test2_id in parents)

        self.grouping.delete_children(group_super_test2_id, 'test_user', [])
        group_definition = self.grouping.search_groups_by_name('super_test2')[
            0]
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = ZZ0000000002",
                "UNION",
                "SELECT", "GroupStaticRelation.member_id",
                "FROM", "AXGroupStaticRelation AS `GroupStaticRelation`",
                "WHERE",
                "GroupStaticRelation.group_id = %s" % group_test2_id,
                "UNION",
                "SELECT", "cpe.cpeid",
                "FROM", "CPEManager_CPEs AS `cpe`", "WHERE",
                "cpe.cpeid = %(cpeid)s"
            ]))
        children = self.grouping.get_children(group_super_test2_id)
        self.assertEqual(2, len(children))
        self.assertTrue(group_test3_id in children)
        self.assertTrue(group_super_test1_id in children)

        self.grouping.delete_children(group_super_test2_id, 'test_user',
                                      [group_super_test1_id])
        group_definition = self.grouping.search_groups_by_name('super_test2')[
            0]
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "cpe.cpeid", "FROM", "CPEManager_CPEs AS `cpe`",
                "WHERE", "cpe.cpeid = %(cpeid)s"
            ]))
        children = self.grouping.get_children(group_super_test2_id)
        self.assertEqual(1, len(children))
        self.assertTrue(group_test3_id in children)
        self.assertFalse(group_super_test1_id in children)

    def test_force_delete_children(self):
        # Create groups
        self.test_create_group()
        group_test1_id = self.grouping.search_groups_by_name('test1')[0]['id']
        group_test2_id = self.grouping.search_groups_by_name('test2')[0]['id']
        group_test3_id = self.grouping.search_groups_by_name('test3')[0]['id']
        group_super_test1_id = self.grouping.search_groups_by_name(
            'super_test1')[0]['id']
        group_super_test2_id = self.grouping.search_groups_by_name(
            'super_test2')[0]['id']

        self.grouping.delete_children(group_super_test1_id, 'test_user',
                                      [group_test1_id],
                                      force=True)
        group_definition = self.grouping.get_group_by_id(group_super_test1_id)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "GroupStaticRelation.member_id",
                "FROM", "AXGroupStaticRelation AS `GroupStaticRelation`",
                "WHERE",
                "GroupStaticRelation.group_id = %s" % group_test2_id
            ]))
        group_definition = self.grouping.get_group_by_id(group_super_test2_id)
        query_map = json.loads(group_definition['query_map'])
        self.assertEqual(
            build_query(query_map), ' '.join([
                "SELECT", "GroupStaticRelation.member_id",
                "FROM", "AXGroupStaticRelation AS `GroupStaticRelation`",
                "WHERE",
                "GroupStaticRelation.group_id = %s" % group_test2_id,
                "UNION", "SELECT", "cpe.cpeid",
                "FROM", "CPEManager_CPEs AS `cpe`", "WHERE",
                "cpe.cpeid = %(cpeid)s"
            ]))

    def test_create_super_group_with_empty_list(self):
        with self.assertRaises(Exception) as context:
            group_super_test1_id = self.grouping.create_super_group(
                'super_test1', 'test group', 'test_user',
                [], cond=["cpe.cid", "=", "WHATEVER"])
        self.assertEqual("Failed to create super group: "
                        "Empty list of sub-groups",
                        str(context.exception))

    def test_create_edit_super_group_remove_all_subgroups(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cid2', '=', 'operator1'])
        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cid2', '=', 'operator2'])
        group_super_test1_id = self.grouping.create_super_group(
                'super_test1', 'test group', 'test_user',
                [group_test1_id, group_test2_id], cond=["cpe.cpetype", "=", "genericTR69"])
        with self.assertRaises(Exception) as context:
            self.grouping.update_super_group(
                group_super_test1_id,
                'test_user',
                'test_super1',
                'test super 1',
                [])
        self.assertEqual("Failed to update super group: "
                        "Cannot remove all sub-groups of a super group",
                        str(context.exception))

    def test_create_edit_super_group_remove_condition_dynamic_groups(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cid2', '=', 'operator1'])
        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cid2', '=', 'operator2'])
        group_super_test1_id = self.grouping.create_super_group(
                'super_test1', 'test group', 'test_user',
                [group_test1_id, group_test2_id], cond=["cpe.IP", "=", "10.0.0.135"])

        members = self.grouping.get_group_unconsumed_members(group_super_test1_id)
        self.assertEqual(members, [['ZZ0000000001']])

        self.grouping.update_super_group(
                group_super_test1_id,
                'test_user',
                'test_super1',
                'test super 1',
                cond=[])
        members = self.grouping.get_group_unconsumed_members(group_super_test1_id)
        self.assertEqual(members, [['ZZ0000000001'], ['ZZ0000000003'], ['ZZ0000000004']])

    def test_create_edit_super_group_add_condition_dynamic_groups(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cid2', '=', 'operator1'])
        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'dynamic', ['cpe.cpeid'],
            ['cpe.cid2', '=', 'operator2'])
        group_super_test1_id = self.grouping.create_super_group(
                'super_test1', 'test group', 'test_user',
                [group_test1_id, group_test2_id])
        members = self.grouping.get_group_unconsumed_members(group_super_test1_id)
        self.assertEqual(members, [['ZZ0000000001'], ['ZZ0000000003'], ['ZZ0000000004']])
        self.grouping.update_super_group(
                group_super_test1_id,
                'test_user',
                'test_super1',
                'test super 1',
                cond=["cpe.IP", "=", "10.0.0.135"])
        members = self.grouping.get_group_unconsumed_members(group_super_test1_id)
        self.assertEqual(members, [['ZZ0000000001']])

    def test_create_edit_super_group_remove_condition_static_groups(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'static', ['cpe.cpeid'],
            ['cpe.cid2', '=', 'operator1'])
        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'static', ['cpe.cpeid'],
            ['cpe.IP', '=', '10.0.0.137'])
        group_super_test1_id = self.grouping.create_super_group(
                'super_test1', 'test group', 'test_user',
                [group_test1_id, group_test2_id], cond=["cpe.IP", "=", "10.0.0.135"])

        members = self.grouping.get_group_unconsumed_members(group_super_test1_id)
        self.assertEqual(members, [['ZZ0000000001']])

        self.grouping.update_super_group(
                group_super_test1_id,
                'test_user',
                'test_super1',
                'test super 1',
                cond=[])
        members = self.grouping.get_group_unconsumed_members(group_super_test1_id)
        self.assertEqual(
            sorted([m[0] for m in members]),
            ['ZZ0000000001', 'ZZ0000000002', 'ZZ0000000003', 'ZZ0000000004'])

    def test_create_edit_super_group_add_condition_dynamic_groups(self):
        group_test1_id = self.grouping.create_group(
            'test1', 'test group', 'test_user', 'static', ['cpe.cpeid'],
            ['cpe.cid2', '=', 'operator1'])
        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'static', ['cpe.cpeid'],
            ['cpe.IP', '=', '10.0.0.137'])
        group_super_test1_id = self.grouping.create_super_group(
                'super_test1', 'test group', 'test_user',
                [group_test1_id, group_test2_id])
        members = self.grouping.get_group_unconsumed_members(group_super_test1_id)
        self.assertEqual(
            sorted([m[0] for m in members]),
            ['ZZ0000000001', 'ZZ0000000002', 'ZZ0000000003', 'ZZ0000000004'])
        self.grouping.update_super_group(
                group_super_test1_id,
                'test_user',
                'test_super1',
                'test super 1',
                cond=["cpe.IP", "=", "10.0.0.135"])
        members = self.grouping.get_group_unconsumed_members(group_super_test1_id)
        self.assertEqual(members, [['ZZ0000000001']])

@unittest2.skipIf(PY3, "Cannot run under python3")
@unittest2.skipIf(not mysql_available, "Cannot run without MySQLdb")
class TestAXGroupingInternal(unittest2.TestCase):
    def setUp(self):
        _create_engine()
        self.grouping = Grouping(GroupTestSchema, engine)
        prepare_data()

    def tearDown(self):
        cleanup_data()

    def test_create_group(self):
        group_test1_id = self.grouping.create_group(
            'test1',
            'test group',
            'test_user',
            'dynamic', ['cpe.cpeid'], ['cpe.cpeid', '=', 'ZZ0000000001'],
            internal=True)
        group_definition = self.grouping.get_group_by_id(group_test1_id)
        self.assertEqual(group_definition['domain'], 'cpe')

        group_test2_id = self.grouping.create_group(
            'test2', 'test group', 'test_user', 'static', ['cpe.cpeid'],
            ['cpe.cpeid', '=', 'ZZ0000000001'])
        group_definition = self.grouping.get_group_by_id(group_test2_id)
        self.assertEqual(group_definition['domain'], 'cpe')

        groups = self.grouping.get_all_groups()
        self.assertEqual(1, len(groups))
        self.assertEqual('test2', groups[0]['name'])

        return {'test1': group_test1_id, 'test2': group_test2_id}

    def test_get_members(self):
        # Create groups
        groups = self.test_create_group()
        group_test1_id = groups['test1']

        members = self.grouping.get_group_members(
            group_test1_id, return_as='dict')
        self.assertEqual(1, len(members))
        self.assertEqual('ZZ0000000001', members[0]['cpe.cpeid'])
        self.assertEqual(1,
                         self.grouping.get_group_member_count(group_test1_id))

    def test_get_group_membership(self):
        # Create groups
        groups = self.test_create_group()
        group_test2_id = groups['test2']

        membership = self.grouping.get_group_membership('cpe.cpeid',
                                                        'ZZ0000000001')
        self.assertEqual(1, len(membership))
        self.assertEqual(group_test2_id, membership[0])

    def test_is_member(self):
        # Create groups
        groups = self.test_create_group()
        group_test1_id = groups['test1']

        self.grouping.is_member('cpe.cpeid', 'ZZ0000000001', group_test1_id)

    def test_get_parents(self):
        # Create groups
        self.test_create_group()
        test1_id = self.grouping.search_groups(
            ['Group.internal', '=', 1], return_as='dict')[0]['Group.id']
        test2_id = self.grouping.search_groups_by_name('test2')[0]['id']

        # Create super group
        super_test1_id = self.grouping.create_super_group(
            'super_test1', 'internal super group', 'test_user', [test1_id, test2_id], internal=True)
        super_test2_id = self.grouping.create_super_group(
            'super_test2', 'non-internal super group', 'test_user', [test1_id, test2_id])

        self.assertEqual(self.grouping.get_parents(test1_id), [super_test2_id])
        self.assertEqual(self.grouping.get_parents(test2_id), [super_test2_id])
        self.assertEqual(
            self.grouping.get_parents(test1_id, internal=True),
            [super_test1_id, super_test2_id])
        self.assertEqual(
            self.grouping.get_parents(test2_id, internal=True),
            [super_test1_id, super_test2_id])



