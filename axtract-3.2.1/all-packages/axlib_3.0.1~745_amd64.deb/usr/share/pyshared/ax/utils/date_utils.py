import time
import datetime
import calendar
import pytz
from pytz.reference import Local as local_tz

MIO = float(10 ** 6)

_default_format = "%Y-%m-%d %H:%M:%S"


def timedelta_to_seconds(td):
    return td.microseconds / MIO + td.seconds + td.days * 86400


def posix_to_local_string(posix_ts, format_=_default_format):
    """Converts a posix timestamp into a string of localtime

    A posix timestamp is the seconds since epoch in UTC.
    This functions converts that timestamp into localtime and
    transforms it into a beauty string for humans
    """

    # Converts a posix TS into localtime tuple
    time_tuple = time.localtime(posix_ts)
    # Formats the localtime tuple into string for humans
    return time.strftime(format_, time_tuple)


def posix_to_naive_datetime(posix_ts):
    """Converts a posix timestamp into a datetime object.

    The datetime object has no timezone attached => it is naive => UTC.
    """
    return datetime.datetime.utcfromtimestamp(posix_ts)


def posix_to_local_datetime(posix_ts):
    """Converts a posix timestamp into a datetime object.

    The datetime object has the timezone of the server attached.
    """
    naive_datetime = posix_to_naive_datetime(posix_ts)
    return naive_datetime_to_local_datetime(naive_datetime)


def ms_posix_to_local_string(posix_ts, format_=_default_format):
    """Same as above. Only posix_ts is in *milliseconds*"""
    return posix_to_local_string(posix_ts / 1000, format_)


def naive_datetime_to_posix(naive_datetime):
    """Converts a naive datetime into posix timestamp

    * naive datetime is a datetime without tzinfo and is in UTC
    * posix timestamp are the seconds since epoch in UTC
    """

    _validate_naive_datetime(naive_datetime)
    return calendar.timegm(naive_datetime.utctimetuple())


def naive_datetime_to_local_datetime(naive_datetime):
    """Converts a naive datetime object to a localized datetime

    A naive datetime is a datetime object *without* tzinfo set. Our convention
    is that this kind of timestamps are UTC. This functions returns a datetime
    object back where tzinfo is set to the Local timezone
    """
    _validate_naive_datetime(naive_datetime)
    return naive_datetime.replace(tzinfo=pytz.utc).astimezone(local_tz)


def naive_datetime_to_local_string(naive_datetime, format_=_default_format):
    """Exaclty like localize_naive_datetime but converts it into a string"""
    return naive_datetime_to_local_datetime(naive_datetime).strftime(format_)


def local_datetime_to_naive_datetime(local_datetime):
    """Converts a datetime with timezone attached (local) into a naive one.

    If there is no timezone is attached assume timezone of the server.
    """

    if local_datetime.tzinfo is None:
        local_datetime = local_datetime.replace(tzinfo=local_tz)

    return local_datetime.astimezone(pytz.utc).replace(tzinfo=None)


def local_datetime_to_posix(local_datetime):
    """Converts a datetime with timezone to a posix timestamp."""
    naive_datetime = local_datetime_to_naive_datetime(local_datetime)
    return naive_datetime_to_posix(naive_datetime)


def local_string_to_naive_datetime(timestring, format_=_default_format):
    """It gets in a string representing a time and returns a naive datetime obj

    The incoming string is interpreted to be in *local time* the return value is
    a naive datetime object. Which is UTC according to the Axiros convention
    """
    dt = datetime.datetime.strptime(timestring, format_)
    return dt.replace(tzinfo=local_tz).astimezone(pytz.UTC)


def local_string_to_posix(timestring, format_=_default_format):
    return time.mktime(time.strptime(timestring, format_))


def local_posix_to_naive_datetime(local_ts):
    local_datetime = datetime.datetime.fromtimestamp(local_ts)
    local_datetime = local_datetime.replace(tzinfo=local_tz)
    utc_datetime = local_datetime.astimezone(pytz.utc)
    # We tread naive datimes as UTC per default
    return utc_datetime.replace(tzinfo=None)


def _validate_naive_datetime(naive_datetime):
    tzname = naive_datetime.tzname()
    if tzname is not None:
        if tzname != 'UTC':
            raise Exception("Got a localized datetime: %s" % tzname)


# The pytz.LocalTimezone has no 'localize' method.
class LocalTimezone(pytz.reference.LocalTimezone):
    def localize(self, dt):
        return dt.replace(tzinfo=self)


class TimeZoneHelper(object):
    """Class to help with timezone handling.

    Important:
        * It receives naive/UTC datetimes only
        * it returns naive/UTC datetime only

    => For example if you call get_start of day in timzone Europe/Berlin
    The start of day (in timezone Europe/Berlin) is returned in the UTC
    equivalent.
    """

    # When replacing the tzinfo object is removed. It could be that due to
    # daylight saving times the zone has been changed.
    # => There is a need to 'localize' it again.
    _day_replace_dict = {
        'tzinfo': None,
        'hour': 0,
        'minute': 0,
        'second': 0,
        'microsecond': 0}

    _month_replace_dict = dict(day=1, **_day_replace_dict)
    _year_replace_dict = dict(month=1, **_month_replace_dict)

    _local_tz = LocalTimezone()

    def __init__(self, timezone_name):
        if timezone_name == 'local':
            self.zone = self._local_tz
        else:
            self.zone = pytz.timezone(timezone_name)

    def start_of_day(self, naive_datetime):
        # Convert to target zone.
        local_dt = self._convert_to_local(naive_datetime)

        # Get the start of day in local datetime
        start_of_day = local_dt.replace(**self._day_replace_dict)
        local_start_of_day = self.zone.localize(start_of_day)

        # Convert it back to naive datetime
        return self._convert_to_naive(local_start_of_day)

    def start_of_week(self, naive_datetime):
        local_dt = self._convert_to_local(naive_datetime)

        # Get start of week in local time
        weekstart = local_dt - datetime.timedelta(days=local_dt.weekday())
        weekstart = weekstart.replace(**self._day_replace_dict)
        local_weekstart = self.zone.localize(weekstart)

        return self._convert_to_naive(local_weekstart)

    def start_of_month(self, naive_datetime):
        local_dt = self._convert_to_local(naive_datetime)

        monthstart = local_dt.replace(**self._month_replace_dict)
        local_monthstart = self.zone.localize(monthstart)

        return self._convert_to_naive(local_monthstart)

    def start_of_year(self, naive_datetime):
        local_dt = self._convert_to_local(naive_datetime)
        local_yearstart = local_dt.replace(**self._year_replace_dict)
        local_yearstart = self.zone.localize(local_yearstart)
        return self._convert_to_naive(local_yearstart)

    def naive_datetime_to_local_datetime(self, naive_datetime):
        _validate_naive_datetime(naive_datetime)
        return self._convert_to_local(naive_datetime)

    def _convert_to_local(self, naive_datetime):
        return pytz.utc.localize(naive_datetime).astimezone(self.zone)

    def _convert_to_naive(self, local_datetime):
        return local_datetime.astimezone(pytz.utc).replace(tzinfo=None)


## Read This:
# The following two functions are *VERY* *DANGEROUS*, use them with care.
# Before using them consider a second opinion, preferable me (SH)
# So if you consider to use this function, in nearly all cases
# you do someting wrong elsewhere.
# This is only here because a external graphing library (highcharts)
# cannot handle timezones.

# This function produces timestamps *not* in UTC anymore. It adds/substracts the
# difference between UTC and 'local server time' to the UTC timestamp.
####

## EXAMPLE:
# Assume the the following start:
# Current UTC time: 9:30 12-10-2012
# Current 'local server time': 11:30 12-10-2012
# The *only correct* posix timestamp to express this time is 1350034754

# After going through posix_to_local_ts we have the following result
# posix timestamp: 1350034754 + 3600
# (3600 is the difference between UTC and 'local server time')
# ==>
# Current UTC time: 11:30 12-10-2012
# Current 'local server time': 13:30 12-10-2012

# As you can see, this is totaly wrong to the defintion of posix timestamps and
# how the noramlly processed.
###

def posix_to_local_ts(posix_ts):
    """read comments above. Did you see the 'very dangerous' there ?"""
    return posix_ts + _get_timezone_offset()


def local_ts_to_posix(local_ts):
    """read comments above. Did you see the 'very dangerous' there ?"""
    return local_ts - _get_timezone_offset()

# These methods do the same as the ones above.
# Only the incoming/outgoing timestamps are in *milliseconds*


def ms_posix_to_local_ts(posix_ts):
    """read comments above. Did you see the 'very dangerous' there ?"""
    return posix_ts + (_get_timezone_offset() * 1000)


def ms_local_ts_to_posix(local_ts):
    """read comments above. Did you see the 'very dangerous' there ?"""
    return local_ts - (_get_timezone_offset() * 1000)


def _get_timezone_offset():
    """This calculates the timezone offset of this server"""
    if time.localtime().tm_isdst and time.daylight:
        return -time.altzone
    else:
        return -time.timezone

def get_timezone_location():
    with open("/etc/timezone", "r") as tz_file:
        return tz_file.read().replace('\n', '')
