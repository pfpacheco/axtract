"""
Provide different output formattings for thread_anal.py

New output formats need to be classes that implement a method
format(self, data, *args, **kwargs). Plus, they need to be known by the
formatter_factory.

TODO: Certain objects could be shown in more detail. E.g. for a socket object
    it would be interesting to know socket.getpeername(), socket.getsockname(),
    socket.gettimeout(), socket.fileno() and so on.
"""
import datetime
import pprint
import time
import traceback


def formatter_factory(style="pprint"):
    """Return a formatter according to $style.
    """
    if style == "pprint":
        return PPrintFormatter()
    elif style == "html":
        return HTMLFormatter()
    else:
        raise NotImplemented("Style '%s' does not exist" % style)


class PPrintFormatter(object):
    def __init__(self, show_globals=True, show_locals=True):
        self.show_globals = show_globals
        self.show_locals = show_locals

        self.template = '''
================================================================================

Thread ID %(thread_id)s

Call stack:
-----------
%(stack)s

Locals:
-------
%(locals)s

Globals:
--------
%(globals)s
'''

    def format(self, data, *args, **kwargs):
        """
            $data must be a dict where the thread IDs are the keys and have
            a subdict as value.
            Each subdict must have following keys:
                globals: a dictionary
                locals: a dictionary
                stack: stacktrace as returned by traceback.extract_stack()
        """
        header = "Backtrace at %s (Unix time %s)\n" % (
                datetime.datetime.now().isoformat(), time.time())
        parts = [header]
        for tid, info in data.iteritems():
            data = {'thread_id': tid,
                    'stack': "".join(traceback.format_list(info['stack']))
                    }
            if self.show_locals:
                data['locals'] = pprint.pformat(info['locals'])
            else:
                data['locals'] = "Local variables not shown"

            if self.show_globals:
                data['globals'] = pprint.pformat(info['globals'])
            else:
                data['globals'] = "Global variables not shown"
            parts.append(self.template % data)

        return "".join(parts)

class HTMLFormatter(object):
    def __init__(self, show_globals=True, show_locals=True):
        self.show_globals = show_globals
        self.show_locals = show_locals

        self.html_intro = """
<html><head><link rel='stylesheet' type='text/css' href='/manage_page_style.css'/>
</head><body>
"""
        self.html_outro = """
</body></html>
"""

        self.template = """
<h2>Thread ID %(thread_id)s</h2>
<h3>Call Stack</h3>
<pre>%(stack)s</pre>


<h3>Locals</h3>
<pre>%(locals)s</pre>

<h3>Globals</h3>
<pre>%(globals)s</pre>

"""
    def format(self, data, *args, **kwargs):
        header = "<h1>Backtrace at %s (Unix time %s)" % (
                datetime.datetime.now().isoformat(), time.time())
        parts = [header]
        for tid, info in data.iteritems():
            data = {'thread_id': tid,
                    'stack': "".join(traceback.format_list(info['stack']))
                    }
            if self.show_locals:
                data['locals'] = pprint.pformat(info['locals'])
            else:
                data['locals'] = "Local variables not shown"

            if self.show_globals:
                data['globals'] = pprint.pformat(info['globals'])
            else:
                data['globals'] = "Global variables not shown"
            parts.append(self.template % data)

        retval = self.html_intro + "".join(parts) + self.html_outro
        return retval
