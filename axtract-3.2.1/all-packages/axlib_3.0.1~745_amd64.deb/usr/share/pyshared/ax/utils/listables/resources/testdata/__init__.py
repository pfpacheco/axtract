


def create_samples(listables, db_name, records=100):
    '''lts are set up, data missing
    '''
    lt = listables


