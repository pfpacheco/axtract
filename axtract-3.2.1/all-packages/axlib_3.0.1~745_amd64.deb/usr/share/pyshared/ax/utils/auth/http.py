# -*- coding: utf-8 -*-
'''
Utilities for http authentication
'''
from ax.utils.func.filters import is_str
from ax.utils.func.cast    import tpl
from ax.utils.condition    import evaluate, parse


def authorize_url(path, adapter, args):
    # 1. do we have a global url authr, so we can check roles?
    #TODO - check for global auther (once per process)

    # 2. do we have allowed_urls
    # in the session or in the token?
    platf = getattr(Adapters, adapter)(args)
    claims = platf.claims()
    if not claims:
        return

    au = claims.get('urls') or platf.global_auth_cond
    if not au:
        return

    if ':' in au:
        au, roles = au.split(':', 1)
        roles = tpl(roles, sep=',')
    else:
        roles = platf.roles

    auth_cond = platf.auth_cond(au)

    verb = platf.verb
    facts = {'verb': verb, 'roles': roles, 'path': path}
    facts['path_str'] = '/'.join(path)

    res = evaluate(auth_cond, facts, claims)

    if res:
        return True
    # normally an exception:
    return platf.unauth()




class Adapters:
    class AXESS:
        _cond_by_loc = {}
        global_auth_cond = None
        class PropsClaimsGetter(dict):
            '''Utility to treat AX props as plain dict, for processing like
            claims in a token'''
            @property
            def ap(self):
                return self.get('additional_props', {})
            @property
            def mp(self):
                return self.get('miscProps', {})
            def __getitem__(self, k, dflt=None):
                return self.__dict__.get(k) or self.ap.get(k) or self.mp.get(k, dflt)

        def __init__(self, args):
            self.args = args
            self.user = u = args['req'].AUTHENTICATED_USER
            self.roles = roles = u.getRoles()
            self.verb = args['req'].method.lower()
            if 'Anonymous' in roles:
                self.unauth()

        def unauth(self, msg='Please authenticate'):
            raise self.args['raise'](msg)

        def token(self):
            return None

        def claims(self):
            ''' return any claims, from props or token'''
            req = self.args['req']
            token = self.token()
            if token:
                return token
            props = self.user.getProps()
            if not props:
                return
            return self.PropsClaimsGetter(props)

        def auth_cond(self, loc=None):
            ac = self._cond_by_loc.get(loc)
            if ac:
                return ac
            # from_claims absent: use a global one
            if loc is None:
                raise Exception('No global auth_cond script')
            parts = loc.split('.')
            c = self.args['container']
            while parts:
                c = getattr(c, parts.pop(0), None)
                if c is None:
                    raise Exception('User has allowed_urls but script is not found', au)
            ac = c() # urls by role, from zodb
            if is_str(ac):
                ac = parse(ac)
            self._cond_by_loc[loc] = ac
            return ac




