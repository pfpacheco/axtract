#!/usr/bin/python -tt
"""Client functionality for UDP Echo Plus, as described in TR-143 Appendix A.

UDP Echo Plus is the good old UDP Echo as defined in

http://www.ietf.org/rfc/rfc862.txt

with some additional interpretation of the payload as defined in the TR, see

http://www.broadband-forum.org/technical/trlist.php

for the latest version.

This module provides 3 classes:
    UDPEchoClient: A client for the RFC862 Echo protocol
    UDPEchoPlusClient: The above client, extended to understand TR-143
    UDPEchoPlusCLI: Command line interface for using UDPEchoPlusClient.
"""
import math
import optparse
import socket
import struct
import sys
import time


class UDPEchoClient(object):
    """A client to send a single echo request and receive the reply

    This class does not know about UDP Echo Plus, only about UDP Echo.
    """
    def __init__(self, host, port=7, timeout=1.0, size=20,
            sock=None, socket_module=socket):

        # host must be an IP address string, e.g. "10.1.2.3".
        self.destination = (host, port)


        if sock is None:
            # Need to set up our own socket.
            self.sock = socket_module.socket(
                    socket_module.AF_INET,
                    socket_module.SOCK_DGRAM)
        else:
            # We got some socket object that is (hopefully) ready for use.
            self.sock = sock

        self.timeout = timeout
        self.size = size

        # When we sent the request / received the reply
        self.start = None
        self.stop = None

        # After receiving a reply, these will contain...
        # ...the reply data from the Echo server
        self.reply = None
        # ...the roundtrip time in seconds
        self.roundtrip_time = None

    def build_request(self):
        """Return the packet data we should send to the Echo server"""
        return "X" * self.size

    def send(self):
        """Send Echo packet, receive reply, call reply parsing"""
        self.start = time.time()

        # Do not catch timeout exceptions here, we don't know what should be
        # done with them.
        self.sock.settimeout(self.timeout)
        self.sock.sendto(self.build_request(), self.destination)

        while True:
            reply, sender = self.sock.recvfrom(4096)
            if sender == self.destination:
                # The expected reply has arrived.
                break
            else:
                # Some rogue UDP packet that is not for us. Reset timeout so
                # we don't block too long in recvfrom().
                new_timeout = max(time.time() - self.start + self.timeout, 0.0)
                self.sock.settimeout(new_timeout)

        self.reply = reply
        self.stop = time.time()

        self.parse_reply()

    def parse_reply(self):
        """Parse self.reply and set self.xxx properties accordingly"""
        self.roundtrip_time = max(self.stop - self.start, 0.0)


class UDPEchoPlusClient(UDPEchoClient):
    """UDP Echo Client that knows the extensions of TR-143 Appendix A"""

    def __init__(self, *args, **kwargs):
        super(UDPEchoPlusClient, self).__init__(*args, **kwargs)

        if self.size < 20:
            raise ValueError("UDP Echo Plus requires a packet size of 20 "
                    "bytes or more")

        # This will become the "TestGenSN" field in our request.
        self.sequence_number = kwargs.get("sequence_number", 0)
        # 32bit integer wraparound, just to be sure.
        self.sequence_number %= 2**32

        # After receiving a reply, the following will contain...

        # ...the time in seconds that the device needed to process our request.
        # More precisely, it will be
        #       TestRespReplyTimeStamp - TestRespRecvTimeStamp
        # but with clever adjustments just in case there was a 32 bit integer
        # wraparound.
        # Be prepared that this could be exactly 0.0.
        self.processing_time = None

        # ...the content of the "TestRespReplyFailureCount" as define by TR-143.
        # A counter of (previous) requests to which no reply was sent by the
        # Echo Plus server, for whatever reason.
        self.failure_count = None

        # ...the content of the "TestRespSN"
        self.reply_serial_number = None

    def build_request(self):
        header = struct.pack("!I", self.sequence_number)
        payload = "X" * (self.size - 4)
        return header + payload

    def parse_reply(self):
        super(UDPEchoPlusClient, self).parse_reply()

        request_sn, reply_sn, recv_ts, reply_ts, failures = \
                struct.unpack("!IIIII", self.reply[:20])

        if request_sn != self.sequence_number:
            raise ValueError("TestGenSN in reply (%d) does not match "
                    "request (%d)." % (request_sn, self.sequence_number))

        if reply_ts < recv_ts:
            # This could happen if there was an integer wraparound while
            # the packet was being processed.
            adjusted_reply_ts = reply_ts + 2**32
            delta = adjusted_reply_ts - recv_ts
        else:
            delta = reply_ts - recv_ts

        # The timestamps in the packet are in micro (not milli!) seconds.
        if delta > 30 * 1000 * 1000:
            # delta is larger than 30 seconds. That is highly suspicious.
            raise ValueError("Received timestamps seem incorrect. "
                    "recv_ts: %d, reply_ts: %d." % (recv_ts, reply_ts))

        self.processing_time = delta / 1000000.0
        self.failure_count = failures
        self.reply_serial_number = reply_sn


class UDPEchoPlusClientCLI(object):
    def __init__(self):
        self.host = None
        self.port = None
        # How many packets to send, how long to wait in between and how long
        # for replies.
        self.count = None
        self.interval = None
        self.timeout = None

        # How big the packets should be
        self.size = None

        # The TestGenSN field of TR-143.
        # Just a counter field for us that is unmodified in the reply -> We can
        # see if the reply was actually for our request.
        self.gen_sn = 0
        # Socket for sending / receiving
        self.sock = None

        self.total_sent = 0
        self.total_timeouts = 0
        self.total_rtt = 0.0
        self.total_server_time = 0.0

        self.best_rtts = []
        self.worst_rtts = []

    def parse_command_line(self):
        parser = optparse.OptionParser()
        parser.add_option("-c", "--count", dest="count", type="int",
                help="How many packets to send", default=1)
        parser.add_option("-i", "--interval", dest="interval", default=1.0,
                help="Time to wait between sending of packets",
                type="float")
        parser.add_option("-s", "--size", dest="size", default=20, type="int",
                help="Size of echo requests in bytes (minimum: 20)")
        # Port 7 is defined in RFC 862.
        parser.add_option("-p", "--port", dest="port", default=7, type="int",
                help="Port to contact")
        parser.add_option("-t", "--timeout", dest="timeout", default=1.0,
                type="float", help="How long to wait for a reply.")

        (options, args) = parser.parse_args()

        if not args:
            print("You did not provide a server to contact.")
            sys.exit(1)
        self.host = args[0]

        port = options.port
        if port < 1 or port > 65535:
            print("The port '%s' you specified is invalid" % port)
            sys.exit(1)
        self.port = port

        if options.count < 1:
            print("The value for -c must be >0")
            sys.exit(1)
        self.count = options.count

        if options.interval <= 0:
            print("The interval must be >0")
            sys.exit(1)
        self.interval = options.interval

        if options.timeout <= 0:
            print("The timeout must be >0")
            sys.exit(1)
        self.timeout = options.timeout

        if options.size < 20:
            print(("You specified size %s, but Echo Plus needs at least "
                    "20 bytes.") % options.size)
            sys.exit(1)
        self.size = options.size

    def send_request(self):
        """Send a single request, wait for reply"""

        client = UDPEchoPlusClient(self.host, port=self.port, size=self.size,
                timeout=self.timeout, sock=self.sock)
        self.total_sent += 1
        try:
            client.send()
        except socket.timeout:
            print("\tTimeout after %.3f seconds" % client.timeout)
            self.total_timeouts += 1
            return

        self.do_statistics(client)

    def do_statistics(self, client):
        print("\tRound trip time:  %.2f msec" % (
                client.roundtrip_time * 1000))
        self.total_rtt += client.roundtrip_time
        print("\tServer processing time:  %.2f msec" % (
                client.processing_time * 1000))
        self.total_server_time += client.processing_time

        if self.count < 32:
            return

        # For larger numbers, do some fancy stats.
        num_to_keep = int(math.log(self.count, 4))

        self.worst_rtts.append(client.roundtrip_time)
        self.worst_rtts.sort()
        self.worst_rtts = self.worst_rtts[-num_to_keep:]

        self.best_rtts.append(client.roundtrip_time)
        self.best_rtts.sort()
        self.best_rtts = self.best_rtts[0:num_to_keep]

    def setup_sock(self):
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        except Exception as exc:
            print("Error while setting up socket:", exc)
            sys.exit(1)

    def run(self):
        self.parse_command_line()
        self.setup_sock()

        try:
            for count in xrange(self.count):
                self.send_request()

                # Do not sleep after the last packet.
                if count != self.count - 1:
                    time.sleep(self.interval)
        except Exception as exc:
            print("Exception in main loop:", exc)
        except KeyboardInterrupt:
            # User pressed CTRL + C
            print("\nTerminating...\n")

        print("\nAverage round trip time: %.3f msec" % (
                self.total_rtt / self.total_sent * 1000))
        print("Average server processing time: %.3f msec" % (
                self.total_server_time / self.total_sent * 1000))
        print("Packets sent: %d  Packets lost: %d" % (
                self.total_sent, self.total_timeouts))

        if self.best_rtts and self.worst_rtts:
            print("Best round trip times in milliseconds:")
            print("\t" + ", ".join([
                "%.3f" % (rtt * 1000) for rtt in self.best_rtts]))
            print("Worst round trip times in milliseconds:")
            print("\t" + ", ".join([
                "%.3f" % (rtt * 1000) for rtt in self.worst_rtts]))

def run():
    client = UDPEchoPlusClientCLI()
    client.run()

if __name__ == "__main__":
    run()

