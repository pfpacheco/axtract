# ------------------------------------------- small data type related utilities
from sys import version_info
PY2 = version_info.major == 2

# any func or meth, static or not - __call__ check should be eq in 2 and 3:
is_func = lambda f: hasattr(f, '__call__')
is_list = lambda l: isinstance(l, list)
is_dict = lambda d: isinstance(d, dict)

if PY2:
    # immutable bytes or text:
    is_str  = lambda s: isinstance(s, basestring)
    is_simple = lambda s: type(s) in (bool, float, int, basestring, type(None))
else:
    is_str = lambda s: isinstance(s, (str, bytes))
    is_simple = lambda s: type(s) in (bool, float, int, str, bytes, type(None))



def is_starting_with(a, b):
    ''' does a start with b'''
    if not is_str(a) or not is_str(b):
        #TODO
        raise NotImplemented
    return a.startswith(b)


def is_ending_with(a, b):
    ''' does a end with b'''
    if not is_str(a) or not is_str(b):
        #TODO
        raise NotImplemented
    return a.endswith(b)
