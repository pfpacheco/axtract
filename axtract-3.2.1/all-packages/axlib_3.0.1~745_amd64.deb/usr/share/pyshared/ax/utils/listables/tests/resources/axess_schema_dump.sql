-- MySQL dump 10.16  Distrib 10.1.16-MariaDB, for osx10.10 (x86_64)
--
-- Host: localhost    Database: live
-- ------------------------------------------------------
-- Server version	10.1.16-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `axticketlogtable`
--

DROP TABLE IF EXISTS `axticketlogtable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `axticketlogtable` (
  `id` int(11) DEFAULT NULL,
  `ts` bigint(20) NOT NULL,
  `logLevel` tinyint(1) NOT NULL DEFAULT '0',
  `log` text,
  KEY `id` (`id`),
  KEY `ts` (`ts`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `axtickets`
--

DROP TABLE IF EXISTS `axtickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `axtickets` (
  `ticketid` int(11) NOT NULL AUTO_INCREMENT,
  `extTicketid` varchar(50) DEFAULT NULL,
  `creation_time` datetime DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `lifetime` int(11) DEFAULT NULL,
  `author` varchar(50) DEFAULT NULL,
  `editor` varchar(50) DEFAULT NULL,
  `tickettype` varchar(150) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `archive` tinyint(1) DEFAULT NULL,
  `step` varchar(50) DEFAULT NULL,
  `task` varchar(50) DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `initargs` longtext,
  `ticketProps` longtext,
  `props` longtext,
  `lastResult` longtext,
  `cid` varchar(50) DEFAULT NULL,
  `cid2` varchar(50) DEFAULT NULL,
  `cpeid` varchar(50) DEFAULT NULL,
  `serviceid` varchar(50) DEFAULT NULL,
  `_internal_status` int(11) DEFAULT NULL,
  `logLevel` int(11) DEFAULT NULL,
  PRIMARY KEY (`ticketid`),
  KEY `ix_AXTickets_serviceid` (`serviceid`),
  KEY `ix_AXTickets_cid2` (`cid2`),
  KEY `ix_AXTickets_extTicketid` (`extTicketid`),
  KEY `ix_AXTickets_cpeid` (`cpeid`),
  KEY `ix_AXTickets_cid` (`cid`),
  KEY `lifetime_search` (`status`,`archive`,`lifetime`),
  KEY `axconfigurator_search` (`status`,`archive`,`task`),
  KEY `clear_ticket_table` (`archive`,`last_updated`,`status`)
) ENGINE=MyISAM AUTO_INCREMENT=354428 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cpemanager_cpes`
--

DROP TABLE IF EXISTS `cpemanager_cpes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cpemanager_cpes` (
  `cid` varchar(100) NOT NULL,
  `cid2` char(100) NOT NULL,
  `cpeid` char(150) NOT NULL,
  `cpetype` varchar(250) NOT NULL,
  `path` varchar(250) NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '0',
  `IP` varchar(45) NOT NULL,
  `parentID` char(150) NOT NULL DEFAULT '',
  `protocolVersion` char(150) NOT NULL DEFAULT '',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `firstMsg` int(11) unsigned NOT NULL DEFAULT '0',
  `lastMsg` int(11) unsigned NOT NULL DEFAULT '0',
  `transID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `pii` int(11) unsigned NOT NULL DEFAULT '0',
  `nextDue` bigint(20) NOT NULL DEFAULT '0',
  `logLevel` tinyint(1) NOT NULL DEFAULT '0',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `unmanagedProps` text NOT NULL,
  `pendingProps` text NOT NULL,
  `props` text NOT NULL,
  `scProps` text NOT NULL,
  `lastCookie` char(150) NOT NULL DEFAULT '',
  `events` text NOT NULL,
  `methods` longtext NOT NULL,
  `comments` text NOT NULL,
  `roles` set('Mitel','Yealink','Panasonic','Aastra','Mediatrix','Cisco','supportedFW','unsupportedFW','needUpgradeFW','upgradingFW','failedFWUpgrade','Enterprise','Group','User','DMS','IVRPin','DDI','CPE','NR','VPN','IVR','UserCpeRelation','Trunk','Number','HuntGroup') DEFAULT NULL,
  PRIMARY KEY (`cpeid`),
  KEY `roles` (`roles`),
  KEY `parentID` (`parentID`),
  KEY `lastCookie` (`lastCookie`),
  KEY `path` (`path`),
  KEY `cid` (`cid`),
  KEY `cid2` (`cid2`),
  KEY `IP` (`IP`),
  KEY `state` (`state`,`nextDue`),
  KEY `pii` (`pii`,`state`,`lastMsg`),
  KEY `firstMsg` (`firstMsg`),
  KEY `lastMsg` (`lastMsg`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-04-28 14:20:00
