# Tools for Functional Programming

Low level (generic) tools which are an offer to be used for higher level
problems.

The tools should be

## Referentially Transparent (Pure)

That is: Producing the same output at same input. Guaranteed.
Which means:
- No mutations of object state(s) here.
- No side effects.

## Side Effect Free

Not change anything on the system, except non permanent cpu and mem.

One practical exception we allow and that is *logging*.
