# Listable

Allows to describe any listable data (e.g. from tables, specifically SQL tables)
via a schema, so that standard operations can be offered w/o code, e.g.
searching for combined data.




# Original Docu from the original project:

## Listz


### Example Schema - Queries


```
prefix is:
http://127.0.0.1:9063/live/API/WS/v1/project:MBC/AX/List/CQRS/Query/

/Enterprise/Location/List/limit/3/offset/2
# with meta
/Enterprise/Location/List/limit/3/offset/2/show/meta
/Enterprise/200160/Location/List/show/kv:,Enterprise.EID,cid
/Enterprise/200160/Location/User/List/show/kv:,Enterprise.EID,cid,Location.cid
/Enterprise/200160/Location/User/List/show/meta,kv:,Enterprise.EID,cid,Location.cid,Location.City/filters/Location.City=Thun

# table short:
/Enterprise/Location/User/List/show/meta,kv:ts,Enterprise.EID,Enterprise.City,cid,Location.cid,Location.City/filters/Enterprise.City=Bern

# path filters adaptable keys / readable filter urls (_ at start:  '_' -> ' '):

/Enterprise/City:Mil*/Location/User/List/show/kv:ts,Enterprise.EID,Enterprise.City,cid,Location.cid,Location.City,User.Lastname/filters/_Enterprise.City_like_"M*"

/Enterprise/City:Mil*/Location/User/List/show/kv:ts,Enterprise.EID,Enterprise.City,cid,Location.cid,Location.City,User.Lastname/filters/_Enterprise.City_like_"M*"_and_User.Lastname_like_"K*"


```

### Developping listz

You want hot reloading - so copy it into /opt/axess/Extensions/listz.py and
import within your schema:

```python
#from ax.utils.listables.adapters.axess.data.listz import List, ListUrlSchema
from listz import List, ListUrlSchema

class Query(ListUrlSchema):
    """
    The default hirarchy we want to understand (and potentially restrict)
    in URLs
    """
    listables = MySchema
    class Enterprise(List):
            (...)
```
