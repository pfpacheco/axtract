local rate = tonumber(ARGV[2])
local bucket_size = tonumber(ARGV[3])
local now_ts = tonumber(ARGV[4])
local tokens = math.min(bucket_size, rate)
local last_ts = now_ts

local function try_take_tokens(keyid, amount)
    amount = tonumber(amount)
    local operation = redis.call("LRANGE", keyid, 0, -1)
    if (operation[1] ~= nil) then
        tokens = tonumber(operation[1])
    end
    if (operation[2] ~= nil) then
        last_ts = tonumber(operation[2])
    end
    local delta = math.max(now_ts - last_ts, 0) / 1000
    last_ts = now_ts

    local num_new = delta * rate

    local tokens = math.min(bucket_size, tokens + num_new)
    local ret = 0
    if (tokens >= amount) then
        tokens = tokens - amount
        ret = 1
    end
    redis.call("LTRIM", keyid, -1, 0)
    redis.call("RPUSH", keyid, tokens, last_ts)
    return ret
end

return try_take_tokens(KEYS[1], ARGV[1])
