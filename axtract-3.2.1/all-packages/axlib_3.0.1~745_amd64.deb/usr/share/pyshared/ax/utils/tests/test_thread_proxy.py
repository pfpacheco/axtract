#!/usr/bin/python -tt

import random
import threading
import time
import unittest

from ax.utils import thread_proxy as tp


class ThreadProxyTests(unittest.TestCase):

    def isProxyReentrent(self, some_dict):
        """Proxied functions must be reentrant. Regression test for AXOS-23.
            Not a test case, must be called by a test case.

            If successful this function modifies $some_dict so that it
            evaluates to True and then terminates normally. If unsuccessful
            (=the lock is not reentrant, it will probably deadlock (e.g.
            if threading.Lock is used) or maybe throw an exception. In the
            first case, the thread stays alive. In the second case the dict
            is not modified.
        """
        class Foo(object):
            def foo(self):
                self.callback()
            def bar(self):
                pass

        f = Foo()
        f_threaded = tp.ThreadSafeProx(f)
        f.callback = f_threaded.bar
        # f_threaded.foo() will call f.callback, which is f_threaded.bar(), thus
        # the lock that protects the functions will be reacquired.
        f_threaded.foo()

        some_dict[1] = 42

    def testReentrancy(self):
        """Check if ThreadSafeProx uses reentrant locks"""
        some_dict = {}

        thread = threading.Thread(target=self.isProxyReentrent, args=[some_dict])
        # A daemon thread will not prevent the test suite from terminating.
        thread.daemon = True
        thread.start()

        # Give the thread some time to modify the dict. If it deadlocks, we
        # have a thread hanging around, but better than us deadlocking.
        time.sleep(1)
        self.assertTrue(thread.is_alive() == False)
        self.assertTrue(some_dict)

    def testDecorator(self):
        """The thread_safe_call() must work as a decorator for methods"""

        class Foo(object):
            def __init__(self):
                self.lock = threading.RLock()
            @tp.thread_safe_call
            def bar(self):
                pass
        foo = Foo()
        foo.bar()

if __name__ == "__main__":
    unittest.main()
