import re
import datetime
import simplejson as json
from itertools import repeat
import sys
if sys.version >= '3':
    from copy import deepcopy
else:
    from ax.utils.simple_deepcopy import deepcopy

from ax.utils.listables import get_listables
from ax.utils.listables import SqlListable
from ax.utils.condition import sanitize_input
from ax.utils.condition import traverse_and_apply
from ax.utils.tools import chunk_iterable
from ax.utils.exceptions import InvalidInputError
from ax.utils.exceptions import InternalError
from six import string_types

GROUP_CREATE_TABLE_SQL = """CREATE TABLE IF NOT EXISTS AXGroup (
        id INT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        name VARCHAR(250) NOT NULL,
        description VARCHAR(250) DEFAULT NULL,
        author VARCHAR(50) DEFAULT NULL,
        editor VARCHAR(50) DEFAULT NULL,
        creation_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        last_updated TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
        type ENUM('static', 'dynamic', 'lazy', 'super') NOT NULL,
        domain VARCHAR(250) DEFAULT NULL,
        internal TINYINT(1) UNSIGNED DEFAULT 0,
        persistent TINYINT(1) UNSIGNED DEFAULT 1,
        query_map MEDIUMTEXT,
        INDEX name(name),
        PRIMARY KEY(id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"""

GROUP_CONSUMED_MEMBERS_CREATE_TABLE_SQL = \
    """CREATE TABLE IF NOT EXISTS AXGroupConsumedMembers (
        group_id INT(20) UNSIGNED NOT NULL,
        member_id VARCHAR(200) NOT NULL,
        state TINYINT(1) UNSIGNED NOT NULL DEFAULT 255,
        INDEX group_id(group_id),
        INDEX member_id(member_id),
        INDEX group_id_and_member_id(group_id, member_id),
        INDEX group_id_and_state(group_id, state),
        PRIMARY KEY(group_id, member_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        PARTITION BY LIST (group_id)
        (PARTITION p0 VALUES IN (0) ENGINE = InnoDB)"""

GROUP_STATIC_RELATION_CREATE_TABLE_SQL = \
    """CREATE TABLE IF NOT EXISTS AXGroupStaticRelation (
        group_id INT(20) UNSIGNED NOT NULL,
        member_id VARCHAR(200) NOT NULL,
        INDEX group_id(group_id),
        INDEX member_id(member_id),
        PRIMARY KEY(group_id, member_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        PARTITION BY LIST (group_id)
        (PARTITION p0 VALUES IN (0) ENGINE = InnoDB)"""

GROUP_SUPER_RELATION_CREATE_TABLE_SQL = \
    """CREATE TABLE IF NOT EXISTS AXGroupSuperRelation (
        group_id INT(20) UNSIGNED NOT NULL,
        parent_group_id INT(20) UNSIGNED NOT NULL,
        INDEX group_id(group_id),
        INDEX parent_group_id(parent_group_id),
        PRIMARY KEY(group_id, parent_group_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"""

GROUP_INSERT_SQL = """INSERT INTO AXGroup(
        name,
        description,
        author,
        creation_time,
        type,
        domain,
        internal,
        persistent,
        query_map) VALUES (
        %s, %s, %s, %s, %s, %s, %s, %s, %s)"""

# Insert members into AXGroupConsumedMembers only if the group exists
GROUP_CONSUMED_MEMBERS_INSERT_SQL = """INSERT INTO AXGroupConsumedMembers
        SELECT * FROM (<format_specifiers>) AS X WHERE EXISTS (
        SELECT id FROM AXGroup WHERE id = %s) ON DUPLICATE KEY UPDATE state=%s"""

GROUP_STATIC_RELATION_INSERT_SQL = """INSERT INTO AXGroupStaticRelation (
        group_id, member_id) VALUES <format_specifiers>"""

GROUP_STATIC_RELATION_CHUNK_SIZE = 1000

GROUP_SUPER_RELATION_INSERT_SQL = """INSERT INTO AXGroupSuperRelation (
        group_id,
        parent_group_id) VALUES (
        %s, %s)"""

GROUP_DELETE_SQL = """DELETE FROM AXGroup
        WHERE id=%s"""

GROUP_CONSUMED_MEMBERS_DELETE_SQL = """DELETE FROM AXGroupConsumedMembers
        WHERE group_id=%s"""

GROUP_CONSUMED_MEMBER_DELETE_BY_ID_SQL = """DELETE FROM AXGroupConsumedMembers
        WHERE group_id=%s AND member_id=%s"""

GROUP_CONSUMED_MEMBERS_DELETE_BY_STATES_SQL = """DELETE FROM AXGroupConsumedMembers
        WHERE group_id=%s AND state IN """

GROUP_CONSUMED_MEMBERS_DELETE_ALL_FINAL_STATES_SQL = """DELETE FROM
        AXGroupConsumedMembers
        WHERE group_id=%s AND state=255"""

GROUP_STATIC_RELATION_DELETE_SQL = """DELETE FROM AXGroupStaticRelation
        WHERE group_id=%s"""

GROUP_SUPER_RELATIONS_DELETE_SQL = """DELETE FROM AXGroupSuperRelation
        WHERE (group_id=%s OR parent_group_id=%s)"""

GROUP_TEMP_COND_DELETE_SQL = """DELETE g FROM AXGroup g
        INNER JOIN AXGroupSuperRelation r
        ON g.id = r.group_id
        WHERE g.persistent = 0
        AND r.parent_group_id = %s"""

GROUP_SUPER_SUB_RELATION_DELETE_SQL = """DELETE FROM AXGroupSuperRelation
        WHERE group_id=%s AND parent_group_id=%s"""

GROUP_QUERY_MAP_UPDATE_SQL = """UPDATE AXGroup SET
        query_map=%s,
        last_updated=%s,
        editor=%s
        WHERE id=%s"""

GROUP_UPDATE_SQL = """UPDATE AXGroup SET
        name=%s,
        description=%s,
        editor=%s,
        type=%s,
        domain=%s,
        query_map=%s,
        last_updated=%s,
        internal=%s
        WHERE id=%s"""

GROUP_SELECT_BY_ID_SQL = """SELECT
        name,
        description,
        author,
        editor,
        creation_time,
        last_updated,
        type,
        domain,
        query_map,
        internal
        FROM AXGroup
        WHERE id=%s"""

GROUP_SELECT_BY_ATTR_SQL = """SELECT
        id,
        name,
        description,
        author,
        editor,
        creation_time,
        last_updated,
        type,
        domain,
        query_map
        FROM AXGroup
        WHERE internal=0
        AND %s %s %s"""

GROUP_SELECT_ALL_SQL = """SELECT
        id,
        name,
        description,
        author,
        editor,
        creation_time,
        last_updated,
        type,
        domain,
        query_map
        FROM AXGroup
        WHERE internal=%s
        LIMIT %s OFFSET %s"""

GROUP_PARENTS_SELECT_SQL = """SELECT
        parent_group_id
        FROM AXGroupSuperRelation
        WHERE group_id=%s"""

GROUP_NON_INTERNAL_PARENTS_SELECT_SQL = """SELECT
        sr.parent_group_id
        FROM AXGroupSuperRelation AS sr INNER JOIN AXGroup as g
        ON sr.parent_group_id = g.id
        WHERE sr.group_id=%s AND g.internal=0"""

GROUP_CHILDREN_SELECT_SQL = """SELECT
        group_id
        FROM AXGroupSuperRelation
        WHERE parent_group_id=%s"""

# Queries combined to check if group exists and members consumed in one go
GROUP_CONSUMED_MEMBERS_SELECT_SQL = """SELECT
        id, 'GroupExists' FROM AXGroup WHERE id = %s
        UNION
        SELECT
        group_id,
        member_id
        FROM AXGroupConsumedMembers
        WHERE group_id=%s AND member_id=%s"""

GROUP_CONSUMED_MEMBERS_SELECT_BY_STATE_SQL = """SELECT
        id, 'GroupExists' FROM AXGroup WHERE id = %s
        UNION
        SELECT
        group_id,
        member_id
        FROM AXGroupConsumedMembers
        WHERE group_id=%s AND member_id=%s AND state=%s"""

# Queries combined to check if group exists and consumed members count in one go
GROUP_CONSUMED_MEMBERS_SELECT_COUNT_SQL = """SELECT
        'GroupExists' FROM AXGroup WHERE id = %s
        UNION
        SELECT
        count(*)
        FROM AXGroupConsumedMembers
        WHERE group_id=%s"""

PARTITION_SQL = """ALTER TABLE %s PARTITION BY LIST(%s)
        (PARTITION p0 VALUES IN (0))"""

PARTITION_ADD_SQL = """ALTER TABLE %s ADD PARTITION
        (PARTITION p%s VALUES IN(%s))"""

PARTITION_DROP_SQL = """ALTER TABLE %s DROP PARTITION p%s"""


class GroupSchema(object):
    class Group(SqlListable):
        table = 'AXGroup'
        primary_id = 'id'
        master_params = ['name', 'description', 'type']
        parent_types = []

    class GroupStaticRelation(SqlListable):
        table = 'AXGroupStaticRelation'
        primary_id = 'group_id'
        master_params = ['group_id', 'member_id']
        parent_types = []


class Grouping(object):
    def __init__(self, schema, db_engine, ns='live'):
        self.db_handle = db_engine

        # Create group table if it doesn't exists
        self.db_handle.execute(GROUP_CREATE_TABLE_SQL)

        # Create group consumed members table if it doesn't exist
        self.db_handle.execute(GROUP_CONSUMED_MEMBERS_CREATE_TABLE_SQL)

        # Create group static relation table if it doesn't exist
        self.db_handle.execute(GROUP_STATIC_RELATION_CREATE_TABLE_SQL)

        # Create group super relation table if it doesn't exist
        self.db_handle.execute(GROUP_SUPER_RELATION_CREATE_TABLE_SQL)

        # Creates/gets an instance of listables for the extended Group schema
        ExtendedGroupSchema = type(
            "%sExtendedGroupSchema" % ns.capitalize(), (GroupSchema, schema, ), {})
        self.listables = get_listables(ExtendedGroupSchema, db_engine)

        # Query map for static group
        self.static_query_map = self.listables.create_query_map()
        lt = self.listables['GroupStaticRelation']
        lt.set_filters(self.static_query_map, ['GroupStaticRelation.group_id', '=', 0])
        lt.set_resultset(self.static_query_map, ['GroupStaticRelation.member_id'])

    def _filter_complies_with_type(self, filter_list, type_):
        placeholder_found = False
        format_specifiers = [
            '%s', '"%s"', '\%\([a-zA-Z0-9_]+\)s', '\"\%\([a-zA-Z0-9_]+\)s\"'
        ]

        def traverse(object_, container_types=(list, tuple)):
            if isinstance(object_, container_types):
                for value in object_:
                    for sub_value in traverse(value, container_types):
                        yield sub_value
            else:
                yield object_

        flat_list = [element for element in traverse(filter_list)]
        for element in flat_list:
            if isinstance(element, string_types) and \
                    re.match('|'.join(format_specifiers), element):
                placeholder_found = True
                break

        if type_ == 'lazy':
            return True if placeholder_found else False

        return False if placeholder_found else True

    def _build_query_map_for_static_group(self, query_map, result_list):
        # Take over from static query map
        query_map.update(self.static_query_map)

        # Set show, as it is used to check membership
        query_map['show'] = result_list

        # Set realized_show, as it is used in post processing listables result
        query_map['realized_show'] = result_list

    def _insert_static_relations(
            self, group_id, query_map, result_list, filter_list):
        try:
            # Add partition for the static group
            self.db_handle.execute(PARTITION_ADD_SQL % (
                'AXGroupStaticRelation', str(group_id), str(group_id)))

            offset = 0
            while True:
                # Fetch members
                data = self.listables.select(
                    self.db_handle, result_list, filter_list,
                    limit=GROUP_STATIC_RELATION_CHUNK_SIZE,
                    offset=offset,
                    return_as='list')
                if not data:
                    break

                offset += GROUP_STATIC_RELATION_CHUNK_SIZE
                data = [row[0] for row in data]

                # Set filter_params to group id
                query_map['filter_params'] = [group_id]

                # Add new group definition
                static_relations = []
                for member_id in data:
                    static_relations.extend([group_id, member_id])

                self.db_handle.execute(
                    GROUP_STATIC_RELATION_INSERT_SQL.replace(
                        '<format_specifiers>', ','.join(
                            list(repeat('(%s,%s)', len(static_relations)/2)))),
                    static_relations)
        except Exception as ex:
            raise InternalError(
                "Failed to populate static members for group %s: " % (
                    group_id, str(ex)))

    def _insert_super_relation(self, group_id, parent_group_id):
        self.db_handle.execute(GROUP_SUPER_RELATION_INSERT_SQL,
                               (str(group_id), parent_group_id))

    def _create_group(self,
                      name,
                      description,
                      user,
                      type_,
                      result_list,
                      filter_list=None,
                      internal=False,
                      persistent=True,
                      base_group=None):
        try:
            if not filter_list:
                filter_list = []

            # Load base group(if provided)
            if base_group:

                base = self.get_group_by_id(base_group)
                base_query_map = json.loads(base['query_map'])

                if type_ == 'super' or base['type'] == 'super':
                    raise ValueError('Cannot extend from or to super group')

                if type_ == 'static' or base['type'] == 'static':
                    raise ValueError('Cannot extend from or to static group')

                # Calculate new filters
                new_filter_list = base_query_map['filters']
                new_filter_list.append('and')
                new_filter_list.append(filter_list)
                filter_list = new_filter_list

                # Prepend base result_list
                result_list.extend(base_query_map['show'])

            # Check if resultset exists
            if not result_list:
                raise ValueError("No resultset provided")

            # Check if filter satisfies group type
            if not self._filter_complies_with_type(filter_list, type_):
                raise ValueError("Filter doesn't comply with group type %s" %
                                 type_)

            # Initialize query map
            query_map = self.listables.create_query_map()

            # Pick a root listable to start building the query from
            root = result_list[0].split('.')[0]

            # Domain is the type of attributes in the resultset, the 'root'
            # in this case
            domain = root

            if type_ == 'static':
                if len(result_list) > 1:
                    raise InvalidInputError(
                        "Static group must have only one parameter in the "
                        "result list")
                self._build_query_map_for_static_group(query_map, result_list)
            else:
                lt = self.listables[root]

                # Sort resultset ascii only(useful when it comes to super groups)
                result_list = list(set(result_list))
                result_list.sort(key=lambda x: x.lower())

                # Set group filters(WHERE clause)
                lt.set_filters(query_map, filter_list, None)

                # Set group resultset(SELECT clause)
                lt.set_resultset(query_map, result_list)

            # Add new group definition
            res = self.db_handle.execute(GROUP_INSERT_SQL, (
                name, description, user,
                datetime.datetime.utcnow(), type_,
                domain, int(internal), int(persistent), json.dumps(query_map)))
            id_ = res.lastrowid

            # Add partition for consumed members
            self.db_handle.execute(PARTITION_ADD_SQL % (
                'AXGroupConsumedMembers', str(id_), str(id_)))

            if type_ == 'static':
                # Add relations with auto generated group id
                self._insert_static_relations(
                    id_, query_map, result_list, filter_list)

                # Update query map with group id in filter
                self.db_handle.execute(GROUP_QUERY_MAP_UPDATE_SQL, (
                    json.dumps(query_map), datetime.datetime.utcnow(), user, str(id_)))

            return id_
        except (InvalidInputError, ValueError) as err:
            raise ValueError("Cannot create group %s: %s" % (name, str(err)))

    def _fuse_group_defs(self, groups, operator='UNION', base_query_map=None):
        if not base_query_map:
            base_query_map = {}

        count = 0
        result_list = base_query_map.get('result_list', [])
        filter_params = base_query_map.get('filter_params', [])
        filter_placeholders = base_query_map.get('filter_placeholders', [])
        fused_query = base_query_map.get('full_query', [])

        for i, group in enumerate(groups):
            count += 1
            sub_group_type = group['type']
            sub_group_query_map = json.loads(
                group['query_map']) if isinstance(
                    group['query_map'], string_types) else group['query_map']
            group_result_list = sub_group_query_map['show']
            group_query = sub_group_query_map['full_query']
            group_filter_params = sub_group_query_map['filter_params']
            group_filter_placeholders = sub_group_query_map[
                'filter_placeholders']

            if sub_group_type == "lazy":
                if set(filter_placeholders).intersection(
                        group_filter_placeholders):
                    raise ValueError(
                        "Sub-groups have overlapping placeholders")

                filter_placeholders.extend(group_filter_placeholders)

            if not result_list:
                result_list = group_result_list

            if (not set(result_list).symmetric_difference(
                    set(group_result_list))) is False:
                raise ValueError("Sub-groups have disjoint resultsets")

            # Append group query to super group query
            if fused_query:
                fused_query.append(operator)
            fused_query.extend(group_query)
            filter_params.extend(group_filter_params)

        if count < len(groups):
            raise ValueError('Cannot fetch all sub-groups')

        # Pick a root listable to start building the query from
        root = result_list[0].split('.')[0]
        lt = self.listables[root]

        # Get a query map
        query_map = self.listables.create_query_map()

        # Set group resultset(SELECT clause)
        lt.set_resultset(query_map, result_list)

        query_map['full_query'] = fused_query
        query_map['filter_params'] = filter_params
        query_map['filter_placeholders'] = filter_placeholders

        return query_map


    def _create_or_update_super_group(self,
                                      user,
                                      sub_groups=None,
                                      name=None,
                                      description=None,
                                      group_definition=None,
                                      internal=False,
                                      overwrite=False,
                                      cond=None,
                                      force=False):

        query_map = None
        existing_children = []
        parents = []

        # Check if the group already exists
        id_ = None
        if group_definition:
            id_ = group_definition['id']
            existing_children = self.get_children(id_)
            parents = self.get_parents(id_)

            if group_definition['type'] != 'super':
                raise ValueError("Cannot update group %s of type %s here" %
                                 (id_, group_definition['type']))

            if not name:
                name = group_definition['name']

            if not description:
                description = group_definition['description']

            # Load query map and extend this group(Used by add_children)
            if not overwrite:
                query_map = json.loads(group_definition['query_map'])

            # If no sub_groups provided, just recalculate query from existing
            # children
            if not sub_groups:
                sub_groups = existing_children

        # Check if the group is referenced by others
        if not force and parents:
            raise Exception("Group is referenced by another super group")

        # If the group has no children, remove it
        sub_groups = set(sub_groups if sub_groups else [])
        if not sub_groups:
            self.delete_group(id_, user)
            return None

        # Fetch each sub-group and combine their queries
        if not cond:
            fused_query_map = self._fuse_group_defs(
                [self.get_group_by_id(group_id) for group_id in sub_groups],
                base_query_map=query_map)
        else:
            if id_ and parents:
                raise Exception(
                    "Cannot add condition to super group that is "
                    "already referenced by another super group")
            fused_query_map = self._build_query_map_for_groups_results_cond(
                sub_groups, cond=cond, super_cond_check=True)

        # Add/update group definition(argument internal is ignored in case of updates)
        if group_definition:
            self.db_handle.execute(GROUP_UPDATE_SQL,
                                   (name, description, user, 'super', None,
                                    json.dumps(fused_query_map),
                                    datetime.datetime.utcnow(),
                                    internal, str(id_)))
        else:
            res = self.db_handle.execute(GROUP_INSERT_SQL, (
                name, description, user,
                datetime.datetime.utcnow(), 'super',
                None, internal, True, json.dumps(fused_query_map)))
            id_ = res.lastrowid

        # Link sub-group to super group
        for sub_group_id in sub_groups.difference(existing_children):
            self._insert_super_relation(sub_group_id, id_)

        # Remove links if necessary
        if overwrite:
            for sub_group_id in set(existing_children).difference(sub_groups):
                self._delete_group_super_sub_relation(sub_group_id, id_)

        # Cascade changes upwards to parents
        parents = self.get_parents(id_)
        for group_id in parents:
            # Fetch group definition
            parent_def = self.get_group_by_id(group_id)
            query_map = json.loads(parent_def['query_map'])
            super_cond = query_map.get('_axgroup_metadata', {}).get(
                'super_cond', None)

            self._create_or_update_super_group(
                user,
                group_definition=parent_def,
                overwrite=True,
                cond=super_cond,
                force=force)

        return id_

    def create_group(self,
                     name,
                     description,
                     user,
                     type_,
                     result_list,
                     filter_list=None,
                     internal=False,
                     base_group=None):
        """
        Creates a group based on filters and result parameters
        @param name: Group name
        @param description: Group description
        @param user: Group author
        @param type_: Group type(static, dynamic, lazy)
        @param result_list: Group show parameters
        @param filter_list: Group filters as nested list(with AND/OR connectors)
        @param internal: Is the group for internal use?
        @param base_group: Group to build on top of
        """
        return self._create_group(
            name,
            description,
            user,
            type_,
            deepcopy(result_list),
            deepcopy(filter_list),
            internal=internal,
            persistent=True,
            base_group=base_group)

    def _enhance_static_group_query_map(
            self, group_id, query_map, result_list=None, filter_list=None,
            sort=None):
        results = []

        if result_list:
            results.extend(result_list)

        # Decoy param just to add the original group param table to the join
        static_join_param = query_map['show'][0]
        results.append(static_join_param)

        # Pick a root listable to start building the query from
        root = static_join_param.split('.')[0]
        lt = self.listables[root]

        # Build listable query and join AXGroupStaticRelation manually
        qm = self.listables.create_query_map()
        lt.set_resultset(qm, results)
        lt.set_filters(qm, filter_list)

        extra_join = [
            'RIGHT JOIN AXGroupStaticRelation',
            'ON %s = AXGroupStaticRelation.member_id' % static_join_param]
        extra_where = ['AND AXGroupStaticRelation.group_id = %s' % group_id]

        sql_list = qm['full_query']
        where_index = sql_list.index('WHERE')
        if sort:
            lt.set_query_options(qm, sort=sort)
            sql_list[where_index:where_index] = extra_join
            order_by_index = sql_list.index('ORDER BY')
            sql_list[order_by_index:order_by_index] = extra_where
        else:
            sql_list[where_index:where_index] = extra_join
            sql_list.extend(extra_where)

        select_params = sql_list[
            sql_list.index('SELECT') + 1: sql_list.index('FROM')][0].split(',')

        # Remove decoy param from SELECT clause and query_map['show']
        if result_list:
            del select_params[-1]

        # Replace the original param with member_id to make the
        # RIGHT JOIN work
        select_params = [
            'AXGroupStaticRelation.member_id' if p.strip(
                ) == static_join_param else p for p in select_params]
        sql_list[sql_list.index('SELECT') + 1:sql_list.index('FROM')] = [
            ','.join(select_params)]

        # Update order by clause
        if sort:
            try:
                sort_clause = sql_list[sql_list.index('ORDER BY') + 1:][0]
                sort_clause = sort_clause.replace(
                    static_join_param + ' ', 'AXGroupStaticRelation.member_id ')
                sql_list[sql_list.index('ORDER BY') + 1:] = [sort_clause]
            except ValueError:
                pass

        if result_list:
            del qm['show'][-1]

        query_map = qm

        return query_map

    def _reverse_sanitize(self, type_, cond):
        if cond[1] in ['like', 'not like']:
            # Don't reverse sanitize lazy filter placeholders
            if type_ == 'lazy' and re.match(
                    '\%\([a-zA-Z0-9_]+\)s', cond[2]):
                return

            if cond[2]:
                cond[2] = sanitize_input(cond[2], "reverse_engine")

    def _get_resolved_group_defs(
            self,
            groups,
            results,
            cond,
            super_cond_check=False):
        group_defs = {}

        for group_id in set(groups):

            group_def = self.get_group_by_id(group_id)
            query_map = json.loads(group_def['query_map'])

            # Resolve super group by getting all its sub-group definitions
            if group_def['type'] == 'super':
                super_cond = query_map.get(
                    '_axgroup_metadata', {}).get('super_cond')

                # The check is used from create/update super group
                if super_cond_check and super_cond:
                    raise Exception(
                        'Cannot build a super group referencing another '
                        'super group with condition(%s)' % str(group_id))

                sub_group_defs = self._get_resolved_group_defs(
                    self.get_children(group_id),
                    results,
                    cond=[cond, 'and', super_cond] if super_cond else cond,
                    super_cond_check=super_cond_check)

                group_defs.update(sub_group_defs)
                continue

            root = query_map['show'][0].split('.')[0]
            lt = self.listables[root]

            if group_def['type'] == 'static':
                query_map = self._enhance_static_group_query_map(
                    group_def['id'],
                    query_map,
                    result_list=results,
                    filter_list=cond)
            else:
                # Reverse sanitize group filter before using it to create a new one
                traverse_and_apply(
                    False,
                    query_map['filters'],
                    lambda cond: self._reverse_sanitize(group_def['type'], cond))

                if cond:
                    # Calculate new filters and update the query_map
                    lt.set_filters(query_map, [query_map['filters'], 'and', cond])
                if results:
                    lt.set_resultset(query_map, results)

            # Update group definition
            group_def['query_map'] = json.dumps(query_map)
            group_defs[group_def['id']] = group_def

        return group_defs

    def _build_query_map_for_groups_results_cond(
            self,
            groups,
            results=None,
            cond=None,
            sort=None,
            super_cond_check=False):

        if not groups:
            raise Exception('No sub-groups provided')

        group_defs = self._get_resolved_group_defs(
            groups, results, cond, super_cond_check).values()

        if len(group_defs) == 1 and sort:
            # sort is not supported on unionised super group queries
            if group_defs[0]['type'] == 'static':
                # Applying sort on a static group is as good as redoing it
                group_def = self.get_group_by_id(group_defs[0]['id'])
                query_map = json.loads(group_def['query_map'])
                query_map = self._enhance_static_group_query_map(
                    group_def['id'],
                    query_map,
                    result_list=results,
                    filter_list=cond,
                    sort=sort)
            else:
                query_map = json.loads(group_defs[0]['query_map'])
                root = query_map['show'][0].split('.')[0]
                lt = self.listables[root]
                lt.set_query_options(query_map, sort=sort)

            fused_query_map = query_map
        else:
            fused_query_map = self._fuse_group_defs(group_defs)

        # Flag the group to be 'super with condition'
        if cond:
            fused_query_map['_axgroup_metadata'] = {'super_cond': cond}

        return fused_query_map

    def create_super_group(self,
                           name,
                           description,
                           user,
                           sub_groups,
                           cond=None,
                           internal=False):
        """
        Creates a super group by combining queries from given sub-groups
        and an extra condition
        @param name: Group name
        @param description: Group description
        @param user: Group author
        @param sub_groups: A list of sub-group IDs
        @param cond: Additional condition to be applied to all the sub groups
        @param internal: Is the group for internal use?
        """
        try:
            if not sub_groups:
                raise ValueError(
                    "Empty list of sub-groups")

            id_ = self._create_or_update_super_group(
                user, sub_groups, name, description, internal=internal,
                overwrite=True, cond=deepcopy(cond))

            # Add partition for consumed members
            self.db_handle.execute(PARTITION_ADD_SQL % (
                'AXGroupConsumedMembers', str(id_), str(id_)))

            return id_

        except Exception as ex:
            raise Exception("Failed to create super group: %s" % str(ex))

    def update_super_group(self,
                           id_,
                           user,
                           name=None,
                           description=None,
                           sub_groups=None,
                           cond=None,
                           internal=None,
                           force=False):
        """
        Update an existing super group with a new list of subgroups and a condition
        @param id_: ID of the super group to be updated
        @param user: Group editor
        @param name: New group name
        @param description: New group description
        @sub_groups: A list of new sub-group IDs. If None, the query will be
        recalculated based on existing sub groups.
        @param cond: Additional condition to be applied to all the sub groups.
        If None, existing condition will be used
        @param internal: Is the group for internal use?
        @param force: Update group even if it is referenced by another?
        """
        try:
            group_def = self.get_group_by_id(id_)

            if sub_groups is not None and len(sub_groups) == 0:
                raise Exception("Cannot remove all sub-groups of a super group")

            if internal is None:
                internal = group_def['internal']

            # If no cond provided, load from group definition
            if cond is None:
                query_map = json.loads(group_def['query_map'])
                cond = query_map.get('_axgroup_metadata', {}).get(
                    'super_cond', [])

            self._create_or_update_super_group(
                user, sub_groups, name, description, group_def,
                internal=internal, overwrite=True, cond=deepcopy(cond),
                force=force)

        except Exception as ex:
            raise Exception("Failed to update super group: %s" % str(ex))

    def add_children(self, id_, user, sub_groups, force=False):
        """
        Adds(or links) sub-groups to a super group
        @param id_: Group id of the super group
        @param user: Group editor
        @param sub_groups: A list IDs of the sub-groups to be added
        @param force: Add children even if the super group is referenced by another?
        TODO: Either support super group with cond or remove the api
        """
        try:
            # Check if the group is part referenced by a super group
            if not force and self._has_super_group(id_):
                raise ValueError("Group is referenced by another group")

            # Check if group exists
            group_definition = self.get_group_by_id(id_)
            if group_definition['type'] != 'super':
                raise ValueError("Cannot add children to non-super group %s" %
                                 str(id_))

            self._create_or_update_super_group(
                user,
                sub_groups,
                overwrite=False,
                group_definition=group_definition,
                force=force)

        except (InvalidInputError, ValueError) as err:
            raise ValueError("Cannot add children to group %s: %s" %
                             (str(id_), str(err)))

    def delete_children(self, id_, user, sub_groups, force=False):
        """
        Deletes(or unlinks) sub-groups from a super group
        @param id_: Group id of the super group
        @param user: Group editor
        @param sub_groups: A list IDs of the sub-groups to be deleted
        @param force: Delete children even if the super group is referenced by another?
        TODO: Either support super group with condition or remove api
        """
        try:
            # Check if group exists
            group_definition = self.get_group_by_id(id_)
            if group_definition['type'] != 'super':
                raise ValueError(
                    "Cannot delete children for non-super group %s" % id_)

            # Check if the group is part referenced by a super group
            if not force and self._has_super_group(id_):
                raise ValueError("Group is referenced by another group")

            # Get sub-groups for the super groups
            subs = self.get_children(id_)
            sub_groups_to_be_retained = set(subs).difference(sub_groups)
            if sub_groups_to_be_retained:
                # Delete sub-group links
                for sub_group in sub_groups:
                    self._delete_group_super_sub_relation(sub_group, id_)

                # Update super group
                if not set(sub_groups_to_be_retained) == set(subs):
                    self._create_or_update_super_group(
                        user,
                        sub_groups_to_be_retained,
                        group_definition=group_definition,
                        overwrite=True,
                        force=force)
            else:
                self.delete_group(id_, force=True)

        except (InvalidInputError, ValueError) as err:
            raise ValueError("Cannot delete children from group %s: %s" %
                             (str(id_), str(err)))

    def delete_group(self, id_, user, force=False):
        """
        Deletes a group
        Note: The operation is not transaction safe which may lead to
        dangling consumed members/static references/super relations
        @param id_: ID of the group to be deleted
        @param force: Delete group even if it is referenced by another?
        """
        try:
            # Check if the group is part referenced by a super group
            if not force and self._has_super_group(id_):
                raise ValueError("Group is referenced by another group")

            # Note parents and group_type
            parents = self.get_parents(id_)
            group_type = self.get_group_by_id(id_)['type']

            # Delete group definition
            self.db_handle.execute(GROUP_DELETE_SQL, (str(id_)))

            # Clean up group relations to super groups
            self._delete_group_super_relations(id_)

            # Update parents
            for group_id in parents:
                parent_def = self.get_group_by_id(group_id)
                query_map = json.loads(parent_def['query_map'])
                super_cond = query_map.get('_axgroup_metadata', {}).get(
                    'super_cond', None)

                self._create_or_update_super_group(
                    user,
                    group_definition=parent_def,
                    overwrite=True,
                    cond=super_cond,
                    force=force)

            # Clean up group relations of static group
            if group_type == 'static':
                self._delete_group_static_relations(id_)

            # Delete group consumed members
            self._delete_group_consumed_members(id_)

        except (InvalidInputError, ValueError) as err:
            raise ValueError("Cannot delete group %s: %s" % (id_, str(err)))

    def _has_super_group(self, group_id):
        res = self.db_handle.execute(GROUP_PARENTS_SELECT_SQL, (str(group_id)))
        return True if res.first() else False

    def _delete_group_static_relations(self, id_):
        # Delete group static relations
        try:
            self.db_handle.execute(PARTITION_DROP_SQL % (
                'AXGroupStaticRelation', str(id_)))
        except:
            pass

    def _delete_group_consumed_members(self, id_):
        # Delete group consumed members
        try:
            self.db_handle.execute(PARTITION_DROP_SQL % (
                'AXGroupConsumedMembers', str(id_)))
        except:
            pass

    def _delete_group_super_relations(self, id_):
        # Delete temporary groups associated with the super group
        self.db_handle.execute(GROUP_TEMP_COND_DELETE_SQL, (str(id_)))

        # Delete group relations
        self.db_handle.execute(GROUP_SUPER_RELATIONS_DELETE_SQL,
                               (str(id_), str(id_)))

    def _delete_group_super_sub_relation(self, group_id, parent_group_id):
        # Delete group relations
        self.db_handle.execute(GROUP_SUPER_SUB_RELATION_DELETE_SQL,
                               (str(group_id), str(parent_group_id)))

    def update_group(self,
                     id_,
                     user,
                     name=None,
                     description=None,
                     type_=None,
                     result_list=None,
                     filter_list=None,
                     internal=None,
                     force=False):
        """
        Update group with new name, description, type, filters and show parameters
        @param id_: ID of the group to be updated
        @param user: Group editor
        @param name: New group name
        @param description: New group description
        @param type_: New group type(static, dynamic, lazy)
        @param result_list: New group show parameters
        @param filter_list: New group filters as nested list(with AND/OR connectors)
        @param force: Update group even if it is referenced by another?
        """
        try:
            result_list = deepcopy(result_list)
            filter_list = deepcopy(filter_list)

            # Check if super group
            group_definition = self.get_group_by_id(id_)
            if group_definition['type'] == 'super':
                raise ValueError(
                    "Update operation is not supported on super groups")

            if not name:
                name = group_definition['name']

            if not description:
                description = group_definition['description']

            if not type_:
                type_ = group_definition['type']

            if internal is None:
                internal = group_definition['internal']

            # Extract query map from the group definition
            existing_query_map = json.loads(group_definition['query_map'])

            if not result_list:
                result_list = existing_query_map['show']

            if filter_list is None:
                filter_list = existing_query_map['filters']

            # Check if filter satisfies group type
            if not self._filter_complies_with_type(filter_list, type_):
                raise ValueError("Filter doesn't comply with type %s" % type_)

            # Initialize query map
            query_map = self.listables.create_query_map()

            # Pick a root listable to start building the query from
            root = result_list[0].split('.')[0]

            # Domain is the type of attributes in the resultset, the 'root'
            # in this case
            domain = root

            if type_ == 'static':
                if len(result_list) > 1:
                    raise InvalidInputError(
                        "Static group must have only one parameter in the "
                        "result list")
                self._build_query_map_for_static_group(query_map, result_list)
            else:
                lt = self.listables[root]

                # Set group filters(WHERE clause)
                lt.set_filters(query_map, filter_list, None)

                # Set group resultset(SELECT clause)
                lt.set_resultset(query_map, result_list)

            # Clean up old group relations(may be the group was static before)
            group_type = self.get_group_by_id(id_)['type']
            if group_type == 'static':
                self._delete_group_static_relations(id_)

            # Add relations with auto generated group id
            if type_ == 'static':
                self._insert_static_relations(id_, query_map, result_list, filter_list)

            # Update group definition
            self.db_handle.execute(GROUP_UPDATE_SQL,
                                   (name, description, user, type_, domain,
                                    json.dumps(query_map),
                                    datetime.datetime.utcnow(), internal,
                                    str(id_)))

            # Update parents
            parents = self.get_parents(id_)
            for group_id in parents:
                parent_def = self.get_group_by_id(group_id)
                self._create_or_update_super_group(
                    user,
                    group_definition=parent_def,
                    overwrite=True,
                    force=force)

        except (InvalidInputError, ValueError) as err:
            raise ValueError("Cannot update group %s: %s" %
                             (str(id_), str(err)))

    def _get_group_filter(self, group_type, query_map):
        # TODO: Return filter for static groups
        if group_type =='static' or group_type == 'super':
            return None
        else:
            return query_map.get('filters', None)

    def _get_group_by_id(self, id_):
        try:
            return self.get_group_by_id(id_)
        except (InvalidInputError, ValueError):
            return None

    def get_group_by_id(self, id_):
        """
        Returns a group definition for the id_ or raises ValueError
        @param id_: ID of the group to be fetched
        """
        result = {}

        # Fetch group definition
        res = self.db_handle.execute(GROUP_SELECT_BY_ID_SQL, (str(id_)))
        row = res.first()
        if row:
            result = {
                'id': id_,
                'name': row[0],
                'description': row[1],
                'author': row[2],
                'editor': row[3],
                'creation_time': row[4].strftime("%Y-%m-%d %H:%M:%S") \
                        if isinstance(row[4], datetime.datetime) \
                        else str(row[4]),
                'last_updated': row[5].strftime("%Y-%m-%d %H:%M:%S") \
                        if isinstance(row[5], datetime.datetime) \
                        else str(row[5]),
                'type': row[6],
                'domain': row[7],
                'query_map': row[8],
                'filter': self._get_group_filter(row[6], json.loads(row[8])),
                'internal': row[9]
            }
        else:
            raise ValueError("Group %s does not exist" % id_)

        return result

    def _get_groups_by_attr(self, attr_name, attr_value, operator='='):
        result_list = []

        # Put attribute name and operator
        sql = GROUP_SELECT_BY_ATTR_SQL % (attr_name, operator, '%s')

        if operator == 'like':
            # Replace wildcard * with %
            attr_value = sanitize_input(attr_value, 'mysql')

        res = self.db_handle.execute(sql, (str(attr_value)))
        for row in res:
            result_list.append({
                'id': row[0],
                'name': row[1],
                'description': row[2],
                'author': row[3],
                'editor': row[4],
                'creation_time': row[5].strftime("%Y-%m-%d %H:%M:%S") \
                        if isinstance(row[5], datetime.datetime) \
                        else str(row[5]),
                'last_updated': row[6].strftime("%Y-%m-%d %H:%M:%S") \
                        if isinstance(row[6], datetime.datetime) \
                        else str(row[6]),
                'type': row[7],
                'domain': row[8],
                'query_map': row[9],
                'filter': self._get_group_filter(row[7], json.loads(row[9]))
            })

        return result_list

    def get_groups_by_type(self, type_):
        """
        Returns group definitions for given type
        @param type_: Type of the groups to be fetched(* as wildcard)
        """
        return self._get_groups_by_attr('type', type_)

    def search_groups_by_name(self, name):
        """
        Returns group definitions for matching name
        @param name: Name of the groups to be fetched(* as wildcard)
        """
        return self._get_groups_by_attr('name', name, operator='like')

    def search_groups_by_description(self, desc):
        """
        Returns group definitions for matching description
        @param desc: Description of the groups to be fetched(* as wildcard)
        """
        return self._get_groups_by_attr('description', desc, operator='like')

    def search_groups_by_domain(self, domain, limit=100, offset=0):
        """
        Returns group definitions for matching domain
        @param name: Domain of the groups to be fetched
        """
        groups = self.search_groups(
            [['Group.domain', '=', domain],
             'and', ['Group.internal', '=', '0']],
            ['id', 'name', 'description', 'author', 'editor', 'creation_time',
             'last_updated', 'type', 'domain', 'query_map'],
            limit=limit,
            offset=offset,
            return_as='dict')

        for group in groups:
            group['filter'] = self._get_group_filter(
                group['Group.type'], json.loads(group['Group.query_map']))

        return groups

    def search_groups(self,
                      filter_list=None,
                      result_list=None,
                      sort=None,
                      limit=100,
                      offset=0,
                      return_as='list'):
        """
        Returns requested group attributes for matching filters
        @param filter_list: Search criteria as listable filter
        @param result_list: List of group attributes as result
        @param sort: Sort criteria as a listable sort list
        @param limit: Records to be fetched
        @param offset: Offset from which the records to be fetched
        """

        if not filter_list and not result_list:
            return []

        query_map = self.listables.create_query_map()
        lt = self.listables['Group']
        if filter_list: lt.set_filters(query_map, filter_list)
        if result_list: lt.set_resultset(query_map, result_list)
        if sort: lt.set_query_options(query_map, sort=sort)
        data = lt.get_data(query_map, self.db_handle, limit, offset)
        if return_as == 'list':
            return data
        else:
            return self.listables.post_process(data, query_map, self.db_handle)

    def resolve_children(self, id_):
        """
        Returns a list of IDs of the sub-groups until all super
        groups are resolves
        @param id_: ID of the parent group
        """
        resolved_children = []
        children = self.get_children(id_)

        for group_id in children:
            group = self.get_group_by_id(group_id)
            if group['type'] == 'super':
                resolved_children.extend(self.resolve_children(group_id))
            else:
                resolved_children.append(group_id)

        return resolved_children

    def get_children(self, id_):
        """
        Returns a list of IDs of the sub-groups
        @param id_: ID of the parent group
        """
        res = self.db_handle.execute(GROUP_CHILDREN_SELECT_SQL, (str(id_)))
        children = [row[0] for row in res]
        return children

    def get_parents(self, id_, internal=False):
        """
        Returns a list of IDs of the parent groups
        @param id_: ID of the child group
        @param internal: Return parents flagged as internal in addition to
        non-internals if True else only non-internal parents
        """
        parents = []

        if internal:
            res = self.db_handle.execute(GROUP_PARENTS_SELECT_SQL, (str(id_)))
        else:
            res = self.db_handle.execute(
                GROUP_NON_INTERNAL_PARENTS_SELECT_SQL, (str(id_)))

        for row in res:
            parents.append(row[0])

        return parents

    def get_all_groups(self, limit=100, offset=0, internal=False):
        """
        Returns group definitions of all the non-internal groups
        @param limit: Records to be fetched
        @param offset: Offset from which the next records to be fetched
        """
        # Fetch all group definition
        result_list = []
        res = self.db_handle.execute(GROUP_SELECT_ALL_SQL,
                                     (str(1)
                                      if internal else str(0), limit, offset))
        for row in res:
            result_list.append({
                'id': row[0],
                'name': row[1],
                'description': row[2],
                'author': row[3],
                'editor': row[4],
                'creation_time': row[5].strftime("%Y-%m-%d %H:%M:%S") \
                        if isinstance(row[5], datetime.datetime) \
                        else str(row[5]),
                'last_updated': row[6].strftime("%Y-%m-%d %H:%M:%S") \
                        if isinstance(row[6], datetime.datetime) \
                        else str(row[6]),
                'type': row[7],
                'domain': row[8],
                'query_map': row[9],
                'filter': self._get_group_filter(row[7], json.loads(row[9]))
            })

        return result_list

    def get_group_members(self,
                          id_,
                          lazy_filter=None,
                          sort=None,
                          limit=100,
                          offset=0,
                          return_as='list'):
        """
        Returns members(show parameters) of a group
        @param id_: ID of a group whose members to be fetched
        @param lazy_filter: Values to be resolved for lazy placeholders
        @param sort: One or more group show parameters based on which the results are sorted
        @param limit: Records to be fetched
        @param offset: Offset from which the next records to be fetched
        @param return_as: Returned as 'list' or 'dict'
        """
        try:
            # Get group definition
            group = self.get_group_by_id(id_)
            query_map = json.loads(group['query_map'])

            # Extract query map from the group definition
            if group['type'] == 'static':
                lazy_filter = {'static_group_id': id_}
                lt = self.listables['GroupStaticRelation']

                # static group can only be sorted based on member_id
                if sort:
                    try:
                        sort = [['GroupStaticRelation.member_id', sort[0][1]]]
                    except IndexError:
                        sort = [['GroupStaticRelation.member_id', 'asc']]
            else:
                root = query_map['show'][0].split('.')[0]
                lt = self.listables[root]

            # Update query options(ORDER BY)
            lt.set_query_options(query_map, sort=sort)

            # Fetch group members and post process
            data_list = lt.get_data(
                query_map,
                self.db_handle,
                limit=limit,
                offset=offset,
                lazy_filter=lazy_filter)

            if return_as == 'dict':
                data_list = self.listables.post_process(
                    data_list, query_map, self.db_handle)

            return data_list
        except KeyError as err:
            raise ValueError(
                "Cannot fetch members of group %s: Key %s not found" %
                (str(id_), str(err)))
        except (InvalidInputError, ValueError, TypeError) as err:
            raise ValueError("Cannot fetch members of group %s: %s" %
                             (str(id_), str(err)))

    def get_group_members_with_condition(
            self, ids, cond=None, result_list=None, lazy_filter=None, limit=100, offset=0,
            return_as='list'):
        """
        Returns members of one or more groups and the condition
        @param ids: Group ids as a list
        @param cond: filter as axcondition
        @param result_list: New list of member attributes to be returned
        @param lazy_filter: Values to be resolved for lazy placeholders
        @param limit: Records to be fetched
        @param offset: Offset from which the next records to be fetched
        @param return_as: Returned as 'list' or 'dict'
        """

        try:
            # Build a fused query map out of all group queries
            query_map = self._build_query_map_for_groups_results_cond(
                ids, results=result_list, cond=cond)

            # Fetch group members and post process
            root = query_map['show'][0].split('.')[0]
            lt = self.listables[root]
            data_list = lt.get_data(
                query_map,
                self.db_handle,
                limit=limit,
                offset=offset,
                lazy_filter=lazy_filter)

            if return_as == 'dict':
                data_list = self.listables.post_process(
                    data_list, query_map, self.db_handle)

            return data_list
        except Exception as ex:
            raise ValueError("Cannot fetch members of groups %s, cond %s and result %s: %s" %
                             (str(ids), str(cond), str(result_list), str(ex)))

    def get_group_members_with_condition_count(
            self, ids, cond=None, lazy_filter=None):
        """
        Returns members of one or more groups and the condition
        @param ids: Group ids as a list
        @param cond: filter as axcondition
        @param lazy_filter: Values to be resolved for lazy placeholders
        """

        try:
            # Build a fused query map out of all group queries
            query_map = self._build_query_map_for_groups_results_cond(
                ids, cond=cond)

            # Fetch group members and post process
            root = query_map['show'][0].split('.')[0]
            lt = self.listables[root]

            # Fetch group members and post process
            count = lt.get_count(
                query_map,
                self.db_handle,
                lazy_filter=lazy_filter,
                wrap=True)

            return count
        except Exception as ex:
            raise ValueError("Cannot fetch member count of groups %s and cond %s: %s" %
                             (str(ids), str(cond), str(ex)))

    def get_group_extended_members(self,
                                   id_,
                                   result_list=None,
                                   filter_list=None,
                                   lazy_filter=None,
                                   sort=None,
                                   limit=100,
                                   offset=0,
                                   return_as='list'):
        """
        Returns requested extended members matching further filter
        @param id_: ID of a group whose extended members to be fetched
        @param result_list: New list of member attributes to be returned
        @param filter_list: Further filters to be applied to the group members
        @param lazy_filter: Values to be resolved for lazy placeholders
        @param sort: One or more group show parameters based on which the
        results are sorted
        @param limit: Records to be fetched
        @param offset: Offset from which the next records to be fetched
        @param return_as: Returned as 'list' or 'dict'
        """
        try:
            query_map = self._build_query_map_for_groups_results_cond(
                [id_], result_list, filter_list, sort)

            # Fetch group members and post process
            root = query_map['show'][0].split('.')[0]
            lt = self.listables[root]
            data_list = lt.get_data(
                query_map,
                self.db_handle,
                limit=limit,
                offset=offset,
                lazy_filter=lazy_filter)

            if return_as == 'dict':
                data_list = self.listables.post_process(
                    data_list, query_map, self.db_handle)

            return data_list
        except KeyError as err:
            raise ValueError(
                "Cannot fetch extended members of group %s: Key %s not found" %
                (str(id_), str(err)))
        except (InvalidInputError, ValueError, TypeError) as err:
            raise ValueError("Cannot fetch extended members of group %s: %s" %
                             (str(id_), str(err)))

    def get_group_extended_members_count(self,
                                         id_,
                                         result_list=None,
                                         filter_list=None,
                                         lazy_filter=None):
        """
        Returns requested extended members count matching further filter
        @param id_: ID of a group whose extended members to be counted
        @param result_list: New list of member attributes to be counted
        @param filter_list: Further filters to be applied to the group members
        @param lazy_filter: Values to be resolved for lazy placeholders
        """
        try:
            group = self.get_group_by_id(id_)

            query_map = self._build_query_map_for_groups_results_cond(
                [id_], result_list, filter_list)

            # Fetch group members and post process
            root = query_map['show'][0].split('.')[0]
            lt = self.listables[root]
            count = lt.get_count(
                query_map,
                self.db_handle,
                lazy_filter=lazy_filter,
                wrap=True if group['type'] == 'super' else False)

            return count
        except KeyError as err:
            raise ValueError(
                "Cannot fetch extended members count of group %s: Key %s not found" %
                (str(id_), str(err)))
        except (InvalidInputError, ValueError, TypeError) as err:
            raise ValueError("Cannot fetch extended members count of group %s: %s" %
                             (str(id_), str(err)))


    def _build_unconsumed_members_query_map(self,
                                            id_,
                                            lazy_filter=None):
        # Get group definition
        group = self.get_group_by_id(id_)

        # Extract query map from the group definition
        query_map = json.loads(group['query_map'])

        # Amend the query to skip the consumed members(this is a hack)
        amendment_prefix = ""
        amendment_suffix = ""
        sub_query = "NOT IN ( SELECT member_id FROM AXGroupConsumedMembers " \
                "WHERE group_id = %s )" % id_
        primary_object = query_map['show'][0].split('.')[0]
        primary_id = self.listables.get_primary_id(primary_object)

        if group['type'] == 'static':
            amendment_suffix = "AND member_id %s" % sub_query
        elif group['type'] == 'super':
            # Determine the columns of the first query
            query = query_map['full_query']
            first_query = query[:query.index('UNION')] if "UNION" in query else query[:]
            first_show = first_query[first_query.index(
                'SELECT') + 1:first_query.index('FROM')][0].split(',')
            first_show = [p.split('.')[1] for p in first_show]

            amendment_prefix = "SELECT %s FROM ( " % ','.join(first_show)
            amendment_suffix = " ) AS AXSuperQuery WHERE AXSuperQuery.%s %s" \
                % (first_show[0] if len(
                    first_show) == 1 else primary_id, sub_query)
        else:
            amendment_suffix = "AND %s.%s %s" % (primary_object,
                                                    primary_id, sub_query)

        query_map['full_query'].extend(amendment_suffix.split(' '))
        query_map['full_query'][0:0] = amendment_prefix.split(' ')

        return query_map


    def get_group_unconsumed_members(self,
                                     id_,
                                     lazy_filter=None,
                                     sort=None,
                                     limit=100,
                                     offset=0,
                                     return_as='list'):
        """
        Returns unique members(show parameters) of a group across
        all calls(even if the lazy_filters change).
        @param id_: ID of a group whose members to be fetched
        @param lazy_filter: Values to be resolved for lazy placeholders
        @param sort: One or more group show parameters based on which the results are sorted
        @param limit: Records to be fetched
        @param offset: Offset from which the next records to be fetched
        @param return_as: Returned as 'list' or 'dict'
        """
        try:
            # Get group definition
            group = self.get_group_by_id(id_)

            # Build query map for unconsumed members
            query_map = self._build_unconsumed_members_query_map(
                id_, lazy_filter)

            if group['type'] == 'static':
                lazy_filter = {'static_group_id': id_}
                lt = self.listables['GroupStaticRelation']

                # static group can only be sorted based on member_id
                if sort:
                    try:
                        sort = [['GroupStaticRelation.member_id', sort[0][1]]]
                    except IndexError:
                        sort = [['GroupStaticRelation.member_id', 'asc']]
            else:
                root = query_map['show'][0].split('.')[0]
                lt = self.listables[root]

            # Update query options(ORDER BY)
            lt.set_query_options(query_map, sort=sort)

            # Fetch group members and post process
            data_list = lt.get_data(
                query_map,
                self.db_handle,
                limit=limit,
                offset=offset,
                lazy_filter=lazy_filter)

            if return_as == 'dict':
                data_list = self.listables.post_process(data_list, query_map,
                                                        self.db_handle)

            return data_list
        except KeyError as err:
            raise ValueError(
                "Cannot fetch members of group %s: Key %s not found" %
                (str(id_), str(err)))
        except (ValueError, TypeError) as err:
            raise ValueError("Cannot fetch members of group %s: %s" %
                             (str(id_), str(err)))

    def get_group_unconsumed_member_count(self,
                                          id_,
                                          lazy_filter=None):
        """
        Returns unconsumed member count
        @param id_: ID of a group whose unconsumed member count to be fetched
        @param lazy_filter: Values to be resolved for lazy placeholders
        """
        try:
            # Get group definition
            group = self.get_group_by_id(id_)
            query_map = json.loads(group['query_map'])

            if group['type'] == 'static':
                lazy_filter = {'static_group_id': id_}
                lt = self.listables['GroupStaticRelation']
            else:
                root = query_map['show'][0].split('.')[0]
                lt = self.listables[root]

            # Build query map for unconsumed members
            query_map = self._build_unconsumed_members_query_map(
                id_, lazy_filter)

            return lt.get_count(
                query_map,
                self.db_handle,
                lazy_filter=lazy_filter,
                wrap=True if group['type'] == 'super' else False)

        except KeyError as err:
            raise ValueError(
                "Cannot fetch unconsumed member count for group %s: Key %s not found" %
                (str(id_), str(err)))
        except (ValueError, TypeError) as err:
            raise ValueError("Cannot fetch unconsumed member count for group %s: %s" %
                             (str(id_), str(err)))


    def get_group_consumed_member_count(self, id_):
        """
        Returns unconsumed member count
        @param id_: ID of a group whose consumed member count to be fetched
        """
        res = self.db_handle.execute(GROUP_CONSUMED_MEMBERS_SELECT_COUNT_SQL,
                                     (str(id_), str(id_)))
        res = [row[0] for row in res]

        if not res or res[0] != 'GroupExists':
            raise ValueError(
                "Cannot count consumed members: Group %s does not exist" %
                str(id_))

        return int(res[1]) if len(res) > 1 else 0


    def consume_member(self, group_id, member_id, state=255):
        """
        Sets member of group as consumed i.e. never to be returned again
        by get_group_unique_members call until unconsume_all_members is called
        @param group_id: ID of the group whose member to be tagged as consumed
        @param member_id: Primary ID of the member of the group to be tagged as
        consumed
        @param state: Consumption state
        """
        return self.consume_members(group_id, [member_id], state)

    def consume_members(self, group_id, member_ids, state=255):
        """
        Sets members of a group as consumed i.e. never to be returned again
        by get_group_unique_members call until unconsume_all_members is called
        @param group_id: ID of the group whose member to be tagged as consumed
        @param member_ids: List of primary IDs of the members of the group to be
        tagged as consumed
        @param state: Consumption state
        """
        # Add memebr to consumed members for a group
        values = []
        for member_id in member_ids:
            values.extend([str(group_id), str(member_id), str(state)])

        # Append group id for SELECT clause
        values.append(str(group_id))

        # Append state for UPDATE clause
        values.append(str(state))

        res = self.db_handle.execute(GROUP_CONSUMED_MEMBERS_INSERT_SQL.replace(
            '<format_specifiers>', ' UNION ALL '.join(list(repeat(
                'SELECT %s AS g,%s AS m,%s AS s', len(member_ids))))), values)

        if not res.rowcount:
            raise ValueError("Cannot consume members: Group %s does not exist" %
                             group_id)

    def is_member_consumed(self, group_id, member_id, state=255):
        """
        Returns True if member of group is consumed already
        by get_group_unique_members call until unconsume_all_members is called
        @param group_id: ID of the group whose member to be tagged as consumed
        @param member_id: Primary ID of the member of the group to be tagged as
        consumed
        @param state: state to be matched(if None, return True if the member is
        consumed irrespective of state)
        """
        if state is None:
            res = self.db_handle.execute(GROUP_CONSUMED_MEMBERS_SELECT_SQL, (
                str(group_id), str(group_id), str(member_id)))
        else:
            res = self.db_handle.execute(
                GROUP_CONSUMED_MEMBERS_SELECT_BY_STATE_SQL, (
                str(group_id), str(group_id), str(member_id), str(state)))
        res = [row for row in res]

        if not res or res[0][1] != 'GroupExists':
            raise ValueError(
                "Cannot check if member consumed: Group %s does not exist" %
                str(group_id))

        return True if len(res) > 1 else False

    def unconsume_all_members(self, group_id):
        """
        Un-consumes all consumed members of a group
        @param group_id: ID of the group to reset
        """
        try:
            # Delete consumed members for a group, ignore if the
            # partition does not exist for some reason
            self.db_handle.execute(PARTITION_DROP_SQL % (
                'AXGroupConsumedMembers', str(group_id)))
        except:
            pass

        # Add partition for consumed members
        self.db_handle.execute(PARTITION_ADD_SQL % (
            'AXGroupConsumedMembers', str(group_id), str(group_id)))

    def unconsume_members_by_states(self, group_id, states=None):
        """
        Un-consumes the consumed members of a group by states
        @param group_id: ID of the group to reset
        @param states: A list of states; members in these states will be reset(
        defaults to resetting all consumed members with state 255)
        """
        if states:
            self.db_handle.execute(GROUP_CONSUMED_MEMBERS_DELETE_BY_STATES_SQL +
                                   '(' + ','.join(
                                       list(repeat('%s', len(states)))) + ')',
                                   (str(group_id),) + tuple(states))
        else:
            self.db_handle.execute(
                GROUP_CONSUMED_MEMBERS_DELETE_ALL_FINAL_STATES_SQL,
                (str(group_id)))


    def unconsume_member(self, group_id, member_id):
        """
        Un-consumes the consumed member of a group by its id
        @param group_id: ID of the group to reset
        @param member_id: ID of the group member to be reset
        """
        self.db_handle.execute(GROUP_CONSUMED_MEMBER_DELETE_BY_ID_SQL,
                               (str(group_id), str(member_id)))

    def get_group_member_count(self, id_, lazy_filter=None):
        """
        Returns member count of a group
        @param id_: ID of a group whose member count to be fetched
        @param lazy_filter: Values to be resolved for lazy placeholders
        """
        try:
            # Get group definition
            group = self.get_group_by_id(id_)
            query_map = json.loads(group['query_map'])

            if group['type'] == 'static':
                lazy_filter = {'static_group_id': id_}
                lt = self.listables['GroupStaticRelation']
            else:
                root = query_map['show'][0].split('.')[0]
                lt = self.listables[root]

            return lt.get_count(
                query_map,
                self.db_handle,
                lazy_filter=lazy_filter,
                wrap=True if group['type'] == 'super' else False)
        except (InvalidInputError, ValueError) as err:
            raise ValueError("Cannot get member count for group %s: %s" %
                             (str(id_), str(err)))

    def get_group_membership(self, property_name, value):
        """
        Returns a list of non-lazy groups that the property value is member of
        @param property_name: Name of the property to be looked in
        @param value: Property value to be matched with group members
        """
        membership = []
        last_fetch_count = limit = 100
        offset = 0
        try:
            # Resolve property name if required
            property_name = self._resolve_property_name(property_name)

            # Don't fetch all groups at once but 100 at a time
            while last_fetch_count == limit:
                # Fetch a bunch of groups
                groups = self.get_all_groups(limit, offset)

                # Fetch count and set new offset for the next run
                last_fetch_count = len(groups)
                offset += limit

                # Iterate over groups to check if the requested value is a member
                for group in groups:
                    # Ignore lazy groups
                    if group['type'] == 'lazy':
                        continue

                    # Extract query map from the group definition
                    query_map = json.loads(group['query_map'])

                    # Skip the group if the object is not in its result set
                    if property_name not in query_map['show']:
                        continue

                    # Skip super group if it has lazy filters
                    if group['type'] == 'super':
                        # Instantiate listables
                        root = query_map['show'][0].split('.')[0]
                        lt = self.listables[root]
                        if lt.has_lazy_filter(query_map):
                            continue

                    if self.is_member(property_name, value, group['id']):
                        membership.append(group['id'])
        except (InvalidInputError, ValueError) as err:
            raise ValueError("Cannot fetch memberships for %s=%s: %s" %
                             (property_name, value, str(err)))

        return membership

    def is_member(self, property_name, value, group_id, lazy_filter=None):
        """
        Checks if a property value is a memebr of a given group
        @param property_name: Name of the property to be looked in
        @param value: Property value to be matched with group members
        @param group_id: ID of a group against which the membership is verified
        @param lazy_filter: Values to be resolved for lazy placeholders
        """
        try:
            # Resolve property name if required
            property_name = self._resolve_property_name(property_name)

            # Get group definition
            group = self.get_group_by_id(group_id)

            # Extract query map from the group definition
            query_map = json.loads(group['query_map'])

            # Not a member if the object is not in its result set
            if property_name not in query_map['show']:
                return False

            # Special handling for super groups
            if group['type'] == 'super':
                members = self.get_group_members_with_condition(
                    [group_id],
                    [property_name, "=", value],
                    lazy_filter=lazy_filter,
                    limit=1)
                return len(members) >= 1
            elif group['type'] == 'static':
                data = self.listables.select(
                    self.db_handle,
                    results=['member_id'],
                    filters=[
                        ['group_id', '=', group_id],
                        'and',
                        ['member_id', '=', value]],
                    limit=1,
                    return_as='list',
                    root='GroupStaticRelation')
                return True if data else False

            # Add the object id to the group filter and check is record exists
            root = query_map['show'][0].split('.')[0]
            lt = self.listables[root]
            filter_list = query_map['filters']
            extra_filter = ['and', [property_name, '=', value]]
            lt.set_filters(query_map, filter_list, extra_filter)

            data_list = lt.get_data(
                query_map, self.db_handle, limit=1, lazy_filter=lazy_filter)

            return True if data_list else False
        except KeyError as err:
            raise ValueError("Cannot verify membership for %s=%s against group %s: " \
                             "Key %s not found" % (property_name, value, str(group_id), str(err)))
        except (InvalidInputError, ValueError, TypeError) as err:
            raise ValueError(
                "Cannot verify membership for %s=%s against group %s: %s" %
                (property_name, value, str(group_id), str(err)))

    def _resolve_property_name(self, property_name):
        if not property_name:
            return None

        # Resolve property name if required
        if len(property_name.split('.')) == 1:
            property_name = '.'.join(
                (property_name, self.listables.get_primary_id(property_name)))

        return property_name
