"""
AXC Struct Logger

By default it Writes serialized objects to watched rotating file handler
and also, if started on foreground, to stdout, prettyfied and colorized.


Clients need to only import get_setup method and start logging structures
(maps and lists).

We generate the logger based on environ settings and insert elasticsearch
compliant timestamps.

All else is from environ -> we assume type of logging as the same for the
basic structures of a daemon (in and out).

The serializing is made to work for sure, i.e. don't fail for non str keys or
value objects

If startfg is exported as RUNCMD (AXC style) then you get colored struct
logs in foreground mode, i.e. for your REST API calls.

Best Practice:

    from axc_logging import get_setup
    logger, log, logs, debug, info, warning, error, exception = get_setup()

    and then logs(mydict, 'my message' , prio=error)
    or       log((mydict, 'my message'), error)

or just:

    from axc_logging import get_setup
    logger, logs = setup_logger()[:2]

    logs(mydict, 'my message', prio=logger.error)
    logs(mydict, 'my message', myticket)



"""


import time, datetime
from ax.utils.logging.handlers import WatchedFileHandler
from os import environ, path
from json import dumps
from logging import INFO, getLogger
from colorhilite import colyhighlight, coljhighlight
import yaml

foreground = 0
if environ.get('RUNCMD') == 'startfg':
    foreground = 1

def get_setup(**kw):
    """ convenicene method for clients """
    logger = setup_logger(**kw)
    return logger, log_structs, log_struct, logger.debug, logger.info, \
                    logger.warning, logger.error, logger.exception

# have the simpletypes be built at compiletime and within the locals,
# which is faster:
def string_keys(m, simpletypes=(float, bool, int, basestring)):
    """ intended for the dumps operation to work in any case
    so we return [] also for tuples"""
    if isinstance(m, simpletypes):
        return m
    if isinstance(m, dict):
        res = {}
        for k, v in m.items():
            # func calls expensive:
            if not isinstance(v, simpletypes):
                v = string_keys(v)
            res[str(k)] = v
        return res
    try:
        return [string_keys(el) for el in m]
    except:
        return str(m)




# the only way without additional libs to get all compliant:
tzoffset = time.strftime('%z')
tzoffset = tzoffset[:3] + ':' + tzoffset[3:]

def log_structs(*struct, **kw):
    """
    log_structs(mydict) but also logstructs('received', mydict)
    for the price of having to say prio='warning', instead
    ls(mydict, 'warning')
    """
    if isinstance(struct, tuple) and len(struct) == 1:
        struct = struct[0]
    return log_struct(struct, **kw)

logger = None
def log_struct(struct, prio=None, no_log=0):
    """
    the base method clients have to use to log structures
    level arg, so that normally not logging clients can force writes
    """

    global logger

    if not logger:
        logger = setup_logger()

    if prio is None:
        prio = logger.info

    # https://tools.ietf.org/html/rfc3339#section-5.8
    isot = datetime.datetime.now().isoformat() + tzoffset
    m = {'@timestamp': isot,
         '@fields': struct}
    try:
        dumped = dumps(m, default=str)
    except TypeError as ex:
        if 'keys must be' in ex.args[0]:
            # he has objects in keys. -> convert to str:
            m = string_keys(m)
            struct = m['@fields']
            dumped = dumps(m, default=str)
    if no_log:
        # somebody else wants a safely dumped structure:
        return dumped

    # fastest is to call us with the method:
    try:
        prio(dumped)
    except TypeError:
        # prio as string, maybe from user. be tolerant here.
        try:
            getattr(logger, prio)(dumped)
        except AttributeError:
            prio = prio.lower()
            if 'err' in prio:
                prio = 'error'
            getattr(logger, prio)(dumped)

    if foreground:
        # yml has the advantage of insert refs instead duplicate structures, 
        # much shorter output than json:
        # print coljhighlight(dumps(struct, indent=2))
        # but syntaxhighligher (lexer) is stupid. no key hightlighting.
        #print colyhighlight(struct)
        print (coljhighlight(struct))



def setup_logger(foreground=-1, logger_name=None):
    """
    The foreground argument allows to set it up to fg also from outside
    here
    """
    global logger
    if foreground != -1:
        globals()['foreground'] = 1

    # AXC compat environ setup required:
    # one dedicated logger per daemon, id like unauthd:
    e = environ
    if logger_name is None:
        logger_name = e.get('logger', e.get('id', 'ax'))

    logger = getLogger(logger_name)

    if logger.handlers:
        # set up already
        return logger

    d = e.get('log_dir', '/var/log')
    fn = logger_name + '.json'
    file_name = path.join(d, fn)
    logger.setLevel(INFO)
    #TODO: check env for destionations. Right now only this:
    logger.addHandler(WatchedFileHandler(file_name))
    return logger



