#!/usr/bin/env python
# coding: utf-8
from __future__ import absolute_import, division, print_function

import unittest2
from ax.utils import fs
from functools import partial
from ax.utils.formatting.unicode_chars import unic, native
import os, sys

test1, test2 = "①②③④⑤⑥⑦⑧⑨⑩", "① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩"


# we test with real files, not stringio, to be more realistic
D = "/tmp/test_ax_utils_fs"
os.system('/bin/rm -rf "%s"; mkdir -p "%s"' % (D, D))
fn = lambda s: D + "/" + s


class TestFS(unittest2.TestCase):
    def setUp(self):
        self.fds = []
        for k, n in ("fn1", test1), ("fn2", test2):
            with open(fn(k), "w") as fd:
                fd.write(n)

    def test_write_file(self):
        fn = D + "/foo2/baz"
        fs.write_file(fn, "cont2", mkdir=1)
        self.assertEqual(fs.read_file(fn), "cont2")

        fn = D + "/foo/bar/baz"
        with self.assertRaises(IOError):
            fs.write_file(fn, "cont")

        with self.assertRaises(OSError):
            fs.write_file(fn, "cont", mkdir=1)

        # now with mkdirs
        fs.write_file(fn, "cont", mkdirs=1)
        self.assertEqual(fs.read_file(fn), "cont")

    def test_read_uni_chars(self):
        for chars in -1, 0, 1, 2, 10, 100:
            print(chars)
            for k, n in ("fn1", test1), ("fn2", test2):
                # '''fd will be closed in teardown
                self.fds.append(open(fn(k), "r"))
                res = fs.read_uni_chars(self.fds[-1], chars)
                print(str(res))
                c = unic(n)[:chars] if chars > -1 else unic(n)
                self.assertEqual(unic(res), c)
                self.assertEqual(type(res), type(""))  # i.e. str in 2 uni in 3

    def test_read_file(self):
        for k, n in ("fn1", test1), ("fn2", test2):
            self.assertEqual(fs.read_file(fn(k)), native(n))
            self.assertEqual(fs.read_file(fn(k), "", 0), "")
            for chars in 0, 1, 2, 10, 100:
                res = fs.read_file(fn(k), "", chars)
                self.assertEqual(unic(res), unic(n)[:chars])
                self.assertEqual(type(res), type(""))  # i.e. str in 2 uni in 3

    def tearDown(self):
        for fd in self.fds:
            try:
                fd.close()
            except:
                pass


if __name__ == "__main__":
    unittest2.main()
