import threading
from ax.utils.six.moves.queue import Queue
from ax.utils.six.moves.queue import Empty
from copy import deepcopy
import traceback

class ConsumerRunner(threading.Thread):
    def __init__(self, consum_func, queue, reduce_, init):
        threading.Thread.__init__(self)
        self.stop = False
        self.consum_func = consum_func
        self.queue = queue
        self.reduce_ = reduce_
        self.init = init

    def run(self):
        while not self.stop:
            try:
                job = self.queue.get(True, 1)
            except Empty:
                pass
            else:
                try:
                    self.init = self.reduce_(self.init, self.consum_func(job))
                except Exception:
                    print (traceback.print_exc())
                self.queue.task_done()


_default = lambda x,y: None
def run(producer, consumer, number, reduce_func=_default, initial=None):
    q = Queue(number + 1)

    threads = []
    for _ in range(number):
        t = ConsumerRunner(consumer, q, reduce_func, deepcopy(initial))
        t.start()
        threads.append(t)

    try:
        for job in producer:
            q.put(job, 1)
        q.join()
    finally:
        for t in threads:
            initial = reduce_func(initial, t.init)

        for t in threads:
            t.stop = True
            t.join()
    return initial
