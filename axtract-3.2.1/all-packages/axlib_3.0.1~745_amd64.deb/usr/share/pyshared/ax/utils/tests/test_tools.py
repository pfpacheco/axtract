import unittest2
import multiprocessing
import os
import sys

from ax.utils.tools import chunk_iterable
from ax.utils.tools import get_resident_memory
from ax.utils.tools import ProcessLocal


class TestTools(unittest2.TestCase):
    def compare_chunked_to_ref(self, chunked, ref):
        """Helper function for testing chunk_iterable
        """
        chunked_list = [list(chunk) for chunk in chunked]
        self.assertEqual(ref, chunked_list)

    def test_chunk_iterable(self):
        """chunk an iterable with a len()"""
        data = 'abcdefghijklmnop'
        ref = [
            ['a', 'b', 'c', 'd', 'e', 'f', 'g'],
            ['h', 'i', 'j', 'k', 'l', 'm', 'n'],
            ['o', 'p']
        ]
        chunked = chunk_iterable(data, 7)
        self.compare_chunked_to_ref(chunked, ref)

        self.assertTrue(data == 'abcdefghijklmnop')

    def test_chunk_iterator(self):
        """chunk an iterable withOUT a len()"""
        data = 'abcdefghijklmnop'
        ref = [
            ['a', 'b', 'c', 'd', 'e', 'f', 'g'],
            ['h', 'i', 'j', 'k', 'l', 'm', 'n'],
            ['o', 'p']
        ]
        chunked = chunk_iterable(iter(data), 7)
        self.compare_chunked_to_ref(chunked, ref)

        self.assertTrue(data == 'abcdefghijklmnop')

    def test_empty_iterable(self):
        """empty iterables must work"""
        data = []
        ref = []

        # empty list
        chunked = chunk_iterable(data, 7)
        self.compare_chunked_to_ref(chunked, ref)

        # iterator over empty list
        chunked = chunk_iterable(iter(data), 7)
        self.compare_chunked_to_ref(chunked, ref)

        self.assertTrue(data == [])

    def test_short_chunk(self):
        """test for chunksize==1"""
        data = [1, 2, 3]
        ref = [ [1], [2], [3] ]

        # over list
        chunked = chunk_iterable(data, 1)
        self.compare_chunked_to_ref(chunked, ref)
        # over iterator
        chunked = chunk_iterable(iter(data), 1)
        self.compare_chunked_to_ref(chunked, ref)

        self.assertTrue(data == [1, 2, 3])

    def test_len_smaller_chunksize(self):
        """see what happens if len(iterable) < $chunksize"""
        data = [1]
        ref = [[1]]

        # over list
        chunked = chunk_iterable(data, 2)
        self.compare_chunked_to_ref(chunked, ref)
        # over iterator
        chunked = chunk_iterable(iter(data), 2)
        self.compare_chunked_to_ref(chunked, ref)

        self.assertTrue(data == [1])

    def test_len_is_chunksize(self):
        """see what happens if len(iterable) == $chunksize"""
        data = [1, 2, 3]
        ref = [[1, 2, 3]]

        # over list
        chunked = chunk_iterable(data, 3)
        self.compare_chunked_to_ref(chunked, ref)
        # over iterator
        chunked = chunk_iterable(iter(data), 3)
        self.compare_chunked_to_ref(chunked, ref)

        self.assertTrue(data == [1, 2, 3])

    def test_len_is_multiple_chunksize(self):
        """see what happens if len(iterable) is a multiple of $chunksize"""
        data = [1, 2, 3, 4, 5, 6]
        ref = [[1, 2, 3], [4, 5, 6]]

        # over list
        chunked = chunk_iterable(data, 3)
        self.compare_chunked_to_ref(chunked, ref)
        # over iterator
        chunked = chunk_iterable(iter(data), 3)
        self.compare_chunked_to_ref(chunked, ref)

        self.assertTrue(data == [1, 2, 3, 4, 5, 6])
    def test_len_is_not_multiple_chunksize(self):
        """see what happens if len(iterable) is NOT a multiple of $chunksize"""
        data = [1, 2, 3, 4, 5]
        ref = [[1, 2, 3], [4, 5]]

        # over list
        chunked = chunk_iterable(data, 3)
        self.compare_chunked_to_ref(chunked, ref)
        # over iterator
        chunked = chunk_iterable(iter(data), 3)
        self.compare_chunked_to_ref(chunked, ref)

        self.assertTrue(data == [1, 2, 3, 4, 5])

    # Tests with $iterlength are below

    def test_iterlength_must_limit(self):
        """check if $iterlength really limits the number of returned values"""
        data = [1, 2, 3, 4, 5, 6]
        ref = [[1, 2, 3], [4, 5]]

        # over list
        chunked = chunk_iterable(data, 3, 5)
        self.compare_chunked_to_ref(chunked, ref)
        # over iterator
        chunked = chunk_iterable(iter(data), 3, 5)
        self.compare_chunked_to_ref(chunked, ref)

        self.assertTrue(data == [1, 2, 3, 4, 5, 6])

        data = [1, 2]
        ref = [[1]]

        # over list
        chunked = chunk_iterable(data, 2, 1)
        self.compare_chunked_to_ref(chunked, ref)
        # over iterator
        chunked = chunk_iterable(iter(data), 2, 1)
        self.compare_chunked_to_ref(chunked, ref)

        self.assertTrue(data == [1, 2])

    def test_iterlength_is_zero(self):
        """check if $iterlength works if it is 0 """
        data = [1, 2, 3, 4, 5, 6]
        ref = []

        # over list
        chunked = chunk_iterable(data, 3, 0)
        self.compare_chunked_to_ref(chunked, ref)
        # over iterator
        chunked = chunk_iterable(iter(data), 3, 0)
        self.compare_chunked_to_ref(chunked, ref)

        self.assertTrue(data == [1, 2, 3, 4, 5, 6])

        # loops must not be entered
        for chunk in chunk_iterable([], 42):
            self.assertTrue(False)

    @unittest2.skipIf("linux" not in sys.platform, "Cannot run on non-Linux systems")
    def test_get_resident_memory(self):
        # allocate 200 meg
        m = 'x' * 200 * 1024 * 1024
        rss = get_resident_memory()
        self.assertGreater(rss, len(m))

    def test_process_local_basic_ops(self):
        ob = ProcessLocal()

        ob['foo'] = 1
        self.assertEqual(1, ob['foo'])
        self.assertEqual(['foo'], list(ob))
        self.assertEqual(1, len(ob))
        self.assertIn('foo', ob)

        del ob['foo']
        self.assertEqual({}, ob)

    def test_process_local_after_fork(self):
        ob = ProcessLocal()
        ob['foo'] = 1

        child_pid = os.getpid()

        def after_fork():
            # Don't use self.assert.. in another process.
            assert ob.get('foo', 'other') == 'other'
            ob['foo'] = 2

            ref = {
                child_pid: {'foo': 1},
                os.getpid(): {'foo': 2},
            }

            assert ref == ob._store

        p = multiprocessing.Process(target=after_fork)
        p.start()
        p.join()
        self.assertEqual(0, p.exitcode)


if __name__ == "__main__":
    unittest2.main()
