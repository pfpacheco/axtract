from .reconnect_helpers import build_call_op_with_reconnect
from .reconnect_helpers import build_yield_docs_with_reconnect
from bson.raw_bson import RawBSONDocument
from pymongo.read_preferences import ReadPreference


class ReconnectCollection(object):
    """This class 'wraps' a pymongo.Collection objects.

    Then it wraps often used methods so that a 'timeout' period after a failover
    is done.
    """

    __slots__ = ('coll', 'yield_docs', 'call_op')

    def __init__(self, coll, yield_docs, call_op):
        self.coll = coll
        self.yield_docs = yield_docs
        self.call_op = call_op

    @property
    def name(self):
        return self.coll.name

    @property
    def database(self):
        return self.coll.database

    @property
    def codec_options(self):
        return self.coll.codec_options

    def find(self, *args, **kwargs):
        # Keep in mind, this does NOT return a cursor object, just a generator.
        return self.yield_docs(self.coll.find, *args, **kwargs)

    def find_one(self, *args, **kwargs):
        return self.call_op(self.coll.find_one, *args, **kwargs)

    def count(self, *args, **kwargs):
        return self.call_op(self.coll.count, *args, **kwargs)

    def insert(self, *args, **kwargs):
        return self.call_op(self.coll.insert, *args, **kwargs)

    def insert_one(self, *args, **kwargs):
        return self.call_op(self.coll.insert_one, *args, **kwargs)

    def insert_many(self, *args, **kwargs):
        return self.call_op(self.coll.insert_many, *args, **kwargs)

    def update(self, *args, **kwargs):
        return self.call_op(self.coll.update, *args, **kwargs)

    def update_one(self, *args, **kwargs):
        return self.call_op(self.coll.update_one, *args, **kwargs)

    def update_many(self, *args, **kwargs):
        return self.call_op(self.coll.update_many, *args, **kwargs)

    def replace_one(self, *args, **kwargs):
        return self.call_op(self.coll.replace_one, *args, **kwargs)

    def remove(self, *args, **kwargs):
        return self.call_op(self.coll.remove, *args, **kwargs)

    def delete_one(self, *args, **kwargs):
        return self.call_op(self.coll.delete_one, *args, **kwargs)

    def delete_many(self, *args, **kwargs):
        return self.call_op(self.coll.delete_many, *args, **kwargs)

    def ensure_index(self, *args, **kwargs):
        return self.create_index(*args, **kwargs)

    def create_index(self, *args, **kwargs):
        return self.call_op(self.coll.create_index, *args, **kwargs)

    def drop(self, *args, **kwargs):
        return self.call_op(self.coll.drop, *args, **kwargs)

    def distinct(self, *args, **kwargs):
        return self.call_op(self.coll.distinct, *args, **kwargs)

    def group(self, *args, **kwargs):
        return self.call_op(self.coll.group, *args, **kwargs)

    def find_and_modify(self, *args, **kwargs):
        return self.call_op(self.coll.find_and_modify, *args, **kwargs)

    def find_one_and_update(self, *args, **kwargs):
        return self.call_op(self.coll.find_one_and_update, *args, **kwargs)

    def options(self):
        return self.call_op(self.coll.options)

    def with_options(self, *args, **kwargs):
        new_coll = self.coll.with_options(*args, **kwargs)
        return ReconnectCollection(new_coll, self.yield_docs, self.call_op)

    def aggregate(self, *args, **kwargs):
        return self.call_op(self.coll.aggregate, *args, **kwargs)

    def bulk_write(self, *args, **kwargs):
        return self.coll.bulk_write(*args, **kwargs)

    # Here are axiros extensions to the pymongo collection
    def gen_find_cursor(self, *args, **kwargs):
        return self.coll.find(*args, **kwargs)

    def count_by_crit(self, crit):
        return self.call_op(lambda: self.coll.find(crit).count())

    def as_raw_collection(self):
        codec_options = self.coll.codec_options
        codec_options = codec_options._replace(document_class=RawBSONDocument)
        return self.with_options(codec_options=codec_options)

    def with_read_preference(self, read_preference):
        if not read_preference:
            return self
        elif hasattr(ReadPreference, read_preference):
            return self.with_options(
                read_preference=getattr(ReadPreference, read_preference))
        else:
            raise Exception("Unknown ReadPreference: %s" % read_preference)

    # bulk operations
    def initialize_ordered_bulk_op(self):
        return self.coll.initialize_ordered_bulk_op()

    def initialize_unordered_bulk_op(self):
        return self.coll.initialize_unordered_bulk_op()


def gen_reconnect_collection(coll, *args, **kwargs):
    yield_docs = build_yield_docs_with_reconnect()
    call_op = build_call_op_with_reconnect()
    return ReconnectCollection(coll, yield_docs, call_op)


def build_reconnect_coll_factory(*args, **kwargs):
    yield_docs = build_yield_docs_with_reconnect()
    call_op = build_call_op_with_reconnect()

    def factory(coll):
        return ReconnectCollection(coll, yield_docs, call_op)

    return factory
