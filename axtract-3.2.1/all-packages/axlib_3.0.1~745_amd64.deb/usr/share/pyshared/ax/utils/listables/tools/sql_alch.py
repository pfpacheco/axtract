#!/usr/bin/env python
'''
# Tools Built on SQLAlchemy

'''
import sys
from fnmatch import fnmatch
from ax.utils.locking.tools import is_str

def l(*msg):
    print ' '.join([str(s) for s in msg])

def convert_schema(from_eng, to_eng, table_match='*', delete_first=False):
    '''
    # Converts a schema from one engine to another, using sqlalch.

    No data is migrated
    See [here](http://www.tylerlesmann.com/2009/apr/27/copying-databases-across-platforms-sqlalchemy/)
    on how this is done.

    # Parameters

    - from_eng, to_eng: urls accepted as well

    # Status: Prealpha
    - just used for an axess db conv, from mysql to sqllite
    - no cli, you have to invoke the function *somehow*

    '''
    import sqlalchemy as sa

    def type_conv_mysql_to_sqlite(sa, col):
        s = str(col.type)
        sl = sa.dialects.sqlite
        # first match rules:
        match = ( ( 'TINYINT'      , sl.SMALLINT )
                , ( 'SET'          , sl.VARCHAR  )
                , ( 'INT'          , sl.INTEGER  )
                )
        for mtch, typ in match:
            if mtch in s:
                col.type = typ()
                return


    ce = lambda *a: sa.create_engine(*a, echo=True)

    from_eng = ce(from_eng) if is_str(from_eng) else from_eng
    to_eng   = ce(to_eng)   if is_str(to_eng)   else to_eng
    insp = sa.inspect(from_eng)

    # choose a dialect specific type converter:
    conv = locals().get('type_conv_%s_to_%s' % (from_eng.dialect.name,
                                                to_eng.dialect.name))
    # e.g. mysql to ora does work as is:
    conv = lambda *a, **kw: None if conv is None else conv

    for tn in insp.get_table_names() + insp.get_view_names():
        if not fnmatch(tn, table_match):
            l('skipping', tn)
            continue
        l('converting', tn)
        from_meta = sa.MetaData(bind=from_eng)
        t = sa.Table(tn, from_meta, autoload=True)
        if delete_first:
            to_eng.execute('drop table if exists %s' % tn)
        [conv(sa, c) for c in t.columns]
        t.metadata.create_all(to_eng)



def populate_db(eng, listables, records=100):
    import pdb; pdb.set_trace()



if __name__ == '__main__':
    sys.path.insert(0, '/usr/lib64/python2.7/site-packages')
    convert_schema('mysql://admin:ax@127.0.0.1:3308/live',
                   'sqlite:///ax.db',
                   table_match='vss_*',
                   delete_first=True)



























