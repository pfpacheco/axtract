
IPDR_MESSAGE_TYPES = {
        'FLOW_START'               : 0x01,
        'FLOW_STOP'                : 0x03,
        'CONNECT'                  : 0x05,
        'CONNECT_RESPONSE'         : 0x06,
        'DISCONNECT'               : 0x07,
        'SESSION_START'            : 0x08,
        'SESSION_STOP'             : 0x09,
        'KEEP_ALIVE'               : 0x40,
        'TEMPLATE_DATA'            : 0x10,
        'MODIFY_TEMPLATE'          : 0x1a,
        'MODIFY_TEMPLATE_RESPONSE' : 0x1b,
        'FINAL_TEMPLATE_DATA_ACK'  : 0x13,
        'START_NEGOTIATION'        : 0x1d,
        'START_NEGOTIATION_REJECT' : 0x1e,
        'GET_SESSIONS'             : 0x14,
        'GET_SESSIONS_RESPONSE'    : 0x15,
        'GET_TEMPLATES'            : 0x16,
        'GET_TEMPLATES_RESPONSE'   : 0x17,
        'DATA'                     : 0x20,
        'DATA_ACK'                 : 0x21,
        'ERROR'                    : 0x23,
        'REQUEST'                  : 0x30,
        'RESPONSE'                 : 0x31
}

# according to TMFORUM spec
IPDR_BASIC_TYPES = {
        "int"                      : 0x00000021,
        "u_int"                    : 0x00000022,
        "long"                     : 0x00000023,
        "u_long"                   : 0x00000024,
        "float"                    : 0x00000025,
        "double"                   : 0x00000026,
        "hex_binary"               : 0x00000027,
        "string"                   : 0x00000028,
        "boolean"                  : 0x00000029,
        "byte"                     : 0x0000002a,
        "u_byte"                   : 0x0000002b,
        "short"                    : 0x0000002c,
        "u_short"                  : 0x0000002d,
        "ip_addr"                  : 0x00000827,
        "ipv4addr"                 : 0x00000322,
        "ipv6addr"                 : 0x00000427,
        "uuid"                     : 0x00000527,
        "date_time"                : 0x00000122,
        "date_time_msec"           : 0x00000224,
        "date_time_usec"           : 0x00000623,
        "mac_addr"                 : 0x00000723
}

def get_template_field_string_type_by_id(hex_id):
    for field_type, hex_number in IPDR_BASIC_TYPES.items():
        if hex_number == hex_id:
            return field_type
    return "unknown"
