import time
from ax.utils.tokenbucket import Tokenbucket
from ax.utils.lru import ExpiringLRUCache
from ax.utils.globalnumbers import GlobalNumbers, setup_global_numbers

class RatelimitBlacklist(object):
    """Manage blacklisting of (crazy) clients that send too many requests.

    Crazy clients occur when some kind of client (DHCP, TFTP...) has a buggy
    implementation and keeps making requests to the server. Usually, this
    happens for unprovisioned clients for which the server has no valid data
    it can give them (i.e. DHCP cannot assign address, TFTP cannot generate
    DOCSIS config file).
    Such clients can make hundreds of requests per second, so blocking them is
    important to maintain a decent performance. However, unblocking must happen
    periodically and automatically because such devices may get provisioned at
    any time.
    Blacklisting is not designed for security purposes: Under certain
    conditions, the ExpiringLRUCache can forget a blacklisted client. However,
    if the items_cache is big enough this happens very rarely, so that the aim
    of restricting crazy clients is still achieved.

    Note that the blacklist differentiates between "item" and "itemid". In the
    default case, these are identical. However, "item" could be e.g. a DHCP
    request object, "itemid" could be the MAC of the device that sent the
    request. Or "item" could be a TFTP request object and "itemid" is the IP
    address of the client making the request. This provides a better seperation
    of concerns, because the user of the Blacklist does not need to know
    how individuals are differentiated.
    """
    def __init__(self, max_items=10000, track_duration=900, block_duration=900,
            allowed_rate=0.5, allowed_burst=3, globnum=None, **kwargs):
        # This defines of how many items we keep track of and how long we
        # track them at least. If an item was not blacklisted after this time,
        # it will be forgotten. If it gets blacklisted, block_itemid() will
        # ensure it stays in the cache for the entire blacklist duration.
        self.max_items = max_items
        self.track_duration = track_duration

        # The cache is a
        #   itemid -> cache_entry
        # mapping with cache entries that are tuples like this:
        #   (tokenbucket, block_start, block_stop)
        # The block_* variables are 0 for items that are not blocked or UNIX
        # time stamps of the start and stop of the blocking. If the block_stop
        # is nonzero and in the past, it means that the item was blocked before.
        self.items_cache = ExpiringLRUCache(self.max_items, self.track_duration)

        # How fast we allow items to bother us. These will become parameters for
        # a Tokenbucket.
        self.allowed_rate = allowed_rate
        self.allowed_burst = allowed_burst

        # For how long we block an item by default. Can be longer than
        # self.track_duration, self.block_itemid() handles this case.
        self.block_duration = block_duration

        # The GlobalNumbers object we use for statistics, or the pathname of
        # the registry file we should use. If the value is None, the
        # setup_global_numbers will give us a FakeGlobalNumbers object, which
        # is OK.
        if isinstance(globnum, GlobalNumbers):
            self.globnum = globnum
        else:
            # Treat globnum as a filename to use for the registry.
            # "total_blacklisted": How often (in total) items were newly(!)
            #       blacklisted.
            # "total_counted": How often self.count() has counted, EXcluding
            #       count() calls for items that are already blacklisted.
            self.globnum = setup_global_numbers(globnum,
                    ensure_ulong=("total_blacklisted", "total_counted"))

        self.open_external_connections()
        self.load_from_external()


    # Core functionality that is not usually customized.
    def block(self, item, duration=None):
        """Blacklist the given item in any case"""
        self.block_itemid(self.item_to_itemid(item), duration=duration)

    def block_itemid(self, itemid, duration=None):
        """Blacklist the given itemid in any case

        If duration is given, the itemid is blocked for that many seconds.
        Otherwise, self.get_block_duration() is called
        """
        if duration is None:
            duration = self.get_block_duration(itemid)

        old_blacklist_entry = self.get_itemid(itemid)

        duration = duration
        now = time.time()
        blacklist_entry = (self.get_tokenbucket(itemid), now, now + duration)
        # Entry must be valid at least as long as it is blacklisted.
        timeout = max(self.get_track_duration(itemid), duration)
        self.items_cache.put(itemid, blacklist_entry, timeout=timeout)

        already_blacklisted = False
        if old_blacklist_entry is not None:
            # Check if the entry was already blacklisted
            if old_blacklist_entry[2] > now:
                already_blacklisted = True
        if already_blacklisted:
            self.update_blocked(itemid, duration)
        else:
            self.notify_blocked(itemid, duration)
            self.globnum.increment("total_blacklisted", 1)

    def unblock(self, item):
        """Remove given item from blacklist"""
        self.unblock_itemid(self.item_to_itemid(item))

    def unblock_itemid(self, itemid):
        """Remove given itemid from blacklist"""
        was_blocked = self.is_blocked_itemid(itemid)
        self.items_cache.invalidate(itemid)
        if was_blocked:
            self.notify_explicit_unblock(itemid)

    def is_blocked(self, item):
        """Return True if the item is blacklisted, else False"""
        return self.is_blocked_itemid(self.item_to_itemid(item))

    def is_blocked_itemid(self, itemid):
        """Return True if the itemid is blacklisted, else False"""
        entry = self.get_itemid(itemid)
        if entry is None:
            return False
        blocked_until = entry[2]
        return blocked_until >= time.time()

    def get(self, item):
        """Return cache entry for item if it is in the cache, else None

        Getting an item here only means we are tracking it, not that it is
        blacklisted.
        """
        return self.get_itemid(self.item_to_itemid(item))


    # Core functionality intended for customization.
    def get_itemid(self, itemid):
        """Return cache entry for itemid if in cache, else None.

        Custom classes that use external databases may want to consult their
        database at this point.
        """
        return self.items_cache.get(itemid)

    def item_to_itemid(self, item):
        """Customization point if items need a conversion to get the itemid

        For example, the "item" could be a DHCP packet object, the itemid could
        be the MAC address of the device that sent the request. This way the
        caller does not need to know exactly how the blacklist identifies
        individual entities.
        """
        return item

    def count(self, item):
        """To be called when the given item should be counted.

        Usually, counting is done when a client makes some kind of request to
        a server. This counting can result in the item being blacklisted if we
        think it occurs too often. However, this method can also decide not to
        count, e.g. it may skip certain request types.
        """
        return self.count_itemid(self.item_to_itemid(item))

    def count_itemid(self, itemid):
        existing_entry = self.get_itemid(itemid)
        if existing_entry is None:
            # Create new entry for this itemid. Prefill with one less token
            # than burst size to account for the token that we use now.
            tokenbucket = self.get_tokenbucket(itemid)
            new_entry = (tokenbucket, 0, 0)
            track_duration = self.get_track_duration(itemid)
            self.items_cache.put(itemid, new_entry, timeout=track_duration)
        else:
            if existing_entry[2] > time.time():
                # The item is currently blocked, anyway. Do not prolong
                # its blocking so that it will eventually be unblocked. This
                # has the same effect as if you do not count() for blocked
                # items, which is probably what many people will do, anyway.
                return
            # Try to take a token from the itemid's tokenbucket.
            tokenbucket = existing_entry[0]
            if not tokenbucket.try_take_tokens(1):
                # No token available -> blacklist it.
                self.block_itemid(itemid)
        # Do not count for items that were already blacklisted when we came
        # here. For such items, we will "return" above.
        self.globnum.increment("total_counted", 1)


    def get_tokenbucket(self, itemid):
        """Get a Tokenbucket instance for the given itemid.

        You can customize this if you think that certain itemids should get
        bigger/smaller token buckets than the default.
        """
        # Prefill with one less token than burst size to account for the token
        # that we use now (this method is likely called from self.count()).
        return Tokenbucket(self.allowed_burst, self.allowed_rate,
                prefill=self.allowed_burst - 1)

    def get_block_duration(self, itemid):
        """Return the amount of seconds that the itemid should be blocked

        You can customize here if certain itemids should get blocked for a
        non-default duration.
        """
        return self.block_duration

    def get_track_duration(self, itemid):
        """Return the amount of seconds we should keep track of this item

        Note that blacklisted items will be tracked at least as long as they
        are blacklisted.
        """
        return self.track_duration

    def notify_blocked(self, itemid, duration):
        """Called when itemid is newly blacklisted.

        This gives you the possibility to inform others that this device,
        customer, IP address, or whatever was blacklisted.
        It is also a good place to write to external databases if you wish.
        """
        pass

    def update_blocked(self, itemid, duration):
        """Called when blacklisting of itemid is extended.

        Similar to notify_blacklisted, you can notify whoever is interested.
        This method is only called upon explicit extension of blacklisting. If
        a blacklisted item is simply counted, this method is not called.
        """
        pass

    def notify_explicit_unblock(self, itemid):
        """Called when a blacklisted itemid was explicitly unblocked.

        This method will not be called upon implicit unblocking (e.g. blacklist
        duration exceeded).
        """
        pass


    # Extension points you can use if you want to read/write blacklist infos
    # from/to some external storage.
    def open_external_connections(self):
        """Will be called by __init__"""
        pass

    def close_external_connections(self):
        """Close connections that were opened by open_external_connections().

        This must be called by the user of the RatelimitBlacklist object if he
        wishes a clean 'shutdown' of the object.
        """
        pass

    def load_from_external(self):
        """Reads in ALL data from external data source(s).

        Called when object is instantiated and potentially also later on to
        keep in sync with your data source(s).
        """
        pass

    def load_item_from_external(self, item):
        """Update data for a SINGLE item from external data source(s)."""
        self.load_itemid_from_external(self.item_to_itemid(item))

    def load_itemid_from_external(self, item):
        """Update data for a SINGLE itemid from external data source(s)."""
        pass

    def write_to_external(self):
        """Write in ALL data to external data source(s)."""
        pass

    def write_item_to_external(self, item):
        """Update data for a SINGLE item in external data source(s)."""
        self.load_itemid_from_external(self.item_to_itemid(item))

    def write_itemid_from_external(self, item):
        """Update data for a SINGLE itemid in external data source(s)."""
        pass
