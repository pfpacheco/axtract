import time
import threading
import unittest2
from ax.utils.locking.mongo_lock import LockManager
from ax.utils.locking.mongo_lock import MongoLock

try:
    import pymongo
    import pymongo.errors
    client = pymongo.MongoClient(
        "127.0.0.1",
        27017,
        serverSelectionTimeoutMS=5000)
    client.admin.command('ismaster')
except ImportError:
    mongo_running = False
except pymongo.errors.AutoReconnect:
    mongo_running = False
except pymongo.errors.ConnectionFailure:
    mongo_running = False
else:
    mongo_running = True


@unittest2.skipIf(not mongo_running, "There is no mongo server running")
class TestLockManager(unittest2.TestCase):
    def setUp(self):
        self.manager = LockManager('127.0.0.1', 27017 , 'lock_db', 'lock_coll')
        self.manager.db[self.manager.coll_name].delete_many({})

    def tearDown(self):
        self.manager.db[self.manager.coll_name].delete_many({})

    def test_simple(self):
        with self.manager('cpeid1'):
            pass

        with self.manager('cpeid1'):
            pass

    def test_with_threads(self):
        m1 = LockManager('127.0.0.1', 27017 , 'lock_db', 'lock_coll')
        m2 = LockManager('127.0.0.1', 27017 , 'lock_db', 'lock_coll')
        m3 = LockManager('127.0.0.1', 27017 , 'lock_db', 'lock_coll')

        res = []
        def do_something(me, manager):
            with manager('cpeid'):
                time.sleep(3.1)
                res.append((me, time.time()))

        t1 = threading.Thread(target=do_something, args=('t1', m1))
        t1.start()
        time.sleep(0.5)
        t2 = threading.Thread(target=do_something, args=('t2',m2))
        t2.start()
        time.sleep(0.5)
        t3 = threading.Thread(target=do_something, args=('t3',m3))
        t3.start()

        t1.join()
        t2.join()
        t3.join()
        self.assertGreater(res[1][1] - res[0][1], 3)
        self.assertGreater(res[2][1] - res[1][1], 3)

    def test_w_lifetime(self):
        db = pymongo.MongoClient('127.0.0.1', 27017)['lock_db']
        coll = db.lock_coll
        m1 = MongoLock(coll, 'cpeid2', 1)
        m1.__enter__()
        m1.__enter__()
