from pyparsing import Word
from pyparsing import nums
from pyparsing import StringEnd
from pyparsing import Optional
from pyparsing import CaselessLiteral
from pyparsing import Or
from pyparsing import OneOrMore
from pyparsing import Combine
from pyparsing import Literal


def parse(bytes_string):
    result = PARSER.parseString(bytes_string)
    return result[0]


def _gen_parser():
    dot = Literal('.')
    number = Word(nums)

    fraction = dot + number
    float_nb = Or([number, Optional(number) + fraction, number + dot])
    float_nb = Combine(float_nb)

    _bytes = number + Optional(CaselessLiteral('b'))
    _bytes.setParseAction(lambda tokens: int(tokens[0]))

    _kbytes = float_nb + Or([CaselessLiteral('kb'), CaselessLiteral('k')])
    _kbytes.setParseAction(lambda tokens: float(tokens[0]) * 1024)

    _mbytes = float_nb + Or([CaselessLiteral('mb'), CaselessLiteral('m')])
    _mbytes.setParseAction(lambda tokens: float(tokens[0]) * pow(1024, 2))

    _gbytes = float_nb + Or([CaselessLiteral('gb'), CaselessLiteral('g')])
    _gbytes.setParseAction(lambda tokens: float(tokens[0]) * pow(1024, 3))

    exp = OneOrMore(Or([_bytes, _kbytes, _mbytes, _gbytes]))
    exp.setParseAction(lambda tokens: int(sum(tokens)))

    return exp + StringEnd()

PARSER = _gen_parser()
