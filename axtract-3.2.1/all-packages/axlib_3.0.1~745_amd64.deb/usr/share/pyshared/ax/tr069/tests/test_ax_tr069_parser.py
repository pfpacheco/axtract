from ax.tr069.ax_tr069_parser import AXTR069PropertiesParser
import unittest2

buildId = AXTR069PropertiesParser.buildId


class AXTR069PropertiesParserTest(unittest2.TestCase):
    def test_parse_xml_string(self):
        s = """<?xml version="1.0"?>
               <InternetGatewayDevice id="1" islist="false">
                   <OldNode unit="Kcal/mol" short="I.myshort"/>
               </InternetGatewayDevice>"""

        res = {
            'InternetGatewayDevice': {
                'tr69': 'InternetGatewayDevice',
                'short69': 'I',
                'file': '',
                'id': '1',
            },
            'InternetGatewayDevice.OldNode': {
                'tr69': 'InternetGatewayDevice.OldNode',
                'short69': 'I.myshort',
                'file': '',
                'unit': 'Unit: Kcal/mol',
            }
        }

        self.maxDiff = None
        TR069Props = AXTR069PropertiesParser()
        TR069Props.parse_xml_string(s)
        TR69 = TR069Props.get_tr069_props()
        self.assertTrue(isinstance(TR69['InternetGatewayDevice'], dict))
        a = TR69['InternetGatewayDevice']
        b = res['InternetGatewayDevice']
        self.assertEqual(a['tr69'], b['tr69'])
        self.assertEqual(a['short69'], b['short69'])
        self.assertEqual(a['file'], b['file'])
        self.assertEqual(a['id'], b['id'])

        a = TR69['InternetGatewayDevice.OldNode']
        b = res['InternetGatewayDevice.OldNode']
        self.assertEqual(a['tr69'], b['tr69'])
        self.assertEqual(a['short69'], b['short69'])
        self.assertEqual(a['file'], b['file'])
        self.assertEqual(a['unit'], b['unit'])

    def test_lowercase_parameternames(self):
        s = """<?xml version="1.0"?>
<InternetGatewayDevice id="1" islist="false">
    <X_TELSEY_COM_SWITCH islist="false">
        <vlanCfgEntry islist="true">
            <vidCfgEntry islist="true">
                <vid type="string"/>
            </vidCfgEntry>
        </vlanCfgEntry>
    </X_TELSEY_COM_SWITCH>
</InternetGatewayDevice>
"""

        TR069Props = AXTR069PropertiesParser(False)
        TR069Props.parse_xml_string(s)

    def test_strict_parse_xml_string(self):
        s = """<?xml version="1.0"?>
               <InternetGatewayDevice id="1" islist="false">
                   <OldNode unit="Kcal/mol" short="I.myshort"/>
                   <OldNode2 unit="Kcal/mol" short="I.myshort"/>
               </InternetGatewayDevice>"""

        TR069Props = AXTR069PropertiesParser(True)
        with self.assertRaises(Exception):
            TR069Props.parse_xml_string(s)

        TR069Props = AXTR069PropertiesParser(False)
        TR069Props.parse_xml_string(s)

        s = """<?xml version="1.0"?>
               <InternetGatewayDevice id="1" islist="false">
                   <OldNode unit="Kcal/mol"/>
                   <OldNode2 unit="Kcal/mol" short="I.ON"/>
               </InternetGatewayDevice>"""

        TR069Props = AXTR069PropertiesParser(True)

        with self.assertRaises(Exception):
            TR069Props.parse_xml_string(s)

        TR069Props = AXTR069PropertiesParser(False)
        TR069Props.parse_xml_string(s)

    def test_shortname_generation(self):
        s = """<?xml version="1.0"?>
               <InternetGatewayDevice id="1" islist="false">
                 <SmartMeterMgmt>
                   <Sml>
                     <FirstName TR_description="8181C78205FF"/>
                     <FamilyName TR_description="8181C78206FF"/>
                   </Sml>
                 </SmartMeterMgmt>
               </InternetGatewayDevice>"""

        TR069Props = AXTR069PropertiesParser(True)
        TR069Props.parse_xml_string(s)

        TR069 = TR069Props.get_tr069_props()
        a = TR069['InternetGatewayDevice.SmartMeterMgmt.Sml.FirstName']['short69']
        b = TR069['InternetGatewayDevice.SmartMeterMgmt.Sml.FamilyName']['short69']

        self.assertEqual(a, "I.SMM.S.FN")
        self.assertEqual(b, "I.SMM.S.FaN")

    def test_build_id(self):
        # taken 1:1 from the production code:
        assert buildId("GafdPadPasda") == "GPP"
        assert buildId("cGafdPadABCc") == "GPAC"
        assert buildId("SIP") == "S"
        assert buildId("SIP", 1) == "SI"
        assert buildId("SIP", 2) == "SIP"
        assert buildId("SIP", 3) == "SIP1"

        ret = buildId(
            "X_AVM-DE_VendorUnsupportedModifications",
            conv_map={'X_AVM-DE': 'XAvm'})
        assert ret == "XAvmVUM"

        ret = buildId(
            "X_AVM-DE_g726_via_rfc3551_supported",
            conv_map={'X_AVM-DE': 'XAvm'})
        assert ret == "XAvmgvr3s"

    def test_parsing(self):
        LEAF_ATTRS = [
            'type',
            'size',
            'default',
            'TR_description',
            'islist',
            'id',
            'write',
            'typeLength',
            'emptyfromcpe',
            'unit'
        ]

        s = """<?xml version="1.0"?>
               <InternetGatewayDevice id="1" islist="false">
                   <OldNode unit="Kcal/mol" short="I.myshort"/>
               </InternetGatewayDevice>"""

        TR069Props = AXTR069PropertiesParser()
        TR069Props.parse_xml_string(s)
        TR069 = TR069Props.get_tr069_props()
        root = TR069['InternetGatewayDevice']
        for attr in LEAF_ATTRS:
            root[attr]

    def test_bogus_list_attribute(self):
        s = """<?xml version="1.0"?>
               <InternetGatewayDevice id="1" islist="foo">
                   <OldNode unit="Kcal/mol" short="I.myshort"/>
               </InternetGatewayDevice>"""

        TR069Props = AXTR069PropertiesParser(True)
        with self.assertRaises(ValueError):
            TR069Props.parse_xml_string(s)

    def test_colliding_trees(self):
        xml1 = """
            <InternetGatewayDevice>
                <WanDevice>
                    <Status></Status>
                </WanDevice>
            </InternetGatewayDevice>"""

        # I know WanDirectory does not exists, just a example of a LongParameter
        # in *another* xml file mapping to the same shortname per default
        xml2 = """
            <InternetGatewayDevice>
                <WanDirectory>
                    <Status></Status>
                </WanDirectory>
            </InternetGatewayDevice>"""

        props = AXTR069PropertiesParser()
        props.parse_xml_string(xml1)
        props.parse_xml_string(xml2)

        ref_short_to_long = {
            'I': 'InternetGatewayDevice',
            'I.WD': 'InternetGatewayDevice.WanDevice',
            'I.WD.S': 'InternetGatewayDevice.WanDevice.Status',
            'I.WaD': 'InternetGatewayDevice.WanDirectory',
            'I.WaD.S': 'InternetGatewayDevice.WanDirectory.Status',
        }

        ref_long_to_short = {}
        for key, value in ref_short_to_long.items():
            ref_long_to_short[value] = key

        short_to_long = {}
        for key, value in props.get_short_tr069_props().items():
            short_to_long[key] = value.get_full_name()
        self.assertEqual(ref_short_to_long, short_to_long)

        long_to_short = {}
        for key, value in props.get_tr069_props().items():
            long_to_short[key] = value.get_full_shortname()
        self.assertEqual(ref_long_to_short, long_to_short)

    def test_colliding_list_trees(self):
        xml1 = """
            <InternetGatewayDevice>
                <Services>
                    <STBService islist="true">
                        <Enable></Enable>
                    </STBService>
                </Services>
            </InternetGatewayDevice>
        """

        xml2 = """
            <InternetGatewayDevice>
                <Services>
                    <StorageService islist="true">
                        <Enable></Enable>
                    </StorageService>
                </Services>
            </InternetGatewayDevice>
        """

        props = AXTR069PropertiesParser()
        props.parse_xml_string(xml1)
        props.parse_xml_string(xml2)

        props_dict = props.get_tr069_props()
        v1 = props_dict['InternetGatewayDevice.Services.StorageService.x']
        v1 = v1.get_shortname()
        v2 = props_dict['InternetGatewayDevice.Services.STBService.x']
        v2 = v2.get_shortname()

        self.assertNotEqual(v1, v2)

    def test_colliding_leafs_by_double_def(self):
        xml1 = """
            <InternetGatewayDevice>
                <WLANConfiguration islist="true">
                    <SSID></SSID>
                </WLANConfiguration>
            </InternetGatewayDevice>"""

        xml2 = """
            <InternetGatewayDevice>
                <WLANConfiguration islist="true">
                    <Status></Status>
                    <SSID></SSID>
                </WLANConfiguration>
            </InternetGatewayDevice>"""

        props = AXTR069PropertiesParser()
        props.parse_xml_string(xml1)
        props.parse_xml_string(xml2)


        ref_short_to_long = {
            'I': 'InternetGatewayDevice',
            'I.WC.x': 'InternetGatewayDevice.WLANConfiguration.x',
            'I.WC.x.S': 'InternetGatewayDevice.WLANConfiguration.x.SSID',
            'I.WC.x.St': 'InternetGatewayDevice.WLANConfiguration.x.Status'
        }

        ref_long_to_short = {}
        for key, value in ref_short_to_long.items():
            ref_long_to_short[value] = key

        short_to_long = {}
        for key, value in props.get_short_tr069_props().items():
            short_to_long[key] = value.get_full_name()
        self.assertEqual(ref_short_to_long, short_to_long)

        long_to_short = {}
        for key, value in props.get_tr069_props().items():
            long_to_short[key] = value.get_full_shortname()
        self.assertEqual(ref_long_to_short, long_to_short)


    def test_colliding_leafs_by_double_def2(self):
        xml1 = """
            <InternetGatewayDevice>
                <WLANConfiguration islist="true">
                    <Status></Status>
                    <SSID></SSID>
                </WLANConfiguration>
            </InternetGatewayDevice>"""

        xml2 = """
            <InternetGatewayDevice>
                <WLANConfiguration islist="true">
                    <SSID></SSID>
                </WLANConfiguration>
            </InternetGatewayDevice>"""


        props = AXTR069PropertiesParser()
        props.parse_xml_string(xml1)
        props.parse_xml_string(xml2)


        # Simulate the behaviour of the GUI
        ret = {}
        for key, value in props.get_short_tr069_props().items():
            ret[key] = value['short69']

        ref = {
            'I': 'I',
            'I.WC.x.S': 'I.WC.x.S',
            'I.WC.x.SS': 'I.WC.x.SS',
            'I.WC.x': 'I.WC.x'
        }

        self.assertEqual(ref, ret)
