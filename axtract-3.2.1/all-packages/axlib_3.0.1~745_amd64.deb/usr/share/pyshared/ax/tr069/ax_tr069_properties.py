"""
Implementation of TR-069 tree nodes for storage of TR-069 parameter
information.
"""


class AXTR069Node(dict):
    def __init__(self, name):
        self._name = name
        self._shortname = ""
        self._childs = []
        self._parent = None

    def __getitem__(self, key):
        return self.get(key, self.__missing__(key))

    def __missing__(self, key):
        if key == 'short69': return self.get_full_shortname()
        elif key == 'tr69': return self.get_full_name()
        elif key == 'typeLength': return None
        elif key == 'default': return None
        elif key == 'readOnly': return self["write"] in ["", "-"]
        elif key == 'TR_description': return None
        elif key == 'write': return None
        elif key == 'emptyfromcpe': return None
        elif key == 'islist': return isinstance(self, AXTR069ListNode)
        elif key == 'type': return 'string'
        elif key == 'id': return '1'
        elif key == 'unit': return None
        elif key == 'size': return 20
        elif key == 'isNode': return self.has_childs()
        elif key == 'file': return ""

        raise KeyError("%s" % str(key))

    def to_dict(self):
        """
        Create an old-style dictionary with all keys.
        """
        attrs = [
            'short69',
            'tr69',
            'typeLength',
            'default',
            'readOnly',
            'TR_description',
            'write',
            'emptyfromcpe',
            'islist',
            'type',
            'id',
            'unit',
            'size',
            'isNode',
            'file'
        ]
        ret = dict()
        for a in attrs:
            ret[a] = self[a]

        return ret

    def add_child(self, node):
        if not isinstance(node, AXTR069Node):
            raise ValueError("Child must be of type AXTR069Node")

        self._childs.append(node)
        node._parent = self

    def get_name(self):
        return self._name

    def get_native_name(self):
        return self._name

    def get_native_shortname(self):
        return self._shortname

    def set_shortname(self, shortname):
        if '.' in shortname:
            raise Exception('There must not be a "." within a shortname when using set_shortname().')
        self._shortname = shortname

    def set_full_shortname(self, shortname, auto_parent=0):
        parent = self.get_parent()
        if isinstance(parent, AXTR069Node):
            parent_full_shortname = parent.get_full_shortname()
            if not shortname.startswith(parent_full_shortname):
                if auto_parent:
                    shortname = parent_full_shortname + shortname
                else:
                    raise ValueError(
                        "Short name for node '%s' needs to begin with the same"
                        " short name as its parent which is '%s'"
                        % (self.get_full_name(), parent.get_full_shortname()))

            # We only store this nodes' partial shortname
            shortname = shortname.replace("%s." % parent_full_shortname, "")
            if shortname.endswith('.x'):
                shortname = shortname[:-2]
            self._shortname = shortname
        else:
            # If this is a root node (== no parent) there are no dots allowed
            # in the name
            if "." in shortname:
                raise ValueError(
                    "Root node '%s' is not allowed to have a '.'"
                    "in its short name" % self.get_full_name())
            else:
                self._shortname = shortname

    def get_shortname(self):
        return self._shortname

    def get_full_shortname(self):
        parent = self.get_parent()
        if isinstance(parent, AXTR069Node):
            return ".".join((parent.get_full_shortname(), self.get_shortname()))
        else:
            return self.get_shortname()

    def get_full_name(self):
        parent = self.get_parent()
        if isinstance(parent, AXTR069Node):
            return ".".join((parent.get_full_name(), self.get_name()))
        else:
            return self.get_name()

    def get_parent(self):
        return self._parent

    def has_childs(self):
        if self.get_direct_childs():
            return True
        return False

    def get_direct_childs(self):
        return self._childs

    def get_childs_tree(self):
        t = [self]
        for c in self.get_direct_childs():
            t = t + c.get_childs_tree()

        return t

    def __eq__(self, other):
        if not isinstance(other, AXTR069Node):
            return NotImplemented

        if self._name == other._name:
            return self._parent == other._parent

    def __ne__(self, other):
        if not isinstance(other, AXTR069Node):
            return NotImplemented

        return not self.__eq__(other)

    def __nonzero__(self):
        """
        Our nodes always have a meaning, so booleanisation should yield True
        """
        return True

    # Py2/Py3 compatibility
    __bool__ = __nonzero__

    def __repr__(self):
        return "AXTR069Node for '%s'" % self.get_full_name()


class AXTR069ListNode(AXTR069Node):
    def get_name(self):
        return self._name + ".x"

    def get_shortname(self):
        return self._shortname + ".x"

    def __repr__(self):
        return "AXTR069ListNode for '%s'" % self.get_full_name()
