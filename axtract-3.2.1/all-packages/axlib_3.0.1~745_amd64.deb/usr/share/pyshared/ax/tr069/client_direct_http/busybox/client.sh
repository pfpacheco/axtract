#!/bin/sh
echo "client starting"
ACS_HOST="82.94.204.22"
ACS_PORT="9673"
# Convert an ASCII file for transport over HTTP GET. 
# Result will replace the original file.
# % since we do map substitution on this string.
cleanup() {
  # URL-encode some special character.OC
  [ -e "$1" ] || return
  sed -i 's/\ /%20/g' "$1"
  sed -i 's/!/%21/g' "$1"
  sed -i 's/"/%22/g' "$1"
  sed -i 's/#/%23/g' "$1"
  sed -i 's/\$/%24/g' "$1"
  sed -i 's/%/%25/g' "$1"
  sed -i 's/&/%26/g' "$1"
  sed -i "s/'/%27/g" "$1"
  sed -i 's/;/%3b/g' "$1"
  sed -i 's/`/%60/g' "$1"
  sed -i 's/{/%7b/g' "$1"
  sed -i 's/|/%7c/g' "$1"
  sed -i 's/}/%7d/g' "$1"
  for line in `cat $1`; do
    echo -n "
$line" >> /tmp/axiros_tmp
  done
  mv /tmp/axiros_tmp "$1"
}
  
cd /tmp
serial=`ifconfig |grep eth0 |  tr -s ' ' | cut -d' ' -f5`
# send initial inform
wget -q -O /tmp/serverjob "http://${ACS_HOST}:${ACS_PORT}/live/Custom/SB/rc_receiver?step=0&serial=${serial}&last_result="


# Debug stuff, remove for production
echo "return code of initial inform: $?"
ls -al /tmp/serverjob


# Keep talking to server as long as it has new jobs
step=1
while grep '# newjob' /tmp/serverjob; do

    # Debug stuff, remove for production
    echo "jobdata:"
    cat /tmp/serverjob


    . /tmp/serverjob > /tmp/jobresult
    rm /tmp/serverjob
    cleanup "/tmp/jobresult"
    output="$(cat /tmp/jobresult)"
    rm /tmp/jobresult
    wget -q -O /tmp/serverjob "http://${ACS_HOST}:${ACS_PORT}/live/Custom/SB/rc_receiver?step=${step}&serial=${serial}&last_result=${output}"
done

