#include "Python.h"
#include "structmember.h"
#include "compat.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>

/* module documentation */
PyDoc_STRVAR(globalnumbers_doc,
"The intention of this module is to save 'counter' like numbers system wide.\n"
"The current values of these counters alone make NO sense and can be seen as\n"
"arbitrary. The only meaningful thing you can get is the delta of two counters\n"
"between points in time. For example at 12:00 counter X is 11042 and at\n"
"12:05 it is 11360. So you know within 5 minutes the counter increased by 318.\n"
"Each counter is identified by a name choosable from the user/application of the\n"
"GlobalNumbers object. This name is used to identify the counter system wide.\n"
"So if you have different processes which use the SAME name for a counter,\n"
"they see the same number. To synchronize the different processes you need a\n"
"filename. => FILENAME+COUNTERNAME = Same counter for all processes.\n"
"All operations on GlobalNumbers (add, get) are atomic operations!\n"
"GlobalNumers supports different kind of 'numbers-types'\n"
" - INT_TYPE : 32-bit signed number\n"
" - UINT_TYPE: 32-bit unsigned number\n"
" - LONG_TYPE : 64-bit signed number\n"
" - ULONG_TYPE : 64-bit unsigned number\n"
" - FLOAT_TYPE : 64-bit fixed point (NOT floating point!) number. Precision\n"
"                of 5 decimals, valid range from -2**47 to +2**47-1.\n"

"If you increment a counter, currently not kown by the registry, the counter\n"
"is added automaticly into the registry.\n"

"Implemenation notes:\n"
"Shared memory is used to store the current values of all counters. It is\n"
"difficult to resize shared memory 'on the fly' => there is a maximum limit of\n"
"usable counters. The size of the shared memory is chosen big enough so this\n"
"limit should not matter.\n"

"This shared memory is an array of bytes and the GlobalNumers-object takes care\n"
"which parts of the array belong to a different counter.\n"

"All known counters are saved in a file called 'registry'. This registry\n"
"stores the\n"
" - Name of a counter\n"
" - offset of a counter. This offset is a number of 'bytes' from the beginning\n"
"  of the shared memory segment. At this byte-position the counter value\n"
"  starts.\n"
" - type of a counter. For example to know if it is a FLOAT_TYPE or UINT_TYPE\n"
"   This knowledge is needed for\n"
"     1) Calculating the next offset\n"
"     2) __sync_fetch_and_add needs the type of the counter.\n"

"- SNMP-type: Currently unused, can be changed by the user to make the life of\n"
"  SNMP-Agents easier\n"
"Atomic access to this 'registry' file is provided by a system wide semaphore\n"
);

/* This module was originally tested under python2.6.
 * In python2.4 the Py_ssize_t type does not exists,
 * see http://www.python.org/dev/peps/pep-0353/ for more details
 * The following snippet is taken from the PEP to backport Py_ssize_t
 */
#if PY_VERSION_HEX < 0x02050000 && !defined(PY_SSIZE_T_MIN)
typedef int Py_ssize_t;
#define PY_SSIZE_T_MAX INT_MAX
#define PY_SSIZE_T_MIN INT_MIN
#endif


/*
 * the initial value of the semaphore is 1 => lock will set the value to 0 and a
 * additional lock will block.
 */
#define SEMAPHORE_LOCK -1
#define SEMAPHORE_UNLOCK 1

/* Store float internally as long long, the original value will be multiplied by
 * this value. To get the original value back the 'long long' is divided by this
 * value.
 */
#define FLOAT_PRECISION 100000

/*
 * Constants for supported internal types
 * The number here MUST correspond to the place inside the
 * INTERNAL_TYPE_AS_STRING array. Otherwise the function
 * convert_pretty_name_to_constant gets a problem !!
 */
#define INT_TYPE 0
#define UINT_TYPE 1
#define LONG_TYPE 2
#define ULONG_TYPE 3
#define FLOAT_TYPE 4
#define NO_TYPE 5

/* Inside the registry file we would like 'pretty names for internal types */
static const char * INTERNAL_TYPE_AS_STRING[] = {
    "INT_TYPE",
    "UINT_TYPE",
    "LONG_TYPE",
    "ULONG_TYPE",
    "FLOAT_TYPE",
    "NO_TYPE",
    /* sentinel for searching */
    NULL
};

/*
 * Index constants of the values inside the tuple of the registry dict.
 */
#define SNMP_TYPE_INDEX 0
#define INTERNAL_TYPE_INDEX 1
#define OFFSET_INDEX 2

/*
 * Macros to get the C-types from the Python Tuple of the registry dict
 */
#define GET_OFFSET(value) PyInt_AsLong(PyTuple_GetItem( (value), OFFSET_INDEX))
#define GET_INTERNAL_TYPE(value) PyInt_AsLong(PyTuple_GetItem( (value), INTERNAL_TYPE_INDEX))
#define GET_SNMP_TYPE(value) PyStr_AsString(PyTuple_GetItem( (value), SNMP_TYPE_INDEX))

/*
 * fscanf needs preallocated buffers => limit the size of a namespace
 */
#define MAX_NAMESPACE_SIZE 1024
#define REG_READ_FORMAT "%1024s%31s%31s%i"

/* Defines the minium size of the shared memory segment.
 * 512 => 512 / 8 => 64 counters.
 */
#define SHM_MIN_SIZE 512

/* Saftey net in case of ridiculous big segments.
 * Currently my defintion of 'ridiculous' is 1GB => 134.000.000 counters
 */
#define SHM_MAX_SIZE 1073741824

/* Default size of the of the shared memory segment.
 * 1MB is up to 130k counters.
 */
#define SHM_DEFAULT_SIZE 1048576

/* This macro is used by the various increment_* calls to save lines of code */
#define ATOMIC_ADD(type, numbers, offset, raw_to_add) ( \
        __sync_add_and_fetch((type*)&numbers[offset], raw_to_add) )

#define ATOMIC_ADD_FETCH(type, numbers, offset, raw_to_add, result) \
        type tmp_result = __sync_add_and_fetch((type*)&numbers[offset], raw_to_add); \
        memcpy(result, &tmp_result, sizeof(type))

/* macros are used by the various decrement_* calls ot save lines of code */
#define ATOMIC_SUB(type, numbers, offset, raw_to_sub) ( \
        __sync_sub_and_fetch((type*)&numbers[offset], raw_to_sub) )

#define ATOMIC_SUB_FETCH(type, numbers, offset, raw_to_sub, result) \
        type tmp_result = __sync_sub_and_fetch((type*)&numbers[offset], raw_to_sub); \
        memcpy(result, &tmp_result, sizeof(type))

/* These are the perms for the registry filename, semaphore, shared memory. I
 * know these rights are pretty open. But tell me how can I guarentee that other
 * processes with other user names (for example apache runs with www-data user)
 * can access the counters? Worst case is a denial of service, when an attacker
 * deletes the shared memory or the registry file is changed.
 */

static int resource_perms = S_IROTH | S_IWOTH | S_IRGRP | S_IWGRP | S_IWUSR | S_IRUSR;

/* The forth parameter of semctl is not defined in any header */

#if defined(_SEM_SEMUN_UNDEFINED)
union semun {
        struct semid_ds *buf;    /* Buffer for IPC_STAT, IPC_SET */
};
#endif

/* Forward decleration */
static PyObject* convert_pointer_to_py(char *pos, long raw_type);

/* Macros for micro optimizations */
#define LIKELY(x)       __builtin_expect((x),1)


/*
 * GlobalNumbers instace description.
 * PyObject_HEAD Macro makes the GlobalNumbers struct into a PythonObject.
 * This structure is passed around when dealing with instaces of GlobalNumbers
 */

typedef struct {
    PyObject_HEAD
    /* name of the registry-file. The inode-id of this file is also used to
     * identify the semaphore and shared_memory
     */
    PyObject * filename;

    /* Every namespace (name of a single number) accessed via the public API
     * is prefixed with 'ns_prefix' before written to the registry file
     */
    PyObject * ns_prefix;

    /* ID returned by semget. This ID is used to call semop */
    int semid;

    /* Pointer to the attached shared memory segment. */
    char * numbers;

    /* Pointer to a python dictonary which holds the parsed information of the
     * registry-file. Key is the namespace of the counter
     */
    PyObject * registry_data;
} GlobalNumbers;

/* This type is for speed only.
 * It increments a *fixed* namspace, by a fixed number.
 * => We called you cannot influence the namespace nor the number to increment.
 * This is configured when the object is created.
 */
typedef struct {
    PyObject_HEAD

    /* Pointer to globalnumbers.
     * Keep a reference to it to prevent garbage collection.
     */
    GlobalNumbers* gn;

    /* Offset within the shared memory segment to touch. */
    long offset;

    /* Type of the number to increment. */
    long raw_type;

    /* Keep the namespace we are going to increment.
     * So the user can acces this later if needed.
     */
    PyObject* namespace;

    /* Value which is added all the time this object is called. */
    PyObject* to_add;

} GNIncrementor;

/* Forward decleration. */
static PyTypeObject GNIncrementorType;

/*
 * Called if the reference count of an GlobalNumbers instance goes to 0.
 * Then the garbage collector frees the memory and calls this method.
 */
static void
GlobalNumbers_dealloc(GlobalNumbers *self){

    /*
     * We dont need a reference to filename-object anymore.
     * We dont need a reference to the registry_data
     *   (all the python objects inside the dictionary are also freed)
     * Py_XDECREF does already a check if self->filename is NULL
     */
    Py_XDECREF(self->filename);
    Py_XDECREF(self->registry_data);
    Py_XDECREF(self->ns_prefix);

    /* detach from shared memory */
    if(self->numbers != NULL)
        shmdt(self->numbers);

    /*'type-free' frees the 'internal' memory for a python object */
    Py_TYPE(self)->tp_free((PyObject*) self);
}


/*
 * Called if a new instance of GlobalNumbers is created. The intention of this
 * method is to reserve the *only minimum* needed memory to create this object.
 * NO advanced initialization should be done, for this use GlobalNumbers_init
 */
static PyObject *
GlobalNumbers_new(PyTypeObject *type, PyObject *args, PyObject *kwargs)
{
    GlobalNumbers * self;
    /* 'type'-allocator reserves the 'internal' memory for a python object */
    self = (GlobalNumbers*) type->tp_alloc(type, 0);

    /*
     * Dont initialze our variables here.
     * Some of them need reasonable 'NULL' values, because if GlobalNumbers_init
     * raises a Exception GlobalNumbers_dealloc is also called
     */
    self->filename = NULL;
    self->semid = -1;
    self->numbers = NULL;
    self->registry_data = NULL;
    self->ns_prefix = NULL;

    return (PyObject*)self;
}

/* Ensures that the filename is either
 *  - just bytes
 *  - unicode with ASCII only codepoints
 * Returns:
 *  - NULL on error
 *  - New reference to a PyBytesObject
 */
static PyObject*
as_ascii_bytes(PyObject *ob)
{
    if (PyBytes_Check(ob)) {
        Py_INCREF(ob);
        return ob;
    } else {
        return PyUnicode_AsASCIIString(ob);
    }
}

/* Converts the namespace into the 'native' string representation.
 * python2:
 *  bytes: stay bytes
 *  unicode: converted to bytes via UTF-8
 * python3:
 *  only unicode supported
 *
 * => Returns a new reference to the native string representation:
 * py2: bytes
 * py3: unicode
 */
static PyObject*
ns_to_native_string(PyObject *ob)
{

#if IS_PY2
    if (PyUnicode_Check(ob)) {
        return PyUnicode_AsUTF8String(ob);
    }
#endif

    if (!PyStr_Check(ob)) {
        return PyErr_Format(
            PyExc_TypeError,
            "Namespace must be of type (%s), but %s given",
            PyUnicode_Type.tp_name,
            Py_TYPE(ob)->tp_name);
    }

    Py_INCREF(ob);
    return ob;
}

/*
 * Check if a filename points to a regular file
 * Returns -1 if the file is *not* regular, or on error.
 * (Python Excepion already set)
 */
static int
is_regular_file(char *filename)
{
    struct stat buf;
    if (stat(filename, &buf) != 0) {
        PyErr_Format(
                PyExc_OSError,
                "Error in check if registry file is a regular file: %s",
                strerror(errno));
        return -1;
    }

    if (!S_ISREG(buf.st_mode)) {
        PyErr_Format(
                PyExc_OSError,
                "Registry file is not a regular file");
        return -1;
    }

    return 0;
}

/*
 * Atomicly create the registry-file
 * Return 0  if call is successfull
 * Return -1 if call goes wrong
 * The full error is already set as a Exception inside the python intepreter
 * => At the python level a OSError will be raised
 */
static int
create_registry_file(PyObject * py_filename)
{
    char* filename;

    if ((filename = PyBytes_AsString(py_filename)) == NULL)
        return -1;

    /* The system call itself ensures the atomic behaviour */
    int err = open(filename, O_RDWR | O_CREAT | O_EXCL, resource_perms);
    if (err == -1) {
        /* File already there, no need for chmod. Just check if its regular */
        if (errno == EEXIST)
            return is_regular_file(filename);

        PyErr_Format(
            PyExc_OSError,
            "creating registry file: %s",
            strerror(errno));
        return -1;
    }

    /* Only the creator can do a chmod => only do it on creation */
    if (fchmod(err, resource_perms) == -1) {
        PyErr_Format(
            PyExc_OSError,
            "Cannot change permission on registry file: %s",
            strerror(errno));
        close(err);
        return -1;
    }
    close(err);

    /* The file created by us, check if its still regular */
    return is_regular_file(filename);
}

/*
 * Generates a key which is used for a system wide identificaiton of the
 * shared-memory and semphore. (The Inode of the filename is used)
 * Returns -1 on error (and the Exception already set inside the Interpreter)
 * Returns valid key on success
 */
static key_t
build_key(PyObject * filename)
{
    key_t ret;
    if( (ret = ftok(PyBytes_AsString(filename), 'x')) == -1) {
        PyErr_Format(
            PyExc_OSError,
            "building unique key_t with file (%s) : %s",
            PyBytes_AsString(filename),
            strerror(errno));
        return -1;
    }
    return ret;
}

/* For some reason the umask influences the semget call.
 * This method ensures that the permissions are correct.
 */
static int
fix_semaphore_perms(int semid)
{
    union semun semctl_opt;
    struct semid_ds semaphore_opts;

    semctl_opt.buf = &semaphore_opts;
    if (semctl(semid, 0, IPC_STAT, semctl_opt) == -1) {
        PyErr_Format(
            PyExc_OSError,
            "Cannot read permissions on semaphore: %s",
            strerror(errno));
        return -1;
    }

    semctl_opt.buf->sem_perm.mode = resource_perms;

    if (semctl(semid, 0, IPC_SET, semctl_opt) == -1) {
        PyErr_Format(
            PyExc_OSError,
            "Cannot set permissions on semaphore: %s",
            strerror(errno));
        return -1;
    }
    return 0;
}

/*
 * Atomicly initializes the Semaphore for coordinating access to registry-file.
 * Returns the semid on success
 * Return -1 on error (Exception already set inside the Interpreter)
 */
static int
init_semaphore(PyObject *filename)
{
    key_t key;

    if( (key = build_key(filename)) == -1)
        return -1;

    int semid;
    /* Try to create the semaphore.
     * Is the semaphore already there, an error is returned and NO initialization
     * Yes we allow others to access the semaphore. Do we have another way to
     * ensure that all proccesses can access it, plz tell me!
     */

    semid = semget(key, 1, IPC_CREAT | IPC_EXCL | resource_perms);

    if (semid == -1) {
        /* Only EEXIST is a valid error, all other errors point to a problem */
        if (errno != EEXIST) {
            PyErr_Format(
                PyExc_OSError,
                "Creating semaphore with key_t (%x) : %s",
                key,
                strerror(errno));

            return -1;
        }
        /* Call it again to get the semid */
        if( (semid = semget(key, 0, 0)) == -1) {
            PyErr_Format(
                PyExc_OSError,
                "Get semid by key (%x) even if semaphore is already there: %s",
                key,
                strerror(errno));

            return -1;
        }
    }
    else {

        if (fix_semaphore_perms(semid) == -1)
            return -1;

        /* lock/unlock methods need a initial value to work */
        if (semctl(semid, 0, SETVAL, (int)1) == -1) {
            PyErr_Format(
                PyExc_OSError,
                "Set initial semaphore value to 1, semid(%i), key(%x): %s",
                semid,
                key,
                strerror(errno));

            return -1;
        }
    }

    return semid;
}

static size_t
get_shared_memory_size(PyObject *filename)
{
    key_t key;
    int shmid;
    struct shmid_ds stat_buf;

    if ((key = build_key(filename)) == -1) {
        return -1;
    }

    /* This is the way to get shmid of an existing SHM segment */
    shmid = shmget(key, 0, 0);
    if (shmid == -1) {
        PyErr_Format(
            PyExc_OSError,
            "Error at shmget while getting size of shm segment. "
            "fn(%s), key_t(%i): %s",
            PyBytes_AsString(filename),
            key,
            strerror(errno));
        return -1;
    }

    if (shmctl(shmid, IPC_STAT, &stat_buf) == -1) {
        PyErr_Format(
            PyExc_OSError,
            "Error at shmctl(IPC_STAT) while getting size of shm segment. "
            "fn(%s), shmid(%i): %s",
            PyBytes_AsString(filename),
            shmid,
            strerror(errno));
        return -1;
    }

    return stat_buf.shm_segsz;
}

/* For some reason the umask influences the shmget call.
 * This method ensures that the permissions are correct.
 */
static int
fix_shared_memory_perms(int shmid)
{
    struct shmid_ds buf;

    if (shmctl(shmid, IPC_STAT, &buf) == -1) {
        PyErr_Format(
            PyExc_OSError,
            "Cannot read permissions on shared memory: %s",
            strerror(errno));
        return -1;
    }

    buf.shm_perm.mode = resource_perms;

    if (shmctl(shmid, IPC_SET, &buf) == -1) {
        PyErr_Format(
            PyExc_OSError,
            "Cannot set permissions on shared memory: %s",
            strerror(errno));
        return -1;
    }
    return 0;
}

/*
 * Gets the ID of the shared memory segment. Is the shared memory *not* there
 * create it.
 * Returns the shmid on success
 * Returns -1 on failure (Python Exception already set)
 */
static int
ensure_shared_memory(key_t key, Py_ssize_t req_shm_size)
{
    /* Get the ID of the shared memory, automaticly create it if not there */
    int shmid = shmget(key, req_shm_size, IPC_CREAT | IPC_EXCL | resource_perms);

    if (shmid == -1) {
        if (errno != EEXIST) {
            PyErr_Format(
                PyExc_OSError,
                "creating Shared memory with key (%i) : %s",
                key,
                strerror(errno));
            return -1;
        }

        shmid = shmget(key, 0, 0);
        if (shmid == -1) {
            PyErr_Format(
                PyExc_OSError,
                "Getting Shared memory with key (%i) : %s",
                key,
                strerror(errno));
            return -1;
        }
    }
    else {
        if (fix_shared_memory_perms(shmid) == -1)
            return -1;
    }

    return shmid;
}

/*
 * Creates the shared memory if not already existing.
 * Attaches the shared memory to the current instance
 * Returns NULL on error (Exception already set inside the intepreter)
 * Return pointer to the attached shared memory segment
 */
static void *
attach_shared_memory(PyObject *filename, Py_ssize_t req_shm_size)
{
    key_t key;
    if ((key = build_key(filename)) == -1)
        return NULL;

    int shmid = ensure_shared_memory(key, req_shm_size);
    if (shmid == -1)
        return NULL;

    /* Attach the shared memory into user space */
    void * ret;
    /* On error shmat returns (void*)-1 */
    if ((ret = shmat(shmid, NULL, 0)) == (void*)-1) {
        PyErr_Format(
            PyExc_OSError,
            "Attaching to shared memory key(%i), shmid(%i): %s",
            key,
            shmid,
            strerror(errno));
        return NULL;
    }
    return ret;
}

/*
 * According to the operation
 *  * Waits until the semephore is free
 *  * Releases the semephore
 * Returns -1 on error (Exception already set inside the intepreter)
 * Return 0 on success
 */
static int
semaphore_operation(GlobalNumbers * self, int operation)
{
    struct sembuf tmp_sem;

    /*
     * semop goes linearly through the semaphore array, BUT the ordering is
     * given by sem_num and not the place inside the array
     */
    tmp_sem.sem_num = 0;
    tmp_sem.sem_op = operation;
    /* If the process gets killed, this flag undos the lock */
    tmp_sem.sem_flg = SEM_UNDO;
    if( semop(self->semid, &tmp_sem, 1) == -1) {
        PyErr_Format(
            PyExc_OSError,
            "Calling semaphore operation (%i) on semid(%i): %s",
            operation,
            self->semid,
            strerror(errno));
        return -1;
    }
    return 0;
}

/* convert the pretty_name of the internal type to a constant*/
static int
convert_pretty_name_to_constant(char* to_check)
{
    int i;
    const char * ref;
    for(i=0; INTERNAL_TYPE_AS_STRING[i] != NULL; i++) {
        ref = INTERNAL_TYPE_AS_STRING[i];
        if(strncmp(to_check, ref, strlen(ref)) == 0)
            return i;
    }
    return -1;
}

/*
 * Parses the registry-file and fills a dictionary for each row
 * Returns a new reference to a PythonDictonary
 * Return NULL on error (Exception already set in the intepreter)
 */
static PyObject *
parse_registry_file(PyObject *filename)
{
    PyObject * ret_dict;
    PyObject * tmp_dict_entry;
    /* +1 is needed to keep the '\0' */
    char namespace[MAX_NAMESPACE_SIZE+1];
    char snmp_type[32];
    char internal_type[32];
    int offset;
    int scanf_ret;
    FILE * registry_file;

    /* Open the registry-file for reading */
    if( (registry_file = fopen(PyBytes_AsString(filename), "r")) == NULL) {
        return PyErr_Format(
            PyExc_OSError,
            "Open registry file (%s) for reading: %s",
            PyBytes_AsString(filename),
            strerror(errno));
    }

    if( (ret_dict = PyDict_New()) == NULL) {
        fclose(registry_file);
        return NULL;
    }

    scanf_ret = fscanf(
        registry_file,
        REG_READ_FORMAT,
        namespace,
        snmp_type,
        internal_type,
        &offset);

    while (scanf_ret == 4) {
        tmp_dict_entry = Py_BuildValue(
                "(sii)",
                snmp_type,
                convert_pretty_name_to_constant(internal_type),
                offset);

        if (tmp_dict_entry == NULL) {
            Py_DECREF(ret_dict);
            fclose(registry_file);
            return NULL;
        }

        /* python3 converts namespace via UTF-8 to a unicode object. */
        PyDict_SetItemString(ret_dict, namespace, tmp_dict_entry);

        /* PyDict_SetItemString increases the reference count and for new
         * the tuple in tmp_dict_entry is not needed
         */
        Py_DECREF(tmp_dict_entry);

        scanf_ret = fscanf(
            registry_file,
            REG_READ_FORMAT,
            namespace,
            snmp_type,
            internal_type,
            &offset);
    }


    if (ferror(registry_file)) {
        PyErr_Format(
            PyExc_OSError,
            "Processing registry file (%s) : %s",
            PyBytes_AsString(filename),
            strerror(errno));

        Py_DECREF(ret_dict);
        fclose(registry_file);
        return NULL;
    }

    fclose(registry_file);
    return ret_dict;
}

PyDoc_STRVAR(GlobalNumbers_doc,
"GlobalNumbers(filename)"
"All instances of GlobalNumbers with the same filename use the same counters."
"Each time a GlobalNumbers object is created the constructer checks if the "
"Semaphore, SharedMemory, Registry-file are already there. "
"If not the constructer creates them automaticly in a atomic fashion"
"The Semaphore is needed to coordinate access to the Registry-file"
);

/*
 * Called after GlobalNumbers_new, with following return values
 *  return 0 means no error happens
 *  return -1 means that a error happens
 */
static int
GlobalNumbers_init(GlobalNumbers *self, PyObject *args, PyObject *kwargs)
{
    PyObject *filename;
    PyObject *ns_prefix = NULL;
    Py_ssize_t req_shm_size = SHM_DEFAULT_SIZE;

    /* Parse and Validate the arguments */
    if (!PyArg_ParseTuple(args, "O|On", &filename, &ns_prefix, &req_shm_size))
        return -1;

    if (req_shm_size > SHM_MAX_SIZE) {
        PyErr_Format(
            PyExc_ValueError,
            "Requested size is too big: %zd",
            req_shm_size);
        return -1;
    }

    if (req_shm_size < SHM_MIN_SIZE) {
        PyErr_Format(
            PyExc_ValueError,
            "Requested size is too small: %zd",
            req_shm_size);
        return -1;
    }

    /* No need to decrement the refcount of 'as_ascii_bytes()' here.
     * self->filename is needed during the entire lifetime of self.
     * Same goes for 'self->ns_prefix'.
     */
    if ((self->filename = as_ascii_bytes(filename)) == NULL)
        return -1;

    if (ns_prefix != NULL) {
        if ((self->ns_prefix = ns_to_native_string(ns_prefix)) == NULL) {
            return -1;
        }

        /* Don't prepend empty string, makes no sense */
        if (PyObject_Length(self->ns_prefix) == 0) {
            Py_DECREF(self->ns_prefix);
            self->ns_prefix = NULL;
        }
    }

    if (create_registry_file(self->filename) == -1)
        return -1;

    if ((self->semid = init_semaphore(self->filename)) == -1)
        return -1;

    self->numbers = attach_shared_memory(self->filename, req_shm_size);
    if (self->numbers == NULL)
        return -1;

    if (semaphore_operation(self, SEMAPHORE_LOCK) == -1)
        return -1;

    self->registry_data = parse_registry_file(self->filename);

    /* An Error in parse_registry_file is suppressed by an error here */
    if (semaphore_operation(self, SEMAPHORE_UNLOCK) == -1)
        return -1;

    if (self->registry_data == NULL)
        return -1;

    return 0;
}

/* Builds the NS object for later use.
 *   - Ensures a 'native' string.
 *      py2: bytes
 *      py3: unicode
 *   - Adds the ns_prefix in front of the string (if needed)
 * Returns:
 *     Success: Always a *new* reference => Decrement after usage
 *     Error: NULL
 */
static PyObject*
construct_ns(GlobalNumbers *self, PyObject *namespace)
{
    namespace = ns_to_native_string(namespace);
    if (namespace == NULL) {
        return NULL;
    }

    if (self->ns_prefix == NULL) {
        /* ns_to_native_string took already care of the reference. */
        return namespace;
    }

    PyObject *tmp = PyStr_Concat(self->ns_prefix, namespace);

    /* ns_to_native_string gave us a reference. Lets get rid of it. */
    Py_DECREF(namespace);

    return tmp;
}

/*
 * Autoconvert (guess) the internal type of a python number
 * (NO error check of number is done)
 */
static long
guess_internal_type(PyObject *number)
{
    if (PyInt_CheckExact(number))
        return ULONG_TYPE;
    if (PyLong_CheckExact(number))
        return ULONG_TYPE;
    if (PyFloat_CheckExact(number))
        return FLOAT_TYPE;
    return NO_TYPE;
}

/*
 * Checks if possible_number is one of these python-types
 * int, float, long
 * (subclasses are considered as FALSE)
 * Returns 1 if possible_number is a number
 * Returns 0 if possible_number is NOT a number.
 * In that case a appropiate Py-Exception is set
 */
static int
is_valid_number(PyObject *possible_number)
{
    if (PyInt_CheckExact(possible_number) ||
        PyLong_CheckExact(possible_number) ||
        PyFloat_CheckExact(possible_number))
    {

        return 1;
    }

    /* It is not a number */
    PyErr_Format(
        PyExc_TypeError,
        "need a number not - %s",
        Py_TYPE(possible_number)->tp_name);
    return 0;
}

/*
 * Iterates over all entries in the registry-file and searches for the
 * highest offset. If the highest offset is found, add the size of the datatype
 * stored there. This number is then the next free offset.
 * Returns -1 If an error happens (Exception set in the interpreter)
 * Returns a number >= 0 which is the next free offset
 */
static long
calc_next_offset(PyObject * registry_data)
{
    /* tmp variables needed to iterate over the registry_data*/
    PyObject *key, *value;
    Py_ssize_t pos=0;
    /* For the first counter we store offset 0 in the file. So for the next
     * counter offset 0 should be taken
     */
    long offset = -1;
    long possible_offset;
    long internal_type = NO_TYPE;

    while (PyDict_Next(registry_data, &pos, &key, &value)) {
        possible_offset = GET_OFFSET(value);
        if (possible_offset > offset) {
            offset = possible_offset;
            internal_type = GET_INTERNAL_TYPE(value);
        }
    }

    /* -1 means no counter there => take the first place */
    if(offset == -1)
        return 0;

    switch (internal_type) {
        case INT_TYPE:
            return offset + sizeof(long);
        case UINT_TYPE:
            return offset + sizeof(unsigned long);
        case LONG_TYPE:
            return offset + sizeof(long long);
        case ULONG_TYPE:
            return offset + sizeof(unsigned long long);
        case FLOAT_TYPE:
            return offset + sizeof(long long);
        default:
            return offset;
    }

}

/*
 * Iterates over the internal copy of registry_data and fully overwrites the
 * file. => ENSURE you hold the lock, otherwise you have evil race conditions
 * Returns -1 on error
 * Returns 0 on success
 */
static int
write_registry_data(PyObject * registry_data, PyObject *filename)
{
    PyObject *key, *value;
    Py_ssize_t pos=0;

    FILE * stream;
    if ((stream = fopen(PyBytes_AsString(filename), "w")) == NULL) {
        PyErr_Format(
            PyExc_OSError,
            "Open registry file (%s) for writing: %s",
            PyBytes_AsString(filename),
            strerror(errno));

        return -1;
    }

    while (PyDict_Next(registry_data, &pos, &key, &value)) {
        fprintf(stream, "%s %s %s %li\n",
                PyStr_AsString(key),
                GET_SNMP_TYPE(value),
                INTERNAL_TYPE_AS_STRING[GET_INTERNAL_TYPE(value)],
                GET_OFFSET(value));
    }

    fclose(stream);
    return 0;
}

/*
 * Add a new counter into the internal registry_data
 */
static int
add_new_counter(GlobalNumbers *self, PyObject *ns, long internal, char *snmp)
{
    long new_offset;
    PyObject *dict_entry;
    PyObject *registry = self->registry_data;

    const size_t shm_size = get_shared_memory_size(self->filename);
    if (shm_size == -1) {
        return -1;
    }

    const size_t max_offset = shm_size - sizeof(unsigned long long);

    new_offset = calc_next_offset(registry);
    if (new_offset > max_offset) {
        PyErr_Format(PyExc_Exception, "Not enough space for more counters");
        return -1;
    }

    dict_entry = Py_BuildValue("(sii)", snmp, internal, new_offset);
    if (dict_entry == NULL) {
        return -1;
    }

    PyDict_SetItem(registry, ns, dict_entry);
    Py_DECREF(dict_entry);
    return 0;
}

static int
reread_registry_data(GlobalNumbers *self)
{
    PyObject * new;

    if ((new = parse_registry_file(self->filename)) == NULL)
        return -1;

    Py_XDECREF(self->registry_data);
    self->registry_data = new;
    return 0;
}

static int
get_offset_and_type(PyObject *registry, PyObject *ns, long *offset, long *internal)
{
    PyObject * dict_entry;
    dict_entry = PyDict_GetItem(registry, ns);
    (*offset) = GET_OFFSET(dict_entry);
    (*internal) = GET_INTERNAL_TYPE(dict_entry);
    return 0;
}

/* ## Now comes a set of 'converter' functions.
 * They convert various PythonNumber types into a specific C-level type.
 * The caller ensures that only int, float, long objects can come in.
 * If these methods fail no appropiate return code is defined.
 * Use PyErr_Occurred() to check for an error.
 */

/* In python3 the PyInt_ is gone. Only PyLong is there.
 * 'compat.h' brings the PyInt back by mapping it to PyLong.
 * This is OK and makes the code working.
 * However in python3 for performance reasons inside the convert_XXX functions
 * we would like to omit the path where 'PyInt_CheckExact' returns True.
 */
#if IS_PY3
#define is_py2int(nb) 0
#endif

#if IS_PY2
#define is_py2int PyInt_CheckExact
#endif

static long
convert_to_int_type(PyObject *number)
{
    if (is_py2int(number)) {
        return PyInt_AsLong(number);
    }
    else if (PyLong_CheckExact(number)) {
        return PyLong_AsLong(number);
    }
    else if (PyFloat_CheckExact(number)) {
        if ((number = PyNumber_Long(number)) == NULL)
            return 0;

        long raw_number = PyLong_AsLong(number);

        /* PyNumber_Long creates a new reference */
        Py_XDECREF(number);
        return raw_number;
    }
}

static unsigned long
convert_to_uint_type(PyObject *number)
{
    /*
     * PyLong_AsUnsignedLong does the appropriate typechecks if the python number
     * can be *really* converted to an unsigned long
     */
    if (is_py2int(number) || PyFloat_CheckExact(number)) {
        if ((number = PyNumber_Long(number)) == NULL)
            return 0;
        unsigned long raw_number = PyLong_AsUnsignedLong(number);

        /* PyNumber_Long creates a new reference */
        Py_XDECREF(number);

        return raw_number;

    }
    else {
        return PyLong_AsUnsignedLong(number);
    }
}

static long long
convert_to_long_type(PyObject *number)
{
    if (is_py2int(number)) {
        return (long long)PyInt_AsLong(number);
    }
    else if (PyLong_CheckExact(number)) {
        return PyLong_AsLongLong(number);
    }
    else if (PyFloat_CheckExact(number)) {

        if ((number = PyNumber_Long(number)) == NULL)
            return 0;

        long long raw_number = PyLong_AsLongLong(number);
        Py_XDECREF(number);
        return raw_number;
    }
}

static unsigned long long
convert_to_ulong_type(PyObject *number)
{
    /*
     * PyLong_AsUnsignedLongLong does the appropriate typechecks if
     * the python number can be *really* converted to an unsigned long
     */

    if (is_py2int(number) || PyFloat_CheckExact(number)) {
        if ((number = PyNumber_Long(number)) == NULL)
            return -1;

        unsigned long long raw_number = PyLong_AsUnsignedLongLong(number);
        Py_XDECREF(number);
        return raw_number;
    }
    else {
        return PyLong_AsUnsignedLongLong(number);
    }
}

static long long
convert_to_float_type(PyObject *number)
{
    if (is_py2int(number)) {
        return (long long)(PyInt_AsLong(number) * FLOAT_PRECISION);
    }
    else if (PyLong_CheckExact(number)) {
        return PyLong_AsLongLong(number) * FLOAT_PRECISION;
    }
    else if (PyFloat_CheckExact(number)) {
        return (long long)(PyFloat_AsDouble(number) * FLOAT_PRECISION);
    }
}

/** Here comes the low level increment code **/

/* Add the python number to an INT_TYPE */
static int
increment_int_type(char *numbers, long offset, PyObject *to_add, char *result)
{
    long raw_to_add = convert_to_int_type(to_add);
    if(PyErr_Occurred())
        return -1;

    if (LIKELY(result == NULL)) {
        ATOMIC_ADD(long, numbers, offset, raw_to_add);
    }
    else {
        ATOMIC_ADD_FETCH(long, numbers, offset, raw_to_add, result);
    }
    return 0;
}

/* Add a python number to an UINT_TYPE */
static int
increment_uint_type(char *numbers, long offset, PyObject *to_add, char *result)
{
    unsigned long raw_to_add = convert_to_uint_type(to_add);
    if (PyErr_Occurred())
        return -1;

    if (LIKELY(result == NULL)) {
        ATOMIC_ADD(unsigned long, numbers, offset, raw_to_add);
    }
    else {
        ATOMIC_ADD_FETCH(unsigned long, numbers, offset, raw_to_add, result);
    }
    return 0;
}

/* Add a a python number to an LONG_TYPE */
static int
increment_long_type(char *numbers, long offset, PyObject *to_add, char *result)
{
    long long raw_to_add = convert_to_long_type(to_add);
    if(PyErr_Occurred())
        return -1;

    if (LIKELY(result == NULL)) {
        ATOMIC_ADD(long long, numbers, offset, raw_to_add);
    }
    else {
        ATOMIC_ADD_FETCH(long long, numbers, offset, raw_to_add, result);
    }
    return 0;
}

/* Add a python number to an ULONG_TYPE */
static int
increment_ulong_type(char *numbers, long offset, PyObject *to_add, char *result)
{
    unsigned long long raw_to_add = convert_to_ulong_type(to_add);
    if (PyErr_Occurred())
        return -1;

    if (LIKELY(result == NULL)) {
        ATOMIC_ADD(unsigned long long, numbers, offset, raw_to_add);
    }
    else {
        ATOMIC_ADD_FETCH(unsigned long long, numbers, offset, raw_to_add, result);
    }
    return 0;
}

/* Add a python number to a FLOAT_TYPE */
static int
increment_float_type(char *numbers, long offset, PyObject *to_add, char *result)
{
    long long raw_to_add = convert_to_float_type(to_add);
    if (PyErr_Occurred())
        return -1;

    if (LIKELY(result == NULL)) {
        ATOMIC_ADD(long long, numbers, offset, raw_to_add);
    }
    else {
        ATOMIC_ADD_FETCH(long long, numbers, offset, raw_to_add, result);
    }
    return 0;
}

static int
increment_shared_mem(char *numbers, long offset, long internal, PyObject *to_add)
{
    if (internal == INT_TYPE)
        return increment_int_type(numbers, offset, to_add, NULL);
    if (internal == UINT_TYPE)
        return increment_uint_type(numbers, offset, to_add, NULL);
    if (internal == LONG_TYPE)
        return increment_long_type(numbers, offset, to_add, NULL);
    if (internal == ULONG_TYPE)
        return increment_ulong_type(numbers, offset, to_add, NULL);
    if (internal == FLOAT_TYPE)
        return increment_float_type(numbers, offset, to_add, NULL);
    return -1;
}

static int
increment_shared_mem_and_fetch(
        char *numbers,
        long offset,
        long internal,
        PyObject *to_add,
        char *result)
{
    if (internal == INT_TYPE)
        return increment_int_type(numbers, offset, to_add, result);
    if (internal == UINT_TYPE)
        return increment_uint_type(numbers, offset, to_add, result);
    if (internal == LONG_TYPE)
        return increment_long_type(numbers, offset, to_add, result);
    if (internal == ULONG_TYPE)
        return increment_ulong_type(numbers, offset, to_add, result);
    if (internal == FLOAT_TYPE)
        return increment_float_type(numbers, offset, to_add, result);
    return -1;
}
/** Here comes the low level decrement code **/

/* Substract the python number from an INT_TYPE */
static int
decrement_int_type(char *numbers, long offset, PyObject *to_sub, char *result)
{
    long raw_to_sub = convert_to_int_type(to_sub);
    if(PyErr_Occurred())
        return -1;

    if (LIKELY(result == NULL)) {
        ATOMIC_SUB(long, numbers, offset, raw_to_sub);
    }
    else {
        ATOMIC_SUB_FETCH(long, numbers, offset, raw_to_sub, result);
    }
    return 0;
}

/* Substract a python number form an UINT_TYPE */
static int
decrement_uint_type(char *numbers, long offset, PyObject *to_sub, char *result)
{
    unsigned long raw_to_sub = convert_to_uint_type(to_sub);
    if (PyErr_Occurred())
        return -1;

    if (LIKELY(result == NULL)) {
        ATOMIC_SUB(unsigned long, numbers, offset, raw_to_sub);
    }
    else {
        ATOMIC_SUB_FETCH(unsigned long, numbers, offset, raw_to_sub, result);
    }
    return 0;
}

/* Substract a python number from an LONG_TYPE */
static int
decrement_long_type(char *numbers, long offset, PyObject *to_sub, char *result)
{
    long long raw_to_sub = convert_to_long_type(to_sub);
    if(PyErr_Occurred())
        return -1;

    if (LIKELY(result == NULL)) {
        ATOMIC_SUB(long long, numbers, offset, raw_to_sub);
    }
    else {
        ATOMIC_SUB_FETCH(long long, numbers, offset, raw_to_sub, result);
    }
    return 0;
}

/* Substract a python number from an ULONG_TYPE */
static int
decrement_ulong_type(char *numbers, long offset, PyObject *to_sub, char *result)
{
    unsigned long long raw_to_sub = convert_to_ulong_type(to_sub);
    if (PyErr_Occurred())
        return -1;

    if (LIKELY(result == NULL)) {
        ATOMIC_SUB(unsigned long long, numbers, offset, raw_to_sub);
    }
    else {
        ATOMIC_SUB_FETCH(unsigned long long, numbers, offset, raw_to_sub, result);
    }
    return 0;
}

/* Substract a python number from a FLOAT_TYPE */
static int
decrement_float_type(char *numbers, long offset, PyObject *to_sub, char *result)
{
    long long raw_to_sub = convert_to_float_type(to_sub);
    if (PyErr_Occurred())
        return -1;

    if (LIKELY(result == NULL)) {
        ATOMIC_SUB(long long, numbers, offset, raw_to_sub);
    }
    else {
        ATOMIC_SUB_FETCH(long long, numbers, offset, raw_to_sub, result);
    }
    return 0;
}

static int
decrement_shared_mem(char *numbers, long offset, long internal, PyObject *to_sub)
{
    if (internal == INT_TYPE)
        return decrement_int_type(numbers, offset, to_sub, NULL);
    if (internal == UINT_TYPE)
        return decrement_uint_type(numbers, offset, to_sub, NULL);
    if (internal == LONG_TYPE)
        return decrement_long_type(numbers, offset, to_sub, NULL);
    if (internal == ULONG_TYPE)
        return decrement_ulong_type(numbers, offset, to_sub, NULL);
    if (internal == FLOAT_TYPE)
        return decrement_float_type(numbers, offset, to_sub, NULL);
    return -1;
}

static int
decrement_shared_mem_and_fetch(
        char *numbers,
        long offset,
        long internal,
        PyObject *to_sub,
        char *result)
{
    if (internal == INT_TYPE)
        return decrement_int_type(numbers, offset, to_sub, result);
    if (internal == UINT_TYPE)
        return decrement_uint_type(numbers, offset, to_sub, result);
    if (internal == LONG_TYPE)
        return decrement_long_type(numbers, offset, to_sub, result);
    if (internal == ULONG_TYPE)
        return decrement_ulong_type(numbers, offset, to_sub, result);
    if (internal == FLOAT_TYPE)
        return decrement_float_type(numbers, offset, to_sub, result);
    return -1;
}

/** Here comes the low level set code **/
static int
set_int_type(char *numbers, long offset, PyObject *to_set)
{
    long raw_to_set = convert_to_int_type(to_set);
    if (PyErr_Occurred())
        return -1;

    *((long*) &numbers[offset]) = raw_to_set;
    return 0;
}

static int
set_uint_type(char *numbers, long offset, PyObject *to_set)
{
    unsigned long raw_to_set = convert_to_uint_type(to_set);
    if (PyErr_Occurred())
        return -1;

    *((unsigned long*) &numbers[offset]) = raw_to_set;
    return 0;
}

static int
set_long_type(char *numbers, long offset, PyObject *to_set)
{
    long long raw_to_set = convert_to_long_type(to_set);
    if(PyErr_Occurred())
        return -1;

    *((long long*) &numbers[offset]) = raw_to_set;
    return 0;
}

static int
set_ulong_type(char *numbers, long offset, PyObject *to_set)
{
    unsigned long long raw_to_set = convert_to_ulong_type(to_set);
    if (PyErr_Occurred())
        return -1;

    *((unsigned long long*) &numbers[offset]) = raw_to_set;
    return 0;
}

static int
set_float_type(char *numbers, long offset, PyObject *to_set)
{
    long long raw_to_set = convert_to_float_type(to_set);
    if (PyErr_Occurred())
        return -1;

    *((long long*) &numbers[offset]) = raw_to_set;
    return 0;
}

static int
set_shared_mem(char *numbers, long offset, long internal, PyObject *to_set)
{
    if (internal == INT_TYPE)
        return set_int_type(numbers, offset, to_set);
    if (internal == UINT_TYPE)
        return set_uint_type(numbers, offset, to_set);
    if (internal == LONG_TYPE)
        return set_long_type(numbers, offset, to_set);
    if (internal == ULONG_TYPE)
        return set_ulong_type(numbers, offset, to_set);
    if (internal == FLOAT_TYPE)
        return set_float_type(numbers, offset, to_set);
    return -1;
}

/*
 * Checks if the counter is in the local registry data. Otherwise it rereads
 * the file.
 * DONT use this function if the caller already gets the LOCK
 */
static int
is_counter_in_registry(GlobalNumbers *self, PyObject *namespace)
{
    int ns_in_reg = PyDict_Contains(self->registry_data, namespace);
    if (ns_in_reg == -1)
        return -1;

    if (ns_in_reg == 0) {
        if (semaphore_operation(self, SEMAPHORE_LOCK) == -1)
            return -1;

        if (reread_registry_data(self) == -1) {
            semaphore_operation(self, SEMAPHORE_UNLOCK);
        }

        semaphore_operation(self, SEMAPHORE_UNLOCK);
        return PyDict_Contains(self->registry_data, namespace);
    }
    return 1;
}

/* Checks if namespace is suitable to work with GlobalNumbers
 * returns 1 if its fine;
 * returns 0 if its *not* fine.
 * In that case a appropiate Py-Exception is set
 */
static int
is_namespace_valid(PyObject *namespace)
{
    const char* ns;
    Py_ssize_t ns_size;

    ns = PyStr_AsUTF8AndSize(namespace, &ns_size);
    if (ns == NULL) {
        return 0;
    }

    /* check if the namespace is not too big */
    if (ns_size > MAX_NAMESPACE_SIZE) {
        PyErr_Format(
                PyExc_TypeError,
                "Namespace has the size %zd but only %i are allowed",
                ns_size,
                MAX_NAMESPACE_SIZE);
        return 0;
    }

    /* currently the parser (fscanf) cannot handle whitespaces very well */
    if (strstr(ns, " ") != NULL) {
        PyErr_Format(
            PyExc_TypeError,
            "Namespace contains a not allowed whitespace: %s",
            ns);
        return 0;
    }

    return 1;
}

static int
add_namespace(GlobalNumbers *self, PyObject *namespace, long internal_type)
{
    int ns_in_reg=0;
    int ret = 0;
    if (!is_namespace_valid(namespace))
        return -1;

    if (semaphore_operation(self, SEMAPHORE_LOCK) == -1)
        return -1;

    /* Reread the file, maybe the counter is already there */
    if (reread_registry_data(self) == -1) {
        semaphore_operation(self, SEMAPHORE_UNLOCK);
        return -1;
    }

    if ((ns_in_reg = PyDict_Contains(self->registry_data, namespace)) == -1) {
        semaphore_operation(self, SEMAPHORE_UNLOCK);
        return -1;
    }

    if (ns_in_reg == 0) {
        /* Counter is not there, add it to the registry_data*/
        ret = add_new_counter(
                    self,
                    namespace,
                    internal_type,
                    "N/A");

        if (ret != -1) {
            /* Write the newly created counter into the registry file */
            write_registry_data(self->registry_data, self->filename);
        }
    }
    semaphore_operation(self, SEMAPHORE_UNLOCK);
    return ret;
}

static int
ensure_namespace(GlobalNumbers *self, PyObject *namespace, PyObject *number)
{
    int ns_in_reg=0;
    if (!is_valid_number(number))
        return -1;

    if ((ns_in_reg = PyDict_Contains(self->registry_data, namespace)) == -1)
        return -1;

    if (ns_in_reg == 0) {
        if (add_namespace(self, namespace, guess_internal_type(number)) == -1)
            return -1;
    }
    return 0;
}

PyDoc_STRVAR(increment_doc,
"increment(namespace, number_to_add)"
"namespaces can be an arbitrary string with a maximum length of 1024"
"number_to_add can be either float, int, long"
"Returns always None"
);

/*
 * For this kind of methods return NULL means an Exception happened. Furthermore
 * the interpreter expects an Exception set
 */
static PyObject *
GlobalNumbers_increment(GlobalNumbers *self, PyObject *args)
{
    PyObject * namespace;
    PyObject * to_add;
    long offset = 0;
    long raw_type = NO_TYPE;

    if (!PyArg_ParseTuple(args, "OO", &namespace, &to_add))
        return NULL;

    namespace = construct_ns(self, namespace);
    if (namespace == NULL) {
        return NULL;
    }

    if (ensure_namespace(self, namespace, to_add) == -1) {
        Py_DECREF(namespace);
        return NULL;
    }

    get_offset_and_type(self->registry_data, namespace, &offset, &raw_type);
    if (increment_shared_mem(self->numbers, offset, raw_type, to_add) == -1) {
        Py_DECREF(namespace);
        return NULL;
    }

    Py_DECREF(namespace);
    Py_RETURN_NONE;
}

PyDoc_STRVAR(increment_and_fetch_doc,
"increment_and_fetch(namespace, number_to_add)"
"namespaces can be an arbitrary string with a maximum length of 1024"
"number_to_add can be either float, int, long"
"Returns the number after the increment"
);

static PyObject *
GlobalNumbers_increment_and_fetch(GlobalNumbers *self, PyObject *args)
{
    PyObject * namespace;
    PyObject * to_add;
    long offset = 0;
    long raw_type = NO_TYPE;

    if (!PyArg_ParseTuple(args, "OO", &namespace, &to_add))
        return NULL;

    namespace = construct_ns(self, namespace);
    if (namespace == NULL) {
        return NULL;
    }

    if (ensure_namespace(self, namespace, to_add) == -1) {
        Py_DECREF(namespace);
        return NULL;
    }

    get_offset_and_type(self->registry_data, namespace, &offset, &raw_type);

    /* Don't use namespace anymore */
    Py_DECREF(namespace);

    /* Allocate storage for the result */
    char result[12];
    memset(result, 0, 12);

    int status = increment_shared_mem_and_fetch(
                                self->numbers,
                                offset,
                                raw_type,
                                to_add,
                                result);

    if (status == -1)
        return NULL;

    return convert_pointer_to_py(result, raw_type);
}

PyDoc_STRVAR(decrement_doc,
"decrement(namespace, number_to_sub)"
"namespaces can be an arbitrary string with a maximum length of 1024"
"number_to_sub can be either float, int, long"
"Returns always None"
);

/*
 * For this kind of methods return NULL means an Exception happened. Furthermore
 * the interpreter expects an Exception set
 */
static PyObject *
GlobalNumbers_decrement(GlobalNumbers *self, PyObject *args)
{
    PyObject * namespace;
    PyObject * to_sub;
    long offset = 0;
    long raw_type = NO_TYPE;

    if (!PyArg_ParseTuple(args, "OO", &namespace, &to_sub))
        return NULL;

    namespace = construct_ns(self, namespace);
    if (namespace == NULL) {
        return NULL;
    }

    if (ensure_namespace(self, namespace, to_sub) == -1) {
        Py_DECREF(namespace);
        return NULL;
    }

    get_offset_and_type(self->registry_data, namespace, &offset, &raw_type);
    if (decrement_shared_mem(self->numbers, offset, raw_type, to_sub) == -1) {
        Py_DECREF(namespace);
        return NULL;
    }

    Py_DECREF(namespace);
    Py_RETURN_NONE;
}

PyDoc_STRVAR(decrement_and_fetch_doc,
"decrement_and_fetch(namespace, number_to_sub)"
"namespaces can be an arbitrary string with a maximum length of 1024"
"number_to_sub can be either float, int, long"
"Returns the number after the decrement"
);

static PyObject *
GlobalNumbers_decrement_and_fetch(GlobalNumbers *self, PyObject *args)
{
    PyObject * namespace;
    PyObject * to_sub;
    long offset = 0;
    long raw_type = NO_TYPE;

    if (!PyArg_ParseTuple(args, "OO", &namespace, &to_sub))
        return NULL;

    namespace = construct_ns(self, namespace);
    if (namespace == NULL) {
        return NULL;
    }

    if (ensure_namespace(self, namespace, to_sub) == -1) {
        Py_DECREF(namespace);
        return NULL;
    }

    get_offset_and_type(self->registry_data, namespace, &offset, &raw_type);

    /* Don't use namespace anymore */
    Py_DECREF(namespace);

    /* Allocate storage for the result */
    char result[12];
    memset(result, 0, 12);

    int status = decrement_shared_mem_and_fetch(
                                self->numbers,
                                offset,
                                raw_type,
                                to_sub,
                                result);

    if (status == -1)
        return NULL;

    return convert_pointer_to_py(result, raw_type);
}

/* Keep in mind when using this method that namespace must be without
 * 'ns_prefix'. This method prepends the ns_prefix of its own
 */
static int
internal_set(GlobalNumbers *self, PyObject *namespace, PyObject *to_set)
{
    long offset = 0;
    long raw_type = NO_TYPE;

    namespace = construct_ns(self, namespace);
    if (namespace == NULL) {
        return -1;
    }

    if (ensure_namespace(self, namespace, to_set) == -1) {
        Py_DECREF(namespace);
        return -1;
    }

    get_offset_and_type(self->registry_data, namespace, &offset, &raw_type);
    Py_DECREF(namespace);

    if (set_shared_mem(self->numbers, offset, raw_type, to_set) == -1)
        return -1;
    return 0;
}

PyDoc_STRVAR(set_value_doc, "set_value(namespace, number)");

static PyObject*
GlobalNumbers_set_value(GlobalNumbers *self, PyObject *args)
{

    PyObject *namespace;
    PyObject *to_set;

    if (!PyArg_ParseTuple(args, "OO", &namespace, &to_set))
        return NULL;

    if (internal_set(self, namespace, to_set) == -1) {
        return NULL;
    }

    Py_RETURN_NONE;
}

/* Converts a pointer to a number to the appropiate python type.
 * Returns NULL on Error
 * */
static PyObject *
convert_pointer_to_py(char *pos, long raw_type)
{
    switch (raw_type) {
        case INT_TYPE:
            return PyLong_FromLong(*(long*)pos);

        case UINT_TYPE:
            return PyLong_FromUnsignedLong(*(unsigned long*)pos);

        case LONG_TYPE:
            return PyLong_FromLongLong(*(long long*)pos);

        case ULONG_TYPE:
            return PyLong_FromUnsignedLongLong(*(unsigned long long*)pos);

        case FLOAT_TYPE:
            return PyFloat_FromDouble((double) (*(long long*)pos) / FLOAT_PRECISION);

        default:
            return NULL;
    }
}
/*
 * Read the number from the shared memory and converts it back to a python type.
 * Returns NULL on Error
 */
static PyObject *
read_shm_and_convert_to_py(char * numbers, long offset, long raw_type)
{
    return convert_pointer_to_py(&numbers[offset], raw_type);
}

static PyObject *
internal_get(GlobalNumbers *self, PyObject *namespace)
{

    long offset = 0;
    long raw_type = NO_TYPE;

    namespace = construct_ns(self, namespace);
    if (namespace == NULL) {
        return NULL;
    }

    int ns_in_reg = is_counter_in_registry(self, namespace);
    if (ns_in_reg == -1) {
        Py_DECREF(namespace);
        return NULL;
    }

    if (ns_in_reg == 0) {
        PyErr_Format(
            PyExc_KeyError,
            "Cannot find counter (%s)",
            PyStr_AsString(namespace));
        Py_DECREF(namespace);
        return NULL;
    }

    get_offset_and_type(self->registry_data, namespace, &offset, &raw_type);
    Py_DECREF(namespace);

    return read_shm_and_convert_to_py(self->numbers, offset, raw_type);
}

PyDoc_STRVAR(get_doc,
"get(namespace)"
"namespaces can be an arbitrary string with a maximum length of 1024"
"Returns a number according to the value in shared memory"
);

static PyObject *
GlobalNumbers_get(GlobalNumbers *self, PyObject *namespace)
{
    return internal_get(self, namespace);
}

PyDoc_STRVAR(get_registry_data_doc,
"get_registry_data()"
"Returns a deep copy of the internal registry data PLUS the current value"
"The ret_value is a dictonary with the following format"
"{ 'namespace' : (snmp_type, pretty_name_of_type, offset, current_value) }"
);

static PyObject *
GlobalNumbers_get_registry_data(GlobalNumbers *self)
{
    /* tmp variables needed to iterate over the registry_data*/
    PyObject *key, *value, *ret_dict, *ret_entry, *curr_val;
    Py_ssize_t pos=0;

    long offset;
    long raw_type;

    /* Read the current data of the file */
    if (semaphore_operation(self, SEMAPHORE_LOCK) == -1)
        return NULL;

    if (reread_registry_data(self) == -1) {
        semaphore_operation(self, SEMAPHORE_UNLOCK);
        return NULL;
    }
    semaphore_operation(self, SEMAPHORE_UNLOCK);

    if ((ret_dict = PyDict_New()) == NULL) {
        return NULL;
    }

    while (PyDict_Next(self->registry_data, &pos, &key, &value)) {
        get_offset_and_type(self->registry_data, key, &offset, &raw_type);

        curr_val = read_shm_and_convert_to_py(self->numbers, offset, raw_type);
        ret_entry = Py_BuildValue(
                "(OsOO)",
                PyTuple_GetItem(value, SNMP_TYPE_INDEX),
                INTERNAL_TYPE_AS_STRING[GET_INTERNAL_TYPE(value)],
                PyTuple_GetItem(value, OFFSET_INDEX),
                curr_val);

        /*
         * Py_BuildValue increments the refcount and
         * curr_val is not used here anymore
         */
        Py_XDECREF(curr_val);

        if (ret_entry == NULL) {
            Py_DECREF(ret_dict);
            return NULL;
        }

        PyDict_SetItem(ret_dict, key, ret_entry);
        Py_DECREF(ret_entry);

    }
    return ret_dict;
}

PyDoc_STRVAR(reset_values_doc,
"reset_values()"
"Set all numbers to 0"
);

static PyObject*
GlobalNumbers_reset_values(GlobalNumbers *self)
{
    const size_t shm_size = get_shared_memory_size(self->filename);
    if (shm_size == -1) {
        return NULL;
    }

    if(self->numbers != NULL) {
        memset(self->numbers, 0, shm_size);
    }

    Py_RETURN_NONE;
}

static PyObject*
ensure_type_at_namespace(
        GlobalNumbers *self,
        PyObject *namespace,
        long internal_type_to_ensure)
{
    int ns_in_reg = 0;
    long offset = 0;
    long raw_type = NO_TYPE;


    if (semaphore_operation(self, SEMAPHORE_LOCK) == -1)
        return NULL;

    if (reread_registry_data(self) == -1) {
        semaphore_operation(self, SEMAPHORE_UNLOCK);
        return NULL;
    }
    semaphore_operation(self, SEMAPHORE_UNLOCK);

    if ((ns_in_reg = PyDict_Contains(self->registry_data, namespace)) == -1)
        return NULL;

    if (ns_in_reg == 1) {
        get_offset_and_type(self->registry_data, namespace, &offset, &raw_type);
        if (raw_type != internal_type_to_ensure) {
            return PyErr_Format(
                    PyExc_TypeError,
                    "Namespace already configured but with different type");
        }
    }

    if (ns_in_reg == 0) {
        if (add_namespace(self, namespace, internal_type_to_ensure) == -1)
            return NULL;
    }

    Py_RETURN_NONE;
}

PyDoc_STRVAR(ensure_int_type_doc,
"ensure_int_type(namespace)"
"Registers a int type for the namespace. It is written to the registry file."
"Furthermore space is resevred in the shared memory segment"
);

static PyObject*
GlobalNumbers_ensure_int_type(GlobalNumbers *self, PyObject *namespace)
{
    namespace = construct_ns(self, namespace);
    if (namespace == NULL) {
        return NULL;
    }

    PyObject *ret = ensure_type_at_namespace(self, namespace, INT_TYPE);
    Py_DECREF(namespace);
    return ret;
}


PyDoc_STRVAR(ensure_uint_type_doc,
"ensure_uint_type(namespace)"
"Registers a uint type for the namespace. It is written to the registry file."
"Furthermore space is reserved in the shared memory segment"
);

static PyObject*
GlobalNumbers_ensure_uint_type(GlobalNumbers *self, PyObject *namespace)
{
    namespace = construct_ns(self, namespace);
    if (namespace == NULL) {
        return NULL;
    }

    PyObject *ret = ensure_type_at_namespace(self, namespace, UINT_TYPE);
    Py_DECREF(namespace);
    return ret;
}


PyDoc_STRVAR(ensure_long_type_doc,
"ensure_long_type(namespace)"
"Registers a long type for the namespace. It is written to the registry file."
"Furthermore space is resevred in the shared memory segment"
);

static PyObject*
GlobalNumbers_ensure_long_type(GlobalNumbers *self, PyObject *namespace)
{
    namespace = construct_ns(self, namespace);
    if (namespace == NULL) {
        return NULL;
    }

    PyObject *ret = ensure_type_at_namespace(self, namespace, LONG_TYPE);
    Py_DECREF(namespace);
    return ret;
}


PyDoc_STRVAR(ensure_ulong_type_doc,
"ensure_ulong_type(namespace)"
"Registers a ulong type for the namespace. It is written to the registry file."
"Furthermore space is resevred in the shared memory segment"
);

static PyObject*
GlobalNumbers_ensure_ulong_type(GlobalNumbers *self, PyObject *namespace)
{
    namespace = construct_ns(self, namespace);
    if (namespace == NULL) {
        return NULL;
    }

    PyObject *ret = ensure_type_at_namespace(self, namespace, ULONG_TYPE);
    Py_DECREF(namespace);
    return ret;
}


PyDoc_STRVAR(ensure_float_type_doc,
"ensure_float_type(namespace)"
"Registers a float type for the namespace. It is written to the registry file."
"Furthermore space is resevred in the shared memory segment"
);

static PyObject*
GlobalNumbers_ensure_float_type(GlobalNumbers *self, PyObject *namespace)
{
    namespace = construct_ns(self, namespace);
    if (namespace == NULL) {
        return NULL;
    }

    PyObject *ret = ensure_type_at_namespace(self, namespace, FLOAT_TYPE);
    Py_DECREF(namespace);
    return ret;
}


PyDoc_STRVAR(build_incrementor_doc,
"build_incrementor(ns, to_add)"
"Returns a callable which increments 'ns' by 'to_add' everythime being called."
"This is a *speed* improvement only. Use it in performance critical code."
);

static PyObject*
GlobalNumbers_build_incrementor(GlobalNumbers* self, PyObject* args)
{
    PyObject* namespace;
    PyObject* to_add;
    long offset = 0;
    long raw_type = NO_TYPE;

    if (!PyArg_ParseTuple(args, "OO", &namespace, &to_add)) {
        return NULL;
    }

    namespace = construct_ns(self, namespace);
    if (namespace == NULL) {
        return NULL;
    }

    if (ensure_namespace(self, namespace, to_add) == -1) {
        Py_DECREF(namespace);
        return NULL;
    }

    get_offset_and_type(self->registry_data, namespace, &offset, &raw_type);

    GNIncrementor* gn_inc = PyObject_New(GNIncrementor, &GNIncrementorType);
    if (gn_inc == NULL) {
        Py_DECREF(namespace);
        return NULL;
    }

    /* 'to_add' and 'self' is assigned to 'gn_inc'.
     * => 'gn_inc' has a reference to them => Increment refcount.
     */
    Py_INCREF(to_add);
    Py_INCREF(self);

    gn_inc->gn = self;
    gn_inc->offset = offset;
    gn_inc->raw_type = raw_type;
    gn_inc->to_add = to_add;

    /* No need to INCREF 'namespace'. construct_ns() did this already. */
    gn_inc->namespace = namespace;

    return (PyObject*)(gn_inc);
}


/*
 * Holds pointers to the methods which should be available for the
 * GlobalNumbers object. Link to the docu about its structure
 * http://docs.python.org/release/2.6.6/c-api/structures.html?highlight=pymethoddef#PyMethodDef
 */
static PyMethodDef GlobalNumbers_methods[] = {
    {"increment", (PyCFunction)GlobalNumbers_increment, METH_VARARGS,
      increment_doc},

    {"increment_and_fetch", (PyCFunction)GlobalNumbers_increment_and_fetch, METH_VARARGS,
      increment_and_fetch_doc},

    {"decrement", (PyCFunction)GlobalNumbers_decrement, METH_VARARGS,
      decrement_doc},

    {"decrement_and_fetch", (PyCFunction)GlobalNumbers_decrement_and_fetch, METH_VARARGS,
      decrement_and_fetch_doc},

    {"get", (PyCFunction)GlobalNumbers_get, METH_O,
      get_doc},

    {"get_registry_data", (PyCFunction)GlobalNumbers_get_registry_data, METH_NOARGS,
      get_registry_data_doc},

    {"reset_values", (PyCFunction)GlobalNumbers_reset_values, METH_NOARGS,
      reset_values_doc},

    {"set_value", (PyCFunction)GlobalNumbers_set_value, METH_VARARGS,
        set_value_doc},

    {"ensure_int_type", (PyCFunction)GlobalNumbers_ensure_int_type, METH_O,
        ensure_int_type_doc},

    {"ensure_uint_type", (PyCFunction)GlobalNumbers_ensure_uint_type, METH_O,
        ensure_uint_type_doc},

    {"ensure_long_type", (PyCFunction)GlobalNumbers_ensure_long_type, METH_O,
        ensure_long_type_doc},

    {"ensure_ulong_type", (PyCFunction)GlobalNumbers_ensure_ulong_type, METH_O,
        ensure_ulong_type_doc},

    {"ensure_float_type", (PyCFunction)GlobalNumbers_ensure_float_type, METH_O,
        ensure_float_type_doc},

    {"build_incrementor", (PyCFunction)GlobalNumbers_build_incrementor, METH_VARARGS,
        build_incrementor_doc},

    /* Sentinel Entry */
    {NULL, NULL, 0, NULL}
};

static PyObject *
Globalnumbers_subscript(GlobalNumbers *self, PyObject *namespace)
{
    return internal_get(self, namespace);
}

static int
Globalnumbers_ass_subscript(
        GlobalNumbers *self,
        PyObject *namespace,
        PyObject *to_set)
{
    if (to_set == NULL) {
        PyErr_Format(PyExc_NotImplementedError, "Deletion is not supported");
        return -1;
    }

    /* Typecheck of namespace happens in internal_set. */
    return internal_set(self, namespace, to_set);
}

static PyMappingMethods GlobalNumbers_as_mapping = {
    NULL, /*mp_length*/
    (binaryfunc)Globalnumbers_subscript,
    (objobjargproc)Globalnumbers_ass_subscript
};

/* Allows access to members of the C-Object via ordinary python
 * Check this to understand the fields
 * http://docs.python.org/release/2.6.6/c-api/structures.html#PyMemberDef
 */
static PyMemberDef GlobalNumbers_members[] = {
    {"ns_prefix", T_OBJECT, offsetof(GlobalNumbers, ns_prefix), READONLY, NULL},
    {NULL}  /* Sentinel */
};


static PyTypeObject GlobalNumbersType= {
    PyVarObject_HEAD_INIT(NULL, 0)
    "globalnumbers.GlobalNumbers", /*tp_name*/
    sizeof(GlobalNumbers),     /*tp_basicsize*/
    0,                         /*tp_itemsize*/
    (destructor)GlobalNumbers_dealloc, /*tp_dealloc*/
    0,                         /*tp_print*/
    0,                         /*tp_getattr*/
    0,                         /*tp_setattr*/
    0,                         /*tp_compare*/
    0,                         /*tp_repr*/
    0,                         /*tp_as_number*/
    0,                         /*tp_as_sequence*/
    &GlobalNumbers_as_mapping, /*tp_as_mapping*/
    0,                         /*tp_hash */
    0,                         /*tp_call*/
    0,                         /*tp_str*/
    0,                         /*tp_getattro*/
    0,                         /*tp_setattro*/
    0,                         /*tp_as_buffer*/
    Py_TPFLAGS_DEFAULT | Py_TPFLAGS_BASETYPE, /*tp_flags*/
    GlobalNumbers_doc,         /* tp_doc */
    0,                         /* tp_traverse */
    0,                         /* tp_clear */
    0,                         /* tp_richcompare */
    0,                         /* tp_weaklistoffset */
    0,                         /* tp_iter */
    0,                         /* tp_iternext */
    GlobalNumbers_methods,     /* tp_methods */
    GlobalNumbers_members,     /* tp_members */
    0,                         /* tp_getset */
    0,                         /* tp_base */
    0,                         /* tp_dict */
    0,                         /* tp_descr_get */
    0,                         /* tp_descr_set */
    0,                         /* tp_dictoffset */
    (initproc)GlobalNumbers_init, /* tp_init */
    0,                         /* tp_alloc */
    GlobalNumbers_new,         /* tp_new */
};



PyDoc_STRVAR(GNIncrementor_doc,
"Helper object to achive *very* fast increments of the shared memory"
);

static void
GNIncrementor_dealloc(GNIncrementor* gn_inc)
{
    Py_XDECREF(gn_inc->to_add);
    Py_XDECREF(gn_inc->gn);

    PyObject_Del(gn_inc);
}

static PyObject*
GNIncrementor_call(GNIncrementor* gn_inc, PyObject* args, PyObject* kwargs)
{
    int result = increment_shared_mem(
        gn_inc->gn->numbers,
        gn_inc->offset,
        gn_inc->raw_type,
        gn_inc->to_add);

    if (result == -1) {
        return NULL;
    }

    Py_RETURN_NONE;
}

/* Allow access to the members of the C-Object. */
static PyMemberDef GNIncrementor_members[] = {
    {"namespace", T_OBJECT, offsetof(GNIncrementor, namespace), READONLY, NULL},
    {"to_add", T_OBJECT, offsetof(GNIncrementor, to_add), READONLY, NULL},
    {NULL}
};

static PyTypeObject GNIncrementorType = {
    PyVarObject_HEAD_INIT(NULL, 0)
    "globalnumbers.GNIncrementor",  /* tp_name */
    sizeof(GNIncrementor),          /* tp_basicsize */
    0,                              /* tp_itemsize */
    (destructor)GNIncrementor_dealloc,  /* tp_dealloc */
    0,                              /* tp_print */
    0,                              /* tp_getattr */
    0,                              /* tp_setattr */
    0,                              /* tp_compare */
    0,                              /* tp_repr */
    0,                              /* tp_as_number */
    0,                              /* tp_as_sequence */
    0,                              /* tp_as_mapping */
    0,                              /* tp_hash */
    (ternaryfunc)GNIncrementor_call,    /* tp_call */
    0,                              /* tp_str */
    0,                              /* tp_getattro */
    0,                              /* tp_setattro */
    0,                              /* tp_as_buffer */
    Py_TPFLAGS_DEFAULT,             /* tp_flags */
    GNIncrementor_doc,              /* tp_doc */
    0,                              /* tp_traverse */
    0,                              /* tp_clear */
    0,                              /* tp_richcompare */
    0,                              /* tp_weaklistoffset */
    0,                              /* tp_iter */
    0,                              /* tp_iternext */
    0,                              /* tp_methods */
    GNIncrementor_members,          /* tp_members */
    0,                              /* tp_getset */
    0,                              /* tp_base */
    0,                              /* tp_dict */
    0,                              /* tp_descr_get */
    0,                              /* tp_descr_set */
    0,                              /* tp_dictoffset */
    0,                              /* tp_init */
    0,                              /* tp_alloc */
    0,                              /* tp_new */
};


PyDoc_STRVAR(destroy_resources_doc,
"destroy_resources(filename)"
"Removes all system wide resources (semaphore, shared-mem)"
"associated with filename. NOT the file itself\n."
"IMPORTANT: Ensure that NOBOBDY uses this resources anymore !!!!!!!!"
);

static PyObject *
destroy_resources(PyObject *module, PyObject *filename)
{
    if ((filename = as_ascii_bytes(filename)) == NULL) {
        return NULL;
    }

    int id;
    key_t key = build_key(filename);
    /* remove the semaphore */
    if ((id = semget(key, 1, 0)) != -1) {
        semctl(id, 0, IPC_RMID);
    }

    /* remove the shared memory */
    if ((id = shmget(key, 0, 0)) != -1) {
        shmctl(id, IPC_RMID, NULL);
    }

    Py_DECREF(filename);
    Py_RETURN_NONE;
}


static PyMethodDef globalnumbers_methods[] = {
    {"destroy_resources", destroy_resources, METH_O, destroy_resources_doc},
    /* Sentinel */
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef moduledef = {
    PyModuleDef_HEAD_INIT,  /* m_base */
    "_globalnumbers",       /* m_name */
    globalnumbers_doc,      /* m_doc */
    -1,                     /* m_size */
    globalnumbers_methods,  /* m_methods */
};


MODULE_INIT_FUNC(_globalnumbers)
{

    if (PyType_Ready(&GNIncrementorType) < 0)
        return NULL;

    if (PyType_Ready(&GlobalNumbersType) < 0)
        return NULL;

    PyObject *m = PyModule_Create(&moduledef);
    if (m == NULL)
        return NULL;

    Py_INCREF(&GlobalNumbersType);
    PyModule_AddObject(m, "GlobalNumbers", (PyObject*)&GlobalNumbersType);

    return m;
}
