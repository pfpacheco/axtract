from ._globalnumbers import GlobalNumbers
from ._globalnumbers import destroy_resources


class FakeGlobalNumbers(GlobalNumbers):
    """Fake GlobalNumbers object for cases when the real one cannot be set up

    This class supports all calls that the real GlobalNumbers has, but it does
    not do anything. All values are 0.
    """
    def __init__(self, filename):
        pass

    def __getitem__(self, name):
        return 0

    def __setitem__(self, name, value):
        pass

    def increment(self, arg1, arg2):
        pass

    def increment_and_fetch(self, arg1, arg2):
        return 0

    def get(self, arg1):
        return 0

    def get_registry_data(self):
        return {}

    def reset_values(self):
        pass

    def set_value(self, arg1, arg2):
        pass

    def ensure_int_type(self, arg1):
        pass

    def ensure_uint_type(self, arg1):
        pass

    def ensure_long_type(self, arg1):
        pass

    def ensure_ulong_type(self, arg1):
        pass

    def ensure_float_type(self, arg1):
        pass


def setup_global_numbers(
        registry,
        logger=None,
        ensure_int=None,
        ensure_uint=None,
        ensure_long=None,
        ensure_ulong=None,
        ensure_float=None,
        ns_prefix=''):

    """Set up and return a GlobalNumbers object

    The registry parameter must be the path (relative or absolute) to a
    registry file. If the file does not yet exist, it will be created.

    The logger parameter is a logger as produced by Python's builtin "logging"
    module.

    The ensure_* parameters must be iterables of names for which the given type
    should be ensured. If the names already exist but have a different type, a
    warning will be logged if a logger was given.

    If the setup of the GlobalNumber object fails (failing to ensure_* is _not_
    considered a failure), a mock object is returned instead. Possible failure
    reasons include
        - system ran out of shared memory segments (use "ipcs" and "ipcrm")
        - permission denied for the registry file
        - disk full/read only file system when creating registry file
    For the mock object, all operations succeed, all values are 0 when you ask
    for them.
    """
    try:
        globnum = GlobalNumbers(registry, ns_prefix)

        todo_items = [
            (globnum.ensure_int_type, ensure_int, "signed integer"),
            (globnum.ensure_uint_type, ensure_uint, "unsigned integer"),
            (globnum.ensure_long_type, ensure_long, "signed long"),
            (globnum.ensure_ulong_type, ensure_ulong, "unsigned long"),
            (globnum.ensure_float_type, ensure_float, "floating point")
        ]
        for method, names_to_ensure, log_snippet in todo_items:
            if names_to_ensure:
                for name in names_to_ensure:
                    try:
                        method(name)
                    except Exception:
                        if logger:
                            msg = "Failed to ensure %s type for %s:"
                            logger.exception(msg, log_snippet, name)
    except Exception:
        if logger:
            logger.exception("Failed to set up GlobalNumbers for registry "
                             "file '%s'. You will not get any statistics!",
                             registry)

        globnum = FakeGlobalNumbers(registry)

    return globnum
