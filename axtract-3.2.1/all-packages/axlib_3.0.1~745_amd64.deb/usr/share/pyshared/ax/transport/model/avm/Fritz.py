from ax.utils.parsing.parse_text import get_line_val, parse_timestr
import re
from cgi import escape
import time
from datetime import datetime
from netaddr import IPAddress as IP
from netaddr import IPNetwork, EUI
from ax.transport.model.misc import get_uptime_secs, put
from ax.transport.model.misc import get_ifmap_by_ip
from ax.transport.model.misc import safe_cli_get
from ax.transport.model.keyval import depends, lines
from ax.transport.model.model_support import add_model
from ax.transport.model.model_support import Model

# we work only via these:
DI = '.DeviceInfo.'

class Fritz(Model):
    root = 'D'
    model = 'DEV2'
    # vendor is avm, transport via is FritzHTML:
    matching = 'avm.FritzHTML'

    def mget_fritz(self, t, data, url = None, headers = {}):
        """ convenience wrapper around most common calls """
        res = t.get_fritz(data, url, headers)
        print(res['data'])
        return res

        if t.sid and not 'sid' in data:
            data['sid'] = self.sid
        if not url:
            url = '/cgi-bin/webcm'
        res = self.get(url, data = data, headers = headers)
        if res['status'] == 200:
            logger.info('Got success status')
        return res


    def GPV_DeviceInfo(self, t):
        c = t.session_cache
        import ipdb; ipdb.set_trace()

        c['.RootDataModelVersion'] = '2.6'

        c[DI + 'SupportedDataModel.1.URL'] = 'http://localhost/AVM_2.6.xml'
        c[DI + 'SupportedDataModel.1.URN'] = 'urn:axiros-com:device-2-6-0'
        c[DI + 'SupportedDataModel.1.Features'] = 'AVMHtmlFeatures'

        c[DI + 'Manufacturer'] = 'Avm'
        c[DI + 'ManufacturerOUI'] = '00040E'
        c[DI + 'ProductClass'] = 'AXPAND'
        c[DI + 'SoftwareVersion'] = '1.1'
        # HW model: take the first word in the line after Processor board ID:
        c[DI + 'ModelName'] = 'FritzBox7170'
        c[DI + 'HardwareVersion'] = 'Fritz'
        c[DI + 'Description'] = 'Avm %s IAD Managed By Axiros AXPAND' % 'Fritz'
        c[DI + 'SerialNumber'] = '12345'
        c[DI + 'UpTime'] = 1234
        c['.NSLookupDiagnostics.HostName'] = 'hostname'


add_model(('avm.Fritz', Fritz()))
