class CRC16(object):
    CRC_POLYNOM = 0x8408
    CRC_PRESET = 0xFFFF

    def calcString(self, message):
        crc = self.CRC_PRESET
        i = 0
        while i < len(message):
            crc ^= int(message[i:i+2], 16)
            for j in xrange(8):
                if crc & 0x001:
                    crc = (crc >> 1) ^ self.CRC_POLYNOM
                else:
                    crc = (crc >> 1)
            i += 2
        result = ("0000" + hex((~crc) & self.CRC_PRESET).split('0x')[1])[-4:].upper()
        return result[2:] + result[:2]

