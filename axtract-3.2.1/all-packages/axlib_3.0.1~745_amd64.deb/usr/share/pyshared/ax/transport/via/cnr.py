"""Implementation of a suds based soap interaction """

# Note: basic implementation only, we only return what the soap server
# sent (suds objects for complex objects) w/o further parsing into
# python standard objects.

# but all client.service.<rpc>s can be called.

from ax.transport.base import \
        ErrorConditionException, TransportException
from ax.transport.connected_transport import ConnectedGetter
import socket

class CNR(ConnectedGetter):
    """
    Send a CNR via http or udp
    """

    identification =  "CNR://%(user)s@%(cnr_url)s"
    user = None
    password = None
    cnr_url = None


    def open_connection (self):
        return None

    def communicate(self, cmd, conn_obj, condition,\
            error_condition, timeout, **kwargs):
        if cmd == 'UDP_CNR':
                pass
        elif cmd == 'HTTP_CNR':
                pass
                # send digest authed http cnr


