"""Implementation of a http based interaction """
import logging
from os import environ
import xmlrpclib, httplib

from ax.transport.base import \
        ErrorConditionException, ConnectionClosedException,\
        TransportException, TimeoutException
from ax.transport.connected_transport import ConnectedGetter

logger = logging.getLogger( __name__)

class XMLRPC(ConnectedGetter):
    """
    Using xmlrpclib
    No auth up to now.

    conn_obj = the xmlrpc url
    data = the arguments of an RPC
    """

    identification =  "XMLRPC:%(url)s"
    allowed_args = None
    allowed_cmds = None
    url = None
    user = None
    password = None
    proxy = None

    def close_connection(conn_obj):
        # no need to call close, will result in a method call:
        return

    def open_connection (self):
        if not self.url.startswith('http'):
            self.url = 'http://' + self.url
        proxy = self.proxy or environ.get('http_proxy')
        if proxy:
            if '://' in proxy:
                proxy = proxy.split('://', 1)[1]
            p = ProxiedTransport()
            p.set_proxy(proxy)
            conn_obj = xmlrpclib.Server(self.url, transport=p, allow_none=1)
        else:
            conn_obj = xmlrpclib.Server(self.url, allow_none=1)
        return conn_obj


    def communicate(self, cmd, conn_obj, condition,\
            error_condition, timeout, args=(), **kwargs):
        res = apply(getattr(conn_obj, cmd), args)
        return res


    # this one can deliver jobs:
    def find_job_in_get_result(self, is_job, res, **kwargs):
        return is_job(res, **kwargs)



class ProxiedTransport(xmlrpclib.Transport):
    def set_proxy(self, proxy):
        self.proxy = proxy
    def make_connection(self, host):
        self.realhost = host
        h = httplib.HTTP(self.proxy)
        return h
    def send_request(self, connection, handler, request_body):
        connection.putrequest("POST", 'http://%s%s' % (self.realhost, handler))
    def send_host(self, connection, host):
        connection.putheader('Host', self.realhost)


