#!/opt/axess/bin/call_with_eggs
"""
Example for Model usage. Defined is a model for cisco.IOS
"""

import logging, sys
# set to DEBUG if needed:
logging.basicConfig(level=logging.DEBUG)

from ax.transport import axpand
from ax.utils.tr069 import TR69Utils
from pprint import pformat
# read in all xml definition files:
# root object:
R = 'InternetGatewayDevice'

#IP = 'aida.axiros.com'
IP = '89.181.202.190'

#import pdb; pdb.set_trace()
t = axpand.get_transport_object(
 'cisco.C1861', settings={'via': 'telnet',
                        'user': 'axiros',
                        'password': 'menuth63ecr89eG5',
                        'condition': '>/Z',
                        'host': IP,
                        'port': 23,
                        'allowed_cmds': None,
                        'prolog': "/F:LIB:oa_telnet",
                        'model': 'oneaccess.ONEOS_IGD'
                       })
# direct commands still work:
import pdb; pdb.set_trace() 
res = t.model.GetParameterValues('InternetGatewayDevice.', t)
res = t.model.GetParameterValues('InternetGatewayDevice.X_AXIROS_COM.', t)
res = t.model.GetParameterValues('InternetGatewayDevice.LANDevice.', t)
sc = t.session_cache

print '###########################################################'
print '############# RESULT GPV InternetGatewayDevice. ###########'
print '###########################################################'
print pformat(res)
print '################################'
"""import pdb; pdb.set_trace()
"""

res = t.model.GetParameterValues('InternetGatewayDevice.DeviceInfo.', t)
print '###########################################################'
print '############# RESULT GPV DeviceInfo. ###########'
print '###########################################################'
print pformat(res)
print '################################'
"""import pdb; pdb.set_trace()
"""


print '***'
print '***'
print '***'
print '***'
print '**********************************************'
res = t.model.GetParameterValues('InternetGatewayDevice.Time.Status', t)
print pformat(res)
print '**********************************************'
import pdb; pdb.set_trace()


res = t.model.GetParameterValues('.DeviceConfig.PersistentData', t)
print pformat(res)
res = t.model.GetParameterNames({'NextLevel': False,
            'ParameterPath': 'InternetGatewayDevice.'}, t)
print pformat(res)

res = t.model.GetParameterValues('.', t)
print pformat(res)

    #res = t.model.Upload({'URL': 'tftp://10.11.0.1/foasdfo/basdfar',
#                  'FileType': '1 Vendor Configuration File'}, t)

# that takes ages:
print "skipping reboot"
#res = t.model.Reboot('asdf', t)



res = t.model.SetParameterValues({
'Device.LANDevice.1.LANEthernetInterfaceConfig.2.Enable':\
        '1',
'Device.LANDevice.1.LANHostConfigManagement.IPInterface.2.IPInterfaceIPAddress':\
        '2.11.0.11',
'Device.LANDevice.1.LANHostConfigManagement.IPInterface.2.IPInterfaceSubnetMask':\
        '255.255.255.0'
                                },
                               t)
t.close()


res = t.model.GetParameterValues('.LANDevice.', t)
print pformat(res)

try:
    for k in [
            '.DeviceInfo.',
            '.DeviceInfo.SoftwareVersion',
            '.DeviceInfo.DeviceLog',
            '.'
            ]:
        print "=" * 80
        print "Getting %s" % k
        res = t.model.GetParameterValues(R+ k, t)
        print pformat(res)

finally:
    t.close()
