test_cfg = {'mysql':
            {'user': 'root',
             'password': 'foo',
             'host': '127.0.0.1',
             'port': 3306},
            'axess':
             {'user': 'admin',
              'password': 'ax',
              'host': '127.0.0.1:5673',
              'uri': '/live'
              },
           'snmp':
           {'host': '127.0.0.1'}
        }

# check availability:
import os
# snmp currently excluded after the rewrite too much settings dependence:
if not 'snmp' in os.popen('netstat -uanp | grep :161|grep snmp').read():
    print ('')
    print ("---------------> NO SNMP TESTS " )
    test_cfg['snmp']['unavailable'] = 1

axess = test_cfg['axess']['host'].split(':')
import socket
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.settimeout(0.2)
try:
    sock.connect((axess[0], int(axess[1])))
except:
    print ("---------------> NO AXESS TESTS " )
    test_cfg['axess']['unavailable'] = 1
sock.close()

# test mysql:
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.settimeout(0.2)
try:
    sock.connect((test_cfg['mysql']['host'],
        int(test_cfg['mysql']['port'])))
    cmd = 'mysql -u %s --password=%s -e "show databases"'\
            % (test_cfg['mysql']['user'],
               test_cfg['mysql']['password'])
    res = os.popen(cmd).read()
    if 'denied' in res or not res:
        print ("-------------->Can't log in to Mysql")
        raise Exception()
except Exception as ex:
    print ("---------------> NO MYSQL TESTS " )
    test_cfg['mysql']['unavailable'] = 1

sock.close()











