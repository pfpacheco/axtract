"""Implementation """

import os
import subprocess
from time import time, sleep
from Queue import Queue, Empty
from random import randint
from thread import start_new_thread
from threading import Thread
from ax.utils.redis.client import RedisClient
from ax.transport.connected_transport import ConnectedReceiver

import logging
logger = logging.getLogger(__name__)

DEBUG = 1
class Publisher(ConnectedReceiver, Thread):
    """
    Create a fifo and publish any input to it to a redis server
    """
    # custom writers into the fifo:
    procs   = None
    # redis host
    host    = None
    # a further source of input:
    queues  = None
    # we publish here:
    channel = None
    # publish max 100 messages every 0.2 secs:
    rate    = "100/0.2"
    identification =  "Publisher://%(channel)s-%(host)s"


    def open_connection(self):
        self.buffer = Queue()
        self.fifo   = '/tmp/tmp%s' % time()
        os.mkfifo(self.fifo)
        self.redis = RedisClient(self.host)
        self.procids = {}
        self.max_evs, self.buf_int = [float(a) for a in self.rate.split('/')]
        # we can kill the main queue by sending this:
        self.kill_pill = 'killme_%s' % randint(10, 100000000000)
        return self.redis


    def buffer_publisher(self):
        """ running in a thread, publishing all 0.2 seconds in a pipe """
        pipe = self.redis.pipeline(transaction=False)
        ev = 0
        while not self.shutdown_requested:
            try:
                pipe.publish(self.channel, self.buffer.get(False))
                ev += 1
                if ev < self.max_evs:
                    continue
                logger.warn('Overload, dropping %s events' % \
                            self.buffer.qsize())
                # popping it empty:
                while not self.buffer.empty():
                    self.buffer.get(False)
            except Empty:
                pass
            if ev:
                pipe.execute()
            # sleep in any case:
            sleep(self.buf_int)
            ev = 0

    def add_proc(self, proc):
        """ add a subprocess outputting into the queue, tail -f, tcpflow...."""
        logger.info('Adding process: %s' % proc)
        p = subprocess.Popen(proc.split(), stdout=open(self.fifo, 'w'))
        self.procids[proc] = p.pid

    def stop_proc(self, proc):
        """ kill a subprocess """
        for myproc, pid in self.procids.items():
            if myproc == proc:
                for i in (15, 9):
                    try:
                        os.kill(pid, i)
                    except:
                        pass

    def stop_procs(self):
        """ ending - kill all subprocesses"""
        for proc in self.procids:
            self.stop_proc(proc)


    def main_loop(self):
        start_new_thread(self.buffer_publisher, ())
        for proc in self.procs:
            self.add_proc(proc)
        fifo = os.fdopen(os.open(self.fifo, os.O_RDWR), 'r')
        while not self.shutdown_requested:
            line = fifo.readline().strip()
            if DEBUG:
                logger.debug('fifo input: %s' % line)
            if line == self.kill_pill:
                logger.warn('Main loop got exit signal')
                break
            if line:
                self.buffer.put(line)

    def close(self, conn_obj=None):
        self.stop_procs()
        self.stop_loop()
        self.destroy()

    def destroy(self):
        if os.path.exists(self.fifo):
            os.unlink(self.fifo)

    def stop_loop(self):
        """ dead pill to the event loop """
        if self.is_alive():
            with open(self.fifo, 'w') as f:
                f.write(self.kill_pill + '\n')


    def communicate(self, cmd, conn_obj, condition, error_condition,\
            timeout, **kwargs):
        proc = kwargs.get('proc')
        if proc:
            if cmd == 'add_proc':
                self.add_proc(proc)
                return 'process added: %s' % proc
            elif cmd == 'rem_proc':
                self.stop_proc(proc)
                return 'process killed: %s' % proc
        raise NotImplementedError






