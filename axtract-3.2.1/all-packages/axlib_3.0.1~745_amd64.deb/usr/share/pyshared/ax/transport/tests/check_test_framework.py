import unittest

class t11(unittest.TestCase):
    def setUp(self):
        print "in setup"


    def test_2(self):
        print "test2"



    def test_1(self):
        print "test1"

    def tearDown(self):
        print "in tear down"

if __name__ == "__main__":
    unittest.main()
