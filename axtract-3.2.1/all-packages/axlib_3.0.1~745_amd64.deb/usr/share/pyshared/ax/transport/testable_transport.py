"""
This MixIn for the Getter in base.py is allowing to record and replay communiation
flows against any endpoint - using any transport

Usage:
    in settings supply a testmode parameter like:
        'testmode': 'write: $mpath/94.93.50.30.py'
    or
        'testmode': '$mpath/94.93.50.30.py'

    to record a comm. flow to a file / replay everything back.

    $mpath is being replaced at setup time of a transport like:
       if '$mpath' in tf:
           test_dir = test_dir.replace('$mpath', self.model.get_model_path())
           test_dir = join(test_dir, 'tests/flows_%s_rev%s/' % (self.model_name,
                                                               self.model.rev))


"""
from os.path import join
import time
import logging
from ax.transport.condition_checking  import check_condition

class UntestedFlowException(Exception):
    pass

logger = logging.getLogger(__name__)


class TestConnObj(object):
    pass


class TestableTransport(object):

    def set_testmode(self, settings):
        """ handle transport and model testing """
        from os.path import exists, dirname
        from os import makedirs
        if not ':' in self.testmode:
            self.testmode = 'run:' + self.testmode
        mode, tf = self.testmode.split(':', 1)
        #import ipdb; ipdb.set_trace()

        tf = tf.strip()
        # shortcut to have written to correct location - model and revision:
        test_dir, test_file = tf.rsplit('/', 1)
        if '$mpath' in tf:
            test_dir = test_dir.replace('$mpath', self.model.get_model_path())
            test_dir = join(test_dir, 'tests/flows_%s_rev%s/' % (self.model_name,
                                                                 self.model.rev))
        if not exists(dirname(test_dir)):
            makedirs(dirname(test_dir))

        # on duplicate overwrite if an ! is at the end, else raise:
        test_file = join(test_dir, test_file)

        if '%' in test_file:
            # we support %(host)s and the like:
            test_file = test_file % settings
        if not test_file.endswith('!'):
            if exists(test_file) and 'write' in mode:
                raise Exception("testfile exists at %s" % tf)
        else:
            test_file = test_file[:-1]

        if not test_file.endswith('.py'):
            # better force this, it *is* a py file, so use e.g. syntax highl:
            test_file = test_file + '.py'
        self.testfile = test_file

        logger.log(10, '\n\nRunning in Testmode using file:\n%s\n%s\n%s\n' \
                   % ('-' * 80, self.testfile, '-' * 80))
        if  not 'write' in mode:
            # Run the logic not on the real transport but on the testmap:
            if not getattr(self, 'testmap', None):
                import datetime
                # quiet pyflakes:
                with open(self.testfile) as f:
                    tms = f.read()
                exec("tmo=%s" % tms, locals())
                self.testmap = tmo
            # punch the duck:
            self.do_get = self.get
            self.get    = self.test_reading_get
            # for connected transports we overide it:
            self.open_connection = self.test_open_connection
            return

        # create a testmap - which can be flushed at any point of time:
        self.testmap = {'tests'     : {},
                        'At'        : time.ctime(),
                        'Model'     : self.model_name,
                        'ModelRev'  : str(self.model.rev),
                        'Settings'  : settings,
                        'AXPAND Transport' : '%s' % self}
        self.testcounter = 0
        self.do_get      = self.get
        self.get         = self.test_writing_get


    def test_open_connection(self):
        return TestConnObj()

    def test_reading_get(self, cmd, condition=None, error_condition=None,
            timeout=None, **kwargs):
        """
        this is a the get - if we are in testmode, where we take all results
        from the testmap
        (note: def get was punched to this method)
        """

        #FIXME: we just for now check for the cmd:
        print(('Reading from spec: %s' % cmd))
        if cmd.startswith('/F'):
            # this is a microflow switch -> run it really:
            rs = self.do_get(cmd, condition, error_condition, timeout, **kwargs)
            return rs

        tests = self.testmap.get('tests')
        for k in sorted(tests):
            spec = tests[k]
            if spec['cmd'] == cmd:
                logger.debug('testcase %s' % cmd)
                # now for any next call of the same cmd (which should not happen
                # anyway, because of session cache, we force to find the NEXT
                # one in the tests map. Only if not there we take the original
                # one next time, which will be at the end:
                tests['z_was_run_%s' % k] = spec
                del tests[k]
                res = spec.get('res')
                # check if the condition of the flow would still match:
                cond = condition or self.condition
                if cmd.startswith('model') or cmd.startswith('/'):
                    # res could be not string,
                    # failing the check_condidiont:
                    match = 1
                else:
                    try:
                        match = check_condition(res, cond)
                    except:
                        match = 0

                if not match:
                    raise Exception(
                        "condition '%s' not matching anymore with '%s'"\
                                % (condition, res))

                return res

        if hasattr(self, 'strict_testing'):
            # this is neat when upgrading customers to new models:
            # we can exactly see which flows are not test covered.
            raise UntestedFlowException(
                  "The flow %s is not found in the test map")
        # lets hope the model can cope with that:
        print(('Warning: testcase not found: %s:' % cmd))
        return ''


    def write_testmap(self):
        """ Called from e.g. a GPV in model_support """
        from pprint import pformat
        open(self.testfile, 'w').write(pformat(self.testmap)+'\n')
        print(('testfile written: %s' % self.testfile))



    def test_writing_get(self, cmd, condition=None, error_condition=None,
            timeout=None, **kwargs):
        """ this creates a map of args and results, which can be written to
        any file - and rerun later """
        # do_get set by the one who punched test_writing_get in:
        self.testcounter += 1
        m = self.testmap['tests'][self.testcounter] = {}
        m.update({
                'cmd':              cmd,
                'condition':        condition,
                'error_condition':  error_condition,
                'timeout':          timeout,
                'kwargs':           kwargs,
                })

        res = self.do_get(cmd, condition, error_condition, timeout, **kwargs)
        m['res'] = res
        return res
