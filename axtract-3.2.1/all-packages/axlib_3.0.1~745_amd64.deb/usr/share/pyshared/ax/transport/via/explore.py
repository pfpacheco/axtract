from ax.transport import axpand
from os import listdir
from ax.transport.model.model_support import MODELS, I

from ax.transport.base import ConnectionClosedException, TimeoutException, \
        TooMuchDataException, ErrorConditionException, TransportException
from ax.transport.connected_transport import ConnectedGetter
import socket
import re
from time import time, sleep
from ax.utils.formatting.pretty_print import dict_to_txt
from cgi import escape as esc
from ax.transport.model.model_support import Model, load_model
from ax.utils.tr069.TR69Utils import SHORT69



####################################
#
# Supported:
# cisco: Telnet, user pass and pass only
# onaccess: Telnet
# audiocodes; SSH
#
######################################

MODEL_PREFIXES = 'linux, cisco, audiocodes, oneaccess, patton, axiros'


RE_PROMPT = '(\$|\$ |:|: |#|# |>|> )$'
PROMPT = '|Re: %s' % RE_PROMPT

supported_login_prompts = ['user', 'password', 'login', 'authenticate',
                          ]
def get_tcp_data(host, port, timeout=0.4):
    """ suck the socket empty on connection open """

    data = ''
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    httptest = 'GET / HTTP/1.0\r\n\r\n'
    try:
        sock.settimeout(timeout + 0.1)
        sock.connect((host, port))
        data = sock.recv(1024)
        if not data.strip():
            # does not hurt at first pushing servers and we save time:
            sock.sendall(httptest)
        count = 1
        while 1:
            count += 1
            if count > 100:
                # keeps sending crap. stop.
                break
            #sleep(timeout/0.1)
            incr = sock.recv(1024)
            data += incr
            if not len(incr):
                break
            data_l = data.replace(httptest, '').lower()
            # we know what we support below:
            for prompt in supported_login_prompts:
                for p in [prompt, prompt + ' ', prompt + ':', prompt + ': ']:
                    if data_l.endswith(p):
                        # success, exit:
                        raise Exception()
    except Exception as ex:
        pass
    finally:
        sock.close()
        return data.replace(httptest, '')


def get_greedy(t):
    res = 'xxx'
    counter = 0
    while t.get('') != res:
        counter += 1
        if counter > 10:
            break
    return res




class SocketException(TransportException):
    """ Parent Class for Socket Related Exceptions """
    pass

class BogusSocketException(SocketException):
    """ Bogus Socket Specified (Port not int, host not IP or DNS) """
    err_id = 11010

class SocketClosedException(SocketException):
    """ Socket Not Available"""
    err_id = 11020

class CantOpenTransportException(TransportException):
    """ Transport via could not be instantiated """
    err_id = 12000


class NoTelnetPromptException(CantOpenTransportException):
    """ Socket was open on telnet but nothing received """
    err_id = 12010


class AuthenticationException(CantOpenTransportException):
    """ Parent Class for Auth. Related Exceptions """
    err_id = 13000

class MissingPWException(AuthenticationException):
    """ PW missing in t_type exploration """
    err_id = 13010

class NoSSHCredentialsException(AuthenticationException):
    """ No Username / Password at an SSH via """
    err_id = 13020

class NoUserNameException(AuthenticationException):
    """ Username Prompt but no 'username' Parameter """
    err_id = 13030

class FlowException(TransportException):
    """ Parent Class for Flow Related Exceptions, After Login """
    err_id = 14000

class DeviceTypeDetectionException(FlowException):
    """ Device Type Could Not Be Derived From Testing the
    Protocol Server After Auth. """
    err_id = 14010

class DeviceTypeMismatchException(FlowException):
    """ t_type was Specified But We Found Another One """
    err_id = 14020

class NoModelFoundException(FlowException):
    """
    No Matching Model Could Be Found At a get('model') Flow
    Note: This is no exception if only t_type is queried
    """
    err_id = 14030

class ModelMismatchException(FlowException):
    """ Model Was Specified But We Found Another """
    err_id = 14040

class SerialMismatchException(FlowException):
    """ Serial Number Was Specified But Another One Was Found """
    err_id = 14050

# Vendor Specific Error Codes Follow:
class NoEnablePasswordException(AuthenticationException):
    """ t_type is Cisco But No enable_pass Parameter is Available """
    err_id = 15010


class WrongEnablePasswordException(AuthenticationException):
    """ Cisco Enable Password Was Rejected """
    err_id = 15020

# legacy - same ids:
class CiscoNoEnablePasswordException(NoEnablePasswordException):
    """ t_type is Cisco But No enable_pass Parameter is Available """
    err_id = 15010


class CiscoWrongEnablePasswordException(WrongEnablePasswordException):
    """ Cisco Enable Password Was Rejected """
    err_id = 15020




class DummyConnObj(object):
    def close(self):
        return 'closed'

class Explore(ConnectedGetter):
    host = None
    port = None
    via = None
    t_type = None
    model = None
    user = None
    password = None
    enable_pass = None
    timeout = 0.4
    found_models = None
    cpeid = ''
    banner = ''

    identification = "EXPL://%(host)s:%(port)s/"
    # scan this folder and match in the given order:
    model_prefix = MODEL_PREFIXES
    # match on any:
    root_model = ''

    def open_connection(self):
        # this is to be explored:
        self.via = None
        # we allow to specify a type to speed up things:
        self.t_type = self.settings.get('t_type')
        if self.t_type == 'explore':
            self.t_type = ''
        self.found_params = []
        self.found_models = []
        if not self.model_prefix.strip():
            self.model_prefix = MODEL_PREFIXES
        return DummyConnObj()



    def found(self, key, val=None, t=None):
        if isinstance(key, str):
            key = (key,)
        for k in key:
            if k in self.found_params:
                continue
            if not k in self.found_params:
                self.found_params.append(k)

    def get_found(self):
        ret = {}
        for k in self.found_params:
            ret[k] = getattr(self.t, k, None) or getattr(self, k)
        return ret

    def communicate(self, cmd, conn_obj, condition, err_con, timeout, **kwargs):
        t = self
        details = {}

        if cmd == 'via':
            # find the via
            try:
                t.timeout = float(t.timeout)
            except:
                t.timeout = 2.0
            self.found('timeout')

            try:
                t.port = int(t.port)
                if t.port < 0 or t.port > 65000 or not t.host:
                    raise Exception
            except:
                raise BogusSocketException('host:port = %s:%s' % (t.host, t.port))
            self.found('host')
            self.found('port')

            t1 = time()
            self.banner       = get_tcp_data(t.host, t.port, t.timeout)
            self.banner_upper = self.banner.upper()
            details['Socket check millis'] = time() - t1
            if not self.banner:
                raise SocketClosedException( \
                    'Socket %s:%s not open within %s seconds' % (t.host,
                        t.port, t.timeout))

            pref = 'Transport via'

            if not t.via or t.via == 'explore':
                pref += ' (autodetected)'
                if 'SSH' in self.banner_upper:
                    t.via = 'ssh'

                if re.search(RE_PROMPT, self.banner_upper):
                    t.via = 'telnet'

            ret = {pref: t.via,
                   'Host': t.host,
                   'Port': t.port,
                   'Fingerprint': '...' + esc(self.banner.strip()[-40:])}
            details.update(ret)
            self.found('via')
            return {'msg': 'Socket open: %s' % details, 'status': 0}


        if cmd == 't_type' or cmd == 'model':

            # even if given we try to verify:
            if not t.via or t.via=='explore':
                t.get('via')

            if t.password == None:
                # might be "''" (patton)
                raise MissingPWException

            # try socket first:
            try:
                try_settings = {}
                for k in (
                        'host',
                        'port',
                        'user',
                        'timeout',
                        'password',
                        'enable_pass',
                        'via'):
                    try_settings[k] = getattr(t, k, '')

                if t.via == 'ssh':
                    # ssh via shell:
                    if 'AUDIOCODES' in self.banner_upper:
                        # works only in shell mode:
                        try_settings['invoke_shell'] = 1
                    elif 'CISCO' in self.banner_upper:
                        try_settings['invoke_shell'] = 1

                # if already set, like in a second run:
                try_settings['t_type'] = t.t_type


                # vne

                # CHANGE self.t now to the real one, not the explore one:
                if t.via == 'ssh' or t.via == 'pexpect':
                    # no key auth yet:
                    if not 'user' in try_settings or \
                       not 'password' in try_settings:
                        raise NoSSHCredentialsException(
                                'Need user and password for via type ssh')

                if t.via == 'ssh' or t.via == 'telnet':
                    try:
                        self.t = axpand.get_transport_object(via=t.via,
                                            settings=try_settings)
                    except ConnectionClosedException as ex:
                        if 'incompatible' in str(ex).lower():
                            # we have to swwitch to pexpect:
                            t.via = 'pexpect'

                elif t.via == 'pexpect':
                    try_settings['command'] = 'ssh %(user)s@%(host)s' % \
                                 try_settings
                    try_settings['via'] = 'pexpect'
                    self.t = axpand.get_transport_object(via=t.via,
                                        settings=try_settings)
                    self.found('command')

            except Exception as ex:
                raise CantOpenTransportException(
                        esc('%s - %s' % (ex, type(ex))))
            t = self.t
            t.condition = PROMPT
            t.allowed_cmds = ''
            c = t.session_cache

            try:
                # detected type:
                dt_type = None
                t.entered_username = None
                if t.via == 'ssh':
                    if 'invoke_shell' in try_settings:
                        t.get('/WAIT')

                    # FIXME: ADD MORE:

                    if 'CISCO' in self.banner_upper:
                        dt_type = self.verify_cisco(t)

                    elif 'DEBIAN' in self.banner_upper:
                        dt_type = self.verify_linux(t)

                    elif 'AUDIOCODES' in self.banner_upper:
                        dt_type = self.verify_audiocodes(t)

                    if not dt_type:
                        raise DeviceTypeDetectionException(
                                'Cant detect device type on SSH')

                    if t.t_type and dt_type != t.t_type:
                        raise DeviceTypeMismatchException(
                           'Type mismatch - detected %s, given was %s' % \
                                   (dt_type, t.t_type))
                    t.t_type = dt_type

                if t.via == 'telnet' or t.via == 'pexpect':
                    res_prompt = self.banner
                    try:
                        intro = t.get('/WAIT', self.banner[-30:])
                    except:
                        raise NoTelnetPromptException()

                    if 'user' in res_prompt.lower() or \
                       'login' in res_prompt.lower():
                        # for the prolog:
                        t.entered_username = 1
                        if not t.user:
                            raise NoUserNameException
                        res_user = t.get(t.user)
                        print ('after user: %s!'% res_user)
                    try:
                        res_prompt = t.get(t.password)
                        print ('after pass: %s!'% res_prompt)
                        # seomtimes the welcome banner matches, so read on:
                        res_prompt += t.get('', timeout=min(0.8, self.timeout),
                                condition='thisshouldnevermatch|Meta: /TIMEOUT')
                        foo = res_prompt
                        print ('after wait: %s!'% res_prompt)
                        # seomtimes the welcome banner matches, so read on:

                    except Exception as ex:
                        res_prompt = 'timeout (%s)' % ex

                    for err in ('failure', 'password', 'user', 'timeout'):
                        if err in res_prompt.lower():
                            raise AuthenticationException('%s[%s]' %(err, res_prompt))

                    # analyse t_type on telnet:
                    if res_prompt.endswith('>'):
                        # cisco or oneaccess or patton:
                        dt_type = self.verify_cisco(t)

                    elif res_prompt.endswith('# ') or res_prompt.endswith('$ '):
                        dt_type = self.verify_linux(t, s)

                    elif res_prompt.endswith('#'):
                        dt_type = self.verify_cisco_enabled(t)

                    if not dt_type:
                        import pdb; pdb.set_trace()

                        raise DeviceTypeDetectionException(
                                "Can't detect device type on telnet")

                    if t.t_type and dt_type != t.t_type:
                            raise DeviceTypeMismatchException(
                               'Type mismatch - detected %s, given was %s' % \
                                   (dt_type, t.t_type))
                    t.t_type = dt_type
                    self.found(('newline', 'condition'))

                self.found(('t_type', 'user', 'password',
                            'prolog', 'found_models', 'model'))
                no_mod_ret = {'msg': 'Transport type is: %s.' % t.t_type,
                              'status': 0}



                # we are in with SSH or TELNET.
                # have via and type!

                # try(!) get the model:
                dmodel = ''
                for model_prefix in self.model_prefix.split(','):
                    model_prefix = model_prefix.strip()
                    if not model_prefix:
                        continue
                    for mod_name, obj in MODELS.items():
                        if not obj.matching.startswith(t.t_type):
                            continue
                        if not t.via in obj.matching:
                            continue
                        # in principal this one would work:
                        if not mod_name in self.found_models:
                            self.found_models.append(mod_name)
                        if not self.root_model in obj.model:
                            continue
                        if not mod_name.startswith(model_prefix):
                            continue
                        if not dmodel:
                                dmodel = mod_name
                if not dmodel:
                    # no model available
                    if not cmd == 'model':
                        return no_mod_ret
                    else:
                        raise NoModelFoundException

                t.model = dmodel
                load_model(t)
                dev_info = Model.make_inform(transport=t)
                # no need to push over network:

                details['DeviceInfo (%s)' % dmodel] = dev_info
                d_id = dev_info.get('.DeviceInfo.SerialNumber')
                if self.cpeid and self.cpeid != d_id:
                    raise SerialMismatchException(
                       'Serial mismatch: %s vs %s' % (self.cpeid, d_id))
                t.cpeid = d_id
                self.found('cpeid')


                AXP = {'prolog': t.prolog,
                        'via': t.via,
                        'condition': t.condition,
                        'allowed_cmds': t.allowed_cmds,
                        # better to print escaped, the vias take care to
                        # replace back:
                        'newline': t.newline.replace('\r', '\\r').replace('\n', '\\n'),
                        'model': dmodel,
                           }

                # specials for some vendors:
                if 'invoke_shell' in self.get_found():
                    AXP['invoke_shell'] = t.invoke_shell
                if 'command' in self.get_found():
                    AXP['command'] = t.command
                if 'page_fwd' in self.get_found():
                    AXP['page_fwd'] = t.page_fwd


                return {'model': dmodel,
                        'cpeid': d_id,
                        't_type': t.t_type,
                        'via': t.via,
                        'TR069': dev_info,
                        'AXP': AXP,
                        'status': 0,
                        'msg': 'Success'}


            finally:
                t.close()

    def _get_enable_pw(self, t):
        ep = getattr(t, 'enable_pass', None)
        if ep:
            return ep
        raise NoEnablePasswordException

    def verify_oneaccess(self, t):
        if not "ONE" in t.input_buf:
            return ''
        if t.via == 'telnet':
            t.newline = '\n'
            t.condition = '>/Z'
            t.prolog = '/F:LIB:oa_telnet'
            t.allowed_cmds = ''
            t.t_type = 'oneaccess'
            self.found(('newline', 'condition', 'prolog',
                       'allowed_cmds', 't_type'))
            return 'oneaccess'


    def verify_patton(self, t):
        if t.via == 'telnet':
            sv = t.get('show port ethernet')
            if 'Ethernet Configuration' in sv:
                t.newline = '\r\n'
                t.condition = '#/Z'
                t.prolog = '/F:LIB:patton_telnet_user_pw'
                t.get('enable')
                t.allowed_cmds = ''
                t.t_type = 'patton'
                self.found(('newline', 'condition', 'prolog',
                    'allowed_cmds', 't_type'))
                return 'patton'

    def verify_cisco_enabled(self, t):
        t_type = None
        if t.via == 'telnet':
            t.condition = '#/Z'
        sv = t.get('term len 0')
        sv = t.get('show version')
        if not 'cisco' in sv.lower():
            return
        t.session_cache['show version'] = sv
        t.prolog = '/F:LIB:cisco_direct_ena'
        t.allowed_cmds = ''
        if t.via == 'ssh' or t.via == 'pexpect':
            t.newline = '\n'
            t.condition = ''
        self.found('prolog', 'newline')
        return 'cisco'




    def verify_cisco(self, t):
        t_type = None
        if t.via == 'ssh' or t.via == 'pexpect':
            t.newline = '\n'
        t.condition = '>/Z'
        # no work on patton, but error ends with '>':
        sv = t.get('term len 0')
        if 'Keyword mismatch' in sv:
            # patton ?
            t_type = self.verify_patton(t)
            if t_type:
                return t_type

        sv = t.get('show version')
        if 'cisco' in sv.lower():
            t_type = 'cisco'
        # OA CLI also ends with a '>' - in telnet mode:
        if not t_type and ('ONE' in sv and not 'cisco' in sv.lower()):
            t_type = self.verify_oneaccess(t)
            if t_type:
                # they don't have enable:
                return t_type

        if t_type == 'cisco':
            ep = self._get_enable_pw(t)
            t.session_cache['show version'] = sv

            if t.via == 'ssh' or t.via == 'pexpect':
                t.condition = ''
                t.newline = '\n'
                res = t.get('enable', condition="word:")
                res = t.get(ep, condition="|Re: (>|#)$")
                if not res.endswith('#'):
                    raise WrongEnablePasswordException
                # prolog:
                if t.via == 'pexpect':
                    t.prolog = '/F:LIB:cisco_direct_password'
                else:
                    t.prolog = '/F:LIB:cisco_ssh'
                    self.found('invoke_shell')
            else:
                t.condition = '>/Z'
                t.get('enable', ':')
                res = t.get(ep, '|Re: (>|#)$')

                if res.endswith('>'):
                    raise WrongEnablePasswordException

                # prolog:
                t.prolog = '/F:LIB:cisco_%s_' % t.via
                if t.via == 'telnet':
                    if t.entered_username:
                        t.prolog += 'user_'
                    t.prolog += 'pw'
            t.newline = "\n"
            t.condition = "#/Z"
            t.allowed_cmds = ''
            self.found('enable_pass', 'prolog', 'newline')
            return t_type

    def verify_audiocodes(self, t):
        if t.via == 'ssh':
            #res = t.get('')
            t.condition=""
            ep = self._get_enable_pw(t)
            res = t.get('enable', condition="word: ")
            res = t.get(ep, condition="|Re: (> |# )$")
            if not res.endswith('# '):
                raise WrongEnablePasswordException
            t.prolog = '/F:LIB:ac_ena_ssh'
            t.newline = '\r\n'
            t.allowed_cmds = ''
            t.condition = "# /Z|Re: --MORE--"
            t.page_fwd = '--MORE--'
            t.invoke_shell = 1
            self.found(('enable_pass', 'page_fwd', 'invoke_shell', 'prolog', 'newline', 'condition'))
            return 'audiocodes'


    def verify_linux(self, t):
        t.condition = '|Re: (# |\$ )$'
        sv = t.get('uname -a')
        if 'linux' in sv.lower():
            return 'linux'





def fmt_html(pmap):
    return  dict_to_txt(pmap, fmt = {
        'html': 'ax',
        'styles': {'td': 'report3'}})


def model_ops(s, t, t_type):
    s['t_type'] = t_type
    model = TS.get(t_type, {}).get('model', {}).get(s['root_model'])
    if not model:
        s['details']['model'] = 'no %s model found' % s['root_model']
        return
    model = model()
    model.GPV_DeviceInfo(t)

if __name__ == "__main__":
    from ax.transport import axpand
    s = {'host': '94.93.54.170', 'port': 22, 'via': 'explore', 'user': 'service', 'password': 'service', 'enable_pass': 'pUnt0l@n'}
    t = axpand.get_transport_object('explo', settings = s)
    print (t.get('model'))
