"""Implementation of a http based interaction """
#from ax.transport.base import \
#        ErrorConditionException, ConnectionClosedException,\
#        TransportException, TimeoutException
from ax.transport.connected_transport import ConnectedGetter
from ax.utils.config_mgmt.ConfigManager import get_internal_svc_port
import logging
try:
    import requests
except:
    print ("Can't use http2 transport via - run 'pip install requests'!")

logger = logging.getLogger( __name__)
req = None


HTTP_PROXY = get_internal_svc_port('http_proxy', 8999)
VERBS = ('GET', 'PUT', 'POST', 'DELETE', 'OPTIONS', 'PATCH')

class HTTP2(ConnectedGetter):
    """
    Using urllib2
    """

    identification     = "%(host)s"
    allowed_args       = None
    allowed_cmds       = None
    host               = None
    data               = ''
    #neutralize_scripts = True
    proxy              = None
    user               = None
    password           = None
    get_http_errs      = 1
    verify_ssl         = False
    #prefix_urls        = None
    # umlauts, whatever:
    #handle_unicode     = 'ignore'
    #handle_unicode     = None
    # session id:
    sid                = None

    def open_connection (self):
        if not self.host.startswith('http'):
            if self.verify_ssl:
                # reasonable:
                self.host = 'https://' + self.host
            else:
                self.host = 'http://' + self.host
        if self.host.endswith('/'):
            self.host = self.host[:-1]
        s = requests.Session()
        if self.user and self.password:
            s.auth = (self.user, self.password)
        return s


    def communicate(self, cmd, conn_obj, condition,
            error_condition, timeout, data=None,
            headers={}, **kwargs):
        s = conn_obj
        # like 'GET /foo/bar?fooo=bar'
        verb = cmd.split(' ', 1)
        if len(verb) > 1 and len(verb[0]) < 10 and verb[0] in VERBS:
            meth_s = verb[0].lower()
            cmd    = verb[1].strip()
        else:
            # think empty post at TR-069:
            if data is not None:
                meth_s = 'post'
            else:
                meth_s = 'get'
        meth = getattr(s, meth_s)
        if not cmd.startswith('http'):
            if not cmd.startswith('/'):
                cmd = '/' + cmd
            cmd = self.host + cmd

        r = meth(cmd, verify=self.verify_ssl, data=data)
        status  = r.status_code
        headers = r.headers
        text = r.text
        if type(text) == unicode:
            text = text.encode('utf8')

        return {'status' : status,
                'headers': headers,
                'sid'    : self.sid,
                'data'   : text}

