
from ax1.django_tools import render_request


def render_tom(r, s, ctx, uri, app):
    return "<script>alert('hello');</script> hello "

    tmpl = 'logging/main.html'
    return render_request(r, tmpl, ctx)
