from ax.transport.model.model_support import Model
from ax.transport.model.model_support import add_model
from ax.transport.via.http_tools.cnr_digestauth import AuthDigestClient



class Tools(Model):
    """ Static functions, callable w/o transport """
    root = "D"
    rev  = 1.0
    def CNR(self, server, path, username, password, **kw):
        return str(AuthDigestClient(server, path, username, password, **kw).call())

add_model(('axiros.tools', Tools()),)
