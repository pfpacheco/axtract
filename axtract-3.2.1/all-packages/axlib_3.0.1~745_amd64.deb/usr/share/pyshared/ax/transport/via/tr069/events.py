""" Event Helpers for TR-069 """
from time import time

TR069_EVENTS = {
    1: "1 BOOT",
    0: "0 BOOTSTRAP",
    2: "2 PERIODIC",
    3: "3 SCHEDULED",
    4: "4 VALUE CHANGE",
    5: "5 KICKED",
    6: "6 CONNECTION REQUEST",
    7: "7 TRANSFER COMPLETE",
    8: "8 DIAGNOSTICS COMPLETE",
    10: "10 AUTONOMOUS TRANSFER COMPLETE",
    51: "M Reboot",
    52: "M Scheduled Inform",
    53: "M Download",
    54: "M Upload"
}

import sys; PY2 = sys.version_info[0] < 3
if PY2:
    is_str = lambda s: isinstance(s, basestring)
else:
    is_str = lambda s: isinstance(s, str)

def build_events(events, new_events=None):
    """  Builds event lists out from convenient shortcuts.

    You can specify events like [0, "1 BOOT", {"CommandKey"...}]
    Here we parse that to the proper settings which is list of maps:
    """
    ret = []

    if new_events:
        if is_str(new_events):
            events.append(new_events)
        else:
            events.extend(new_events)

    for ev in events:
        try:
            ev = TR069_EVENTS.get(int(ev))
        except:
            pass

        if is_str(ev):
            evmap = {"CommandKey": str(time()), "EventCode": ev}
        elif isinstance(ev, dict):
            evmap = ev
        else:
            raise Exception("Can't handle event %s" % ev)

        # Ensure that no duplicated events are added
        for ev in ret:
            if ev.get('EventCode') == evmap.get('EventCode'):
                break
        else:
            ret.append(evmap)

    return ret
