from ax.transport.model.keyval import depends
from ax.transport.model.model_support import add_model
from ax.transport.model.protocols.snmp import SNMP

class CMTS(SNMP):
    dev  = 0.1
    model = 'DEV2'
    matching = 'docsis.cmts'

    def Get_Status(self, t, **kwargs):
        """
        given the internal cable modem id as cm_id it
        returns the status of it according to the cmts
        """
        cm_id = kwargs.get('cm_id')
        try:
            cm_id = int(cm_id)
        except ValueError:
            raise ValueError("cm_id needs to be an integer and not %s" %\
                    str(cm_id))
        res = t.get('GET:1.3.6.1.4.1.4491.2.1.20.1.3.1.6.%d' % cm_id)
        if res[0] == 8:
            return 'online'
        elif res[0] == 1:
            return 'offline'
        else:
            return 'other'

    def Get_MAC_Domain_Interface(self, t, **kwargs):
        """
        given the internal cable modem id as cm_id it
        returns the MAC Domain Interface string of it
        """
        cm_id = kwargs.get('cm_id')
        try:
            cm_id = int(cm_id)
        except ValueError:
            raise ValueError("cm_id needs to be an integer and not %s" %\
                    str(cm_id))
        oid = '1.3.6.1.4.1.4491.2.1.20.1.3.1.7.%d' % cm_id
        res = t.get('GET:%s' % oid)
        if res[0] is None:
            raise Exception("%s is invalid on device" % oid)
        oid = '1.3.6.1.2.1.2.2.1.2.%s' % res[0]
        res = t.get('GET:%s' % oid)
        return res[0]

    def Get_DS_Ifname(self, t, **kwargs):
        """
        given a list of integers of downstream channel ids as channel_ids,
        returns a list with the interface names on the cmts
        """
        channel_ids = kwargs.get('channel_ids')
        if not isinstance(channel_ids, list):
            msg = "a parameter called channel_ids of type list is needed"
            raise TypeError(msg)
        res = []
        for ch_id in channel_ids:
            try:
                ch_id = int(ch_id)
            except ValueError:
                msg = "channel id %s is not an integer" % str(ch_id)
                raise ValueError(msg)
            oid = '1.3.6.1.2.1.2.2.1.2.%d' % ch_id
            tmp_res = t.get('GET:%s' % oid)
            res.append(tmp_res[0])
        return res

    def Get_US_Channel_Frequency(self, t, **kwargs):
        """
        given a list of integers of upstream channel ids as channel_ids,
        returns a list with all channel frequencies of the upstream channels
        """
        channel_ids = kwargs.get('channel_ids')
        if not isinstance(channel_ids, list):
            msg = "a parameter called channel_ids of type list is needed"
            raise TypeError(msg)
        res = []
        for ch_id in channel_ids:
            try:
                ch_id = int(ch_id)
            except ValueError:
                msg = "channel id %s is not an integer" % str(ch_id)
                raise ValueError(msg)
            oid = '1.3.6.1.2.1.10.127.1.1.2.1.2.%d' % ch_id
            tmp_res = t.get('GET:%s' % oid)
            try:
                tmp_res = '%.2f' % (float(tmp_res[0]) / 1000000)
            except TypeError:
                tmp_res = None
            res.append(tmp_res)
        return res

    def Get_US_Channel_Width(self, t, **kwargs):
        """
        given a list of integers of upstream channel ids as channel_ids,
        returns a list with all channel width values of the upstream channels
        """
        channel_ids = kwargs.get('channel_ids')
        if not isinstance(channel_ids, list):
            msg = "a parameter called channel_ids of type list is needed"
            raise TypeError(msg)
        res = []
        for ch_id in channel_ids:
            try:
                ch_id = int(ch_id)
            except ValueError:
                msg = "channel id %s is not an integer" % str(ch_id)
                raise ValueError(msg)
            oid = '1.3.6.1.2.1.10.127.1.1.2.1.3.%d' % ch_id
            tmp_res = t.get('GET:%s' % oid)
            try:
                tmp_res = '%.1f' % (float(tmp_res[0]) / 1000000)
            except TypeError:
                tmp_res = None
            res.append(tmp_res)
        return res

    def Get_US_Ifname(self, t, **kwargs):
        """
        given a list of integers of upstream channel ids as channel_ids,
        returns a list with all Interface names of the upstream channels
        """
        channel_ids = kwargs.get('channel_ids')
        if not isinstance(channel_ids, list):
            msg = "a parameter called channel_ids of type list is needed"
            raise TypeError(msg)
        res = []
        for ch_id in channel_ids:
            try:
                ch_id = int(ch_id)
            except ValueError:
                msg = "channel id %s is not an integer" % str(ch_id)
                raise ValueError(msg)
            oid = '1.3.6.1.2.1.2.2.1.2.%d' % ch_id
            tmp_res = t.get('GET:%s' % oid)
            res.append(tmp_res[0])
        return res

    def Get_US_Modulation(self, t, **kwargs):
        """
        given a list of integers of upstream channel ids as channel_ids,
        returns a list with all modulation types of the upstream channels
        """
        channel_ids = kwargs.get('channel_ids')
        if not isinstance(channel_ids, list):
            msg = "a parameter called channel_ids of type list is needed"
            raise TypeError(msg)
        c = {0: None, 1: 'other', 2: 'QPSK', 3: 'QAM16', 4: 'QAM8',
                5: 'QAM32',  6: 'QAM64', 7: 'QAM128'}
        res = []
        for ch_id in channel_ids:
            try:
                ch_id = int(ch_id)
            except ValueError:
                msg = "channel id %s is not an integer" % str(ch_id)
                raise ValueError(msg)
            oid = '1.3.6.1.2.1.10.127.1.1.2.1.4.%d' % ch_id
            _id = t.get('GET:%s' % oid)
            if _id[0] is None:
                tmp_res = 0
            else:
                oid = '1.3.6.1.2.1.10.127.1.3.5.1.4.%s.6' % _id[0]
                value = t.get('GET:%s' % oid)
                if value[0] is None:
                    tmp_res = 0
                else:
                    oid = '1.3.6.1.2.1.10.127.1.3.5.1.4.%s.10' % value[0]
                    tmp_res = t.get('GET:%s' % oid)[0]
                    tmp_res = int(tmp_res)
            tmp_res = c.get(tmp_res, tmp_res)
            res.append(tmp_res)
        return res

    def Get_US_Receive_Power(self, t, **kwargs):
        """
        given a list of integers of upstream channel ids as channel_ids
        and a cable modem id as cm_id,
        returns a list with all receive power values of the upstream channels
        """
        cm_id = kwargs.get('cm_id')
        try:
            cm_id = int(cm_id)
        except ValueError:
            raise ValueError("cm_id needs to be an integer and not %s" %\
                    str(cm_id))
        channel_ids = kwargs.get('channel_ids')
        if not isinstance(channel_ids, list):
            msg = "a parameter called channel_ids of type list is needed"
            raise TypeError(msg)
        res = []
        for ch_id in channel_ids:
            try:
                ch_id = int(ch_id)
            except ValueError:
                msg = "channel id %s is not an integer" % str(ch_id)
                raise ValueError(msg)
            oid = '1.3.6.1.4.1.4491.2.1.20.1.4.1.3.%d.%d' % (cm_id, ch_id)
            tmp_res = t.get('GET:%s' % oid)
            try:
                rec_power = '%.1f' % (tmp_res[0] / 10)
            except TypeError:
                rec_power = None
            res.append(rec_power)
        return res

    def Get_US_SNR(self, t, **kwargs):
        """
        given a list of integers of upstream channel ids as channel_ids
        returns a list with all receive power values of the upstream channels
        """
        channel_ids = kwargs.get('channel_ids')
        if not isinstance(channel_ids, list):
            msg = "a parameter called channel_ids of type list is needed"
            raise TypeError(msg)
        res = []
        for ch_id in channel_ids:
            try:
                ch_id = int(ch_id)
            except ValueError:
                msg = "channel id %s is not an integer" % str(ch_id)
                raise ValueError(msg)
            oid = '1.3.6.1.2.1.10.127.1.1.4.1.5.%d' % ch_id
            tmp_res = t.get('GET:%s' % oid)
            try:
                snr = '%.1f' % (tmp_res[0] / 10)
            except TypeError:
                snr = None
            res.append(snr)
        return res


# -------------------------------Helpers
add_model(('docsis.cmts', CMTS()))

RUN = ""
