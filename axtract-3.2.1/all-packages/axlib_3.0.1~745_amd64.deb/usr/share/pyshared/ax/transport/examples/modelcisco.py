#!/opt/axess/bin/call_with_eggs
"""
Example for Model usage. Defined is a model for cisco.IOS
"""

import logging, sys
# set to DEBUG if needed:
logging.basicConfig(level=logging.DEBUG)

from ax.transport import axpand
from ax.utils.tr069 import TR69Utils
from pprint import pformat
# read in all xml definition files:
TR69Utils.parse_global_properties('/etc/axess/TR69')

# root object:
R = 'Device'

via = 'telnet'
logins = {'telnet': "[R]Username: [S]%(user)s[R]Password: [S]%(password)s[R]>"}
prolog = "/F:" + logins.get(via, '')
prolog += "[S]enable[R]Password: [S]%(enable_pass)s"
prolog += "[R][S]term len 0[R]"

IP = '85.45.12.90'
#import pdb; pdb.set_trace()
t = axpand.get_transport_object(
 'cisco.C1861', settings={'via': via,
                        'user': 'cisco',
                        'password': 'cisco',
                        'enable_pass': 'cisco',
                        'condition': '#/Z',
                        'host': IP,
                        'allowed_cmds': None,
                        'prolog': prolog,
                        'model': 'cisco.C1861'        
                       })
# direct commands still work:
#import pdb; pdb.set_trace()
res = t.model.GetParameterValues('InternetGatewayDevice.', t)
print '###########################################################'
print '############# RESULT GPV InternetGatewayDevice. ###########'
print '###########################################################'
print pformat(res)
print '################################'
import pdb; pdb.set_trace()


res = t.model.GetParameterValues('DeviceInfo.', t)
print '###########################################################'
print '############# RESULT GPV DeviceInfo. ###########'
print '###########################################################'
print pformat(res)
print '################################'
import pdb; pdb.set_trace()


res = t.model.GetParameterValues('.DeviceConfig.PersistentData', t)
print pformat(res)

res = t.model.GetParameterNames({'NextLevel': False,
            'ParameterPath': 'InternetGatewayDevice.'}, t)
print pformat(res)

res = t.model.GetParameterValues('.', t)
print pformat(res)

    #res = t.model.Upload({'URL': 'tftp://10.11.0.1/foasdfo/basdfar',
#                  'FileType': '1 Vendor Configuration File'}, t)

# that takes ages:
print "skipping reboot"
#res = t.model.Reboot('asdf', t)



res = t.model.SetParameterValues({
'Device.LANDevice.1.LANEthernetInterfaceConfig.2.Enable':\
        '1',
'Device.LANDevice.1.LANHostConfigManagement.IPInterface.2.IPInterfaceIPAddress':\
        '2.11.0.11',
'Device.LANDevice.1.LANHostConfigManagement.IPInterface.2.IPInterfaceSubnetMask':\
        '255.255.255.0'
                                },
                               t)
t.close()


res = t.model.GetParameterValues('.LANDevice.', t)
print pformat(res)

try:
    for k in [
            '.DeviceInfo.',
            '.DeviceInfo.SoftwareVersion',
            '.DeviceInfo.DeviceLog',
            '.'
            ]:
        print "=" * 80
        print "Getting %s" % k
        res = t.model.GetParameterValues(R+ k, t)
        print pformat(res)

finally:
    t.close()
