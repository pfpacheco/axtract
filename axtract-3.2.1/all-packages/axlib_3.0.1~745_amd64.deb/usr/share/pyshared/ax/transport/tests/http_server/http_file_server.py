import SimpleHTTPServer
import SocketServer
import sys

# serves the files from the local directory for http testing
try:
    PORT = int(sys.argv[1])
except:
    print "usage: %s <port>" % sys.argv[0]

Handler = SimpleHTTPServer.SimpleHTTPRequestHandler
Handler.do_POST = Handler.do_GET

def my_do_POST(self, *args, **kwargs):
    if 'handle_tr069_inform' in self.path:
        self.send_response( 200 )
        try:
            length= int( self.headers['content-length'] )
            din = self.rfile.read(length)
            if 'ParameterList' in din:
                self.end_headers()
                self.wfile.write(open('./http_server/tr069_inform_response','r').read())
                return
        except:
            pass
        self.send_header( "Content-length", str(0) )
        self.end_headers()
        self.wfile.write( '' )
    else:
        return self.do_GET(*args, **kwargs)

Handler.do_POST = my_do_POST
#Handler.do_GET = my_do_POST
httpd = SocketServer.TCPServer(("", PORT), Handler)

print "serving at port", PORT
httpd.serve_forever()
