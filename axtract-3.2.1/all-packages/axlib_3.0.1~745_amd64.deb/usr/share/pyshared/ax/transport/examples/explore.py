#!/opt/axess/bin/call_with_eggs

from time import time
from ax.transport import axpand

t = axpand.gto(str(time()), settings={'host': '10.0.0.10',
                                      'port': 11112,
                                      'via': 'explore',
                                      'user': 'test',
                                      'enable_pass': 'cisco',
                                      'password': 'test'})

import pdb; pdb.set_trace() 
#t.get('via')
#t.get('t_type')
print t.get('model')


















































































