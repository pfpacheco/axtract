from ax.transport.model.model_support import Model, AX_DI
from ax.utils.parsing.parse_text      import parse
from ax.transport.model.keyval        import depends
from ax.transport.model.model_support import add_model
from ax.transport.model.keyval        import handle_GPN, handle_SPV
from ax.transport.model.keyval        import set_flow



class Static(Model):
    """ acting on a transport having access to a static
    resource of parameters already in the target model"""

    root = "I"
    rev  = 1.0

    def GPV_DeviceInfo(self, t):
        """ will be run at Inform time -> calls GPV, i.e. all params set"""
        depends('GPV', t)

    def GPV(self, t):
        c = t.session_cache
        if hasattr(t, 'ctype'):
            if t.ctype == 'file_tr069':
                parse_tr069_file(t)
                c.update(t.cache_parsed)
        # framework will filter the queried ones:
        return c



    def Reboot(self, command_key, t):
        return



    # ------------------------------------------------------------- SPV Support
    # Instead of just pushing them into the map in one line of code,
    # (overwriting def SetParameterValues in model_support)
    # we do the real thing, like in real transports - using setter function(s)
    # which are run in try mode first for transactional support:


    # this setter handles all, substring match will alwyays be true
    setters = {'SPV_ALL': ['']}

    def SPV_ALL(self, t):
        c = t.session_cache
        params = c['to_set_params']
        for k, v in params.items():
            # that will make the spv framework think this one is not changeable:
            # important for GPNs:
            if k in c['ro_params']:
                continue

            # error markers: the change will fail if the error markers match
            # on the get call.
            # ctx_exit: if we have a fail we leave the context via this cmd:
            set_map = {
                       'error_markers': '',
                       'ctx_exit': '',
                       }

            # affects_params is key for the GPN to autodetect w and r params:
            # could be more for one flow, but we run one by one:
            set_map['affects_params'] = (k, )
            # set_flow will run a get flow with this command on t:
            set_map['flow'] = '/RUNS: model.change(%s, %s)' % (k, v)
            # run it, first in try mode, then real:
            set_flow(set_map, t)

    def change(self, k, v, **kwargs):
        """
        This represents a changing flow run on a transport. Here: trivial.
        called by the setter, to really *do* the change if not in try mode
        """
        t = kwargs['transport']
        # do the change:
        t.session_cache[k] = v
        return 'no error'




# ---------------parse various static sources into a TR style map, incl. event:
def parse_tr069_file(t):
    cp = t.cache_parsed
    if cp:
        return cp
    parsed = parse(t.cache)
    cp['events'] = cp.get('Events', '').strip()
    res = {}
    rec_parse(parsed.get('Parameters'), res, '')
    t.cache_parsed = res


def rec_parse(m, res, prefix):
    """ recursive parse.
        builds a tr style map out of indented subnode style
    """
    if not prefix:
        res['ro_params'] = ro = {}
    else:
        ro = res['ro_params']
    for k, v in m.items():
        kn = '%s.%s' % (prefix, k)
        if isinstance(v, dict):
            rec_parse(v, res, kn)
        else:
            if isinstance(v, str):
                # marked as read only?
                if v.endswith('(r)'):
                    v = v.rsplit('(r)', 1)[0].strip()
                    ro[prefix + '.' + k] = 1
            res[kn] = v





class StaticDev2(Static):
    root = 'D'


add_model(('axiros.static', Static()), ('axiros.static_dev2', StaticDev2()))

