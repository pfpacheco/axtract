# ZODB expternalizations: Send CNR and commyunicate with a worker

from time import time
from simplejson import loads, dumps as Job
from ax.transport.jobs.axp_jobs import push_job


def CNR(c, cid): 
    # fetch the proxy service with that cid and push an Inform job with the settings:
    c = c; SS = c.CPEManager.AXServiceStorage
    try:
        svc = SS.manage_getServices({'cid': cid})[0]
    except:
        return 'not found'

    """ parametrize a tr-069 axpand job """
    cache = svc.cache
    dev_proxy = {}
    dev_proxy.update(svc.getServiceProps())
    del dev_proxy['cache']
    dev_proxy.update(cache['AXP'])
    params =    cache['TR069']
    job = {'cmd': 'run',
           'step': '1',
           'ident': 'tr_%s' % time(),
           'settings': {
                        'root': 'I',
                        'via': 'tr069',
                        'params': params,
                        'events': ['6 CONNECTION REQUEST'],
                        'acs_url': svc.acs}}
    job['settings']['dev_proxy'] = dev_proxy
    # run job on southbound tier:
    push_job('AXP_SB', job)
    return 'Inform being sent to %s' % svc.acs


def activate(c, step, ticket, lastResult, CM=None, TM=None,
             log=None, REQUEST=None):

    # we want to get called directly by the workers:
    reply_url = ('http://127.0.0.1:9672/proxy/CPEManager/'
                 'AXTicketManager/Handlers/Services/activate')


    def get_svc(id):
        """ load service for this ticket """
        ServiceStorage = c.AXServiceStorage
        s = ServiceStorage.manage_getServiceById(ticket.serviceid)
        servicetype = s.servicetype
        return s, servicetype, ServiceStorage


    def build_tr_job(s, jobid, sparams={}):
        """ parametrize a tr-069 axpand job """
        cache = s.getPendingProps().get('cache')
        dev_proxy = cache['AXP']
        params =    cache['TR069']
        params.update(sparams)
        job = {'cmd': 'run',
               'step': 'sb_direct_after_tr069',
               'ident': 'tr_%s' % jobid,
               'settings': {
                    'root': 'I',
                    'via': 'tr069',
                    'params': params,
                    'events': ['6 CONNECTION REQUEST'],
                    'acs_url': s.acsPending}}
        return job



    if step == '0':
        """ triggered on NBI through activation call """
        s, servicetype, AXSS = get_svc(ticket.serviceid)
        # tier change, to SBI:
        # run a explore.get('via') to find the via type:
        ts = time()
        job = \
           {'cmd':     'via',
            'step':    'sb_direct_after_via',
            'ident':   'explore_%s' % ts,
            'settings': {'via':     'explore',
                         'user':    s.userPending,
                         'password':s.passwordPending,
                         'host':    s.hostPending,
                         'port':    s.portPending,
                         'acs':     s.acsPending,
                         'model':   'TI.ti_explorer',
                         'model_prefix':    'TI.',
                         'enable_pass' :     s.enable_passPending
                         },
            'reply_url': reply_url,
            'job_id':    ts,
            'objid':     ticket.ticketid
            }
        # run job on southbound tier:
        push_job('AXP_SB', job)
        return '1', 'AXP_SB'


    """ All Below Happens On Southbound Tier! """
    # We are now on a southbound host, getting results from the worker.
    # 3 direct interaction steps with the SB worker follow:

    if 'sb_direct' in step:
        CM = c.CPEManager; TM = c.AXTicketManager
        ticket = TM.manage_getTicketById(ticket)
        ticket.step = step
        job, res = loads(lastResult)
        ticket.log(4, '%s: %s' % (step, res))

        if res and 'err' in res:
            """ Error in Device Exploration
            ->  Fail the Service AND send a TR-069 Inform
                with failure reason
            """
            msg = res['msg']
            s, servicetype, AXSS = get_svc(ticket.serviceid)
            s.setRealStatus(8, msg)
            AXSS.manage_writeService(s)
            ticket.set_failed(msg)
            TM.manage_writeTicket(ticket)

            # Our DB is up to date, push the Inform now:
            di = 'InternetGatewayDevice.DeviceInfo.'
            ti = {di + 'SerialNumber': 'AXPAND_ERROR',
                  di + 'X_TELECOMITALIA_COM_PreProvisoningFailure': res['err'],
                  di + 'X_TELECOMITALIA_COM_PreProvisoningFailureDescription': msg,
                  }
            tr_job = build_tr_job(s, job['ident'], ti)
            tr_job['settings']['dev_proxy'] = {'via':   'explore',
                                               'model': 'TI.ti_explorer'}
            tr_job['reply_url'] = ''

            # flow w/o reply url -> ending:
            return Job(tr_job)


        TM.manage_writeTicket(ticket)

    if step == 'sb_direct_after_via':
        return Job({'cmd':  't_type',
                    'step': 'sb_direct_after_t_type'})

    if step == 'sb_direct_after_t_type':
        return Job({'cmd':  'model',
                    'step': 'sb_direct_after_model'})

    if step == 'sb_direct_after_model':
        s, servicetype, AXSS = get_svc(ticket.serviceid)
        #
        dev_proxy = {}
        dev_proxy.update(s.getPendingProps())
        dev_proxy.update(res['AXP'])
        # goes over wire:
        dev_proxy['cache'] = ''
        # we store the settings:
        s.cachePending['AXP'].update(res['AXP'])
        s.cachePending['TR069'].update(res['TR069'])
        AXSS.manage_writeService(s)
        tr_job = build_tr_job(s, job['ident'])
        tr_job['settings']['dev_proxy'] = dev_proxy
        tr_job['reply_url'] = reply_url
        tr_job['step'] = 'sb_direct_after_tr69'
        # now triggering the tr-069 flow:
        return Job(tr_job)


 
    if step == 'sb_direct_after_tr69':
        # success, we are through:
        msg = 'Inform sent'
        s, servicetype, AXSS = get_svc(ticket.serviceid)
        s.movePendingPropsToProps()
        s.setRealStatus(1, msg)
        AXSS.manage_writeService(s)
        ticket.set_finished(msg)
        TM.manage_writeTicket(ticket)
        return 'ending flow'


