from netaddr import IPAddress, IPNetwork
import sys
try:
    from ax.tr069.misc import get_tr_time
except:
    def get_tr_time():
        return 'no_tr_time_yet_in_py3'

if sys.version_info[0] < 3:
    from urllib import quote
else:
    from urllib.parse import quote

# -----------  Tools:



def put(cache,
        tr_prefix,
        tr_leaf,
        if_map,
        if_key=None,
        notval='n.a.',
        deflt=None):
    if not if_key:
        if_key = tr_leaf
    val = if_map.get(if_key, deflt)
    if val == None or (notval and val == notval):
        # not insert this one:
        return
    cache[tr_prefix + tr_leaf] = val

def warn(c, issue):
    issues = c.get('issues', [])
    issues.append(issue)

def run_many(t, cmds, sep=';echo SEPARATOR;', split='SEPARATOR'):
    """ run a bunch of commands in one transaction and return
    a tuple with the values
    """
    res = t.get(sep.join(cmds))
    retl = ()
    for part in res.split(split):
        retl += (part.strip(),)
    return retl



def get_ifmap_by_ip(ip, nfos):
    """ return the matching map for an ip, i.e. the one which has that ip in the
    network
    if one is down we continue searching and return it only if no matching
    other is up:
    """
    ret = None
    for name, m in nfos.items():
        if is_ip_in_net(ip, m):
            if m.get('Status'):
                return m
            ret = m
    return ret

def is_ip_in_net(ip, net):
    """ net like a.b.c.d/24 or a.b.c.d/255.255.255.0 or an nfos type map with
    'IP' and 'Netmask'"""
    try:
        if isinstance(net, dict):
            in_ip = net['IP']
            in_net = net['Netmask']
            nets = '%s/%s' % (in_ip, in_net)
            isin = is_ip_in_net(ip, nets)
            if isin:
                return isin
            if net.get('IPSecondary'):
                return is_ip_in_net(ip, {'IP': net['IPSecondary'],
                                         'Netmask': net['NetmaskSecondary']})
        return IPAddress(ip) in IPNetwork(net)
    except:
        return False

def safe_cli_get(t, flow, timeout=None, maxdata=None):
    """ for show log or show run, with danger of condition
    too early found"""
    if maxdata==None:
        maxdata=t.maxdata
    if not timeout:
        timeout = t.timeout
    # safe condition: the full prompt:
    prompt = t.get('').rsplit('\n', 1)[1]
    # strip off prompt and cmd:
    # run takes far longer than startup:
    res= t.get(flow, condition=prompt, timeout=timeout, maxdata=maxdata)
    return res.split(prompt)[0].strip()


def get_uptime_secs(pretty):
    """ often (Cisco, patton),  upt like:
    'Up for 18 days, 14 hours, 37 minutes, 28 seconds'
    (no direct output in seconds as required by TR-069's UpTime, so):

    Note: We need a leading whitespace before the first number!
    """
    secs = 0
    pretty = pretty.lower()
    # unit singular or plural:
    for unit, conv in (
                       (' year', 31536000),
                       (' month', 2678400),
                       (' week', 604800),
                       (' day', 86400),
                       (' hour', 3600),
                       (' minute', 60),
                       (' second', 1)):
        if unit in pretty:
           secs += int(pretty.split(unit)[0].rsplit(' ', 1)[1]) * conv

    return secs


def get_error_line(ress, err):
    for line in ress.split('\n'):
        if err in line:
            return line.strip()
    return err



def handle_Download(params, t):
    return handle_Transfer(params, t, mode='down')


def handle_Upload(params, t):
    return handle_Transfer(params, t, mode='up')


def handle_Transfer(params, t, mode='up'):
    t_start   = get_tr_time()
    url       = params['URL']
    user      = quote(params.get('Username', ''))
    password  = quote(params.get('Password', ''))
    #user = user.replace('@', '_')
    #password = password.replace('@', '_')
    #user = password = 'cazzo'
    file_type = params['FileType']
    file_name = params.get('TargetFileName', '')
    file_size = params.get('FileSize', 0)
    Mode = mode.capitalize()
    config_type = ''
    if 'Configuration File' in file_type:
        config_type = "cfg"
    if 'Firmware Upgrade Image' in file_type:
        config_type = "fw"
    if not config_type:
        raise Exception("9013: Unsupported")

    for prot in ('http', 'tftp', 'ftp'):
        if not url.startswith(prot):
            continue

        # like do_http_cfg_upload:
        meth = getattr(t.model, 'do_%s_%s_%sload' % (prot, config_type, mode), None)
        if not meth:
            raise Exception ("9013: %s unsupported" % prot)


        #If proto is http or ftp and user and password present set url
        if not url.startswith('tftp:') and (user and password):
            if not '@' in url:
                # insert user and pw:
                url = '%s://%s:%s@%s' % (prot, user, password,
                        url.split('//', 1)[1])
        res = meth(
                t,
                url,
                user=user,
                password=password,
                file_type=file_type,
                file_name=file_name,
                file_size=file_size
                )
        if not res:
            res = 0
        return {'Status': res,
                'StartTime': t_start,
                'CompleteTime': get_tr_time()
                }


class NoTemplateFound(Exception):
    pass

def find_affected_templates(self, params):
    """ return all templates which contain min one of the params """
    tpls = []
    all_templates = self.get_templates()
    for p in params:
        have_tpl = 0
        for tpl in all_templates:
            if '(%s)s' % p in getattr(self, tpl):
                tpls.append(tpl[5:])
                param_affected = 1
        if not param_affected:
            raise NoTemplateFound("No template for parameter %s" % p)

    return tpls


