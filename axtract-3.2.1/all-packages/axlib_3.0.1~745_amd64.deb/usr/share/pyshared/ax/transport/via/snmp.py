try:
    from pynetsnmp import netsnmp
except Exception as ex:
    raise Exception(("netnsmp import error: %s."
            " apt-get install python-pynetsnmp?" % ex))
from pynetsnmp.CONSTANTS import ASN_BOOLEAN, ASN_BIT_STR, \
        ASN_INTEGER, ASN_OCTET_STR, SNMP_MSG_GETNEXT, \
        SNMP_MSG_SET, SNMP_MSG_GETBULK, SNMP_MSG_GET, \
        ASN_IPADDRESS

from ctypes import byref
from ax.transport.connected_transport import ConnectedGetter
from ax.transport.base import TransportException, \
        ConnectionClosedException, TimeoutException
import struct
import socket
# timeout for the library is like this * seconds:
TIMEOUT_MULT = 1000000

import logging
logger = logging.getLogger( __name__)

# After one day of intensive testing and debuing,
# a horde of manpower  (Petro, Daniel, Martin and me) were not able to fix the
# multithreading by netsnmp + pynetsnmp in a single process
# => single threaded multi process
import threading
import multiprocessing
_global_process_pool_init_lock = threading.RLock()
_global_process_pool = None

class SNMPSetErrorException(TransportException):
    """SNMP Set failed"""
    err_id = 18800

class TransportConnection(object):
    """This class is returned to ax.transport and simulates a connection"""
    def __init__(self, cmd_line_args, settings):
        self.cmd_line_args = cmd_line_args
        self.settings = settings

    def close(self):
        pass

class SNMPSession(netsnmp.Session):
    def _readable_result(self, result):
        if result == None or result == []:
            return None
        temp = {}
        if isinstance(result, dict):
            result = result.items()
        for key, value in result:
            temp['.'.join(str(k) for k in key)] = value
        return temp

    def _is_in_subtree(self, root, node):
        for i in xrange(len(root)):
            if root[i] != node[i]:
                return False
        return True

    def _get_next(self, oid):
        req = self._create_request(SNMP_MSG_GETNEXT)
        return self._send_snmp(req, [oid])

    def _send_snmp(self, request, oids):
        reqid = request.contents.reqid
        for oid in oids:
            oid = netsnmp.mkoid(oid)
            netsnmp.lib.snmp_add_null_var(request, oid, len(oid))
        response = netsnmp.netsnmp_pdu_p()
        while 1:
            if netsnmp.lib.snmp_synch_response(self.sess, request, byref(response)) == 0:
                if response.contents.reqid == reqid:
                    result = dict(netsnmp.getResult(response.contents))
                    netsnmp.lib.snmp_free_pdu(response)
                    return result
                else:
                    # the device sends a response for another request
                    # this must be ignored
                    continue
            else:
                err_no = self.sess.contents.s_snmp_errno
                if err_no == netsnmp.SNMPERR_BAD_VERSION:
                    raise Exception('Wrong SNMP version used for %s' % str(oids))
                elif err_no == netsnmp.SNMPERR_TIMEOUT:
                    raise TimeoutException('Received a timeout for %s' % str(oids))
                else:
                    raise Exception('Received error code %s for %s' % \
                            (str(err_no), str(oids)))
                # tiemout
                return None


    def _bulk_get(self, oids, nonrepeaters=0, maxrepetitions=10):
        req = self._create_request(SNMP_MSG_GETBULK)
        req.contents.errstat = nonrepeaters
        req.contents.errindex = maxrepetitions
        return self._send_snmp(req, oids)

    def bulk_get(self, oids, nonrepeaters=0, maxrepetitions=10):
        result = self.bulk_get_map(oids, nonrepeaters, maxrepetitions)
        if result is None:
            return None
        oids = sorted(result.keys(), cmp=self._oid_cmp)
        temp = []
        for oid in oids:
            temp.append(result[oid])
        return temp

    def bulk_get_map(self, oids, nonrepeaters=0, maxrepetitions=10):
        result = self._bulk_get(oids, nonrepeaters, maxrepetitions)
        return self._readable_result(result)

    def get_map(self, oids):
        result = self._get(oids)
        return self._readable_result(result)

    def _get(self, oids):
        req = self._create_request(SNMP_MSG_GET)
        return self._send_snmp(req, oids)

    def get(self, oids):
        result = self._get(oids)
        if not result or result.values()[0] is None:
            return result
        temp = []
        for oid in oids:
            temp.append(result[oid])
        return temp

    def _walk(self, root):
        results = []
        oid = root
        last_oid = root
        #check if the given oid is an leaf
        get_result = self._get([oid])
        if not get_result: #timeout
            return None
        #node not known on client:
        elif get_result.values()[0] is None:
            getnext_result = self._get_next(oid)
            #there is no next oid
            if getnext_result == None:
                return None
            oid, value = getnext_result.items()[0]
            # the next oid is not in the same table
            if not self._is_in_subtree(root, oid):
                return get_result
            else:
                results.append((oid, value))
        else:
            results.append(get_result.items()[0])
        while 1:
            getnext_result = self._get_next(oid)
            if getnext_result is None:
                return None
            oid, value = getnext_result.items()[0]
            #end of MIB
            if oid == last_oid:
                return results
            else:
                last_oid = oid
            #end of subtree
            if not self._is_in_subtree(root, oid):
                return results
            else:
                results.append(getnext_result.items()[0])

    def _oid_cmp(self, oid1, oid2):
        oid1 = [int(num) for num in oid1.split('.')]
        oid2 = [int(num) for num in oid2.split('.')]
        for i in xrange(min(len(oid1), len(oid2))):
            if oid1[i] < oid2[i]:
                return -1
            elif oid1[i] > oid2[i]:
                return +1
        if len(oid1) < len(oid2):
            return -1
        else:
            return +1

    def _bulk_walk(self, root, nonrepeaters=0, maxrepetitions=10):
        oid = [root]
        results = []
        oid_text = '.'.join([str(num) for num in root])
        while 1:
            oids = []
            # get maxrepetitions number of oids values
            get_results = self.bulk_get_map(oid, nonrepeaters, maxrepetitions)
            if not get_results:
                if results != []:
                    return results
                else:
                    return None
            # check which ones are on the wanted table
            for oid, value in get_results.items():
                if oid.startswith(oid_text + '.'):
                    oids.append(oid)
            # sort them and add them to results
            oids = sorted(oids, cmp=self._oid_cmp)
            wanted_oids = 0
            for oid in oids:
                results.append((oid.split('.'), get_results[oid]))
                wanted_oids += 1
            # check if it is a leaf
            if wanted_oids == 0 and len(results) == 0:
                simple_get_result = self.get_map([root])
                if not simple_get_result:
                    return None
                else:
                    return [(root, simple_get_result.values()[0])]
            # if wanted_oids is not equal to number of the
            # returned results from the bulk_get we stop
            if wanted_oids != len(get_results.keys()):
                break
            else:
                oid = [[int(num) for num in oid.split('.')]]
        return results

    def walk_map(self, root):
        results = self._walk(root)
        if results == None:
            return None
        if results == []:
            return {}
        return self._readable_result(results)

    def bulk_walk_map(self, root, nonrepeaters=0, maxrepetitions=10):
        results = self._bulk_walk(root, nonrepeaters, maxrepetitions)
        if results == None:
            return None
        if results == []:
            return {}
        return self._readable_result(results)

    def walk(self, root):
        results = self._walk(root)
        if not results:
            # None or []:
            return results
        temp = []
        results = self._readable_result(results)
        oids = sorted(results.keys(), cmp=self._oid_cmp)
        for oid in oids:
            temp.append(results[oid])
        return temp

    def bulk_walk(self, root, nonrepeaters=0, maxrepetitions=10):
        results = self._bulk_walk(root, nonrepeaters, maxrepetitions)
        if not results:
            # None or []:
            return results
        return [value for oid, value in results]

    def set(self, var_list):
        req = self._create_request(SNMP_MSG_SET)
        for oid, val, val_type in var_list:
            oid = netsnmp.mkoid(oid)
            if val_type == 'INTEGER':
                val_type = ASN_INTEGER
                try:
                    val = struct.pack("=i",int(val))
                except ValueError:
                    return 'value needs to be an integer for type INTEGER'
                size = 4
            elif val_type == 'BIT_STR':
                val_type = ASN_BIT_STR
                size = len(val)
            elif val_type == 'OCTET_STR':
                val_type = ASN_OCTET_STR
                size = len(val)
            elif val_type == 'BOOLEAN':
                val_type = ASN_BOOLEAN
                size = 1
            elif val_type == 'IPADDRESS':
                val = socket.inet_aton(str(val))
                val_type = ASN_IPADDRESS
                size = 4
            else:
                return 'Unknown type %s for oid %s' % (val_type, oid)
            netsnmp.lib.snmp_pdu_add_variable(req, oid, len(oid),
                    val_type, val, size)
        response = netsnmp.netsnmp_pdu_p()
        if netsnmp.lib.snmp_synch_response(self.sess, req,
                byref(response)) == 0:
            if str(response.contents.errstat) != '0':
                raise SNMPSetErrorException('Error code %s' %\
                        str(response.contents.errstat))
            result = netsnmp.getResult(response.contents)
            netsnmp.lib.snmp_free_pdu(response)
            return self._readable_result(result)

def _call_snmp(cmd, fake_conn, condition, error_condition):
    conn_obj = SNMPSession(fake_conn.cmd_line_args, **fake_conn.settings)
    conn_obj.open()
    try:
        return _dosnmp(cmd, conn_obj, condition, error_condition)
    finally:
        conn_obj.close()


def _dosnmp(cmd, conn_obj, condition, error_condition):
    if not error_condition:
        error_condition = ''
    try:
        snmp_cmd, args = cmd.split(':', 1)
    except:
        # convenience, get is default:
        return _dosnmp('get:%s' % cmd, conn_obj, condition,
                error_condition)

    snmp_cmd = snmp_cmd.upper()
    args = args.replace(' ', '')
    oids = []
    if snmp_cmd == 'SET':
        # cmd like: set: oid1:value1:type1, oid2:value2:type2,...
        # types could be INTEGER, BIT_STR, OCTET_STR, BOOLEAN
        # (currently no ':' and ' ' in vals possible)
        for arg in args.split(','):
            if not arg:
                continue
            oid, val, val_type = arg.split(':')
            oid = tuple(map(int, oid.strip('.').split('.')))
            oids.append((oid, val, val_type))
    elif 'BULK' in snmp_cmd:
        # bulk_get, bulk_get_map,
        # bulk_walk, bulk_walk_map
        # cmd like: cmd: oid1,oid2,oid3:non-repeaters:max_repetitions
        try:
            temp_oids, non_repeaters, max_repetitions = args.split(':')
        except ValueError:
            if len(args.split(':')) != 4:
                non_repeaters = 0
                max_repetitions = 10
                temp_oids = args.split(':')[0]
            else:
                raise Exception('provide the command like: oid1,oid2,oid3:non-repeaters:max_repetitions')
        try:
            non_repeaters = int(non_repeaters)
            max_repetitions = int(max_repetitions)
        except ValueError:
            raise Exception('non-repeaters and max_repetitions must be integers')
        for oid in temp_oids.split(','):
            oid = tuple(map(int, oid.strip('.').split('.')))
            oids.append(oid)
    else:
        # get, get_map, walk, walk_map,
        # cmd like: get: 1.3.6.1.2, ...:
        get_args = ()
        for arg in args.split(','):
            if not arg:
                continue
            get_args += (arg, )
        oids = [tuple(map(int, oid.strip('.').split('.'))) \
                for oid in get_args]

    if snmp_cmd == 'GET':
        res = conn_obj.get(oids)
        if res == None:
            raise Exception('Uncaught error while quering for %s' % str(oids))
        elif isinstance(res, dict):
            value = res.values()[0]
            res = [value]

    elif snmp_cmd == 'GET_MAP':
        res = conn_obj.get_map(oids)
        if res == None:
            raise Exception('Uncaught error while quering for %s' % str(oids))

    elif snmp_cmd == 'BULK_GET':
        res = conn_obj.bulk_get(oids, non_repeaters, max_repetitions)
        if res == None:
            raise Exception('Uncaught error while quering for %s' % str(oids))

    elif snmp_cmd == 'BULK_GET_MAP':
        res = conn_obj.bulk_get_map(oids, non_repeaters, max_repetitions)
        if res == None:
            raise Exception('Uncaught error while quering for %s' % str(oids))

    elif snmp_cmd == 'WALK':
        res = conn_obj.walk(oids[0])
        if res == None:
            raise Exception('Uncaught error while quering for %s' % str(oids))

    elif snmp_cmd == 'WALK_MAP':
        res = conn_obj.walk_map(oids[0])
        if res == None:
            raise Exception('Uncaught error while quering for %s' % str(oids))

    elif snmp_cmd == 'BULK_WALK':
        res = conn_obj.bulk_walk(oids[0], non_repeaters, max_repetitions)
        if res == None:
            raise Exception('Uncaught error while quering for %s' % str(oids))

    elif snmp_cmd == 'BULK_WALK_MAP':
        res = conn_obj.bulk_walk_map(oids[0], non_repeaters, max_repetitions)
        if res == None:
            raise Exception('Uncaught error while quering for %s' % str(oids))

    elif snmp_cmd == 'SET':
        res = conn_obj.set(oids)
        if res == None:
            raise Exception('Uncaught error while quering for %s' % str(oids))

    else:
        raise TransportException\
            ("SNMP command %s unknown. Supported " % snmp_cmd.lower()\
            + "commands are: get, get_map, walk, "\
            + "walk_map, bulk_get, bulk_get_map, "\
            + "bulk_walk, bulk_walk_map, set")

    return res


class PyNetSnmp(ConnectedGetter):
    """ Python pynetsnmp telnetter"""
    identification = "snmp_v2://%(peername)s/"

    test_node = None
    # if a node is not supportable, like starting not with 1 we want Exc:
    error_condition = 'client_unknown_node'
    condition = ''
    host = None
    peername = None
    community = 'public'
    timeout = 1
    version = 1
    add_settings = {}
    localname = None
    local_port = 0
    use_multiprocessing = True

    # WARNING: It is imposible to change the pool_size after the first call into
    # this transport. The process_pool is only created *once*.
    multiprocessing_poolsize = 32

    def open_connection(self):
        self.host = self.peername or self.host

        # if no community and version are given assume public and v2c
        # make the timeout in seconds if given
        # because of a bug in pynetsnmp we need to pass the localname
        # and local_port as a cmdline parameter
        if self.localname:
            tpl = '-Yclientaddr=%s:%s'
            cmd_line_args = [tpl % (self.localname, self.local_port)]
        else:
            cmd_line_args = ()

        settings = self._build_settings()
        if self.use_multiprocessing:
            conn_obj = TransportConnection(cmd_line_args, settings)
        else:
            conn_obj = SNMPSession(cmd_line_args, **settings)
            conn_obj.open()

        if self.test_node:
            # Raise error already on connect time
            self.communicate('get:%s' % self.test_node, conn_obj)

        return conn_obj

    def _build_settings(self):
        settings = {
            'community': self.community,
            'peername': self.peername or self.host,
            'timeout': int(self.timeout * TIMEOUT_MULT),
            'community_len': len(self.community),
            'version': self.version}

        if self.add_settings:
            settings.update(self.add_settings)
        return settings

    def communicate(
            self,
            cmd,
            conn_obj,
            condition=None,
            error_condition=None,
            timeout=None,
            **kwargs):

        if self.use_multiprocessing:
            pool = self._get_process_pool()
            args = (cmd, conn_obj, condition, error_condition)
            return pool.apply(_call_snmp, args)
        else:
            return _dosnmp(cmd, conn_obj, condition, error_condition)

    def _get_process_pool(self):
        global _global_process_pool
        if _global_process_pool is None:
            with _global_process_pool_init_lock:
                if _global_process_pool is None:
                    # Will fail if /dev/shm is not mounted
                    try:
                        size = self.multiprocessing_poolsize
                        _global_process_pool = multiprocessing.Pool(size)
                    except OSError as e:
                        if e.errno == 38:
                            raise Exception("/dev/shm not mounted")
                        raise
        return _global_process_pool


if __name__ == "__main__":
    import os
    import sys
    ns = os.popen('netstat -uanp |grep :161|grep snmp').read()
    if not 'snmp' in ns :
        print ("No snmp agent running on this machine, exitting")
        sys.exit(1)
    rec = PyNetSnmp()
    rec.peername = '127.0.0.1'
    rec.timeout = 5
    rec.connect()
    # 'The MIB module for managing IP and ICMP implementations'
    assert 'ICMP' in rec.get('get: 1.3.6.1.2.1.1.9.1.3.6')[0]
    print ("basic snmp tests succesfully run")
