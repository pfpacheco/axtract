from logging import getLogger
from ax.registry import get_store, get_collection_modes, set_config
from ax.eventing.events import coll_event_factory_from_cpe
from ax.utils.ax_tree.ax_tree import AXTree
from ax.registry.configmanager import ConfigManager
from ax.eventing.event_destinations import EventDispatcher
from itertools import chain

class EventToAxtract(object):
    def __init__(self):
        name = 'SML_Axtract'
        self.logger = getLogger("%s.%s" % (__name__, name))
        cm = ConfigManager()
        config = cm.get_config('/opt/axtract/full_config.json')
        set_config(config)
        mode_store = get_collection_modes()
        sml_queue = [('sml_stats', ['sml_to_queue'])]
        mode_dest = chain(mode_store.yield_destinations(), sml_queue)
        self.event_dispatcher = EventDispatcher(mode_dest)

    def create_event(self, cpeid, props):
        cpe_store = 'cpe_store'
        mode_name = 'sml_stats'
        event_source_name = 'sml_receiver'

        cpe = get_store(cpe_store).get_cpe_by_crit(**{'_id': cpeid})
        if cpe is None:
            self.logger.debug('CPE \'%s\' not found' % cpeid)
            return
        event = coll_event_factory_from_cpe(cpe,
                **{ 'mode': mode_name,
                    'event_source': event_source_name,
                    'raw': {},
                    'props': props,
                    'metadata': {}})

        self.logger.debug("Created event:%s", event)
        self.event_dispatcher.send(cpe.mode, event)
