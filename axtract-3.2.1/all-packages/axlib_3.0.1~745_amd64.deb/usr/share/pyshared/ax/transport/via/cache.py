"""Implementation of cache  which reads in from a location and provides in
   memory or physical ops (cmds) """

# but all client.service.<rpc>s can be called.

from ax.transport.base import \
        ErrorConditionException, ConnectionClosedException
from ax.transport.connected_transport import ConnectedGetter
import logging
logger = logging.getLogger( __name__)

class Cache(ConnectedGetter):
    """
    Cache. Multipurpose with ctype and other arguments.
    Connection Object a closable thing like the cache file
    self.cache has the content.

    self.cache_parsed is after parsing into the target format
    """
    source = ''
    identification =  "AXCACHE://%(source)s"
    allowed_args = None
    allowed_cmds = None
    # this is our cache
    cache = None
    cache_parsed = None
    # a hint for the open_connection where to get it from.
    # if it contains 'file' we open a file.
    ctype = None
    persistent = None


    def open_connection(self):
        # parsing is up to the model:
        self.cache_parsed = {}
        if self.ctype and 'file' in self.ctype:
            f = open(self.source, 'r')
            self.cache = f.read()
            #remember that close is called on the conn_obj anyway.
            return f
        return self.cache


