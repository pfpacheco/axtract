#!/opt/axess/bin/call_with_eggs
"""
Example for Model usage. Defined is a model for cisco.IOS
"""

import logging, sys
# set to DEBUG if needed:
logging.basicConfig(level=logging.DEBUG)

from ax.transport import axpand
from ax.utils.tr069 import TR69Utils
from pprint import pformat
# read in all xml definition files:
TR69Utils.parse_global_properties('/etc/axess/TR69')

# root object:
R = 'Device'

via = 'telnet'
logins = {'telnet': "[R]Username: [S]%(user)s[R]Password: [S]%(password)s[R]>"}
prolog = "/F:" + logins.get(via, '')
prolog += "[S]enable[R]Password: [S]%(enable_pass)s"
prolog += "[R][S]term len 0[R]"

IP = '10.11.0.10'

t = axpand.get_transport_object(
 'cisco.IOS', settings={'via': via,
                        'user': 'test',
                        'password': 'test',
                        'enable_pass': 'cisco',
                        'condition': '#/Z',
                        'host': IP,
                        'allowed_cmds': None,
                        'prolog': prolog
                       })
# direct commands still work:
import pdb; pdb.set_trace() 
res = t.get('show version\n')
res = t.model.GetParameterValues('.DeviceInfo', t)

# here the TR-069 RPCs:
#res = t.model.Download({'URL': 'http://10.11.0.1:8000/demo-cpe-01-confg',
#                        'TargetFileName': 'foo2',
#                        'FileType': '1 Vendor Configuration File'}, t)
print res
res = t.model.GetParameterValues('.DeviceConfig.PersistentData', t)
print pformat(res)

res = t.model.GetParameterNames({'NextLevel': False,
            'ParameterPath': 'InternetGatewayDevice.'}, t)
print pformat(res)

res = t.model.GetParameterValues('.', t)
print pformat(res)

res = t.model.Upload({'URL': 'tftp://10.11.0.1/foasdfo/basdfar',
                      'FileType': '1 Vendor Configuration File'}, t)

# that takes ages:
print "skipping reboot"
#res = t.model.Reboot('asdf', t)



res = t.model.SetParameterValues({
'Device.LANDevice.1.LANEthernetInterfaceConfig.2.Enable':\
        '1',
'Device.LANDevice.1.LANHostConfigManagement.IPInterface.2.IPInterfaceIPAddress':\
        '2.11.0.11',
'Device.LANDevice.1.LANHostConfigManagement.IPInterface.2.IPInterfaceSubnetMask':\
        '255.255.255.0'
                                },
                               t)
t.close()


res = t.model.GetParameterValues('.LANDevice.', t)
print pformat(res)

try:
    for k in [
            '.DeviceInfo.',
            '.DeviceInfo.SoftwareVersion',
            '.DeviceInfo.DeviceLog',
            '.'
            ]:
        print "=" * 80
        print "Getting %s" % k
        res = t.model.GetParameterValues(R+ k, t)
        print pformat(res)

finally:
    t.close()
