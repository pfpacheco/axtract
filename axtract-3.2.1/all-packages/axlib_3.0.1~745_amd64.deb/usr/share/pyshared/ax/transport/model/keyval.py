""" Tools for key/value style working with a legacy CPE

Note: Maps have no order, we are free regarding when to fetch and set keys.

However, keys are related to contexts and the art is to do the right thing
at the right time, not wasting resources.

"""
from ax.transport.base import TransportException
import logging
from ax.utils.six import string_types
import sys; PY2 = sys.version_info[0] < 3
logger = logging.getLogger( __name__)


class SPVException(TransportException):
    er_id = 50001

class InvalidArguments(TransportException):
    er_id = 50002

def lines(l):
    return l.splitlines()

def indizes(node, pmap):
    ret = ()
    for key in pmap:
        if key.startswith(node):
            index = int(key.split(node)[1].split('.', 1)[0])
            if not index in ret:
                ret += (index,)
    return ret


def depends(dependencies, t, timeout=None):
    """ helper to not run comm flows more then once
    dependencies can be methods in the model or get cmds
    """
    c = t.session_cache
    if isinstance(dependencies, string_types):
        dependencies = (dependencies,)

    for dep in dependencies:
        if not c.get(dep):
            meth = getattr(t.model, dep, None)
            if meth:
                res = meth(t)
            else:
                if timeout:
                    res = t.get(dep, timeout=timeout)
                else:
                    res = t.get(dep)
            if res == None:
                res = 1
            c[dep] = res
    #convenience if just one dep:
    return c[dep]


def clear_cache(t):
    # clear called methods from c:
    t.session_cache.clear()

def clear_GPVs(t):
    c = t.session_cache
    for k, v in list(c.items()):
        if k.startswith('GPV_'):
            del c[k]


def get_map(keys, t):
    """ We consolidate the access to key values by flows we need to run,
        We do not run more than needed

        $t is the transport
        $model is a static module or class providing
            - contexts
            - access methods
            - parsers
        model is normally an attribute of t
        c will hold the final result dict
    """
    model = t.model
    c = t.session_cache

    all_GPV_meths = []
    for meth in dir(model):
        if meth.startswith('GPV_'):
            all_GPV_meths.append(meth)
    # find the matching flow, we have _ in the methods no dots:
    for key in keys:
        xkey = key.split('.')
        for i in range(len(xkey)):
            if xkey[i].isdigit():
                xkey[i] = 'x'
        xkey = 'GPV' + '_'.join(xkey)
        orig_xkey = xkey
        counter = 0
        while 1:
            counter += 1
            if counter > 100:
                raise Exception("Excessive recursion trying to find GPVs for %s"
                               % keys)
            found = find_GPV_methods(xkey, all_GPV_meths, model, orig_xkey)
            if not found:
                # deviceinfo.softwareversion in keys, run deviceinfo:
                # method not found, try a node before:
                xkey = '_'.join(xkey.split('_')[:-1])
                if xkey == 'GPV':
                    # maximaly reduced and not GPV_ method given in the model:
                    # -> DONT run it. key could be e.g .MS. - why run GPV(I.)
                    break
            else:
                for getter in found:
                    if not getter in c:
                        # run it:
                        t.info('running %s' % getter)
                        res = getattr(model, getter)(t)
                        # c it:
                        if not res:
                            res = 1
                        c[getter] = res
                break



def find_GPV_methods(xkey, all_GPV_meths, model, orig_xkey):
    # we search for a fitting method:
    #if xkey in all_GPV_meths:
    #    # direct match, cool:
    #    return (xkey,)
    if xkey == 'GPV_':
        return all_GPV_meths
    res = ()
    if xkey.endswith('_'):
        xkey = xkey[:-1]
    if orig_xkey.endswith('_'):
        orig_xkey = orig_xkey[:-1]
    if xkey == 'GPV':
        # this is from node reduction, not directly called I.
        # (GPV, not GPV_)
        # NOT run ALL if not a def GPV is defined:
        if not 'GPV' in all_GPV_meths:
            return res

    for getter in all_GPV_meths:
        # try all nodes below, but only if in the original key
        # if we did not reduce it to higher levels:
        if getter.startswith(xkey) and \
                (orig_xkey.startswith(getter) or orig_xkey == xkey):
            res += (getter,)
    return res


def handle_GPV(tr_params, t):
    """
    build a return map for tr params queried ready for forwarding to ACS
    First fill all with cd values (cpe.props)
    Then run the flows, using get_map
    Then kick out not queried params.

    hot_params: just gotten parameters, dont' need to get again
    (like from inform_params)

    w/o it we pretty much call the get_map method alone, w.o any logic:
    """
    c     = t.session_cache
    model = t.model

    # c is always dotted, tr_params anything.
    if not tr_params:
        return {}
    if isinstance(tr_params, string_types):
        tr_params = (tr_params,)

    root_queried = '.' in tr_params

    # call the transport method:
    get_map(keys=tr_params, t=t)

    # invalid ? we just check the result for occurrence of all params:
    try:
        ret_str = str(c)
    except Exception as ex:
        ret_str = str(c, encoding='utf-8')
    """
    # we DONT verify anymore the existence of the called
    params. Makes no sense in proxy use cases.
    for pn in tr_params:
        if not pn in ret_str:
            raise Exception(pn)
    """
    # kick out the not queried ones:
    res = {}
    for pn in tr_params:
        for k in c:
            # don't deliver .AxirosAxess params if not explicitely
            # queried:
            if k.startswith(pn):
                val = c.get(k)
                if not (root_queried and 'AxirosAxess' in k):
                    res[k] = c.get(k)
    return res




def get_error_line(ress, err):
    for line in ress.split('\n'):
        if err in line:
            return line.strip()
    return err




def set_flow(set_map, t):
    """ called by the model, when running a chaning device interaction
    we accept error markers to see if the flow failed and context
    exit commands.
    """
    c = t.session_cache
    flow, affects_params, error_markers, ctx_exit = \
            (set_map.get('flow'),
             set_map.get('affects_params', ()),
             set_map.get('error_markers', ()),
             set_map.get('ctx_exit', ())
             )

    if isinstance(affects_params, string_types):
        affects_params = (affects_params,)
    if isinstance(error_markers, string_types) and error_markers != '':
        error_markers = (error_markers,)
    if isinstance(ctx_exit, string_types):
        ctx_exit = (ctx_exit,)

    to_set_params = c['to_set_params']
    # here we store what was set:
    have_set_params = c['have_set_params']
    # we first check if the params are settable via this:
    try_mode = c.get('spv_try_mode')

    if not try_mode:
        try:
            # run the change:
            res = t.get(flow)

            if error_markers:
                if PY2:
                    ress = unicode(res)
                else:
                    ress = str(res)
                for em in error_markers:
                    if em in ress:
                        err_line = get_error_line(ress, em)
                        # ERROR!
                        # leave the context:
                        for cmd in ctx_exit:
                            t.get(cmd)
                        # raise:
                        raise Exception("Device error: %s" % err_line)
        except Exception as ex:
            msg = '%s (while trying set %s via: %s)' % (
                ex,
                affects_params,
                flow)
            logger.exception(msg)
            raise SPVException(msg)

    for p in affects_params:
        if p in list(to_set_params.keys()):
            have_set_params.append(p)


def invalid_args_fault(msg, rollback_on_fail, t):
    c = t.session_cache
    if rollback_on_fail:
        handle_SPV(c['original_values'], t, in_rollback=1)
    raise InvalidArguments(msg)


def handle_SPV(to_set_params, t, in_rollback=None):
    """
        Set with roll back on fail!

        $to_set_params: dotted map
        $t is the transport
    """
    if not to_set_params:
        return 1


    model = t.model
    c = t.session_cache
    setters = list(model.setters.items())
    # remember what was set in this run:
    c['to_set_params'] = to_set_params
    have_set_params = []
    c['have_set_params'] = have_set_params

    for try_mode in (True, False):

        rollback_on_fail = False
        if not try_mode:
            if c.get('GPNMode'):
                # GPN mode only with try mode:
                return

            if not in_rollback:
                rollback_on_fail = True

        c['spv_try_mode'] = try_mode
        c['have_set_params'] = have_set_params = []

        for key in list(to_set_params.keys()):
            if key in have_set_params:
                continue

            val = to_set_params[key]

            for setter, subs in setters:
                for sub in subs:
                    if sub in key:
                        try:
                            res = getattr(model, setter)(t)
                        except SPVException as ex:
                            # no need for rollback here:
                            invalid_args_fault(str(ex), rollback_on_fail, t)

        if list(to_set_params.values())[0] in ('AddObject', 'DeleteObject'):
            return res

        # Have all been set?
        for key in list(to_set_params.keys()):
            if not key in have_set_params:
                # not set flow was run for that key:
                if not c.get('GPNMode'):
                    invalid_args_fault(key, rollback_on_fail, t)

        if try_mode:
            # read all values
            get_map(list(to_set_params.keys()), t)
            orig_values = {}
            # c filled, remember state for rollback:
            for k in list(to_set_params.keys()):
                # all should b e in the c, through the GPVs done in SPVs
                orig_values[k] = c[k]
            c['original_values'] = orig_values

    commit_fun = getattr(model, 'commit_changes', None)
    if commit_fun and not in_rollback:
        try:
            model.commit_changes(t)
        except Exception as ex:
            invalid_args_fault('could not commit', rollback_on_fail, t)

    # finally update the c:
    c.update(to_set_params)







def handle_GPN(start_node, next_level, t):
    """
    returns like:
        {
        .DeviceConfig. : False
        .DeviceConfig.ConfigFile : True
        .DeviceInfo. : False
        .DeviceInfo.Description : False
        .DeviceInfo.DeviceLog : False
        .DeviceInfo.HardwareVersion : False
        }
    Strategy:
    We run ALL GPVs, change ALL of them in an SPV in try_mode and see
    whats there in have_set_params ;-)
    """
    c = t.session_cache
    handle_GPV([start_node,], t)
    spv = {}
    res = {}
    for k, v in list(c.items()):
        # some flows might only set if there is a change in params
        # so give it the change:
        if not k.startswith('.'):
            continue
        # now change all - in 'GPN Mode', i.e. not really change them:
        res[k] = False
        try:
            spv[k] = float(v) + 1
        except Exception as ex:
            spv[k] = 'GPN: ' + ( unicode(v) if PY2 else str(v) )
    c['GPNMode'] = 1
    try:
        handle_SPV(spv, t)
    except Exception as ex:
        logger.exception('SPV failure trying to find GPN writables')
    else:
        for key in c['have_set_params']:
            res[key] = True
    finally:
        del c['GPNMode']

    # only return what was queried:
    ret = {}
    if next_level in ('False', '0', 0):
        next_level = False
    len_start = len(start_node)
    for k, v in list(res.items()):
        if not k.startswith(start_node):
            continue
        if not next_level:
            # all :
            ret[k] = v
        else:
            next_node = k[len_start:].split('.', 1)[0]
            if start_node + next_node == k:
                ret[k] = v
            else:
                ret[start_node + next_node + '.'] = False

    return ret

