import unittest2
from ax.transport.model.tests.test_models import ModelTests
"""
class Cisc1oTests(ModelTests):
    # run tests only for models matching:
    modelmatch = 'cisco'
"""
