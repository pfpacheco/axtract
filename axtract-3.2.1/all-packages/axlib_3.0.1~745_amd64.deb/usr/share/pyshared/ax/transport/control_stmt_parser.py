import logging
logger = logging.getLogger( __name__)
from ax.transport.microflows import run_microflow
from ax.utils.dynamic_objects.dyn_code import run_exec_command
from ax.utils.sub_proc_runner import start_flow_capt, get_proc_res
from ax.utils.formatting.pretty_print import repl_unprintable
from ax.transport.tools import \
        TransportException, EXT_CODE_ENV, load_uri_with_env
from time import sleep



"""
Called from base.get if the cmd starts with a /
We assume this is then an indictation to check for axpand
control statements:

"""

# For a frequent test, don't want to instantiate all the time:
_params_key_or_none = (['params'], [])

def parse_ctrl(t, cmd, condition, error_condition, timeout, **kwargs):
    """
    parse the cmd, check for control tags, starting with '/'
    and act accordingly
    """
    logger.debug('process control statement %s', cmd)
    wait = noerr = do_ret = None

    # '/' -> Control cmd (probably):

    if cmd.startswith('/F:'):
        do_ret = run_microflow(t, t.get, cmd[3:], **kwargs)

    elif cmd.startswith('/EXEC:'):
        # we shall execute a function:
        cmd = cmd[6:].strip()
        """Special command: Do not send to CPE, but 'exec' instead.
            Inside the 'exec', the command may call code that was loaded via
            t.do_load_ext_uri().
            The executed code will have access to the following variables:
                - $handler, $transport, $spec, $ret_map, re (the module)
                - the exception classes defined by the telnetter and the
                    flow handler
                - everything loaded via 'ext_uri' commands
                - __builtins__ which are provided magically by Python
            The command may e.g. be "Exec: transport.read_until('abc')" to
            just read until the other side sends "abc".
        """
        exec_globals = {'transport': t, 'self': t}
        exec_globals.update(EXT_CODE_ENV)
        do_ret = run_exec_command(cmd, exec_globals)
        if not do_ret:
            do_ret = ''

    elif cmd.startswith('/LOAD'):
        # Special command: Load external URI to get command flow extensions
        uri = cmd.split(':', 1)[1].strip()
        load_uri_with_env(uri, t)
        do_ret = ''

    elif cmd.startswith('/EXC:'):
        # client wants us to throw an excpeption of a certain type:
        # e.g. in a micro flow
        ename = cmd[5:].strip() + 'Exception'
        etype = globals().get(ename, EXT_CODE_ENV.get(ename))
        if not etype:
            raise TransportException(
                "Could not raise %s - it's not known" % ename)
        raise etype

    elif cmd.startswith('/FLOW'):
        # start tcpflowing or fetch result:
        if cmd.startswith('/FLOWRES'):
            capt_proc_id = t.flow_capt_proc_id
            if not capt_proc_id:
                do_ret = "no capture was running"
            else:
                if cmd.replace(' ', '').startswith('/FLOWRES:close'):
                    # not have the close stop the proc:
                    t.flow_capt_proc_id = 0
                    t.close()
                    t.flow_capt_proc_id = capt_proc_id
                do_ret = get_proc_res(capt_proc_id)
                t.flow_capt_proc_id = 0
        else:
            # this won't work w/o host and port, i.e. for
            # connected transports only anyway - and there
            # they are closed in def close if not stopeed by
            # get_proc_res:
            if hasattr(t, 'is_connected'):
                t.flow_capt_proc_id, do_ret = start_flow_capt(t)
            else:
                do_ret = "capturing works only for connected transports"


    elif cmd.startswith('/RUN'):
        # /RUNS: or /RUN:
        mode, cmd = cmd.split(':', 1)
        cmd = cmd.strip()
        if mode == '/RUNS':
            # simply run a function, pass params as
            # one string to parse:
            # like: /RUN: setDHCPServer(1.2.3.4, 24)
            # only string params, see tests:
            if '(' in cmd:
                cmd, params = cmd.split('(', 1)
                cmd = cmd.strip()
                params = params.rsplit(')', 1)[0].strip().split(', ')
            else:
                # /RUNS: foo (where foo was set previously)
                # pass cmd through:
                params = None
        else:
            # normal case with /RUN: params = ():
            params = kwargs.get('params', ())

        # maybe a callable wants the transport
        # -> client has to supply 'transport' in params[0]
        t_repl = ''
        if params and params[0] == 'transport':
            params = (t, ) + tuple(params[1:])
            t_repl = 'params'
        # here we put it in anyway:
        if not 'transport' in kwargs:
            kwargs['transport'] = t
            t_repl += 'kwargs'

        # fun within t or at a subobj, like model:
        fun = getattr(t, cmd, None)
        if not fun:
            if '.' in cmd:
                # subobject:
                fun = t
                for part in cmd.split('.'):
                    fun = getattr(fun, part, None)
                    if not fun:
                         raise TransportException(
                            "%s not found" % cmd)
        # run it:
        if params is not None:
            # lets see how the function is signatured:
            try:
                do_ret = fun(*params, **kwargs)
            except TypeError as ex:
                do_ret = fun(*params)

            if not do_ret:
                do_ret = ''

            # replace back, no obj refs into params and kwargs,
            # they might be persisting in the client:
            if t_repl:
                if 'params' in t_repl:
                    params = ('transport', ) + tuple(params[1:])
                if 'kwargs' in t_repl:
                    try:
                        del kwargs['transport']
                    except Exception:
                        pass


    elif cmd.startswith('/SET'):

        logger.debug(cmd)
        # set a value into the transport:
        if not '=' in cmd:
            cmd += '=1'

        var, val = cmd.split(':', 1)[1].split('=', 1)
        var  = var.strip()
        val  = val.strip()

        if 'SETFLOAT' in cmd:
            val = float(val)

        elif 'SETINT' in cmd:
            val = int(val)

        elif 'SETREPL' in cmd:
            val = repl_unprintable(val)

        setattr(t, var, val)
        do_ret = ''

    elif cmd.startswith('/UNSET:'):
        logger.debug(cmd)
        try:
            delattr(t, cmd[7:].strip())
        except Exception:
            pass
        do_ret = ''

    elif cmd.startswith('/GETOBJ'):
        attr = cmd.split(':', 1)[1].strip()
        do_ret = getattr(t, attr, None)

    elif cmd.startswith('/GET'):
        attr = cmd.split(':', 1)[1].strip()
        do_ret = str(getattr(t, attr, ''))

    elif cmd.startswith('/WAIT'):
        wait = True
        if ':' in cmd:
            sleeptime = float(cmd.split(':')[1].strip())
            sleep(sleeptime)
            do_ret = 'waited %s' % sleeptime

    elif cmd.startswith('/NOERR:'):
        logger.debug(cmd)
        noerr = True
        cmd = cmd[7:].strip()

    elif cmd.startswith('/IF:'):
        logger.debug(cmd)
        cond, cmd = cmd[4:].split(':')
        do_run_cmd = None
        if not '=' in cond:
            if getattr(t, cond.strip(), None):
                do_run_cmd = 1
        else:
            var, val = cond.split('=', 1)
            if str(getattr(t, var.strip(), None)) == str(val.strip()):
                do_run_cmd = 1
        if do_run_cmd:
            cmd = cmd.strip()
            do_ret = None
        else:
            cmd = ''
            do_ret = ''

    return cmd, do_ret, wait, noerr

