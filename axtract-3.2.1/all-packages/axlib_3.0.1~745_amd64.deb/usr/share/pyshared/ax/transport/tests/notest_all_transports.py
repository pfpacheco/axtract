#!/opt/axess/bin/call_with_eggs

"""
The tests are white (unit) AND black (use case) box tests.

We work with a multithreaded socket server on the other side,
which understands various control commands, like sleep or echo.

Furhter we set up a http server, serving various files configured
in its set up routine (for testing soap, http and tr069 transports).

In the test_cfg module we check for available other services and skip
tests accordingly via appropriate skip decorators if not available.
"""
import logging
logging.basicConfig(level=logging.DEBUG)

from ax.transport.tests.cfg_test_all_transports import test_cfg
from ax.transport.via_transport_group import OutOfTransportsException

from thread import start_new_thread
from pprint import pformat
# for the server process:
import subprocess
# to test if server is up:
import socket
# parsing the xml files for the cpe tests:
import traceback
import sys, os

sys.path.append('.')
from ax.utils.tr069 import TR69Utils
from ax.utils.tr069.TR69Utils import SHORT69
try:
    TR69Utils.parse_global_properties('/etc/axess/TR69',
            ['TR69.xml', 'axiros.xml'])
except Exception as ex:
    print ("Could not find/parse the property files")

import pprint
from random import randint
from time import sleep, time

USER = 'user'
from ax.utils import package_home
tests_dir = package_home(globals())
echo_server_prog = tests_dir + '/echo_socket_server.py'
from ax.transport.flow_handling import run_cmd_flow, try_line_parsing
from ax.transport.transport_access import get_transport_object
from ax.transport.transport_access import get_settingsmap_by_cpe_props
from echo_socket_server import ThreadedMyTCPHandler, SETUPS

from ax.transport.via.soap import SOAPClient
from ax.transport.via.tcp_socket import PythonSocketTelnetter
from ax.transport.via.pexpecter import PexpectTelnetter
from ax.transport.via.popen import Popen
from ax.transport.via.telnet_lib import PyTelnetLib
from ax.transport.via.snmp import PyNetSnmp
from ax.transport.condition_checking import CONDITION_PARSER_CACHE
from ax.transport.condition_checking import CONDITION_OBJ_CACHE
from ax.transport.condition_checking import check_condition
from ax.utils.dynamic_objects.dyn_code import CODE_CACHE
from ax.utils.dynamic_objects.dyn_code import invalidate_cache
from ax.utils.dynamic_objects.dyn_code import set_global_code_cache_size
from ax.transport.transport_access import  OBJ_POOLS

from ax.transport.base import ConnectionClosedException
from ax.transport.base import ErrorConditionException
from ax.transport.base import TimeoutException
from ax.transport.base import TooMuchDataException
from ax.transport.base import STACK_TRACE_GET_EXCEPTIONS
from ax.transport.base import SecurityException

from ax.transport.connected_transport import  PrologException

import unittest2

# other tests are changing this and don't reset:
set_global_code_cache_size(10000)


# This would be the way to have a global setup and teardown method
# for functional tests (e.g. to kill servers which take long time to
# start...:
# see: http://pypi.python.org/pypi/zope.testrunner/
class ServerUsingLayer:
    def setUp(cls):
        setUp = classmethod(setUp)

    def tearDown(cls):
        tearDown = classmethod(tearDown)


# for the test server communication get a port range which is not in use:
in_use = os.popen('netstat -tan').read()
while 1:
    startport = randint(200, 500)
    if not str(startport) in in_use:
        break
# we will count up by 1 from here:
global commport
commport = startport * 100
print ('Startport is %s' % commport)

server_proc = None

def start_echo_server(setup = 'default', port = 0):
    """ Starting a test server if not running
    We start at random ports to avoid socket waiting times
    after exceptions
    """
    global server_proc
    server_proc = subprocess.Popen(["python", "-tt", echo_server_prog,
        "%s" % port, "%s" % setup], shell=False)
    # it needs time to start:
    ts = time()
    while time() - ts < 2:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.1)
        s.bind(('127.0.0.1', 0))
        try:
            s.connect(('127.0.0.1', int(port)))
            sleep(0.01)
            return
        except:
            sleep(0.01)
    raise Exception ("Server could not start at port %s" % port)

def shutserver():
    # killall servers. For a speed up put this into the layer setup:
    for to_kill in ('echo_socket_server', 'http_file_server'):
        for l in os.popen('ps ax |grep %s' % to_kill).read().split('\n'):
            l = l.strip()
            pid = l.split(' ',1)[0]
            if not pid:
                continue
            cmd = 'kill %s' % pid
            #print (cmd)
            os.popen(cmd + " 2>/dev/null").read()
    subprocess.call(["kill", "-9", "%d" % server_proc.pid])




def create_transport ( transport_class):
    """ straight forward transport instantiation """
    global commport
    t = transport_class()
    port = commport
    # PythonSocketTelnetter == transport_class did not work:
    tstr = str(transport_class)
    if 'PythonSocketTelnetter' in  tstr or 'PyTelnetLib' in tstr:
        t.host = '127.0.0.1'
        t.port = port
    elif 'PexpectTelnetter' in tstr:
        t.command = 'netcat 127.0.0.1 %s' % port
        t.newline = '\n'
    elif 'PyNetSnmp' in tstr:
        t.host = '127.0.0.1'
    return t


def get_a_transport( search_folders = None, setup='default',
        poolsize = None, add = {}):
    """ getting a transport using the factory """
    global commport
    m = {'via': 'ax.transport.via.tcp_socket.PythonSocketTelnetter',
            'host': '127.0.0.1', 'port': commport}
    if setup == 'cisco':
        m['condition'] = '#/Z'
        m['prolog'] = ('/F:[R]Username: [S]user[R]Password: [S]pass[R]'
                '>[S]enable[R]Password: [S]cisco[R]#')

    elif setup=='default':
        m['condition'] = '$ /Z'
        m['prolog'] = '/F:[R]Login: [S]user[R]$ '
        m['epilog'] = 'exit'
    m['poolsize'] = poolsize
    m.update(add)
    m['via_class_search_folders'] = search_folders
    return get_transport_object(setup, m['via'], settings = m)


class ServerStarter (unittest2.TestCase):
    tm = None
    epilog = 'exit'
    prompt1 = None
    LS = None
    setup_name = 'default'

    def setUp(self, do_create_transport = 1):
        #if 'PopenTests' in str(self):
        global commport
        # can't get a bind for the server w/o that, 
        # don't know how to unbind:
        commport += 1
        print ("server port: %s, %s" % (commport, self.setup_name))
        start_echo_server(setup = self.setup_name, port = commport)
        self.tm = SETUPS[self.setup_name]
        self.prompt1 = self.tm.get('prompt1')
        self.LS = self.tm.get('LS')
        if do_create_transport:
            self.t = create_transport(self.transport)
            if '-v' in sys.argv:
                # only stack traces on 
                self.t.dbg_cli = STACK_TRACE_GET_EXCEPTIONS
            self.t.condition = self.LS + self.prompt1
            self.t.timeout = 1
        OBJ_POOLS.clear()


    def tearDown(self):
        shutserver()
        OBJ_POOLS.clear()


class SocketTelnetterConnect (ServerStarter):
    transport = PythonSocketTelnetter

    def establish_connection(self):
        self.t.connect()
        return self.tm.get('LoginMsg')



    def test_connect_establish(self):
        """Testing connection establishment """
        lm = self.establish_connection()
        assert lm in self.t.get(None, lm)


    def test_server_close_reconnect(self):
        r = self.t.get("exit", "")
        # relogin:
        self.test_connect_establish()


class BaseSocketTelnetter (SocketTelnetterConnect):
    cache_check = 1
    check_eval = 1

    def setUp(self):
        super(BaseSocketTelnetter, self).setUp()
        # setup is to create and connect, self.tm is set and self.t as well:
        self.establish_connection()


    def do_login(self):
        # try with prompt as argument
        r = self.t.get('user', self.t.condition )
        assert r.endswith(self.tm.get('WelcomeMsg') + self.t.condition)
        # convenience for other callers:
        return self.t.condition


    def test_handshake(self):
        """Testing basic communication with testserver"""
        assert self.tm.get('LoginMsg') in self.t.get('wronguser',
                self.tm.get('LoginMsg'))


    def test_login(self):
        """Testing Login process"""
        self.do_login()
        self.t.get('exit', "$ |Meta: /EOF")


    def test_conditions_handling(self):
        """Testing conditions handling"""
        prompt = self.do_login()
        # Testing condition = None -> take prompt (=t.condition)
        r = self.t.get('test2', condition = None)
        assert r == 'SERVERECHO: test2' + prompt
        # Testing condition = NOREAD -> don't read, just send
        r = self.t.get('test3', condition = '/NOREAD')
        assert r == ''
        # Testing condition = '' -> like NOREAD"
        r = self.t.get('test4', condition = '')
        assert r == ''
        r = self.t.get(cmd = '/WAIT', condition = 'test4%s' % prompt)
        assert r =='SERVERECHO: test3%sSERVERECHO: test4%s' % (prompt, prompt)
        assert self.t.input_buf.endswith(('SERVERECHO: test3%sSERVERECHO: '
                                          'test4%s' % (prompt, prompt)))
        # Running ps ax, checking for python process"
        r = self.t.get('os: ps ax')
        assert 'python' in r

        if self.cache_check:
            # Checking caches"
            assert self.t.condition in CONDITION_PARSER_CACHE
            assert self.t.condition in CONDITION_OBJ_CACHE

        # Checking '/NOREAD' condition"
        r = self.t.get('os: ps ax', '/NOREAD')
        assert r == ''
        # now we can read the output which we did not with the NOREAD:
        # Checking /WAIT cmd"
        r = self.t.get('/WAIT')
        assert 'python' in r
        # Checking |Meta: /EOF condition"
        r = self.t.get("exit", "$ |Meta: /EOF")
        assert '' == r
        prompt = self.relogin()
        # Checking error_condition handling, we will stimulate an ErrorConditionException"
        self.assertRaises(ErrorConditionException, self.t.get, 'fubar',
                'no match prompt', 'fubar')
        prompt = self.relogin()

        rgx = '|Re: bcd[1]'
        # Testing regexp condition %s" % rgx
        r = self.t.get('abcd123', rgx)
        if self.cache_check:
            assert rgx in CONDITION_PARSER_CACHE
            assert rgx  in CONDITION_OBJ_CACHE
        # Testing compound plain / regexp / Meta condition"
        r = self.t.get('fubar - 123', '123|Re: WRONG')
        r = self.t.get('fubar - 123', 'abcd|Re: 12[3x]')
        r = self.t.get('exit', 'abcd|Re: [x]|Meta: /EOF')
        prompt = self.relogin()

        # testing check_condition with string input"
        assert True == check_condition('parrot', 'parrot')
        assert True == check_condition('parrot', 'arrot/Z')
        assert True == check_condition('parrot', '/Aparro')
        assert True == check_condition('parrot', '/Aparrot/Z')

        # Testing plain starts/ends/is conditions"
        cond = '/ASERVERECHO: fubar4'
        r = self.t.get('fubar4', cond)
        assert CONDITION_PARSER_CACHE.get(cond).get('plain_match') == 'starts'
        cond = prompt + '/Z'
        r = self.t.get('fubar5', cond)
        assert CONDITION_PARSER_CACHE.get(cond).get('plain_match') == 'ends'
        cond = '/ASERVERECHO: fubar6'+ prompt + '/Z'
        r = self.t.get('fubar6', cond)
        assert 'fubar6' in self.t.input_buf
        assert CONDITION_PARSER_CACHE.get(cond).get('plain_match') == 'is'
        # All conditions had been set correctly"

        # Crosschecking /A and /Z with no match"
        self.assertRaises(ErrorConditionException, self.t.get, 'fubarasdf',
                '/Axxxx/Z', '$ ')
        assert 'fubarasdf' in self.t.input_buf
        assert not self.t.is_connected
        prompt = self.relogin()

        if self.check_eval:
            et = '|Eval: "fubar2" in data'
            # Checking eval terminator: %s" % et
            r = self.t.get('fubar2', et)
            assert 'fubar2' in r

        # Testing disabling the global error_condition and error precedence 
        # (check output for errors)"
        # setting global error_condition"
        self.t.error_condition = 'servererror'
        self.assertRaises(ErrorConditionException, self.t.get, 'servererror')
        prompt = self.relogin()

        self.t.error_condition = 'servererror'
        # Now disabling the error checking, prompt alone will match again"
        self.t.get('servererror', error_condition = '')

        # Testing NOERR: "
        self.t.error_condition = 'servererror'
        self.t.get('/NOERR: servererror')
        self.assertRaises(ErrorConditionException, self.t.get,  'servererror')

    def relogin(self):
        self.t.connect()
        return self.do_login()

    def test_exception_handling(self):
        """ testing correct exception throwing """
        prompt = self.do_login()
        # Timeout Exception: 'sleep x makes the server sleep x secs: 
        self.assertRaises(TimeoutException, self.t.get, 'sleep: 0.05',
                timeout=0.049)
        prompt = self.relogin()

        # Checking timeout exception when server answers, but not the expected stuff"
        self.assertRaises(TimeoutException, self.t.get, 'fubar', 'barfoo',
                timeout=0.01)
        prompt = self.relogin()

        # Testing the /TIMEOUT meta"
        r = self.t.get('fubar77', 'barfoo|Meta: /TIMEOUT', timeout=0.01)
        # Test if server connection is still up, should be not closed,
        # since /TIMEOUT was captured"
        res = self.t.get('fubar78')

        # Testing maxdata"
        self.assertRaises(TooMuchDataException, self.t.get, 'fubar', maxdata=4)
        self.relogin()

        # testing ConnectionClosedException"
        # we have to make sure that everything is read from the socket
        # before we test
        # connection closed exception - if there is something on it
        # (with the prompt)
        # then the read_until would work, hiding the exception
        assert 'buffer_filler' in  self.t.get('buffer_filler',
                'buffer_filler%s' % prompt)
        # now there is no prompt which can be found anymore, so cause the server to close:
        self.assertRaises(ConnectionClosedException, self.t.get, 'exit')

        # the relogin created a different connection than t. t is off:
        assert not self.t.is_connected
        # don't want the login window
        # Testing auto_reconnect. 'user' is the login username"
        assert 'Welcome' in  self.t.get('user')

        # Testing /EOF Meta"
        # sending nothing, expecting error in receive:
        # w/o this self.t.get would raise conn.closed:
        conn  = self.t.get_connection_obj()
        self.assertRaises(ConnectionClosedException, self.t.get, 'exit')
        self.t.is_connected = 1
        self.t.set_connection_obj(conn)
        r = self.t.get('/WAIT', '|Meta: /EOF')
        assert r == ''

class PexpectTelnetterTests(BaseSocketTelnetter):
    """ Using pexpecter as a transport """
    # will run all tests from BaseSocketTelnetter 
    # via inheritence of test methods
    transport = PexpectTelnetter


class telnet_libTests(BaseSocketTelnetter):
    """ Using Python's telnet_lib"""
    cache_check = None
    check_eval = None
    transport = PyTelnetLib

class PopenComm(unittest2.TestCase):
    def test_single(self):
        t = get_a_transport( setup= 'popen_comm',
                add = {'popen_args': '/bin/bash', 'via': 'popen_comm'})
        res = t.get('ps ax')
        assert 'python' in str(res)

class PopenTests(ServerStarter):
    """ Using pexpecter as a transport """
    transport = Popen
    setup_name = 'closing_server'


    def test_blocking_read(self):
        """ Testing Popen """
        # CURRENTLY IT BLOCKS ON READ, i.e. can't communicate only
        # one sconnecteds"""
        # Only thing we can do is for now to send stuff over,
        # it closes and we read result:

        #FIXME for some alien reason netcat does not work when previously 
        # pexpecterTests and Extension Tests where running:
        #self.t.popen_args = ['netcat', '127.0.0.1', str(commport)]

        self.t.popen_args = ['telnet', '127.0.0.1', str(commport)]
        self.t.newline = '\n'
        self.server = None
        # this causes the server to close after received stuff:
        # write/read is superfast:
        self.t.connect()
        # Testing if we receive our sent stuff"
        self.t.run_command('popentest', conn_obj = self.t.get_connection_obj())
        r = self.t.read(3, 1000000, conn_obj = self.t.get_connection_obj())
        assert 'popentest' in r
        self.server = None


@unittest2.skipIf(test_cfg['snmp'].get('unavailable'), "no SNMP")
class PySNMPTests(unittest2.TestCase):
    """ Testing PySNMP """
    transport = PyNetSnmp
    def setUp(self):
        # The MIB module for managing IP and known_node
        # implementation = 1.3.6.1.2.1.1.9.1.3.6
        self.epilog = None
        self.known_node = "1.3.6.1.2.1.1.9.1.3.6"
        self.t = create_transport(PyNetSnmp)
        self.t.host = '127.0.0.1'
        self.known_node_val = 'ICMP'
        self.server_unknown_node = "1.3.6.6.6.6.6.6"
        self.t.timeout = 0.2
        self.t.connect()
        self.c = self.t.get_connection_obj()

    def test_timeout_change(self):
        # FIXME: NO effect seen when setting timeout to 0!
        r =  self.t.get('get: %s,1.3.6.1.2.1.1.4.0' % self.known_node)
        r2 =  self.t.get('get: %s,1.3.6.1.2.1.1.4.0' % self.known_node,
                timeout = 0)


    def test_server_unavail(self):
        """ Testing  PyNetNsmp"""
        # testing server availability check at connection:
        self.t.host = '1.0.0.0'
        self.t.test_node = '1.3.6.1.2.1.1.4.0'
        self.t.timeout = 1
        # localhost should be available for this within 0.2 secs:
        self.t.connect_timeout = 0.2
        self.assertRaises(ConnectionClosedException, self.t.connect )

    def test_server_avail(self):
        # testing switching test off:
        # connecting with test on and 0.2 secs check timeout"
        self.t.connect()

    def test_get(self):
        # Testing single get"
        assert self.known_node_val in self.t.communicate('get: %s' % self.known_node, \
                 self.c, error_condition = self.t.error_condition)[0]

    def test_2_get(self):
        # Testing two value get"
        r =  self.t.communicate('get: %s,1.3.6.1.2.1.1.4.0' % self.known_node,\
                self.c, error_condition = self.t.error_condition)
        r =  self.t.get('get: %s,1.3.6.1.2.1.1.4.0' % self.known_node)
        assert len(r) == 2 and self.known_node_val in r[0]

    def test_format(self):
        # Testing format - spaces removed?"
        r =  self.t.communicate('get: %s, 1.3.6.1.2.1.1.4.0  ' \
                % self.known_node, \
                self.c, error_condition = self.t.error_condition)
        assert len(r) == 2 and self.known_node_val in r[0]

    def test_server_unknown_node(self):
        # Testing if None comes when server does not know it"
        # tcpdump -vv says: .1.3.6.6.6.6.6.6.6.6=[noSuchObject] -> we get None for it:
        r =  self.t.communicate('get: %s, %s' % (self.known_node, self.server_unknown_node ), \
                 self.c, error_condition = self.t.error_condition)
        assert r[1] == None


    def test_walk(self):
        # Testing walk (patience pls.)"
        #print ('walked %s values' %  len(self.t.get('1.3.6.1.2.1.88.1.4.3.1.3.6.95.115.110.109.112.100.95.109.116.101.84.114.105.103.103.101.114.70.97.108.108.105.110.103')))
        res = self.t.get('walk: 1.3.6.1.2.1')
        print ('walked %s values' %  len(res))
        assert len(res) > 10


    def test_client_unknown_node(self):
        self.t.error_condition = 'client_unknown_node'
        self.assertRaises(ErrorConditionException, self.t.get,
                ('get: 4.5.6.7'))


    def test_client_unknown_node_getmap(self):
        self.t.error_condition = 'client_unknown_node'
        self.assertRaises(ErrorConditionException, self.t.get,
                ('get_map: 4.5.6.7'))


    def test_client_unknown_node_walkmap(self):
        self.t.error_condition = 'client_unknown_node'
        self.assertRaises(ErrorConditionException, self.t.get,
                ('walk_map: 4.5.6.7'))


    def test_client_unknown_node_walk(self):
        self.t.error_condition = 'client_unknown_node'
        self.assertRaises(ErrorConditionException, self.t.get,
                ('walk: 4.5.6.7'))


    def test_server_unknown_node(self):
        self.t.error_condition = 'server_unknown_node'
        self.assertRaises(ErrorConditionException, self.t.get,
                ('get: 1.3.6.10000'))


    def test_server_unknown_node_getmap(self):
        self.t.error_condition = 'server_unknown_node'
        self.assertRaises(ErrorConditionException, self.t.get,
                ('get_map: 1.3.6.10000'))


    def test_server_unknown_node_walkmap(self):
        self.t.error_condition = 'server_unknown_node'
        self.assertRaises(ErrorConditionException, self.t.get,
                ('walk_map: 1.3.6.10000'))


    def test_server_unknown_node_walk(self):
        self.t.error_condition = 'server_unknown_node'
        self.assertRaises(ErrorConditionException, self.t.get,
                ('walk: 1.3.6.10000'))


    def test_server_unknown_node_walkmap_noexc(self):
        assert self.t.get('walk_map: 1.3.6.10000') == {}


    def test_walkmap(self):
        res = self.t.get('walk_map: %s' % self.known_node)
        assert type(res) == dict
        assert res





    def test_get_map(self):
        res = self.t.get('get_map:1.3.6.1.2.1.1.4.0, 1.3.6.1.2.1.31.1.5.99')
        assert type(res) == type({})
        assert len(res) == 2
        # me@localhost:
        assert res['1.3.6.1.2.1.1.4.0']


class MicroFlowTests(SocketTelnetterConnect):
    """Testing Microflows and Autologin"""

    def test_autologin(self):
        # Testing '/F:[R]Login: [S]user[R]$ 'auto functions"
        self.t = get_a_transport(setup = 'default')
        # Testing autologin"
        res = self.t.get('foobar')
        assert 'foobar' in self.t.get('foobar')
        # if we don't exit then we will see ugly lost pipe exceptions from teh server
        # as soon as we reassign t (with it's socket):
        self.t.get('exit', '')


    def test_nested_flows(self):
        # Testing nested flows"
        lf = ('/F:[R]Login: [S]%(user)s[R]$ |Re: Login: [IF]Login: [S1]'
              '%(def_user)s[R1]$ |Re: Login: [IF1]Login: [S2]/EXC:Prolog'
              '[ELSE1][S2]/SET:logged_in_def[/IF1][ELSE][S1]/UNSET:'
              'logged_in_def[/IF][S]hooray, in[R]hooray, in')
        self.add = {'dbg_cli': '2', 'prolog':lf, 'user': 'foo', 'def_user': 'bar'}

        self.assertRaises(PrologException, get_a_transport, add=self.add)
        # now supply the right one as default user"
        self.add['def_user'] = 'user'
        self.t = get_a_transport(add = self.add)
        res = self.t.get('after login')
        # check if the setting of the microflow is set correctly:
        assert self.t.logged_in_def
        self.t.close()
        self.add['user'] = 'user'
        self.add['def_user'] = 'foo'
        self.t = get_a_transport(add = self.add)
        res = self.t.get('after login')
        assert not hasattr(self.t, 'logged_in_def')
        self.t.close()

        # Testing some convenience features in microflows"
        lf_simpler = ('/F:[R]Login: [S]%(user)s[R]$ |Re: Login: [IF]Login: '
                      '[S1]%(def_user)s[R1]$ |Re: Login: [IF1]Login: /EXC:'
                      'Prolog[ELSE1]/SET:logged_in_def[/IF1][ELSE]/UNSET:'
                      'logged_in_def[/IF]')
        self.add['prolog'] = lf_simpler
        self.t = get_a_transport(add = self.add)
        res = self.t.get('after login')
        assert not hasattr(self.t, 'logged_in_def')
        self.t.close()


class CiscoStyleTests(ServerStarter):
    setup_name = 'cisco'
    transport = PythonSocketTelnetter

    def setUp(self):
        super(CiscoStyleTests, self).setUp()
        self.t = get_a_transport(setup = self.setup_name)

    def test_cisco_autologin(self):
        # Testing autoconnect and autologin with a prolog set:"
        res = self.t.get('show foobar')
        assert 'show foobar' in res

    def test_var_replacement(self):
        # Testing variable replacement for cmd and condition"
        # we have overriddent the __getitem__ method:
        self.t.foo = 'bar'
        self.t.prompt = '#/Z'
        self.t.allowed_cmds = None
        res = self.t.get('show %(foo)s', '%(prompt)s')
        assert 'bar' in res

    def test_epilog(self):
        print  ("Testing epilog")
        self.t.epilog = 'exit'
        self.t.close()
        assert not self.t.is_connected

class WebServerOpener(object):
    transport = SOAPClient
    def openServer(self):
        global server_proc
        global commport
        # empty suds cache:
        os.system('rm -rf /tmp/suds/*')
        commport += 1
        self.t = self.transport()
        self.t.wsdl_url = 'http://127.0.0.1:%s/http_server/getWSDL' % commport

        import logging
        # suds is using logging-> switch debug output off:
        logging.getLogger('suds').setLevel(logging.CRITICAL)
        curdir = os.getcwd()
        os.chdir(tests_dir)
        open('http_server/getWSDL', 'w').write(open('http_server/getWSDL.tmpl',
            'r').read().replace('_PORT_', str(commport)))

        server_proc = subprocess.Popen(['python',
                'http_server/http_file_server.py',
                str(commport)], shell=False)

        os.chdir(curdir)
        sleep(1)
        return commport


class SOAPTests(unittest2.TestCase, WebServerOpener):
    def setUp(self):
        self.openServer()

    def tearDown(self):
        subprocess.call(["kill", "%d" % server_proc.pid])

    def test_getWSDL(self):
        self.t.connect()

    def test_getWSDL2(self):
        # for fun we take t (again) from the object's cache:
        self.t = get_transport_object('soap_suds',
                'ax.transport.via.soap.SOAPClient',
                settings = {'wsdl_url': self.t.wsdl_url},
                do_connect = 0)
        self.t.connect()
        #assert self.t._client.service.sampleMethod

    def test_soap(self):
        # autoconnect is True:
        self.t.dbg_cli = ''
        res = self.t.get('sampleMethod', args= (3,3))
        # that's hardcoded in the answer file ('soap'):
        assert 6 == res

    def test_viaXML(self):
        if not SHORT69:
            print "Omitting test12 - no TR69 xml model parser found"
            return
        props = {'D.AA.CH.A.T.H.S.WU': self.t.wsdl_url}
        sm = get_settingsmap_by_cpe_props(props, SHORT69)
        t = get_transport_object('soap_suds',
                'ax.transport.via.soap.SOAPClient',\
                settings = sm)
        res = t.get('sampleMethod', args= (3,3))
        assert 6 == res




class xtensionTests(ServerStarter):
    """ Testing extensions """

    # see also: test_execloop_with_sql_inserts

    # Don't know why but it must come AFTER Popen tests 
    # when pexpecter Tests are run
    setup_name = 'default'
    transport = PythonSocketTelnetter

    def setUp(self):
        super(xtensionTests, self).setUp()
        # make sure we have cache size:
        self.f = '/tmp/test_transport.py'
        self.f2 = '/tmp/test_extension.txt'
        self.f3 = '/tmp/test_extension_res.txt'
        #open('/tmp/__init__.py', 'a')
        os.system('touch /tmp/__init__.py')
        # create the source of a transport extension class:
        src = """
from ax.transport.via.tcp_socket import PythonSocketTelnetter
class TT(PythonSocketTelnetter):
    def foo(self, bar):
           return self.get(bar)
"""
        open(self.f, 'w').write(src)


    def tearDown(self):
        super(xtensionTests, self).tearDown()
        os.system('rm -f %s' % self.f)
        os.system('rm -f %s' % self.f2)
        os.system('rm -f %s' % self.f3)
        os.unlink('/tmp/__init__.py')
        invalidate_cache()


    def test_file_extension(self):
        # Testing Extensions"
        # a little extension class:
        t = get_a_transport(search_folders = '/tmp',
                add = {'via': 'test_transport.TT'})
        # using the TT only method"
        assert 'sent by TT' in t.foo('sent by TT')

        # test /RUN switch in a flow"
        res = t.get('/RUNS:foo(sent via /RUNS switch and extension function)')
        assert 'via /RUNS' in res


    def test_loading_extensions_via_urls(self):
        # Testing loading functions via URLs"
        # we exec what is in f2, having the environment, i.e. the transport 
        # at hand:
        # we write in f2 that it should write the transport repr + 'success' 
        # into file f3:
        self.t = get_a_transport(search_folders = '/tmp',
                add = {'ident': 'fubar', 'via': 'test_transport.TT'})
        open(self.f2+'x','w').write(\
                "open('%s', 'w').write(str(transport) + ' success')"\
                     % (self.f3 + 'x'))
        # and now we exec this, i.e. write success into file f3+'x':
        self.t.get('/LOAD:RELOAD:file://%s' % self.f2+'x')
        assert 'success' in open(self.f3+'x', 'r').read()


    def test_add_function_from_url(self):
        # Now we add a function from a URL to the transport which we can run more often"
        # the function will turn everything echoed from teh server into uppercase:
        src = """
def bar(lower):
    return transport.get(lower.upper())
transport.ext_meth = bar
"""
        open(self.f2, 'w').write(src)

        # load it into the t object:
        self.t = get_a_transport(search_folders = '/tmp',
                add = {'ident': 'fubar2', 'via': 'test_transport.TT'})
        self.t.get('/LOAD:file://%s' % self.f2)
        assert 'THIS IS UPPER' in self.t.ext_meth('this is upper')
        # works. try now on tt:
        tt = get_a_transport(search_folders = '/tmp',
                add = {'ident': 'fubar3', 'via': 'test_transport.TT'})
        try:
            assert 'THIS IS UPPER' in tt.ext_meth('this is upper')
            raise Exception, "tt should NOT have the external method!"
        except AttributeError:
            print "got expected attribute error on tt"

        # now we try, via a microflow, to load only if not loaded already"
        open(self.f3, 'w').write(src.replace('ext_meth', 'other_meth'))
        # delete the source:
        os.unlink(self.f2)
        # check if ext_meth is there (/IS will return <function bar...> and if no match load:
        
        self.t.get('/F:[S]/GET:ext_meth[R][IF]function[ELSE]/LOAD:file://%s[/IF]'\
                % self.f2)
        # it was not loaded, there would have been an error.
        # now with the 'other_meth' we have written into f3:
        self.t.get('/F:[S]/GET:other_meth[R][IF]function[ELSE]/LOAD:file://%s[/IF]'\
                % self.f3)
        assert 'UPPER' in self.t.ext_meth('upper')
        assert 'UPPER' in self.t.other_meth('upper')
        # both there :-)




class LineParserTests (ServerStarter):

    setup_name = 'default'
    transport = PythonSocketTelnetter

    def test_line_parser(self):
        OBJ_POOLS.clear()
        # Testing flow handling"
        t = get_a_transport()
        assert 'foo' in  run_cmd_flow(t, [{'cmd': '/SET:formatters='},
            {'cmd': 'foo', 'as': 'bar'}])['result']['bar']

        # testing line parsing"
        res = try_line_parsing("""
ifconfig eth0 AS ip
then do something
get something TIMEOUT 10 AS something
get something AS something TIMEOUT 10
insert into foo values (%s, %s) ARGS [1,2]
insert into foo values (%s, %s) ARGS {foo: bar, 1: 2}
        """)
        res = res.get('cmdlist')
        assert str(res[2]) == str(res[3])
        assert res[0].get('cmd') == 'ifconfig eth0'
        assert res[0].get('as') == 'ip'
        assert res[4].get('args') == ['1', '2']
        assert res[5].get('args').get('foo') == 'bar'
        assert res[5].get('args').get('1') == '2'

    def test_settings_parsing(self):
        res = try_line_parsing("""
via telnet
 host 127.0.0.1
 port 23
 condition $ .
 # comment
 prolog F:[S]/UNSET:dbg_cli[S]/WAIT[R]login: [S]user[R]Password: [S]pass[R]$ .

  get

 ifconfig eth0 AS ipconfig
   # second get:
    get AS foo
    FMT html
                """)
        # we got (setup_map, flow_list) back:
        cmds = res.get('cmdlist')
        setup = res.get('settings')
        assert setup['host'] == '127.0.0.1'
        assert cmds[0]['as'] == 'ipconfig'
        assert cmds[0]['cmd'] == 'ifconfig eth0'
        assert cmds[1]['cmd'] == 'get'
        assert cmds[1]['as'] == 'foo'
        assert cmds[2]['fmt'] == 'html'
        assert cmds[2]['cmd'] == ''





class XMLParametrizationTests(ServerStarter):

    setup_name = 'default'

    def setUp(self):
        super(XMLParametrizationTests, self).setUp(do_create_transport=None)

    def test_xml_test(self):
        if not SHORT69:
            print "Omitting test12 - no TR69 xml model parser found"
            return
        # Testing with cpe.props maps, incl. failover variables" 
        props = {'D.AA.CH.A.T.C.V':\
                 'ax.transport.via.tcp_socket.PythonSocketTelnetter',\
                'D.AA.CH.A.T.S.H': '127.0.0.1', \
                'D.AA.CH.A.TS.1.S.H': '128.0.0.1', \
                'D.AA.CH.A.TS.9.S.P': 9, \
                'D.AA.CH.A.TS.101.S.P': 19, \
                'D.AA.CH.A.T.S.P': commport, \
                'D.AA.CH.A.T.DE.C': '$ /Z', \
                'D.AA.CH.A.T.HS.P': '/F:[R]Login: [S]user[R]$ ',\
                'D.AA.CH.A.T.HS.E': 'exit'}
        # for the instantiation of the xml file we need time.
        # do it 2 times, so that it's in the cache, to see how fast it really is
        t0 = time()
        get_settingsmap_by_cpe_props(props, SHORT69)
        t1 = time()
        sm = get_settingsmap_by_cpe_props(props, SHORT69)
        # Settingsmap built in %s (first time xml parsing in %s)" 
        # % ((time() - t1), (t1-t0))
        assert sm.get('host') == props.get('D.AA.CH.A.T.S.H') != None
        assert sm.get('s_host_1') == props.get('D.AA.CH.A.TS.1.S.H') != None
        assert sm.get('s_port_9') == 9
        assert sm.get('s_port_101') == 19
        t = get_transport_object('default', sm['via'], settings = sm)
        assert t.via == sm['via']
        assert t.t_type == 'default'
        print t
        assert 'cpe' in t.get('cpe')



class TemplateTests(ServerStarter):

    setup_name = 'default'
    transport = PythonSocketTelnetter

    def setUp(self):
        super(TemplateTests, self).setUp()
        self.t = get_a_transport(setup = self.setup_name)
        self.t.get('/SET: cmdflow=ifconfig %(interface)s %(updown)s')

    def test_template_tests(self):
        # testing templates and arguments"
        self.t.allowed_args = "^[A-z 0-9]+$"
        res = self.t.get('/RUNS: cmdflow',
                cmd_args= {'interface': 'eth0', 'updown': 'up'})
        assert 'ifconfig eth0 up' in res

    def test_template_security(self):
        self.t.allowed_cmds = "^[0-9]+$"
        # test value checking:"
        self.assertRaises(SecurityException, self.t.get, '/RUNS: cmdflow',
                cmd_args = {'interface': 'eth0', 'updown': 'up'})
    def test_microflow_templates(self):
        self.t.allowed_cmds =  "^[/A-z 0-9]+$"
        print 'try as microflow'
        assert 'ifsomething somethingint down' in \
                self.t.get('/F:ifsomething %(interface)s %(updown)s',\
                cmd_args = {'interface': 'somethingint', 'updown': 'down'})
    def test_member_var_replacement(self):
        # try via member var replacement"
        self.t.get('/SET: iface=anotherint')
        self.t.get('/SET: updown=middle')
        res = self.t.get('ifcfg %(iface)s %(updown)s')
        assert 'ifcfg anotherint middle' in res


@unittest2.skipIf(test_cfg['mysql'].get('unavailable'), 'No SQL')
class MySQLTests(unittest2.TestCase):

    def test_execloop_with_sql_inserts(self):
        """ this is actually an EXEC test, looping over inserts """
        # get the external config:
        m = test_cfg.get('mysql')
        m['database'] = ''
        if not m:
            print " no sql access definition in test config file (cfg_test_all_transports)"
            print " No SQL tests!"
        m['via'] = 'ax.transport.via.mysqldb.MySQLClient'
        self.t = get_a_transport(setup='mysql', add = m)
        self.t.get('drop database auth_test_db', 'Error')
        self.t.get('create database auth_test_db', 'Error')

        self.t.get('use auth_test_db')
        self.t.get("""create table secrets (name varchar(30), email varchar(30), secretId varchar(30), cur_time timestamp)""", 'Error')
        self.t.get("truncate secrets")

        t1 = time()
        for i in xrange(100):
            res= self.t.get("""insert into secrets ( name, email, secretId, cur_time) values ('Test User%s', 'testuser@test.com','Munich GER',now()) """ % i)
        t2 = time() - t1

        fun = """
for i in xrange(100):
    self.get("insert into secrets ( name, email, secretId, cur_time) values ('Test User looped %s', 'testuser@test.com','Munich GER',now())" % i, condition='some condition', kwarg1 = 'check')
"""
        t1 = time()
        res= self.t.get('/EXEC: %s' % fun)
        t2loop = time() - t1
        assert len(self.t.get('select * from secrets')) == 200
        self.t.get('drop database auth_test_db')



    

    def test_mysql(self):
        # get the external config:
        m = test_cfg.get('mysql')
        m['database'] = ''
        if not m:
            print " no sql access definition in test config file (cfg_test_all_transports)"
            print " No SQL tests!"
        m['via'] = 'ax.transport.via.mysqldb.MySQLClient'
        self.t = get_a_transport(setup='mysql', add = m)
        self.t.get('create database axpand_test_db', 'Error')

        self.t.get('use axpand_test_db')
        self.t.get("""create table guestTbl (msgID int not null primary key auto_increment, name varchar(30), email varchar(30), secretId varchar(30), cur_time timestamp, msgBody text)""", 'Error')
        self.t.get("truncate guestTbl")
        assert self.t.get('select * from guestTbl') == ()
        res= self.t.get("""insert into guestTbl (msgID, name, email, secretId, cur_time, msgBody) values (NULL, 'Test User1', 'testuser@test.com','Munich GER',now(), 'This is the body for message 1.')""")
        # try prepared statement with args"
        self.t.get("/SET: do_one=insert into guestTbl (msgID, name, email, secretId, cur_time, msgBody) values (NULL, %s, %s, %s, now(), %s)")
        res= self.t.get("/RUNS: do_one", args= ('Test User1', 'testuser@test.com','Munich GER','This is the body for message 1.'))
        assert len(self.t.get('select * from guestTbl')) == 2
        self.t.get('drop database axpand_test_db')



class MultithreadedAccessTests(ServerStarter):

    setup_name = 'default'
    transport = PythonSocketTelnetter

    def test_connection_reusing(self):
        # Testing Transport Factory and Pooling - with same self.commport"
        # Testing basic connection reusing"
        # this sets a transport with a login microflow (prolog)
        t1 = get_a_transport(setup = 'default', poolsize = 1)
        con = t1.get_connection_obj()
        t1.close()
        t2 = get_a_transport(setup = 'default', poolsize = 1)
        assert t1 == t2
        assert t1.get_connection_obj() == t2.get_connection_obj()


    def test_data_flow(self):
        # testing socket data flow"
        t2 = get_a_transport(setup = 'default', poolsize = 1,
                add={'connection_pooling': 1})
        t2.get('sent by t2', '/NOREAD')
        t2.close()
        t3 = get_a_transport(setup = 'default', poolsize = 1,
                add={'connection_pooling': 1})
        assert 'sent by t2' in t3.get('foobar', 'foobar')


    def test_multithread_performance(self):
        # Performance tests"

        # Configure the test server:
        # Set global Sleep mode to 0.1 secs:
        network_delay  = 0.01
        t3 = get_a_transport(setup = 'default', poolsize = 1)
        t3.get('Sleep: %s' % network_delay)
        t3.get('ServerSilent')
        t3.close()

        all_res = {}
        total_connections = 40
        poolsize = 20

        # we run x times one transaction and call close after it - with different
        # parametrizations on it, and either serial or parallel running of it

        # 2 runs, at first ones the threads won't be connected
        # run 2 will work with established connections.
        # we create different queues of connections,
        # through the different idents of the test runs:
        for k in ['pool_new', 'pool_established']:
            all_res[k] = {}
            for  j in [ 'serial_no_pool',
                        'serial',
                        'parallel_poolsize_1',
                        'parallel_big_pool']:
                # -" * 70
                print k, j
                # -" * 70
                resmap = {}
                ts = time()

                for i in xrange(total_connections):
                    if j == 'serial_no_pool':
                        t = get_a_transport(add={'ident': str(time())})
                        #print t.__hash__(), j
                        # this runs a transaction, measures time, then t.close()
                        run_get(i, t, resmap)

                    elif j == 'serial':
                        # supplying in 'ident' fixes the pool id, we get the same:
                        t = get_a_transport(poolsize = 1,
                                add = {'ident': 'serial'})
                        #print t.__hash__(), j
                        run_get (i, t, resmap)

                    elif j =='parallel_poolsize_1':
                        t = get_a_transport(poolsize = 1,
                                add = {'ident': 'p1',
                                       'connection_pooling': 1})
                        start_new_thread(run_get, (i, t, resmap))

                    elif j == 'parallel_big_pool':
                        t = get_a_transport(poolsize = poolsize,
                                add = {'ident': 'pmany',
                                       'connection_pooling': 1})
                        # start_new_thread(run_get, (i, get_a_transport(
                        #       poolsize = total_connections), 
                        #        resmap))
                        start_new_thread(run_get, (i, t, resmap))

                # wait until all ready:
                if j == 'parallel_big_pool' or j == 'parallel_poolsize_1':
                    # have to wait here until resmap is filled:
                    while len(resmap) < total_connections:
                        sleep(network_delay/4)

                all_t = time() - ts
                av = 0
                for i in xrange(total_connections):
                    av += resmap[i][1]
                av = av / total_connections

                # %s transactions in: %s.\nAverage run time:  %s seconds" %
                # (total_connections, all_t, av)
                all_res[k][j] = (all_t, av)

        # First number is total run time, second is average per transaction"
        mh = all_res.get('pool_established')
        snpt = mh.get('serial_no_pool')[0]
        snpa = mh.get('serial_no_pool')[1]
        st = mh.get('serial')[0]
        sa = mh.get('serial')[1]
        p1t = mh.get('parallel_poolsize_1')[0]
        p1a = mh.get('parallel_poolsize_1')[1]
        pt = mh.get('parallel_big_pool')[0]
        pa = mh.get('parallel_big_pool')[1]
        # to get a chart call like this:
        # /opt/axess/bin/test  -m /opt/axess/bin/test  
        #      -m ax.transport/* --xml -x 
        #      --test=test_multithread_performance -v
        if '-v' in sys.argv:
            try:
                from ax.utils.formatting.charting import bar_chart
                print bar_chart(all_res, mode ='0:Vals,1:Main',
                        val_descr_list = ['\tTotal Run Times',
                            '\tAverage Run Times'])
            except:
                print " ! CAN'T IMPORT BAR_CHART"
            pprint.pprint(all_res)

            print  ("total run times: full pool must be way fastest, "
                    "especially with higher network delays")
        assert pt < st  
        assert pt < p1t  < snpt
        assert pt < total_connections * network_delay
        assert st > total_connections * network_delay
        assert p1t > total_connections * network_delay
        assert snpt > total_connections * network_delay


        if '-v' in sys.argv:
            print ("At %s connections at a network delay of %s secs, the %s "
                   "thread pool was %s times faster than the threadless serial"
                   "connections ") % (total_connections,
                           network_delay,
                           poolsize,
                           snpt / pt)



def run_get(i, t, resmap):
    s = 'test_%s' % i
    ts = time()
    t.debug = 1
    t.timeout = 10
    res =t.get(s)
    t.close()
    rt = time() - ts
    if not s in res:
        sys.exit(0)
    resmap[i] = (s in res, rt)




class PingTests(unittest2.TestCase):

    def setUp(self):
        self.sm_ping = {'via': 'icmp', 'host' : '127.0.0.1',
                'count': 1, 'pause': 0.01}
        self.t = get_transport_object('ping', self.sm_ping['via'],
                settings = self.sm_ping)
        self.t.timeout= 0.3

    def test_ping1(self):
        res = self.t.get('ping')
        assert res[0][0] == 1
        assert res[0][1] < 1

    def test_ping_error_cond(self):
        self.t.error_condition = 0.001
        self.assertRaises(ErrorConditionException, self.t.get,'ping')
        self.t.error_condition = 1
        # hopefulle not there:
        self.t.host = '1.0.0.1'
        self.assertRaises(TimeoutException, self.t.get,'ping')
        self.t.error_condition = None
        assert 0 ==  self.t.get('ping')[0][0]
        self.assertRaises(TimeoutException, self.t.get,'ping',
                error_condition = 0.001)


    def test_ping_no_resolve(self):
        self.sm_ping['host'] = 'asdf'
        self.assertRaises(ConnectionClosedException,
                get_transport_object, 'ping',
                self.sm_ping['via'],
                settings = self.sm_ping)

    def test_ping_pause(self):
        self.sm_ping['count'] = 3
        self.sm_ping['pause'] = 0.1
        self.sm_ping['background'] = None
        self.t = get_transport_object('ping', self.sm_ping['via'],
                settings = self.sm_ping)
        t1 = time()
        res = self.t.get('ping')
        t2 = time()
        # 0.19 instead of 0.2 because of a stupid clock bug in XEN:
        assert t2 - t1 > 0.19 and t2 - t1 < 0.25 and res[0][0] == 1



#########################################################################
#
# Multithreading Tests
#
#########################################################################



class TransportGroupTests(unittest2.TestCase):
    def setUp(self):
        self.sm_ping = {'via':              'group',
                        'host':             '127.0.0.1',
                        'vias':             'icmp',
                        'group_size':       3,
                        'active':           1,
                        'connect_at_start': [0],
                        'comm_calls':       2,
                        'comm_call_sleep':  0.1,
                        'pause':            0.2,
                        'timeout':          0.3}

    def test_base(self):
        self.t = get_transport_object('group1', 'group',
                settings = self.sm_ping)


    def test_foreground_spammed(self):
        # spam the system's I/O and try again:
        # that's a tough one on any system:
        spammer =  subprocess.Popen(['ping', '-f', '127.0.0.1'])
        sleep(1)
        self.test_foreground(is_spammed='LOADED')
        spammer.kill()


    def test_foreground(self, is_spammed='NORMAL'):
        """ run communication tasks in the foreground,
            i.e. wait for the results """
        self.t = get_transport_object('group1', 'group',
                settings = self.sm_ping)
        t_test_start = time()
        res = self.t.get('ping')
        # transport results like: 
        """
            {0: {'data': deque([(1344447248.702143,
                                    ((1, 0.06008148193359375),)),
                                (1344447248.8040979,
                                    ((2, 0.0591278076171875),))],
                                maxlen=3),
                 'last_exc': (0, None),
                 'req_close': False,
                 'state': 0,
                 'ts': 1344444976.368006},
             1: {'data': deque([], maxlen=3),
                 'last_exc': (0, None),
                 'req_close': False,
                 'state': 1},
             2: {'data': deque([], maxlen=3),
                 'last_exc': (0, None),
                 'req_close': False,
                 'state': 1}}
        where state 0 means finished, 1 means initted
        (we had connect at start set to 0 -> only the first was running)

        There are consecutive runs in thread 0, with sleep time 0.1 in between.
        - The 2 communication events of thread 0 finished at
                1344447248.702143 and 1344447248.8040979
                (i.e. comm_call_sleep of 0.1 in between them)
        - The results of the calls are (1, 0.06008148193359375),) and
             (2, 0.0591278076171875),), which means for a pinger:
             received replies and ping time (in milliseconds).

        """
        # the transport only returns the results for comm events, i.e. res like
        # {0: {'state': 0, 'last_exc': (0, None), 
        # 'data': ((1344447248.702143, ((1, 0.06008148193359375),)),
        #          (1344447248.8040979, ((2, 0.0591278076171875 ),))
        # )}}
        print "Ping result at %s system state: %s" % (is_spammed,
                        pformat(res))
        self.assertGreater(time() - t_test_start, 0.1)
        self.assertLess(time() - t_test_start, 0.2)
        # only one comm thread was run:
        self.assertEqual(len(res), 1)
        # no exception:
        self.assertEqual(res[0]['last_exc'][0], 0)
        # first thread (res[0], first comm, first ping,
        # first elemet of result:
        # which is (success count, time)
        self.assertEqual(res[0]['data'][0][1][0][0], 1)
        # ping to localhost:
        # disabled - under very loaded conditions the ping time can be much
        # greater then 0.5 milliseconds:
        # self.assertLess(res[0]['data'][0][1][0][1], 0.5)
        return res

    def test_exceptions(self):
        self.sm_ping['active'] = 2
        self.assertRaises(Exception, get_transport_object, 'group1',
                'group', settings = self.sm_ping)

    def param(self, add = {}):
        self.sm_ping['count'] = 2
        self.sm_ping['active'] = 2
        self.sm_ping['connect_at_start'] = [0,1]
        self.sm_ping.update(add)
        self.t = get_transport_object('group1', 'group',
                settings = self.sm_ping)

    def test_foreground_2(self):
        self.param()
        t1 = time()
        res = self.t.get('ping')
        t2 = time()
        # 2 comm_calls with 2 (count) pings with 0.2(pause) in between, 
        # 0.1 between the comm calls = 0.5 in total
        # that 2 times sequentially (active = 2)
        self.assertGreater(t2 - t1, 0.9)
        self.assertLess(t2 - t1, 1.1)
        self.assertEqual(len(res), 2)
        for i in (0,1):
            self.assertEqual(len(res[i]['data']), len(res[i]['data'][0]))
            self.assertEqual(len(res[i]['data']), len(res[i]['data'][1]))
        self.assertEqual(self.t.connected, [0,1])

    def test_background_1(self):
        self.param({'background': 1})
        t1 = time()
        res = self.t.get('ping')
        t2 = time()
        # we now need half the time of test_foreground_2:
        self.assertGreater(t2 - t1, 0.49)
        self.assertLess(t2 - t1, 0.55)
        self.assertEqual(len(res), 2)
        for i in (0,1):
            self.assertEqual(len(res[i]['data']), len(res[i]['data'][0]))
            self.assertEqual(len(res[i]['data']), len(res[i]['data'][1]))
        self.assertEqual(self.t.connected, [0,1])



    def test_parametrization(self):
        self.param({'s_host_1': 'localhost', 's_host_2': 'localhost'})
        self.assertEqual(self.t.transports[0].host, '127.0.0.1')
        # .host has been resolved already in do_connect:
        assert self.t.transports[1].host == '127.0.0.1'
        assert self.t.transports[1].settings['host'] == 'localhost'
        # not connected yet (connect_at_start):
        assert self.t.transports[2].host == 'localhost'
        res = self.t.get('ping')
        assert len(res) == 2
        for i in (0,1):
            assert len(res[i]['data']) == len(res[i]['data'][0]) ==\
                    len(res[i]['data'][1])
        assert self.t.connected == [0,1]


    def test_failover(self):
        self.param({'s_host_0': 'asdfasdf',
            's_host_1': 'localhost',
            's_host_2': 'localhost'})
        t1 = time()
        res = self.t.get('ping')
        t2 = time()
        assert t2 - t1 > 0.9 and t2 - t1 < 1.05
        assert len(res) == 3
        assert res[0]['last_exc'][1] == res[0]['data'][0][1] ==  18400
        assert res[2]['last_exc'][0] == 0
        assert res[2]['data'][0][1][0][0] == 1
        assert self.t.connected == [1,2] or self.t.connected == [2,1]


    def test_switchback(self):
        # background on, otherwise the failing one will use the sequentially 
        # before it one, and not the excepted one:
        self.param({'retry_secs': 1, 'background': 1, 'count': 2,
            'comm_calls': 1, 's_host_0': 'asdfasdf', 's_host_1': 'localhost',
            's_host_2': 'localhost'})

        t1 = time()
        res = self.t.get('ping')
        t2 = time()
        # connected now 1 and 2.
        self.t.transports[0].host = 'localhost'
        # kill 2:
        # that will cause an exception:
        self.t.transports[2]._conn_obj = None
        res = self.t.get('ping')
        assert self.t.connected == [0,1] or self.t.connected == [1,0]
        assert res[0]['last_exc'][0] > 0
        assert res[1]['last_exc'][0] == 0
        assert res[2]['last_exc'][0] > 0


    def test_try_no_transport_avail(self):
        # retry secs put to 1
        self.param({'retry_secs': 0.2,'wait_for_results': 1,
            'background': 1, 'count': 3, 'comm_calls': 2,
            's_host_0': 'asdfasdf', 's_host_1': 'localhost',
            's_host_2': 'localhost'})

        t1 = time()
        res = self.t.get('ping')
        t2 = time()
        # connected now 1 and 2.
        # kill 2
        # that will cause an exception:
        self.t.transports[2]._conn_obj = None
        self.t.transports[2].host = None
        t1 = time()

        self.assertRaises(OutOfTransportsException, self.t.get, 'ping')
        t2 = time()


    def test_no_connect(self):
        # simple not 2 possible to connect. Synch. Exception in any case.
        self.assertRaises(OutOfTransportsException,
                self.param, add = {'retry_secs': 0.2,
                    'background': 1, 'count': 3, 'comm_calls': 2,
                    's_host_0': 'asdfasdf', 's_host_1': 'localhost',
                    's_host_2': 'asdfas'})


class TestViaFile(unittest2.TestCase):
    def setUp(self):
        import tempfile
        self.tfile = tempfile.mktemp()
        try: os.unlink(self.tfile)
        except: pass
        self.sm = {'via': 'file',
                'buffering': 1,
                'target_file': self.tfile,
                'format_str': '%(tpretty)s\t%(ts)s\t%(foo)s'}

    def test_reopen(self):
        # let it check everytime:
        self.sm['max_size_check'] = 1
        self.t = get_transport_object('file1', 'file', settings = self.sm)
        res = self.t.get('write', line = '1 bla bla')
        os.unlink(self.tfile)
        #
        res = self.t.get('write', line = '2 bla bla', do_flush = 1)
        assert open(self.tfile).read() == '2 bla bla\n'

    def test_write(self):
        self.t = get_transport_object('file', 'file', settings = self.sm)
        assert open(self.tfile).read() == ''
        res = self.t.get('write', stuff = {'foo': 'bar'})
        written = open(self.tfile).read()[:-1]
        assert res == written
        assert written.split('\t')[2] == 'bar'

    def test_flush(self):
        self.sm['buffering'] = 10
        self.t = get_transport_object('file', 'file', settings = self.sm)
        res1 = self.t.get('write', line = '12')
        # first one he always seems to write:
        assert open(self.tfile).read() == '12\n'
        # number 3 was the \n:
        res2 = self.t.get('write', line = '45')
        assert open(self.tfile).read() == '12\n'
        res3 = self.t.get('write', line = '78')
        assert open(self.tfile).read() == '12\n'
        res3 = self.t.get('write', line = '9..!')
        assert open(self.tfile).read().endswith('!\n')


    def test_max_size(self):
        self.sm['buffering'] = 1
        self.sm['max_size'] = 2
        self.sm['max_size_check'] = 2
        self.t = get_transport_object('file', 'file', settings = self.sm)
        res1 = self.t.get('write', line = '1 bla bla')
        assert open(self.tfile).read() == '1 bla bla\n'
        res2 = self.t.get('write', line = '2 bla bla')
        assert open(self.tfile).read() == res1 +'\n' + res2 +'\n'
        res3 = self.t.get('write', line = '3 bla bla')
        res4 = self.t.get('write', line = '4 bla bla')
        # it truncated off after 2 anything except '1 ' 
        # and then wrote 3 and 4:
        assert open(self.tfile).read() == '1 3 bla bla\n4 bla bla\n'



class TR069(unittest2.TestCase, WebServerOpener):
    """ we test the basics via the static server, programmed to
    reply empty if empty post is comming -> one inform cycle"""
    def setUp(self):
        comm_port = self.openServer()
        print comm_port
        self.sm = {'t_type': 'tr069', 'via': 'tr069',\
            'acs_url': 'http://127.0.0.1:%s/http_server/handle_tr069_inform'\
                % comm_port}
        self.t = get_transport_object('tr069', 'tr069', settings = self.sm)

    def test_inform(self):
        res = self.t.get('run')
        assert res['history'][0].get('request_args').get('Event')[0].\
               get('EventCode') == '0 BOOTSTRAP'

    def test_events(self):
        res = self.t.get('run', events = [1,2])
        # must have now 3 events in the first request:
        assert len(res['history'][0].get('request_args').get('Event')) == 3
        assert len(res['history'][1]) == 4 and \
                res['history'][1].values()[0] == None
        # can't check much more since it's up to the server what it sends

    def test_no_acs(self):
        self.sm['acs_url'] = 'http://127.0.0.1:11'
        self.t = get_transport_object('tr069', 'tr069', settings = self.sm)
        self.assertRaises(ConnectionClosedException, self.t.get,
                'run', events = [1,2])

    def test_reparam(self):
        # run on working url then on non working one:
        self.t = get_transport_object('new_tr069', 'tr069', settings = self.sm)
        self.t.get('run')
        self.assertRaises(ConnectionClosedException, self.t.get, 'run', \
                params = {'InternetGatewayDevice.ManagementServer.URL':\
                'http://127.0.0.1:11'}, \
                events = [1,2])

@unittest2.skipIf(test_cfg['axess'].get('unavailable'), 'No axess server')
class HTTPRaw(unittest2.TestCase):
    def setUp(self):
        ac = test_cfg.get('axess')
        self.sm = {'t_type': 'axess', 'via': 'http'}
        self.sm.update(ac)
        self.t = get_transport_object('axess', 'http', settings = self.sm)

    def test_get(self):
        res = self.t.get(self.sm.get('uri'))
        assert res['status'] == 200
        assert res['reason'] == 'OK'
        assert 'Axiros' in res['data']

    def test_manage_get(self):
        res = self.t.get(('/live/CPEManager/manage_main?__ac_name=%s'
            '&__ac_password=%s') % (self.sm['user'], self.sm['password']))
        res = self.t.get('/live/CPEManager/manage_main')
        res = res['data']
        assert res.find('AXAuthenticator') > 0



# The old concurrency setup:
class MultiThreadingTests:
    def setUp(self):
        self.sm_ping = {'t_type': 'ping_test',
                'via': 'icmp',
                'host' : '127.0.0.1',
                'concurrency': 4,
                'count': 2,
                'pause': 0.2,
                'timeout': 0.3}

    def test_concurrent_ping(self):
        self.t = get_transport_object('ping_test',
                self.sm_ping['via'],
                settings = self.sm_ping)

        res = self.t.get('ping')
        assert len(self.t.comm_thread_objs) == 4
        for i in xrange(4):
            if not self.t.comm_thread_objs[i].is_alive():
                raise Exception("Commthread not alive")
        sleep(0.3)
        for i in xrange(4):
            if self.t.comm_thread_objs[i].is_alive():
                raise Exception("Commthread still alive")


    def test_results_waiting(self):
        self.sm_ping['wait_for_results'] = True
        self.t = get_transport_object('ping_test',
                self.sm_ping['via'],
                settings = self.sm_ping)

        t1 = time()
        res = self.t.get('ping')
        t2 = time()
        # 2 pings, 0.2 pause in between, 4 threads:
        assert t2 - t1 >0.2 and t2-t1 < 0.25


    def test_results_fetching(self):
        self.sm_ping['wait_for_results'] = True
        self.sm_ping['history'] = 10
        self.sm_ping['concurrency'] = 1
        self.sm_ping['count'] = 3
        self.sm_ping['comm_calls'] = 2
        self.sm_ping['comm_call_sleep_time'] = 0.1
        self.t = get_transport_object('ping_test',
                self.sm_ping['via'],
                settings = self.sm_ping)
        t1 = time()
        res = self.t.get('ping')
        t2 = time()

        assert res[0].get('ok') == 1
        # timestamp recent?
        assert time() - res[0].get('ts') < 0.2
        data = res[0].get('data')
        assert len(data) == 2
        assert len(data[0]) == 3

        # we ran 2 series (comm_calls = 2) of 3 pings.
        # 1 series takes (3-1) * 0.2 = 0.4
        # we have 0.1 sleep time between the series
        # i.e in total we have 0.4 * 2(series) + 0.1 (comm call sleep time)
        # = 0.9
        assert t2 - t1 >0.9 and t2-t1 < 0.95






if __name__ == "__main__":

    # starting the server at a random port in a new process for a new test run:
    # report skipping by using unittest testresult2:


    unittest2.main(verbosity=2)
