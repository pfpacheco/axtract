"""
Static access methods for the transports
Normally imported as 'axpand'
"""
from ax.utils.sub_proc_runner import get_proc_res
from inspect import getargspec
from threading import RLock
from ax.utils.dynamic_objects.objectpool import object_pool_factory
# the pools for the pooled transports:
from ax.utils.dynamic_objects.class_loader import get_class_by_name
from ax.transport.inventory import check_inventory
from ax.transport.base import is_str
import logging

logger = logging.getLogger(__name__)

tfolder = globals().get('__file__').rsplit('/', 1)[0]
VIA_CLASS_SEARCH_FOLDERS = [tfolder+'/vendors',
                            '/opt/plugins.ax/axpand/via',
                            '/opt/plugins.proj/axpand/via']

def add_via_class_search_folders(folders):
    if not type(folders) == list:
        raise Exception("Need folders as list of strings")
    VIA_CLASS_SEARCH_FOLDERS.extend(folders)

class TransportViaClassNotFound(Exception):
    """find_class did not find a class to instantiate"""
    err_id = 16200

def get_communicate_args(t):
    """ deliver the kwargs for communicate calls"""
    # args like ['self', 'cmd', 'conn_obj', 'condition', 'error_condition',
    # 'timeout', 'data', 'foo'] - we deliver ['data', 'foo']:
    return getargspec(t.communicate)[0][6:]


def get_microflows():
    from ax.transport import microflows
    return microflows.MF_LIB


# we need this when we create a new connection specific Lock:
GLOBAL_LOCK = RLock()

OBJ_POOLS = {}
CLASS_BY_NAME = {}


def gto(settings={}):
    return get_transport_object(settings=settings)

def get_transport_object(pool_id=None, via=None, settings={}, do_connect=1):
    """
    Delivers a transport object from the (bounded) pool of connected
    ones (hashed by their ident) or from the unbounded object pool for a
    certain type.

    $pool_id: A required arbitrary label for identifying a transport object
    and be able to reuse it, connected or unconnected but parametrized
    Might be given in settings as alternatively.
    IF NOT GIVEN THE OBJECT POOL IS NOT USED!

    $via: String pointing to the class of the transport object, with all its needed
    functionalities. Will be also found by 'via' string parameter in settings if None.

    $settings: The parameters for building a specific transport object
    from a certain class

    $do_connect: Connect the transport immediatelly

    """
    # could be None here if already pooled:
    via = via or settings.get('via')

    # if not connected pool we might find the pool by ident or pool_id,
    # w/o any via
    # if connected (poolsize given) we need to be able to create the ident,
    # i.e. need the class. See base.py for ident creation.
    pool_id = pool_id or settings.get('pool_id')
    if not pool_id:
        # no pooling:
        t = t_obj_factory(via, settings)
    else:
        # connection_pooling? Not only objects are pooled but also their
        # connections remain OPEN!
        connection_pooling = settings.get('connection_pooling')

        # should we block when there are more needed then avail:
        # number of connections restricted?
        poolsize = settings.get('poolsize')
        if not poolsize and connection_pooling:
            # can't allow infinite open sockets:
            raise Exception("Need poolsize when 'connection_pooling' is set")

        settings['pool_id']            = pool_id
        settings['poolsize']          = poolsize
        settings['connection_pooling'] = connection_pooling

        if pool_id not in OBJ_POOLS:
            with GLOBAL_LOCK:
                if pool_id not in OBJ_POOLS:
                    #TODO: limit the creation rate via the factory.
                    OBJ_POOLS[pool_id] = object_pool_factory(
                            t_obj_factory,
                            obj_args=(via, settings),
                            poolsize=poolsize)
        my_pool = OBJ_POOLS[pool_id]

        # oh what magic (that may BLOCK if poolsize limit is reached):
        t = my_pool.get_object()

    # via might have been set in t before
    # (not in params):
    if via and t.via != via:
        raise Exception("The pooled object had via %s, now %s - can't continue"\
            % (via, t.via))

    if not t.is_connected:
        # parametrize it, either with all or with the
        # specific settings.
        # Note: for connected transports that might not
        # be necessary most of the time
        # parametrization of t - transport groups needs all params:
        t.setup(settings)

        # w/o settings no use to connect. Could be connected already when con.pooling:
        if hasattr(t, 'connect') and do_connect and settings:
            try:
                t.connect()
            except Exception as ex:
                t.close(force_close=True)
                logger.exception(ex)
                raise ex
    return t


def find_class(via, settings):
    # cache:
    t_class = CLASS_BY_NAME.get(via)
    if not t_class:
        # where do we search:
        s_folders = settings.get('via_class_search_folders')
        if is_str(s_folders):
            s_folders = [s_folders]
        if s_folders and isinstance(s_folders, list):
            s_folders.extend(VIA_CLASS_SEARCH_FOLDERS)
        else:
            s_folders = VIA_CLASS_SEARCH_FOLDERS

        full_name = via
        inv = check_inventory(via, s_folders)
        if inv:
            full_name = inv.get('via')
            s_folders = inv.get('path', s_folders)

        # may not(!) change the global folders here:
        try:
            t_class = get_class_by_name(full_name, search_folders = s_folders)
        except Exception as e:
            raise TransportViaClassNotFound(e)
        CLASS_BY_NAME[via] = t_class
    return t_class



def t_obj_factory(via, settings={}):
    """ a pool wants us to deliver a class instance """
    if not via or not is_str(via):
        raise Exception("Wrong or no via")

    # find the class:
    t_class = find_class(via, settings)
    # put objects back in pool, potentially connected:
    t_class = overwrite_close_meth(t_class)
    # make a new transport instance:
    t_obj = t_class()
    t_obj.via = via
    return t_obj





# FACTORY & POOLING:
def close(self, force_close = None, conn_obj = None):
    """ Duck punching the transport's close function
    -> we must get back to the object pool
    """
    if self.flow_capt_proc_id:
        get_proc_res(self.flow_capt_proc_id)
        self.flow_capt_proc_id = 0

    if not hasattr(self, 'pool_id'):
        return self.do_close(conn_obj=conn_obj)

    pool = OBJ_POOLS.get(self.pool_id)
    if self.connection_pooling == None or force_close:
        # never fail here, no matter why:
        try:
            self.do_close(conn_obj=conn_obj)
        except Exception as ex:
            logger.exception("When calling close: %s" % ex)

    self.clear()
    pb = self
    if force_close:
        # this one no one will ever need again:
        if not self.poolsize:
            # unbounded pools can't handle None, wont'
            # get a new one then:
            del(self)
            return
        # pool is bounded. we put <None> so there will be a new
        # connection made by the factory below:
        del(self)
        pb = None
    pool.put_object(pb)



def overwrite_close_meth(t_class):
    """
    now some monkey patching to get clients who call close
    on the transport actually put it back to the pool:
    """
    # already patched?:
    if not hasattr(t_class, 'do_close'):
        # we set the previous (really closing) method to do_close:
        t_class.do_close = t_class.close
        # and patch in the one which does not actually close:
        t_class.close = close
    return t_class



def help():
    from ax.transport import helper
    return helper.get_help(print_out = 0)

def help_exceptions():
    from ax.transport import helper
    return helper.list_exceptions(print_out = 0)

def help_microflows():
    from ax.transport import helper
    return helper.get_microflow_lib(print_out = 0)



