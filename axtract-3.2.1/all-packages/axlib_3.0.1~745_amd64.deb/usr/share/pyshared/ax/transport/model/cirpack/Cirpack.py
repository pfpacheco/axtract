from ax.utils.parsing.parse_text import get_line_val, parse_timestr
import re, sys
from cgi import escape
import time
from datetime import datetime
from netaddr import IPAddress as IP
from netaddr import IPNetwork, EUI
from ax.transport.model.misc import get_uptime_secs, put
from ax.transport.model.misc import get_ifmap_by_ip
from ax.transport.model.misc import safe_cli_get
from ax.transport.model.keyval import depends, lines
from ax.transport.model.model_support import add_model
from ax.transport.model.model_support import Model
import base64
if sys.version_info[0] < 3:
    from urllib import quote
else:
    from urllib.parse import quote
# we work only via these:
DI = '.DeviceInfo.'

class Cirpack(Model):
    root = 'D'
    model = 'DEV2'
    # vendor, product:
    matching = 'cirpack.html'


    def call_web_prov(self, t, params, **kw):
        """
        The control is via wrong quoted URL POSTS:

        POST /WebProv/web_get_entry.cgi HTTP/1.0
        Host: 10.129.200.13
        Content-Length: 52
        Authorization: Basic Y2lycGFjazpmcmlnbw==
        Content-type: x-www-form-urlencoded

        DATA=EXT%26EXTENSIONNAT=3%26EXTENSIONNUM=41938820494

            Eric Hoeger
            Abteilung Switching
            ehoeger@wilhelm-tel.de
        """
        # basic auth:
        auth = base64.b64encode('%s:%s' % (t.user, t.password))
        topost = []
        for k, v in list(params.items()):
            topost.append('%s=%s' % (k, v))
        topost = '&'.join(topost)
        cols = quote(kw.get('cols', ''))
        # the parameter passing is broken on cirpack, order must be like that,
        # so we directly supply the encoded string:
        topost = (('DATA=%sEXT&' % cols) + topost).replace('&', '%26')
        return t.get('WebProv/web_get_entry.cgi',
              headers={'Authorization': 'Basic %s' % auth},
              post_data=topost)


    def get_subscriber(self, t, EXTENSIONNAT, EXTENSIONNUM, cols=''):
        subs = {'EXTENSIONNAT': EXTENSIONNAT, 'EXTENSIONNUM': EXTENSIONNUM}
        return self.call_web_prov(t, params=subs, cols=cols)


    def GPV_DeviceInfo(self, t):
        #foo = self.get_subscriber(t, 3, 41938820494)

        #foo = self.call_web_prov(t,
        #          params={'EXTENSIONNAT': 3, 'EXTENSIONNUM': 41938820494})

        c = t.session_cache
        c['.RootDataModelVersion'] = '2.6'

        c[DI + 'SupportedDataModel.1.URL'] = 'http://localhost/AVM_2.6.xml'
        c[DI + 'SupportedDataModel.1.URN'] = 'urn:axiros-com:device-2-6-0'
        c[DI + 'SupportedDataModel.1.Features'] = 'CirpackFeatures'

        c[DI + 'Manufacturer'] = 'Cirpack'
        # not registered on IEEE:
        c[DI + 'ManufacturerOUI'] = 'CIRPACK'
        c[DI + 'ProductClass'] = 'AXPAND'
        c[DI + 'SoftwareVersion'] = '1.1'
        # HW model: take the first word in the line after Processor board ID:
        c[DI + 'ModelName'] = 'CP'
        c[DI + 'HardwareVersion'] = 'CP'
        c[DI + 'Description'] = 'Cirpack %s Softswitch Managed By Axiros AXPAND' % ''
        c[DI + 'SerialNumber'] = '12345'
        c[DI + 'UpTime'] = 1234
        c['.NSLookupDiagnostics.HostName'] = 'hostname'


add_model(('cirpack.Cirpack', Cirpack()))
