
$.ajaxSetup ({cache: false });

function do_msg(msg, mode, timeout) {
   if (!msg) {
     $('#msg_bar').fadeOut(10); return;
   }
   $('#msg_bar').fadeIn(200);
   var o = $('#badge_msg');
   o.removeClass();
   o.addClass('in');
   o.addClass('badge');
   o.addClass('badge-' + mode);
   o.html(mode);
   $('#txt_msg').html(msg);
   if (timeout) {
       $('#msg_bar').fadeOut(timeout * 1000 );
   }
}

function hide_msg() {
   $('#badge_msg').html('');
   $('#txt_msg').html('');
}

function warning(msg, timeout) {do_msg(msg, 'warning', timeout);}
function info   (msg, timeout) {do_msg(msg, 'info'   , timeout);}


// called after html loading:
function after_html_load() {
    // specify pop="1" to get a popover in any element:
    $("[pop]").popover({html: true, placement: "right"});
    // (other stuff you might want to run on your new html)
}

function req(url, data, res, cb) {
    // res is either html, json(default) or a section. If the latter we update the section html with the result:
    var type = res;
    if (!res) {var type="json"; var res="json";}
    if (res!="html" && res!="json") {var type="html";}

    // spinning wheel on:
    loader();
    // send post to server:
    var posting = $.post(url, data, dataType=type);
    // if html fill the section:
    posting.done(function(resp)  {
        // wheel off:
        loader('off');
        // set the html into the wanted section, and call some js:
        if (type=="html") {$('#' + res).html(resp);
                           after_html_load();
                          }
        if (type=="json") {resp = $.parseJSON(resp)};
        // run the wanted callback:
        if (cb) cb(resp);
    });
}




$(document).ready(function(){  //executed after the page has loaded
    checkURL(); //check if the URL has a reference to a page and load it

    $('ul li a').click(function (e){    //traverse through all our navigation links..

            checkURL(this.hash);    //.. and assign them a new onclick event, using their own hash as a parameter (#page1 for example)

    });

    setInterval("checkURL()",250);  //check for a change in the URL every 250 ms to detect if the history buttons have been used

});

var lasturl=""; //here we store the current URL hash

function checkURL(hash)
{
    if(!hash) hash=window.location.hash;    //if no parameter is provided, use the hash value from the current address
    if (hash == 'noop') {alert(hash);};
    if (hash != lasturl)    // if the hash value has changed
    {   //alert('hash=' + hash + '|Lasthash:'+lasturl);
        lasturl=hash;   //update the current hash
        hash=hash.replace('#page_','');
        var u = window.location.href.split('?');
        var qs = u[1];
        if (!qs) {qs='';}
        req( u[0].split('#')[0] + '/' + hash + '?' + qs, {section:'pageContent'}, 'pageContent');
    }
}

function loader(state) {
   // spinning wheel:
   if (state == 'off' || state == 0) {
          visi = 'hidden';
          //messages off, we just got server stuff back, if its wrong the app will display it anyway:
          do_msg();
  } else {
         visi  = 'visible';
  }
         $('#loading').css('visibility',visi);

} 


