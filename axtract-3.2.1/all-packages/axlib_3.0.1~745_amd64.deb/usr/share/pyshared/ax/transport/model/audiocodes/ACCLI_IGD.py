from ax.utils.parsing.parse_text import get_line_val, get_in, parse_timestr
from cgi import escape
import netaddr
import time
from netaddr import IPNetwork, EUI
from ax.transport.model.misc import get_error_line
from ax.transport.model.misc import get_uptime_secs, run_many, put
from ax.transport.model.misc import safe_cli_get
from ax.transport.model.misc import handle_Upload, handle_Download

from ax.transport.model.keyval import handle_GPV, handle_SPV, handle_GPN
from ax.transport.model.keyval import SPVException, set_flow
from ax.transport.model.keyval import depends, lines, indizes

from ax.transport.model.model_support import add_model
from ax.transport.model.model_support import Model



# we work only via these:
WD = '.WANDevice.1.WANConnectionDevice.1.'
LD = '.LANDevice.1.'


class ACCLI_IGD(Model):
    root = 'I'
    model = 'IGD'
    matching = 'audiocodes.pexpect|ssh|telnet'

    def xGPV_NSLookupDiagnostics_HostName(self, t):
        depends('GPV_DeviceInfo_', t)


    def GPV_DeviceInfo(self, t):
        c = t.session_cache
        DI = '.DeviceInfo.'
        buf = depends('show system version', t)
        c[DI + 'Manufacturer'] = 'AudioCodes'
        c[DI + 'ManufacturerOUI'] = '00908F'
        c[DI + 'ProductClass'] = 'AXPAND'
        c[DI + 'SoftwareVersion'] = get_line_val(buf, 'Software Version', sep=":")
        board = get_line_val(buf, 'Board Name', sep=":")
        c[DI + 'HardwareVersion'] = board
        c[DI + 'ModelName'] = board
        c[DI + 'Description'] = 'AudioCodes %s managed by Axiros AXPAND' % board
        c[DI + 'SerialNumber'] = get_line_val(buf, 'Serial Number', sep = ":")


    def xGPV_DeviceInfo_X_AXIROS_COM(self, t):
        c = t.session_cache
        c['.DeviceInfo.X_AXIROS_COM'] = 'ciao'

    def xGPV_DeviceInfo_DeviceLog(self, t):
        c = t.session_cache
        if c.get('in_inform'):
            return
        buf = depends(t, 'show system active-alarms')
        c['.DeviceInfo.DeviceLog'] = escape(buf[-100:])

    def xGPV_DeviceConfig_ConfigFile(self, t):
        c = t.session_cache
        res = depends('show_run', t)
        c['.DeviceConfig.ConfigFile'] = res


    """
    def xGPV_DeviceConfig_PersistentData(self, t):
        c = t.session_cache
        res = depends('show_startup', t)
        c['.DeviceConfig.PersistentData'] = res

    """

    def xGPV_Time_NTPServer1(self, t):
        """
        address         ref clock       st   when   poll reach  delay  offse
        ~1.2.4.2         .INIT.          16      -     64     0  0.000   0.000 1
        *~62.38.83.25     62.38.0.204      5    801   1024   377  1.351  -5.125
        +~62.38.83.26     62.38.0.205      5     58   1024   377  1.414  -5.231
        * sys.peer, # selected, + candidate, - outlyer, x falseticker, ~ configu
        """
        c = t.session_cache
        for nr in range(1, 4):
            c['.Time.NTPServer%s' % nr] = ''
        buf = t.get('show ntp associations')
        nr = 0
        for l in buf.split('\n'):
            if len(l) > 1 and l[1] == '~':
                nr += 1
                c['.Time.NTPServer%s' % nr] = l[2:].split(' ', 1)[0]


    def xGPV_Time_Status(self, t):
        c = t.session_cache
        buf = t.get('show ntp status')
        if 'not enabled' in buf:
            c['.Time.Status'] = 'Disabled'
        else:
            if ' unsynchronized' in buf:
                c['.Time.Status'] = 'Unsynchronized'
            elif ' synchronized' in buf:
                c['.Time.Status'] = 'Synchronized'
            elif not 'clock' in buf:
                c['.Time.Status'] = 'Disabled'
            else:
                c['.Time.Status'] = 'Error'
        # like: 11:44:59.302 MEZ Sun Jun 16 2002
        clock_buf = t.get('show clock').replace('MEZ', 'CET')
        clock_buf = clock_buf.replace('show clock', '').strip().split('\n')[0].strip()
        if clock_buf.startswith('*'):
            #FIXME: check out what the * means in 
            # *09:14:11.888 UTC Mon Nov 26 2012
            clock_buf = clock_buf[1:]
        # get unixtime:
        ts = parse_timestr(clock_buf, '%H:%M:%S.%f %Z %a %b %d %Y')
        c['.Time.LocalTimeZoneName'] = clock_buf.split(' ')[1]
        tt = time.localtime(ts)
        unixt = time.strftime('%Y-%m-%d %H:%M:%S', tt)
        c['.Time.CurrentLocalTime'] =  unixt





    def xGPV_Time_NTPServer2(self, t):
        depends('GPV_Time_NTPServer1', t)


    def xGPV_Time_NTPServer3(self, t):
        depends('GPV_Time_NTPServer1', t)




    def xGPV_WLANConfiguration(self, t):
        c = t.session_cache
        res = depends('show_run', t)
        values = {}
        prefix = '.LANDevice.5.WLANConfiguration.1.'
        dot11interface = res.split('\ninterface ')[7].split('\n')
        for conf_line in dot11interface:
            if 'ssid' in conf_line:
                values['SSID'] = conf_line.split(' ')[2]
            elif 'encryption mode ciphers' in conf_line:
                ciphers = conf_line.split('encryption mode ciphers ')[-1].split(' ')
                if 'aes-ccm' in ciphers:
                    if 'tkip' in ciphers:
                        values['WPAEncryptionModes'] = 'TKIPandAESEncryption'
                    else:
                        values['WPAEncryptionModes'] = 'AESEncryption'
                elif 'tkip' in ciphers:
                    values['WPAEncryptionModes'] = 'TKIPEncryption'
                elif 'wep128' in ciphers or 'wep40' in ciphers:
                    values['BasicEncryptionModes'] = 'WEPEncryption'
            elif 'channel' in conf_line:
                values['Channel'] = conf_line.split('channel ')[-1]
        if 'BasicEncryptionModes' not in values:
            values['BasicEncryptionModes'] = None
        dot11 = res.split('dot11 ssid')[1].split('!')[0]
        for conf_line in dot11.split('\n'):
            if 'wpa-psk' in conf_line:
                values['PreSharedKey.1.PreSharedKey'] = conf_line.split(' ')[-1]
            elif 'transmit-key' in conf_line and 'size' in conf_line:
                values['WEPKey.1.WEPKey'] = conf_line.split(' transmit-key')[0].split(' ')[-1]
        values['AutoChannelEnable'] = 'Channel' not in values
        
        res = t.get('show dot11 aaa authentication mac-authen filter-cache')
        # if the reply is empty no dhcp server is running
        if res == '':
            c[prefix + 'MACAddressControlEnabled'] = False
        else:
            c[prefix + 'MACAddressControlEnabled'] = True



    def xGPV_LANDevice(self, t):
        ipbrief = depends('show_ip_int', t)




    def xGPV_LANHostConfigManagement(self, t):
        c = t.session_cache
        res = depends('show_run', t)
        pools = {}
        while 1:
            try:
                new_pool = {}
                pool = \
                  res.split('ip dhcp pool', 1)[1].split('!', 1)[0].split('\n')
                res = res.split('ip dhcp pool', 1)[1]
                pool_name = pool[0].replace(' ','')
                for line in pool[1:]:
                    line = line.strip(' ')
                    if line.startswith('network'):
                        new_pool['SubnetMask'] = line.split(' ')[-1].strip()
                        address = line.split(' ')[1].strip()
                        ip = IPNetwork(address + '/' + new_pool['SubnetMask'])
                        new_pool['MaxAddress'] = (netaddr.IPAddress(ip.last) - 1).__str__()
                        new_pool['MinAddress'] = (netaddr.IPAddress(ip.first) + 1).__str__()
                    elif line.startswith('default-router'):
                        new_pool['IPRouters'] = \
                            line.split('default-router ')[1].replace(' ', ',')
                    elif line.startswith('domain-name'):
                        new_pool['DomainName'] = line.split(' ')[-1]
                    elif line.startswith('dns-server'):
                        new_pool['DNSServers'] = \
                                line.split('dns-server ')[1].replace(' ', ',')
                    elif line.startswith('lease'):
                        if 'infinite' in line:
                            new_pool['DHCPLeaseTime'] = 'infinite'
                        else:
                            lease, days, hours, minutes = line.split(' ')
                        new_pool['DHCPLeaseTime'] = str(int(days) * 86400 + \
                                int(hours) * 3600 + int(minutes) * 60)
                pools[pool_name] = new_pool
            except IndexError:
                break
        """ the pools dict should be like this(keys are the pool names):
            {
              '1': {'SubnetMask': '255.255.0.0',
                    'IPRouters': '172.16.1.100,172.16.1.101',
                    'DomainName': 'axiros.com',
                    'DNSServers': '172.16.1.102,172.16.2.102',
                    'MinAddress': '172.16.0.1',
                    'MaxAddress': '172.16.255.254'
                    },
              '192.168.2.0/24': {'DomainName': 'ssg-test.local',
                    'IPRouters': '192.168.2.254',
                    'DHCPLeaseTime': '1800',
                    'SubnetMask': '255.255.255.0',
                    'DNSServers': '192.168.1.1',
                    'MinAddress': '192.168.2.1',
                    'MaxAddress': '192.168.2.254'
              }
            }
        """
        index = 1
        for pool in list(pools.values()):
            prefix = '.LANDevice.x.LANHostConfigManagement.DHCPConditionalServingPool.%d.' % index
            for k, v in list(pool.items()):
                c[prefix + k] = v
            index += 1

        res = t.get('show control-plane host open-ports | i \*:67\ ')
        # if the reply is empty no dhcp server is running
        if res == '':
            c['.LANDevice.x.LANHostConfigManagement.DHCPServerEnable'] = False
        else:
            c['.LANDevice.x.LANHostConfigManagement.DHCPServerEnable'] = True

        res = t.get('show ip interface brief')
        # -1 is for the localinterface
        c['.LANDevice.x.LANHostConfigManagement.IPInterfaceNumberOfEntries'] = 2
        




# -------------------------------Helpers

    def show_run(self, t):
        res = safe_cli_get(t, 'show run', 30)
        return res.split('!', 1)[1].strip()


    def show_startup(self, t):
        res = safe_cli_get(t, 'show startup-config')
        return res.split('!', 1)[1].strip()


    def show_ip_nat_translations(self, t):
        """
        test_C877_BRM#show ip nat translations
        Pro Inside global         Inside local          Outside local         \
                                                                Outside global
        tcp 5.55.224.4:889        192.168.1.10:80       ---                   \
                                                                ---
        tcp 62.38.95.90:389       192.168.1.11:389      ---
        tcp 5.55.224.4:3389       192.168.1.11:3389     10.5.80.225:4184
        tcp 5.55.224.4:3389       192.168.1.11:3389     ---
        test_C877_BRM#
        """
        c = t.session_cache
        res = []
        index = 0
        cmd = 'show ip nat translations'
        for line in lines(t.get(cmd)):
            l = line.split()
            if len(l) < 3 or cmd in line:
                continue
            index += 1
            outip, outport = l[1].split(':')
            inip,  inport  = l[2].split(':')
            res.append({
                          'outIP': outip, 'outPort': outport,
                          'inIP' : inip,  'inPort' : inport,
                          'proto': l[0].upper()
                       }
                      )
        c['show_ip_nat_translations'] = res

    def show_ip_int(self, t):
        c = t.session_cache
        # we will split below, delete the space in the column:
        out = t.get('show interface')  
        # ip int | inc line | Internet address')

        ifs = {
            'ATM':            [],
            'Dialer':         [],
            'Vlan':           [],
            'Dot11Radio':     [],
            'FastEthernet':   [],
            'Virtual-Access': []
              }
        nfos = {}

        # first parse results into mappings:
        #import pdb; pdb.set_trace()
        valid = False
        if_name = "";
        for line in lines(out):
            #search for interface information
            if not line.startswith(' ') and line.strip():
                valid = False
                if_name = line.split(' ', 1)[0]
                # check if name is valid:
                for if_type in ifs:
                    if line.startswith(if_type):
                        valid = True
                        ifs[if_type].append(if_name)
                        if_map = {'Name': if_name,
                                  'Duplex': 'Auto',
                                  'Speed': 'Auto'}
                        nfos[if_name] = if_map
                        if_map['Status'] = 1
                        if 'down' in line:
                            if_map['Status'] = 0
                        break

                continue
            elif valid:  # interface found
                line = line.strip().lower()
                print((line, "-" * 100))
                if line.startswith('internet address is '):
                    ip = IPNetwork(line.rsplit(' ', 1)[1])
                    if_map['IP'], if_map['Netmask'] = str(ip.ip), str(ip.netmask)
                elif 'uplex' in line:
                    if 'half' in line:
                        if_map['Duplex'] = 'Half'
                    else:
                        if_map['Duplex'] = 'Full'
                    if_map['Speed'] = get_line_val(line, ' ', sep='mb/s', get=0)
                elif line.startswith('hardware is'):
                    if line.find("address is "):
                        # if this is a real IF we have the mac in this line:
                        try:
                          if_map['MAC'] = str(EUI(get_line_val(line,
                            'address is ',
                            sep=' ',
                            get=0)))
                        except netaddr.core.AddrFormatError as ex:
                            if_map['MAC'] = ''
                elif line.find('packets input,') > 0:
                    stat = line.split()
                    if_map['rx_bytes'] = int(stat[3])   
                    if_map['rx_packets'] = int(stat[0]) 
                elif line.find('packets output,') > 0:
                    stat = line.split() 
                    if_map['tx_bytes'] = int(stat[3])    
                    if_map['tx_packets'] = int(stat[0])                   
            else:
                print(("DBG invalid line>%s<" % line))
         
        WAN_MAP = ['ATM0/2/0']
        # - ethx : LAN interfaces (x != WAN_MAP)
        # - lo: not modelled
        # O.I - store index counters in cache ?
        #import pdb; pdb.set_trace()
        noIPIF = 0
        noWANDEV = 0
        noWANIPCON = 0
        noLANDEV = 0
        noLANETH = 0
        c['.WANDeviceNumberOfEntries'] = noWANDEV
        c['.LANDeviceNumberOfEntries'] = noLANDEV
        for if_type, if_names in list(ifs.items()):
            for if_name in if_names:
                if_map = nfos[if_name]
                tr_node = None
                index = if_names.index(if_name) + 1
                m = if_map
                # test for WAN interfaces
                ifwan = False
                wm = False
                for wan in WAN_MAP:
                    if if_name.startswith(wan):
                        ifwan = True
                        wm = (if_name == wan)
                        break
                
                if ifwan:
                    # create WAN model
                    if wm:
                        noWANDEV += 1
                        c['.WANDeviceNumberOfEntries'] = noWANDEV
                        twan = '.WANDevice.%d.WANCommonInterfaceConfig.' % noWANDEV
                        c[twan + 'EnabledForInternet'] = '1'
                        if if_map['Status'] == 1:
                            c[twan + 'PhysicalLinkStatus'] = "Up"
                        else:
                            c[twan + 'PhysicalLinkStatus'] = "Down"
                        c[twan + 'TotalBytesSent'] = 0
                        c[twan + 'TotalBytesReceived'] = 0
                        c[twan + 'TotalPacketsSent'] = 0
                        c[twan + 'TotalPacketsReceived'] = 0
                    wan_device = '.WANDevice.%d.' % noWANDEV
                    
                    # for Ethernet (interface or link), only one WANConnectionDevice instance is supported:
                    if if_name != wan:   # only model ATM0/2/0.x as connection! 
                        noWANIPCON += 1
                        c[wan_device + 'WANConnectionNumberOfEntries'] = 1
                        c[wan_device + 'WANConnectionDevice.1.WANIPConnectionNumberOfEntries'] = noWANIPCON
                        tr = wan_device + 'WANConnectionDevice.1.WANIPConnection.%d.' % noWANIPCON
                        c[tr + 'Enable'] = "1"
                        if if_map['Status'] == 1:
                            c[tr + 'ConnectionStatus'] = "Connected"
                        else:
                            c[tr + 'ConnectionStatus'] = "Disconnected"
                        put(c, tr, 'ExternalIPAddress', m, 'IP')
                        put(c, tr, 'SubnetMask', m, 'Netmask')
                        put(c, tr, 'MACAddress', m, 'MAC')
                        c[tr + 'PortMappingNumberOfEntries'] = "0"
                        c[tr + 'PortMapping'] = ''
                        tr += 'Stats.'
                        put(c, tr, 'EthernetBytesSent', m, 'tx_bytes')
                        put(c, tr, 'EthernetBytesReceived', m, 'rx_bytes')
                        put(c, tr, 'EthernetPacketsSent', m, 'tx_packets')
                        put(c, tr, 'EthernetPacketsReceived', m, 'rx_packets')
                        put(c, tr, 'EthernetErrorsSent', m, 'tx_errors')
                        put(c, tr, 'EthernetErrorsReceived', m, 'rx_errors')
                        put(c, tr, 'EthernetDiscardPacketsSent', m, 'tx_dropped')
                        put(c, tr, 'EthernetDiscardPacketsReceived', m, 'rx_dropped')
                        if 'tx_bytes' in m:
                            c[twan + 'TotalBytesSent'] += int(m['tx_bytes'])
                            c[twan + 'TotalBytesReceived'] += int(m['rx_bytes'])
                            c[twan + 'TotalPacketsSent'] += int(m['tx_packets'])
                            c[twan + 'TotalPacketsReceived'] += int(m['rx_packets']) 

                elif if_type == 'FastEthernet':
                    #import pdb; pdb.set_trace()
                    # create LAN interfaces model
                    k = if_name.split(':')
                    if not k[1:2]:
                        # create new LANDevice
                        noLANDEV += 1
                        c['.LANDeviceNumberOfEntries'] = noLANDEV
                        noLANETH = 0
                        tld = '.LANDevice.%d.' % noLANDEV
                        c[tld + 'LANConfigurationNumberOfEntries'] = 0
                    # create new LANEthernetInterfaceConfig
                    noLANETH += 1
                    c[tld + 'LANEthernetInterfaceNumberOfEntries'] = noLANETH
                    tr = tld + 'LANEthernetInterfaceConfig.%d.' % noLANETH 
                    if if_map['Status'] == 1:
                        c[tr + 'Status'] = "Up"
                    else:
                        c[tr + 'Status'] = "Disabled"
                    #put(c, tr, 'LastChange', m, 'status_changed')
                    put(c, tr, 'MACAddress', m, 'MAC')
                    put(c, tr, 'MaxBitRate', m, 'Speed')
                    put(c, tr, 'DuplexMode', m, 'Duplex')
                    c[tr + 'Name'] = if_name
                    if 'tx_bytes' in m:
                        tr += 'Stats.'
                        put(c, tr, 'BytesSent', m, 'tx_bytes')
                        put(c, tr, 'BytesReceived', m, 'rx_bytes')
                        put(c, tr, 'PacketsSent', m, 'tx_packets')
                        put(c, tr, 'PacketsReceived', m, 'rx_packets')
                        put(c, tr, 'ErrorsSent', m, 'tx_errors')
                        put(c, tr, 'ErrorsReceived', m, 'rx_errors')
                        put(c, tr, 'DiscardPacketsSent', m, 'tx_dropped')
                        put(c, tr, 'DiscardPacketsReceived', m, 'rx_dropped')

                if tr_node:
                    # remember the node with indizes:
                    nfos[if_name]['tr_index'] = index
        return [ifs, nfos]




    def show_ip_int_gk(self, t):
        """
test_C877_BRM>show ip int | inc line | address
ATM0 is up, line protocol is up
Dialer0 is up, line protocol is up
Dialer46 is up, line protocol is up
  Internet address is 5.55.224.4/32
  Broadcast address is 255.255.255.255
  Helper address is not set
  Network address translation is enabled, interface in domain outside
Dot11Radio0 is administratively down, line protocol is down
FastEthernet0 is up, line protocol is up
FastEthernet1 is up, line protocol is down
FastEthernet2 is down, line protocol is down
FastEthernet3 is down, line protocol is down
NVI0 is administratively down, line protocol is down
Virtual-Access1 is up, line protocol is up
  Peer address is 62.38.0.170
Vlan1 is administratively down, line protocol is down
Vlan10 is up, line protocol is down
  Internet address is 192.168.1.1/24
  Broadcast address is 255.255.255.255
  Helper address is not set
  Network address translation is enabled, interface in domain inside
Vlan100 is up, line protocol is up
  Internet address is 62.38.95.90/30
  Broadcast address is 255.255.255.255
  Helper address is not set
  Network address translation is disabled
test_C877_BRM>
        """
        c = t.session_cache

        # we will split below, delete the space in the column:
        t.get('')
        out = t.get('show ip int | inc line | Internet address')

        ifs = {
            'ATM':            [],
            'Dialer':         [],
            'Vlan':           [],
            'Dot11Radio':     [],
            'FastEthernet':   [],
            'Virtual-Access': []
              }
        nfos = {}

        for line in lines(out):
            print(('!', line))
            if line and not line.startswith(' '):
                if_name = line.split(' ', 1)[0]
                if_map = {'Name': if_name}
                nfos[if_name] = if_map
                if_map['Status'] = 1
                if 'down' in line:
                    if_map['Status'] = 0

                for if_type in ifs:
                    if line.startswith(if_type):
                        ifs[if_type].append(if_name)
                        break
                continue

            if line.startswith('  Internet address is '):
                ip = IPNetwork(line.rsplit(' ', 1)[1])
                if_map['IP'], if_map['Netmask'] = str(ip.ip), str(ip.netmask)

        for if_type, if_names in list(ifs.items()):
            for if_name in if_names:
                if_map = nfos[if_name]
                tr_node = None
                if not if_map.get('IP'):
                    continue
                index = if_names.index(if_name) + 1

                if if_type == 'Dialer':
                    tr_node = WD + 'WANPPPConnection.%s.' % index
                    c[tr_node + 'Name'] = if_name
                    c[tr_node + 'Enable'] = if_map['Status']
                    c[tr_node + 'ExternalIPAddress'] = if_map['IP']

                elif if_type == 'FastEthernet':
                    tr_node = LD + 'LANEthernetInterfaceConfig.%s.' % index
                    c[tr_node + 'Name'] = if_name
                    c[tr_node + 'Enable'] = if_map['Status']

                    tr_node = LD + 'LANHostConfigManagement.IPInterface.%s.' %\
                                    index
                    c[tr_node + 'IPInterfaceIPAddress'] = if_map['IP']
                    c[tr_node + 'IPInterfaceSubnetMask'] = if_map['Netmask']

                if tr_node:
                    # remember the node with indizes:
                    nfos[if_name]['tr_node'] = tr_node

        return [ifs, nfos]




# -----------  Setter Methods:

    setters = {'SPV_LANSetup': ['LANHostConfigManagement']}
    error_markers = ['Bad ', 'nvalid ', ' ncomplete ']
    exit_context = ['exit', 'end']


    def commit_on_close(self, t):
        # this takes long, do it only on close:
        t.get('copy running-config startup-config', timeout=10)



    def SPV_LANSetup(self, t):
        # all SPV params:
        c = t.session_cache
        params = c['to_set_params']
        # get state:
        ifs, nfos = depends('show_ip_int', t)

        # configure:
        t.get('conf t')

        # stringify SPV map:
        s_params = str(params)

        # check all ifs which are found (i.e. in c):
        for index in indizes(LD + 'LANEthernetInterfaceConfig.', c):
            if_node = LD + 'LANEthernetInterfaceConfig.%s.' % index
            ip_node = LD + 'LANHostConfigManagement.IPInterface.%s.' % index

            if_name = c.get(if_node + 'Name')
            if not if_name or not (if_node in s_params or ip_node in s_params):
                # iface not there or nothing to change on this one:
                continue

            t.get('interface %s' % if_name)
            # enable?
            key = if_node + 'Enable'
            v = params.get(key)
            set_map = {'c': cache,
                       't': t,
                       'error_markers' : self.error_markers,
                       'ctx_exit': self.exit_context
                       }

            if v != None:
                # enable param set to a value. run the cmd:
                set_map['affects_params'] = key
                if str(v) == '1':
                    set_map['flow'] = 'no shutdown'
                else:
                    set_map['flow'] = 'shutdown'
                set_flow(set_map)

            # ip setup with ip address and netmask?
            ip_key =  ip_node + 'IPInterfaceIPAddress'
            net_key = ip_node + 'IPInterfaceSubnetMask'

            if ip_key in s_params or net_key in s_params:
                ip  = params.get(ip_key,  nfos[if_name]['IP'])
                net = params.get(net_key, nfos[if_name]['Netmask'])
                set_map['affects_params'] = (ip_key, net_key)
                set_map['flow'] = 'ip address %s %s' % (ip, net)
                set_flow(set_map)

            # next iface, or exit on error:
            t.get('exit')

        # back to show mode:
        t.get('end')



# -----------  Upload and Download Support:


    def do_http_cfg_upload(self, t, url, *args, **kwargs):
        res = t.get('copy run %s' % url, condition='?')
        res = t.get('', condition='?')
        res = t.get('', timeout=10)
        if 'Error' in res:
            err = get_error_line(str(res), 'Error')
            raise Exception(err)
    do_tftp_cfg_upload = do_http_cfg_upload


    def do_http_cfg_download(self, t, url, file_name, file_size,*args,**kwargs):
        if not file_name:
            file_name = 'running-config'
        else:
            t.get('delete flash:%s' % file_name, condition='?')
            t.get('', condition='onfirm]')
            t.get('')

        res = t.get('copy %s %s' % (url, file_name), condition='?')
        if 'Error' in res:
            raise Exception(get_error_line(str(res), 'Error'))
        if file_name == 'running-config':
            res = t.get('', timeout=10)
            if 'copied' in res:
                # apply it:
                t.get('copy running-config startup-config', condition='?')
                t.get('', timeout=30)
                return
            raise Exception(str(res), 'Error')

        res = t.get('', condition='?', timeout=10)
        if 'Error' in res:
            raise Exception(get_error_line(str(res), 'Error'))
        if 'Erase flash' in res:
            res = t.get('n', timeout=10)
        if 'copied' in res:
            return
        raise Exception(str(res), 'Error')
    do_tftp_cfg_download = do_http_cfg_download




# -----------  Supported TR-069 RPCs:  


    def GetParameterValues(self, params, t):
        # use the default handler:
        return handle_GPV(params, t)


    def SetParameterValues(self, params):
        # use the default handler:
        return handle_SPV(params, t)


    def GetParameterNames(self, params):
        # use the default handler:
        return handle_GPN(params, t)


    def Reboot(self, params, t):
        # we save the running config before reboot:
        res = t.get('reload', condition=']')
        if 'Save?' in res:
            res = t.get('yes', condition='onfirm]', timeout=20)
        if 'reload?' in res:
            res = t.get('confirm', condition=None)
        return {}


    def Download(self, params, t):
        return handle_Download(params, t)


    def Upload(self, params, t, cpe=None, c={}):
        return handle_Upload(params, t, cpe, c)



add_model(('axiros.audiocodes.ACCLI_IGD', ACCLI_IGD()))
