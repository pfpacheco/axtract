from ax.transport.model.keyval import depends
from ax.transport.model.model_support import add_model
from ax.transport.model.model_support import Model
try:
    import pynetsnmp.netsnmp
except ImportError:
    print ("\npynetsnmp is not installed. SNMP model is not usable")
    print ("To install use apt-get install python-pynetsnmp\n")
from ctypes import cdll, c_char_p, c_ulong, c_size_t, \
    pointer, create_string_buffer

class SNMP(Model):
    """
    A general SNMP Model that can serve as the basic model
    for any snmp device model. Import it like:
    from ax.transport.model.protocols.snmp import SNMP
    and make your snmp model inherit from this class
    """
    root = 'D'
    dev  = 0.1
    model = 'DEV2'
    matching = '*.snmp'
    rpcs_custom = ['Get',
            'BulkGet',
            'Walk',
            'BulkWalk',
            'Set']

    #netsnmp lib initialization
    try:
        libnetsnmp = pynetsnmp.netsnmp.lib
        libnetsnmp.init_snmp("translator")
        MAX_OID_LEN = 128
        BUFF_LEN = 32 * MAX_OID_LEN
    except NameError:
        pass

    def _strOID2Array(self, oid_str):
        """
        accepts strings like "1.3.6.1.2.1.1.1.0"
        and converts them into a ctypes array
        """
        oid_str = oid_str.split('.')
        array = (c_ulong * len(oid_str))()
        for i in range(0, len(oid_str)):
            array[i] = c_ulong(int(oid_str[i]))
        return array

    def name_to_oid(self, name):
        """
        accepts names like "sysDescr.0"
        and returns the oid like a string
        eg "1.3.6.1.2.1.1.1.0" or None if it fails
        """
        input_ = c_char_p(name)
        output = (c_ulong * self.MAX_OID_LEN)()
        out_len = c_size_t(self.MAX_OID_LEN)

        if not self.libnetsnmp.get_node(input_, output, pointer(out_len)):
            return None
        oid = ''
        for i in range(out_len.value):
            oid += str(output[i])
            oid += '.'
        oid = oid.rstrip('.')
        return oid

    def oid_to_name(self, oid):
        """
        accepts an oid as a string like "1.3.6.1.2.1.1.1.0"
        and returns the human readable name
        eg SNMPv2-MIB::sysDescr.0
        """
        oid = self._strOID2Array(oid)
        output = create_string_buffer(self.BUFF_LEN)
        if self.libnetsnmp.snprint_objid(output, c_size_t(self.BUFF_LEN), oid,
                c_size_t(len(oid))):
            return output.value
        else:
            return None

    def get_info(self, id_, is_oid=False):
        """
        accepts the name or the oid in a string form
        with the proper flag set and returns a tuple
        with the snmp type and the permissions of the
        object as strings
        """
        if not is_oid:
            oid = self.name_to_oid(id_)
        else:
            oid = id_
        oid = self._strOID2Array(oid)
        output = create_string_buffer(self.BUFF_LEN)
        type_ = permissions = None
        if self.libnetsnmp.snprint_description(output, c_size_t(self.BUFF_LEN),
                oid, c_size_t(len(oid)), 0):
            output = output.value.split('\n')
            for i in output:
                if 'SYNTAX' in i:
                    type_ = i.split('\t')[1]
                elif 'MAX-ACCESS' in i:
                    permissions = i.split('\t')[1]
        return (type_, permissions)


# -------------------------------Helpers
add_model(('snmp', SNMP()))

RUN = ""
