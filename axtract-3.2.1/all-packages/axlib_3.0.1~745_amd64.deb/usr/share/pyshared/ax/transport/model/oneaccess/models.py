from ax.transport.model.oneaccess.ONEOS_IGD import ONEOS_IGD

register = {'oneaccess.ONEOS_IGD': ONEOS_IGD}
