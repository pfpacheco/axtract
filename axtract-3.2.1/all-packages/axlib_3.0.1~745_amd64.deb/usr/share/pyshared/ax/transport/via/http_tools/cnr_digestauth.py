import sys
if sys.version_info[0] < 3:
    from httplib import HTTPConnection
    from httplib import BadStatusLine
else:
    from http.client import HTTPConnection
    from http.client import BadStatusLine

from .digest_algorithm import DigestAlgorithm
from collections import defaultdict

MAX_401 = 2
MAX_503 = 1
MAX_OTHER = 3

CPE_DOES_BASIC_AUTH = "WARNING: CPE does BASIC auth, which has security risks"

class CNRRejected(Exception):
    pass

class AuthDigestClient(object):
    def __init__(self, server, path, username, password,
                 caller=None, timeout=7, cpe_model='', cpe_version='',
                 readall=None):
        """
        @param server: string like 'IP:PORT' or "IP"
        @param readall: if not set then close on status 200 w/o read
        """

        self.caller = caller
        self.server = server
        self.path = path

        self.username = username
        self.password = password
        self.readall  = readall

        self.digest_algo = DigestAlgorithm(username, password, path)
        self.headers = {'Accept': '*/*'}

        self.timeout = timeout
        # this is the REAL connection to the client!
        self.connection = HTTPConnection(self.server, timeout=self.timeout)

        self.retry_counters = defaultdict(int)

    def log(self, level, msg):
        if self.caller is None:
            print (msg)
        else:
            self.caller.log(level, msg)

    def call(self):
        try:
            return self._call()
        finally:
            self.connection.close()

    def _call(self):
        while True:
            resp = self._send_cnr()

            if resp.status == 200:
                return resp.status

            if not self._should_retry(resp):
                raise Exception(self._gen_retry_error_msg())

            try:
                # this method will figure out if the correct headers are there
                self._fill_headers_with_credentials(resp)
            except Exception as error:
                msg = "Cannot decode headers coming from the CPE: %s"
                raise Exception(msg % error)

    def _gen_retry_error_msg(self):
        msg = "Never received a valid reponse from the CPE. "
        msg += "Number of received Unauthorized(401): '%i' - "
        msg += "Number of received Service Unavailable(503): '%i' - "
        msg += "Number of other invalid responses: '%i'"
        nb_401 = self.retry_counters[401]
        nb_503 = self.retry_counters[503]
        return msg % (nb_401, nb_503, self._get_other_count())

    def _send_cnr(self):
        try:
            resp = self._send_and_get_resp()
            if resp.status == 200:
                return resp
        except BadStatusLine:
            # Some CPEs like the Huawei HG520 pretend to support HTTP/1.1
            # *but are closing the connection after the first Req/Resp.
            # Which is in fact HTTP/1.0 but without sending the
            # connection close header. So we have not chance to detect this
            # wrong implementation before.
            # Our strategy in that case is to try it again *once*
            self.connection.close()
            self.connection = HTTPConnection(self.server, timeout=self.timeout)
            resp = self._send_and_get_resp()

        # If the CPE wants a new socket it signals it via this header
        # (look inside the RFC for HTTP1.1 about this header)
        if resp.getheader('connection', '') == 'close':
            self.connection.close()
            self.connection = HTTPConnection(self.server, timeout=self.timeout)

        return resp

    def _send_and_get_resp(self):
        try:
            self.connection.request('GET', self.path, headers=self.headers)
            resp = self.connection.getresponse()
            if not self.readall and resp.status==200:
                # this would be way faster for AVM, they don't serve the body until CWMP session is over:
                # but for now I leave it like it was (if 0)
                resp.close()
                return resp

            # read all the remaining data, otherwise the CPEs are confused
            # that we are sending data back without fully receiving the first
            # message.  Needed if the CPE sends the answer back with
            # 'Transfer-Encoding: chunked'. Then we need to read at least the
            # trailing '0'

            # In the 200 case the client MIGHT ALSO want to read all, since then
            # at least for the AVMs he gets ALWAYS a 200 if CNR URL works (while
            # socket.reject at AVM when Inform ongoing, so he could not tell the
            # difference to a closed firewall).
            # On AXESS as client we by default DON'T read but check at eror case
            # the timestamp in the SQL to tell if an Inform is ongoing ;-)
            resp.read()

            # we can close the response, because we dont need the body
            # inside (headers still there).
            # According to the docu we HAVE to close the response,
            # otherweise it is not possible to send a new request over the
            # same connection(socket). Which is needed in HTTP1.1
            resp.close()

            return resp
        except Exception as ex:
            self.connection.close()
            if ex.errno == 104:
                # connection reset by peer. That happens not at wrong self.path
                # but ALSO while CPE is busy, informing.
                # so we send success (if no inform would come, CM typically writes
                # no reach anyway, before sending the CNR):
                raise CNRRejected
            raise ex

    def _fill_headers_with_credentials(self, resp):
        incoming_headers = dict(resp.getheaders())
        if 'basic' in incoming_headers.get('www-authenticate', '').lower():
            self.log(1, CPE_DOES_BASIC_AUTH)
            auth = ":".join((self.username, self.password)).encode('base64').strip()
            self.headers.update({'Authorization': 'Basic %s' % auth})
        else:
            challenge = self.digest_algo.get_challenge(incoming_headers)
            if challenge is not None:
                self.headers['Authorization'] = self.digest_algo.calc(challenge)

    def _should_retry(self, resp):
        self.retry_counters[resp.status] += 1
        if self.retry_counters[401] == MAX_401:
            return False

        if self.retry_counters[503] == MAX_503:
            return False

        other_count = self._get_other_count()
        if other_count == MAX_OTHER:
            return False

        return True

    def _get_other_count(self):
        other_count = 0
        for code, number in self.retry_counters.items():
            if code not in (401, 503):
                other_count += number
        return other_count


def client_verify(username, password, realm, method, uri, nonce, nc, cnonce, qop, response):
    from hashlib import md5
    HA1 = md5('%s:%s:%s' % (username, realm, password)).hexdigest()
    HA2 = md5('%s:%s' % (method, uri)).hexdigest()

    cacl = md5("%s:%s:%s:%s:%s:%s" % ( HA1, nonce, nc, cnonce, qop, HA2)).hexdigest()

    print (cacl)
    print (response)
    print((cacl == response))

def test_old():
    client_verify(
            '1277472598175',
            '1277472598175',
            'sphairon',
            'GET',
            '/ConnectionRequest',
            '4c25f79aca8e67437098',
            '00000001',
            '6166b59701d43c35',
            'auth',
            '25b5f96a5d6c28878b82195c9a964fb6'
    )

def test_new():
    client_verify(
            '1277472598175',
            '1277472598175',
            'sphairon',
            'GET',
            '/ConnectionRequest',
            '4c25f79aca8e67437098',
            '00000001',
            '121b3f27a266c3ff',
            'auth',
            '7389ee7f80e214967ea16af5d87ab09d'
        )

def test_for_sphairon():
    client = AuthDigestClient(
                    '10.11.1.123:7179',
                    '/ConnectionRequest',
                    '1277472598175',
                    '1277472598175')

    headers = {
            'www-authenticate': 'Digest realm="sphairon", qop="auth,auth-int",'\
                                'nonce="4c25f79aca8e67437098", opaque="cae4a950"'
        }
    challenge = client.digest_algo.get_challenge(headers)
    ret = client.digest_algo.calc(challenge)
    ret =  _parse_result(ret)
    ret['password'] = '1277472598175'
    ret['method'] = 'GET'
    ret.pop('algorithm')
    ret.pop('opaque')
    client_verify(**ret)

def _parse_result(value):
    value = value.replace('Digest ', '')
    def foo(a, b):
        a = a.strip()
        b = b.replace('"', '')
        return a,b
    return dict([ foo(*x.split('=')) for x in value.split(',')])

if __name__ == '__main__':
    test_new()
    test_old()
    test_for_sphairon()
    cl = AuthDigestClient('93.104.237.212:8089', '/c46aaa9d', '1298971774856', '1298971774856')
    print((cl.call()))
