#!/opt/axess/bin/call_with_eggs

from gevent import monkey
monkey.patch_all()
try:
    import gevent
    from gevent.server import StreamServer
    from gevent.server import socket as gevent_socket
except ImportError as e:
    raise ImportError('gevent version 0.13.8 or higher needed')
import logging
import binascii
import os
from ax.transport.servers.sml.sml_lib import SMLParser, SMLDevice
USE_AXTRACT = True
try:
    from ax.transport.servers.sml.event_to_axtract import EventToAxtract
except ImportError as e:
    USE_AXTRACT = False
import urllib
import urllib2
import redis
import simplejson
import signal
from ax.daemon.daemon import AxDaemon


class SMLServer(object):
    """SML server implementation"""
    def __init__(self, device_pool, sml_queue, socket_timeout, acs_url,
            redis_host, node_name, logger):
        global USE_AXTRACT
        self.use_axtract = USE_AXTRACT
        self.logger = logger
        self.socket_timeout = socket_timeout + 10
        self.acs_url = acs_url
        self.logger.debug("Starting SML Server...")
        self.message_type = {'10': 'key_exchange',
                '20': 'data',
                '21': 'push',
                '22': 'logon'}
        self.device_pool = device_pool
        self.sml_queue = sml_queue
        self.messages_processed = 0
        self.redis = redis.Redis(redis_host)
        self.http_timeout = 3
        self.node_name = node_name
        self.eventcode_prefix = 'M X_AXIROS_'

    def parse_sml_payload(self, cpeid, frame_id, payload):
        """initial parsing of the incoming payload"""
        sml_ack = False
        first_four = payload[0:8]
        second_four = payload[8:16]
        if(not int(first_four, 16) & 0xffffffff == 0x1b1b1b1b \
                and int(second_four, 16) & 0xffffffff == 0x01010101):
            self.logger.error('Starting Sequence not found')
        device = self.device_pool.get(cpeid, None)
        if device:
            response = {}
            event = self.message_type[frame_id]
            self.logger.debug("%s: RECEIVED: %s", cpeid, payload[16:])
            sml_messages = device.parse_data(payload[16:])
            try:
                values = sml_messages[1].get_result()
            except AttributeError:
                # this means it was a response to the push message
                values = 'SML ACK'
                sml_ack = True
            transaction_id = sml_messages[0].get_transaction_id()
            response['cpeid'] = device.cpeid
            response['event'] = self.eventcode_prefix + event
            response['node'] = self.node_name
            self.logger.debug("%s: %s", cpeid, values)
            step = None
            if event == 'data':
                metadata = device.get_metadata(transaction_id)
                if metadata is None:
                    self.logger.warning("Invalid transaction ID received. Aborting...")
                    device.command_sequence_complete.release()
                    return
                step = metadata['step']
                inline = metadata.get('inline')
                if 'Failure: ' in str(values) and device.command_list_flag:
                    return
                elif 'Failure: ' in str(values) and not device.command_list_flag:
                    values = device.get_buffer()
                else:
                    if device.command_list_flag:
                        if device.last_job_successful:
                            if device.add_to_buffer(values):
                                return
                        else:
                            os.kill(os.getpid(), signal.SIGUSR1)
                            values = device.get_buffer()
                    else:
                        if device.last_job_successful:
                            device.add_to_buffer(values)
                        values = device.get_buffer()
            device.command_sequence_complete.release()
            response['step'] = step
            response['response'] = simplejson.dumps(values)
            response['ip'] = device.get_ip()
            device.reset_buffer()
            if event == 'data':
                self.logger.debug(response)
                if not sml_ack:
                    if not inline is None:
                        self.reply_to_redis(inline, response['response'])
                    self.notify_nbi(response)
            elif event == 'logon':
                response['event'] = '1 BOOT'
                device.set_timezone(sml_messages[0].get_timezone())
                self.notify_nbi(response)
            elif event == 'push':
                device.add_job('sml_ack', {}, None, None)
                self.logger.debug('Send an SML ACK to \'%s\'',
                        device.cpeid)
                if self.use_axtract:
                    try:
                        self.sml_queue.create_event(device.cpeid, values)
                        self.logger.debug('%s: Forward to axtract successful',
                                device.cpeid)
                    except Exception as axt_e:
                        self.logger.debug('%s: Forward to axtract failed: %s',
                                device.cpeid, axt_e.args[0])
                self.notify_nbi(response)
        else:
            data_to_send = {'cpeid': cpeid, 'node': self.node_name,
                    'event': 'DISCONNECT'}
            self.notify_nbi(data_to_send)
            self.logger.debug(cpeid + ' not in pool')

    def reply_to_redis(self, key, data_to_send):
        self.redis.lpush(key, data_to_send)
        self.redis.expire(key, 10)

    def notify_nbi(self, data_to_send):
        """sends data to the NB server"""
        try:
            nbi_conn = urllib2.build_opener()
            params = urllib.urlencode(data_to_send)
            request = urllib2.Request(url=self.acs_url, data=params)
            response = nbi_conn.open(request)
        except Exception as nbi_e:
            self.logger.warning('Problem connecting to the nbi server')
            self.logger.debug(nbi_e)
            return
        self.logger.debug("NB response: %s %s" %\
                (response.getcode(), response.msg))
        #TODO check server's response
        gevent.spawn(self.cmd_sender, response.read())

    def disconnect_me(self, cpeid):
        device = self.device_pool.get(cpeid)
        if not device is None:
            device.socket.close()
            self.device_pool.pop(cpeid)

    def socket_receive(self, socket, address, new_connection=False,
            cpeid=None):
        """callback for whenever something is received"""
        msg = ''
        try:
            msg = socket.recv(4096)
        except gevent_socket.timeout:
            self.logger.debug("Client timedout %s:%s" % address)
            data_to_send = {'cpeid': cpeid, 'node': self.node_name,
                    'event': 'DISCONNECT'}
            self.notify_nbi(data_to_send)
            return 0
        except gevent.socket.error as e:
            if e.errno == 104:  # connection reset by peer
                msg = ''
        if msg == '':
            self.logger.debug('Client disconnected %s:%s' % address)
            data_to_send = {'cpeid': cpeid, 'node': self.node_name,
                    'event': 'DISCONNECT'}
            self.notify_nbi(data_to_send)
            return 0
        msg = binascii.hexlify(msg).upper()
        frame_id = msg[0:2]
        cpeid = msg[2:10].upper()
        if new_connection:
            if self.device_pool.get(cpeid, None):
                self.logger.warning('CPE \'%s\' already connected.' % cpeid)
            new_device = SMLDevice(socket, cpeid, address[0], self.logger, self.disconnect_me)
            self.device_pool[cpeid] = new_device
        #length = msg[10:14]
        #message_length = len(msg)
        self.messages_processed += 1
        if frame_id == '10':
            self.logger.debug('Got Key Exchange Message')
        elif frame_id == '20':
            self.logger.debug('Got Data Message from \'%s\'', cpeid)
            self.logger.debug(msg)
            #sig = msg[14:128]
            payload = msg[128:]
            self.parse_sml_payload(cpeid, frame_id, payload)
        elif frame_id == '21':
            self.logger.debug('Got Push Message from \'%s\'', cpeid)
            #sig = msg[14:128]
            payload = msg[128:]
            self.parse_sml_payload(cpeid, frame_id, payload)
        elif frame_id == '22':
            self.logger.debug('Got Logon Message from \'%s\'', cpeid)
            payload = msg[128:]
            self.parse_sml_payload(cpeid, frame_id, payload)
        return cpeid

    def handle_sml_message(self, socket, address):
        """method used by Stream Server for new connections"""
        self.logger.debug('New connection from %s:%s' % address)
        socket.settimeout(self.socket_timeout)
        keep_receiving = True
        try:
            cpeid = self.socket_receive(socket, address, new_connection=True)
        except Exception as e:
            self.logger.exception("cpe %s sent something that I cannot understand. (yet..)", cpeid)
            keep_receiving = False
        while keep_receiving:
            try:
                if not self.socket_receive(socket, address,
                        new_connection=False, cpeid=cpeid):
                    break
            except Exception as e:
                self.logger.exception("cpe %s sent something that I cannot understand. (yet..)", cpeid)
                break
        try:
            #self.device_pool.pop(cpeid)
            socket.close()
        except KeyError:
            if cpeid != 0:
                self.logger.debug(cpeid + ' not in socket pool')

    def cmd_sender(self, data):
        """sends commands based on data coming from redis"""
        #TODO validate the data
        if data == '':
            return
        try:
            job = simplejson.loads(data)
        except Exception:
            self.logger.warning('Not a valid JSON string: %s' % data)
            return
        method = job['method']
        arguments = job['args']
        cpeid = job['cpeid']
        device = self.device_pool.get(cpeid, None)
        if device:
            if method == 'cnr':
                ack_channel = job['ack_channel']
                self.redis.publish(ack_channel, '{"cpeid": "%s"}' % cpeid)
                data_to_send = {'cpeid': cpeid, 'node': self.node_name,
                        'event': '6 CONNECTION REQUEST'}
                self.notify_nbi(data_to_send)
            else:
                step = job['step']
                inline = job.get('inline')
                if device.is_fake:
                    data_to_send = {'cpeid': cpeid,
                        'node': self.node_name,
                        'response': job.get('fake_response', ''),
                        'step': step,
                        'event': self.eventcode_prefix + 'data'}
                    self.notify_nbi(data_to_send)
                else:
                    device.add_job(method, arguments, step, inline)
        else:
            if method == 'add_fake':
                data_to_send = {'cpeid': cpeid, 'node': self.node_name,
                        'response': '', 'step': '', 'event': '1 BOOT'}
                self.notify_nbi(data_to_send)
                if self.device_pool.get(cpeid, None):
                    msg = 'Fake CPE \'%s\' already added.' % cpeid
                    self.logger.warning(msg)
                    return
                fake_device = SMLDevice(None, cpeid, self.logger)
                self.device_pool[cpeid] = fake_device
            else:
                data_to_send = {'cpeid': cpeid, 'node': self.node_name,
                    'event': 'DISCONNECT'}
                self.notify_nbi(data_to_send)
                self.logger.debug(cpeid + ' not in pool')

    def redis_listener(self):
        """a greenlet runs this redis_listener"""
        number_spawned = 0
        while 1:
            try:
                self.jobs_queue = self.redis.pubsub()
                self.jobs_queue.subscribe('jobs')
                for msg in self.jobs_queue.listen():
                    self.logger.debug("From Redis: " + str(msg['data']))
                    if number_spawned % 100 == 0:
                        gevent.sleep(0)
                    gevent.spawn(self.cmd_sender, msg['data'])
                    number_spawned += 1
            except redis.ConnectionError:
                gevent.sleep(0.1)


class SMLRunner(AxDaemon):
    """the wrapper class. Implements AxDaemon"""
    def run(self):
        if not self.config_ok:
            msg = 'SML server not configured correctly. Exiting...'
            self.logger.debug(msg)
            return
        msg = 'SML server is starting up with the following config'
        self.logger.debug(msg)
        self.logger.debug('ACS URL: %s' % self.acs_url)
        self.logger.debug('Socket timeout: %d' % self.socket_timeout)
        self.logger.debug('SML Port: %d' % self.sml_port)
        self.logger.debug('Redis Host: %s' % self.redis_host)
        self.logger.debug('Node Name: %s' % self.node_name)
        device_pool = {}
        try:
            sml_queue = EventToAxtract()
            self.logger.debug('Forward to Axtract is ON')
        except NameError:
            sml_queue = None
            self.logger.debug('Forward to Axtract is OFF')
        sml = SMLServer(device_pool, sml_queue, self.socket_timeout,
                self.acs_url, self.redis_host, self.node_name, self.logger)
        redis_greenlet = gevent.spawn(sml.redis_listener)

        self.sml_server = StreamServer(('0.0.0.0', self.sml_port),
                sml.handle_sml_message)
        self.logger.debug('Listening on 0.0.0.0:%d...' % self.sml_port)
        self.sml_server.serve_forever()
        """
        redis_greenlet.kill()
        redis_greenlet.join()
        """

    def handle_termination_signal(self, unused1, unused2):
        super(SMLRunner, self).handle_termination_signal(unused1, unused2)
        self.sml_server.stop()
        self.logger.debug('Stopping SML Server...')

    def setup_logging(self):
        self.daemon_name = "SML Runner"
        super(SMLRunner, self).setup_logging()

    def define_command_line(self):
        super(SMLRunner, self).define_command_line()
        parser = self.option_parser
        parser.add_option("-a", "--acs-url", dest="acs_url",
                  help="ACS URL", default=None)
        parser.add_option("-t", "--socket-timeout", dest="socket_timeout",
                  help="SML socket timeout in seconds", default=None)
        parser.add_option("-P", "--smp-port", dest="sml_port",
                  help="Listening port", default=None)
        parser.add_option("-r", "--redis-host", dest="redis_host",
                  help="Redis Host", default=None)
        parser.add_option("-n", "--node-name", dest="node_name",
                  help="Node Name", default=None)

    def load_configuration(self):
        self.config_ok = False

        env = os.environ
        opts = self.options
        self.acs_url = opts.acs_url if opts.acs_url\
                else env.get('SML_ACS_URL', None)
        self.socket_timeout = opts.socket_timeout if opts.socket_timeout\
                else env.get('SML_SOCKET_TIMEOUT', None)
        self.sml_port = opts.sml_port if opts.sml_port\
                else env.get('SML_PORT', None)
        self.redis_host = opts.redis_host if opts.redis_host\
                else env.get('SML_REDIS_HOST', None)
        self.node_name = opts.node_name if opts.node_name\
                else env.get('SML_NODE_NAME', None)
        if not self.acs_url or not self.socket_timeout or not self.sml_port or\
                not self.redis_host or not self.node_name:
            try:
                config_file = open(self.options.config_file, 'r')
                config = config_file.readlines()
            except Exception as config_e:
                msg = 'Problem opening config file \'%s\': %s' % \
                        (self.options.config_file, config_e.args[0])
                msg = (logging.ERROR, msg)
                self._log_when_ready.append(msg)
                return
            config_file.close()

            try:
                for line in config:
                    line = line.replace(' ', '')
                    if line.startswith('SML_ACS_URL'):
                        if not self.acs_url:
                            self.acs_url = line.split('=')[1][:-1]
                    elif line.startswith('SML_SOCKET_TIMEOUT'):
                        if not self.socket_timeout:
                            self.socket_timeout = line.split('=')[1][:-1]
                    elif line.startswith('SML_PORT'):
                        if not self.sml_port:
                            self.sml_port = line.split('=')[1][:-1]
                    elif line.startswith('SML_REDIS_HOST'):
                        if not self.redis_host:
                            self.redis_host = line.split('=')[1][:-1]
                    elif line.startswith('SML_NODE_NAME'):
                        if not self.node_name:
                            self.node_name = line.split('=')[1][:-1]
            except Exception:
                msg = 'Config file %s not properly formated' %\
                        self.options.config_file
                msg = (logging.ERROR, msg)
                self._log_when_ready.append(msg)
                return
            try:
                self.socket_timeout = int(self.socket_timeout)
            except ValueError:
                msg = 'Invalid value %s for parameter socket_timeout' %\
                        self.socket_timeout
                msg = (logging.ERROR, msg)
                self._log_when_ready.append(msg)
                return
            except TypeError:
                msg = (logging.ERROR, 'Socket timeout is not configured')
                self._log_when_ready.append(msg)
                return
            try:
                self.sml_port = int(self.sml_port)
            except ValueError:
                msg = 'Invalid value %s for parameter sml_port' %\
                        self.sml_port
                msg = (logging.ERROR, msg)
                self._log_when_ready.append(msg)
                return
            except TypeError:
                msg = (logging.ERROR, 'SML port is not configured')
                self._log_when_ready.append(msg)
                return
        if self.acs_url and self.socket_timeout and self.sml_port and\
                self.redis_host and self.node_name:
            self.config_ok = True


if __name__ == '__main__':
    me = SMLRunner()
    me.setup()
    me.run()
    me.cleanup()
