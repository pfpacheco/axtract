"""Provides access to arbitrary commands, e.g. ssh, ftp, telnet, mysql...
    This module requires "pexpect", a python interface to "expect".
"""

try:
    import pexpect
except ImportError:
    raise ImportError("You need to 'apt-get install python-pexpect'")


from ax.transport.base import ConnectionClosedException, \
        TimeoutException
from ax.transport.telnetter import Telnetter

class PexpectTelnetter(Telnetter):
    """Provides access to arbitrary commands, e.g. ssh, ftp, telnet, mysql...
        The "pexcept" library helps to deal with naughty programs like ssh
        that insist on asking for the password on the tty instead of ye good
        olde stdin. The programs are a real pain in the arse with the
        PopenTelnetter.

    Examples:
    --------
        Mysql:
    cmd = 'mysql -h 127.0.0.1 -u ax -p'
    a4  = axpand.get_transport_object('3ne23w234', 'pexpect',
            {'condition': 'sql>', 'command': cmd, 'allowed_cmds': None})
    a4.get('/WAIT', 'assword:')
    a4.get('ax')
    print (a4.get('show databases;'))

        IOS:
    cmd = 'ssh test@10.11.0.10'
    a4  = axpand.get_transport_object('3ne23w234', 'pexpect',
            {'prolog': '/F:LIB:cisco_direct_password',
                'newline': '\n', 'condition': '#/Z', 'command': cmd,
                })
    a4.get('show version')
    a4.close()


        IOS via port 23: USE NETCAT - telnet inserts terminal control cmds!
            cmd = 'netcat 10.11.0.10 23'
            a4  = axpand.get_transport_object('3ne23w234', 'pexpect',
                    {'newline': '\n', 'condition': '>/Z',
                     'command': cmd})

            a4.get('/WAIT', 'name:')
            a4.get('test', 'assword:')
            a4.get('test')
            a4.get('term len 0')
            a4.get('show version')


    """
    identification = 'pexp://%(command)s'

    # The command to run, e.g. "ssh root@192.168.0.1"
    # Note that pexpect.spawn() will not do any regexp mathing, output
    # redirection or other fancy shell stuff with your command. If you
    # want that, your command should be "bash -c ...." so the bash
    # can take care of it.
    command = None

    # reasonable default:
    newline = '\n'


    def open_connection(self):
        """
            $timeout is ignored in this implemention
        """
        super(PexpectTelnetter, self).__init__()
        # client takes care for knowing when to call connect:
        if self.command is None:
            raise ValueError("connect() called, but no $command was set")
        # command need often personalized settings (e.g. username differs)
        if '%(' in self.command:
            self.command = self.command % self
        # options needed, otherwise known_host filled up by axpand
        if self.command.startswith('ssh'):
            # if already set in project specific config we do not overwrite
            if not 'UserKnownHostsFile' in self.command:
                self.command += ' -o UserKnownHostsFile=/dev/null'
            if not 'StrictHostKeyChecking' in self.command:
                self.command += ' -o StrictHostKeyChecking=no'
        try:
            conn_obj = pexpect.spawn(self.command)
            # this avoids reading what was sent:
            conn_obj.setecho(False)
        except pexpect.ExceptionPexpect as exc:
            reason = str(exc)
            if "out of pty" in reason:
                raise ConnectionClosedException("Pexpect could not spawn. "
                        "You likely need to mount /dev/pts by doing "
                        "'mount -t devpts devpts /dev/pts'. Original "
                        "exception message: " + str(exc))
            else:
                raise ConnectionClosedException("Pexpect could not spawn. "
                        "Original exception message: " + str(exc))
        return conn_obj


    def close_connection(self, conn_obj = None):
        conn_obj = conn_obj or self.get_connection_obj()
        try:
            conn_obj.terminate()
            conn_obj.terminate(force=True)
            conn_obj.close()
        except Exception as exc:
            raise ConnectionClosedException(
                    "Exception while closing: %s" % exc)
        finally:
            del conn_obj


    def send_data(self, data, conn_obj):
        """Send the given $data to the other side
        """
        conn_obj.send(data)


    def read(self, timeout, maxdata, conn_obj):
        # read_nonblocking() is a bit misleading. It will block, just
        # not forever.
        try:
            new_data = conn_obj.read_nonblocking(
                    timeout=timeout, size=maxdata)
        except pexpect.TIMEOUT as exc:
            raise TimeoutException(str(exc))
        except pexpect.EOF:
            raise ConnectionClosedException("pexpect reported EOF")
        return new_data.replace('\r', '')



    """ For debugging this might be handy
    def communicate(self, cmd, conn_obj, condition, error_condition, timeout, **kwargs):
        if cmd:
            self.send_data(cmd + self.newline, conn_obj)
        return self.receive_until_condition(conn_obj, condition, error_condition, timeout, **kwargs)

    def receive_until_condition(self, conn_obj, condition, error_condition,
            timeout, **kwargs):
        print ("|expecting %s|" % condition)
        conn_obj.expect(condition, timeout=timeout)
        new_data = conn_obj.before + condition
        print ('-|got %s|-' % new_data)
        return new_data

    """
