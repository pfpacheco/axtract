#!/opt/axess/bin/call_with_eggs
"""
Example for Model usage. Defined is a model for cisco.IOS
"""

import logging, sys
# set to DEBUG if needed:
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger()
from ax.utils.formatting.pretty_print import dict_to_txt

from ax.transport import axpand
from ax.utils.tr069 import TR69Utils
from pprint import pformat
# read in all xml definition files:
TR69Utils.parse_global_properties('/etc/axess/TR69/', ('TR69.xml', 'axiros.xml', 'telecomitalia.xml'))

# root object:
R = 'InternetGatewayDevice'
model = 'cisco.IOS_DEV2'
if 'write' in str(sys.argv):
    testmode ='write: $mpath/%(host)s!'
elif 'run' in str(sys.argv):
    testmode ='run: $mpath/%(host)s!'
else:
    testmode = ''
#model = "greg"
#IP = 'aida.axiros.com'
if sys.argv[1] == '1':
    t = axpand.get_transport_object(
 'cisco.C1861', settings={
                        'via': 'ssh',
                        'user': 'service',
                        'password': 'service',
                        'enable_pass': 'pUnt0l@n',
                        'newline': '\\n',
                        'condition': '#/Z',
                        'testmode': testmode,
                        'host': '94.93.54.170',
                        'port': 22,
                        'invoke_shell': 1,
                        'allowed_cmds': None,
                        'prolog': "/F:LIB:cisco_ssh",
                        'model': model
                       })

if sys.argv[1] == '2':
 t = axpand.get_transport_object(
 'cisco.C1861', settings={'via': 'telnet',
                        'user': 'test',
                        'password': 'test',
                        'enable_pass': 'cisco',
                        'testmode': testmode,
                        'condition': '#/Z',
                        'host': 'aida.axiros.com',
                        'port': 11112,
                        'allowed_cmds': None,
                        'prolog': "/F:LIB:cisco_telnet_user_pw",
                        'model': model,
                       })
if sys.argv[1] == '3':
    t = axpand.get_transport_object(
 'cisco.C1861', settings={'via': 'telnet',
                        'user': 'service',
                        'password': 'service',
                        'enable_pass': '@mprs643',
                        'testmode': testmode,
                        'condition': '#/Z',
                        'host': '87.30.154.136',
                        'port': 23,
                        'allowed_cmds': None,
                        'prolog': "/F:LIB:cisco_telnet_user_pw",
                        'model': model
                       })

if sys.argv[1] == '4':
    t = axpand.get_transport_object(
 'cisco.C1861', settings={'via': 'telnet',
                        'user': 'service',
                        'password': 'service',
                        'enable_pass': '@mprs643',
                        'testmode': testmode,
                        'condition': '#/Z',
                        'host': '94.93.50.30',
                        'port': 23,
                        'allowed_cmds': None,
                        'prolog': "/F:LIB:cisco_telnet_user_pw",
                        'model': model
                       })
if sys.argv[1] == '5':
    t = axpand.get_transport_object(
 'cisco.C1861', settings={'via': 'telnet',
                        'user': 'service',
                        'password': 'service',
                        'enable_pass': 'pUnt0l@n',
                        'testmode': testmode,
                        'condition': '#/Z',
                        'host': '88.53.223.82',
                        'port': 23,
                        'allowed_cmds': None,
                        'prolog': "/F:LIB:cisco_telnet_user_pw",
                        'model': model
                       })

if sys.argv[1] == '6':
    t = axpand.get_transport_object(
 'cisco.C1861', settings={'via': 'telnet',
                        'user': 'service',
                        'password': 'service',
                        'enable_pass': '@mprs643',
                        'condition': '#/Z',
                        'host': '94.93.50.30',
                        'testmode': testmode,
                        'port': 23,
                        'allowed_cmds': None,
                        'prolog': "/F:LIB:cisco_telnet_user_pw",
                        'model': model
                       })

if sys.argv[1] == '7':
    t = axpand.get_transport_object(
 'cisco.C1861', settings={'via': 'telnet',
                        'user': 'service',
                        'password': 'service',
                        'enable_pass': '@mprs643',
                        'testmode': testmode,
                        'condition': '#/Z',
                        'host': '95.227.121.155',
                        'port': 23,
                        'allowed_cmds': None,
                        'prolog': "/F:LIB:cisco_telnet_user_pw",
                        'model': model
                       })

if sys.argv[1] == '8':
    t = axpand.get_transport_object(
 'cisco.C1861', settings={'via': 'telnet',
                        'user': 'service',
                        'password': 'service',
                        'enable_pass': '@mprs643',
                        'testmode': testmode,
                        'condition': '#/Z',
                        'host': '88.46.166.150',
                        'cid': '004113045808',
                        'port': 23,
                        'allowed_cmds': None,
                        'prolog': "/F:LIB:cisco_telnet_user_pw",
                        'model': model
                       })



# direct commands still work:
try:
    res = t.model.GetParameterValues(('.',), t)
    #res = t.model.build_stack(t)
    import ipdb; ipdb.set_trace()
    #res = t.model.build_dev2_ifs(t)
except:
    logger.exception('exc')
finally:
    t.close()
    if 'write' in testmode:
        t.write_testmap()
i = 9/0
c = t.session_cache

res = t.model.GetParameterValues(('.Time.',), t)
c = t.session_cache

print dict_to_txt(res, fmt={'ax': 1})


sys.exit(0)
res = t.model.GetParameterValues(('InternetGatewayDevice..', 'InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.IPInterface.1.IPInterfaceIPAddress'), t)
print '\n' * 10
print pformat(res)
t.close()

print pformat(res)
sys.exit(0)
res = t.model.GetParameterValues(
('InternetGatewayDevice.DeviceInfo.',
'InternetGatewayDevice.DeviceInfo.SerialNumber',
'InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.IPInterface.1.IPInterfaceIPAddress',
'InternetGatewayDevice.Time.'),
t)
print pformat(res)
t.close()
sys.exit(0)
res = t.model.GetParameterValues('InternetGatewayDevice.', t)
res = t.model.GetParameterValues('InternetGatewayDevice.X_AXIROS_COM.', t)
res = t.model.GetParameterValues('InternetGatewayDevice.LANDevice.', t)
res = t.model.GetParameterValues('InternetGatewayDevice.Time.')
sc = t.session_cache

print '###########################################################'
print '############# RESULT GPV InternetGatewayDevice. ###########'
print '###########################################################'
print pformat(res)
print '################################'
"""import pdb; pdb.set_trace()
"""

res = t.model.GetParameterValues('InternetGatewayDevice.DeviceInfo.', t)
print '###########################################################'
print '############# RESULT GPV DeviceInfo. ###########'
print '###########################################################'
print pformat(res)
print '################################'
"""import pdb; pdb.set_trace()
"""


print '***'
print '***'
print '***'
print '***'
print '**********************************************'
res = t.model.GetParameterValues('InternetGatewayDevice.Time.Status', t)
print pformat(res)
print '**********************************************'
import pdb; pdb.set_trace()


res = t.model.GetParameterValues('.DeviceConfig.PersistentData', t)
print pformat(res)
res = t.model.GetParameterNames({'NextLevel': False,
            'ParameterPath': 'InternetGatewayDevice.'}, t)
print pformat(res)

res = t.model.GetParameterValues('.', t)
print pformat(res)

    #res = t.model.Upload({'URL': 'tftp://10.11.0.1/foasdfo/basdfar',
#                  'FileType': '1 Vendor Configuration File'}, t)

# that takes ages:
print "skipping reboot"
#res = t.model.Reboot('asdf', t)



res = t.model.SetParameterValues({
'Device.LANDevice.1.LANEthernetInterfaceConfig.2.Enable':\
        '1',
'Device.LANDevice.1.LANHostConfigManagement.IPInterface.2.IPInterfaceIPAddress':\
        '2.11.0.11',
'Device.LANDevice.1.LANHostConfigManagement.IPInterface.2.IPInterfaceSubnetMask':\
        '255.255.255.0'
                                },
                               t)
t.close()


res = t.model.GetParameterValues('.LANDevice.', t)
print pformat(res)

try:
    for k in [
            '.DeviceInfo.',
            '.DeviceInfo.SoftwareVersion',
            '.DeviceInfo.DeviceLog',
            '.'
            ]:
        print "=" * 80
        print "Getting %s" % k
        res = t.model.GetParameterValues(R+ k, t)
        print pformat(res)

finally:
    t.close()

