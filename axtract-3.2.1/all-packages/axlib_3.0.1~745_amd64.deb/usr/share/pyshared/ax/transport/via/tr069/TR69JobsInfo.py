from time import time,ctime

ThreadsInfo = {}
JobsStateInfo = {}
JobsInfo = {}
JobId = 0;


def getNextJobId():
    global JobId
    JobId += 1
    return JobId


def dropInfo():
    global ThreadsInfo,JobsStateInfo,JobsInfo,JobId
    ThreadsInfo = {}
    JobsStateInfo = {}
    JobsInfo = {
        'JobsNumber':0,
        'ActiveJobsNumber':0,
        'MaxActiveJobsNumber':0,
        'TerminatedJobsNumber':0,
        'CompleteJobsNumber':0,
        'JobsSumTime':0,
        'JobsAvgTime':0,
        'StartTime':None,
        'EndTime':None,
        'ExecutingTime':None,
        'Speed':0,

        'SpecExecutingTime':None,
        'SpecEndTime':None,
        'SpecSpeed':0,
    }

    JobId = 0;

dropInfo()

def printJobsInfo():
    fmt = '%-20s:%+30s'
    for key in JobsInfo.keys():
        if key in ('StartTime','EndTime','SpecEndTime'):
            if JobsInfo[key]:
                value = ctime(JobsInfo[key])
            else:
                value = ''
            print (fmt%(key,value))
        else:
            print (fmt%(key,JobsInfo[key]))


def setMaxActiveJobs():
    if JobsInfo['ActiveJobsNumber'] > JobsInfo['MaxActiveJobsNumber']:
        JobsInfo['MaxActiveJobsNumber'] = JobsInfo['ActiveJobsNumber']
        
def setJobsEndAttrs():
    try:
        JobsInfo['JobsAvgTime'] = JobsInfo['JobsSumTime'] / (JobsInfo['CompleteJobsNumber'] + JobsInfo['TerminatedJobsNumber'])
    except:
        pass
    try:
        JobsInfo['ExecutingTime'] = JobsInfo['EndTime'] - JobsInfo['StartTime']
    except:
        try:
            JobsInfo['ExecutingTime'] = time() - JobsInfo['StartTime']
        except:
            pass

    try:
        JobsInfo['SpecExecutingTime'] = JobsInfo['SpecEndTime'] - JobsInfo['StartTime']
    except:
        try:
            JobsInfo['SpecExecutingTime'] = time() - JobsInfo['StartTime']
        except:
            pass

    try:
        JobsInfo['Speed'] = JobsInfo['CompleteJobsNumber'] / JobsInfo['ExecutingTime']
    except:
        pass

    try:
        JobsInfo['SpecSpeed'] = JobsInfo['CompleteJobsNumber'] / JobsInfo['SpecExecutingTime']
    except:
        pass
            
