import sys; PY2 = sys.version_info[0] < 3
if PY2:
    is_str = lambda s: isinstance(s, basestring)
    tostr    = lambda s: str(s)
else:
    is_str = lambda s: isinstance(s, str)
    tostr    = lambda s: s if is_str(s) else str(s, encoding='utf-8')

from ax.transport.base import TransportException, load_uri_with_env

# static class models, with import they register by model type here:
import logging
import os
from ax.transport.flow_handling import run_flow
from ax.transport.model.keyval import handle_GPV, handle_GPN, handle_SPV
from inspect import getargspec, getsourcefile
logger = logging.getLogger(__name__)


####################################################################
#
# This is a thing wrapper for MODELs - translating native to
# a paramter model. Since currently its mainly about TR-069 models
# we define also related constants and access methods.
#
####################################################################

class AXPModelFlowException(Exception):
    pass


# We instanticate models only ONCE.
# will pick the instance per CWMP session start.
# they register at process start here:
MODELS = {}

I  = 'InternetGatewayDevice'
D  = 'Device'
DI = '.DeviceInfo.'
MS = '.ManagementServer.'


AX_DI = {DI + 'Manufacturer'   : 'Axiros GmbH',
         DI + 'ManufacturerOUI': '0C5521',
         DI + 'ProductClass'   : 'AXPAND',
         DI + 'SerialNumber'   : 'AXPAND',
         '.DeviceSummary'      : ''}


ROOT = {'I': I, 'D': 'Device'}

def out(*msg):
    try:
        if 'startfg' in os.environ['RUNCMD']:
            msg = ' '.join([tostr(i) for i in msg])
            print(msg)
    except:
        pass



def get_model(model):
    try:
        return MODELS[model]
    except:
        raise Exception("model %s not in %s" % (list(model. MODELS.keys())))




def model_call(t, cmd, timeout, condition, error_condition, **kwargs):
    """ from t.get('model.mymodelmethod') - called in base.py via the
    """
    if not t.model:
        raise TransportException("no model defined")
    meth = cmd[6:]
    func = getattr(t.model, cmd[6:])
    if not func:
        raise TransportException("Function %s not found in %s" \
                % (cmd, getattr(t, 'model')))

    # we try co fill args:
    kwargs['timeout']         = float(kwargs.get('timeout', timeout))
    kwargs['condition']       = kwargs.get('condition',
                                condition)
    kwargs['error_condition'] = kwargs.get('error_condition',
                                error_condition)
    spec = getargspec(func)
    args, kw, defs = spec[0], spec[2], spec[3]
    if 't' in args:
        kwargs['t'] = t
    defpos = 0
    if not kw:
        m = {}
        for a in args:
            if a == 'self':
                continue
            if not a in kwargs:
                if defs and len(defs) > defpos:
                    m[a] = defs[defpos]
                    defpos += 1
                    continue
                raise TransportException("argument %s for model method %s not supplied" % \
                        (a, meth))
            m[a] = kwargs[a]
        return func(**m)
    return func(**kwargs)



def load_model(t, tried_create=0):
    """ we loaded all at process start """
    if is_str(t.model):
        model = MODELS.get(t.model)
        if model:
            t.model = model

            # initting of session cache vars, var container objects and the like:
            prepare = getattr(t.model, 'prepare', None)
            if prepare:
                prepare(t)

            return

    if isinstance(t.model, Model):
        return
    last_error = ''

    if not tried_create:
        # not yet in the cache, try get one:

        # download url for it present?
        if t.model_code_uri and not tried_create:
            logger.info('trying download of model at %s' % t.model_code_uri)
            load_uri_with_env(t.model_code_uri, t, MODELS)
            return load_model(t, tried_create=1)

    raise TransportException("Model %s not found or downloadable %s" % \
                             (t.model, last_error))



class UnsupportedRPCException(Exception):
    pass

class Model(object):
    # MUST be overwritten:
    # will be apppended/stripped to/from dotted mode:
    root="xxx"
    # the target parameter domain. Like IGD or D but... anything
    model="xxx"
    # for the explorer to find a model by via and t_type:
    matching="xxx"
    # to trac version changes and tests
    rev=1.0
    # can be extended by specific models, by rpcs_custom list.
    # we check wich one is implemented really in check_model_rpc_suport:
    rpcs = ['GetRPCMethods',
            'GetParameterValues',
            'SetParameterValues',
            'AddObject',
            'DeleteObject',
            'GetParameterNames',
            'GetParameterAttributes',
            'SetParameterAttributes',
            'FactoryReset',
            'Reboot',
            'Download',
            'Upload',
            'X_AXIROS_COM_RunCmdFlow']
    rpcs_custom = []

    def get_simple_callables(self):
        return self.get_all_callables(simple=1)

    def get_all_callables(self, simple=None):
        """ nice to have for some tools like cwmp gui client"""
        res = []
        for meth in dir(self):
            try:
                args = getargspec(getattr(self, meth))
            except:
                continue
            if args[0] == ['self', 't'] or not simple:
                res.append(meth)
        res.sort()
        return res

    def all_gpvs(self, t):
        """ run all GPV_ methods """
        meths = self.get_simple_callables()
        for m in meths:
            if m.startswith('GPV_'):
                getattr(self, m)(t)



    def trp(self, t, match=''):
        """ quick debug method to show tr - parameters """
        ret = {}
        for k, v in list(t.session_cache.items()):
            if k.startswith('.') and (match in k or match in tostr(v)):
                ret[k] = v
        return ret

    def get_model_path(self):
        return getsourcefile(self.__class__).rsplit('/', 1)[0]

    def tr_root(self):
        return ROOT[self.root]

    def check_model_rpc_support(self, RPC = None):
        """ Deliver the RPCs supported or check existence of specific one"""
        if not RPC:
            # can be overwritten by a specific model:
            ret = []
            for m in self.rpcs + self.rpcs_custom:
                if hasattr(self, m):
                    ret.append(m)
            return ret
        if not hasattr(self, RPC):
            raise UnsupportedRPCException("No RPC Support for %s" % RPC)

    def get_ms(self, t):
        m = t.session_cache
        user  = m.get('.ManagementServer.Username', 'no user')
        passw = m.get('.ManagementServer.Password', 'no pass')
        acs =   m.get('.ManagementServer.URL')
        return acs, user, passw



    # ---------------- Events
    def clear_events(self, t):
        del self.get_events(t)[:]

    def has_events(self, t):
        return len(self.get_events(t))

    def get_events(self, t):
        return t.session_cache.get('events', [])




    # ---------------- Strip / Attach the root object:
    def rootify(self, params):
        if is_str(params):
            if params.startswith('.'):
                return self.tr_root() + params
            return params

        res = {}
        root = self.tr_root()
        for k, v in list(params.items()):
            res[root + k] = v
        return res


    def dotify(self, obj):
        """ I.Foo.Bar -> .Foo.Bar for all keys in list """
        if is_str(obj):
            if not obj.startswith('.'):
                return self.dotify((obj,))[0]
            return obj
        if isinstance(obj, dict):
            res = {}
            for k, v in list(obj.items()):
                res['.' + k.split('.', 1)[1]] = v
            return res

        res = []
        for i in range(len(obj)):
            res += ('.' + obj[i].split('.', 1)[1],)
        return res


    # ---------------- Basic RPCs:
    def X_AXIROS_COM_RunCmdFlow(self, cmd, t):
        from simplejson import loads
        cmd = loads(cmd)
        res = run_flow(t, cmd)
        return res

    def GetParameterNames(self, params, next_level, t):
        """ always there """
        dotted_p = self.dotify(params)
        return handle_GPN(dotted_p, next_level, t)


    def GetParameterValues(self, params, t):
        """ always there """
        if is_str(params):
            params = (params,)
        dotted_p = self.dotify(params)
        res = handle_GPV(dotted_p, t)

        # GPV can write automatically a test map:
        if hasattr(t, 'testmode') and 'write' in t.testmode:
            t.testmap['job'] = 'GetParameterValues'
            t.testmap['jobArgs'] = params
            t.testmap['jobResult'] = res
            # future models will deliver more params:
            # so accept more and not fail the tests in the future:
            t.testmap['Checkmode'] = 'subset'
            # t has t.testfile. there the map resides and can be used for
            # unittesting the model:
            t.write_testmap()
        # now insert back forced params
        c = t.session_cache
        ep = c.get('ext_params', ())
        for k in ep:
            if not k in c:
                continue
            val = ep[k]
            if not is_str(val):
                    continue
            if not val.startswith('/F:'):
                continue
            # the user *REALLY* insists on this value:
            if 'SERIAL' in val:
                val = val.replace('SERIAL', c[DI + 'SerialNumber'])
            val = val[3:].strip()
            if val.startswith('int:'):
                val = int(val[4:].strip())
            if val.startswith('float:'):
                val = float(val[6:].strip())
            # push it in:
            c[k] = val
        return res

    def SetParameterValues(self, params, t):
        handle_SPV(params, t)


    def GPV_ManagementServer(self, t):
        # must be in the session cache
        c = t.session_cache
        c['.ManagementServer.EnableCWMP'] = True

    def GetRPCMethods(self, t):
        return t.model.check_model_rpc_support()


    def get_device_id(self, t):
        m = t.session_cache
        dev_id = {
            'Manufacturer': m.get(DI + 'Manufacturer'),
            'OUI'         : m.get(DI + 'ManufacturerOUI'),
            'ProductClass': m.get(DI + 'ProductClass'),
            'SerialNumber': m.get(DI + 'SerialNumber')}
        return dev_id


    @staticmethod
    def make_inform(*args, **kwargs):
        """
        if the model has a def Inform - run it
        else run GPV on .DI. and tell the model that we
        are in an Inform so that it can adapt to it - like
        not returning the .DI.DL

        """

        # set by /RUN in control stmt parser, we can work with kwargs:
        t = kwargs.get('transport')

        if not t or not hasattr(t, 'communicate'):
            raise Exception("No transport object was set")

        # so that we can work, even with empty models:
        t.session_cache.update(AX_DI)

        ep = t.session_cache.get('ext_params')
        if ep:
            # dotify in case someone pushed IGD or Dev2:
            if not list(ep.keys())[0].startswith('.'):
                t.session_cache['ext_params'] = t.model.dotify(ep)
                ep = t.session_cache.get('ext_params')
            # externals overwrite the AX_DI - but can be overwrittn by the
            # transports'
            t.session_cache.update(ep)

        # def Inform defined?
        im = getattr(t.model, 'Inform', None)
        t.session_cache['in_inform'] = 1
        t.session_cache['GPV_show_native_output'] = \
             getattr(t, 'GPV_show_native_output', None)
        # inform method:
        if im:
            do_ret = im(t = t)
        else:
            do_ret = t.model.GetParameterValues(
                    ['.DeviceInfo.', '.ManagementServer.'],
                    t=t,
                    )
        return do_ret


def add_model(*args):
    if not args:
        return
    if not isinstance(args[0], (list, tuple)):
        args = (args, )
    for name, obj in args:
        MODELS[name] = obj

class defer:
    """ just to load deferred, avoiding circ. refs """
    def imp(self, attr):
        exec (attr)


def scan_dir(mf):
    where = mf.split('/transport/model/')[1].replace('/', '.')
    if not path.isdir(mf) or mf.endswith('tests') or '.svn' in mf:
        return
    for f in listdir(mf):
        if path.isdir(path.join(mf, f)):
            scan_dir(path.join(mf, f))

        # the model importer tries to import all models at startup
        if not f.endswith('.py') or '__init__' in f:
            continue
        mod = f.split('.py')[0]
        try:
            imp = "import ax.transport.model.%s.%s" % \
                    (where, mod)
            defer.imp(imp)
            #out('Model %s' % imp)
        except Exception:
            # stupid test, just to know if we should complain:
            with open(path.join(mf, f), 'r') as mod:
                    cont = mod.read()
            if not 'add_model' in cont:
                continue
            logger.exception("Can't import model %s/%s" % (mf, f))

if not MODELS:
    """ we now scan through all first level subfolders here and import models -
    they register themselves and maybe other models in subfolders """
    defer = defer()
    # ---------------- importing all model classes in the beginning!
    from ax.utils import package_home
    p = package_home(globals())
    from os import listdir, path, environ

    for f in listdir(p):
        # model folder:
        mf = path.join(p, f)
        scan_dir(mf)

    env_dir = environ.get('conf_dir', 0)
    if env_dir:
        env_dir += '/model'
        if path.exists(env_dir):
            import sys
            sys.path.append(env_dir)
            for model in listdir(env_dir):
                if model.endswith('.py') and not '__init__' in model:
                    try:
                        __import__(model.split('.py')[0])
                    except Exception as ex:
                        out('error importing %s %s' % (env_dir, model))
                        raise




    l = list(MODELS.keys())
    l.sort()
    out('Loaded AXPAND models:')
    for m in l:
        out('\t%s' % m)


