import sys
from ax.transport.model.model_support import add_model
from ax.transport.model.model_support import Model
from ax.transport.model.cisco.IOS_DEV2 import DI
from ax.transport.model.keyval import depends
from ax.transport.model.cisco.ios_parsing import IOSParser
from ax.utils.parsing.parse_text import sort, get_line_val, get_line
from ax.transport.base import TransportException

class ParameterException(TransportException):
    err_id = 50001

class UnsupportedService(ParameterException):
    err_id = 50002

class InterfaceNotFound(ParameterException):
    err_id = 50003

class EFPIDNotFound(ParameterException):
    err_id = 50004


def issue(dct, err):
    """ we recored problems here """
    issues = dct.setdefault('issues', [])
    issues.append(err)


class IOS_TW(IOSParser, Model):
    """
    The TW Electronics Model.
    Getters (get_cfg):
        Can be called supplying:
            1) nothing -> Get all services (currently only one for the POC)
            2) <SVC> -> Get all svc related parameters on all interfaces
            3) <SVC>, <ME-INTERFACE> -> Get all instances for one iface
            4) <SVC>, <ME-INTERFACE>, <EFP-ID> -> Get params for one instance

        Parsing inconsistencies are returned in 'issues' key

    """
    rev=1
    # root model if tr-069 methods are called:
    root = 'D'
    matching = 'cisco.pexpect|ssh|telnet'

# ------------------------------------------------------------------- Helpers

    def modify(self, params, t):
        """ entry point """
        c = t.session_cache
        # we need a few identifieres to find the corresponding blocks:
        # and will report back ALL missing ones, not one by one:
        c['incomplete_params'] = []

        templates = self.find_affected_templates(params)
        for tpl in templates:
            getattr(self, tpl)(params, t)


    def get_attrs(self, prefix):
        """ check what we have """
        ret = []
        for attr in dir(self):
            if attr.startswith(prefix):
                ret.append(attr)
        return ret

# -------------------------------------------------------------------- Getters:

    def get_cfg(self, t, **kw):
        """ Getting the running config with variable constraints """
        svc = kw.get('SVC')
        getters = self.get_attrs('twget_')
        if svc and 'twget_%s' % svc not in dir(self):
            raise UnsupportedService(
                "%s not configured. Known: %s" % (svc, getters))
        ret = {}
        for svc_getter in getters:
            if svc and not svc in svc_getter:
                continue
            ret[svc_getter[6:]] = getattr(self,  svc_getter)(t, **kw)
        return ret


    def twget_ME3600_EIS_IPVPN_Basic_SNLAN_Untagged(self, t, **kwargs):
        """ The POC service """
        c, run, issues = self.init(t)

        ifaces_cfg = self.parse_interface_blocks(t)

        ME_INTERFACE = kwargs.get('ME-INTERFACE')
        if ME_INTERFACE and not ME_INTERFACE in ifaces_cfg:
            raise InterfaceNotFound('%s not present' % ME_INTERFACE)

        EFP_ID = kwargs.get('EFP-ID', 0)

        ret = {'ME-INTERFACE': {}}
        for iface in ifaces_cfg:
            if not 'Ethernet' in iface:
                continue
            if ME_INTERFACE:
                if not ME_INTERFACE == iface:
                    continue
            if_cfg = ifaces_cfg[iface]
            if_m = {}
            ret['ME-INTERFACE'][iface] = if_m
            descr = if_cfg.get('descr', '')
            if not self.parse_descr(descr, if_m, 'CKT-ID'):
                issue(if_m, 'description error (%s)' % descr)
            try:
                bw = int(if_cfg['bw']) / 1000
            except:
                # should be ok to not have set
                bw = 0
            if_m['TOTAL-BANDWIDTH'] = bw
            if_m['SPEED'] = if_cfg.get('speed', '')

            sis_cfg = if_cfg.get('service_instances', {})

            if EFP_ID and not EFP_ID in sis_cfg:
                raise EFPIDNotFound('%s not present' % EFP_ID)
            if not sis_cfg:
                continue
            if_m['EFP-ID'] = {}
            for instance in sis_cfg:
                if EFP_ID and not EFP_ID == instance:
                    continue
                si_cfg = sis_cfg[instance]
                si_m = {}
                if_m['EFP-ID'][instance] = si_m

                descr = si_cfg.get('descr', '')
                if not self.parse_descr(descr, si_m, 'EVC-ID'):
                    issue(si_m, "description error: '%s'" % descr)
                    # Spec: "If no EVC-ID exists use @CKT-ID@ "
                    if not si_m['EVC-ID']:
                        si_m['EVC-ID'] = if_m['CKT-ID']

                i_pol = si_cfg.get('input-policy', '').replace('mb', '')
                if not i_pol:
                    issue(si_m, 'No input policy')
                else:
                    si_m['BE-BANDWIDTH'] = i_pol
                    if not self.add_policy_map(ret, i_pol, t):
                        issue(si_m, 'Policy not defined')

                vlan = si_cfg['bridge-domain']
                if not vlan:
                    issue(si_m, 'No bridge-domain')
                else:
                    si_m['S-VLAN'] = vlan
                    if not self.add_vlan(ret, vlan, t):
                        issue(si_m, 'Vlan not defined')
                    elif not ret['S-VLAN'][vlan]['EVC-ID'] == si_m['EVC-ID']:
                        issue(si_m,
                         'Vlan name mismatch with service instance description')
        if kwargs.get('summary'):
            if_m['EFP-IDs'] = len(if_m.get('EFP-ID', {}))
            if 'EFP-ID' in if_m:
                del if_m['EFP-ID']
        return ret



    def add_policy_map(self, ret, i_pol, t):
        """ put relevant policy map defs into the return map """
        pol_m = ret.setdefault('BE-BANDWIDTH', {})
        pols_cfg = depends('parse_policy_blocks', t)
        # too often the 'mb' suffix was omitted:
        pol_cfg = pols_cfg.get(i_pol + 'mb') or pols_cfg.get(i_pol)
        if not pol_cfg:
            return
        pol_cfg = pol_cfg.get('class-default')
        if not pol_cfg:
            return
        if pol_m.get(i_pol):
            # already added:
            return 1
        pol_m[i_pol] = {}
        bw = int(pol_cfg.get('bw', 0))
        pol_m[i_pol]['BE-BANDWIDTH'] = int(bw / 1000)
        pol_m[i_pol]['BE-BURST']     = int(pol_cfg.get('burst', 0))
        if bw != i_pol:
            issue(pol_m, 'Real bandwidth does not match name of policy-map')
        return 1


    def add_vlan(self, ret, vlan, t):
        """ put relevant vlan defs into the return map """
        vlan_m = ret.setdefault('S-VLAN', {})
        vlans_cfg = depends('parse_vlan_blocks', t)
        # we have ranges in the vlans:
        vlan_cfg, cfg_key = self.get_in_range(vlans_cfg, vlan)
        if vlan_cfg is None:
            return
        if vlan_m.get(vlan):
            return 1
        vlan_m[vlan] = {}
        vlan_m[vlan]['EVC-ID'] = vlan_cfg.get('name', '')
        return 1





    def parse_descr(self, descr, m, id):
        # try(!) to parse the description line. spec:
        # 'description @CKT-ID@ - @CUSTOMER-NAME@ # @AMOF-ID@ # [@COMMENT@]'
        # no regex here, just try to read greedy what's spec compliant and
        # set the rest empty:
        m[id] = ''
        m['CUSTOMER-NAME'] = ''
        m['AMOF-ID'] = ''
        m['COMMENT'] = ''
        d = descr.strip().split(' ', 6)
        if not len(d):
            return
        m[id] = d[0]
        if not len(d) > 2:
            return
        if d[1] == '-':
            m['CUSTOMER-NAME'] = d[2]
            if not len(d) > 4:
                return
            if d[3] == '#':
                m['AMOF-ID'] = d[4]
                if len(d) > 5:
                    cmt = ' '.join(d[5:])
                    if cmt.startswith('[') and cmt.endswith(']'):
                        m['COMMENT'] = cmt[1:-1]
                        return 1




# --------------------------------------------------------------------- Setters

    def VLAN(self, params, t, mode='read'):
        if not 'S_VLAN' in params:
            raise IncompleteParams("Need S_VLAN")
        if mode == 'read':
            # read the running config if not already done so:
            run = depends('show run', t)
            match = 'vlan'
            vlan_block = self.parse_run_block(match, run)



TPL_Interface = """
interface %(ME_INTERFACE)s
   description %(CKT_ID)s - %(CUSTOMER_NAME)s # %(AMOF_ID)s [%(COMMENT)s]
   no cdp enable
   no switchport access vlan 4000
   no service-policy output DEFAULT-OUTPUT
   spanning-tree portfast trunk
   spanning-tree bpdufilter enable
   switchport trunk allowed vlan none
   switchport mode trunk
   mtu 9800
   bandwidth %(TOTAL_BANDWIDTH)s000
   snmp trap link-status
   storm-control broadcast level 5.00
   no shut
"""


TPL_MediaType = """
interface %(ME_INTERFACE)s
  speed %(SPEED)s
  duplex full

"""


TPL_Policy = """
Policy-map %(BE_BANDWIDTH)smb
  class class-default
   police cir %(BE_BANDWIDTH)s bc %(BE_BURST)s
   conform-action set-cos-transmit 0
   exceed-action drop
"""


TPL_ServiceInstance = """
interface %(ME_INTERFACE)s
   service instance %(EFP_ID)s ethernet
   description %(EVC_ID)s - %(CUSTOMER_NAME)s # %(AMOF_ID)s [%(COMMENT)s]
   encapsulation untagged
   service-policy input %(BE_BANDWIDTH)smb
   service-policy output DEFAULT-OUTPUT
   bridge-domain %(S_VLAN)s
   no shut
"""


TPL_VLAN = """
vlan %(S_VLAN)s
  name %(EVC_ID)s
"""


add_model(('cisco.IOS_TW_%s' % IOS_TW.rev, IOS_TW()))

