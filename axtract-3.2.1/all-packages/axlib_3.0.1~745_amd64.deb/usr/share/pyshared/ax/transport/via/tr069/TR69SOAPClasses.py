"""

TR69SOAPClasses.py is part of the commercial products WPS and Ax.

This file is copyrighted (C) 2002 - 2006 by Axiros GmbH.
Under no circumstance any distribution, derived work, analysis
and/or decompilation of this module is allowed.

Usage is restricted to parties legally owning a license
for the whole product. German copyright laws apply!

For details please read the license.

"""
__author__ = "Axiros GmbH, Germany"
__date__ = "$Date: 2006-09-01 14:40:12 +0200 (Fri, 01 Sep 2006) $"
__version__ = "$Revision: 24 $"[11:-2]


from ax.utils.lib.SOAPpy_ax import *

class ArgStruct(dict):
    def __init__(self):
        dict.__init__(self)
        self._ax_soap_dic=1



class ParameterInfoStruct(dict):
    def __init__(self):
        dict.__init__(self)
        self._ax_soap_dic=1


class ParameterValueStruct(dict):
    def __init__(self):
        dict.__init__(self)
        self._ax_soap_dic=1

class ParameterAttributeStruct(dict):
    def __init__(self):
        dict.__init__(self)
        self._ax_soap_dic=1


class SetParameterAttributesStruct(dict):
    def __init__(self):
        dict.__init__(self)
        self._ax_soap_dic=1

class EventStruct(dict):
    def __init__(self):
        dict.__init__(self)
        self._ax_soap_dic=1

class FaultStruct(dict):
    def __init__(self):
        dict.__init__(self)
        self._ax_soap_dic=1


def convertToSOAPStruct(methodname, param):
        # Convert responses arguments to valid format
    if methodname =='InformResponse':
        param={'MaxEnvelopes':untypedType(str(param.get('MaxEnvelopes')))}
    if methodname =='GetRPCMethodsResponse':
        param={'MethodList':arrayType(param.get('MethodList'), elemsname='string')}

          # Convert methods arguments to valid format
    if methodname =='SetParameterValues':
        if type(param)==type({}):
            if param.get('Name'):
                param={'ParameterList':[{'Name':param.get('Name'), 'Value': param.get('Value')}],'ParameterKey':param.get('ParameterKey','')}

            newStruct=[]
            for el in param.get('ParameterList',[]):
                PVStruct=ParameterValueStruct()
                #PVStruct.update({'Name':untypedType(el.get('Name')),'Value':untypedType(el.get('Value')) })
            #    PVStruct.update({'Name':untypedType(el.get('Name')),'Value':untypedType(str(el.get('Value'))) })
                PVStruct.update({'Name':untypedType(el.get('Name')),'Value':el.get('Value') })
                newStruct.append(PVStruct)
            param['ParameterList']=newStruct
            param={'ParameterList':arrayType(param.get('ParameterList'), elemsname='ParameterValueStruct'),'ParameterKey':untypedType(param.get('ParameterKey',''))}
        else:
            param={'ParameterList':arrayType(param, elemsname='ParameterValueStruct'), 'ParameterKey':''}


    if methodname =='GetParameterNames':
        param={'ParameterPath':untypedType(param.get('ParameterPath')), 'NextLevel':untypedType(str(param.get('NextLevel','True')))}


    if methodname =='AddObject':
        param={'ObjectName':untypedType(param.get('ObjectName')), 'ParameterKey':untypedType(str(param.get('ParameterKey','')))}
        #    param={'ObjectName':param.get('ObjectName'), 'ParameterKey':str(param.get('ParameterKey',''))}

    if methodname =='DeleteObject':
        param={'ObjectName':untypedType(param.get('ObjectName')), 'ParameterKey':untypedType(str(param.get('ParameterKey','')))}

    if methodname =='Download':
        param={
            'CommandKey':untypedType(param.get('CommandKey')),
            'FileType':untypedType(param.get('FileType','')),
            'URL':untypedType(param.get('URL','')),
            'Username':untypedType(param.get('Username','')),
            'Password':untypedType(param.get('Password','')),
            'FileSize':untypedType(str(param.get('FileSize',''))),
            'TargetFileName':untypedType(param.get('TargetFileName','')),
            'DelaySeconds':untypedType(str(param.get('DelaySeconds','0'))),
            'SuccessURL':untypedType(param.get('SuccessURL')),
            'FailureURL':untypedType(param.get('FailureURL'))
            }

    if methodname =='Reboot':
        param={'CommandKey':untypedType(str(param.get('CommandKey','')))}

    if methodname in ['GetParameterValues','GetParameterAttributes']:
        #self.log(5,'param',param['ParameterNames'])
        if type(param['ParameterNames'])==type(''):
            param['ParameterNames']=arrayType([param['ParameterNames']], elemsname='string')
        elif type(param['ParameterNames'])==type([]) and param['ParameterNames'] and type(param['ParameterNames'][0])==type('s'):
            #self.log(5,'array of string',"['GetParameterValues','GetParameterAttributes']")
            param['ParameterNames']=arrayType(param['ParameterNames'], elemsname='string')
    if methodname =='SetParameterAttributes':
        if type(param)==type({}):
            param=[param]
        res=[]
        for el in param:
            tempK= {'Name':untypedType(str(el.get('Name'))),
                    'NotificationChange':untypedType(str(el.get('NotificationChange'))),
                    'Notification':untypedType(str(el.get('Notification'))),
                    'AccessListChange':untypedType(str(el.get('AccessListChange'))),
                    'AccessList':arrayType(el.get('AccessList'),  elemsname='string')
                    }
            PAStruct=SetParameterAttributesStruct()
            PAStruct.update(tempK)
            res.append(PAStruct)
        param={'ParameterList':arrayType(res, elemsname='SetParameterAttributesStruct')}



    return param
