# coding:utf-8

import os, logging
from ax.transport.base import \
        ErrorConditionException, ConnectionClosedException,\
        TransportException
from ax.transport.connected_transport import ConnectedGetter
from ax.utils.formatting.html import rewrite_links, neutralize_script_tags

try:
    import ftputil
except Exception as e:
    raise ImportError("ftputil library is required by ftp.py")

logger = logging.getLogger( __name__)

class FTPClient(ConnectedGetter):
    """
    A FTP transport to walk over FTP folders and download it's files.

    Usage example:

    >>> from ax.transport import axpand
    >>> client = axpand.get_transport_object('test', 'ftp')

    >>> files = client.get(cmd='walk', nodes=['/results/ADSL'], store_at='mem')

    or

    >>> files = client.get(cmd='walk', nodes=['/results/ADSL'], store_at='./tmp')
    """
    # variables:
    allowed_args = None
    allowed_cmds = None
    host = '127.0.0.1'
    identification =  "%(host)s"
    user = 'guest@axiros.com'
    password = '1234'
    download_dir = '.'

    def open_connection (self):
        # this must return your connection object, i.e. 
        # the telnet object, the httpconnection, the ssh 
        # connection or whatever. The Session.
        # it usually has an open and close method.
        # open it here, using your params
        conn_obj = ftputil.FTPHost(self.host, self.user, self.password)
        return conn_obj

    def mget(self, server, local_path='', parent_dir='', storage='mem', results={}):

        absolute_path = '%s/%s' %(parent_dir, local_path)

        for remote_dir, dirs, files in server.walk(absolute_path):
            logger.debug('LISTING of %s: \n\t%s\n\t%s' %(remote_dir, dirs, files))

            for _dir in dirs:
                current_path = absolute_path + '/' + remote_dir

                for _files in self.mget(server, local_path=_dir, parent_dir=current_path, storage=storage, results=results):
                    yield _files

            for _file in files:

                source_abs_path = '%s/%s' %(remote_dir, _file)
                source_attributes = server.lstat(source_abs_path)

                logger.debug('\t\tWill download %s (%s)' %(_file, source_abs_path))

                file_attributes = {
                    'name': _file,
                    'remote_path' : source_abs_path,
                    'local_path' :  '',
                    'size' : source_attributes.st_size,
                    'mode' : source_attributes.st_mode,
                    'uid' : source_attributes.st_uid,
                    'gid' : source_attributes.st_gid,
                    'content' : '',
                    'access_time' : 0.0,
                    'modification_time' :0.0,
                }

                if storage == "mem":
                    source = server.file(source_abs_path, 'r')
                    file_attributes['content'] = source.read()
                    source.close()
                else:
                    target_dir = '%s/%s' %(storage, remote_dir)
                    target_abs_path = '%s/%s' %(storage, source_abs_path)
                    if not os.path.exists(target_dir):
                        os.makedirs(target_dir)
                    server.download_if_newer(source=source_abs_path, target=target_abs_path, mode='b')
                    file_attributes['local_path'] = target_abs_path

                results[source_abs_path] = file_attributes

            yield results

    def communicate(self, cmd, conn_obj, condition,\
            error_condition, timeout, **kwargs):
        # entry point for communication:
        # understand the specific commands here.
        if cmd == 'walk':

            nodes = kwargs['nodes']
            storage = kwargs.get('store_at', self.download_dir)

            stacks = []
            results = {}

            for node in nodes:
                stacks.append(self.mget(server=conn_obj, local_path=self.download_dir, parent_dir=node, storage=storage))

            for stack in stacks:
                for result in stack:
                    results.update(result)

            return results


