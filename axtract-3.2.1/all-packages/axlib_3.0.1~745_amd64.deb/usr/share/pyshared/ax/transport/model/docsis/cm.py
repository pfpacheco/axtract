from ax.transport.model.keyval import depends
from ax.transport.model.model_support import add_model
from ax.transport.model.protocols.snmp import SNMP
import re

class CM(SNMP):
    dev  = 0.1
    model = 'DEV2'
    matching = 'docsis.cm'

    def Get_Device_Info(self, t, **kwargs):
        """
        returns a tuple
        (hardware version, vendor, software version, model)
        """
        oid = '1.3.6.1.2.1.1.1.0'
        res = t.get('GET:%s' % oid)
        regexp = '.*HW_REV:\s([^;]*).*VENDOR:\s([^;]*).*SW_REV:\s([^;]*).*MODEL:\s(.*)>>'
        obj = re.search(regexp, res[0])
        hv, vendor, sv, model = obj.groups()
        return (hv, vendor, sv, model)

    def Get_MAC_Address(self, t, **kwargs):
        """
        returns a list of mac addresses related to the cm
        """
        oid = '1.3.6.1.2.1.17.4.3.1.1'
        tmp_res = t.get('WALK:%s' % oid)
        res = []
        for mac in tmp_res:
            if not mac is None:
                mac = str(mac.encode('hex')).upper()
            res.append(mac)
        return res

    def Get_Port(self, t, **kwargs):
        """
        returns a list of ports
        """
        oid = '1.3.6.1.2.1.17.4.3.1.2'
        return t.get('WALK:%s' % oid)

    def Get_Status(self, t, **kwargs):
        """
        returns a list of status strings
        """
        oid = '1.3.6.1.2.1.17.4.3.1.3'
        tmp_res = t.get('WALK:%s' % oid)
        res = []
        c = {1: 'other', 2: 'invalid', 3: 'learned', 4: 'self', 5: 'mgmt'}
        for status in tmp_res:
            if not status is None:
                status = c.get(status, status)
            res.append(status)
        return res

    def Get_DOCSIS_Capability(self, t, **kwargs):
        """
        returns a string representing the docsis capability
        of the cm. Possible values are '1.0', '1.1', '2.0', '3.0'
        """
        oid = '1.3.6.1.2.1.10.127.1.1.5.0'
        res = t.get('GET:%s' % oid)
        #lookup table for different docsis capabilities
        c = {'1': '1.0', '2': '1.1', '3': '2.0', '4': '3.0'}
        return c.get(res[0])

    def Get_DS_Channel_Frequency(self, t, **kwargs):
        """
        returns a list with all channel frequencies of the downstream channels
        """
        oid = '1.3.6.1.2.1.10.127.1.1.1.1.2'
        res = t.get('WALK:%s' % oid)

        temp_list = []
        for frequency in res:
            try:
                frequency = '%.2f' % (float(frequency) / 1000000)
            except TypeError:
                frequency = None
            temp_list.append(frequency)
        return temp_list

    def Get_DS_Channel_Width(self, t, **kwargs):
        """
        returns a list with all channel widths of the downstream channels
        """
        oid = '1.3.6.1.2.1.10.127.1.1.1.1.3'
        res = t.get('WALK:%s' % oid)

        temp_list = []
        for channel_width in res:
            try:
                channel_width = '%.2f' % (float(channel_width) / 1000000)
            except TypeError:
                channel_width = None
            temp_list.append(channel_width)
        return temp_list

    def Get_DS_Modulation(self, t, **kwargs):
        """
        returns a list of modulation values for ds channels
        """
        oid = '1.3.6.1.2.1.10.127.1.1.1.1.4'
        tmp_res = t.get('WALK:%s' % oid)
        c = {1: 'unknown', 2: 'other', 3: 'QAM64', 4: 'QAM256'}
        res = []
        for mod in tmp_res:
            res.append(c.get(mod, mod))
        return res

    def Get_DS_Receive_Power(self, t, **kwargs):
        """
        returns a list with the receive power of all downstream channels
        """
        oid = '1.3.6.1.2.1.10.127.1.1.1.1.6'
        res = t.get('BULK_WALK:%s' % oid)

        temp_list = []
        for rec_power in res:
            try:
                rec_power = '%.1f' % (float(rec_power) / 10)
            except TypeError:
                rec_power = None
            temp_list.append(rec_power)
        return temp_list

    def Get_DS_SNR(self, t, **kwargs):
        """
        returns a list with the snr values of all downstream channels
        """
        oid = '1.3.6.1.2.1.10.127.1.1.4.1.5'
        res = t.get('WALK:%s' % oid)

        temp_list = []
        for snr in res:
            try:
                snr = '%.1f' % (float(snr) / 10)
            except TypeError:
                snr = None
            temp_list.append(snr)
        return temp_list

    def Get_US_Transmit_Power(self, t, **kwargs):
        """
        returns a list with the transmit power of all upstream channels
        """
        oid = '1.3.6.1.4.1.4491.2.1.20.1.2.1.1'
        tmp_res = t.get('WALK:%s' % oid)
        res = []
        if tmp_res is None:
            oid = '1.3.6.1.2.1.10.127.1.2.2.1.3.2'
            tmp_res = t.get('WALK:%s' % oid)
        for tr_power in tmp_res:
            try:
                tr_power = '%.1f' % (float(tr_power) / 10)
            except TypeError:
                tr_power = None
            res.append(tr_power)
        return res


# -------------------------------Helpers
add_model(('docsis.cm', CM()))

RUN = ""
