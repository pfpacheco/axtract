""" Implementation of the paramiko based ssh transport """
from ax.transport.base import (
    ConnectionClosedException,
    TimeoutException,
    TooMuchDataException,
    ErrorConditionException,
)
from ax.transport.telnetter import Telnetter
from ax.transport.base import TransportException
from ax.transport.condition_checking import parse_condition
from time import sleep, time
from select import select
import logging

logger = logging.getLogger(__name__)

try:
    import paramiko
except:
    raise Exception("No paramiko found - try run easy-install paramiko")


class Paramiko(Telnetter):
    """ Using the paramiko SSH Module
    Multi host support !
    """

    identification = "Paramiko://%(host)s:%(port)s/"
    host_auto_add = True
    host = None
    # looks like a reasonable default:
    port = 22
    user = None
    password = None
    timeout = 3
    private_key = None

    # some ssh (audiocodes) only like this:
    # Cisco as well?
    invoke_shell = None
    shell = None
    # onlu for shell mode:
    newline = "\r\n"

    key_filename = None
    allow_agent = True
    # if true it will e.g. search for axd user's ssh keys -
    # and fail if not working:
    look_for_keys = False
    compress = True
    maxdata = 100000
    # we need a condition, otherwise we would not return anything:
    condition = "."
    # only when set to none we ignore stderr:
    err_condition = "."

    def open_connection(self):
        client = paramiko.SSHClient()
        if self.host_auto_add:
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            res = client.connect(
                self.host,
                int(self.port),
                username=self.user,
                password=self.password,
                pkey=self.private_key,
                key_filename=self.key_filename,
                timeout=float(self.timeout),
                allow_agent=self.allow_agent,
                look_for_keys=self.look_for_keys,
            )

        except Exception as ex:
            raise ConnectionClosedException(ex)
        if self.invoke_shell:
            self.my_newline = self.newline
            if "\\n" in self.newline:
                self.newline = self.newline.replace("\\n", "\n").replace(
                    "\\r", "\r"
                )
            self.shell = client.invoke_shell()
            # use this as conn_obj:
        return client

    def no_shell_send_data(self, data, conn_obj):
        try:
            stdin, stdout, stderr = conn_obj.exec_command(data)
        except Exception as ex:
            raise TransportException(
                (
                    "%s. SSH Session lost. "
                    " Some Cisco routers only"
                    " allow one exec command per session. "
                    "Consider TELNET or IOS change."
                )
                % ex
            )
        stdin.close()
        return stdout, stderr

    def send_data(self, cmd, conn_obj):
        print("<-%sENDSEND" % cmd)
        self.shell.send(cmd)

    def read(self, timeout, maxlen, conn_obj):
        """ called from the receive_until of base.py - sender/receiver """
        # looping until condition is met:
        sleep(0.01)
        while 1:
            if self.shell.recv_ready():
                res = self.shell.recv(maxlen)
                print("->%sENDRECV" % res)
                return res
            sleep(0.01)

    def communicate(
        self, cmd, conn_obj, condition, error_condition, timeout, **kwargs
    ):
        if self.invoke_shell:
            return super(Paramiko, self).communicate(
                cmd, conn_obj, condition, error_condition, timeout, **kwargs
            )

        if timeout and timeout != self.timeout:
            raise TransportException(
                "timeout can only be specified as general param, not by command"
            )
        data = ""
        err = ""
        if not cmd == "/WAIT":
            stdout, stderr = self.no_shell_send_data(cmd, conn_obj)
            if self.shell:
                data = stdout
            else:
                # this waits for the command to finish:
                status = stderr.channel.recv_exit_status()
                data = stdout.read()
                err = stderr.read()
                if err:
                    data += ". STDERR: %s" % err

        if not condition or condition == "/NOREAD":
            return ""

        maxdata = kwargs.get("maxdata", self.maxdata)
        if len(data) > maxdata and maxdata:
            raise TooMuchDataException()

        # if we want stderr output to be checked we must supply an
        # error_condition:
        ec = error_condition or self.error_condition
        if ec:
            err_condition_obj, err_meta = build_condition_object(
                error_condition
            )
            if check_condition(err, err_condition_obj, **kwargs):
                raise ErrorConditionException("data: %s" % data)
        return data
