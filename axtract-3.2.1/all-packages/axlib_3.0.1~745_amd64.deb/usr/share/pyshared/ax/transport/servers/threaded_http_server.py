""" A multithreaded HTTP server, specifically for the job queue"""

from ax.transport.connected_transport import ConnectedReceiver


###############################################################
#
# The web job listener:
#
###############################################################

from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
from SocketServer import ThreadingMixIn
from threading import Thread
from ax.transport.model.model_support import Model
from ax.transport.model.servers.http import http_lib


class DefModel(Model):
    """ If no model has been set we use this dummy one """
    def do_GET(self, t, url, *args, **kw):
        return "Default Get Handler, called at %s" % url

def_model = DefModel()



class AxThreadedHTTPServer(ConnectedReceiver, Thread):
    """ Wrapper for the Axpand Server Framework """
    host = '127.0.0.1'
    port = 0

    def open_connection(self):
        self.jh = ThreadedHTTPServer((self.host, int(self.port)), Handler)
        # the connection object:
        if not self.model or self.model_name == 'axiros.static':
            self.model = def_model
        # handler needs as well:
        self.jh.t = self
        return self.jh

    def main_loop(self):
        self.jh.serve_forever()

    def close(self, conn_obj=None):
        self.jh.shutdown()



class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    pass





class Handler(BaseHTTPRequestHandler):
    def do_GET(self, post_data={}):

        url = self.path
        t = self.server.t

        hm = {}
        cookies = {}
        for h in self.headers:
            hm[h] = self.headers.get(h)
            if h == 'cookie':
                for v in hm[h].split('";'):
                    if not '=' in v:
                        continue
                    ck = v.split('=', 1)[0].strip()
                    cv = v.split('=', 1)[1].strip().replace('"', '')
                    cookies[ck] = cv
        hm['cookies'] = cookies
        try:
            res = t.model.do_GET(t, url, hm, post_data)
        except http_lib.Redirect as ex:
            res = {'status': 302,
                    'headers': (('Location', str(ex)),)}

        # res = map or plain str
        if isinstance(res, (str, unicode)):
            res = {'status': 200, 'data': res}
        self.send_response(res['status'])
        headers = res.get('headers', ())
        headers = http_lib.set_mime_type(url, headers, res)
        for h in headers:
            if h[0] == 'cookies':
                for k, v in h[1].items():
                    self.send_header('Set-Cookie', '%s="%s"' % (k, v))
            else:
                self.send_header(h[0], h[1])
        self.end_headers()
        self.wfile.write(res.get('data', ''))



    def do_POST(self):
        """ currenlyt we require a content-length! """
        if 'content-length' in self.headers:
            length = int(self.headers['content-length'])
            data = self.rfile.read(length)
        else:
            # e.g. our tr-069 client sends nothing at empty post,
            # blocks forever at
            # rfile.read(), so:
            data = ''

        return self.do_GET(post_data=http_lib.parse_form(data))

