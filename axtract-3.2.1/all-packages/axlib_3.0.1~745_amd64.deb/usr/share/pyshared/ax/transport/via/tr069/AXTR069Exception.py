import ax.utils.lib.SOAPpy_ax as SOAPpy

structType = SOAPpy.structType
faultType =  SOAPpy.faultType


class AXTR069FaultType(faultType):
    faultcode = 'Server'
    default_faultcode = "8001"
    default_faultstring = "Request denied (no reason specified)"

    def __init__(
            self,
            faultcode=None,
            faultstring=None,
            detail=1,
            SetParameterValuesFault=None):

        self.tr069 = 1
        if not faultcode:
            faultcode = self.default_faultcode
        if not faultstring:
            faultstring = self.default_faultstring
        if detail:
            self.faultcode = faultcode
            self.faultstring = faultstring
            if isinstance(detail, dict):
                self.detail = AXTR069FaultType(
                            detail['Fault']['FaultCode'],
                            detail['Fault']['FaultString'],
                            0,
                            SetParameterValuesFault)
            else:
                self.detail = AXTR069FaultType(
                            faultcode,
                            faultstring,
                            0,
                            SetParameterValuesFault)

            self.SetParameterValuesFault = None
        else:
            self.faultcode = faultcode
            self.faultstring = faultstring
            if SetParameterValuesFault:
                if isinstance(SetParameterValuesFault, (tuple, list)):
                    self.SetParameterValuesFault = SetParameterValuesFault
                else:
                    self.SetParameterValuesFault = [SetParameterValuesFault]
            else:
                self.SetParameterValuesFault = None
        structType.__init__(self, None, 0)


class AXTR069CPEFaultType(AXTR069FaultType):
    faultcode = 'Client'
    default_faultcode = "9001"
    default_faultstring = "Request denied (no reason specified)"


class SetParameterValuesFault(AXTR069FaultType):
    def __init__(self, faultcode, faultstring, parameter):
        self.tr069 = 1
        self.faultcode = faultcode
        self.faultstring = faultstring
        self.ParameterName = parameter
        structType.__init__(self, None, 0)


class AXTR069Exception(Exception):
    def __init__(
            self,
            FaultCode=8001,
            Description='Request denied (no reason specified)'):

        self.FaultCode = FaultCode
        self.Description = Description

    def __str__(self):
        return "Fault %s %s" % (self.FaultCode, self.Description)
