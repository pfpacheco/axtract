""" Module that helps with telnetting and similar stuff.

This module (or rather, its implementations) provide you with functions that
greatly help you when you need to do command->response->command->response...
chains via telnet.

Actually, the various implementations do not only support telnet but anything
that fits in the send_stuff()->receive_stuff()->send_stuff()->receive_stuff()
pattern. This includes
    - generic TCP/IP interactions similar to what netcat does. Check out
        PythonSocketTelnetter and GeventSocketTelnetter for that.
    - Abstracting STDIN/STDOUT/STDERR of arbitrary programs. This is implemented
        by PopenTelnetter and PexpectTelnetter.

Do not be confused by the "...Telnetter" naming. Telnetting was the first use
of this module, but it has actually become a Layer3/Layer4 abstraction system.
What is meant by Layer4 abstraction is that, (ideally at least) you can convert
a Telnet-flow that uses PythonSocketTelnetter into an SSH-flow that uses
PexpectTelnetter simply by instantiating a different class and setting
different properties (in this case $command instead of $host and $port).
"""
import traceback
import time
import logging
from ax.utils.sub_proc_runner import get_proc_res
from ax.transport.base import Getter, SenderReceiver, \
        TransportException, ConnectionClosedException, \
        UnauthorizedException, \
        TooMuchDataException, TimeoutException, ErrorConditionException,\
        EXT_CODE_ENV


logger = logging.getLogger( __name__)

class PrologException(TransportException):
    """Can't login, often needed in the transport prolog"""
    err_id = 18450

class PrologUnauthorizedException(TransportException):
    """Can't login, often needed in the transport prolog"""
    err_id = 18450


# the registry for external code environment:
EXT_CODE_ENV ["PrologException"] = PrologException
EXT_CODE_ENV ["PrologUnauthorizedException"] = PrologUnauthorizedException


class ConnectedGetter(Getter):
    """ Root class for all client server communication classes.
    Via the 'get' function it starts a communication with the server.
    It can do autoconnect and logins, since there are basic
    flow handling functions.
    """

    # we can run close() after each get:
    auto_close      = False
    is_closing      = None
    is_after_prolog = False
    is_connected    = None

    auto_reconnect = None

    # autologon after connect, if prolog is set?:
    auto_prolog = True
    prolog = None
    epilog = None

    # this will hold the physical connection object (like the socket
    # or the soap client object)
    _conn_obj = None

    def __repr__(self):
        if self.ident:
            if self.is_connected:
                return self.ident + ' (connected)'
            return self.ident
        return '%s.%s (uninitialized)' % (self.__module__, self.__class__)

    def connect(self):
        """ Open the resource and call the prolog (login) """
        logger.debug("connecting")
        try:
            self.set_connection_obj(self.open_connection())
        except Exception as ex:
            logger.exception(ex)
            raise ex

        self.is_connected = 1
        if self.prolog and self.auto_prolog:
            try:
                ret = self.get(self.prolog)
                self.is_after_prolog = True
                return ret
            except UnauthorizedException as e:
                logger.exception(e)
                raise PrologUnauthorizedException(str(e))
            except Exception as e:
                logger.exception(e)
                raise PrologException(str(e))


    def close(self, force_close = None, conn_obj = None):
        """ called by close, taking care of epilog running and flag """
        # NOTE: leave force_close, it's used by pooled transports!
        # is_closing set not that we get again the close command if the
        # epilog run is causing an error -> endless loop

        # this might be called also with a conn_obj, e.g. from a
        # threaded transport - we pass it then via kw args through
        # to the comm_thread_starter:
        if self.is_closing:
            return
        # close and flow:
        if self.flow_capt_proc_id:
            get_proc_res(self.flow_capt_proc_id)
            self.flow_capt_proc_id = 0

        conn_obj = conn_obj or self._conn_obj

        self.is_closing = True
        logger.debug("closing")

        if self.epilog:
            try:
                # send empty condition, we don't wait:
                self.get(self.epilog, '', conn_obj=conn_obj)
            except Exception as ex:
                pass
        try:
            self.close_connection(conn_obj)
        except:
            pass
        self.is_closing = None
        self.is_connected = None
        self.clear()


    def open_connection(self):
        """ Opens the resource to use """
        raise NotImplemented


    def close_connection(self, conn_obj=None):
        """ Closes the resource to use and deletes from memory"""
        # might be overrridden/called by implementations:
        conn_obj = conn_obj or self._conn_obj
        try:
            # most have this:
            conn_obj.close()
        except:
            pass
        # that sets it to None again (the class var value):
        del conn_obj


    def set_connection_obj(self, obj):
        """ Set the connection resource """
        self._conn_obj = obj

    def is_closed(self):
        # to be provided by the specifics who use autoreconnect:
        return None

    def get_connection_obj(self):
        """ get a handle on this transport's connection resource """
        if self.auto_reconnect and self.is_closed(self._conn_obj):
            logger.debug("auto reconnecting")
            del self._conn_obj
            self.set_connection_obj(self.open_connection())
        return self._conn_obj


    def handle_get_exception(self, ex, **kwargs):
        # close the resource.
        # this is the ONLY clean way to react on *any* error
        # Reconnect on the next action.
        # Timeout, server error, max data exceeded
        # must lead to reconnect on the next action with the server.
        # Think about it, especially about unread buffers
        # on this socket...
        self.close(force_close = 1)
        super(ConnectedGetter, self).handle_get_exception(ex, **kwargs)


    def after_get(self):
        """ run in any case after each get """
        self.last_transf_time = time.time()
        if self.auto_close:
            self.close()

    # via this we get autoconnection, w/o having to patch def get:
    def auto_connect(self):
        if not self.is_connected:
            self.connect()
    cmd_intro = auto_connect


class ConnectedSenderReceiver(SenderReceiver, ConnectedGetter):
    """ we inherit the communicate method with send/receive """
    pass


class ConnectedReceiver(ConnectedGetter):
    shutdown_requested = 0
    def run(self):
        self.ident += ' (alive)'
        try:
            self.main_loop()
        except Exception as ex:
            logger.info('Closing %s - %s' % (self, ex))
        self.ident = self.ident.replace(' (alive)', '')

