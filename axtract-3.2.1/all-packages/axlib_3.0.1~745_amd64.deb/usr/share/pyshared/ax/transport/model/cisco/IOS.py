from ax.utils.parser.parse_text import get_line_val
from ax.transport.tools.misc import get_uptime_secs
from netaddr import IPNetwork
from ax.transport.tools.misc import get_tr_rpcs, get_error_line, safe_cli_get
from ax.transport.tools.keyval import handle_GPV, handle_SPV, handle_GPN
from ax.transport.tools.misc import handle_Upload, handle_Download
from ax.transport.tools.keyval import SPVException, set_flow
from ax.transport.tools.keyval import depends, lines, indizes


# we work only via these:
WD = '.WANDevice.1.WANConnectionDevice.1.'
LD = '.LANDevice.1.'


class IOS(object):

    def GPV_NSLookupDiagnostics_HostName(self, c, t):
        depends('GPV_DeviceInfo', c, t)


    def GPV_DeviceInfo(self, c, t):
        buf = t.get('show version')
        c['.DeviceInfo.Manufacturer'] = 'Cisco'
        sw = buf.split(' Version', 1)[1].split(',', 1)[0].strip()
        c['.DeviceInfo.SoftwareVersion'] = buf.split(' Version',
            1)[1].split(',', 1)[0].strip()
        # 877W:
        c['.DeviceInfo.HardwareVersion'] = buf.rsplit('cisco.com',
            1)[1].split(' processor ', 1)[0].split('Cisco ')[1].split(' ')[0]

        pre, upt = buf.split('uptime is', 1)
        c['.DeviceInfo.UpTime'] = get_uptime_secs(upt.split('\n')[0])
        c['.NSLookupDiagnostics.HostName'] = pre.rsplit('\n',1)[1].strip()


    def GPV_DeviceInfo_DeviceLog(self, c, t):
        if c.get('in_inform'):
            return
        buf = safe_cli_get(t, 'show log')
        c['.DeviceInfo.DeviceLog'] = buf[-32768:]


    def GPV_DeviceConfig_ConfigFile(self, c, t):
        res = depends('show_run', c, t)
        c['.DeviceConfig.ConfigFile'] = res


    def GPV_DeviceConfig_PersistentData(self, c, t):
        res = depends('show_startup', c, t)
        c['.DeviceConfig.PersistentData'] = res


    def GPV_Time_NTPServer1(self, c, t):
        """
        address         ref clock       st   when   poll reach  delay  offse
        ~1.2.4.2         .INIT.          16      -     64     0  0.000   0.000 1
        *~62.38.83.25     62.38.0.204      5    801   1024   377  1.351  -5.125
        +~62.38.83.26     62.38.0.205      5     58   1024   377  1.414  -5.231
        * sys.peer, # selected, + candidate, - outlyer, x falseticker, ~ configu
        """
        for nr in range(1, 4):
            c['.Time.NTPServer%s' % nr] = ''
        buf = t.get('show ntp associations')
        nr = 0
        for l in buf.split('\n'):
            if len(l) > 1 and l[1] == '~':
                nr += 1
                c['.Time.NTPServer%s' % nr] = l[2:].split(' ', 1)[0]


    def GPV_Time_NTPServer2(self, c, t):
        depends('GPV_Time_NTPServer1', c, t)


    def GPV_Time_NTPServer3(self, c, t):
        depends('GPV_Time_NTPServer1', c, t)


    def GPV_LANDevice(self, c, t):
        ipbrief = depends('show_ip_int', c, t)


# -------------------------------Helpers

    def show_run(self, c, t):
        res = safe_cli_get(t, 'show run', 30)
        return res.split('!', 1)[1].strip()


    def show_startup(self, c, t):
        res = safe_cli_get(t, 'show startup-config')
        return res.split('!', 1)[1].strip()


    def show_ip_nat_translations(self, c, t):
        """
        test_C877_BRM#show ip nat translations
        Pro Inside global         Inside local          Outside local         \
                                                                Outside global
        tcp 5.55.224.4:889        192.168.1.10:80       ---                   \
                                                                ---
        tcp 62.38.95.90:389       192.168.1.11:389      ---
        tcp 5.55.224.4:3389       192.168.1.11:3389     10.5.80.225:4184
        tcp 5.55.224.4:3389       192.168.1.11:3389     ---
        test_C877_BRM#
        """
        res = []
        index = 0
        cmd = 'show ip nat translations'
        for line in lines(t.get(cmd)):
            l = line.split()
            if len(l) < 3 or cmd in line:
                continue
            index += 1
            outip, outport = l[1].split(':')
            inip,  inport  = l[2].split(':')
            res.append({
                          'outIP': outip, 'outPort': outport,
                          'inIP' : inip,  'inPort' : inport,
                          'proto': l[0].upper()
                       }
                      )
        c['show_ip_nat_translations'] = res



    def show_ip_int(self, c, t):
        """
test_C877_BRM>show ip int | inc line | address
ATM0 is up, line protocol is up
Dialer0 is up, line protocol is up
Dialer46 is up, line protocol is up
  Internet address is 5.55.224.4/32
  Broadcast address is 255.255.255.255
  Helper address is not set
  Network address translation is enabled, interface in domain outside
Dot11Radio0 is administratively down, line protocol is down
FastEthernet0 is up, line protocol is up
FastEthernet1 is up, line protocol is down
FastEthernet2 is down, line protocol is down
FastEthernet3 is down, line protocol is down
NVI0 is administratively down, line protocol is down
Virtual-Access1 is up, line protocol is up
  Peer address is 62.38.0.170
Vlan1 is administratively down, line protocol is down
Vlan10 is up, line protocol is down
  Internet address is 192.168.1.1/24
  Broadcast address is 255.255.255.255
  Helper address is not set
  Network address translation is enabled, interface in domain inside
Vlan100 is up, line protocol is up
  Internet address is 62.38.95.90/30
  Broadcast address is 255.255.255.255
  Helper address is not set
  Network address translation is disabled
test_C877_BRM>
        """
        # we will split below, delete the space in the column:
        out = t.get('show ip int | inc line | Internet address')

        ifs = {
            'ATM':            [],
            'Dialer':         [],
            'Vlan':           [],
            'Dot11Radio':     [],
            'FastEthernet':   [],
            'Virtual-Access': []
              }
        nfos = {}

        for line in lines(out):
            if not line.startswith(' '):
                if_name = line.split(' ', 1)[0]
                if_map = {'Name': if_name}
                nfos[if_name] = if_map
                if_map['Status'] = 1
                if 'down' in line:
                    if_map['Status'] = 0

                for if_type in ifs:
                    if line.startswith(if_type):
                        ifs[if_type].append(if_name)
                        break
                continue

            if line.startswith('  Internet address is '):
                ip = IPNetwork(line.rsplit(' ', 1)[1])
                if_map['IP'], if_map['Netmask'] = str(ip.ip), str(ip.netmask)

        for if_type, if_names in ifs.items():
            for if_name in if_names:
                if_map = nfos[if_name]
                tr_node = None
                index = if_names.index(if_name) + 1

                if if_type == 'Dialer':
                    tr_node = WD + 'WANPPPConnection.%s.' % index
                    c[tr_node + 'Name'] = if_name
                    c[tr_node + 'Enable'] = if_map['Status']
                    c[tr_node + 'ExternalIPAddress'] = if_map['IP']

                elif if_type == 'FastEthernet':
                    tr_node = LD + 'LANEthernetInterfaceConfig.%s.' % index
                    c[tr_node + 'Name'] = if_name
                    c[tr_node + 'Enable'] = if_map['Status']

                    tr_node = LD + 'LANHostConfigManagement.IPInterface.%s.' %\
                                    index
                    c[tr_node + 'IPInterfaceIPAddress'] = if_map['IP']
                    c[tr_node + 'IPInterfaceSubnetMask'] = if_map['Netmask']

                if tr_node:
                    # remember the node with indizes:
                    nfos[if_name]['tr_node'] = tr_node

        return [ifs, nfos]




# -----------  Setter Methods:

    setters = {'SPV_LANSetup': ['LANHostConfigManagement']}
    error_markers = ['Bad ', 'nvalid ', ' ncomplete ']
    exit_context = ['exit', 'end']


    def commit_on_close(self, c, t):
        # this takes long, do it only on close:
        t.get('copy running-config startup-config', timeout=10)



    def SPV_LANSetup(self, c, t):
        # all SPV params:
        params = c['to_set_params']
        # get state:
        ifs, nfos = depends('show_ip_int', c, t)

        # configure:
        t.get('conf t')

        # stringify SPV map:
        s_params = str(params)

        # check all ifs which are found (i.e. in c):
        for index in indizes(LD + 'LANEthernetInterfaceConfig.', c):
            if_node = LD + 'LANEthernetInterfaceConfig.%s.' % index
            ip_node = LD + 'LANHostConfigManagement.IPInterface.%s.' % index

            if_name = c.get(if_node + 'Name')
            if not if_name or not (if_node in s_params or ip_node in s_params):
                # iface not there or nothing to change on this one:
                continue

            t.get('interface %s' % if_name)
            # enable?
            key = if_node + 'Enable'
            v = params.get(key)
            set_map = {'c': cache,
                       't': t,
                       'error_markers' : self.error_markers,
                       'ctx_exit': self.exit_context
                       }

            if v != None:
                # enable param set to a value. run the cmd:
                set_map['affects_params'] = key
                if str(v) == '1':
                    set_map['flow'] = 'no shutdown'
                else:
                    set_map['flow'] = 'shutdown'
                set_flow(set_map)

            # ip setup with ip address and netmask?
            ip_key =  ip_node + 'IPInterfaceIPAddress'
            net_key = ip_node + 'IPInterfaceSubnetMask'

            if ip_key in s_params or net_key in s_params:
                ip  = params.get(ip_key,  nfos[if_name]['IP'])
                net = params.get(net_key, nfos[if_name]['Netmask'])
                set_map['affects_params'] = (ip_key, net_key)
                set_map['flow'] = 'ip address %s %s' % (ip, net)
                set_flow(set_map)

            # next iface, or exit on error:
            t.get('exit')

        # back to show mode:
        t.get('end')



# -----------  Upload and Download Support:


    def do_http_cfg_upload(self, t, url, *args, **kwargs):
        res = t.get('copy run %s' % url, condition='?')
        res = t.get('', condition='?')
        res = t.get('', timeout=10)
        if 'Error' in res:
            err = get_error_line(str(res), 'Error')
            raise Exception(err)
    do_tftp_cfg_upload = do_http_cfg_upload


    def do_http_cfg_download(self, t, url, file_name, file_size,*args,**kwargs):
        if not file_name:
            file_name = 'running-config'
        else:
            t.get('delete flash:%s' % file_name, condition='?')
            t.get('', condition='onfirm]')
            t.get('')

        res = t.get('copy %s %s' % (url, file_name), condition='?')
        if 'Error' in res:
            raise Exception(get_error_line(str(res), 'Error'))
        if file_name == 'running-config':
            res = t.get('', timeout=10)
            if 'copied' in res:
                # apply it:
                t.get('copy running-config startup-config', condition='?')
                t.get('', timeout=30)
                return
            raise Exception(str(res), 'Error')

        res = t.get('', condition='?', timeout=10)
        if 'Error' in res:
            raise Exception(get_error_line(str(res), 'Error'))
        if 'Erase flash' in res:
            res = t.get('n', timeout=10)
        if 'copied' in res:
            return
        raise Exception(str(res), 'Error')
    do_tftp_cfg_download = do_http_cfg_download




# -----------  Supported TR-069 RPCs:  
    def GetRPCMethods(self):
        # default handling:
        return {'MethodList': get_tr_rpcs(self)}


    def GetParameterValues(self, params, t, cpe=None, c={}):
        # use the default handler:
        return handle_GPV(params, t, c=cache, cpe=cpe)


    def SetParameterValues(self, params, t, cpe=None, c={}):
        # use the default handler:
        return handle_SPV(params, t, c=cache, cpe=cpe)


    def GetParameterNames(self, params, t, cpe=None, c={}):
        # use the default handler:
        return handle_GPN(params, t, c=cache, cpe=cpe)


    def Reboot(self, params, t, cpe=None, c={}):
        # we save the running config before reboot:
        res = t.get('reload', condition=']')
        if 'Save?' in res:
            res = t.get('yes', condition='onfirm]', timeout=20)
        if 'reload?' in res:
            res = t.get('confirm', condition=None)
        return {}


    def Download(self, params, t, cpe=None, c={}):
        return handle_Download(params, t, cpe, c)


    def Upload(self, params, t, cpe=None, c={}):
        return handle_Upload(params, t, cpe, c)



# register us:
from ax.transport.base import MODELS
MODELS["cisco.IOS"] = IOS()


