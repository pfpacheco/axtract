"""Implementation of a http based interaction """
import logging
from ax.transport.base import \
        ErrorConditionException, ConnectionClosedException,\
        TransportException, TimeoutException
from ax.transport.connected_transport import ConnectedGetter
from simplejson import loads
import redis
import time
import re
from ax.utils.six.moves import _thread as thread
from threading import Lock

logger = logging.getLogger( __name__)


# Can't think of a use case where we need more than these
# but many possible accidential creations (or DOS attacks) - prevent these:
LOCK = Lock()
MAX_LISTENER_THREADS = 100
def set_max_listener_threads(count):
    global MAX_LISTENER_THREADS
    if count < len(EVS_BY_CHANNEL):
        raise TransportException("Hava already %s listeners: %s" % \
                (len(EVS_BY_CHANNEL), EVS_BY_CHANNEL.keys()))
    MAX_LISTENER_THREADS = count

def get_max_listener_threads():
    return MAX_LISTENER_THREADS



EVS_BY_CHANNEL = {}

def start_listener(client, listen_channel, max_age, events_list_check_len):
    """
    Listens in a thread for events on this channel
    Called in a new thread in the connect method if no listener yet there.
    putting all events in a list which is cleared for too old events.
    """
    global EVS_BY_CHANNEL
    lc = listen_channel
    if len(EVS_BY_CHANNEL) > MAX_LISTENER_THREADS - 1:
        # will be causing a threading exception, won't see it anyway:
        logging.error("can't create new listener thread at %s, have already %s"\
             % (lc, len(EVS_BY_CHANNEL)))
        setattr(client, 'axpand_exception', 1)
        raise Exception()

    logging.info("starting subscriber on channel %s" % lc)
    evs = []
    EVS_BY_CHANNEL[lc] = evs
    pubsub = client.pubsub()
    pubsub.subscribe(lc)
    loop = pubsub.listen()
    # this blocks:
    for ret in loop:
        try:
            ret = loads(ret['data'])
        except Exception as ex:
            logging.error("Could not decode %s on %s" % (str(ret), lc))
            continue

        # housekeeping - clean from expired events:
        if len(evs) > events_list_check_len:
            expire = ()
            t = time.time()
            for ev in evs:
                if t - ev[0] > max_age:
                    expire += (ev,)
            for ev in expire:
                try:
                    evs.remove(ev)
                    logging.debug("removed expired event from %s - %s" \
                            % (lc, str(ev)))
                except Exception as ex:
                    # can happen, the transports also remove theirs:
                    pass

        evs.append((time.time(), ret))
        logging.debug("added %s to the event list at %s", ret, lc)


class RedisPubSub(ConnectedGetter):
    """
    Publishing on redis - and possibly wait for returns
    There is a separate Thread which listens on channels
    and pops out events if they match configurable criteria
    or if they are too old.
    Publishing and listening is based on jsonizable maps.
    We multiply all parameters of the transport into the publish message
    templates.

    FIXME: Currently not tested for connection pooling, i.e.
    we create a redis client for every publish event in connect.
    That can be easily pooled.

    Example Use Case:

participant CPE
participant DNS
participant SBI_N
participant PubSub
participant AXPAND
participant SQL
participant AXESS
participant OSS
parallel{
SBI_N->PubSub: Subscribe on channel CNR
AXPAND->PubSub: Subscribe on channel ACK
}
CPE->DNS: Resolve Mgmt Server
note over DNS: Round Robin over SBI servers
CPE->SBI_N: OpenSocket
note over SBI_N: Put cpeid in cache
SBI_N->AXESS: HTTP Boot Message(cpeid)
alt: cpeid new
AXESS->SQL: Enter Device (cpeid)
end
OSS->AXESS: Job(criteria)
AXESS->SQL: Enter Jobs(criteria)
AXPAND->SQL: FindJobs
AXPAND->PubSub: Publish jobs on channel CNR(cpeids)
PubSub->SBI_N: jobs (cpeid)
note over SBI_N: Check cache for cpeid

alt: cpeid NOT in cache
AXPAND->SQL: Write CPE state:\nno reach\n(after waiting 1 second)
end


alt: cpeid in cache
SBI_N->PubSub: Publish cpeid on channel ACK
PubSub->AXPAND: ACK
AXPAND->SQL: Write CPE state: configuring


SBI_N->AXESS: HTTP Request (cpeid)
AXESS->SBI_N: Job
SBI_N->CPE: Job
CPE->SBI_N: JobResult
SBI_N->AXESS: JobResult
note over SBI_N, AXESS: more jobs, until finished (empty response)
end


DPS for this example:
"efr_smartmeter_always_on": {
               "static.via": "redis_pubsub",
               "cpe.state": 0,
               "cpe.props.AA.CH.A.IEC": "EXT",
               "cpe.props.AA.CH.A.D.DI": "%(cpe.cpeid)s",
               "static.inform_flow": "/RUNS: get(jobs)",
               "static.redis_host": "localhost",
               "static.redis_port": 6379,
               "static.publish_channel": "jobs",
               "static.listen_channel": "cnr_1",
               "static.listen_timeout": 0.5,
               "static.listen_match_crit": "device_identification, data",
               "static.publish_json": '{"cpeid": "%(device_identification)s",
                    "args": "", "method": "cnr", "ack_channel": "cnr_1"}'
                             },

    """

    identification =  "%(publish_channel)s@%(redis_host)s:%(redis_port)s"
    allowed_args = None
    allowed_cmds = None
    redis_host = 'localhost'
    redis_port = 6379
    publish_channel = 'jobs'
    # if set a listen thread will be created:
    listen_channel = None
    listen_timeout = 5.0
    listen_match_crit = None
    publish_json = ''
    listen_timeout = 1
    events_list_check_len = 1000

    def create_redis_client(self):
        return redis.Redis(self.redis_host, port=int(self.redis_port))

    def open_connection (self):
        # to publish:
        p_client = self.create_redis_client()
        # if listen:
        if self.listen_channel:
            evs = EVS_BY_CHANNEL.get(self.listen_channel)
            if not self._is_listen_thread_created():
                with LOCK:
                    # maybe a parallel one created it whith the lock?:
                    if not self._is_listen_thread_created():
                        # build a new client and listen:
                        l_client = self.create_redis_client()

                        self.listen_timeout = float(self.listen_timeout)
                        self.events_list_check_len = int(
                                            self.events_list_check_len
                                                        )
                        try:
                            thread.start_new_thread(
                                start_listener,
                                (l_client,
                                 self.listen_channel,
                                 self.listen_timeout,
                                 self.events_list_check_len)
                                )
                            # was the thread created?:
                            t1 = time.time()
                            while time.time() - t1 < 0.2:
                                if hasattr(l_client, 'axpand_exception'):
                                    break
                                time.sleep(0.02)
                                if self._is_listen_thread_created():
                                    break
                            if not self._is_listen_thread_created():
                                raise Exception("Listener not started")

                        except Exception as ex:
                            raise TransportException(
                                   "Can't create new listener thread at %s" % \
                                            self.listen_channel
                                            )

        # our connection object:
        logging.debug("Created redis client %s", self)
        return p_client

    def _is_listen_thread_created(self):
        return EVS_BY_CHANNEL.get(self.listen_channel) != None

    def _listen_match(self, ev):
        """
        does an event in the listen channel match configured criteria?
        we match if an attribute of us is equal to a key in the ev. map
        """
        if not self.listen_match_crit:
            return
        attr, comp = self.listen_match_crit.split(',', 1)
        # currently only 'is equal' support:
        comp = comp.strip()
        if comp in ev[1]:
            if getattr(self, attr.strip(), 'notequal') == ev[1][comp]:
                return 1


    def communicate(self, cmd, conn_obj, condition,\
            error_condition, timeout, **kwargs):

        redis = self._conn_obj

        if cmd == self.publish_channel:
            logging.debug("publishing on %s" % self.publish_channel)
            job = self.publish_json % self
            res = redis.publish(self.publish_channel, job)
            if not res:
                # redis delivers the number of subscribers back:
                logging.debug("%s: no subscribers at %s", job, self)
            if not self.listen_channel:
                return 'published %s on channel %s' % (
                        job,
                        self.publish_channel
                        )
            global EVS_BY_CHANNEL
            evs = EVS_BY_CHANNEL[self.listen_channel]
            t1 = time.time()
            res = None
            while not res:
                now = time.time()
                if evs:
                    for ev in evs:
                        if self._listen_match(ev):
                            # success:
                            logging.debug("matching event %s", str(ev))
                            evs.remove(ev)
                            # breaking while loop:
                            res = ev[1]
                            # breaking for loop:
                            break
                if now - t1 < self.listen_timeout:
                    time.sleep(0.1)
                else:
                    break

            if not res:
                # we are in listen mode, listen channel was set
                # -> do except
                raise TimeoutException(
                        "No result after waiting %s" %\
                        self.listen_timeout
                                     )
            return res

