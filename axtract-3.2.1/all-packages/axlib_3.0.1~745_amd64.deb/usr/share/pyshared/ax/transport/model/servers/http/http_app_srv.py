"""
App server style request handling
Spec. for the Zope HTTP Server, to use apps outside of Zope
"""


from ax.transport.model.model_support import Model
from ax.utils.lru import ExpiringLRUCache
import traceback
from time import time
from http_lib import Redirect, parse_form
import logging
logger = logging.getLogger( __name__)


class ZResponse(dict):
    def __init__(self):
        self.cookies = {}
        self.headers = {}

    def setCookie(self, name, value, **kw):
        self.cookies[name] = value

    def setHeader(self, name, value):
        self.headers[name] = value


class ZRequest(dict):
    """ Creating a dummy Zope request, incl. a in-process session"""
    def __init__(self, t, called, url, headers, post_data, **kw):
        self.form = post_data or {}
        sessions = t.sessions
        try:
            sid = headers['cookies'][t.cookie_name]
        except Exception:
            sid = 'xx'
        if not sid or sessions.get(sid) is None:
            sid = str(time())
            sessions.put(sid, {})

        self.SESSION = sessions.get(sid)
        self.PATH_INFO = url.split('?')[0]
        self.URL = called

        self.traverse_subpath = []
        if self.URL in self.PATH_INFO:
            rest = self.PATH_INFO.split(self.URL, 1)[1]
            if rest.replace('/', ''):
                if rest.startswith('/'):
                    rest=rest[1:]
                if rest.endswith('/'):
                    rest = rest[:-1]
                self.traverse_subpath = rest.split('/')
        else:
            raise Redirect(called)

        if '?' in url:
            query = url.split('?', 1)[1]
            parse_form(query, self.form)

        self.sid = sid
        self.RESPONSE = ZResponse()
        self.RESPONSE.setCookie(t.cookie_name, sid)
        self.AUTHENTICATED_USER = 'FakeUser %s' % self.sid


class FakeApp(object):
    pass


class ZHTTPRequestHandler(Model):
    """
    Mimicking the Zope request handling model.
    For use by other HTTP server models.
    Note: this is for single process servers (sessions are process-local)
    """
    def get_request_env(self, t, called, url, headers, post_data, **kw):
        """ build a request and a session """
        # we have t, i.e. the type of the HTTP server. Check for its vars there
        # before rebuilding them resuse them, like a request or a session.
        if not hasattr(t, 'cookie_name'):
            t.cookie_name = 'axp_z_http'
            t.sessions = ExpiringLRUCache(size=1000, default_timeout=300)
        # build the request:
        req = ZRequest(t, called, url, headers, post_data, **kw)
        return {'request': req, 'app': FakeApp}


    def handle_exc(self, ex):
        return {'status': 500, 'data': traceback.format_exc()}


try:
    from ZEO import ClientStorage
    from ZODB import DB
    #import transaction
    zeo_avail = 1
except Exception:
    print ("No ZEO libs available - APP access only via HTTP")
    zeo_avail = 0


ZEOConnections = {}
def setup_zeo(t_zeo):
    if not zeo_avail:
        # Not yet implemented, ZODB access w/o the zeo connection:
        # maybe just (r)sync over the datafs file(?)
        ZEOConnections[t_zeo] = FakeApp
    else:
        zeo = t_zeo
        if not ':' in zeo:
            zeo += ':8100'
        host, port = zeo.split(':')
        conn = DB(ClientStorage.ClientStorage((host, int(port)), 'main')).open()
        app = conn.root()['Application']
        ZEOConnections[t_zeo] = app



class ZeoClient(ZHTTPRequestHandler):

    def get_request_env(self, t, called, url, headers, post_data, **kw):
        """ build a request and a session """
        if not hasattr(t, 'zeo'):
            raise Exception('no zeo connection configured in transport')
        env = super(ZeoClient, self).get_request_env(t, called, url,
                               headers, post_data, **kw)
        app = ZEOConnections.get(t.zeo)
        if not app:
            setup_zeo(t.zeo)
            app = ZEOConnections.get(t.zeo)
        env['app'] = app
        return env



