#!/usr/bin/env python

import SocketServer
import sys, os
from random import randint
import pprint
from time import sleep, time
import threading

USER = 'user'
PASS = 'pass'
PASS2 = 'cisco'

# will sleep at each receive (simulate network delay):
# can be set via sending a 'Sleep: <secs>' over to us:
SLEEP = 0

# can be set by sending: ServerSilent
SILENT = 1

PROMPT1 = '$ '
SC = 'exit, logout, <S|s>leep: <secs>, ServerSilent[Off], os: <cmd> - all others are just echoed'
SETUPS = {'default': {'type': 'default', 'LS': '\n',
                    'LoginMsg': 'hint: "user" is accepted\nLogin: ', \
                    'LogoutMsg': 'Good bye', \
                    'WelcomeMsg': 'Welcome to the echo test server! Supported commands: %s' % SC,\
                    'prompt1': PROMPT1},
        'cisco': {'type': 'cisco', 'LS': '\n',
            'LoginMsg': 'hint: user, pass, accepted, cisco is enable pw. Understood: term len 0, enable, configure terminal, exit. Else is echoed when in conf t mode, otherwise they must start with "show "\n\nUser Access Verification \n\nUsername: ',
                'PWPrompt': 'Password: ',
                'prompt1': 'testhost>',
                'prompt2': 'testhost#',
                'prompt3': 'testhost(config)#'}
                    }

m = {}
m.update(SETUPS['default'])
m['is_closing_server'] = 1
SETUPS['closing_server'] = m
SETUPS['soap'] = m

def slog(s):
    global SILENT
    if not SILENT:
        print ("  SERVER: %s" % s)

"""
cisco session:
    on server: python test_socket_server.py cisco
    on client:
    root@debianVM:/opt/axess/src/ax.transport/ax/transport# telnet 127.0.0.1 20093
    Trying 127.0.0.1...
    Connected to 127.0.0.1.
    Escape character is '^]'.
    hint: user, pass, accepted, cisco is enable pw. Understood: term len 0, enable, configure terminal, exit. Else is echoed when in conf t mode, otherwise they must start with "show "

    User Access Verification

    Username: foo
    Password: bar

    % Authentication failed
    hint: user, pass, accepted, cisco is enable pw. Understood: term len 0, enable, configure terminal, exit. Else is echoed when in conf t mode, otherwise they must start with "show "

    User Access Verification

    Username: user
    Password: pass

    testhost>enable
    Password: foo

    % Access denied

    testhost>enable
    Password: cisco
    testhost#ip conf foo

    % Invalid input detected at '^' marker.

    testhost#show foo
    show foo
    testhost#configure terminal
    Enter configuration commands, one per line.  End with CNTL/Z.
    testhost(config)#ip conf foo
    ip conf foo
    testhost(config)#exit
    testhost#exit
    Connection closed by foreign host.
    root@debianVM:/opt/axess/src/ax.transport/ax/transport#


"""

class ThreadedMyTCPHandler(threading.Thread):
    setup = {}
    port = 0
    def setup (self, setup, port):
        slog( "Starting with setup %s at %s" % (setup, port))
        self.port = port
        if type(setup) == type('string'):
            setup = SETUPS[setup]
        self.setup = setup
        MyTCPHandler.testmap = setup
        self.server = SocketServer.ThreadingTCPServer(('127.0.0.1', self.port), MyTCPHandler)

    def run(self):
        self.server.serve_forever()



class MyTCPHandler(SocketServer.BaseRequestHandler):
    """
    The RequestHandler class for our server.

    Test it by telnetting to it manually. Accepted user is 'user'.

    It is instantiated once per connection to the server, and must
    override the handle() method to implement communication to the
    client.
    """
    testmap = {}
    logged_in = 0
    initted = 0


    def setup(self):
        if not self.initted:
            for k,v in self.testmap.items():
                setattr(self, k,v)
            self.initted = 1
        if self.LoginMsg: self.request.send(self.LoginMsg)

    def handle(self):
        global SLEEP
        global SILENT
        # self.request is the TCP socket connected to the client
        self.prompt = self.LoginMsg
        willsend = ''
        while 1:
            try:
                self.data = self.request.recv(1024).strip()
            except Exception as e:
                # exit more cleanly:
                slog( "Connection reset - exitting")
                return
            if self.data == 'stop':
                self.server.shutdown()
                slog( "shutdown")
                return

            elif self.data == 'exit':
                slog( "Exit was sent - closing directly")
                self.request._sock.close()
                return


            sleep(SLEEP)
            slog( "> %s" % self.data)
            if hasattr(self, 'is_closing_server'):
                self.request.send('One shot closing server received %s' % self.data)
                return

            if self.type == 'cisco':
                slog( "Logged in mode: %s " % self.logged_in)
                slog( "Received %s." % self.data)
                if self.logged_in == 0:
                    self.logged_in = 1
                    user_entered  = self.data
                    self.request.send(self.PWPrompt)
                    continue
                if self.logged_in == 1:
                    if user_entered + self.data ==USER+PASS:
                        self.logged_in = 2
                        self.prompt = self.prompt1
                        self.request.send('\n' + self.prompt)
                        continue
                    else:
                        sleep(1)
                        self.logged_in = 0
                        user_entered = ''
                        self.request.send('\n% Authentication failed\n' + self.LoginMsg)
                        continue
                if self.data == 'term len 0':
                    self.request.send( self.prompt)
                    continue
                if self.logged_in == 2:
                    if self.data == 'enable':
                        self.logged_in = 3
                        self.request.send(self.PWPrompt)
                        continue
                if self.logged_in == 3:
                    if self.data == PASS2 :
                        # enabled:
                        self.logged_in = 4
                        self.prompt = self.prompt2
                        self.request.send(self.prompt2)
                        continue
                    else:
                        # cisco does no sleep here
                        self.logged_in = 2
                        self.request.send('\n% Access denied\n\n' + self.prompt)
                        continue
                if self.logged_in == 4:
                    if self.data == 'configure terminal':
                        self.prompt = self.prompt3
                        self.logged_in = 5
                        self.request.send('Enter configuration commands, one per line.  End with CNTL/Z.\n' + self.prompt)
                        continue
                if self.logged_in == 5:
                    # conf t enable mode:
                    if self.data == 'exit':
                        self.logged_in = 4
                        self.prompt = self.prompt2
                        self.request.send(self.prompt)
                        continue
                if not self.data.startswith('exit') and not self.data.startswith('show ') and self.logged_in != 5:
                    self.request.send("\n% Invalid input detected at '^' marker.\n\n" + self.prompt)
                    continue




            if not self.logged_in:
                if self.data == USER:
                    self.prompt = self.prompt1
                    self.logged_in = 1
                    willsend = self.WelcomeMsg
            else:
                # this is an echo server, if not stated
                # otherwise below:
                willsend = 'SERVERECHO: %s' % self.data
                # this is a hard break, dangling socket:
                if self.data == 'logout':
                    slog( 'Logout - we leave open and go to login prompt again')
                    self.logged_in = 0
                    self.prompt = self.LoginMsg
                    willsend = self.LogoutMsg

                elif self.data == 'ServerSilent':
                    slog( "Silent mode on")
                    SILENT = 1

                elif self.data == 'ServerSilentOff':
                    slog( "Silent mode off")
                    SILENT = 0

                # sleep: t or Sleep: t?
                elif self.data[1:].startswith('leep: '):
                    secs = float(self.data[6:].strip())
                    if self.data[0] == 'S':
                        slog( "Global sleep mode on: %s secs" % secs)
                        SLEEP = secs
                    else:
                        slog( "sleeping %s secs" % secs)
                        sleep(secs)
                        slog("done sleeping")
                elif self.data.startswith('os: '):
                    # run an os call:
                    willsend = os.popen(self.data[4:]).read()
            try:
                self.request.send(willsend + self.LS + self.prompt)
            except Exception as ex:
                slog( 'Server exitting with error: %s' % ex)
                return


if __name__ == "__main__":
    if '-h' in sys.argv:
        print ("Start with %s [commport] [setup_name] where commport is the port to listen and setup_name is the name of the setup " % (sys.argv[0], ))
        print ("-" * 70)
        print ("All setups:")
        pprint.pprint(SETUPS)
        sys.exit(0)
    if len(sys.argv) == 3:
        commport, setup_name = int(sys.argv[1]), sys.argv[2]
        TS = ThreadedMyTCPHandler()
        TS.setup(setup_name, commport)
    else:
        commport = randint(20000, 21100)
        TS = ThreadedMyTCPHandler()
        import sys
        if len (sys.argv) > 1:
            TS.setup(sys.argv[1], commport)
        else:
            TS.setup('default', commport)
    #TS.setDaemon(True)
    TS.start()
    slog( "Started threaded server on port %s. Send 'stop' to this port to stop it" % commport)
