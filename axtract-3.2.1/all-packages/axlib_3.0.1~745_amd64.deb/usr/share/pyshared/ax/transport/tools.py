'''
Dependency free base tools, resovling some circular import probs
'''

import logging, sys, re
logger = logging.getLogger(__name__)

PY2 = sys.version_info[0] < 3
_str_type = basestring if PY2 else str
is_str = lambda s: isinstance(s, _str_type)



class TransportException(Exception):
    """ Root of all exceptions"""
    err_id = 18000
    def __init__(self, ex_str=None, ex_obj=None):
        self.ex_obj = ex_obj
        if not ex_str:
            if ex_obj:
                ex_str = str(ex_obj)
            else:
                ex_str = 'Transport Exception'
        super(TransportException, self).__init__(ex_str)

    def get_class_name(self, c):
        # crazy, obviously strange exception objects gotten:
        return str(c.__class__).rsplit('.',1)[1].split("'", 1)[0]

    def __str__(self):
        cs = self.get_class_name(self)
        m = self.message
        if self.ex_obj:
            ecs = self.get_class_name(self.ex_obj)
            return '%s %s: %s(%s)' % (cs, self.err_id, ecs, m)
        else:
            return '%s %s: %s' % (cs, self.err_id, m)


class ConnectionClosedException(TransportException):
    """You wanted to send/receive but the other side closed the connection"""
    err_id = 18400

class UnauthorizedException(TransportException):
    """Credentials had not been accepted"""
    err_id = 18450


class TooMuchDataException(TransportException):
    """A read aborted because more data was received than allowed.
        Check the $maxdata parameter of read_until()
    """
    err_id = 18500

class TimeoutException(TransportException):
    """A read aborted because no $terminator was found before timeout"""
    err_id = 18600

class SecurityException(TransportException):
    """Cmds or args violated the allowed set"""
    err_id = 18650


class ErrorConditionException (TransportException):
    """An interaction with the other side was considered an error from the
    other side (matching the error_condition in general)"""
    err_id = 17000


def load_uri_with_env(uri, t_obj, MODELS):
    if not uri:
        return
    logger.info('loading uri %s for %s', uri, t_obj)
    exec_globals = {
            'transport': t_obj,
            'self': t_obj,
            'MODELS': MODELS
            }
    exec_globals.update(EXT_CODE_ENV)
    do_reload = False
    if uri.startswith('RELOAD:'):
        uri = uri.split('RELOAD:', 1)[1].strip()
        do_reload = True
    code = load_ext_uri(uri, exec_globals, cache_code=1, force_reload=do_reload)
    logger.debug("loaded code %s", code)



# debug level control (dbg_cli var)
START_PDB_ON_GET = '1'
STACK_TRACE_GET_EXCEPTIONS = '2'

# object() is quite
# pointless, but guaranteed not to be equal to anything except itself.
UNTIL_EOF = lambda data, **kwargs: isinstance(data, ConnectionClosedException)
UNTIL_TIMEOUT = lambda data, **kwargs: isinstance(data, TimeoutException)
NO_READ = object()

# that map might be extended by other transports:
EXT_CODE_ENV = {"re"            : re,
    "TransportException"        : TransportException,
    "TimeoutException"          : TimeoutException,
    "TooMuchDataException"      : TooMuchDataException,
    "UnauthorizedException"     : UnauthorizedException,
    "SecurityException"         : SecurityException,
    "ErrorConditionException"   : ErrorConditionException,
    "ConnectionClosedException" : ConnectionClosedException,
    "UNTIL_EOF"                 : UNTIL_EOF,
    "UNTIL_TIMEOUT"             : UNTIL_TIMEOUT,
    "NO_READ"                   : NO_READ
            }



RE_CACHE = {}
STATS = {}
STATS_EXTENDED = {}
