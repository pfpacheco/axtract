"""Implementation of a fast file writer - ready to subclass """
# FIXME: Currently no file deletion detection. Need signal handling?

from ax.transport.base import ErrorConditionException, \
        ConnectionClosedException, TimeoutException
from ax.transport.connected_transport import ConnectedGetter
import os
from os import linesep as LS
import logging
from time import time, ctime

logger = logging.getLogger( __name__)

class FileWriter(ConnectedGetter):
    """
    Writing to files, lineseperated, with flush control
    and max size policies
    """
    target_file = None
    identification =  "FILE://%(target_file)s"
    reset = None
    # 100 meg default:
    max_size = 1024 * 1024 * 100
    # every 100 we check:
    max_size_check = 100
    format_str = ""
    counter = 0
    buffering = -1
    allowed_args = None
    do_newline = True
    newline = ''

    def open_connection(self):
        mode = 'a'
        if self.reset:
            mode = 'w'
        try:
            myfile = open(self.target_file, mode, self.buffering)
            if self.do_newline:
                self.newline = LS
        except Exception as ex:
            raise ConnectionClosedException('Could not open file: %s (%s)' \
                    % (self.target_file, ex))
        return myfile

    def check_file_deleted(self, conn_obj):
        try:
            os.stat(self.target_file)
        except:
            logging.warning("file deleted - recreating it")
            conn_obj = open(self.target_file, 'a')
            self.set_connection_obj(conn_obj)
            self.counter = 0
        return conn_obj

    def communicate(self, cmd, conn_obj, condition, error_condition,\
            timeout, **kwargs):

        args = kwargs.get('args', {})

        self.counter += 1

        # tell flushes, at least in 2.6
        if self.counter > self.max_size_check:
            self.counter = 1
            if conn_obj.tell() > self.max_size:
                conn_obj.truncate(self.max_size)
            conn_obj = self.check_file_deleted(conn_obj)

        if not cmd == 'write':
            raise TransportException\
                    ("only cmds 'write' are supported")

        line = kwargs.get('line')

        if not line:
            # auto add ts and tpretty as possible format params:
            stuff = kwargs.get('stuff')

            if not type(stuff) == dict:
                raise TransportException("Need line or stuff argument")

            stuff['ts'] = time()
            stuff['tpretty'] = ctime()

            try:
                line = self.format_str % stuff
            except Exception as ex:
                raise TransportException\
                        ("parameter missing in %s % %s: %s" % \
                        (self.format_str, stuff, ex))

        for run in (1,2):
            try:
                conn_obj.write(line + self.newline)
                break
            except IOError:
                # someone deleted it? Recreate:
                # FIXME:NOPE. We don't see it. 
                # this exception block won't be hit.
                if run == 1:
                    conn_obj = self.set_connection_obj\
                            (open(self.target_file, 'a'))
                    continue
                else:
                    raise ConnectionClosedException
                    ("Can't write to file %s" % self.target_file)

        # per write event flush control:
        if 'do_flush' in kwargs:
            logging.debug("flusing")
            # force flush:
            conn_obj.flush()

        return line


