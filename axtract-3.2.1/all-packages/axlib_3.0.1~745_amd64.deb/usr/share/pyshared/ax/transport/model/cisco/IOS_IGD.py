from ax.utils.parsing.parse_text import get_line_val, parse_timestr
from cgi import escape
from netaddr.core import AddrFormatError
import time
from datetime import datetime
from netaddr import IPAddress as IP
from netaddr import IPNetwork, EUI
from ax.transport.model.misc import get_error_line
from ax.transport.model.misc import get_uptime_secs, put
from ax.transport.model.misc import safe_cli_get
from ax.transport.model.misc import handle_Upload, handle_Download

from ax.transport.model.keyval import handle_SPV, handle_GPN
from ax.transport.model.keyval import set_flow
from ax.transport.model.keyval import depends, lines, indizes
from ax.transport.model.model_support import add_model
from ax.transport.model.model_support import Model, ROOT
# we work only via these:
DI = '.DeviceInfo.'

class IOS_IGD(Model):
    root = 'I'
    model = 'IGD'
    # DEV2 is explored now -> x:
    matching = 'xcisco.pexpect|ssh|telnet'


    def GPV_DeviceInfo(self, t):
        c = t.session_cache
        # InterfaceStackNumberOfEntries:
        buf = depends('show version', t)


        c[DI + 'Manufacturer'] = 'Cisco'
        c[DI + 'ManufacturerOUI'] = '00067C'
        c[DI + 'ProductClass'] = 'AXPAND'
        c[DI + 'SoftwareVersion'] = get_line_val(
                buf,
                'Version',
                ',',
                get=0)
        # HW model: take the first word in the line after Processor board ID:
        hw = buf.split('Processor board ID', 1)[1].split('\n', 1)[1].split()[0]
        c[DI + 'ModelName'] = hw
        c[DI + 'HardwareVersion'] = hw
        c[DI + 'Description'] = 'Cisco %s router managed by Axiros AXPAND' % hw
        c[DI + 'SerialNumber'] = get_line_val(buf, 'Processor board ID')

        pre, upt = buf.split('uptime is', 1)
        c[DI + 'UpTime'] = get_uptime_secs(upt.split('\n')[0])
        c['.NSLookupDiagnostics.HostName'] = pre.rsplit('\n',1)[1].strip()

        # boot time - vendor specific feature:
        # System restarted at 05:10:03 MEZ Wed May 8 2002
        boot_time_ts = depends('parse_clock', t) - c[DI + 'UpTime']
        # convert:
        try:
            # client conversion problem with float:
            c['.X_AXIROS_COM.CpeInfos.BootTime'] = str(boot_time_ts)
            c['.X_AXIROS_COM.CpeInfos.BootTimePretty'] = time.ctime(boot_time_ts)
        except:
            # not statement about restart:
            pass


    def GPV_DeviceInfo_DeviceLog(self, t):
        c = t.session_cache
        if c.get('in_inform'):
            return
        buf = safe_cli_get(t, 'show log')
        c['.DeviceInfo.DeviceLog'] = escape(buf[-100:])

    def GPV_DeviceConfig_ConfigFile(self, t):
        c = t.session_cache
        res = depends('show_run', t)
        c['.DeviceConfig.ConfigFile'] = res


    """
    def xGPV_DeviceConfig_PersistentData(self, t):
        c = t.session_cache
        res = depends('show_startup', t)
        c['.DeviceConfig.PersistentData'] = res

    """

    def GPV_Time_NTPServer1(self, t):
        """
        address         ref clock       st   when   poll reach  delay  offse
        ~1.2.4.2         .INIT.          16      -     64     0  0.000   0.000 1
        *~62.38.83.25     62.38.0.204      5    801   1024   377  1.351  -5.125
        +~62.38.83.26     62.38.0.205      5     58   1024   377  1.414  -5.231
        * sys.peer, # selected, + candidate, - outlyer, x falseticker, ~ configu
        """
        c = t.session_cache
        for nr in range(1, 5):
            c['.Time.NTPServer%s' % nr] = ''
        buf = t.get('show ntp associations')
        nr = 0
        for l in buf.split('\n'):
            if len(l) > 1 and l[1] == '~':
                nr += 1
                c['.Time.NTPServer%s' % nr] = l[2:].split(' ', 1)[0]


    def GPV_Time(self, t):
        c = t.session_cache
        buf = t.get('show ntp status')
        c['.Time.Enable'] = True
        if 'not enabled' in buf:
            c['.Time.Status'] = 'Disabled'
        else:
            if ' unsynchronized' in buf:
                c['.Time.Status'] = 'Unsynchronized'
            elif ' synchronized' in buf:
                c['.Time.Status'] = 'Synchronized'
            elif not 'clock' in buf:
                c['.Time.Status'] = 'Disabled'
                c['.Time.Enable'] = False
            else:
                c['.Time.Status'] = 'Error'
        # like: 11:44:59.302 MEZ Sun Jun 16 2002
        clockts = depends('parse_clock', t)
        c['.Time.CurrentLocalTime'] =  datetime.fromtimestamp(int(clockts))

        # additional parameters, required by REGMAN
        # TODO: Fill with valid values if available
        c['.Time.DaylightSavingsEnd'] = ""
        c['.Time.DaylightSavingsStart'] = ""
        c['.Time.DaylightSavingsUsed'] = ""
        c['.Time.LocalTimeZone'] = ""


    def GPV_Time_NTPServer2(self, t):
        depends('GPV_Time_NTPServer1', t)


    def GPV_Time_NTPServer3(self, t):
        depends('GPV_Time_NTPServer1', t)

    def GPV_IP_Diagnostics(self, t):
        """ not yet... """
        c = t.session_cache
        c['.IP.Diagnostics.IPPing.DiagnosticsState']    = ""
        c['.IP.Diagnostics.IPPing.FailureCount']        = ""
        c['.IP.Diagnostics.IPPing.Host']                = ""
        c['.IP.Diagnostics.IPPing.Interface']           = ""
        c['.IP.Diagnostics.IPPing.MaximumResponseTime'] = 0
        c['.IP.Diagnostics.IPPing.MinimumResponseTime'] = 0
        c['.IP.Diagnostics.IPPing.NumberOfRepetitions'] = 0
        c['.IP.Diagnostics.IPPing.SuccessCount']        = 0
        c['.IP.Diagnostics.IPPing.AverageResponseTime'] = 0
        c['.IP.Diagnostics.IPPing.Timeout']             = ""



# -------------------------------Helpers
    def ip_in_pool(self,ip, pool):
        ipmin = int(IP(pool['MinAddress']))
        ipmax = int(IP(pool['MaxAddress']))
        if ipmin <= int(ip) and int(ip) <= ipmax:
            return 1

    def parse_dhcp(self, t):
        run = depends('show_run', t)
        pools = {}
        for pool_block in self.parse_run_blocks('ip dhcp pool', run):
            try:
                new_pool = {}
                pool = pool_block.splitlines()
                pool_name = pool[0].strip().rsplit(' ',1)[1]
                for line in pool[1:]:
                    line = line.strip()
                    if line.startswith('network'):
                        new_pool['SubnetMask'] = line.split(' ')[-1].strip()
                        address = line.split(' ')[1].strip()
                        ip = IPNetwork(address + '/' + new_pool['SubnetMask'])
                        new_pool['MaxAddress'] = (IP(ip.last) - 1).__str__()
                        new_pool['MinAddress'] = (IP(ip.first) + 1).__str__()
                    elif line.startswith('default-router'):
                        new_pool['IPRouters'] = \
                            line.split('default-router ')[1].replace(' ', ',')
                    elif line.startswith('domain-name'):
                        new_pool['DomainName'] = line.split(' ')[-1]
                    elif line.startswith('dns-server'):
                        new_pool['DNSServers'] = \
                                line.split('dns-server ')[1].replace(' ', ',')
                    elif line.startswith('lease'):
                        # lease {days [hours][minutes] | infinite}
                        if 'infinite' in line:
                            new_pool['DHCPLeaseTime'] = 'infinite'
                        else:

                            lease_t = line.split()+['0', '0']
                            days  = lease_t[1]
                            hours = lease_t[2]
                            mnt   = lease_t[3]
                            new_pool['DHCPLeaseTime'] = int(days) * 86400 + \
                                int(hours) * 3600 + int(mnt) * 60
                    if not new_pool.get('DHCPLeaseTime'):
                        # cisco default is a day:
                        new_pool['DHCPLeaseTime'] = 86400


                pools[pool_name] = new_pool
            except IndexError:
                continue
        t.session_cache['pools'] = pools
        return pools
        """ the pools dict should be like this(keys are the pool names):
            {
              '1': {'SubnetMask': '255.255.0.0',
                    'IPRouters': '172.16.1.100,172.16.1.101',
                    'DomainName': 'axiros.com',
                    'DNSServers': '172.16.1.102,172.16.2.102',
                    'MinAddress': '172.16.0.1',
                    'MaxAddress': '172.16.255.254'
                    },
              '192.168.2.0/24': {'DomainName': 'ssg-test.local',
                    'IPRouters': '192.168.2.254',
                    'DHCPLeaseTime': '1800',
                    'SubnetMask': '255.255.255.0',
                    'DNSServers': '192.168.1.1',
                    'MinAddress': '192.168.2.1',
                    'MaxAddress': '192.168.2.254'
              }
            }
        """



    def parse_clock(self, t):
        ret = depends('show clock', t).replace('*', '')
        if not ret:
            return ''
        ret = ret.replace('show clock', '').strip().split('\n')[0].strip().split()
        t.session_cache['.Time.LocalTimeZoneName'] = ret[1]
        # FIXME must be IEEE 1003.1:
        t.session_cache['.Time.LocalTimeZone'] = ret[1]
        # strange timezones replacement: FIXME
        ret[1] = 'CET'
        ret = ' '.join(ret)
        if ret[8] == '.':
            ret = ret[0:8] + ret[12:]
        ret = parse_timestr(ret, '%H:%M:%S %Z %a %b %d %Y')
        return ret


    def parse_run_blocks(self, match, run):
        blocks = run.split(match)[1:]
        res = []
        for b in blocks:
            res.append(self.parse_run_block(match, '\n' + match + b))
        return res


    def parse_run_block(self, match, run):
        ret = ''
        inblock = 0
        for line in run.split('\n'):
            if line.startswith('!'):
                continue
            if not line.startswith(' '):
                if inblock:
                    # we are out:
                    return ret
                else:
                    if not match in line:
                        continue
                    ret += line + '\n'
                    inblock = 1
            else:
                if inblock:
                    ret += line + '\n'

        return ''



    def show_run(self, t):
        #TODO
        return RUN
        res = safe_cli_get(t, 'show run', 30)
        return res.split('!', 1)[1].strip()


    def show_startup(self, t):
        res = safe_cli_get(t, 'show startup-config')
        return res.split('!', 1)[1].strip()

    def show_ip_nat_translations(self, t):
        """
        test_C877_BRM#show ip nat translations
        Pro Inside global         Inside local          Outside local         \
                                                                Outside global
        tcp 5.55.224.4:889        192.168.1.10:80       ---                   \
                                                                ---
        tcp 62.38.95.90:389       192.168.1.11:389      ---
        tcp 5.55.224.4:3389       192.168.1.11:3389     10.5.80.225:4184
        tcp 5.55.224.4:3389       192.168.1.11:3389     ---
        test_C877_BRM#
        """
        c = t.session_cache
        res = []
        index = 0
        cmd = 'show ip nat translations'
        for line in lines(t.get(cmd)):
            l = line.split()
            if len(l) < 3 or cmd in line:
                continue
            index += 1
            outip, outport = l[1].split(':')
            inip,  inport  = l[2].split(':')
            res.append({
                          'outIP': outip, 'outPort': outport,
                          'inIP' : inip,  'inPort' : inport,
                          'proto': l[0].upper()
                       }
                      )
        c['show_ip_nat_translations'] = res

    def lan_hosts(self, t, prefix, ifn, ip_brief, arp, layer2name):
        # ifn = 'FastEthernet0/1'
        """
        InternetGatewayDevice.LANDevice.1.Hosts.Host.9.HostName : horst
        InternetGatewayDevice.LANDevice.1.Hosts.Host.9.IPAddress : 192.168.1.31
        InternetGatewayDevice.LANDevice.1.Hosts.Host.9.InterfaceType : Ethernet
        InternetGatewayDevice.LANDevice.1.Hosts.Host.9.LeaseTimeRemaining : 0
        InternetGatewayDevice.LANDevice.1.Hosts.Host.9.MACAddress : 28:37:37:02:FE:68
        InternetGatewayDevice.LANDevice.1.Hosts.HostNumberOfEntries : 13
        """
        c = t.session_cache
        dhcp = depends('show ip dhcp binding', t)
        layer2name = ROOT[self.root] + layer2name
        clockts = depends('parse_clock', t)
        prefix += 'Hosts.'
        buf = arp
        hind = 0
        active_hosts = []
        int_by_ip = {}
        for line in buf.split('\n'):
            line = line.strip()
            if 'Incomplete' in line:
                continue
            ls = line.split()
            if not len(ls) == 6:
                continue
            IP = ls[1]
            if ' %s ' % IP in ip_brief:
                # this is the cisco itself.
                continue
            int_by_ip[IP] = ls[-1].strip()
            if ifn not in ls[-1]:
                continue
            hind += 1
            tld = prefix +'Host.%s.' % hind
            c[tld + 'Layer2Interface'] = layer2name
            c[tld + 'IPAddress'] = IP
            c[tld + 'InterfaceType'] = 'Ethernet'
            c[tld + 'Active'] = True
            address_source = 'Static'
            lease_time_remaining = 0
            for row in dhcp.split('\n'):
                if row.startswith(IP):
                    tmp = row.split()[2:-1]
                    lease_expire = parse_timestr('%s %s %s %s' \
                            % (tmp[3], tmp[0], tmp[1], tmp[2]), '%H:%M %b %d %Y')
                    address_source = 'DHCP'
                    lease_time_remaining = int(lease_expire - clockts)
                    break
            c[tld + 'AddressSource'] = address_source
            c[tld + 'LeaseTimeRemaining'] = lease_time_remaining
            mac = ls[3]
            c[tld + 'MACAddress'] = str(EUI(mac)).replace('-', ':')
            c[tld + 'HostName'] = 'Org: ' + \
                    EUI(mac).info.OUI.org.replace(' ','')
            active_hosts.append(IP)
        # search for hosts no longer in the arp table but still in dhcp binding
        for row in dhcp.split('\n'):
            # is ip, for sure there are better ways..
            try:
                ip_test_len = len(row.split()[0].split('.'))
            except:
                continue
            if ip_test_len == 4:
                IP = row.split()[0]
                if not ifn in int_by_ip.get(IP, ''):
                    continue
                if IP not in active_hosts:
                    # inactive host, let's add it
                    hind += 1
                    tld = prefix +'Host.%s.' %  hind
                    c[tld + 'Layer2Interface'] = layer2name
                    c[tld + 'IPAddress'] = IP
                    c[tld + 'InterfaceType'] = 'Ethernet'
                    c[tld + 'Active'] = False
                    c[tld + 'AddressSource'] = 'DHCP'
                    c[tld + 'LeaseTimeRemaining'] = 0
                    mac = row.split()[1][-15:].replace('.', '')
                    c[tld + 'MACAddress'] = str(EUI(mac)).replace('-', ':')
                    try:
                        hn = 'Org: ' + EUI(mac).info.OUI.org.replace(' ','')
                    except:
                        hn = 'Unknown'
                    c[tld + 'HostName'] = hn

        if ifn == 'Dot11Radio0':
            wlan_hosts = depends('show dot11 associations', t)
            """
            802.11 Client Stations on Dot11Radio0:

            SSID [Cisco877] :

            IP address      Device        Name            Parent         State
            10.x.x.65      ccx-client    -               self           Assoc
            10.x.x.225     ccx-client    -               self           Assoc
            10.x.x.239     4800-radio    abc123          self           Assoc
            10.x.x.127     4800-radio    abc123          self           Assoc

            r-05513058904#
            """

            associated_hosts = []
            if 'State' in wlan_hosts:
                associated_hosts = wlan_hosts.split('State')[1].split('\n')

            for hosts in associated_hosts:
                device = hosts.split()
                if device and len(device) == 5:
                    hind += 1
                    tld = prefix +'Host.%s.' % hind
                    c[tld + 'Layer2Interface'] = layer2name
                    c[tld + 'IPAddress'] = device[0]
                    c[tld + 'InterfaceType'] = 'WLAN'
                    c[tld + 'Active'] = True
                    address_source = 'Static'
                    lease_time_remaining = 0
                    c[tld + 'AddressSource'] = address_source
                    c[tld + 'LeaseTimeRemaining'] = lease_time_remaining
                    c[tld + 'MACAddress'] = device[1]
                    c[tld + 'HostName'] = device[2]

        c[prefix + 'HostNumberOfEntries'] = hind


    # ------------------- TR-181
    def GPV_Ethernet(self, t):
        depends('build_dev2_ifs', t)


    def GPV_IP(self, t):
        depends('build_dev2_ifs', t)

    def GPV_DHCPv4_Server(self, t):
        c = t.session_cache
        depends('show_ip_int', t)
        depends('build_dev2_ifs', t)
        run = depends('show_run', t)
        nfos, ifs = c['nfos'], c['ifs']
        pools = self.parse_dhcp(t)
        index = 0
        c['.DHCPv4Server.Enable'] = False
        for name, pool in pools.items():
            m = pool
            c['.DHCPv4Server.Enable'] = True
            index += 1
            tr = '.DHCPv4Server.Pool.%s.' % index
            c[tr + 'Alias'] = 'cpe-%s' % name
            # FIXME - check
            c[tr + 'Enable']     = True
            put(c, tr, 'DomainName', m, 'DomainName')
            put(c, tr, 'DNSServers', m, 'DNSServers')
            put(c, tr, 'IPRouters' , m, 'IPRouters' )
            put(c, tr, 'MinAddress', m, 'MinAddress')
            put(c, tr, 'MaxAddress', m, 'MaxAddress')
            put(c, tr, 'SubnetMask', m, 'SubnetMask')
            put(c, tr, 'LeaseTime' , m, 'DHCPLeaseTime')
            # find the interface:
            for i in xrange(1, 100):
                try:
                    ip = c['.IP.Interface.%s.IPv4Address.1.IPAddress'  % i]
                    if self.ip_in_pool(IP(ip), pool):
                        c[tr + 'Interface'] = 'IP.Interface.%s' % i

                except:
                    break

        c['.DHCPv4Server.PoolNumberOfEntries'] = index


    def build_if_stack(self, t):
        """
        {'ATM': ['ATM0', 'ATM0.1'],
        'Dialer': [],
        'Dot11Radio': ['Dot11Radio0', 'Dot11Radi
        'FastEthernet': ['FastEthernet0',
                        'FastEthernet1',
                        'FastEthernet2',
                        'FastEthernet3'],
        'Serial': [],
        'Tunnel': [],
        'Virtual-Access': [],
        'Vlan': ['Vlan1']}
        """
        # we have DSL.Line.1
        # Ethernet.Interface.1
        # X_Axiros_Com_Cisco

        c = t.session_cache
        depends('show_ip_int', t)
        nfos, ifs = c['nfos'], c['ifs']
        run = depends('show_run', t)
        import pdb; pdb.set_trace()
        eth_ifs = []
        bridges = []
        eth_links = []
        ip_ifs = []
        stack = {'EthernetInterfaces': eth_ifs,
                 'Bridges': bridges,
                 'EthernetLinks': eth_links,
                 'IPInterfaces': ip_ifs
                 }
        for iface in nfos:
            if 'Ethernet' in iface:
                upper = []
                m = {'name': iface,'up': upper}
                eth_ifs.append(m)

                i_cfg = self.parse_run_block(iface, run)
                if not i_cfg.strip():
                    # this is just configured, nothing on it:
                    continue
                for line in i_cfg.splitlines():
                    if 'switchport' in line and ' vlan' in line:
                        vlan = 'Vlan' + line.rsplit(' vlan', 1)[1]
                        inserted = 0
                        for b in bridges:
                            if b['name'] == vlan:
                                # insert a bridge port to that one:
                                b_down_ports = b['down']
                                nr = len(b_down_ports) + 1
                                b_down_ports.append(nr)
                                upper.append(nr)
                                inserted = 1
                                break
                        if not inserted:
                            # create new one:
                            nr = len(bridges) + 1
                            ip_ifs.append({'name': vlan, 'down': len(eth_links) + 1})
                            eth_links.append({'down': nr, 'up': len(ip_ifs), 'name': vlan})
                            bridges.append({'name': vlan, 'up': len(eth_links), 'down': [2]})
                            upper.append(nr)



        import pdb; pdb.set_trace()





    def build_dev2_ifs(self, t):
        c = t.session_cache
        # don't run show run
        depends('show_ip_int', t)
        # first the FastEthernets:
        nfos, ifs = c['nfos'], c['ifs']
        links = {}
        # save in sessionmap:
        c['links'] = links

        index = 0
        for iface in ifs['FastEthernet']:
            m = nfos[iface]
            index += 1
            tr = '.Ethernet.Interface.%s.' % index
            # keep a ref to the model:
            m['tr181'] = tr
            # no bridging here, we do 1:1:
            self.add_link(links, iface, tr)

            c[tr + 'Alias']      = 'cpe-%s' % iface

            put(c, tr, 'DuplexMode',  m, 'Duplex', deflt='Auto')
            put(c, tr, 'Enable',      m,           deflt='Auto')
            put(c, tr, 'MACAddress',  m, 'MAC',    deflt='')

            status = 'Down'
            if m.get('Status', 0) == 1:
                status = 'Up'
            c[tr + 'Status'] = status

            speed = m.get('Speed', 'Auto')
            if 'auto' in str(speed).lower():
                speed = -1
            c[tr + 'MaxBitRate'] = speed
            c[tr + 'Name']       = iface
            c[tr + 'Upstream'] = self.is_upstream(m, c)
            self.set_stats(c, tr, m)
        c['.Ethernet.InterfaceNumberOfEntries'] = index

        # links. for now we build links 1:1 to ifs:
        index = 0
        for link, m in links.items():
            index += 1
            tr = '.Ethernet.Link.%s.' % index
            m['tr181'] = tr
            low_lay = m['lower_layers']
            c[tr + 'LowerLayers'] = ','.join(low_lay)
            if len(low_lay) == 1:
                # if just one we take the stats from the lower layer:
                ll = '.' + low_lay[0] + '.'
                for k in c:
                    if k.startswith(ll):
                        postfix = k.split(ll, 1)[1]
                        m[tr + postfix] = c.get(k)
                c.update(m)
        c['.Ethernet.LinkNumberOfEntries'] = index

        # vlans - we use for now VlanTermination table, not bridge.
        if ifs.get('Vlan'):
            shvl = t.get('show vlan-switch brief')
            vlans = {}
            for vlan in ifs.get('Vlan'):
                # vlan like 'Vlan1'
                vnr = vlan.split('Vlan', 1)[1]
                ena = True
                try:
                    vnfos = shvl.split('\n%s ' % vnr)[1].split()
                except:
                    # the vlan is in show interfaces but not in here.
                    # use Enable = False
                    ena = False
                    vnfos = ['', 'Down']
                descr  = vnfos[0]
                status = vnfos[1]
                ifaces = []
                for iface in vnfos[2:]:
                    if iface.endswith(','):
                        iface = iface[:-1]
                    iface = iface.replace('Fa', 'FastEthernet')
                    if iface.isdigit() or iface.endswith('#'):
                        break # next vlan nr
                    ifaces.append(iface)
                vlans[vnr] = {'name'  : vlan,
                              'ena'   : ena,
                              'descr' : descr,
                              'status': status,
                              'ifaces': ifaces}
            index = 0
            for vlan_nr, m in vlans.items():
                index += 1
                tr = '.Ethernet.VLANTermination.%s.' % index
                name, status, ifaces = (m.get('name'),
                                        m.get('status'),
                                        m.get('ifaces'))

                nfos_map = nfos.get(name)
                nfos_map['tr181'] = tr
                c[tr + 'Alias']   = 'cpe-%s' % name
                nr = name.split('Vlan')[1]
                # like voce, or internet, don't see a better key than name:
                descr = m.get('descr')
                if not descr:
                    descr = nr
                c[tr + 'Name']    = nr
                c[tr + 'VLANID']  = nr
                c[tr + 'Enable']  = m.get('ena')
                statu = 'Down'
                if status == 'active':
                    statu = 'Up'
                c[tr + 'Status']  = statu

                self.set_stats(c, tr, nfos_map)
                low_lay = ''
                for iface in ifaces:
                    try:
                        low_lay += '%s,' % links.get(iface)['tr181'][1:-1]
                    except:
                        pass
                low_lay = low_lay[:-1]
                c[tr + 'LowerLayers'] = low_lay

        c['.Ethernet.VLANTerminationNumberOfEntries'] = index


        # ip interfaces:
        # we just parse ip int brief:
        index = 0
        ip_brief   = depends('show ip int brief', t)
        for line in ip_brief.splitlines():
            infos = line.split()
            try:
                ip = IP(infos[1])
                name = infos[0]
                m  = nfos[name]
            except:
                # either not an IP there or not parsed iface type
                continue
            index += 1
            tr = '.IP.Interface.%s.' % index
            c[tr + 'IPv4Address.1.Enable']       = True
            c[tr + 'IPv4Address.1.IPAddress']    = str(ip)
            c[tr + 'Name']                       = name
            c[tr + 'Enable']                     = m['Enable']
            c[tr + 'Alias']                      = 'cpe-%s'%  name
            c[tr + 'IPv4Address.1.Alias']        = 'cpe-%s-IP1' % name
            c[tr + 'IPv4Address.1.Status']       = 'Enabled'
            c[tr + 'IPv4Address.1.SubnetMask']   = 'Netmask'
            c[tr + 'IPv4AddressNumberOfEntries'] = 1
            c[tr + 'Loopback']                   = False
            c[tr + 'LowerLayers']                = m.get('tr181', '')
            put(c, tr, 'MaxMTUSize', m, 'mtu')

            status = 'Down'
            if m.get('Status', 0) == 1:
                status = 'Up'
            c[tr + 'Status'] = status
            self.set_stats(c, tr, m)

            if_type = 'Normal'
            if name.startswith('Tunnel'):
                if_type = 'Tunnel'
                # Tunneled ?
            c[tr + 'Type'] = if_type

        c['.IP.InterfaceNumberOfEntries'] = index
        return 1





    def add_link(self, links, link_name, lower_tr):
        link_map = links.get(link_name)
        if not link_map:
            links[link_name]= {'lower_layers': []}
            link_map = links[link_name]
            # no dots left and right:
            link_map['lower_layers'].append(lower_tr[1:-1])


    def set_stats(self, c, tr, m, if_type=None):
        tr = tr + 'Stats.'
        put(c, tr, 'BytesSent', m, 'tx_bytes')
        put(c, tr, 'BytesReceived', m, 'rx_bytes')
        put(c, tr, 'PacketsSent', m, 'tx_packets')
        put(c, tr, 'PacketsReceived', m, 'rx_packets')
        put(c, tr, 'ErrorsSent', m, 'tx_errors')
        put(c, tr, 'ErrorsReceived', m, 'rx_errors')
        put(c, tr, 'DiscardPacketsSent', m, 'tx_dropped')
        put(c, tr, 'DiscardPacketsReceived', m, 'rx_dropped')
        put(c, tr, 'BroadcastPacketsReceived', m, 'rx_broadcasts')
        put(c, tr, 'BroadcastPacketsSent', m, 'tx_broadcasts')
        c[tr + 'MulticastPacketsReceived'] = 0
        c[tr + 'MulticastPacketsSent'] = 0
        packets = 'Packets'
        if if_type == 'Dot11Radio':
            packets = 'TotalPackets'
        try:
            c[tr + 'UnicastPacketsSent'] = \
                    c[tr + packets + 'Sent'] - \
                    c[tr + 'BroadcastPacketsSent']
        except:
            pass
        try:
            c[tr + 'UnicastPacketsReceived'] = \
                    c[tr + packets + 'Received'] - \
                    c[tr + 'BroadcastPacketsReceived']
        except:
            pass
        put(c, tr, 'UnknownProtoPacketsReceived', m, 'ignored')
        put(c, tr, 'DiscardPacketsReceived', m)
        put(c, tr, 'DiscardPacketsSent', m)






    def is_upstream(self, m, c):
        """ if the name of the IF is in def_gw_if or the gw ip is in th network
        we say this is Upstream """
        if m.get('Name', 'xx') in c['def_gw_if']:
            return True
        ip, mask = m.get('IP'), m.get('Netmask')
        if not ip or not mask:
            return False
        gw = c.get('def_gw_ip')
        if not gw or gw == 'n.a.':
            return False
        if IP(gw) in IPNetwork('%s/%s' % (ip, mask)):
            return True
        return False

    def parse_default_gw(self, c, def_route):
        c['def_gw_ip'] = get_line_val(def_route.lower(), 'default gateway is ')
        c['def_gw_if'] = get_line_val(def_route, 'directly connected, via ')









    def show_ip_int(self, t):
        """
        Main interfaces parser.
        Build a map(nfos) of Iface names versus their properties.
        Then build the TR params out of it.

        """
        c = t.session_cache
        # we will split below, delete the space in the column:
        # simul:

        interfaces = depends('show interface', t)
        def_route  = depends('show ip route 0.0.0.0', t)
        ip_brief   = depends('show ip int brief', t)

        self.parse_default_gw(c, def_route)
        # ip int | inc line | Internet address')

        ifs = {
            'ATM':            [],
            'Dialer':         [],
            'Vlan':           [],
            'Tunnel':         [],
            'Dot11Radio':     [],
            'FastEthernet':   [],
            'Virtual-Access': [],
            'Serial'        : []
              }
        nfos = {}

        # first parse results into mappings:
        #import pdb; pdb.set_trace()
        valid = False
        if_name = "";
        for line in lines(interfaces):
            #search for interface information
            if not line.startswith(' ') and line.strip():
                valid = False
                if_name = line.split(' ', 1)[0]
                # check if name is valid:
                for if_type in ifs:
                    if line.startswith(if_type):
                        valid = True
                        ifs[if_type].append(if_name)
                        if_map = {'Name': if_name,
                                  'Duplex': 'Auto',
                                  'Speed': 'Auto'}
                        nfos[if_name] = if_map
                        if_map['Status'] = 1
                        if_map['Enable'] = True
                        if 'down' in line:
                            if_map['Status'] = 0
                            if 'administratively down' in line:
                                if_map['Enable'] = False
                        break

                continue
            elif valid:  # interface found
                line = line.strip().lower()
                #print line, "-" * 100
                if line.startswith('internet address is '):
                    ip = IPNetwork(line.rsplit(' ', 1)[1])
                    if_map['IP'], if_map['Netmask'] = str(ip.ip), str(ip.netmask)
                elif 'uplex' in line:
                    if 'half' in line:
                        if_map['Duplex'] = 'Half'
                    else:
                        if_map['Duplex'] = 'Full'
                    if_map['Speed'] = get_line_val(line, ' ', sep='mb/s', get=0)
                elif 'mtu ' in line and ' bw ' in line:

                    try:
                        if_map['mtu'] = int(line.split('mtu ', 1)[1].split(' ')[0])
                        if_map['bw_kb'] = int(line.split(' kbit/sec')[0].\
                                rsplit(' ', 1)[1])
                    except:
                        if_map['bw_kb'] = 0

                elif line.startswith('hardware is'):
                    if line.find("address is "):
                        # if this is a real IF we have the mac in this line:
                        try:
                          if_map['MAC'] = str(EUI(get_line_val(line,
                            'address is ',
                            sep=' ',
                            get=0))).replace('-', ':')
                        except AddrFormatError as ex:
                            if_map['MAC'] = ''
                elif line.find('packets input,') > 0:
                    stat = line.split()
                    if_map['rx_bytes'] = int(stat[3])
                    if_map['rx_packets'] = int(stat[0])
                elif ' broadcasts,' in line and 'received ' in line:
                    stat = line.split()
                    if_map['rx_broadcasts'] = int(stat[1])
                    # no info:
                    if_map['tx_broadcasts'] = 0
                elif 'maximum active vcs,' in line:
                    stat = line.split()
                    if_map['max_vcs'] = int(stat[0])
                    if_map['cur_vcs'] = int(stat[-3])
                elif line.find('packets output,') > 0:
                    stat = line.split()
                    if_map['tx_bytes'] = int(stat[3])
                    if_map['tx_packets'] = int(stat[0])
                elif line.find('input errors') > 0:
                    stat = line.split()
                    if_map['rx_errors'] = int(stat[0])
                    if_map['ignored'] = int(stat[-2])
                elif line.find('output errors') > 0:
                    stat = line.split()
                    if_map['tx_errors'] = int(stat[0])

                elif 'input queue' in line:
                    stat = line.split()
                    # 0/75/0/0 (size/max/drops/flushes):
                    smdf = stat[2].split('/')[2]
                    if_map['DiscardPacketsReceived'] = int(smdf)
                    if_map['DiscardPacketsSent'] = int(stat[-1])
                elif 'encapsulation' in line:
                    if_map['Encapsulation'] = line.split()[1]


            else:
                pass


        run = depends('show_run', t)
        arp = depends('show arp', t)

        # - ethx : LAN interfaces (x != WAN_MAP)
        # - lo: not modelled
        # O.I - store index counters in cache ?
        #import pdb; pdb.set_trace()
        noIPIF = 0
        noWANDEV = 0
        noWANIPCON = 0
        noLANDEV = 0
        noLANETH = 0
        c['.WANDeviceNumberOfEntries'] = noWANDEV
        c['.LANDeviceNumberOfEntries'] = noLANDEV
        for if_type, if_names in ifs.items():
            for if_name in if_names:
                if_map = nfos[if_name]
                tr_node = None
                index = if_names.index(if_name) + 1
                m = if_map
                # test for WAN interfaces
                if 'Serial' in if_name and not if_name.endswith('.1'):
                    comp = {}
                    comp.update(if_map)
                    try:
                       comp.update(nfos[if_name + '.1'])
                    except:
                        pass
                    # create WAN model
                    noWANDEV += 1
                    c['.WANDeviceNumberOfEntries'] = noWANDEV
                    c['.WANConnectionNumberOfEntries'] = noWANDEV
                    twan = '.WANDevice.%d.WANCommonInterfaceConfig.' % noWANDEV
                    c[twan + 'EnabledForInternet'] = '1'
                    c[twan + 'WANAccessType'] = comp.get('Encapsulation', 'n.a.')
                    bwdown = if_map.get('bw_kb', 0)
                    if bwdown == 1024:
                        bwup = 128
                    else:
                        bwup = 0
                    c[twan + 'Layer1DownstreamMaxBitRate'] = bwdown
                    c[twan + 'Layer1UptreamMaxBitRate'] = bwup

                    if if_map['Status'] == 1:
                        c[twan + 'PhysicalLinkStatus'] = "Up"
                    else:
                        c[twan + 'PhysicalLinkStatus'] = "Down"
                    put(c, twan, 'MaximumActiveConnections', m, 'max_vcs')
                    put(c, twan, 'NumberOfActiveConnections', m, 'cur_vcs')


                    put(c, twan, 'TotalBytesSent', m, 'tx_bytes')
                    put(c, twan, 'TotalPacketsSent', m, 'tx_packets')
                    put(c, twan, 'TotalBytesReceived', m, 'rx_bytes')
                    put(c, twan, 'TotalPacketsReceived', m, 'tx_bytes')



                if 'ATM' in if_name and not if_name.endswith('.1'):
                    # create WAN model
                    noWANDEV += 1
                    c['.WANDeviceNumberOfEntries'] = noWANDEV
                    c['.WANConnectionNumberOfEntries'] = noWANDEV
                    twan = '.WANDevice.%d.WANCommonInterfaceConfig.' % noWANDEV
                    c[twan + 'EnabledForInternet'] = '1'
                    c[twan + 'WANAccessType'] = 'DSL'
                    bwdown = if_map.get('bw_kb', 0)
                    if bwdown == 1024:
                        bwup = 128
                    else:
                        bwup = 0
                    c[twan + 'Layer1DownstreamMaxBitRate'] = bwdown
                    c[twan + 'Layer1UptreamMaxBitRate'] = bwup

                    if if_map['Status'] == 1:
                        c[twan + 'PhysicalLinkStatus'] = "Up"
                    else:
                        c[twan + 'PhysicalLinkStatus'] = "Down"
                    put(c, twan, 'MaximumActiveConnections', m, 'max_vcs')
                    put(c, twan, 'NumberOfActiveConnections', m, 'cur_vcs')


                    put(c, twan, 'TotalBytesSent', m, 'tx_bytes')
                    put(c, twan, 'TotalPacketsSent', m, 'tx_packets')
                    put(c, twan, 'TotalBytesReceived', m, 'rx_bytes')
                    put(c, twan, 'TotalPacketsReceived', m, 'tx_bytes')

                    #wan_device = '.WANDevice.%d.' % noWANDEV

                    twan = twan.replace('.WANCommonInterfaceConfig.',
                                        '.WANDSLInterfaceConfig.')


                    if if_map['Status'] == 0:
                        c[twan + 'Enable'] = False
                        c[twan + 'ConnectionStatus'] = "NoSignal"
                    else:
                        c[twan + 'Enable'] = True
                        c[twan + 'ConnectionStatus'] = "Up"



                    # ATM/0/0 and ATM/0/0.1
                    base_run_block = self.parse_run_block(if_name, run)
                    run_block01 = self.parse_run_block(if_name+'.1', run)

                    #dsl operating-mode itu-dmt
                    try:
                        encoding = base_run_block.split('dsl operating-mode ', 1)\
                            .split('\n')[0]
                        if '-' in encoding:
                            encoding = encoding.rsplit('-', 1)[1]
                    except:
                        encoding = ''
                    if nfos[if_name].get('Enable'):

                        c[twan + 'LineEncoding'] = encoding.upper()
                        # no idea:
                        c[twan + 'AllowedProfiles'] = ''
                        c[twan + 'CurrentProfile'] = ''
                        atm_det = depends('show atm interface %s' % if_name, t)
                        try:
                            data_path = atm_det.split(' OUT ')[1].split('\n')[0].strip()
                            if 'fastVBR-NRT' in data_path:
                                data_path = 'interleave'
                        except:
                            data_path = 'fast'
                        c[twan + 'DataPath'] = data_path.capitalize()
                        dsl_infos = depends('show dsl interface %s' % if_name, t)
                        modem_status = get_line_val(dsl_infos, 'Modem Status:')
                        if "Down" in modem_status:
                            c[twan + 'Status']  = 'Disabled'
                        else:
                            c[twan + 'Status']  = 'Up'
                            noise =  get_line_val(dsl_infos, 'Noise Margin:').split()
                            c[twan + 'UpstreamNoiseMargin'] = float(noise[2])
                            c[twan + 'DownstreamNoiseMargin'] = float(noise[0])
                            attn =  get_line_val(dsl_infos, 'Attenuation:').split()
                            c[twan + 'UpstreamAttenuation'] = float(attn[2])
                            c[twan + 'DownstreamAttenuation'] = float(attn[0])
                            powe =  get_line_val(dsl_infos, 'Output Power:').split()
                            c[twan + 'UpstreamPower'] = float(powe[2])
                            c[twan + 'DownstreamPower'] = float(powe[0])
                            c[twan + 'TotalStart'] = 0
                            c[twan + 'ShowtimeStart'] = 0

                            speed =  get_line_val(dsl_infos, 'Speed (kbps):').split()
                            if "fast" in data_path:
                                c[twan + 'UpstreamCurrRate'] = speed[2]
                                c[twan + 'DownstreamCurrRate'] = speed[0]
                            else:
                                c[twan + 'UpstreamCurrRate'] = speed[3]
                                c[twan + 'DownstreamCurrRate'] = speed[1]

                            twan += 'Stats.Total.'
                            c[twan + 'ReceiveBlocks'] = 0
                            c[twan + 'TransmitBlocks'] = 0
                            c[twan + 'CellDelin'] = 0
                            c[twan + 'LinkRetrain'] = 0
                            c[twan + 'InitErrors'] = 0
                            c[twan + 'InitTimeouts'] = 0
                            c[twan + 'LossOfFraming'] = 0
                            c[twan + 'LOF'] = 0
                            c[twan + 'ErroredSecs'] = 0
                            c[twan + 'SeverelyErroredSecs'] = 0
                            c[twan + 'FECErrors'] = 0
                            c[twan + 'ATUCFECErrors'] = 0
                            c[twan + 'HECErrors'] = 0
                            c[twan + 'ATUCHECErrors'] = 0
                            crc =  get_line_val(dsl_infos, 'CRC Errors:').split()
                            c[twan + 'CRCErrors'] = int(crc[0])
                            c[twan + 'ATUCCRCErrors'] = 0





                elif if_type == 'Dialer':
                    noWANIPCON += 1
                    tr = '.WANDevice.1.WANConnectionDevice.%s.' % noWANIPCON
                    c[tr + 'WANIPConnectionNumberOfEntries'] = noWANIPCON
                    tr += 'WANIPConnection.'
                    if m['Status'] == 1:
                        c[tr + 'Enable'] = True
                        c[tr + 'ConnectionStatus'] = 'Connected'
                    else:
                        c[tr + 'Enable'] = False
                        c[tr + 'ConnectionStatus'] = 'Disconnected'

                    c[tr + 'PossibleConnectionTypes'] = 'Unconfigured, IP_Routed, IP_Bridged'
                    c[tr + 'ConnectionType'] = 'IP_Routed'
                    c[tr + 'Name'] = if_name
                    c[tr + 'Uptime'] = 0
                    c[tr + 'NATEnabled'] = True
                    block = self.parse_run_block(if_name, run)
                    if 'negotiated' in block:
                        c[tr + 'AddressingType'] = 'DHCP'
                    else:
                        c[tr + 'AddressingType'] = 'Static'
                    c[tr + 'ExternalIPAddress'] = m['IP']
                    c[tr + 'SubnetMask'] = m['Netmask']
                    c[tr + 'DefaultGateway'] = '0.0.0.0'
                    dns = depends('show ip dns view', t)
                    ds = dns.split('Domain name-servers:', 1)[1].split('\n')
                    ds = ds[1].strip()
                    c[tr + 'DNSServers'] = ds
                    c[tr + 'MTU'] = m.get('mtu', 0)
                    c[tr + 'MACAddress'] = ''

                    c[tr + 'PortMappingNumberOfEntries'] = "0"
                    c[tr + 'PortMapping'] = ''

                    tr += 'Stats.'
                    put(c, tr, 'EthernetBytesSent', m, 'tx_bytes')
                    put(c, tr, 'EthernetBytesReceived', m, 'rx_bytes')
                    put(c, tr, 'EthernetPacketsSent', m, 'tx_packets')
                    put(c, tr, 'EthernetPacketsReceived', m, 'rx_packets')
                    put(c, tr, 'EthernetErrorsSent', m, 'tx_errors')
                    put(c, tr, 'EthernetErrorsReceived', m, 'rx_errors')
                    put(c, tr, 'EthernetDiscardPacketsSent', m, 'tx_dropped')
                    put(c, tr, 'EthernetDiscardPacketsReceived', m, 'rx_dropped')
                    if 'tx_bytes' in m:
                        c[tr + 'TotalBytesSent'] = int(m['tx_bytes'])
                        c[tr + 'TotalBytesReceived'] = int(m['rx_bytes'])
                        c[tr + 'TotalPacketsSent'] = int(m['tx_packets'])
                        c[tr + 'TotalPacketsReceived'] = int(m['rx_packets'])

                elif if_type == 'FastEthernet' or (if_type == 'Dot11Radio' and \
                                                   not if_name.endswith('.1')):
                    #if if_type == 'Dot11Radio':
                    # create LAN interfaces model
                    k = if_name.split(':')
                    if not k[1:2]:
                        # create new LANDevice
                        noLANDEV += 1
                        c['.LANDeviceNumberOfEntries'] = noLANDEV
                        noLANETH = 0
                        tld = '.LANDevice.%d.' % noLANDEV
                        if if_type == 'Dot11Radio':
                            c[tld + 'LANWLANConfigurationNumberOfEntries'] = 1
                        else:
                            c[tld + 'LANWLANConfigurationNumberOfEntries'] = 0
                    # create new LANEthernetInterfaceConfig
                    noLANETH += 1
                    if if_type == 'Dot11Radio':
                        c[tld + 'LANHostConfigManagement.IPInterface.1.' +  \
                                'IPInterfaceIPAddress'] = if_map.get('IP',
                                    nfos.get(if_name + '.1', {}).get('IP', ''))
                        c[tld + 'LANWLANConfigurationNumberOfEntries'] = noLANETH
                        tr = tld + 'WLANConfiguration.%d.' % noLANETH
                    else:
                        c[tld + 'LANHostConfigManagement.IPInterface.1.' +  \
                                'IPInterfaceIPAddress'] = if_map.get('IP','')
                        c[tld + 'LANEthernetInterfaceNumberOfEntries'] = noLANETH
                        tr = tld + 'LANEthernetInterfaceConfig.%d.' % noLANETH

                    if if_map['Status'] == 1:
                        c[tr + 'Status'] = "Up"
                    else:
                        c[tr + 'Status'] = "Disabled"

                    c[tr + 'Enable'] = if_map['Enable']
                    #put(c, tr, 'LastChange', m, 'status_changed')
                    if if_type != 'Dot11Radio':
                        put(c, tr, 'MACAddress', m, 'MAC')
                        put(c, tr, 'DuplexMode', m, 'Duplex')
                        put(c, tr, 'MaxBitRate', m, 'Speed')
                    else:
                        # add some wlan specific parameters
                        chan = get_line_val(run, 'channel').split()
                        if not chan[0]:
                            c[tr +'Channel'] = 0
                        else:
                            wlan_controler = depends('show controller dot11 0',
                                                      t)
                            freq = get_line_val(wlan_controler,
                                    'Current Frequency:').split()
                            c[tr +'Channel'] = freq[3]

                        # PreSharedKey is static as according to TR69
                        # it will return nothing at GPV
                        c[tr + 'PreSharedKey.1.PreSharedKey'] = ''

                        mac = get_line_val(wlan_controler,
                                           'Base Address').split()
                        macadr = mac[0].replace(":", "").replace("-",
                                            "").replace(".", "").upper()
                        bssid = macadr[:2] + ":" + ":".join([macadr[i] + \
                                        macadr[i+1] for i in range(2,12,2)])
                        c[tr +'BSSID'] = bssid

                        enc = get_line_val(run,
                                'authentication key-management').split()
                        if 'wpa' in enc:
                            c[tr +'BeaconType'] = '11i'
                            wpapsk = get_line_val(run, 'wpa-psk').split()
                            if wpapsk:
                                c[tr +'IEEE11iAuthenticationMode'] = \
                                        'PSKAuthentication'
                                c[tr +'WPAAuthenticationMode'] = \
                                        'PSKAuthentication'

                        # wifi enc check:
                        buf = self.parse_run_block('nterface %s' % if_name, run)
                        c[tr + 'SSID']       = get_line_val(buf, 'ssid ')
                        speed                = get_line_val(buf, 'speed')
                        c[tr + 'MaxBitRate'] = '%s Mbps' % speed.rsplit()[-1]
                        ciphers              = get_line_val(buf, 'mode ciphers')
                        trwenc               = tr +'WPAEncryptionModes'
                        if 'aes-ccm' in ciphers:
                            if 'tkip' in ciphers:
                                c[trwenc] = 'TKIPandAESEncryption'
                            else:
                                c[trwenc] = 'AESEncryption'
                        elif 'tkip' in ciphers:
                            c[trwenc] = 'TKIPEncryption'
                        elif 'wep128' in ciphers or 'wep40' in ciphers:
                            c[tr +'BasicEncryptionModes'] = 'WEPEncryption'


                    c[tr + 'Name'] = if_name
                    self.lan_hosts(t, tld, if_name, ip_brief, arp, tr)
                    if 'tx_bytes' in m:
                        tr += 'Stats.'
                        if if_type == 'Dot11Radio':
                            tr = tr.replace('Stats.', '')
                            put(c, tr, 'TotalBytesSent', m, 'tx_bytes')
                            put(c, tr, 'TotalBytesReceived', m, 'rx_bytes')
                            put(c, tr, 'TotalPacketsSent', m, 'tx_packets')
                            put(c, tr, 'TotalPacketsReceived', m, 'rx_packets')
                            tr += 'Stats.'
                        else:
                            put(c, tr, 'BytesSent', m, 'tx_bytes')
                            put(c, tr, 'BytesReceived', m, 'rx_bytes')
                            put(c, tr, 'PacketsSent', m, 'tx_packets')
                            put(c, tr, 'PacketsReceived', m, 'rx_packets')
                        put(c, tr, 'ErrorsSent', m, 'tx_errors')
                        put(c, tr, 'ErrorsReceived', m, 'rx_errors')
                        put(c, tr, 'DiscardPacketsSent', m, 'tx_dropped')
                        put(c, tr, 'DiscardPacketsReceived', m, 'rx_dropped')
                        put(c, tr, 'BroadcastPacketsReceived', m, 'rx_broadcasts')
                        put(c, tr, 'BroadcastPacketsSent', m, 'tx_broadcasts')
                        c[tr + 'MulticastPacketsReceived'] = 0
                        c[tr + 'MulticastPacketsSent'] = 0
                        packets = 'Packets'
                        if if_type == 'Dot11Radio':
                            packets = 'TotalPackets'
                        try:
                            c[tr + 'UnicastPacketsSent'] = \
                                    c[tr + packets + 'Sent'] - \
                                    c[tr + 'BroadcastPacketsSent']
                        except:
                            pass
                        try:
                            c[tr + 'UnicastPacketsReceived'] = \
                                    c[tr + packets + 'Received'] - \
                                    c[tr + 'BroadcastPacketsReceived']
                        except:
                            pass
                        put(c, tr, 'UnknownProtoPacketsReceived', m, 'ignored')
                        put(c, tr, 'DiscardPacketsReceived', m)
                        put(c, tr, 'DiscardPacketsSent', m)


                if tr_node:
                    # remember the node with indizes:
                    nfos[if_name]['tr_index'] = index


        c['ifs']  = ifs
        c['nfos'] = nfos


        return [ifs, nfos, ip_brief, arp]

# -----------  Setter Methods:

    setters = {'ip_setup': ['.IP.Interface', '']}
    error_markers = ['Bad ', 'nvalid ', ' ncomplete ']
    exit_context = ['exit', 'end']


    def commit_on_close(self, t):
        # this takes long, do it only on close:
        t.get('copy running-config startup-config', timeout=10)

    def set_interface(self, iface, ip, netmask):
        import pdb; pdb.set_trace()

    def SPV_IFSetup(self, t):
        # all SPV params:
        c = t.session_cache
        params = c['to_set_params']
        # get state:
        ifs, nfos, ip_brief, arp = depends('show_ip_int', t)

        # configure:
        t.get('conf t')

        # stringify SPV map:
        s_params = str(params)

        # check all ifs which are found (i.e. in c):
        for index in indizes(LD + 'LANEthernetInterfaceConfig.', c):
            if_node = LD + 'LANEthernetInterfaceConfig.%s.' % index
            ip_node = LD + 'LANHostConfigManagement.IPInterface.%s.' % index

            if_name = c.get(if_node + 'Name')
            if not if_name or not (if_node in s_params or ip_node in s_params):
                # iface not there or nothing to change on this one:
                continue

            t.get('interface %s' % if_name)
            # enable?
            key = if_node + 'Enable'
            v = params.get(key)
            set_map = {'c': cache,
                       't': t,
                       'error_markers' : self.error_markers,
                       'ctx_exit': self.exit_context
                       }

            if v != None:
                # enable param set to a value. run the cmd:
                set_map['affects_params'] = key
                if str(v) == '1':
                    set_map['flow'] = 'no shutdown'
                else:
                    set_map['flow'] = 'shutdown'
                set_flow(set_map)

            # ip setup with ip address and netmask?
            ip_key =  ip_node + 'IPInterfaceIPAddress'
            net_key = ip_node + 'IPInterfaceSubnetMask'

            if ip_key in s_params or net_key in s_params:
                ip  = params.get(ip_key,  nfos[if_name]['IP'])
                net = params.get(net_key, nfos[if_name]['Netmask'])
                set_map['affects_params'] = (ip_key, net_key)
                set_map['flow'] = 'ip address %s %s' % (ip, net)
                set_flow(set_map)

            # next iface, or exit on error:
            t.get('exit')

        # back to show mode:
        t.get('end')



# -----------  Upload and Download Support:


    def do_http_cfg_upload(self, t, url, *args, **kwargs):
        res = t.get('copy run %s' % url, condition='?')
        res = t.get('', condition='?')
        res = t.get('', timeout=10)
        if 'Error' in res:
            err = get_error_line(str(res), 'Error')
            raise Exception(err)
    do_tftp_cfg_upload = do_http_cfg_upload


    def do_http_cfg_download(self, t, url, file_name, file_size,*args,**kwargs):
        if not file_name:
            file_name = 'running-config'
        else:
            t.get('delete flash:%s' % file_name, condition='?')
            t.get('', condition='onfirm]')
            t.get('')

        res = t.get('copy %s %s' % (url, file_name), condition='?')
        if 'Error' in res:
            raise Exception(get_error_line(str(res), 'Error'))
        if file_name == 'running-config':
            res = t.get('', timeout=10)
            if 'copied' in res:
                # apply it:
                t.get('copy running-config startup-config', condition='?')
                t.get('', timeout=30)
                return
            raise Exception(str(res), 'Error')

        res = t.get('', condition='?', timeout=10)
        if 'Error' in res:
            raise Exception(get_error_line(str(res), 'Error'))
        if 'Erase flash' in res:
            res = t.get('n', timeout=10)
        if 'copied' in res:
            return
        raise Exception(str(res), 'Error')
    do_tftp_cfg_download = do_http_cfg_download




# -----------  Supported TR-069 RPCs:


    def SetParameterValues(self, params, t):
        # use the default handler:
        return handle_SPV(params, t)


    def GetParameterNames(self, params, t):
        # use the default handler:
        return handle_GPN(params, t)


    def Reboot(self, params, t):
        # we save the running config before reboot:
        res = t.get('reload', condition=']')
        if 'Save?' in res:
            res = t.get('yes', condition='onfirm]', timeout=20)
        if 'reload?' in res:
            res = t.get('', condition='/NOREAD')
        return {}


    def Download(self, params, t):
        return handle_Download(params, t)


    def Upload(self, params, t, cpe=None, c={}):
        return handle_Upload(params, t, cpe, c)

add_model(('cisco.IOS_IGD', IOS_IGD()))

