 # vim: set sw=4 expandtab :
 #
 # Copyright 2004 Apache Software Foundation 
 # 
 # Licensed under the Apache License, Version 2.0 (the "License"); you
 # may not use this file except in compliance with the License.  You
 # may obtain a copy of the License at
 #
 #      http://www.apache.org/licenses/LICENSE-2.0
 #
 # Unless required by applicable law or agreed to in writing, software
 # distributed under the License is distributed on an "AS IS" BASIS,
 # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
 # implied.  See the License for the specific language governing
 # permissions and limitations under the License.
 #
 # Originally developed by Gregory Trubetskoy.
 # 
 # The code in this file originally donated by Graham Dumpleton.
 # 
 # $Id: importer.py 481741 2006-12-03 09:14:06Z grahamd $

from mod_python import apache

import os
import sys
import new
import traceback


# Define alternate implementations of the top level
# mod_python entry points and substitute them for the
# standard one in the 'mod_python.apache' callback
# object.

_callback = apache._callback

_status_values = {
    "postreadrequesthandler":   [ apache.DECLINED, apache.OK ],
    "transhandler":             [ apache.DECLINED ],
    "maptostoragehandler":      [ apache.DECLINED ],
    "inithandler":              [ apache.DECLINED, apache.OK ],
    "headerparserhandler":      [ apache.DECLINED, apache.OK ],
    "accesshandler":            [ apache.DECLINED, apache.OK ],
    "authenhandler":            [ apache.DECLINED ],
    "authzhandler":             [ apache.DECLINED ],
    "typehandler":              [ apache.DECLINED ],
    "fixuphandler":             [ apache.DECLINED, apache.OK ],
    "loghandler":               [ apache.DECLINED, apache.OK ],
    "handler":                  [ apache.DECLINED, apache.OK ],
}

def _execute_target(req, ob, arg):
    try:
        return ob(arg)
    except apache.SERVER_RETURN, value:
        # For a connection handler, there is no request
        # object so this form of response is invalid.
        # Thus exception is reraised to be handled later.

        if not req:
            raise

        # The SERVER_RETURN exception type when raised
        # otherwise indicates an abort from below with
        # value as (result, status) or (result, None) or
        # result.

        if len(value.args) == 2:
            (result, status) = value.args
            if status:
                req.status = status
        else:
            result = value.args[0]

        return result

# Define an alternate implementation of the module
# importer system and substitute it for the standard one
# in the 'mod_python.apache' module.

def import_module(module_name):
    return __import__(module_name, {}, {}, ['*'])

apache.import_module = import_module


def _construct_ob(handler, default):
    if '::' in handler:
        module_name, object_str = handler.split('::', 1)
    else:
        module_name = handler
        object_str = default

    module = import_module(module_name)
    return apache.resolve_object(module, object_str)


__ob_cache = {}


def _process_target(config, req, handler, default, arg):
    if not callable(handler):
        if handler not in __ob_cache:
            __ob_cache[handler] = _construct_ob(handler, default)

        ob = __ob_cache[handler]

    else:
        ob = handler

    # Lookup expected status values that allow us to
    # continue when multiple handlers exist.

    expected = _status_values.get(default, None)

    # Default to apache.DECLINED unless in content
    # handler phase.

    if not expected or apache.DECLINED not in expected:
        result = apache.OK
    else:
        result = apache.DECLINED

    result = _execute_target(req, ob, arg)

    # Stop iteration when target object returns a
    # value other than expected values for the phase.

    if expected and result not in expected:
        return (True, result)

    return (False, result)


def FilterDispatch(self, filter):
    """ This is the dispatcher for input/output filters.  """
    if filter.is_input:
        default_handler = "inputfilter"
    else:
        default_handler = "outputfilter"

    try:
        _process_target(
                config=filter.req.get_config(),
                req=filter.req,
                handler=filter.handler,
                default=default_handler,
                arg=filter)

        if not filter.closed:
            filter.flush()
    except:
        filter.disable()

        try:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            self.ReportError(exc_type, exc_value,
                    exc_traceback, req=filter.req, filter=filter,
                    phase="Filter: " + filter.name,
                    hname=filter.handler)
        finally:
            exc_traceback = None

    return apache.OK

def HandlerDispatch(self, req, handlers):
    """This is the dispatcher for handler phases."""

    # Cache name of phase in case something changes it.

    phase = req.phase

    # Determine the default handler name.

    default_handler = phase[len("python"):].lower()

    # Be cautious and return server error as default.

    result = apache.HTTP_INTERNAL_SERVER_ERROR

    # Cache configuration for later.

    config = req.get_config()

    handler = ''
    aborted = False
    try:
        # Iterate over the handlers defined for the
        # current phase and execute each in turn
        # until the last is reached or prematurely
        # aborted.
        for handler in handlers:
            aborted, result = _process_target(
                config=config,
                req=req,
                handler=handler,
                default=default_handler,
                arg=req)

            if aborted:
                break
    except:
        try:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            result = self.ReportError(
                exc_type,
                exc_value,
                exc_traceback,
                req=req,
                phase=phase,
                hname=handler)
        finally:
            exc_traceback = None

    return result

_callback.FilterDispatch = new.instancemethod(
        FilterDispatch, _callback, apache.CallBack)
_callback.HandlerDispatch = new.instancemethod(
        HandlerDispatch, _callback, apache.CallBack)


def ReportError(self, etype, evalue, etb, conn=None, req=None, filter=None,
                phase="N/A", hname="N/A", debug=0):

    try:
        try:
            # Determine which log function we are going
            # to use to output any messages.

            if filter and not req:
                req = filter.req

            if req:
                log_error = req.log_error
            elif conn:
                log_error = conn.log_error
            else:
                log_error = apache.main_server.log_error

            # Always log the details of any exception.

            pid = os.getpid()
            iname = apache.interpreter
            flags = apache.APLOG_ERR

            text = "mod_python (pid=%d, interpreter=%s, " % (pid, `iname`)
            text = text + "phase=%s, handler=%s)" % (`phase`, `hname`)
            text = text + ": Application error"

            log_error(text, flags)

            if req:
                hostname = req.server.server_hostname
                root = req.document_root()

                log_error('ServerName: %s' % `hostname`, flags)
                log_error('DocumentRoot: %s' % `root`, flags)
                log_error('URI: %s' % `req.uri`, flags)
                log_error('Filename: %s' % `req.filename`, flags)
                log_error('PathInfo: %s' % `req.path_info`, flags)

            tb = traceback.format_exception(etype, evalue, etb)

            for line in tb:
                log_error(line[:-1], flags)

            return apache.HTTP_INTERNAL_SERVER_ERROR
        except:
            # When all else fails try and dump traceback
            # directory standard error and flush it.

            traceback.print_exc()
            sys.stderr.flush()

    finally:
        etb = None

_callback.ReportError = new.instancemethod(
    ReportError, _callback, apache.CallBack)
